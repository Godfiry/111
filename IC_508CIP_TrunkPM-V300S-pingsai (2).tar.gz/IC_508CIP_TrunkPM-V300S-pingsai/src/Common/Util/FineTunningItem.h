/*
 * FineTunningItem.h
 *
 *  Created on: 2023-08-29
 *      Author: taohao
 */

#ifndef SRC_COMMON_UTIL_FINETUNNINGITEM_H_
#define SRC_COMMON_UTIL_FINETUNNINGITEM_H_

#include "Alarm.h"
#include "ReadWriteInt.h"
#include "ReadWriteDouble.h"
#include "ReadWriteString.h"
#include "StrTool.h"
#include <iostream>
#include "ControlObjectEX.h"
#ifdef IAP4_0
using namespace IAP::ALARM;
using namespace IAP::IO;
#endif

class FineTunningItem :public ControlObjectEX
{
    DECLARE_DYNAMIC( FineTunningItem )
    DECLARE_MSG_MAP

    public:
        FineTunningItem();
        virtual ~FineTunningItem();

    public:
        void setRcpIntOffset(string sRcpParamName,int offset);
        void setRcpDoubleOffset(string sRcpParamName,double offset);
        void setRFRunMode(bool bRFMode);

        double getTunningValue(string sStpParName);

        void setSetupTunningCh(const string strParamName, const string &strpath);
    protected:
        map<string,int> m_rcpIntOffset;
        map<string,double> m_rcpDoubleOffset;
        ReadWriteInt *m_cfgFineTunningType;

        map<string,ReadWriteDouble*> m_tunningCh;
        bool m_RFPowerMode;
};

#endif /* SRC_COMMON_UTIL_FINETUNNINGITEM_H_ */
