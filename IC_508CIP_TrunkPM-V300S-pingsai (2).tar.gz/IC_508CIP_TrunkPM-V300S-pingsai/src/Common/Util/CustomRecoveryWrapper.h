/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					2013-08-01  lijj  create 
**      
***************************************************************************/
#ifndef CUSTOMRECOVERYWRAPPER_H_
#define CUSTOMRECOVERYWRAPPER_H_

#include "CustomRecoveryInterface.h"
#include "RecoveryAction.h"
#ifdef IAP4_0
using namespace IAP::ALARM;
#endif

class CustomRecoveryWrapper : public RecoveryAction
{
	private:
		CustomRecoveryInterface *m_owner;
		
	public:
		CustomRecoveryWrapper(CustomRecoveryInterface *owner);
		virtual ~CustomRecoveryWrapper();
		
		virtual bool execute(const Alarm *alarm, Recovery *recovery);
};

#endif /*CUSTOMRECOVERYWRAPPER_H_*/
