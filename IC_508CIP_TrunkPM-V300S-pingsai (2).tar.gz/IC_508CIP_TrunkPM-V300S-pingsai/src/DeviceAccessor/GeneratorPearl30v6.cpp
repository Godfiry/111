/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: GeneratorPearl30v6.cpp
** Description:  
** Release: 1.1
** Modification history: 
**					2020-4-4   mujy create
*********************************************************************/
#include "GeneratorPearl30v6.h"
#include "DeviceManager.h"

#include "Converter.h"
#include "StrTool.h"
#include "Hex.h"
#include "CheckCalculationTool.h"
#include <cctype>
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std; 

GeneratorPearl30v6::Cmd GeneratorPearl30v6::m_cmd[] = {{""},//reserved
											{":01100000000102",0},//1.turn the RF output off/On, 1:RF ON; 0:RF OFF
											{":01100000000102",2},//2. 1:Parallel Pre  0:Serial Pre
											{":01100000000102",3},//3.Reset generator faults, 1:Fault Reset,0:Normal state
											{":01100000000102",5},//4.power mode: 0 is Forward,1 is Load // 30M20 not support
											{"",0},                       //5 ..
											{":01100001000102",0},//6 set the power setpoint in watts to x
											{"",0},//7 ..
											{"",0},//8 ..
											{"",0},//9 ..
											{":010340000001",0},//10 get output forward power
											{":010340010001",0},//11 get output reverse power
											{":010340050001",0},//12 read Frequency MHz
											{":010340040001",0x0001},//13 get status, bit 0 is RF ON/OFF
											{":010340040001",0x0004},//14 get status, bit 2 is Fault;
											{":010340040001",0x0010},//15 get status, bit 4 is Interlock open
											{":010340040001",0x0100},//16 get status, bit 8 is link Intergrity fault
											{":010340040001",0x0200},//17 get status, bit 9 is Over temp condition
											{":010340040001",0x0040},//18 get status, bit 6 is Parallel Preference
											{":010308060001",0xFFFF} //19 get fault,bit 0:panel switch open; bit 1:Thermal switch open;  // 30M20 not support
																					//bit 3:Interlock open; bit 7: Pr trip; bit 11:Abnormal state of DC Power; bit 13: Power over

};
GeneratorPearl30v6::GeneratorPearl30v6():SerialDevice(200, "\x0D\x0A")
{
	m_timeOut = 50;//5s
	m_pollPeriod = 200; //200ms

	//m_nAddress0000 = 0;

	m_nFullScale = 0x1FFF;//8191
}

GeneratorPearl30v6::~GeneratorPearl30v6()
{
}

string GeneratorPearl30v6::sendCommandAndReadResponse(string &strCommond, int nTimeOut)
{
	string strResponse = getCommandResult(strCommond, nTimeOut);

	if(strResponse.find("\x0D\x0A",0) == string::npos)
	{
		throw IOException("Generator send command ["+strCommond+"] occurred error [" + strResponse+"]");
	}
	size_t nPos = 0;  //changed by wzd 1.1.39
	string strCommondHead = strCommond.substr(0,5);
	if(strResponse.find(strCommondHead,0) != string::npos)
	{
		return strResponse;
	}
	else if((nPos = strResponse.find(":0190",0)) != string::npos || (nPos = strResponse.find(":0183",0)) != string::npos)
	{
		string strErrorCode = strResponse.substr(nPos+5,2);
		throw IOException("Generator send command ["+strCommond+"] occurred error, error code is [" + strErrorCode+"]");
	}
	else
	{
		throw IOException("Generator send command ["+strCommond+"] failed for unknown response [" + strResponse+"]");
	}
}

int GeneratorPearl30v6::readAddress0000(int nTimeOut)
{
	string strCommand = ":010300000001FB";

	string strResponse = sendCommandAndReadResponse(strCommand, nTimeOut);
	size_t nPos = strResponse.find(":");  //changed by wzd 1.1.39
	int nValueInAddress0000 = 0;

	string strSplitValue = strResponse.substr(nPos+7,4);
	cout<<strSplitValue<<endl;
	if(!Hex::stringToHex(&nValueInAddress0000, strSplitValue))
	{
		cout<<"response "<<strSplitValue <<" invalid."<<endl;
		throw IOException(strSplitValue + " is invalid.");
	}
	if(nValueInAddress0000 & 0x0001)
	{
		cout<<"In write register 0x0000, RF is On"<<endl;
	}
	else
	{
		cout<<"In write register 0x0000, RF is Off"<<endl;
	}
	//
	if(nValueInAddress0000 & 0x0008)
	{
		cout<<"In write register 0x0000, Fault reset"<<endl;
	}
	else
	{
		cout<<"In write register 0x0000, Normal State"<<endl;
	}
	//
	if(nValueInAddress0000 & 0x0020)
	{
		cout<<"In write register 0x0000, Load Control"<<endl;
	}
	else
	{
		cout<<"In write register 0x0000, Forward Control"<<endl;
	}
	return nValueInAddress0000;
}

bool GeneratorPearl30v6::writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
	string strCommand = m_cmd[nChannelNum].m_strAddress;

	double dTempValue = dValue * m_nFullScale / typeInfo.getMax();
	int nTemp = (int) dTempValue;
	string strTemp = Hex::hexToString(nTemp,4);
	
	strCommand += strTemp;
	strCommand += CheckCalculationTool::GetLRCCode(strCommand);
	strCommand = StrTool::toUpper(strCommand);
	string strResponse = sendCommandAndReadResponse(strCommand, m_timeOut);
	return true;
}
		
bool GeneratorPearl30v6::readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo)
{
	Cmd cmd = m_cmd[nChannelNum];
	string strCommand = cmd.m_strAddress + CheckCalculationTool::GetLRCCode(cmd.m_strAddress);
	strCommand = StrTool::toUpper(strCommand);
	string strResponse = sendCommandAndReadResponse(strCommand, m_timeOut);
	size_t nPos = strResponse.find(":");  //changed by wzd 1.1.39
	string strSplitValue = strResponse.substr(nPos+7, 4);
	int nValue = 0;
	if(nChannelNum == 12) //frequency
	{
		if(!Converter::stringToInt(nValue, strSplitValue))
		{
			throw IOException("Generator read frequency failed for can't convert response ["+strSplitValue+"] to integer value.");
		}
		*pValue = (double)nValue;
		return true;
	}
	else
	{
		if(!Hex::stringToHex(&nValue, strSplitValue))
		{
			throw IOException("Generator read power/reflect power failed for can't convert response ["+strSplitValue+"] to integer value.");
		}
		else
		{
			*pValue = (double)nValue * typeInfo.getMax() / m_nFullScale;
			return true;
		}
	}

}
		
bool GeneratorPearl30v6::readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
	Cmd cmd = m_cmd[nChannelNum];
	string strCommand = cmd.m_strAddress + CheckCalculationTool::GetLRCCode(cmd.m_strAddress);
	strCommand = StrTool::toUpper(strCommand);

	string strResponse = sendCommandAndReadResponse(strCommand, m_timeOut);
	size_t nPos = strResponse.find(":");  //changed by wzd 1.1.39
	string strSplitValue = strResponse.substr(nPos+7, 4);
	int nValue = 0;
	if(!Hex::stringToHex(&nValue, strSplitValue))
	{
		throw IOException("Generator read status failed for can't convert response ["+strSplitValue+"] to integer value.");
	}
	else
	{
		if(nChannelNum == 19)
			*pValue = nValue;
		else 
			*pValue = (nValue & cmd.m_nDeal) != 0;

		switch(nChannelNum)
		{
			case 14:
			case 15:
			case 16:
			case 17:
			case 19:
				if(*pValue)
				{
					SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "GeneratorPearl30v6: channel ["+Converter::convertToString(nChannelNum)+"] read back = "+strResponse +" ;split value = "+strSplitValue);
				}
				break;
			default:
				break;
		}
		return true;
	}	
}
		
bool GeneratorPearl30v6::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
	string strCommand = "";
	int nTempAddress0000 = readAddress0000(m_timeOut);
	unsigned char bitmask = 1;
	bitmask = bitmask << m_cmd[nChannelNum].m_nDeal;

	if(nValue == 1)
	{
		nTempAddress0000 = nTempAddress0000 | bitmask;
	}
	else
	{
		bitmask = ~bitmask;
		nTempAddress0000 = nTempAddress0000 & bitmask;
	}
	string strData = Hex::hexToString(nTempAddress0000,4);
	strCommand = m_cmd[nChannelNum].m_strAddress + strData;
	strCommand += CheckCalculationTool::GetLRCCode(strCommand);
	strCommand = StrTool::toUpper(strCommand);//need test to decide if keep it
	string strResponse = sendCommandAndReadResponse(strCommand,m_timeOut);
	//m_nAddress0000 = nTempAddress0000;
	return true;
}

void GeneratorPearl30v6::initChs(DeviceNode<GeneratorPearl30v6> *pNode)
{
	pNode->registerWriteCh(1, &GeneratorPearl30v6::writeInt);
	pNode->registerWriteCh(3, &GeneratorPearl30v6::writeInt);
	pNode->registerWriteCh(4, &GeneratorPearl30v6::writeInt);
	pNode->registerWriteCh(6, &GeneratorPearl30v6::writeDouble);
	for(int i = 10; i<=12; ++i)
	{
		pNode->registerReadCh(i, &GeneratorPearl30v6::readDouble);
	}
	for(int i = 13; i<=19; ++i)
	{
		pNode->registerReadCh(i, &GeneratorPearl30v6::readInt);
	}
	pNode->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &GeneratorPearl30v6::getStatus);
}

void GeneratorPearl30v6::initDevice()
{
	cout<<"Start Scan pearl generator...."<<endl;
	//say hello to generator
	try
	{
		readAddress0000(m_timeOut);
		writeInt(2, 0, IntTypeInfo());
	}
	catch(exception &ex)
	{
		cout<<"Scan pearl generator failed. Communication abnormal!"<<endl;
		throw;
	}
	cout<<"Scan pearl generator Successfully...."<<endl;
}

void GeneratorPearl30v6::init()
{
	DeviceNode<GeneratorPearl30v6> *pNode = new DeviceNode<GeneratorPearl30v6>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
	if(!isSimulated())
	{
		initChs(pNode);
		initDevice();
	}	
}

IMPLEMENT_DYNAMIC(GeneratorPearl30v6, SerialDevice )

BEGIN_MSG_MAP(GeneratorPearl30v6, SerialDevice )
	SET_V( init, GeneratorPearl30v6 )
END_MSG_MAP
