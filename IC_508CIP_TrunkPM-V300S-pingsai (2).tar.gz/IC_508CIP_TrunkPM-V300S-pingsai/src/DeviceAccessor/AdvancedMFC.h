/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AdvancedMFC.h
** Description:This Driver is use for DeviceNet MFC(Brooks,Horiba,QiXing MFC all apply)  
** Release: 1.1
** Modification history: 
** 					2008-5-21   LiJuanjuan create
**      
*********************************************************************/
#ifndef ADVANCEDMFC_H_
#define ADVANCEDMFC_H_

#include "IODevice.h"
#include "DoubleTypeInfo.h"
#include "ReadWriteInt.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class AdvancedMFC:public IODevice
{
	DECLARE_DYNAMIC(AdvancedMFC)	
	DECLARE_MSG_MAP
	public:
		AdvancedMFC();
		virtual ~AdvancedMFC();

	public://override
		virtual void init();
		virtual void initDevice();
		void setMFCNegativeEnable(bool bEnable);//add by guoj

		void setGasPressureFullScale(double dFullScale);  //add by chensc 1.6.0
		void setGasTempFullScale(double dFullScale);  //add by chensc 1.6.0
		void setMFCValue(const std::string &strPath);
		void setSimulatedFromSetup(const std::string &strPath);//zhangyy add for gas CIP
	public:
		bool setGasFlow(int channelNum, double value, const DoubleTypeInfo &typeInfo);
		bool getGasFlow(int channelNum, double *value, const DoubleTypeInfo &typeInfo);
		virtual bool getStatus(int nChannelNum, int *pBit, const IntTypeInfo &typeInfo);

		bool getGasPressure(int channelNum, double *value, const DoubleTypeInfo &typeInfo);    //add by wzd 1.1.61
		bool getGasTemp(int channelNum, double *value, const DoubleTypeInfo &typeInfo);     //add by chensc 1.6.0

	private:
		int m_nInBytesSize;
		int m_nOutBytesSize;
		bool m_bMFCNegativeEnable;//add by guoj

		double m_dPressureFullScale;  //add by chensc 1.6.0
		double m_dTempFullScale;  //add by chensc 1.6.0
		int m_nMFCMaxValue;
		double m_dSimulateGasFlow;
};

#endif /*ADVANCEDMFC_H_*/
