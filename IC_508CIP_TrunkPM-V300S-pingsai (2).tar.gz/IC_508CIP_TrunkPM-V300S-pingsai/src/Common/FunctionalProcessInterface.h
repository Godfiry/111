/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					Feb 22, 2008  shenql  create 
**      
***************************************************************************/
#ifndef FUNCTIONALPROCESSINTERFACE_H_
#define FUNCTIONALPROCESSINTERFACE_H_

#include "ServiceResultInfo.h"
#include "ExecRcpHandler.h"
#include "AppRcpBody.h"
#include "AppRecipeManager.h"
#ifdef IAP4_0
using namespace IAP::RECIPE;
#endif

class FunctionalProcessInterface
{
public:
	virtual ~FunctionalProcessInterface(){}

    virtual bool call_PrepareForProcessingMaterial() = 0;//taohao[v1.5.0_HotFix] modify for obtain the recipe from the memory
	
	virtual bool call_ProcessMaterial() = 0;

	virtual double getTotalProcessTime() = 0;
};

#endif /*FUNCTIONALPROCESSINTERFACE_H_*/
