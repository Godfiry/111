/************************************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: IOMonitorLogThread.h
** Description: This file includes declaration of class IOMonitorLogThread.          
** Release: 1.0
** Modification history: 
*************************************************************************************/


#ifndef IOMONITORLOGTHREAD_H_
#define IOMONITORLOGTHREAD_H_


#include "IThread.h"
#include "FileLogger.h"
#include "IOMonitor.h"
#include <unistd.h>  //add by wzd 1.1.39
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

class IOMonitorLogThread : public IThread,public ManagedObject
{
	DECLARE_JOINT( IOMonitorLogThread)
	
	public:
		IOMonitorLogThread();
		virtual ~IOMonitorLogThread();
		
	public:
		void setLogPath(std::string & strPath);
		void setIOMonitor(IOMonitor *);
		void toExit();
	
	protected:
		virtual void dealWithTheData(MonitorData &pData);// fixed by liusy 1.1.47
		virtual void run();
	
	private:
		void getData();
		
	protected:
		FileLogger * m_plogger;
	private:
		IOMonitor * m_pMonitor;
		volatile bool m_bExit;
};
#endif /*IOMONITORLOGTHREAD_H_*/
