/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TCPDeviceHoriba.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-7-21   LiJuanjuan create
**      
*********************************************************************/
#include "TCPDeviceHoriba.h"
#include "TCPConnectionHoriba.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#include <string.h>
#ifdef IAP4_0
using namespace IAP;
#endif
using namespace std;

TCPDeviceHoriba::TCPDeviceHoriba()
{
	m_connection = NULL;
	m_server = "";
	m_port = "";
	m_nodeNum = -1;
	m_pollInterval = 200;//ms
	m_timeOut = 10;//s
	m_checkInterval = 100;//ms
	m_connected = false;
	m_running = true;
	memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
}

TCPDeviceHoriba::~TCPDeviceHoriba()
{
	m_running = false;
	if(m_connection != NULL)
	{
		m_connection->disconnect();
		delete m_connection;
		m_connection = NULL;//mujy added 20160616[v1.0.16]

	}
}

void TCPDeviceHoriba::setServer(const std::string &server)
{
	m_server = server;
}
	
void TCPDeviceHoriba::setPort(const string &port)
{
	m_port = port;
}

void TCPDeviceHoriba::sendData(const char *data, int size)
{
	try
	{
		m_connection->sendData(data, size);	
	}
	catch(const exception &ex)
	{
		setDeviceConnected(false);
		throw;
	}
}

void TCPDeviceHoriba::setNodeNum(int nodeNum)
{
	m_nodeNum = nodeNum;
}

void TCPDeviceHoriba::setPollIntervalMS(int interval)
{
	m_pollInterval = interval;
}

void TCPDeviceHoriba::setTimeOutS(int timeOut)
{
	m_timeOut = timeOut;
}

void TCPDeviceHoriba::init()
{
	m_connection = new TCPConnectionHoriba(m_server, m_port);
	m_connection->setDevice(this);
	m_connection->connect();
	setDeviceConnected(true);
}

bool TCPDeviceHoriba::isConnected()const
{
	return m_connection->isConnected() && m_connected;
}

void TCPDeviceHoriba::setDeviceConnected(bool flag)
{
	m_connected = flag;
}

bool TCPDeviceHoriba::reconnectDevice()
{
	setDeviceConnected(true);
	return true;
}

bool TCPDeviceHoriba::readData(char *buffer, int len)
{
	if(!m_connection->recvData(buffer, len))
	{
		setDeviceConnected(false);
		return false;
	}
	else
	{
		return true;
	}
}
		
bool TCPDeviceHoriba::readFixLenData(char *buffer, int len)
{
	if(!m_connection->recvFixLenData(buffer, len))
	{
		setDeviceConnected(false);
		return false;
	}
	else
	{
		return true;
	}
}

std::string TCPDeviceHoriba::getDeviceName()
{
	return "Unknown";
}

IMPLEMENT_JOINT(TCPDeviceHoriba, AbstractDevice)
BEGIN_MSG_MAP( TCPDeviceHoriba, AbstractDevice)
	SET_S( setServer, TCPDeviceHoriba )  
	SET_S( setPort, TCPDeviceHoriba )
	SET_I( setNodeNum, TCPDeviceHoriba )
	SET_I( setPollIntervalMS, TCPDeviceHoriba )
	SET_I( setTimeOutS, TCPDeviceHoriba )
	SET_V( init, TCPDeviceHoriba )
END_MSG_MAP
