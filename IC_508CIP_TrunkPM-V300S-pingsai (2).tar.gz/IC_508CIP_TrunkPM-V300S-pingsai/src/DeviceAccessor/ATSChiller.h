/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: ATSChiller.h
** Description: This driver is used for Institute of Automation Chiller 
*                RS485
* 				   Communication Type:Modbus protocol,ASCII Mode
* 				   BaudRate:9600
*                DataBit:7
*                StopBit:1
*                Parity:Even
*                FlowControl:no flow control 
*                          
** Release: 1.1
** Modification history: 
** 					2009-11-25   LiJuanjuan create
**      			2021-1-28	chenmz modify [V1.1.3] for being compatible with Dual Channel.
*********************************************************************/
#ifndef ATSCHILLER_H_
#define ATSCHILLER_H_

#include "SerialDevice.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class ATSChiller:public SerialDevice
{
	DECLARE_DYNAMIC(ATSChiller)	
	DECLARE_MSG_MAP	
	
	public:
		ATSChiller();
		virtual ~ATSChiller();
		
		bool writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo);
		bool readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);
		bool readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);
		bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
		void init();

	protected:
		void initDevice();
		void initChs(DeviceNode<ATSChiller> *pNode);

	private:
		typedef struct
		{
			std::string m_strAddress;
			int m_nDeal;
		}Cmd;
		
		static Cmd m_cmd[];
};

#endif /*ATSCHILLER_H_*/
