#include "SMEEChiller.h"
#include "ObjectManager.h"
#include "DeviceManager.h"


#include <stdio.h>
#include <cctype>
#include <sstream>
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
using namespace IAP;
#endif
using namespace std;

SMEEChiller::Cmd SMEEChiller::m_cmd[]={{""},
                                     {"STR1",0},//start
                                     {"STP1",0},//stop
                                     {"SET1_",0},//2 set temperature  
                                     {"RTV1",0},//3 read temprature
                                     {"RPV1",0},//4 read pump Pressure
                                     {"RFV1",0},//5 read water flow
                                     {""},//6 read fault summary
                                     {""},//7 read warn summary
                                     {""},//8 read local remote
                                     {"RAM1"},//9 read alarm
                                     
                                     {"STR2",0},//start
                                     {"STP2",0},//stop
                                     {"SET2_",0},//12 set temperature  
                                     {"RTV2",0},//13 read temprature
                                     {"RPV2",0},//14 read pump Pressure
                                     {"RFV2",0},//15 read water flow
                                     {""},//16 read fault summary
                                     {""},//17 read warn summary
                                     {""},//18 read local remote
                                     {"RAM2"}//19 read alarm
                                     };
SMEEChiller::SMEEChiller():SerialDevice(200, "\x0D\x0A")
{
    m_timeOut=200;
    m_pollPeriod=1000;
    m_channel = 1;
}

SMEEChiller::~SMEEChiller()
{
}

bool SMEEChiller::writeDouble(int channelNum, double value,const DoubleTypeInfo &typeInfo)
{
     string cmd;
     string strValue;
     stringstream stream;
     stream<<value;
     stream>>strValue;
     if(strValue.find(".",0)==string::npos)
     {
         strValue+=".0";
     }
     if(channelNum==2)
     {
         cmd=m_cmd[3].m_address+strValue;
     }
     else if(channelNum==12)
     {
         cmd=m_cmd[13].m_address+strValue;
     }
     else
     {
         return false;
     }
    sendCommandOnly(cmd);
    return true;
}

double SMEEChiller::stringToDouble(string strValue)
{
    double strDouble=0;
    if(strValue!="")
    {
     stringstream stream;
     stream.clear();
     stream<<strValue;
     stream>>strDouble;
    }
      return strDouble;
}
bool SMEEChiller::readDouble(int channelNum, double *value,const DoubleTypeInfo &typeInfo)
{
    string cmd;
    string resp;
    unsigned int index=0;
        cmd=m_cmd[channelNum+1].m_address;
    string t_res = getCommandResult(cmd, m_timeOut);
    switch(channelNum)
    {
        case 3:
        case 13:
           index=t_res.find("C",0);
           if(index!=string::npos)
           {
                resp=t_res.substr(0,index);
           }
        break;
        case 4:
        case 14:
           index=t_res.find("BAR",0);
           if(index!=string::npos)
           {
                resp=t_res.substr(0,index);
           }
        break;
        case 5:
        case 15:
           index=t_res.find("L",0);
           if(index!=string::npos)
           {
                resp=t_res.substr(0,index);
           }
        break;
        default:
        break;
    }
    *value=stringToDouble(resp);
    return true;
}

bool SMEEChiller::writeInt(int channelNum, int value,const IntTypeInfo &typeInfo)
{
    string strStart;
    string strStop;
    if(channelNum==1)
    {
        strStart=m_cmd[1].m_address;
        strStop=m_cmd[2].m_address;
    }
    else if(channelNum=11)
    {
        strStart=m_cmd[11].m_address;
        strStop=m_cmd[12].m_address;
    }
    else
    {
        return false;
    }
    if(value==0)
    {
        sendCommandOnly(strStop);
    }
    else
    {
        sendCommandOnly(strStart);
    }
    return true;

}
bool SMEEChiller::readInt(int channelNum, int *value,const IntTypeInfo &typeInfo)
{
    string strValue;
    switch(channelNum)
    {
        case 6:
        case 16:
         *value=0;
        break;
        case 7:
        case 17:
         *value=0;
        break;
        case 8:
        case 18:
          *value=1;
        break;
        case 9:
        case 19:
          if(readAlarm(channelNum,strValue))
           {
                 if(strValue[2]!='0'||strValue[3]!='0'||strValue[4]!='0'||strValue[5]!='0')
                 {
                      *value=1;
                 }
                 else
                 {
                      *value=0;
                 }
           }
           else
           {
                return false;
           }
         break;
        default:
        break;
    }
    return true;
}

bool SMEEChiller::readAlarm(int channelNum,string &strValue)
{
    string cmd;
    if(channelNum==9)
    {
        cmd=m_cmd[10].m_address;
    }
    else if(channelNum==19)
    {
        cmd=m_cmd[20].m_address;
    }
    else
    {
        return false;
    }
    string t_res = getCommandResult(cmd, m_timeOut);

    if(t_res.find("$",0)!=string::npos)
    {
        strValue=t_res;
        return true;
    }
    else if(t_res.find("?",0)!=string::npos)
    {
        throw IOException("Illegal command error:"+t_res);
    }
    else if(t_res.find("!",0)!=string::npos)
    {
        throw IOException("Command execution failed error:"+t_res);
    }
    else
    {
        throw IOException("Unknown read_back:"+t_res);
    }

}
void SMEEChiller::initDevice()
{

}
void SMEEChiller::initChs(DeviceNode<SMEEChiller>* node)
{
    if(m_channel = 1)//single channel chiller
    {
        node->registerWriteCh(1, &SMEEChiller::writeInt);
        node->registerWriteCh(2, &SMEEChiller::writeDouble);
        for(int i=3;i<=5;i++)
        {
            node->registerReadCh(i, &SMEEChiller::readDouble);
        }
       for(int i=6;i<=9;i++)
       {
               node->registerReadCh(i, &SMEEChiller::readInt);
       }
    }
    else if(m_channel = 2)//Dual channel chiler
    {
        node->registerWriteCh(1, &SMEEChiller::writeInt);
        node->registerWriteCh(11, &SMEEChiller::writeInt);
        node->registerWriteCh(2, &SMEEChiller::writeDouble);
        node->registerWriteCh(12, &SMEEChiller::writeDouble);
        for(int i=3;i<=5;i++)
        {
            node->registerReadCh(i, &SMEEChiller::readDouble);
            node->registerReadCh(i+10, &SMEEChiller::readDouble);
        }
       for(int i=6;i<=9;i++)
       {
               node->registerReadCh(i, &SMEEChiller::readInt);
               node->registerReadCh(i+10, &SMEEChiller::readInt);
       }
    }
}
void SMEEChiller::init()
{
    DeviceNode<SMEEChiller> *node = new DeviceNode<SMEEChiller>(m_pollPeriod, this);
    DeviceManager::getInstance()->registerNode(m_nodeNum, node);
    if(!isSimulated())
    {
        initChs(node);
        initDevice();
    }
}
void SMEEChiller::setChannel(int i)
{
    m_channel=i;
} 
IMPLEMENT_DYNAMIC(SMEEChiller, SerialDevice )

BEGIN_MSG_MAP(SMEEChiller, SerialDevice )
    SET_I(setChannel,SMEEChiller)
    SET_V( init, SMEEChiller )
END_MSG_MAP
