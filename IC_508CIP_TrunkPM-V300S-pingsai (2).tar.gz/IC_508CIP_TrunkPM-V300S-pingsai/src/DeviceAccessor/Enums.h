/*******************************************************************************
** Copyright (c) 2019 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: Enums.h
** Description:  
** Release: 1.0
** Modification history:           
** 					2019-05-29   Duq create
** 
 ******************************************************************************/
 
#ifndef ENUMS_H_
#define ENUMS_H_

#include <stdlib.h>
#include <stdint.h>

//cip status
typedef enum EnIPNetworkStatus {OnLine, OnLineReadRejected, OnLineWriteRejected, OnLineForwardOpenReject, OffLine}EnIPNetworkStatus;

// Volume 2 : Table 2-3.2 Encapsulation Commands
typedef enum EncapsulationCommands
{
    Nop = 0x0000,   // Application keep alive
    ListServicesCommand = 0x0004,
    ListIdentityCommand = 0x0063,
    ListInterfacesCommand = 0x0064,
    RegisterSessionCommand = 0x0065,
    UnRegisterSessionCommand = 0x0066,
    SendRRDataCommand = 0x006F,
    SendUnitDataCommand = 0x0070,
    IndicateStatusCommand = 0x0072,
    CancelCommand = 0x0073
}EncapsulationCommands;

// Volume 2 : Table 2-3.3 Error Codes
// Another time these documents are a bag of shit
// this table shows 16 bits status	
typedef enum EncapsulationStatus
{
    EncapsulationStatus_Success = 0x00000000,
    Unsupported_Command = 0x00000001,
    Insufficient_Memory = 0x00000002,
    Incorrect_Data = 0x00000003,
    Invalid_Session_Handle = 0x00000064,
    Invalid_Length = 0x00000065,
    Unsupported_Protocol_Revision= 0x00000069
}EncapsulationStatus;

// Volume 1 : Table A-3.1 CIP Service Codes and Names
// High bit 0 for query, 1 for response
typedef enum CIPServiceCodes
{
    GetAttributesAll = 0x01,
    SetAttributeAll = 0x02,
    GetAttributeList = 0x03,
    SetAttributeList = 0x04,
    Reset = 0x05,
    Start = 0x06,
    Stop = 0x07,
    Create = 0x08,
    Delete = 0x09,
    MultipleServicePacket = 0x0A,
    ApplyAttributes = 0x0D,
    GetAttributeSingle = 0x0E,
    SetAttributeSingle = 0x10,
    FindNextObjectInstance = 0x11,
    Restore = 0x15,
    Save = 0x16,
    NOP = 0x17,
    GetMember = 0x18,
    SetMember = 0x19,
    InsertMember = 0x1A,
    RemoveMember = 0x1B,
    GroupSync = 0x1C,
    ForwardCloseService = 0x4E,
    UnconnectedSend = 0x52,
    ForwardOpenService = 0x54,  
    LargeForwardOpenService = 0x5B
}CIPServiceCodes;

// Volume 1 : Table B-1.1 CIP General Status Codes
typedef enum CIPGeneralSatusCode
{
    CIPGeneralSatusCode_Success = 0,
    Connection_failure = 1,
    Resource_unavailable = 2,
    Invalid_parameter_value = 3,
    Path_segment_error = 4,
    Path_destination_unknown = 5,
    Partial_transfer = 6,
    Connection_lost = 7,
    Service_not_supported = 8,
    Invalid_attribute_value = 9,
    Attribute_list_error = 10,
    Already_in_requested_mode_state = 11,
    Object_state_conflict = 12,
    Object_already_exists = 13,
    Attribute_not_settable = 14,
    Privilege_violation = 15,
    Device_state_conflict = 16,
    Reply_data_too_large = 17,
    Fragmentation_of_a_primitive_value = 18,
    Not_enough_data = 19,
    Attribute_not_supported = 20,
    Too_much_data = 21,
    Object_does_not_exist = 22,
    Service_fragmentation_sequence_not_in_progress = 23,
    No_stored_attribute_data = 24,
    Store_operation_failure = 25,
    Routing_failure_request_packet_too_large = 26,
    Routing_failure_response_packet_too_large = 27,
    Missing_attribute_list_entry_data = 28,
    Invalid_attribute_value_list = 29,
    Embedded_service_error = 30,
    Vendor_specific_error = 31,
    Invalid_parameter = 32,
    Write_once_value_or_medium_already_written = 33,
    Invalid_reply_received = 34,
    Buffer_overflow = 35,
    Invalid_message_format = 36,
    Key_failure_in_path = 37,
    Path_size_invalid = 38,
    Unexpected_attribute_in_list = 39,
    Invalid_Member_ID = 40,
    Member_not_settable = 41,
    Group_2_only_server_general_failure = 42,
    Unknown_Modbus_error = 43,
    Attribute_not_gettable = 44
}CIPGeneralSatusCode;
	
// Volume 2 : Table 2-6.3 Item ID Numbers
typedef enum CommonPacketItemIdNumbers
{
    CommonPacketItemIdNumbers_NULL = 0x0000,
    ListIdentityResponse = 0x000C,
    ConnectionBased = 0x00A1,
    ConnectedDataItem = 0x00B1,
    UnConnectedDataItem = 0x00B2,
    ListServicesResponse = 0x0100,
    SocketaddrInfo_O2T = 0x8000,
    SocketaddrInfo_T2O = 0x8001,
    SequencedAddressItem = 0x8002
}CommonPacketItemIdNumbers;

#endif  /* ENUMS_H_ */
