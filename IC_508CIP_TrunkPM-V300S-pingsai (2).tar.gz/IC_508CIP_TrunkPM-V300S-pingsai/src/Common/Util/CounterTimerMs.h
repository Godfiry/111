/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
**                  Feb 22, 2008  shenql  create 
*                   2010-01-18 lijj modified
**      
***************************************************************************/
#ifndef COUNTERTIMERMS_H_
#define COUNTERTIMERMS_H_

#include "TimerSubscriber.h"
#include "ReadWriteDouble.h"
#include "IntTypeInfo.h"
#include "Timer.h"
#include "ReadWriteInt.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
#endif

class CounterTimerMs : public TimerSubscriber
{
    private:
        double m_periodInSeconds;
        int m_counterType;
        ReadWriteDouble *m_timerItem;
        IntTypeInfo m_typeInfo;
        static const int Up = 0;
        static const int Down = 1;  
        #ifdef IAP4_0
        IAP::CORE::TimerPtr m_myTimer;
        #else
        Timer *m_myTimer;
        #endif
        bool m_running;
        long m_startTime;
        double m_initialTime;
        double m_dCollectTime;
        ReadWriteInt* m_pCollectData;//added by mujy[20170807] 
        double m_dThreshold;  //add by xiezr v1.1.48_hotfix2
     
    private:
        CounterTimerMs(const CounterTimerMs& pObj); //modified by chenw [1.6.0_RC02]

        CounterTimerMs& operator=(const CounterTimerMs& pObj);

    public:
        CounterTimerMs();

        ~CounterTimerMs();
        CounterTimerMs(ReadWriteDouble *data, int counterType, double period);
        CounterTimerMs(ReadWriteDouble *data, int counterType, double period,ReadWriteInt *collectData,double collectTime);//added by mujy[20170807]
        CounterTimerMs(ReadWriteDouble *data, int counterType, double period,ReadWriteInt *collectData, double collectTime, double updateThreshold);  //add by xiezr v1.1.48_hotfix2
        
        void setCounterType(int i);
        
        void setCounterType(std::string s);
        
        void setPeriod(double d);//seconds
        
        void setTimerItem(ReadWriteDouble* data);
        
        void setCollectTime(double dTime); //added by mujy[20170807]
        
        void start();
        
        void stop();
        
        #ifdef IAP4_0
        void updateFromTimer(const Timer * const timer);
        #else
        void updateFromTimer();
        #endif
};

#endif /*COUNTERTIMERMS_H_*/
