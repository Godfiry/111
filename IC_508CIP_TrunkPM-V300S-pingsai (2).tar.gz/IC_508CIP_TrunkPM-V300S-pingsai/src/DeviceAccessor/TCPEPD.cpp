/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TCPEPD.cpp
** Description:  
** Release: 1.1
** Modification history: 
**                     2009-7-21   LiJuanjuan create
**      
*********************************************************************/
#include "TCPEPD.h"
#include "DeviceManager.h"
#include "SysLogger.h"
#include "ConfigException.h"
#include <iostream>
#include <string.h>
#include <StrTool.h>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;

TCPEPD::TCPEPD()
{
    m_timeOut = 8;//s (reference to verity manual )
    m_checkInterval = 100;//ms
    m_configList = "";
    m_configName = "";
    m_epdStatus = 0;//
    m_endPoint = 0;
    m_endPointTime = 0.0;
    m_errorStr = "";
    m_nameOfSPCV = "";
    m_version = "";
    memset(m_sndBuffer, 0, sizeof(m_sndBuffer));

    m_vecError.clear();
    m_nErrorSeverity = ERROR_MESSAGE_SEVERITY::Normal;
    m_strErrorMoreInfo = "";
}

TCPEPD::~TCPEPD()
{
    if(!isSimulated())
    {
        try
        {
            m_running = false;
            disconnectEPD();
        }
        catch(const exception &ex)
        {
        }
    }
}

bool TCPEPD::writeI(int channelNum, int setpt, const IntTypeInfo &)
{
    if (!isConnected() && channelNum != 7)//not connect
    {
        throw IOException("EPD device is not connected!");
    }
    switch(channelNum)
    {
        case 0: //present
            sendCmd(&m_PRESENT);
            break;

        case 1: //reset
            sendCmd(&m_RESET);
            break;

        case 2:// test
            sendCmd(&m_TEST);
            break;

        case 3://startwithrecipe
            {
                m_endPoint = 0;
                m_endPointTime = 0.0;
                m_START.m_cmd.Length = strlen(m_configName.c_str());
                memcpy(m_START.m_cmd.Text, m_configName.c_str(), m_START.m_cmd.Length);
                sendCmd(&m_START);
            }
            break;

        case 4://stop
            sendCmd(&m_STOP);
            m_endPoint = 0;
            break;

        case 5://complete
            sendCmd(&m_COMPLETE);
            m_endPointTime = 0;//added by taohao [1.9.1] for reset EPDTime channel befor process
            break;

        case 6://only send configlist cmd
            sendCmd(&m_CFGLIST);
            break;

        case 7://connect
            sendCmd(&m_CONNECT);
            setDeviceConnected(true);
            break;

        case 8://version
            sendCmd(&m_VERSION);
            break;

        case 9://disconnect
            sendCmd(&m_DISCONNECT);
            setDeviceConnected(false);
            break;
        case 13:
            m_nErrorSeverity = ERROR_MESSAGE_SEVERITY::Normal;
            setErrorStr("");
            m_strErrorMoreInfo = "";
            break;
        default:
            break;
    }
    return true;
}

bool TCPEPD::readI(int channelNum, int *value, const IntTypeInfo &)
{
    if (!isConnected() && channelNum != 10)//not epdstatus
    {
        throw IOException("EPD device is not connected!");
    }
    switch(channelNum)
    {
        case 10: //epdstatus
            *value = m_epdStatus;
            break;
        case 11: //EndPoint
            *value = m_endPoint;
            break;
        case 12:// ErrorSeverity
            *value = m_nErrorSeverity;
            break;
        case 46:// Ping added by guojin[1.1.43]
            #ifdef IAP4_0
            long timeFromStart = ITime::getCurrentTimeAsSeconds()- m_pingStartTime;
            #else
            long timeFromStart = Time::getCurrentTimeAsSeconds()- m_pingStartTime;
            #endif
            if ((timeFromStart % m_pingInterval == 0) && (m_pingLastTime != timeFromStart))
            {
                try
                {
                    sendCmd(&m_TEST);

                }
                catch(const exception &ex)
                {
                    *value = 0;
                    m_pingStatus = 0;
                    m_pingLastTime = timeFromStart;
                    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": Ping is exception ");
                    return true;
                }
                m_pingStatus = 1;

            }
            *value = m_pingStatus;
            m_pingLastTime = timeFromStart;
            break;

    }
    return true;
}

bool TCPEPD::readS(int channelNum, std::string *value, const StringTypeInfo &)
{
    if (!isConnected())
    {
        throw IOException("EPD device is not connected!");
    }
    switch(channelNum)
    {
        case 30: // error
            *value = getErrorStr();
            break;

        case 31: //configurelist
            *value = m_configList;
            break;

        case 32: //version
            *value = m_version;
            break;
        case 33:
            *value = m_strErrorMoreInfo;
            break;
    }
    return true;
}

void TCPEPD::setErrorStr(const std::string &error)
{
    IMutexLocker locker(&m_lockErrorStr);
    m_errorStr = error;
}

std::string TCPEPD::getErrorStr()
{
    IMutexLocker locker(&m_lockErrorStr);
    return m_errorStr;
}

bool TCPEPD::writeS(int channelNum, std::string value, const StringTypeInfo &)
{
    if (!isConnected())
    {
        throw IOException("EPD device is not connected!");
    }
    switch(channelNum)
    {
        case 40: // configname
            m_configName = value;
            return true;

        case 41: //lot
            m_vtyWaferDesc.Label = "Lot";
            m_vtyWaferDesc.Text = value.c_str();
            m_vtyWaferDesc.Flags = VTY_WAFER_LOT_NAME;
            break;

        case 42: //slot
            m_vtyWaferDesc.Label = "Slot";
            m_vtyWaferDesc.Text = value.c_str();
            m_vtyWaferDesc.Flags = VTY_WAFER_SLOT;
            break;

        case 43: // wafer
            m_vtyWaferDesc.Label = "Wafer";
            m_vtyWaferDesc.Text = value.c_str();
            m_vtyWaferDesc.Flags = VTY_WAFER_WAFERID;
            break;

        case 44: //recipe
            m_vtyWaferDesc.Label = "Recipe";
            m_vtyWaferDesc.Text = value.c_str();
            m_vtyWaferDesc.Flags = VTY_WAFER_RECIPE;
            break;

        case 45: //step
            m_vtyWaferDesc.Label = "Step";
            m_vtyWaferDesc.Text = value.c_str();
            m_vtyWaferDesc.Flags = VTY_WAFER_STEP_NUM;
            break;
    }

    /*
    //compose waferinfo command

    char t_buffer[BUFFER_SIZE] = {0};
    tVTYDynString t_dynStr;
    int t_index = 0;
    int t_len = 0;

    //copy Label
    t_dynStr = m_vtyWaferDesc.Label.Text;
    t_index = t_dynStr.Write(t_buffer);
    memcpy(m_WAFERINFO.m_cmd.Text, t_buffer+10, t_index-10);//10 is the length of non text data
    t_len = t_index - 10;

    //copy Text
    memset(t_buffer, 0, sizeof(t_buffer));
    //memset(t_dynStr, 0, sizeof(t_dynStr));
    t_dynStr = tVTYDynString();
    t_dynStr = m_vtyWaferDesc.Text.Text;
    t_index = t_dynStr.Write(t_buffer);
    memcpy(m_WAFERINFO.m_cmd.Text + t_len, t_buffer+10, t_index-10);//10 is the length of non text data
    t_len += t_index - 10;

    //copy Flags
    for(unsigned int i=0; i<sizeof(m_vtyWaferDesc.Flags); ++i)
    {
        unsigned char t_buf = (m_vtyWaferDesc.Flags >> (i*8)) & 0xFF;
        memcpy(m_WAFERINFO.m_cmd.Text+t_len, &t_buf, 1);
        t_len += 1;
    }
    m_WAFERINFO.m_cmd.Length = t_len;
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPEPD about to send wafer info " + string(m_vtyWaferDesc.Label.Text) + " - " + string(m_vtyWaferDesc.Text.Text));

    sendCmd(&m_WAFERINFO);*/

    sendWfrInfo();
    return true;
}


void TCPEPD::sendWfrInfo()
{
    //compose command
    char t_sndBuf[300];
    memset(t_sndBuf, 0, sizeof(t_sndBuf));
    int t_size = 130*2 + 4 +10;

    m_WAFERINFO.m_cmd.Length = 130*2;//size of two _tVTYString. not include DWORD, for the next line code will add 4 to the length
    m_WAFERINFO.m_cmd.Write(t_sndBuf);
    memcpy(t_sndBuf+10, m_vtyWaferDesc.Label, sizeof(_tVTYString));
    memcpy(t_sndBuf+10+130, m_vtyWaferDesc.Text, sizeof(_tVTYString));
    for(unsigned int i=0; i<sizeof(m_vtyWaferDesc.Flags); ++i)
    {
        unsigned char t_buf = (m_vtyWaferDesc.Flags >> (i*8)) & 0xFF;
        memcpy(t_sndBuf+10+130+130+i, &t_buf, 1);
    }


    //send command
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPEPD sending cmd -waferinfo");
    m_WAFERINFO.m_successful = false;
    sendData(t_sndBuf, t_size);
    int t_leftcount = m_timeOut*1000/m_checkInterval;
    while(t_leftcount > 0)
    {
        if(m_WAFERINFO.m_successful)
        {
            if(m_WAFERINFO.m_status == VTY_OK)
            {
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPEPD sended cmd -waferinfo");
                return;
            }
            else if(m_WAFERINFO.m_status == VTY_FAIL)
            {
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": TCPEPD get fail ack for cmd - waferinfo.error is " + m_WAFERINFO.m_error);
                throw IOException("[EPD Issue]: Failed to get ACK of command [waferinfo]. Error is " + m_WAFERINFO.m_error);
            }
            else
            {
                throw IOException("[EPD Issue]: Get unknown ACK of command [waferinfo]. Error is " + m_WAFERINFO.m_error);
            }
        }
        usleep(m_checkInterval*1000);
        --t_leftcount;
    }
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": TCPEPD waiting for cmd ack time out-waferinfo");
    throw IOException("[EPD Issue]: Waiting for ACK of command [waferinfo] time out");
}


bool TCPEPD::readD(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
    if (!isConnected())
    {
        throw IOException("EPD device is not connected!");
    }
    if(channelNum == 20)
    {
        *value = MathTool::Round(m_endPointTime,0.001);
    }
    else
    {
        double dValue = getTrendData("EPDTrend" + Converter::convertToString(channelNum - 20));
        if(dValue < 0)
        {
            *value = 0;
        }
        else
        {
            *value = MathTool::Round(dValue,typeInfo.getAccuracy());
        }
    }
    return true;
}

double TCPEPD::getTrendData(const std::string &name)
{
    IMutexLocker locker(&m_lockTrendData);
    return m_trendDatas[name]->m_value;
}

void TCPEPD::initChannels(DeviceNode<TCPEPD> *node)
{
    for (int i = 0; i <= 9; i++)
    {
        node->registerWriteCh(i,&TCPEPD::writeI);
    }
    for (int i = 10; i <= 12; i++)
    {
        node->registerReadCh(i,&TCPEPD::readI);
    }

    node->registerWriteCh(13,&TCPEPD::writeI);

    for (int i = 20; i <= 26; i++)
    {
        node->registerReadCh(i,&TCPEPD::readD);
    }

    for (int i = 30; i <= 33; i++)
    {
        node->registerReadCh(i,&TCPEPD::readS);
    }
    for (int i = 40; i <= 45; i++)
    {
        node->registerWriteCh(i,&TCPEPD::writeS);
    }
    node->registerReadCh(46,&TCPEPD::readI);//added by guojin[1.1.43]

    node->registerReadCh(COMMUNICATION_STATUS_CHANNEL,&TCPEPD::getStatus);
}



void TCPEPD::initCmd()
{
    m_CONNECT.m_name = "connect";
    m_CONNECT.m_successful = false;
    m_CONNECT.m_status = VTY_FAIL;
    m_CONNECT.m_error = "";
    m_CONNECT.m_cmd.LogicalPort = VTY_LP_TOURI;
    m_CONNECT.m_cmd.Command = VTY_CONNECT;
    m_CONNECT.m_cmd.Status = 0;
    m_CONNECT.m_cmd.Length = strlen(m_nameOfSPCV.c_str());
    memcpy(m_CONNECT.m_cmd.Text, m_nameOfSPCV.c_str(), m_CONNECT.m_cmd.Length);

    m_VERSION.m_name = "version";
    m_VERSION.m_successful = false;
    m_VERSION.m_status = VTY_FAIL;
    m_VERSION.m_error = "";
    m_VERSION.m_cmd.LogicalPort = VTY_LP_TOURI;
    m_VERSION.m_cmd.Command = VTY_CMD_VERSION;
    m_VERSION.m_cmd.Status = 0;
    m_VERSION.m_cmd.Length = strlen(m_nameOfSPCV.c_str());
    memcpy(m_VERSION.m_cmd.Text, m_nameOfSPCV.c_str(), m_VERSION.m_cmd.Length);

    m_COMPLETE.m_name = "complete";
    m_COMPLETE.m_successful = false;
    m_COMPLETE.m_status = VTY_FAIL;
    m_COMPLETE.m_error = "";
    m_COMPLETE.m_cmd.LogicalPort = VTY_LP_TOURI;
    m_COMPLETE.m_cmd.Command = VTY_CMD_COMPLETE;
    m_COMPLETE.m_cmd.Status = 0;
    m_COMPLETE.m_cmd.Length = 0;

    m_TEST.m_name = "test";
    m_TEST.m_successful = false;
    m_TEST.m_status = VTY_FAIL;
    m_TEST.m_error = "";
    m_TEST.m_cmd.LogicalPort = VTY_LP_TOURI;
    m_TEST.m_cmd.Command = VTY_CMD_TEST;
    m_TEST.m_cmd.Status = 0;
    m_TEST.m_cmd.Length = 0;

    m_RESET.m_name = "reset";
    m_RESET.m_successful = false;
    m_RESET.m_status = VTY_FAIL;
    m_RESET.m_error = "";
    m_RESET.m_cmd.LogicalPort = VTY_LP_TOURI;
    m_RESET.m_cmd.Command = VTY_CMD_RESET;
    m_RESET.m_cmd.Status = VTY_RSC_RESETALL;
    m_RESET.m_cmd.Length = 0;

    m_PRESENT.m_name = "present";
    m_PRESENT.m_successful = false;
    m_PRESENT.m_status = VTY_FAIL;
    m_PRESENT.m_error = "";
    m_PRESENT.m_cmd.LogicalPort = VTY_LP_TOURI;
    m_PRESENT.m_cmd.Command = VTY_CMD_PRESENT;
    m_PRESENT.m_cmd.Status = 0;
    m_PRESENT.m_cmd.Length = 0;

    m_CFGLIST.m_name = "cfglist";
    m_CFGLIST.m_successful = false;
    m_CFGLIST.m_status = VTY_FAIL;
    m_CFGLIST.m_error = "";
    m_CFGLIST.m_cmd.LogicalPort = VTY_LP_TOURI;
    m_CFGLIST.m_cmd.Command = VTY_CMD_CFG_LIST;
    m_CFGLIST.m_cmd.Status = 0;
    m_CFGLIST.m_cmd.Length = 0;


    m_START.m_name = "start";
    m_START.m_successful = false;
    m_START.m_status = VTY_FAIL;
    m_START.m_error = "";
    m_START.m_cmd.LogicalPort = VTY_LP_TOURI;
    m_START.m_cmd.Command = VTY_CMD_START;
    m_START.m_cmd.Status = 0;

    m_STOP.m_name = "stop";
    m_STOP.m_successful = false;
    m_STOP.m_status = VTY_FAIL;
    m_STOP.m_error = "";
    m_STOP.m_cmd.LogicalPort = VTY_LP_TOURI;
    m_STOP.m_cmd.Command = VTY_CMD_STOP;
    m_STOP.m_cmd.Status = 0;
    m_STOP.m_cmd.Length = 0;

    m_WAFERINFO.m_name = "waferinfo";
    m_WAFERINFO.m_successful = false;
    m_WAFERINFO.m_status = VTY_FAIL;
    m_WAFERINFO.m_error = "";
    m_WAFERINFO.m_cmd.LogicalPort = VTY_LP_TOURI;
    m_WAFERINFO.m_cmd.Command = VTY_CMD_WAFERINFO;
    m_WAFERINFO.m_cmd.Status = VTY_WISC_UPDATE;

    m_DISCONNECT.m_name = "disconnect";
    m_DISCONNECT.m_successful = false;
    m_DISCONNECT.m_status = VTY_FAIL;
    m_DISCONNECT.m_error = "";
    m_DISCONNECT.m_cmd.LogicalPort = VTY_LP_TOURI;
    m_DISCONNECT.m_cmd.Command = VTY_DISCONNECT;
    m_DISCONNECT.m_cmd.Status = 0;
    m_DISCONNECT.m_cmd.Length = 0;

    for(int i=0; i<6; ++i)
    {
        m_trendDatas.insert(TrendPair("EPDTrend" + Converter::convertToString(i+1), new TrendData(0.0, 0, -1)));
    }
}

void TCPEPD::connectEPD()
{
    sendCmd(&m_CONNECT);
    sendCmd(&m_VERSION);
    sendCmd(&m_RESET);
}

bool TCPEPD::reconnectDevice()
{
    if(!m_running)
    {
        return false;
    }
    try
    {
        connectEPD();
    }
    catch(const exception &ex)
    {
        return false;
    }
    return TCPDevice::reconnectDevice();
}

void TCPEPD::disconnectEPD()
{
    if(isConnected())
    {
        sendCmd(&m_DISCONNECT);
    }
}

void TCPEPD::initEPD()
{
    initCmd();
    connectEPD();
}

void TCPEPD::init()
{
    DeviceNode<TCPEPD> *node = new DeviceNode<TCPEPD>(m_pollInterval,this);
    DeviceManager::getInstance()->registerNode(m_nodeNum,node);

    if(!isSimulated())
    {
        initChannels(node);
        setPort(VTY_TCPIP_PORT);
        TCPDevice::init();
        initEPD();
        initErrorMessage();
    }
}

void TCPEPD::sendCmd(Cmd *cmd)
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPEPD sending cmd -" + cmd->m_name);
    memset(m_sndBuffer, 0, sizeof(m_sndBuffer));
    cmd->m_successful = false;
    int t_size = cmd->m_cmd.Write(m_sndBuffer);
    sendData(m_sndBuffer, t_size);
    int t_leftcount = m_timeOut*1000/m_checkInterval;
    while(t_leftcount > 0)
    {
        if(cmd->m_successful)
        {
            if(cmd->m_status == VTY_OK)
            {
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPEPD sended cmd -" + cmd->m_name);
                return;
            }
            else if(cmd->m_status == VTY_FAIL)
            {
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": TCPEPD get fail ack for cmd - "+ cmd->m_name + ".error is " + cmd->m_error);
                throw IOException("[EPD Issue]: Failed to get ACK of command ["+ cmd->m_name + "]. Error is " + cmd->m_error);
            }
            else
            {
                throw IOException("[EPD Issue]: Get unknown ACK of command ["+ cmd->m_name+ "]. Error is " + cmd->m_error);
            }
        }
        usleep(m_checkInterval*1000);
        --t_leftcount;
    }
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": TCPEPD waiting for cmd ack time out-" + cmd->m_name);
    throw IOException("[EPD Issue]: Waiting for ACK of command [" + cmd->m_name+"] time out");
}

void TCPEPD::acceptData()
{
    IMutexLocker t_locker(&m_lock);
    memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
    //memset(m_DynStringR, 0, sizeof(m_DynStringR));
    m_DynStringR = tVTYDynString();
    if(readFixLenData(m_recvBuffer,10))
    {
        m_DynStringR.PreRead(m_recvBuffer);
        if(m_DynStringR.Command < 200)
        {
            replyCmd();
        }
        else
        {
            replyEvent();
        }
    }
    else
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": TCPEPD reading header failed in acceptData()");
    }
}

void TCPEPD::replyCmd()
{
    switch(m_DynStringR.Command)
    {
        case VTY_CONNECT://connect
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got ack of CONNECT, length is "+ Converter::convertToString(m_DynStringR.Length));
            replyCmd(&m_CONNECT);
            break;

        case VTY_DISCONNECT://connect
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got ack of DISCONNECT, length is "+ Converter::convertToString(m_DynStringR.Length));
            replyCmd(&m_DISCONNECT);
            break;

        case VTY_CMD_VERSION://change to dynamic
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got ack of VERSION, length is "+ Converter::convertToString(m_DynStringR.Length));
            replyCmd(&m_VERSION);
            m_version = m_DynStringR.Text;
            break;

        case VTY_CMD_RESET://ResetACK
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got ack of RESET, length is "+ Converter::convertToString(m_DynStringR.Length));
            replyCmd(&m_RESET);
            break;

        case VTY_CMD_PRESENT://ResetACK
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got ack of PRESENT, length is "+ Converter::convertToString(m_DynStringR.Length));
            replyCmd(&m_PRESENT);
            break;

        case VTY_CMD_TEST://TestACK
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got ack of TEST, length is "+ Converter::convertToString(m_DynStringR.Length));
            replyCmd(&m_TEST);
            break;

        case VTY_CMD_CFG_LIST://CFG_LIST ACK
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got ack of CFGLIST, length is "+ Converter::convertToString(m_DynStringR.Length));
            readConfigList();
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got CFGLIST :" + m_configList);
            break;

        case VTY_CMD_COMPLETE://CompleteACK
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got ack of COMPLETE, length is "+ Converter::convertToString(m_DynStringR.Length));
            replyCmd(&m_COMPLETE);
                break;

        case VTY_CMD_SET_VAR://set var
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got ack of SETVAR, length is "+ Converter::convertToString(m_DynStringR.Length));
                flush();
                break;

        case VTY_CMD_START:
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got ack of START, length is "+ Converter::convertToString(m_DynStringR.Length));
            replyCmd(&m_START);
                break;

        case VTY_CMD_STOP:
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got ack of STOP, length is "+ Converter::convertToString(m_DynStringR.Length));
            replyCmd(&m_STOP);
                break;

           case VTY_CMD_WAFERINFO:
               SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got ack of WAFERINFO, length is "+ Converter::convertToString(m_DynStringR.Length));
               replyCmd(&m_WAFERINFO);
            break;

        case VTY_CMD_GET_VAR://get var for debug use
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got ack of GETVAR, length is "+ Converter::convertToString(m_DynStringR.Length));
            flush();
            break;

        default:
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got ack of UNKNOWN COMMAND:" + Converter::convertToString(m_DynStringR.Command) + ", length is "+ Converter::convertToString(m_DynStringR.Length));
            flush();
                break;
    }
}

void TCPEPD::replyCmd(Cmd *cmd)
{
    readDatas();
    cmd->m_status = m_DynStringR.Status;
    if(m_DynStringR.Status == VTY_FAIL)
    {
        cmd->m_error = m_DynStringR.Text;
    }
    else
    {
        cmd->m_error = "";
    }
    cmd->m_successful = true;
}

void TCPEPD::readDatas()
{
    if (m_DynStringR.Length > 0)
    {
        if(m_DynStringR.Length > s_INBUFFERSIZE) //changed by liuxj v2.1.32, for limit the data block's length.
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ":TCPEPD read datablock length more than 65535. length is  :" + Converter::convertToString(m_DynStringR.Length));
            flush();
            return;
        }
        memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
        bool res = readFixLenData(m_recvBuffer, m_DynStringR.Length);
        if (res)
        {
            m_DynStringR.Read(m_recvBuffer, m_DynStringR.Length);
        }
        else
        {
            string t_error = "readDatas time out";
            memcpy(m_DynStringR.Text, t_error.c_str(), sizeof(t_error));
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ":TCPEPD readDatas time out");
        }
    }
}


void TCPEPD::flush()
{
    if (m_DynStringR.Length > 0)
    {
        memset(m_recvBuffer, 0, sizeof(m_recvBuffer));

        int nReceiveLen = m_DynStringR.Length;

        while(nReceiveLen > s_INBUFFERSIZE)
        {
            readFixLenData(m_recvBuffer, s_INBUFFERSIZE);
            nReceiveLen -= s_INBUFFERSIZE;
        }

        readFixLenData(m_recvBuffer, nReceiveLen);
    }
}

void TCPEPD::replyEvent()
{
    switch(m_DynStringR.Command)
    {
        case VTY_EVENT_NOTREADY://EPD_NotReady
            m_epdStatus = 3;
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got event NOTREADY, length is "+ Converter::convertToString(m_DynStringR.Length));
            flush();
            break;

        case VTY_EVENT_READY://Ready
            m_epdStatus = 2;
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got event READY, length is "+ Converter::convertToString(m_DynStringR.Length));
            flush();
            break;
 
        case VTY_EVENT_RUNNING:
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got event RUNNING, length is "+ Converter::convertToString(m_DynStringR.Length));
            flush();
            break;

        case VTY_EVENT_MATRIX://VTY_EVENT_MATRIX
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got event MATRIX, length is "+ Converter::convertToString(m_DynStringR.Length));
            readMatrix();
            break;

        case VTY_EVENT_DATABLOCK://VTY_EVENT_DATABLOCK
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got event DATABLOCK, length is "+ Converter::convertToString(m_DynStringR.Length));
            readDataBlock();
            break;

        case VTY_EVENT_ENDPOINT://VTY_EVENT_ENDPOINT
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got event ENDPOINT, length is "+ Converter::convertToString(m_DynStringR.Length));
            readEPDTime();//changed by mujy for read EPDTime first
            m_endPoint = 1;
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got event ENDPOINT and endtime is " + Converter::convertToString(m_endPointTime));
            break;

        case VTY_EVENT_LOCAL://VTY_EVENT_LOCAL
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got event LOCAL, length is "+ Converter::convertToString(m_DynStringR.Length));
            flush();
            break;

        case VTY_EVENT_REMOTE://VTY_EVENT_REMOTE
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got event REMOTE, length is "+ Converter::convertToString(m_DynStringR.Length));
            flush();
            break;

        case VTY_EVENT_MARKEVENT://VTY_EVENT_RUNNING
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got event MARKEVENT, length is "+ Converter::convertToString(m_DynStringR.Length));
            readDatas();
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got event MARKEVENT : " + string(m_DynStringR.Text));
            break;

        case VTY_EVENT_ERROR://VTY_EVENT_ERROR
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got event ERROR, length is "+ Converter::convertToString(m_DynStringR.Length));
            readDatas();
            setErrorStr(m_DynStringR.Text);
            m_epdStatus = 3;//NotReady
            m_nErrorSeverity = dealWithErrorMessage(m_errorStr,m_strErrorMoreInfo);
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got event ERROR-" + m_errorStr);
            break;

        case VTY_EVENT_POWERUP://VTY_EVENT_POWERUP
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got event POWERUP, length is "+ Converter::convertToString(m_DynStringR.Length));
            readDatas();
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got event POWERUP device is : " + string(m_DynStringR.Text));
            break;

        default:
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got UNKNOWN EVENT:" + Converter::convertToString(m_DynStringR.Command) + ", length is "+ Converter::convertToString(m_DynStringR.Length));
            flush();
            break;
    }
}

int TCPEPD::dealWithErrorMessage(string strError, string &strMoreInfo)
{
    StrTool::string_replace(strError," ","");
    string strTemp = StrTool::toLower(strError);

    for(int i = 0; i < m_vecError.size(); i++)
    {
        if(strTemp.find(m_vecError[i].m_strMessageKey) != string::npos)
        {
            strMoreInfo = m_vecError[i].m_strMoreInfo;
            return m_vecError[i].m_nSeverityLevel;
        }
    }
    strMoreInfo = "";
    return ERROR_MESSAGE_SEVERITY::Normal;
}

void TCPEPD::readMatrix()
{
    IMutexLocker locker(&m_lockTrendData);
    if(m_DynStringR.Length > 0)
    {
        if(m_DynStringR.Length > s_INBUFFERSIZE) //changed by liuxj v2.1.32, for limit the data block's length.
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ":TCPEPD read datablock length more than 65535. length is  :" + Converter::convertToString(m_DynStringR.Length));
            flush();
            return;
        }
        //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ":TCPEPD got Matrix, number is " + Converter::convertToString(m_DynStringR.Status));
        memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
        bool res = readFixLenData(m_recvBuffer, m_DynStringR.Length);
        if(res)
        {
            std::map<std::string, TrendData*>::iterator t_it;
            int t_index = 0;
            tVTYDynString t_name;
            for(int i=0; i<m_DynStringR.Status; ++i)
            {
                //memset(t_name, 0, sizeof(t_name));
                t_name = tVTYDynString();
                t_index += t_name.Read(m_recvBuffer + t_index, m_DynStringR.Length - t_index);
                t_it = m_trendDatas.find(string(t_name.Text));
                if(t_it != m_trendDatas.end())
                {
                    memcpy(&(t_it->second->m_ID), m_recvBuffer+t_index, 2);//ID is 2 byte and right after name
                    //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ":TCPEPD got id of " + t_it->first + ", is " + Converter::convertToString(t_it->second->m_ID));
                }
                t_index += 6;//6 is length sum of ID, Type and DataInterval
            }
        }
        else
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ":TCPEPD read matrix timeout. length is  :" + Converter::convertToString(m_DynStringR.Length));
        }
    }
    else
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ":TCPEPD got wrong matrix number :" + Converter::convertToString(m_DynStringR.Status));
    }
}

void TCPEPD::readDataBlock()
{
    IMutexLocker locker(&m_lockTrendData);
    if(m_DynStringR.Length > 0)
    {
        if(m_DynStringR.Length > s_INBUFFERSIZE)
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ":TCPEPD read datablock length more than 65535. length is  :" + Converter::convertToString(m_DynStringR.Length));
            flush();
            return;
        }
        //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ":TCPEPD got DataBlock, number is " + Converter::convertToString(m_DynStringR.Status));
        memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
        bool res = readFixLenData(m_recvBuffer, m_DynStringR.Length);
        std::map<std::string, TrendData*>::iterator t_it;
        if(res)
        {
            char t_test[33] = {0};//33 is the length of a datablock item
            int t_in = 0;
            for(int i=0; i<m_DynStringR.Status; ++i)
            {
                memset(t_test, 0, 33);
                memcpy(t_test, m_recvBuffer+t_in, 33);
                for(t_it=m_trendDatas.begin(); t_it!=m_trendDatas.end(); ++t_it)
                {
                    if(((tVTYDataItem*)t_test)->DataItemID == t_it->second->m_ID)
                    {
                        t_it->second->m_offSet = ((tVTYDataItem*)t_test)->Offset;
                        //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ":TCPEPD get offset of " + t_it->first + " and offset is " + Converter::convertToString(t_it->second->m_offSet));
                    }
                }
                t_in += 33;
            }
            t_in += 33;
            char t_value[4] = {0};
            for(t_it=m_trendDatas.begin(); t_it!=m_trendDatas.end(); ++t_it)
            {
                memset(t_value, 0, sizeof(t_value));
                memcpy(t_value, m_recvBuffer + t_it->second->m_offSet, 4);
                t_it->second->m_value = *((float*)t_value);
                //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ":TCPEPD get value of " + t_it->first + " and value is " + Converter::convertToString(t_it->second->m_value));
            }
        }
        else
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ":TCPEPD read datablock timeout. length is  :" + Converter::convertToString(m_DynStringR.Length));
        }
    }
    else
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ":TCPEPD got wrong datablock number :" + Converter::convertToString(m_DynStringR.Status));
    }
}

void TCPEPD::readEPDTime()
{
    if (m_DynStringR.Length >0)
    {
        if(m_DynStringR.Length > s_INBUFFERSIZE) //changed by liuxj v2.1.32, for limit the data block's length.
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ":TCPEPD read datablock length more than 65535. length is  :" + Converter::convertToString(m_DynStringR.Length));
            flush();
            return;
        }
        memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
        bool res = readFixLenData(m_recvBuffer, m_DynStringR.Length);
        if (res)
        {
            tVTYEventData t_epd;
            t_epd.Read(m_recvBuffer, m_DynStringR.Length);
            m_endPointTime = t_epd.Time;
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ":TCPEPD got epdtime, time is " + Converter::convertToString(m_endPointTime) + ", code is " + Converter::convertToString(t_epd.Code) + ", text is " + t_epd.Text.Text);
        }
        else
        {
            m_endPointTime = 100.0;//declare error
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ":TCPEPD in readEPDTime() read epdtime timeout");
        }
    }
    else
    {
        m_endPointTime = 100.0;//declare error
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ":TCPEPD in readEPDTime() reading epdtime failed for data length is zero");
    }
}

void TCPEPD::readConfigList()
{
    m_CFGLIST.m_status = m_DynStringR.Status;
    if(m_DynStringR.Status == VTY_FAIL)
    {
        readDatas();
        m_CFGLIST.m_error = m_DynStringR.Text;
    }
    else if(m_DynStringR.Length == 0)
    {
        m_configList = "";
        m_CFGLIST.m_error = "";
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ":TCPEPD in readConfigList() configlist length is 0");
    }
    else
    {
        if(m_DynStringR.Length > s_INBUFFERSIZE) //changed by liuxj v2.1.32, for limit the data block's length.
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ":TCPEPD read datablock length more than 65535. length is  :" + Converter::convertToString(m_DynStringR.Length));
            flush();
            return;
        }
        memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
        bool res = readFixLenData(m_recvBuffer, m_DynStringR.Length);
        if(!res)
        {
            m_CFGLIST.m_error = "read time out and count is :" + Converter::convertToString(m_DynStringR.Length);
            m_DynStringR.Status = VTY_FAIL;
        }
        else
        {
            m_configList = "";
            m_CFGLIST.m_error = "";
            tVTYDynString t_name;
            unsigned int t_index = 0;
            while(t_index < m_DynStringR.Length)
            {
                t_index += t_name.Read(m_recvBuffer+t_index, m_DynStringR.Length - t_index);
                if(m_configList == "")
                {
                    m_configList = t_name.Text;
                }
                else
                {
                    m_configList += "," + string(t_name.Text);
                }
                //memset(t_name, 0, sizeof(t_name));
                t_name = tVTYDynString();
                t_index += t_name.Read(m_recvBuffer+t_index, m_DynStringR.Length - t_index);
                t_index += 4;//skip Size
            }
        }
    }
    m_CFGLIST.m_successful = true;
}

std::string TCPEPD::getDeviceName()
{
    return "EPD";
}

void TCPEPD::setDeviceConnected(bool flag)
{
    if(!flag)
    {
        m_epdStatus = 1;//disconnected
    }
    TCPDevice::setDeviceConnected(flag);
}

void TCPEPD::setNameOfSPCV(const std::string &name)
{
    if(name == "")
    {
        throw ConfigException("name can not be empty");
    }
    m_nameOfSPCV = name;
}

void TCPEPD::addErrorMessage(string strKey,int nSeverity, string strMoreInfo)
{
    StrTool::string_replace(strKey," ","");
    Error tmp;
    tmp.m_strMessageKey = StrTool::toLower(strKey);
    tmp.m_nSeverityLevel = nSeverity;
    tmp.m_strMoreInfo = strMoreInfo;
    m_vecError.push_back(tmp);
}

void TCPEPD::initErrorMessage()
{
    addErrorMessage("undefined message",ERROR_MESSAGE_SEVERITY::Error,"Error Message:No details are known; [CRLF]Cause: No system event matched the string; [CRLF]Corrective action: Determine source of undefined string.");
    addErrorMessage("device connection lost or missing",ERROR_MESSAGE_SEVERITY::Fault,"Error Message:SRM cannot communicate with the device or it is powered off; [CRLF]Cause: Communication failure. either through loss of power to the device or connection; [CRLF]Corrective action: Check power and communication connections to the spectrometer.");
    addErrorMessage("Flash lamp unavailable",ERROR_MESSAGE_SEVERITY::Warning,"Error Message:Lamp connection missing/lost after first detection; [CRLF]Cause: Loss of interlock connection. Power to device or communication to device; [CRLF]Corrective action: Check interlock and power and communication connections.");
    addErrorMessage("Spectrometer fan failure",ERROR_MESSAGE_SEVERITY::Warning,"Error Message:Fan on the spectrometer is showing improper electrical usage; [CRLF]Cause: Voltage drop detected in spectrometer fan; [CRLF]Corrective action: Spectrometer fan may need to be replaced soon.");
    addErrorMessage("Spectrometer temperature has exceeded the safe range",ERROR_MESSAGE_SEVERITY::Fault,"Error Message:The CPU is hot enough to do damage to the processor; [CRLF]Cause: Internal temperature has exceeded safe operating range. Possible fan failure. Possible TE cooling failure; [CRLF]Corrective action: Make sure the SpectraView instance name is correct in the SRM window.");
    addErrorMessage("Flash lamp fan failure",ERROR_MESSAGE_SEVERITY::Warning,"Error Message:Fan on the flash lamp is showing improper electrical usage; [CRLF]Cause: Voltage drop detected in flashlamp fan; [CRLF]Corrective action: Flashlamp fan may need to be replaced soon.");
    addErrorMessage("Unable to communicate with Spectra Resource Manager",ERROR_MESSAGE_SEVERITY::Fault,"Error Message:SRM does not have the instance registered or can't be started; [CRLF]Cause:SpectraView instance is not registered with SRM or the SRM application is not responding; [CRLF]Corrective action: Make sure the SpectraView instance name is correct in the SRM window.");
    addErrorMessage("Packet header is corrupted",ERROR_MESSAGE_SEVERITY::Fault,"Error Message:Message header values are not within valid ranges; [CRLF]Cause:Messages are being received slowly or out of sync; [CRLF]Corrective action: Investigate possible communication issues.");
    addErrorMessage("Packet of unexpected size was received",ERROR_MESSAGE_SEVERITY::Fault,"Error Message:Packet of unexpected size was received ; [CRLF]Cause: Messages are being received slowly or out of sync; [CRLF]Corrective action: Investigate possible communication issues.");
    addErrorMessage("Dynamic Mode no longer supported",ERROR_MESSAGE_SEVERITY::Fault,"Error Message: Dynamic Mode is a legacy R and D mode that is no longer supported by SpectraView; [CRLF]Cause: An attempt was made to use the legacy Dynamic Mode for device communication; [CRLF]Corrective action:Configure SRM if a spectrometer is needed for editing/processing.");
    addErrorMessage("The device is not for use with this installation",ERROR_MESSAGE_SEVERITY::Fault,"Error Message: The spectrometer code and/or customer ID are incompatible; [CRLF]Cause:The spectrometer identification is not for use with the application installation; [CRLF]Corrective action:Use a spectrometer developed for this customer.");
    addErrorMessage("Failed to get device parameters from Spectra Resource Manager",ERROR_MESSAGE_SEVERITY::Fault,"Error Message:The SRM Configuration information is corrupted; [CRLF]Cause:SRM is unable to provide the spectrometer details; [CRLF]Corrective action:Check communications and reconfigure SRM for this application instance.");
    addErrorMessage("The disk space is dangerously low after Auto Delete completed",ERROR_MESSAGE_SEVERITY::Warning,"Error Message:Repeated as the prescribed days are deleted/archived and the error level is still not recovered; [CRLF]Cause:Auto Delete cannot free enough disk space using the current settings and remaining space is critically low; [CRLF]Corrective action:Manually free disk space by removing files and/or adjust Auto Delete settings to remove old data sooner");
    addErrorMessage("The disk space is dangerously low after Auto Archive completed",ERROR_MESSAGE_SEVERITY::Warning,"Error Message:Repeated as the prescribed days are deleted/archived and the error level is still not recovered; [CRLF]Cause:Auto Archive cannot free enough disk space and remaining space is critically low; [CRLF]Corrective action:Manually free disk space by removing files and/or enable Auto Delete");
    addErrorMessage("Auto Archive could not locate destination directory",ERROR_MESSAGE_SEVERITY::Warning,"Error Message:The destination directory is not available for archiving; [CRLF]Cause:Root directory is missing.  Most often this occurs when a network location is no longer available; [CRLF]Corrective action:Change auto archive settings to the proper directory for data file archive");
    addErrorMessage("Failed to write data to the data file",ERROR_MESSAGE_SEVERITY::Error,"Error Message:Failed to write data to the data file; [CRLF]Cause:The operating system reported a failure when data was being saved to the data file; [CRLF]Corrective action:Check that the disk is not full or has errors");
    addErrorMessage("Exception thrown in run thread",ERROR_MESSAGE_SEVERITY::Fault,"Error Message:A fatal processing error; [CRLF]Cause:Internal software failure occurred while processing spectra for the current data interval; [CRLF]Corrective action:Determine if system memory is sufficient for this application or install a newer version.");
    addErrorMessage("Exception occurred in calculation thread",ERROR_MESSAGE_SEVERITY::Error,"Error Message:Failure to evaluate an equation, could cause endpoint to fail; [CRLF]Cause:Internal software failure occurred while processing equations; [CRLF]Corrective action:Determine if system memory is sufficient for this application or install a newer version.");
    addErrorMessage("Equation Exception",ERROR_MESSAGE_SEVERITY::Error,"Error Message:Failed to evaluate properly due to a calculation error or memory being too low to complete the operation; [CRLF]Cause:Internal software failure occurred while processing equations; [CRLF]Corrective action:Determine if system memory is sufficient for this application or install a newer version");
    addErrorMessage("Sequence Parameter Error",ERROR_MESSAGE_SEVERITY::Warning,"Error Message:A parameter to a sequence item is not in the valid range; [CRLF]Cause:It is likely that a variable has been set outside the valid range during process; [CRLF]Corrective action:Edit Sequence settings to ensure variable remains within valid range");
    addErrorMessage("Expression Exception",ERROR_MESSAGE_SEVERITY::Error,"Error Message:Expression calculation failure in a sequence item, could cause endpoint to fail; [CRLF]Cause:Internal software failure occurred while processing an expression in the sequence; [CRLF]Corrective action:Determine if system memory is sufficient for this application or install a newer version");
    addErrorMessage("Endpoint Statistics Database write error",ERROR_MESSAGE_SEVERITY::Warning,"Error Message:Endpoint Statistics Database write error; [CRLF]Cause:Internal operating system, hardware, or driver failure; [CRLF]Corrective action:Find and repair error in host operating system, hardware, or software installation");
    addErrorMessage("Unable to monitor directories for changes",ERROR_MESSAGE_SEVERITY::Error,"Error Message:One or more of the directories for data, Variables, or configurations cannot be found; [CRLF]Cause:One or more key directory does not exist or cannot be monitored by the system; [CRLF]Corrective action:Make sure all directories in the Tools->Options dialog exist");
    addErrorMessage("Spectral Latency",ERROR_MESSAGE_SEVERITY::Warning,"Error Message:Time has exceeded the data interval duration without a spectrum being received; [CRLF]Cause:Expected spectral data is at least one second late; [CRLF]Corrective action:Find and resolve the network or hardware cause for data arriving slowly or inconsistently");
    addErrorMessage("Flatline Spectrum",ERROR_MESSAGE_SEVERITY::Warning,"Error Message:There is an internal data collection or processing problem at the instrument; [CRLF]Cause:At least one raw spectral data source has no signal; [CRLF]Corrective action:An internal spectrometer problem must be analyzed and repaired");
    addErrorMessage("Saturated Spectrum",ERROR_MESSAGE_SEVERITY::Notification,"Error Message:One or more wavelength peaks has exceeded the maximum intensity read by the sensor; [CRLF]Cause:One or more spectral data source has one or more saturated wavelengths; [CRLF]Corrective action:If the saturated wavelengths are needed, attenuate the signal by reducing the integration or physically changing the light collected by the spectrometer.");
    addErrorMessage("Time Variation",ERROR_MESSAGE_SEVERITY::Warning,"Error Message:Time Variation; [CRLF]Cause:System and Data times are out of sync more than one second; [CRLF]Corrective action:Investigate network or other hardware causes for data to be lost or collected incorrectly");
    addErrorMessage("Non-Sequential Spectra",ERROR_MESSAGE_SEVERITY::Warning,"Error Message:Non-Sequential Spectra; [CRLF]Cause:The sequential order of a spectral data source was interrupted; [CRLF]Corrective action:Investigate network or other hardware causes for data to be lost or received out of order");
    addErrorMessage("Start Latency",ERROR_MESSAGE_SEVERITY::Warning,"Error Message:The actual start of SpectraView processing did not happen immediately upon receipt of the Start signal; [CRLF]Cause:The start response exceeded one second; [CRLF]Corrective action:Investigate if disk space is very low, a network error occurred, or other hardware cause");
    addErrorMessage("Processing Latency",ERROR_MESSAGE_SEVERITY::Warning,"Error Message:Multiple parameters are monitored to determine if processing is or will be falling behind real time; [CRLF]Cause:The processing is more than one second behind real-time; [CRLF]Corrective action:Investigate if CPU usage is extremely high or the complexity of equation calculations cannot be processed within the data interval");
    addErrorMessage("Sustained High CPU Usage",ERROR_MESSAGE_SEVERITY::Warning,"Error Message:The PC operating system is reading high computing activity at the processor core; [CRLF]Cause:The utilization of the processor(s) has been above 90% for over one second; [CRLF]Corrective action:Determine if the configuration complexity, number of Endpoint Application instances, outside programs/services, or user interactions should be reduced or eliminated");
    addErrorMessage("Flashlamp Misfire",ERROR_MESSAGE_SEVERITY::Warning,"Error Message:A misfire signal was received from the flashlamp; [CRLF]Cause:The flashlamp did not flash; [CRLF]Corrective action:The lamp element (bulb) in the flashlamp may need to be replaced soon");
    addErrorMessage("Disk Space Critically Low",ERROR_MESSAGE_SEVERITY::Warning,"Error Message:SpectraView is running low on hard drive space; [CRLF]Cause:The hard disk is >95% full; [CRLF]Corrective action:Enable or properly configure Auto Delete or Archive to ensure creation of data files does not fill the hard disk to dangerous levels");
    addErrorMessage("Disk Drive Latency",ERROR_MESSAGE_SEVERITY::Warning,"Error Message:Hard drive response is slow; [CRLF]Cause:Data file creation took more than one second; [CRLF]Corrective action:Check that the disk is not full or has errors, or if the size or complexity of the configuration requires significant time to load and initialize");
    addErrorMessage("Physical Memory Critically Low",ERROR_MESSAGE_SEVERITY::Warning,"Error Message:Available RAM is being overtaxed by processes being run by the SpectraView PC; [CRLF]Cause:The available physical memory has dropped below 5% available; [CRLF]Corrective action:Determine if the configuration complexity, number of Endpoint Application instances, outside programs/services, or user interactions should be reduced or eliminated");
    addErrorMessage("Processing Paused",ERROR_MESSAGE_SEVERITY::Notification,"Error Message:SpectraView has received a Pause command; [CRLF]Cause:The endpoint step has been paused by the tool or a user; [CRLF]Corrective action:In Local Mode, press the pause button again to continue.  In remote mode, the system will wait until the tool sends a command to resume processing");
}
IMPLEMENT_DYNAMIC(TCPEPD, TCPDevice )

BEGIN_MSG_MAP( TCPEPD, TCPDevice )
    SET_S( setNameOfSPCV, TCPEPD )
    SET_SIS(addErrorMessage,TCPEPD)
END_MSG_MAP

