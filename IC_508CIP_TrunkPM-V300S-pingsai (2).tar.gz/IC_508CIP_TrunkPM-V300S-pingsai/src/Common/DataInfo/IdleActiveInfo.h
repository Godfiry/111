/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					Jan 22, 2008  shenql  create 
**      
***************************************************************************/
#ifndef IDLEACTIVEINFO_H_
#define IDLEACTIVEINFO_H_
#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class IdleActiveInfo : public IntValueInfo
{
public:

		static const int UnInit = -1;
		static const int Idle = 0;
		static const int Active = 1;
		static const IntTypeInfo typeInfo;

	   IdleActiveInfo():IntValueInfo(-1, typeInfo)
	   {
	   }
	
	   IdleActiveInfo(int i):IntValueInfo(i, typeInfo)
	    {
	    }
	
	   IdleActiveInfo(std::string s):IntValueInfo(s, typeInfo)
	    {
	    }
};


#endif /*IDLEACTIVEINFO_H_*/
