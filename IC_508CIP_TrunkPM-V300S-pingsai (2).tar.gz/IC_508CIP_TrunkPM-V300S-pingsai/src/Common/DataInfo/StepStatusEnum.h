#ifndef STEPSTATUSENUM_H_
#define STEPSTATUSENUM_H_

namespace STEP_STATUS
{
	enum StepStatusEnum
	{
		Stop,
		CollectData,
		Start
	};
}

#endif /*MODULESTATUSENUM_H_*/
