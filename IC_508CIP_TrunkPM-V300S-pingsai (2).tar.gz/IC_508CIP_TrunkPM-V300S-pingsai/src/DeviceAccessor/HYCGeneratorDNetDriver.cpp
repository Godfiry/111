/*
 * HYCGeneratorDNetDriver.cpp
 *
 *  Created on: 2023��7��4��
 *      Author: liusiyuan
 */

#include "HYCGeneratorDNetDriver.h"
#include "DeviceManager.h"
#include <iostream>
#include <sys/time.h>
#include <sstream>
#include <string.h>
#include "Converter.h"
#include "Hex.h"
#include "MathTool.h"
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
#endif
using namespace std;

HYCGeneratorDNetDriver::Com HYCGeneratorDNetDriver::m_Commands[] = {{0, 0}, //0	reserved
											{4,0},//1.Byte4, Bit0 is Turn the RF output On/off:0:Off;1:On
											{4,2},//2.Byte4, Bit2 turn Tuning:0: Auto-Tune, 1: fixed    //IO value modified by zhangpf[1.1.48]
											{0,0},//3.reserve
											{4,3},//4.Byte4,Bit3,Level mode: 0:load leveling, 1:forward leveling;  //IO value modified by zhangpf[1.1.48]
											{4,1},//5.Byte4, Bit1, turn pulsing:0:off;1:On

											{0,0},//6.Byte0 and Byte1,set the power setpoint in watts to x, for
											{0,0},//7.reserve
											{3,0},//8,Byte3 and Byte4,set Pulse Frequency
											{2,0},//9.Byte2,set Pulse Duty
											{5,0},//10.Byte5 and Byte6,set start Frequency
											{7,0},//11.Byte7,Set StepGain
											{8,0},//12.Byte8 and Byte9,set cable length
											{10,0},//13.Byte10,STOP VSWR
											{11,0},//14.Byte11,START VSWR
											{12,0},//15.Byte12,RETUNE TIMER
											//-----------------------------------------------------------------------------------
											{0,0},//16.Byte0 and Byte1,get output forward power
											{2,0},//17.Byte2 and Byte3,get output reverse power
											{4,0},//18.Byte4 and Byte5,get Frequency
											{6,0},//19.Byte6,get PULSE Duty
											{7,0},//20.Byte7 and Byte 8,get PULSE Frequency
											{9,0},//21.Byte9 ,get STEP GAIN
											{10,0},//22.Byte10 and 11,get Cable Length
											{12,0},//23.Byte12,get STOP VSWR
											{13,0},//24.Byte13,get START VSWR
											{14,0},//25.Byte14,get RETUNE TIMER
											{15,0}, //26.Byte15,get Current VSWR
											{16,0},//27.Byte16,Bit 0,Power On status, 1=on,0 =off
											{16,1},//28.Byte16,Bit1, Sepoint status , 1=reached, 0=not reached
											{16,2},//29.Byte16,Bit2, Temperature Status, 1=Normal, 0=OverTemp
											{16,3},//30.Byte16,Bit3, Tuning Mode , 1=AutoTune, 0=FixedFrequency
											{16,4},//31.Byte16,Bit4, Interlock Status , 1=Satisfied, 0=Open
											{16,6},//32.Byte16,Bit5, Pulse Mode , 1=On, 0=Off
											{16,5}//33.Byte16,Bit6, Forward/Load Mode , 1=Forward, 0=Load
};


HYCGeneratorDNetDriver::HYCGeneratorDNetDriver() {
	// TODO Auto-generated constructor stub
	m_pWriteBuffer = NULL;
	m_pReadBuffer = NULL;

	m_nLastLevelMode = 1;
	m_nLastPulseMode = 0;
	m_nLastTuningMode = 1;
	m_nLastRFOnOffControl = 0;
	m_nLastCableLength = 15*100;
	m_nStartFrequency = 400*1000; //400kHz
}

HYCGeneratorDNetDriver::~HYCGeneratorDNetDriver() {
	// TODO Auto-generated destructor stub
	if(m_pWriteBuffer != NULL)
	{
		delete m_pWriteBuffer;
		m_pWriteBuffer = NULL;
	}
	if(m_pReadBuffer != NULL)
	{
		delete m_pReadBuffer;
		m_pReadBuffer = NULL;
	}
}


bool HYCGeneratorDNetDriver::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
	Com com = m_Commands[nChannelNum];

	unsigned char bitmask = 1;
	bitmask = bitmask << com.m_nBit;
	
	if(2 == nChannelNum || 4== nChannelNum)    //IO value modify by zhangpf[1.1.48]
	{
		nValue= nValue*(-1) + 1;
	}
	if(nValue == 1)
	{
		m_pWriteBuffer[com.m_nByte] = m_pWriteBuffer[com.m_nByte] | bitmask;
	}
	if(nValue == 0)
	{
		bitmask = ~bitmask;
		m_pWriteBuffer[com.m_nByte] = m_pWriteBuffer[com.m_nByte] & bitmask;
	}

	cout<<"write :: "<<Hex::GetHexString(m_pWriteBuffer, m_deviceNet->getOBytesSize(m_macID))<<endl;
	return m_deviceNet->writeByte(m_macID, m_pWriteBuffer);
}

bool HYCGeneratorDNetDriver::writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
	Com com = m_Commands[nChannelNum];
	unsigned long temp;
	if(nChannelNum == 6)//set power
	{
		temp = (unsigned long) (dValue * 4095.0 / typeInfo.getMax()); //0x0FFF

		m_pWriteBuffer[com.m_nByte] = (unsigned char)(temp & 0xff);
		m_pWriteBuffer[com.m_nByte + 1] = (unsigned char)((temp>>8) & 0x0f);

		//unsigned long  temp =(unsigned long)((value / m_maxLFPower) * 4095);//0xFFF
	}
	else if(nChannelNum == 8)//set Pulse Frequency
	{
		temp = (unsigned long) (dValue);

		m_pWriteBuffer[com.m_nByte] = (unsigned char)(temp & 0xff);
		m_pWriteBuffer[com.m_nByte + 1] = m_pWriteBuffer[com.m_nByte + 1] & 0x0F;
		m_pWriteBuffer[com.m_nByte + 1] = (((unsigned char)((temp>>8) & 0x0f))<<4) + m_pWriteBuffer[com.m_nByte + 1];
	}
	else if (nChannelNum == 9)//set Pulse Duty
	{
		temp = (unsigned long) (dValue);
		m_pWriteBuffer[com.m_nByte] = (unsigned char)(temp & 0xff);
	}
	else if ( 11== nChannelNum|| 13== nChannelNum|| 14== nChannelNum|| 15== nChannelNum)//set StepGain/STOP VSWR/START VSWR/RETUNE TIMER
	{
		temp = (unsigned long) (dValue);

		m_pWriteBuffer[com.m_nByte] = (unsigned char)(temp & 0xff);
	}
	else if (nChannelNum == 10)//set start Frequency
	{
		temp = (unsigned long) (dValue/10);

		m_pWriteBuffer[com.m_nByte] = (unsigned char)(temp & 0xff);
		m_pWriteBuffer[com.m_nByte + 1] = (unsigned char)((temp>>8) & 0xff);
	}
	else if (nChannelNum == 12)//set cable length
	{
		//temp = 15;
		m_nLastCableLength = (unsigned long) (dValue);
	}
	else
	{
		return false;
	}
	
	m_pWriteBuffer[8] = (unsigned char)(m_nLastCableLength & 0xff);
	m_pWriteBuffer[9] = (unsigned char)((m_nLastCableLength>>8) & 0x0f);
	
	cout<<"write :: "<<Hex::GetHexString(m_pWriteBuffer, m_deviceNet->getOBytesSize(m_macID))<<endl;

	return m_deviceNet->writeByte(m_macID, m_pWriteBuffer);
}

bool HYCGeneratorDNetDriver::readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
	Com com = m_Commands[nChannelNum];

	//memset(m_pReadBuffer, 0, m_deviceNet->getIBytesSize(m_macID));
	m_deviceNet->readByte(m_macID, m_pReadBuffer);
	//cout<<"Read :: "<<Hex::GetHexString(m_pReadBuffer, m_deviceNet->getIBytesSize(m_macID))<<endl;
	unsigned int movebit = 1 << com.m_nBit;
	unsigned int temp = ((unsigned int)m_pReadBuffer[com.m_nByte]) & movebit;
	int nTempValue = temp >> com.m_nBit;
	if(nTempValue == 0 || nTempValue == 1)
	{
		*pValue = nTempValue;
		return true;
	}
	else
	{
		return false;
	}
}

bool HYCGeneratorDNetDriver::readDouble(int nChannelNum, double *dValue, const DoubleTypeInfo &typeInfo)
{
	Com com = m_Commands[nChannelNum];
	//memset(m_pReadBuffer, 0, m_deviceNet->getIBytesSize(m_macID));
	m_deviceNet->readByte(m_macID, m_pReadBuffer);

	//cout<<"Read :: "<<Hex::GetHexString(m_pReadBuffer, m_deviceNet->getIBytesSize(m_macID))<<endl;
	unsigned long temp=0;
	double dTempValue = 0;

	if(nChannelNum == 16 || nChannelNum == 17)
	{
		temp = (((unsigned long)m_pReadBuffer[com.m_nByte]) & 0xff) + ((((unsigned long)m_pReadBuffer[com.m_nByte+1]) << 8) & 0xff00);
		dTempValue = temp * typeInfo.getMax() / 4095.0;
	}
	else if(19 == nChannelNum)  //PulseDutyAI
	{
		temp = (((unsigned long)m_pReadBuffer[com.m_nByte]) & 0xff);
		dTempValue = temp;
	}
	else if(20 == nChannelNum)  //PulseFreqAI
	{
		temp = (((unsigned long)m_pReadBuffer[com.m_nByte]) & 0xff) + ((((unsigned long)m_pReadBuffer[com.m_nByte+1]) << 8) & 0xff00);
		dTempValue = temp;
	}
	else if(21 == nChannelNum || 23 == nChannelNum|| 24 == nChannelNum|| 25 == nChannelNum|| 26 == nChannelNum )  //get STEP GAIN /get STOP VSWR/get START VSWRget RETUNE TIMER/get Current VSWR
	{
		temp = (((unsigned long)m_pReadBuffer[com.m_nByte]) & 0xff);
		dTempValue = temp;
	}
	else if(18 == nChannelNum )  //get start Fre
	{
		temp = (((unsigned long)m_pReadBuffer[com.m_nByte]) & 0xff)+ ((((unsigned long)m_pReadBuffer[com.m_nByte+1])<< 8) & 0xff00);
		dTempValue = temp*10;
	}
	else if( 22 == nChannelNum )  //get Cable Length
	{
		temp = (((unsigned long)m_pReadBuffer[com.m_nByte]) & 0xff)+ ((((unsigned long)m_pReadBuffer[com.m_nByte+1])<< 8) & 0x0f00);
		dTempValue = temp;
	}

	*dValue = MathTool::Round(dTempValue,typeInfo.getAccuracy());
	return true;
	/*
	string strResult="";
	for(int i=0;i<=16;i++)
	{
		strResult+=Hex::hexToString(int(m_pReadBuffer[i]),4);
		strResult+=",";
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ":HYC-LF ReadBuffer =" + strResult); 
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() +"read :: "<<Hex::GetHexString(m_pWriteBuffer, m_deviceNet->getOBytesSize(m_macID));
	*/
}

void HYCGeneratorDNetDriver::InitChannels(DeviceNode<HYCGeneratorDNetDriver> *node)
{
	for(int i = 1; i <= 5; ++i)
	{
		node->registerWriteCh(i, &HYCGeneratorDNetDriver::writeInt);
	}
	for(int i = 6; i <= 15; ++i)
	{
		node->registerWriteCh(i, &HYCGeneratorDNetDriver::writeDouble);
	}
	for(int i = 16; i <= 26; ++i)
	{
		node->registerReadCh(i, &HYCGeneratorDNetDriver::readDouble);
	}
	for(int i = 27; i <= 33; ++i)
	{
		node->registerReadCh(i, &HYCGeneratorDNetDriver::readInt);
	}
	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &HYCGeneratorDNetDriver::getStatus);
}

void HYCGeneratorDNetDriver::initDevice()
{
	int nInBytesSize = m_deviceNet->getIBytesSize(m_macID);
	int nOutBytesSize = m_deviceNet->getOBytesSize(m_macID);

	m_pWriteBuffer = new char[nOutBytesSize];
	memset(m_pWriteBuffer, 0, nOutBytesSize);

	m_pReadBuffer = new char[nInBytesSize];
	memset(m_pReadBuffer, 0, nInBytesSize);

	//set StartFrequence
	m_nStartFrequency = m_nStartFrequency/10;
	m_pWriteBuffer[5] = (unsigned char)(m_nStartFrequency & 0xff);
	m_pWriteBuffer[6] = (unsigned char)((m_nStartFrequency>>8) & 0xff);
	m_deviceNet->writeByte(m_macID, m_pWriteBuffer);

	cout<<"scan HYCGeneratorDNetDriver Successfully...."<<endl;
}

void HYCGeneratorDNetDriver::setStartFrequency(int nStartFrequency)
{
	m_nStartFrequency = nStartFrequency;
}

void HYCGeneratorDNetDriver::init()
{
	DeviceNode<HYCGeneratorDNetDriver> *pNode = new DeviceNode<HYCGeneratorDNetDriver>(m_pollInterval, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
	if(!isSimulated())
	{
		InitChannels(pNode);
		initDeviceNet();
		initDevice();
	}
}
IMPLEMENT_DYNAMIC(HYCGeneratorDNetDriver, IODevice )
BEGIN_MSG_MAP(HYCGeneratorDNetDriver, IODevice )
    SET_V( init, HYCGeneratorDNetDriver )
	SET_I( setStartFrequency, HYCGeneratorDNetDriver)
END_MSG_MAP

