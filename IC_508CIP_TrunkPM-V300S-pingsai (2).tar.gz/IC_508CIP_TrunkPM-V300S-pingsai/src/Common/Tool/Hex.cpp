#include "Hex.h"
#include <sstream>
#include <stdio.h>
#include "Converter.h"
#include <cstdlib>
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
#endif
string Hex::GetHexString(const char * pData,int nLength)
{
    std::string strResult="";
    for(int i =0 ; i< nLength ; ++i)
    {
        strResult=strResult+"0x";
        char pHex[3] = {0};
        snprintf(pHex,3,"%02x",(unsigned char)pData[i]);
        strResult=strResult+pHex+" ";
    }
    return strResult;
}

vector<Hex::HexArray> Hex::splitBySet(char *pData,int nDataLength,const char *pSeparator,int nSeparatorNum)
{
    vector<HexArray> result;
    
    int nSepStart=0;

    for(int i = 0 ; i <nDataLength ;++i)
    {
        for(int j = 0 ; j <nSeparatorNum ;++j)
        {
            if(pData[i]==pSeparator[j])
            {
                if(i>nSepStart)
                {
                    HexArray Temp;
                    Temp.nLength=i-nSepStart;
                    Temp.pData=pData+nSepStart;
                    result.push_back(Temp);
                }
                nSepStart=i+1;
                break;
            }
        }
    }
    if(nSepStart!=nDataLength)
    {
        HexArray Temp;
        Temp.nLength=nDataLength-nSepStart;
        Temp.pData=pData+nSepStart;
        result.push_back(Temp);
    }
    return result;
}

vector<Hex::HexArray> Hex::splitByList(char* pData,int nDataLength,const char * pSeparator,int nSeparatorNum)
{
    vector<HexArray> result;
    int nSepStart=0;
    for(int i = 0 ; i < nDataLength ; ++i )
    {
        bool bFlag=false;
        for(int j = 0 ; j < nSeparatorNum ; ++j)
        {
            if(pData[i+j]!=pSeparator[j])
            {
                bFlag=false;
                break;
            }
            else
            {
                bFlag=true;
            }
        }
        if(bFlag)
        {
            if(i>nSepStart)
            {
                HexArray Temp;
                Temp.nLength=i-nSepStart;
                Temp.pData=pData+nSepStart;
                result.push_back(Temp);
            }
            nSepStart=i+nSeparatorNum;
        }
    }
    if(nSepStart!=nDataLength)
    {
        HexArray Temp;
        Temp.nLength=nDataLength-nSepStart;
        Temp.pData=pData+nSepStart;
        result.push_back(Temp);
    }
    return result;
}

bool Hex::stringToHex(int *res, const std::string &s)
{
    if(s.find(".",0) != string::npos)
    {
        return false;
    }
    istringstream iss( s );
    return !(iss>>hex>>*res).fail();    
}

void Hex::stringToHexChar(const std::string& strHexString, char* charArray, size_t nArraySize)//added by wangyk 20251225 [v1.8.1] for MotorPin DongfangMada
{
    std::stringstream ss(strHexString);
    std::string hexValue;
    size_t index = 0;

    if(!charArray)
    {
    	std::cerr << "Invalid charArray input" << std::endl;
    	return;
    }

    size_t nCharSize = sizeof(charArray) / sizeof(charArray[0]);
    if(nArraySize > nCharSize || nArraySize < 0)
    {
        std::cerr << "Invalid nArraySize value: " << nArraySize << std::endl;
        return;
    }

    while (ss >> std::hex >> hexValue && index < nArraySize)
    {
        if (hexValue.size() == 2)
        {
            charArray[index] = static_cast<char>(std::strtol(hexValue.c_str(), NULL, 16));
            ++index;
        }
        else
        {
            std::cerr << "Invalid hex value: " << hexValue << std::endl;
            break;
        }
    }

    if (index < nArraySize)
    {
        std::cerr << "Not enough hex values provided. Array size: " << Converter::convertToString(nArraySize) << ", Values provided: " << Converter::convertToString(index) << std::endl;
        throw string("Not enough hex values provided. Array size: " + Converter::convertToString(nArraySize) + ", Values provided: " + Converter::convertToString(index));
    }
}

string Hex::hexToString(int value)
{
    ostringstream t_o;
    int t_v1 = value;
    int t_v2 = 0;
    string t_res = "";
    while(t_v1 > 0)
    {
        t_v2 = t_v1 % 16;
        t_v1 = (int)(t_v1 / 16);
        t_o.str("");
        t_o <<hex << t_v2;
        t_res = t_o.str() + t_res;      
    }
    return t_res;
}

string Hex::hexToString(int value,int nlength)
{
    ostringstream t_o;
    int t_v1 = value;
    int t_v2 = 0;
    string t_res = "";
    while(t_v1 > 0)
    {
        t_v2 = t_v1 % 16;
        t_v1 = (int)(t_v1 / 16);
        t_o.str("");
        t_o <<hex << t_v2;
        t_res = t_o.str() + t_res;      
    }
    while(t_res.length() < nlength)
    {
        t_res = "0"+t_res;
    }
    return t_res;
}

std::string Hex::hexToAscii( std::string &hex)//not used
{ 
    if(((hex.size()))%2 != 0)
        return "INVALID";
    std::string result;
    try
    {
        int nTemp=0;
        for(string::size_type i =0; i<hex.size(); i=i+2)
        {
            std::string temp ;
            temp.push_back(hex.at(i));
            temp.push_back(hex.at(i+1));
            nTemp = hexToInt(temp);
            if(nTemp==-1)
            {
                return "INVALID";
            }
            result.push_back((char)(nTemp));
        }
    }
    catch(...)
    {
        return "INVALID";
    }
    return result;
}

std::string Hex::asciiToHex( std::string &str)//not used
{
    std::string result;
    std::string temp="";
    try
    {
        for(string::size_type i =0; i< str.size(); i++)
        {
            temp=intToHex((int)(str.at(i)));
            if(temp == "INVALID")
            {
                return "INVALID";
            }
            result += intToHex((int)(str.at(i)));
        }
    }
    catch(...)
    {
        return "INVALID";
    }
    return result;
}
//INVALID : failed to exchange
std::string Hex::intToHex(int i)
{
    int temp1;
    int temp2;
    std::vector<int> a;
    std::string result;
    temp1 = i/16;
    temp2 = i%16;
    a.push_back(temp2);
    if(temp1 <16)
    {
        a.push_back(temp1);
    }
    while(temp1 >=16)
    {
        temp2= temp1%16;
        temp1 = temp1/16;
        a.push_back(temp2);
        if(temp1<16)
            a.push_back(temp1);
    }
    if(a.size() == 1)
    {
        result.push_back('0');
        result.push_back(a.at(0));
        return result;
    }
    for(int k=a.size()-1; k>=0; k--)
    {
        if(a.at(k)<= 9)
            result= result + Converter::convertToString(a.at(k));
        else
        {
            char ch;
            switch(a.at(k))
            {
                case 10 :
                    ch = 'A';
                    break;
                case 11 :
                    ch = 'B';
                    break;
                case 12 :
                    ch = 'C';
                    break;
                case 13 :
                    ch = 'D';
                    break;
                case 14 :
                    ch = 'E';
                    break;
                case 15 :
                    ch = 'F';
                    break;
                default:    
                    return "INVALID";
            }
            result.push_back(ch);
        }       
    }
    return result;
    
}
//-1 : failed to exchange
int Hex::hexToInt( std::string &hex)
{
    if(hex.empty())
        return 0;
    char ch;
    int result =0;
    int flag=0;
    for(int i=hex.size()-1; i>=0; i-- ,flag++ )
    {
        int temp;
        ch = hex.at(i);
        if(ch >= '0' && ch <= '9')
            temp = ch - '0';
        else if(ch <= 'F' && ch >= 'A')
        {
            temp = 10 + ch - 'A';
        }
        else
            return -1;
        int m=1;
        for(int j=0; j<flag; j++)
        {
            m= m*16;
        }
        result = result + temp*m;
    }   
    return result;
}

string Hex::hexToStringFixWidth(unsigned char value)
{
    char str[3];//[zhangcx v1.5.0 sonar]
    sprintf(str, "%02X", value);
    return str;
}

