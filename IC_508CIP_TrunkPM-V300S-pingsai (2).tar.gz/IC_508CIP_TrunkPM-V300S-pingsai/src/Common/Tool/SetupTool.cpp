/********************************************************************
** Copyright (c) 2019, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: SetupTool.cpp
** Description:
** Created on: Jan 9, 2019
** Author: mujy
** Modification history:
**						[V1.0.0.2] create
**
*********************************************************************/

#include "SetupTool.h"
#include "SysLogger.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "AbortException.h"
#endif
#include "SetupRepository.h"
#include "Setup.h"
#include "IntTypeInfo.h"
#include "DoubleTypeInfo.h"
#include "StringTypeInfo.h"
#include "IntValueInfo.h"
#include "Converter.h"
#include <iostream>
#include <dirent.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <iomanip>
#include "MapTool.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
using namespace IAP::SETUP;
using namespace IAP::IO;
#endif

SetupTool* SetupTool::m_pInstance=NULL;
SetupTool::SetupTool() {
	m_pInstance = this;
	// TODO Auto-generated constructor stub
	m_PrintAll = new PrintAll();
	m_PrintAll->setOwner(this);

	m_SavePreservedValue = new SavePreservedValue();
	m_SavePreservedValue->setOwner(this);
}

SetupTool::~SetupTool() {
	// TODO Auto-generated destructor stub
}

SetupTool* SetupTool::getInstance()
{
	if(m_pInstance == NULL)
	{
		m_pInstance= new SetupTool();
	}
	return m_pInstance;
}

void SetupTool::make()
{
	vector<string> setupNameVector = SetupRepository::getInstance()->getAllSetupNames();

	for(unsigned int i=0; i<setupNameVector.size(); ++i)
	{
		if(setupNameVector[i].find("PreservedValue") != string::npos || setupNameVector[i].find("Counters") != string::npos)
		{
			continue;
		}
		Setup * pSetup = SetupRepository::getInstance()->getSetup(setupNameVector[i]);
		vector<const Parameter*> params = pSetup->getAllParameters();
		for (unsigned int j = 0; j < params.size(); j++)
		{
			//cout<<"SetupTool addtoMap "<<params[j]->getDataObjName()<<" "<<params[j]->getName()<<endl;
			MapTool::addToMap(mapSetupParam,params[j]->getDataObjName(),params[j]->getName());
		}
	}
}

void SetupTool::PrintAll::execute()
{
	ControlObject *owner = getOwner();
	if (owner != NULL)
	{
		try
		{
			static_cast<SetupTool*>(owner)->do_PrintAll();
		}
		catch(const AbortException &ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": Start service was aborted for:" + string(ex.what()));
			throw;
		}
		catch(const exception &ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": Start service has error for:" + string(ex.what()));
			throw;
		}
	}
}

void SetupTool::SavePreservedValue::execute()
{
	ControlObject *owner = getOwner();
	if (owner != NULL)
	{
		try
		{
			static_cast<SetupTool*>(owner)->do_SavePreservedValue();
		}
		catch(const AbortException &ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": SavePreservedValue service was aborted for:" + string(ex.what()));
			throw;
		}
		catch(const exception &ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": SavePreservedValue service has error for:" + string(ex.what()));
			throw;
		}
	}
}

void SetupTool::call_PrintAll()
{
	call(m_PrintAll);
}

void SetupTool::call_SavePreservedValue()
{
	call(m_SavePreservedValue);
}

void SetupTool::do_PrintAll()
{
	cout<<"-------------------------------------------------"<<endl;
	cout<<"Start to print setup information..."<<endl;

	char current_absolute_path[300];
	if(NULL == getcwd(current_absolute_path,300))
	{
		cout<<"Cannot get current absolute path!"<<endl;
		return;
	}

	string strPath = string(current_absolute_path)+"/Information/";

	cout<<"Print setup info to path ["<<strPath<<"]"<<endl;

	if (access(strPath.c_str(), F_OK) != 0)
	{
		if(mkdir(strPath.c_str(),S_IRWXU|S_IRWXG|S_IRWXO) != 0)
		{
			cout<<"Cannot creat specified syslog directory "<<strPath<<endl;
			throw string("Cannot creat specified syslog directory "+strPath);
		}
	}
	else
	{
		if (access(strPath.c_str(), R_OK|W_OK) != 0) // cannot obtain 'rw' permission of dir
		{
			cout<<"Cannot access specified directory "<<strPath<<endl;
			throw string("Cannot access specified directory "+strPath);
		}
	}

	vector<string> setupNameVector = SetupRepository::getInstance()->getAllSetupNames();
	SysLogger::getInstance()->logMsg(LOGBRANCH::ALARM, LEVEL::EVENT, "getAllSetup");
	ofstream in;
	string strFileName = strPath + "Setup.txt";
	in.open(strFileName.c_str(),ios::trunc);
	in <<setiosflags(ios::left)<<setw(40)<<"Parameter";
	in <<setiosflags(ios::left)<<setw(18)<<"CurrentValue";
	in <<setiosflags(ios::left)<<setw(25)<<"Range";
	in <<setiosflags(ios::left)<<setw(15)<<"Unit";
	in <<setiosflags(ios::left)<<setw(18)<<"DefaultValue"<<endl;
	for(unsigned int i=0; i<setupNameVector.size(); ++i)
	{
		if(setupNameVector[i].find("PreservedValue") != string::npos || setupNameVector[i].find("Counters") != string::npos)
		{
			continue;
		}
		in <<"			=>" << setupNameVector[i]<<"<="<<endl;
		Setup * pSetup = SetupRepository::getInstance()->getSetup(setupNameVector[i]);
		vector<string> paramNames = pSetup->getAllParamNames();

		vector<const Parameter*> params = pSetup->getAllParameters();
		for (unsigned int j = 0; j < params.size(); j++)
		{
			in <<setiosflags(ios::left)<<setw(40)<< params[j]->getName();
			string strActual = " "+pSetup->getValueAsString(1,params[j]->getName());
			in <<setiosflags(ios::left)<<setw(18)<<strActual;
			in <<setiosflags(ios::left)<<setw(25)<<getRangeInfo(params[j]);
			in <<setiosflags(ios::left)<<setw(15)<<getUnitInfo(params[j]);
			in <<setiosflags(ios::left)<<setw(18)<<getDefaultValueInfo(params[j])<<endl;
		}
		in<<endl;
	}
	in.close();
	cout<<"Print setup information end."<<endl;
	cout<<"-------------------------------------------------"<<endl;
}

string SetupTool::getRangeInfo(const Parameter* pParam)
{
	string strInfo = "";
	switch (pParam->getType())
	{
		case IO::INTDATA: // 'INT' Parameter
		{
			IntTypeInfo *intTypeInfo = (IntTypeInfo*)pParam->getTypeInfo();

			strInfo+=Converter::convertToString(intTypeInfo->getMin())+"~";
			strInfo+=Converter::convertToString(intTypeInfo->getMax());
			if(intTypeInfo->getDescriptorList().getListAsString() != "")
			{
				strInfo+="["+intTypeInfo->getDescriptorList().getListAsString()+"]";
			}
		}
		break;

		case IO::STRINGDATA: // 'STRING' Parameter
		{
			//StringTypeInfo *strTypeInfo = (StringTypeInfo*)pParam->getTypeInfo();
			//strInfo+=" maxLength="+Converter::convertToString(strTypeInfo->getMaxLength());
		}
		break;

		case IO::DOUBLEDATA: // 'DOUBLE' Parameter
		{
			DoubleTypeInfo *dTypeInfo = (DoubleTypeInfo*)pParam->getTypeInfo();
			strInfo+=Converter::convertToString(dTypeInfo->getMin())+"~";
			strInfo+=Converter::convertToString(dTypeInfo->getMax());
			//strInfo+=" accuracy="+Converter::convertToString(dTypeInfo->getAccuracy());
		}
		break;
	}
	return strInfo;
}

string SetupTool::getUnitInfo(const Parameter* pParam)
{
	string strInfo = "";
	switch (pParam->getType())
	{
		case IO::INTDATA: // 'INT' Parameter
		{
			IntTypeInfo *intTypeInfo = (IntTypeInfo*)pParam->getTypeInfo();
			strInfo+=intTypeInfo->getUnit();
		}
		break;

		case IO::STRINGDATA: // 'STRING' Parameter
		{
			//StringTypeInfo *strTypeInfo = (StringTypeInfo*)pParam->getTypeInfo();
			//strInfo+=" maxLength="+Converter::convertToString(strTypeInfo->getMaxLength());
		}
		break;

		case IO::DOUBLEDATA: // 'DOUBLE' Parameter
		{
			DoubleTypeInfo *dTypeInfo = (DoubleTypeInfo*)pParam->getTypeInfo();
			strInfo+=dTypeInfo->getUnit();
			//strInfo+=" accuracy="+Converter::convertToString(dTypeInfo->getAccuracy());
		}
		break;
	}
	return strInfo;
}

string SetupTool::getDefaultValueInfo(const Parameter* pParam)
{
	string strInfo = "";
	if (pParam->getType() == IO::INTDATA)
	{
		try // maybe no descriptor
		{
			strInfo+=((IntValueInfo*)pParam->getDefaultValue())->getValueAsDescriptor();
		}
		catch (const exception&)
		{
			strInfo+=pParam->getDefaultValue()->getValueAsString();
		}
	}
	else
	{
		strInfo+=pParam->getDefaultValue()->getValueAsString();
	}
	return strInfo;
}

void SetupTool::do_SavePreservedValue()
{
	Setup * m_pXMLFile = SetupRepository::getInstance()->getSetup("PreservedValue");
	if(m_pXMLFile == NULL)
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": in do_SavePreservedValue() failed.File Name [ PreservedValue ] is not exist.");
		return;
	}

	if(!m_pXMLFile->doLoad())
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": in do_SavePreservedValue() failed to call doLoad()" );
	}

	if(!m_pXMLFile->doSave())
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": in do_SavePreservedValue() failed to call doSave()" );
	}

	if(!m_pXMLFile->commitChange())
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": in do_SavePreservedValue() failed to call commitChange");
	}
}

string SetupTool::getNameOfParameter(string strDataObjName)
{
	if(mapSetupParam.find(strDataObjName) != mapSetupParam.end())
	{
		return mapSetupParam[strDataObjName];
	}
	else
	{
		return strDataObjName;
	}
}
IMPLEMENT_DYNAMIC_SERVICE(PrintAll, SetupTool)
IMPLEMENT_DYNAMIC_SERVICE(SavePreservedValue, SetupTool)

BEGIN_SERVICEINFO_LIST(SetupTool)
	ADD_SERVICE_INFO(SetupTool, PrintAll, Print All setup value)
	ADD_SERVICE_INFO(SetupTool, SavePreservedValue, Save setup Preserved value to file)
END_SERVICEINFO_LIST(SetupTool)

IMPLEMENT_DYNAMIC(SetupTool, ControlObject)

BEGIN_MSG_MAP( SetupTool, ControlObject)

END_MSG_MAP
