#include "Station.h"
#include "CTCExport.h"
#include "Converter.h"
#include "SlotMapInfo.h"
#ifdef IAP4_0
using namespace IAP::CORE;
#endif
//#include "ServiceResultEnum.h"

Station::Station()
{
	m_pCapacity=new ReadWriteInt();
	m_pCapacity->setValue(0);
	
	m_PrepWfr=new PrepWfr();
	m_PrepWfr->setOwner(this);
	
	m_CompWfr=new CompWfr();
	m_CompWfr->setOwner(this);
}

Station::Station(const Station& pObj)
{
	m_pCapacity = new ReadWriteInt();
	m_pCapacity->setValue(0);

	m_PrepWfr = new PrepWfr();
	m_PrepWfr->setOwner(this);

	m_CompWfr = new CompWfr();
	m_CompWfr->setOwner(this);
}

Station& Station::operator=(const Station& pObj)
{
	if (this != &pObj)
	{
		m_pCapacity = new ReadWriteInt();
		m_pCapacity->setValue(0);

		m_PrepWfr = new PrepWfr();
		m_PrepWfr->setOwner(this);

		m_CompWfr = new CompWfr();
		m_CompWfr->setOwner(this);
	}
	return *this;
}

Station::~Station()
{
}

int Station::getWfrState(int nLocationIndex)
{
	if(checkLocationIndex(nLocationIndex))
	{
		return m_ppSlotState[nLocationIndex]->getValue();
	}
	else
	{
		//postAlarm("SlotOutOfRange",Converter::convertToString(nLocationIndex));
		return 0;//can't reach here
	}
}

void Station::setWfrState(int nLocationIndex,int nState)
{
	Log_Info(getSelfName()+" setWfrState start, locaton = "+Converter::convertToString(nLocationIndex)+" state="+Converter::convertToString(nState));
	if(checkLocationIndex(nLocationIndex))
	{
		m_ppSlotState[nLocationIndex]->setValue(nState);
		Log_Info(getSelfName()+" setWfrState end, state = " + m_ppSlotState[nLocationIndex]->getValueAsDescriptor());
	}
	else
	{
		//postAlarm("SlotOutOfRange",Converter::convertToString(nLocationIndex));
	}
}

void Station::setCapacity(int nCapacity)
{
	//log(LEVEL::VERBOSE, "%s :set nCapacity=%d start",getName().c_str(),nCapacity);
	if(nCapacity<1)
	{
		//log(LEVEL::FATAL, getName()+": setCapacity()- error capacity number!");
		throw "error capacity number!";
	}
	m_pCapacity->setValue(nCapacity);
	
	CTCExport::exportToCTC(m_pCapacity,getSelfName()+"_Capacity");
	m_ppSlotState = new ReadWriteInt*[nCapacity+1];
	m_ppSlotState[0] = NULL;
	for(int i = 1 ; i <nCapacity+1 ; ++i )
	{
		m_ppSlotState[i]=new ReadWriteInt(SlotMapInfo::typeInfo);
		ObjectManager::getInstance()->registerObject(m_ppSlotState[i], getName() + "/S"+Converter::convertToString(i)+"/Wfr");///PM/S1/Wfr
		CTCExport::exportToCTC(m_ppSlotState[i],getSelfName()+"_S"+Converter::convertToString(i)+"Wfr");
		m_ppSlotState[i]->setValue(SlotMapInfo::Unknown);//added by mujy [V1.0.0.3]
	}
}

int Station::getCapacity()
{
	return m_pCapacity->getValue();
}

void Station::call_PrepWfr(int nSlot, int nTransferOperation, int nHandOffMode,int nWaferID,string strLotID, string strWfrName)
{
	m_PrepWfr->setParamValue("slot",nSlot);
	m_PrepWfr->setParamValue("wfrOpr",nTransferOperation);
	m_PrepWfr->setParamValue("handoffmode",nHandOffMode);
	m_PrepWfr->setParamValue("waferID",nWaferID);
	m_PrepWfr->setParamValue("lotID",strLotID);
	m_PrepWfr->setParamValue("wfrName",strWfrName);
	call(m_PrepWfr);
}

void Station::do_PrepWfr(int nSlot, int nTransferOperation,int nHandOffMode,int nWaferID,string strLotID, string strWfrName)
{
	
}

void Station::call_CompWfr()
{
	call(m_CompWfr);
}

int Station::do_CompWfr()
{
	return 1;
}

void Station::verifyInit()
{
	FunctionalModel::verifyInit();
	if(m_pCapacity->getValue()<1)
	{
		throw "not set capacity!";
	}
}

void Station::initialize()
{
	FunctionalModel::initialize();
	//addAlarm("SlotOutOfRange");
}

void Station::make()
{
	FunctionalModel::make();
}

bool Station::checkLocationIndex(int nLocationIndex)
{
	if(nLocationIndex<1 || nLocationIndex>getCapacity())
	{
		return false;
	}
	else
	{
		return true;
	}
}

void Station::PrepWfr::execute()
{
	Station *pOwner = dynamic_cast<Station*>(getOwner());
	if(pOwner!=NULL)
	{
		int nSlot = Params["slot"].Int;
		int nTransferOperation = Params["wfrOpr"].Int;
		int nHandOffMode = Params["handoffmode"].Int;
		int nWaferID = Params["waferID"].Int;
		string strLotID = Params["lotID"].Str;
		string strWfrName = Params["wfrName"].Str;
		pOwner->do_PrepWfr(nSlot,nTransferOperation,nHandOffMode,nWaferID,strLotID,strWfrName);
	}
	
}

void Station::CompWfr::execute()
{
	Station *pOwner = dynamic_cast<Station*>(getOwner());
	if(pOwner != NULL)
	{
		#ifdef IAP4_0
		Result.Int =pOwner->do_CompWfr();
		#else
		Results["success"].Int =pOwner->do_CompWfr();
		#endif
	}
}

IMPLEMENT_DYNAMIC_SERVICE(PrepWfr, Station)
IMPLEMENT_DYNAMIC_SERVICE(CompWfr, Station)

BEGIN_SERVICEINFO_LIST(Station)
	ADD_SERVICE_INFO(Station, PrepWfr, The PrepWfr service )
		ADD_PARAM_INFO(Station, PrepWfr, slot, int, )
		ADD_PARAM_INFO(Station, PrepWfr, wfrOpr, int, Receive:0 Send:1 Swap:2 Xfer:2)
		ADD_PARAM_INFO(Station, PrepWfr, handoffmode, int, UnInit:-1 Unknown:0 Passive:1 Active:2)
		ADD_PARAM_INFO(Station, PrepWfr, waferID, int, )
		ADD_PARAM_INFO(Station, PrepWfr, lotID, string, )
		ADD_PARAM_INFO(Station, PrepWfr, wfrName, string, )
	ADD_SERVICE_INFO(Station, CompWfr, The CompWfr service )
END_SERVICEINFO_LIST(Station)

IMPLEMENT_DYNAMIC(Station, FunctionalModel)

BEGIN_MSG_MAP( Station, FunctionalModel )
    SET_I( setCapacity, Station )
END_MSG_MAP
