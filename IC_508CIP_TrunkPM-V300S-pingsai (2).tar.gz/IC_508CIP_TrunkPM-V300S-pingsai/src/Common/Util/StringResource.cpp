/********************************************************************
** Copyright (c) 2016, Beijing NMC Co.,Ltd. All rights reserved.
** All rights reserved.
**
** File name: StringResource.cpp
**
** Description:
**
** Modification history:
*                           2016.10.31      lvjw    created.
*********************************************************************/


#include "StringResource.h"
#include "StrManager.h"
#include "Converter.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

StringResource::StringResource()
{
}

StringResource::~StringResource()
{
}

bool StringResource::AddString(int nID,const string &strData)
{
    if(StrManager::getInstance()->AddString(nID,strData))
    {
        return true;
    }
    else
    {
        throw "Add string ERR:"+Converter::convertToString(nID)+" has already exist.";
        //return false;
    }
}

IMPLEMENT_DYNAMIC(StringResource,CmdTarget )

BEGIN_MSG_MAP(StringResource,CmdTarget )
    SET_IS(AddString, StringResource)
END_MSG_MAP
