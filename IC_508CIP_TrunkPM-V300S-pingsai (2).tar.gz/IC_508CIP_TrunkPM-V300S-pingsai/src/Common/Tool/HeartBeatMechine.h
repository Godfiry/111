/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description:
** Release:
** Modification history:
** 					lv Jiawen created.2020-09-23
**  				zhangyy modified.2025-11-10
***************************************************************************/

#ifndef HEARTBEATMECHINE_H_
#define HEARTBEATMECHINE_H_

//#include "Timer.h"
//#include "TimerSubscriber.h"
#include "CmdTarget.h"
#include "IThread.h"
#include "ReadWriteInt.h"
#include "ReadWriteDouble.h"
#include "AppCondition.h"
#include "NonBlockingAlarm.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
using namespace IAP::CONDITION;
using namespace IAP::ALARM;
#endif
using namespace std;

class HeartBeatMechine: public CmdTarget,public IThread
{
	DECLARE_DYNAMIC( HeartBeatMechine )
	DECLARE_MSG_MAP

public:
	HeartBeatMechine();
	virtual ~HeartBeatMechine();

public://xml config
	void setBeatInterval(int nMS);
	void setBeatChannel(string strPath);

public://voerride
	virtual void make();
	virtual void startup();
	virtual void run();//zhangyy modify[1.8.0]
	/**
	#ifdef IAP4_0
	virtual void updateFromTimer(const Timer * const timer);
	#else
	virtual void updateFromTimer();
	#endif
	**/

private:
	bool checkProcessOverEtch();//added by zhangyy [1.6.0]
	double m_nBeatInterval;//ms
	/**
	#ifdef IAP4_0
	IAP::CORE::TimerPtr m_pMyTimer;
	#else
	Timer *m_pMyTimer;
	#endif
	**/
	int m_nBeatLeave;//0  or 1
	bool m_bKeepRun;//zhangyy modify[1.8.0]

	ReadWriteInt * m_pBeatChannel;
	ReadWriteInt *m_pProcessTheRecipeFlag;
	ReadWriteDouble *m_pMaxProcessTime;
	//NonBlockingAlarm *m_pProcessOnTimeOutAlarm;
	AppConditionPtr m_ProcessOnCondition;
	long m_longProcessOnBeginTime;
	Alarm *m_pProcessOnTimeOutAlarm;
};

#endif /* HEARTBEATMECHINE_H_ */
