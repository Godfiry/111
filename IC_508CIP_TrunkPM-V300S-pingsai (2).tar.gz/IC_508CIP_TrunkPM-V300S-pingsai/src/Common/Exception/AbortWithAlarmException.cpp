/*************************************************************************************
** Copyright (c) 2007, Beijing NMC Co.Ltd.  All rights reserved.
** File name: 	AbortWithAlarmException.cpp
** Description: 
** Release: 		1.0
** Modification history:
** 					2008-3-27   WangYonggui create
**
*************************************************************************************/

#include "AbortWithAlarmException.h"

AbortWithAlarmException::AbortWithAlarmException() : AbortException("AbortWithAlarmException")
{
	m_alarm = NULL;
}

AbortWithAlarmException::AbortWithAlarmException(const std::string &s) : AbortException(s)
{
    m_alarm = NULL;
}

AbortWithAlarmException::AbortWithAlarmException(const std::string &s, BlockingAlarm *alarm) : AbortException(s)
{
	m_alarm = alarm;
}

/*AbortWithAlarmException::~AbortWithAlarmException()
{
}*/

void AbortWithAlarmException::setAlarm(BlockingAlarm *alarm)
{
	m_alarm = alarm;
}

BlockingAlarm* AbortWithAlarmException::getAlarm() const
{
	return m_alarm;
}
