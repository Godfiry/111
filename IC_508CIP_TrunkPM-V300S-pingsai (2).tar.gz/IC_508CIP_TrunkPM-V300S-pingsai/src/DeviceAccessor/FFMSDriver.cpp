/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: FFMSDriver.cpp
** Description:  
** Release: 1.1
** Modification history: 
**                          2022-04-19   create
**      
*********************************************************************/
#include "FFMSDriver.h"
#include "DeviceManager.h"

#include "Converter.h"
#include "Util.h"
#include <cctype>
#include "SysLogger.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std; 

/************************************
Action command || operation message || @**CR
Parameter set command || setup message || @**[setting value]CR
Status demand Command || Report message || @**?CR

*************************************/
                                                            //     [unit]     [data type]
FFMSDriver::Cmd FFMSDriver::m_cmd[] = {{"",0,""},
                         {"@00",0,"=00"},//1 measurement
                         {"@03",0,"=03"},//2 purge
                         {"@05",0,"=05"},//3 discontnue
                         {"@07",0,"=07"},//4 connection leak check
                         {"",0,""},
                         {"@10",1,"?10"},//6 ultimate pressure               Torr     float
                         {"@11",1,"?11"},//7 timeout setting               sec     int
                         {"@12",1,"?12"},//8 known vol setting               ml     float
                         {"@13",1,"?13"},//9 ext vol setting               ml     float
                         {"@14",1,"?14"},//10 min pressure               Torr     float
                         {"@16",1,"?16"},//11 stray vol setting               ml     float
                         {"@17",1,"?17"},//12 purge number setting          times     int
                         {"@18",1,"?18"},//13 flow quantity stability waiting time sec     int
                         {"@41",1,"?41"},//14 flow quantity stability monitoring   Torr     float
                         {"",0,""},
                         {"@21?",1,"@21"},//16 flow                         float
                         {"@23?",1,"@23"},//17 ext vol                    float
                         {"@29?",1,"@29"},//18 leak                         float
                         {"",0,""},
                         {"",0,""},
                         {"@20?",1,"@20"},//21status                         
};

FFMSDriver::FFMSDriver():SerialDevice(200, "\x0D")//\0D cr  \0A lf
{
     m_timeOut = 200;//20s
     m_pollPeriod = 1000; //1s          
}

FFMSDriver::~FFMSDriver()
{
}

/*
std::string FFMSDriver::calculateLRC(const std::string &buffer)
{
     int t_sum = 0;
     int t_v = 0;
     int i = 1; 
     while(i < buffer.length()-1)
     {
          Util::stringToHex(&t_v, buffer.substr(i, 2));
          t_sum += t_v;
          t_v = 0;
          i += 2;
     }
     t_sum = - t_sum;
     t_sum = t_sum & 0xFF;

     return Util::hexToString(t_sum, 2);
}*/

bool FFMSDriver::writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
     string t_cmd = m_cmd[channelNum].m_command;
     if(m_cmd[channelNum].type==1) t_cmd = t_cmd + Converter::convertToString(value);
     /*switch(t_str.length())
     {
          case 1:
               t_str = "000"+t_str;
               break;
          case 2:
               t_str = "00"+t_str;
               break;
          case 3:
               t_str = "0"+t_str;
               break;
          default:
               break;
     }*/
     //sendCommandOnly(t_cmd);
     //string t_resp = getResultOnly(m_timeOut);
     string t_resp = getCommandResult(t_cmd, m_timeOut);
     if(t_resp.find(m_cmd[channelNum].m_error)!=string::npos)
     {
          throw IOException("getResult invalid");
     }
     if(t_resp.find(m_cmd[channelNum].m_command)==string::npos)
     {
          throw IOException("getResult error");
     }
     return true;
}
          
bool FFMSDriver::readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
     Cmd t_cmd = m_cmd[channelNum];
     string t_command = t_cmd.m_command;
     string t_res = getCommandResult(t_command, m_timeOut);
     int t_pos = t_res.find(t_cmd.m_error, 0);
     if(t_pos == string::npos)
     {
          throw IOException("unknow read_back:" + t_res);
     }
     else if(m_cmd[channelNum].type==1)
     {
          string resp = t_cmd.m_error;
          if((t_pos = t_res.find(resp, 0))!=string::npos){
               string t_sv = t_res.substr(t_pos+resp.size());
               double t_iv = 0;
               if(!Converter::stringToDouble(t_iv, t_sv))
               {
                    throw IOException("invalid read_back double value:" + t_sv);
               }
               else
               {
                    switch(channelNum)
                    {
                         case 3:
                              *value = t_iv;
                              break;
                         case 4:
                              *value = t_iv;
                              break;
                         case 5:
                              *value = t_iv;
                              break;
                         case 11:
                              *value = t_iv;
                              break;
                         case 13:
                              *value = t_iv;
                              break;
                         case 16:
                              *value = t_iv;
                              if(*value>typeInfo.getMax())
                              {
                                   *value=typeInfo.getMax();
                              }
                              if(*value<typeInfo.getMin())
                              {
                                   *value=typeInfo.getMin();
                              }
                              break;
                         case 17:
                              *value = t_iv;
                              break;
                         default:
                              break;
                    }
                    return true;
               }
          }
          else{
               throw IOException("unknow read_back:" + t_res);
          }
     }
}
          
bool FFMSDriver::readInt(int channelNum, int *value, const IntTypeInfo &typeInfo)
{
     Cmd t_cmd = m_cmd[21];
     string t_command = t_cmd.m_command;
     string t_res = getCommandResult(t_command, m_timeOut);
     int t_pos = t_res.find(t_cmd.m_error, 0);
     if(t_pos == string::npos)
     {
          throw IOException("getResult error" + t_res);
     }
     else
     {
          string resp = t_cmd.m_error;
          if((t_pos = t_res.find(resp, 0))!=string::npos){
               string t_sv = t_res.substr(t_pos+resp.size());
               int t_iv = 0;
               //cout<<"t_sv is:"<<t_sv<<endl;
               /*if(!Util::stringToHex(&t_iv, t_sv))
               {
                    throw IOException("invalid read_back double value:" + t_sv);
               }
               else
               {*/
                    //*value = (t_iv & t_cmd.m_p1) != 0;
                    if(channelNum==21)
                    {
                         t_iv = t_sv[0];
                         //cout<<"chn num is:"<<channelNum<<", t_iv is:"<<t_iv<<endl;
                         *value = (t_iv&0x07);
                         //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "FFMSDriver  Fault t_command: "+t_command);
                         //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "FFMSDriver  Fault t_res: "+t_res);
                    }
                    if(channelNum==22)
                    {
                         t_iv = t_sv[1];
                         //cout<<"chn num is:"<<channelNum<<", t_iv is:"<<t_iv<<endl;
                         //int temp = ((t_iv&0x70)>>4);
                         *value = ((t_iv&0x07));
                         //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "FFMSDriver  Warning t_command: "+t_command);
                         //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "FFMSDriver  Warning t_res: "+t_res);
                    }
                    return true;
               //}
          }
          else{
               throw IOException("unknow read_back:" + t_res);
          }
     }     
}
          
bool FFMSDriver::writeInt(int channelNum, int value, const IntTypeInfo &typeInfo)
{
     string t_cmd = m_cmd[channelNum].m_command;
     if(m_cmd[channelNum].type==1) t_cmd = t_cmd + Converter::convertToString(value);
     
     string t_resp = getCommandResult(t_cmd, m_timeOut);

     if(t_resp.find(m_cmd[channelNum].m_error)!=string::npos)
     {
          throw IOException("getResult invalid");
     }
     if(t_resp.find(m_cmd[channelNum].m_command)==string::npos)
     {
          throw IOException("getResult error");
     }
     return true;
}

void FFMSDriver::initChs(DeviceNode<FFMSDriver> *node)
{
    	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &SerialDevice::getStatus);
     
     for(int i = 1; i<=5; ++i)
     {
          node->registerWriteCh(i, &FFMSDriver::writeInt);
     }
     for(int i = 6; i<=15; ++i)
     {
          node->registerWriteCh(i, &FFMSDriver::writeDouble);
     }
     for(int i = 16; i<=20; ++i)
     {
          node->registerReadCh(i, &FFMSDriver::readDouble);
     }
     for(int i = 21; i<=25; ++i)
     {
          node->registerReadCh(i, &FFMSDriver::readInt);
     }
}

void FFMSDriver::initDevice()
{
     
}

void FFMSDriver::init()
{
     cout<<getName()+"FFMSDriver init start"<<endl;
     SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "FFMSDriver start");
     DeviceNode<FFMSDriver> *node = new DeviceNode<FFMSDriver>(m_pollPeriod, this);
     DeviceManager::getInstance()->registerNode(m_nodeNum, node);
     if(!isSimulated())
     {
          initChs(node);     
          initDevice();
     }
     cout<<getName()+"FFMSDriver  end start"<<endl;
     SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "FFMSDriver end");
}

IMPLEMENT_DYNAMIC(FFMSDriver, SerialDevice )

BEGIN_MSG_MAP(FFMSDriver, SerialDevice )
     SET_V( init, FFMSDriver )
END_MSG_MAP
