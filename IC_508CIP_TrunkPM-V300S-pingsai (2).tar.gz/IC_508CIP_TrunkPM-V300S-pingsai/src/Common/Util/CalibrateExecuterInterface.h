/********************************************************************
** Copyright (c) 2020, Beijing NAURA Co.,Ltd.  All rights reserved.
** File name: CalibrateExecuterInterface.h
** Description: 
** Release: 1.1
** Modification history: 
** 					2020-2-19   chenmz create
*********************************************************************/
#ifndef CALIBRATEEXECUTERINTERFACE_H_
#define CALIBRATEEXECUTERINTERFACE_H_
#include <iostream>
using namespace std;

class CalibrateExecuterInterface
{
	public:
		CalibrateExecuterInterface(){}
		virtual ~CalibrateExecuterInterface(){}
		
		virtual double Calibrate(const double dValue) = 0;
};


#endif /*CALIBRATEEXECUTERINTERFACE_H_*/
