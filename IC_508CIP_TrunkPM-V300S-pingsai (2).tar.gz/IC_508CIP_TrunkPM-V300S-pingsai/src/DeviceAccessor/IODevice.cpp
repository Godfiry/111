/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: IODevice.cpp
** Description:  
** Release: 1.1
** Modification history: 
**                     2007-9-22   LiJuanjuan create
**      
*********************************************************************/
#include "IODevice.h"
#include "XmlGetter.h"
#include "DeviceManager.h"
#include "ConfigException.h"
#include <cmath>
#include <iostream>
#include <string.h>

#ifdef SS5136DN
#include "DNSS5136.h"
#warning DNSS5136
#else
#ifdef CIFXDN
#include "CIFXDEVNET.h"
#include "CIFXDEVNETAutoScan.h"
#warning CIFXDEVNET
#else
#ifdef ZYDN
#include "ZYDEVNET.h"
#warning ZYDEVNET
#else
#include "SSTDN3PCU1.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif
#warning SSTDN3PCU1
#endif
#endif
#endif
using namespace std;

DeviceNet* IODevice::m_deviceNet = NULL;// new DeviceNet("/dev/ss5136dn0", 0, 125);

IODevice::IODevice()
{
    m_buffer = NULL;
    m_macID = -1;
    m_nodeNum = -1;
    m_DIChsSize = 0;
    m_DOChsSize = 0;
    m_pollInterval = 100; //0.1s
    m_baudRate = 125;
    m_fwdir = "";
    m_AIChsSize = 0;
    m_AOChsSize = 0;
    m_dFullScale = 32768;
    m_pollStatusInterval = 10;
    m_currentCycle = 1;
    m_connectStatus = COMMUNICATION_STATUS::CONNECT;
    m_dmTorrRatio = 0.1; //added by taohao[1.1.30]
}

IODevice::~IODevice()
{
    if(!isSimulated())
    {
        delete m_deviceNet;
        m_deviceNet = NULL;
        delete m_buffer;
        m_buffer = NULL;
    }
}

void IODevice::setMacID(int macId)
{
    if(macId < 0 || macId > 63)
    {
        throw ConfigException("IODevice: illegal MacID");
    }
    m_macID = macId;
}

void IODevice::setNodeNum(int nodeNum)
{
    if(nodeNum < 0)
    {
        throw ConfigException("IODevice: illegal NodeNum");
    }
    m_nodeNum = nodeNum;
}

void IODevice::setDeviceName(const std::string &name)
{
    m_deviceName = name;
}

void IODevice::setValuePerUnit(double mTorrRatio) //added by taohao [1.1.30]
{
    m_dmTorrRatio = mTorrRatio;
}

bool IODevice::readBit(int channelNum, int *bit, const IntTypeInfo &typeInfo)
{
    bool inbit;
    int t_bitPos= channelNum - 100 + m_AIChsSize*16;
    bool flag = m_deviceNet->readBit(m_macID, t_bitPos, &inbit);
    if(!flag)
    {
        return false;
    }
    else
    {
        *bit = inbit;
        return true;
    }
}

bool IODevice::writeBit(int channelNum, int bit, const IntTypeInfo &typeInfo)
{
    if(bit < 0 || bit > 1)
    {
        return false;
    }
    int t_bitPos = channelNum + m_AOChsSize*16;
    int byteno = t_bitPos / 8;
    int bitno = t_bitPos % 8;
    unsigned char bitmask = 1;
    bitmask = bitmask << bitno;
    if(bit == 1)
    {
        m_buffer[byteno] = m_buffer[byteno] | bitmask;
    }
    if(bit == 0)
    {
        bitmask = ~bitmask;
        m_buffer[byteno] = m_buffer[byteno] & bitmask;
    }
    return m_deviceNet->writeByte(m_macID, m_buffer);
}

bool IODevice::readAnalog(int channelNum, double *bit, const DoubleTypeInfo &typeInfo)
{
    char inbit[m_deviceNet->getIBytesSize(m_macID)];
    bool flag = m_deviceNet->readByte(m_macID, inbit);

    if(!flag)
    {
        return false;
    }
    else
    {
        *bit = (double)((inbit[(channelNum-300)*2] & 0xff) + (inbit[(channelNum-300)*2+1]<<8 &0xff00))   / m_dFullScale * typeInfo.getMax();
        return true;
    }
}

bool IODevice::writeAnalog(int channelNum, double bit, const DoubleTypeInfo &typeInfo)
{
    double inbit;
    inbit = bit / typeInfo.getMax() * m_dFullScale;
    m_buffer[(channelNum-200)*2] = char((int)inbit & 0xff);
    m_buffer[(channelNum-200)*2+1] = char(((int)inbit>>8) & 0xff);
    bool flag = m_deviceNet->writeByte(m_macID, m_buffer);
    if(!flag)
    {
        return false;
    }
    else
    {
        bit = inbit;
        return true;
    }
}

void IODevice::setOutEnableCh(int channelNum)
{
    if(channelNum >= m_DOChsSize || channelNum < 0)
    {
        throw ConfigException("IODevice: illegal OutEnableCh");
    }
    m_enableChs.push_back(channelNum);
}

void IODevice::setDIChsSize(int num)
{
    if(num < 0)
    {
        throw ConfigException("IODevice: illegal DIChsSize");
    }
    m_DIChsSize = num;
}

void IODevice::setAIChsSize(int num)
{
    if(num < 0)
    {
        throw ConfigException("IODevice: illegal AIChsSize");
    }
    m_AIChsSize = num;
}

void IODevice::setAOChsSize(int num)
{
    if(num < 0)
    {
        throw ConfigException("IODevice: illegal AOSChsSize");
    }
    m_AOChsSize = num;
}

void IODevice::setDOChsSize(int num)
{
    if(num < 0)
    {
        throw ConfigException("IODevice: illegal DOChsSize");
    }
    m_DOChsSize = num;
}

void IODevice::setPollInterval(int ms)
{
    m_pollInterval = ms;
}

void IODevice::initChs(DeviceNode<IODevice> *node)
{
    for(int i = 0; i < m_DIChsSize; ++i)
    {
        node->registerReadCh(i+100, &IODevice::readBit);
    }
    for(int i = 0; i < m_DOChsSize; ++i)
    {
        node->registerWriteCh(i, &IODevice::writeBit);
    }
    for(int i = 0; i < m_AIChsSize; ++i)
    {
        node->registerReadCh(i+300, &IODevice::readAnalog);
    }
    for(int i = 0; i < m_AOChsSize; ++i)
    {
        node->registerWriteCh(i+200, &IODevice::writeAnalog);
    }
    node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &IODevice::getStatus);//added by mujy[v1.0.8]
}

void IODevice::initDevice()
{
    for(int i=0; i<m_enableChs.size(); ++i)
    {
        int byteno = m_enableChs[i] / 8;
        int bitno = m_enableChs[i] % 8;
        unsigned char bitmask = 1;
        bitmask = bitmask << bitno;
        m_buffer[byteno] = m_buffer[byteno] | bitmask;
    }
    if(!m_deviceNet->writeByte(m_macID, m_buffer))
    {
        throw ConfigException("IODevice: write enable bits failed");
    }
}

bool IODevice::getStatus(int nChannelNum, int *pBit, const IntTypeInfo &typeInfo)
{
	if (m_currentCycle == m_pollStatusInterval)
	{
		m_currentCycle = 0;
		int nStatus = m_deviceNet->readStatus(m_macID);
		if (0 == nStatus)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::FATAL,
					getSelfName() + ": Node Status is abnormal! MacID: " + Converter::convertToString(m_macID)
							+ ", Status: " + Converter::convertToString(nStatus));
			m_connectStatus = COMMUNICATION_STATUS::DISCONNECT;
		}
		else
		{
			m_connectStatus = COMMUNICATION_STATUS::CONNECT;
		}
	}
	else
	{
		m_currentCycle++;
	}
	*pBit = m_connectStatus;
	return true;
}

void IODevice::initDeviceNet() 
{
    if(m_deviceNet == NULL)
    {
        #ifdef SS5136DN
        m_deviceNet = new DNSS5136("/dev/ss5136dn0", 0, m_baudRate);
        #warning DNSS5136
        #else
        #ifdef CIFXDN
        if(m_deviceName.find("AutoScan",0) != string::npos)//added by mujy [20250220] for cifx auto scan
        {
            m_deviceNet = new CIFXDEVNETAutoScan("/dev/uio0", 0, m_baudRate);
        }
        else
        {
            m_deviceNet = new CIFXDEVNET("/dev/uio0", 0, m_baudRate);
        }
        #warning CIFXDEVNET
        #else
		#ifdef ZYDN
		m_deviceNet = new ZYDEVNET("/dev/zdnm0A", 0, m_baudRate);//added by zhangyy [v1.4.0]
		#warning ZYDEVNET
		#else
		m_deviceNet = new SSTDN3PCU1("/dev/sstdn3pcu10", 0, m_baudRate);
		#warning SSTDN3PCU1		
		#endif
        #endif
        #endif
        m_deviceNet->setFWdir(m_fwdir);
        m_deviceNet->loadDevice();
    }
    if(!(m_deviceNet->addDevice(m_macID)))
    {
        throw ConfigException("Add device failed : " + Converter::convertToString(m_macID));
    }
}

void IODevice::init()
{
    DeviceNode<IODevice> * node = new DeviceNode<IODevice>(m_pollInterval,this);
    DeviceManager::getInstance()->registerNode(m_nodeNum, node);
    if(!isSimulated())
    {
        initChs(node);
        initDeviceNet();
        string error = "";
        int inBytesSize = m_deviceNet->getIBytesSize(m_macID);
        int outBytesSize = m_deviceNet->getOBytesSize(m_macID);
        if((m_DIChsSize + m_AIChsSize*16)  > inBytesSize*8)
        {
            error = "Input channel number is bigger than allowed input number: " + Converter::convertToString(m_DIChsSize + m_AIChsSize*16) + ">"+Converter::convertToString(inBytesSize*8);
            throw ConfigException(error);
        }
        if((m_DOChsSize + m_AOChsSize*16) > outBytesSize*8)
        {
            error = "Output channel number is bigger than allowed output number: " + Converter::convertToString(m_DOChsSize + m_AOChsSize*16) + ">"+Converter::convertToString(outBytesSize*8);
            throw ConfigException(error);
        }
        m_buffer = new char[outBytesSize];
        memset(m_buffer, 0, outBytesSize);
        initDevice();
    }
}

double IODevice::realToDouble(long value)
{
    unsigned long m = (value & 0x7fffff) | 0x800000;
    int e = (value >> 23) & 0xff;
    int s = (value >> 31) & 0x01;
    double res = 0;
    int mi = 0;
    for(int i=0; i<24; ++i)
    {
        mi = (m >> i) & 0x01;
        if(mi == 1)
        {
            res += pow((double)(mi*2), (int)(e-127+i-23));
        }
    }
    return res*pow(-1.0, (int)s);
}

unsigned long IODevice::doubleToReal(double value)
{

    unsigned long s = value>0?0:1;
    unsigned long e = 0;
    unsigned long m = 0;
    double x = log(value)/log(2);
    int Xtrunc = ((int)x) - (1-(x/fabs(x)))/2;
    e = Xtrunc + 127;
    unsigned long bitmask = 1;
    double mr1 = value - pow(2.0, Xtrunc);
    double mr2 = 0;
    for(int i=22; i>0; --i)
    {
        mr2 = mr1 - pow(2.0, (int)(Xtrunc+i-23));
        if(mr2 > 0)
        {
            m |= (bitmask << i);
            mr1 = mr2;
        }
    }
    unsigned long res = (s << 31) | (e << 23) | m;
     return res;
}

void IODevice::setBaudRate(int baudRate)
{
    m_baudRate = baudRate;
}

void IODevice::setFWdir(const std::string &dir)
{
    m_fwdir = dir;
}
/**
void IODevice::setFullScale(double dFullScale)
{
    m_dFullScale = dFullScale;
}
**/

void IODevice::setFullScale(const std::string &strPath)
{
    double dFullScale = 0;
    if(strPath.find("/") == std::string::npos)
    {
        if(!Converter::stringToDouble(dFullScale, strPath))
		{
			throw IOException("The FullScale type is invalid :" + strPath);
		}
        m_dFullScale = dFullScale;
    }
    else
    {
        string strTemp = XmlGetter::getFromNamespace<ReadWriteInt*>(strPath)->getValueAsDescriptor();
	string::size_type leftBracket = strTemp.find("(",0);//6
	string::size_type rightBracket = strTemp.find(")",0);//12
	//m_dFullScale = strTemp.substr(leftBracket+1,rightBracket-leftBracket-1);
	if(!Converter::stringToDouble(dFullScale, strTemp.substr(leftBracket+1,rightBracket-leftBracket-1)))
		{
			throw IOException("The FullScale type is invalid :" + strPath);
		}
        m_dFullScale = dFullScale;
	cout<<"&&&&&&&&&&&&&&  full scale = "<<m_dFullScale<<endl;
    }
}

void IODevice::setStatusPollInterval(int cycle)
{
    m_pollStatusInterval = cycle;
}

void IODevice::addAIFilterParam(int channelNum, int nAIFilterValue)//[added by wangyk 1.2.4]
{
    m_aiFilter.insert(pair<int,int>(channelNum,nAIFilterValue));
}
IMPLEMENT_DYNAMIC(IODevice, AbstractDevice )
BEGIN_MSG_MAP( IODevice, AbstractDevice )
    SET_S( setDeviceName, IODevice )
    SET_I( setNodeNum, IODevice )
    SET_I( setMacID, IODevice )
    SET_D( setValuePerUnit, IODevice )
    SET_I( setDIChsSize, IODevice )
    SET_I( setDOChsSize, IODevice )
    SET_I( setAIChsSize, IODevice )
    SET_I( setAOChsSize, IODevice )
    SET_I( setOutEnableCh, IODevice )
    SET_I( setPollInterval, IODevice )
    SET_I( setBaudRate, IODevice )
    //SET_D( setFullScale, IODevice )
    SET_S( setFWdir, IODevice )
    SET_I( setStatusPollInterval, IODevice )
	SET_II(addAIFilterParam, IODevice )//[added by wangyk 1.2.4]
    SET_V( init, IODevice )
    SET_S( setFullScale, IODevice )//zhangyy add for Gas CIP
END_MSG_MAP


