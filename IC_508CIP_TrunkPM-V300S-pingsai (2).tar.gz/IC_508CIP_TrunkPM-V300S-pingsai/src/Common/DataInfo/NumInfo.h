/********************************************************************
** Copyright (c) 2023 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: NumInfo.h
** Description:
** Release: 1.0
** Modification history:
** 					2023-10-31   GuoJin create
**
*********************************************************************/
#ifndef NUMINFO_H_
#define NUMINFO_H_

#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class NumInfo : public IntValueInfo
{
	public:
		static const IntTypeInfo typeInfo;

		NumInfo():IntValueInfo(0,typeInfo)
		{
		}

		NumInfo(int i):IntValueInfo(i, typeInfo)
		{
		}

		NumInfo(const std::string s):IntValueInfo(s, typeInfo)
		{
		}
};

#endif  /*NUMINFO_H_*/
