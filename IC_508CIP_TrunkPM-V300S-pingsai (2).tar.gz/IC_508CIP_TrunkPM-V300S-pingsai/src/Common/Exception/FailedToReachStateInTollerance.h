/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: FailedToReachStateInTollerance.h
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-03-17   LiJuanjuan create
**      
*********************************************************************/
#ifndef FAILEDTOREACHSTATEINTOLLERANCE_H_
#define FAILEDTOREACHSTATEINTOLLERANCE_H_

#include "TMCException.h"

class FailedToReachStateInTollerance:public TMCException
{
	public:
		FailedToReachStateInTollerance(const std::string &s);
};

#endif /*FAILEDTOREACHSTATEINTOLLERANCE_H_*/
