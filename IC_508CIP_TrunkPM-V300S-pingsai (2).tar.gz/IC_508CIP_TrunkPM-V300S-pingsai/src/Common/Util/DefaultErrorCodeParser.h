/********************************************************************
** Copyright (c) 2019, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: DefaultErrorCodeParser.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2019-5-8   mujy create
**      
*********************************************************************/
#ifndef DEFAULTERRORCODEPARSER_H_
#define DEFAULTERRORCODEPARSER_H_

#include "ErrorCodeParser.h"
#include <string>

class DefaultErrorCodeParser: public ErrorCodeParser   
{
	DECLARE_DYNAMIC(DefaultErrorCodeParser)
	DECLARE_MSG_MAP
	
public:
	DefaultErrorCodeParser();
	virtual ~DefaultErrorCodeParser();

public://override
	virtual std::string parseErrorCode(const std::string strCode);

};

#endif /*OPRPM_H_*/
