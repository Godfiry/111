/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: CheckItem.h
** Description:  
** Release: 1.1
** Modification history: 
**						2016-11-2		lvjw		Created
**      
*********************************************************************/

#ifndef STATION_H_
#define STATION_H_


#include "FunctionalModel.h"
#include "Service.h"
#ifdef IAP4_0
using namespace IAP::CONTROL;
#endif

class Station :public FunctionalModel
{
	DECLARE_DYNAMIC( Station ) 
	DECLARE_MSG_MAP
	DECLARE_SERVICEINFO_LIST

	class PrepWfr : public Service
	{
		DECLARE_DYNAMIC_SERVICE(PrepWfr)
		
		public:
			void execute();
	};
	class CompWfr : public Service
	{
		DECLARE_DYNAMIC_SERVICE(CompWfr)
		public:
			void execute();
	};
	
private:
	Station(const Station& pObj); //modified by chenw [1.6.0_RC02]

	Station& operator=(const Station& pObj);

public://construction
	Station();

	virtual ~Station();

public:
	int getWfrState(int nLocationIndex);
	void setWfrState(int nLocationIndex,int nState);
	
	int getCapacity();
	
public://xml config	
	void setCapacity(int nCapacity);
	
public://for service
	void call_PrepWfr(int nSlot, int nTransferOperation, int nHandOffMode,int nWaferID,string strLotID, string strWfrName);
	virtual void do_PrepWfr(int nSlot, int nTransferOperation, int nHandOffMode,int nWaferID,string strLotID, string strWfrName);
	
	void call_CompWfr();
	virtual int do_CompWfr();
	
protected://override
	virtual void initialize();
	virtual void verifyInit();
	virtual void make();
	
protected:
	bool checkLocationIndex(int nLocationIndex);
	
private:
	ReadWriteInt** m_ppSlotState;//index 0 is null
	ReadWriteInt*	m_pCapacity;
	
private:
	ServicePtr<PrepWfr> m_PrepWfr;
	ServicePtr<CompWfr> m_CompWfr;
};

#endif /*STATION_H_*/
