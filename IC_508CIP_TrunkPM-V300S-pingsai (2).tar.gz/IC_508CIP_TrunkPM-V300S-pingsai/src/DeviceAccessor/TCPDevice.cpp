/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TCPDevice.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-7-21   LiJuanjuan create
**      
*********************************************************************/
#include "TCPDevice.h"
#include "TCPConnection.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#ifdef IAP4_0
#include "ITime.h"
#else
#include "Time.h"
#endif
#include <string.h>
#ifdef IAP4_0
using namespace IAP;
using namespace IAP::CORE;
#endif

using namespace std;

TCPDevice::TCPDevice()
{
	m_connection = NULL;
	m_server = "";
	m_port = "";
	m_nodeNum = -1;
	m_pollInterval = 200;//ms
	m_timeOut = 10;//s
	m_checkInterval = 100;//ms
	m_connected = false;
	m_running = true;
	m_pingInterval = 2;//added by guojin[1.1.43]
	m_pingStatus = 0;
	m_pingStartTime = 0;
	m_pingLastTime = 0;
	memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
}

TCPDevice::~TCPDevice()
{
	m_running = false;
	if(m_connection != NULL)
	{
		m_connection->disconnect();
		delete m_connection;
	}
}

void TCPDevice::setServer(const std::string &server)
{
	m_server = server;
}
	
void TCPDevice::setPort(const string &port)
{
	m_port = port;
}

void TCPDevice::sendData(const char *data, int size)
{
	try
	{
		m_connection->sendData(data, size);	
	}
	catch(const exception &ex)
	{
		setDeviceConnected(false);
		throw;
	}
}

void TCPDevice::setNodeNum(int nodeNum)
{
	m_nodeNum = nodeNum;
}

void TCPDevice::setPollIntervalMS(int interval)
{
	m_pollInterval = interval;
}

void TCPDevice::setPingIntervalS(int interval)//added by guojin[1.1.43]
{
	m_pingInterval = interval;
}

void TCPDevice::setTimeOutS(int timeOut)
{
	m_timeOut = timeOut;
}

void TCPDevice::init()
{
	m_connection = new TCPConnection(m_server, m_port);
	m_connection->setDevice(this);
	m_connection->connect();
	setDeviceConnected(true);
	#ifdef IAP4_0
	m_pingStartTime = ITime::getCurrentTimeAsSeconds();//added by guojin[1.1.43]
	#else
	m_pingStartTime = Time::getCurrentTimeAsSeconds();//added by guojin[1.1.43]
	#endif
}

bool TCPDevice::getStatus(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)//added by mujy [v1.0.8]
{
	if(isConnected())
	{
		*pValue = COMMUNICATION_STATUS::CONNECT;
	}
	else
	{
		*pValue = COMMUNICATION_STATUS::DISCONNECT;
	}
	return true;
}

bool TCPDevice::isConnected()const
{
	return m_connection->isConnected() && m_connected;
}

void TCPDevice::setDeviceConnected(bool flag)
{
	m_connected = flag;
}

bool TCPDevice::reconnectDevice()
{
	setDeviceConnected(true);
	#ifdef IAP4_0
	m_pingStartTime = ITime::getCurrentTimeAsSeconds();//added by guojin[1.1.43]
	#else
	m_pingStartTime = Time::getCurrentTimeAsSeconds();//added by guojin[1.1.43]
	#endif
	return true;
}

bool TCPDevice::readData(char *buffer, int len)
{
	if(!m_connection->recvData(buffer, len))
	{
		setDeviceConnected(false);
		return false;
	}
	else
	{
		return true;
	}
}
		
bool TCPDevice::readFixLenData(char *buffer, int len)
{
	if(!m_connection->recvFixLenData(buffer, len))
	{
		setDeviceConnected(false);
		return false;
	}
	else
	{
		return true;
	}
}

std::string TCPDevice::getDeviceName()
{
	if(getName() != "")
	{
		return getName();
	}
	else
	{
		return "Unknown";
	}
}

IMPLEMENT_JOINT(TCPDevice, AbstractDevice)
BEGIN_MSG_MAP( TCPDevice, AbstractDevice)
	SET_S( setServer, TCPDevice )  
	SET_S( setPort, TCPDevice )
	SET_I( setNodeNum, TCPDevice )
	SET_I( setPollIntervalMS, TCPDevice )
	SET_I( setPingIntervalS, TCPDevice )//added by guojin[1.1.43]
	SET_I( setTimeOutS, TCPDevice )
	SET_V( init, TCPDevice )
END_MSG_MAP
