/*
 * SHMInitInstance.cpp
 *
 *  Created on: 2025年4月29日
 *      Author: wenxiang
 */

#include <unistd.h>
#include "SHMInitInstance.h"
#include "IMutex.h"
#include "SysLogger.h"

#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
using namespace IAP;
#endif

SHMInitInstance SHMInitInstance::m_instance;

SHMInitInstance& SHMInitInstance::getInstance()
{
	return m_instance;
}

SHMInitInstance::SHMInitInstance()
{
}

SHMInitInstance::~SHMInitInstance()
{
}

bool SHMInitInstance::InitSHM()
{
	static bool shmInitialized = false;
	static IMutex shmMutex;

	shmMutex.lock();
	if(shmInitialized)
	{
		shmMutex.unlock();
		return true;
	}

	int count = 0;
	while(count < 10)
	{
		if(KY_SHM_OK != Init())
		{
			count += 1;
			usleep(500*1000);
		}
		else if(count == 10)
		{
	        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
	                        "EtherCatToSerial::shmSerialOpen() failed: initial shared memory failed.");
			return false;
		}
		else
		{
			break;
		}
	}

	shmInitialized = true;
	shmMutex.unlock();

	return true;
}

bool SHMInitInstance::InitEcatSHM()
{
	static bool ecatInitialized = false;
	static IMutex ecatMutex;

	ecatMutex.lock();
	if(ecatInitialized)
	{
		ecatMutex.unlock();
		return true;
	}

	int count = 0;
	while(count < 10)
	{
		if(S_ERROR == ky_ecat_shm_init())
		{
			count += 1;
			usleep(500*1000);
		}
		else if(count == 10)
		{
	        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
	                        "EtherCatToSerial::shmSerialOpen() failed: initial EtherCAT shared memory failed.");
			return false;
		}
		else
		{
			break;
		}
	}

	ecatInitialized = true;
	ecatMutex.unlock();

	return true;
}
