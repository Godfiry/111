/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: ChillerAtsEnt30.cpp
** Description:  
** Release: 1.1
** Modification history: 
*                      2019-1-3   chenmz create
**
*********************************************************************/
#include "ChillerAtsEnt30.h"
#include "DeviceManager.h"

#include "Converter.h"
#include "Hex.h"
#include "StrTool.h"
#include "CheckCalculationTool.h"
#include "SysLogger.h"
#include <string.h>
#include <iostream>
#include <cctype>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;

ChillerAtsEnt30::Cmd ChillerAtsEnt30::m_cmd[] = {{""},//reserved
                                       {":0117010200000109000102",0}, //1 stop:0/run:1
                                              {":011701020000010A000102",0},//2  set temprature
                                              {":011701010002010A000000",0},//3 read temperature (-60~160)
                                              {":011701040002010A000000",0},//4 read fluid resistivity(0~20)
                                              {":011701050002010A000000",0},//5 read flow rate(0~10)
                                              {":011701000002010A000000",0x8000},//6 read fault summary ok:0/fault:1
                                              {":011701000002010A000000",0x4000},//7 read warn summary ok:0/warning:1
                                            {":011701020002010A000000",0x0400},//8 local:0/remote:1
                                            {":011701020002010A000000",0xF800},//9 read fault
//(15:fluid level fault/14:fluid flow fault/13:fluid resistivity fault/12:facility water fault/11:fuse fault)
                                            {":011701020002010A000000",0x0200},};//10 read on off

ChillerAtsEnt30::ChillerAtsEnt30():SerialDevice(200, "\x0D\x0A")
{
    m_timeOut = 50;//5s
    m_pollPeriod = 1000; //1s
}

ChillerAtsEnt30::~ChillerAtsEnt30()
{
}

bool ChillerAtsEnt30::writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
    string strCommand = m_cmd[nChannelNum].m_strAddress;
    double dTemp = (double)((dValue + 60) * 65535 / 220);
    double dTemp1 = (int) dTemp;
    int nTemp = dTemp1;
    string strTemp = Hex::hexToString(nTemp,4);
    strCommand += strTemp;
    strCommand += CheckCalculationTool::GetLRCCode(strCommand);
    strCommand = StrTool::toUpper(strCommand);
    string strResponse = getCommandResult(strCommand, m_timeOut);
    size_t nPos = strResponse.find(":", 0);  //changed by wzd 1.1.39
    if(nPos == string::npos)
    {
        throw IOException("Chiller write temperature ["+Converter::convertToString(dValue)+"] failed for unknown response [" + strResponse+"]");
    }
    return true;
}

bool ChillerAtsEnt30::readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo)
{
    Cmd cmd = m_cmd[nChannelNum];
    string strCommand = cmd.m_strAddress + CheckCalculationTool::GetLRCCode(cmd.m_strAddress);
    strCommand = StrTool::toUpper(strCommand);
    string strRes = getCommandResult(strCommand, m_timeOut);
    size_t nPos = strRes.find(":", 0);  //changed by wzd 1.1.39
    if(nPos == string::npos)
    {
        throw IOException("Chiller read temperature failed for unknown response [" + strRes+"]");
    }
    else
    {
        string strValue = strRes.substr(nPos+7, 4);
        int nValue = 0;
        if(!Hex::stringToHex(&nValue, strValue))
        {
            throw IOException("Chiller read temperature failed for can't convert response ["+strValue+"] to double value.");
        }
        else
        {
            switch(nChannelNum)
            {
                case 3:
                    *pValue = nValue * 220.0/65535.0-60;//value range is from -60 to 160,see the manual
                    break;
                case 4:
                    *pValue = nValue * 20/65535.0;//value range is from 0 to 20,see the manual
                    break;
                case 5:
                    *pValue = nValue * 10/65535.0;//value range is from 0 to 10,see the manual
                    break;
                default:
                    break;
            }
            return true;
        }
    }
}

bool ChillerAtsEnt30::readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
    Cmd cmd = m_cmd[nChannelNum];
    string strCommand = cmd.m_strAddress + CheckCalculationTool::GetLRCCode(cmd.m_strAddress);
    strCommand = StrTool::toUpper(strCommand);
    string strRes = getCommandResult(strCommand, m_timeOut);

    size_t nPos = strRes.find(":", 0);  //changed by wzd 1.1.39
    if(nPos == string::npos)
    {
        throw IOException("Chiller read status failed for unknown response [" + strRes+"]");
    }
    else
    {
        string strValue = strRes.substr(nPos+7, 4);
        int nTempValue = 0;
        if(!Hex::stringToHex(&nTempValue, strValue))
        {
            throw IOException("Chiller read status failed for can't convert response ["+strValue+"] to integer value.");
        }
        else
        {
            *pValue = (nTempValue & cmd.m_nDeal) != 0;
            switch(nChannelNum)
            {
                case 6:
                case 7:
                case 9:
                    if(*pValue == 1)
                    {
                        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "ChillerAtsEnt30: channel ["+Converter::convertToString(nChannelNum)+"] read back = "+strRes +" ;split value = "+strValue);
                        if(nChannelNum == 9)
                        {
                            if(nTempValue & 0x8000)
                            {
                                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,"ChillerAtsEnt30 has alarm.Detail is fluid level fault");
                            }
                            if(nTempValue & 0x4000)
                            {
                                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,"ChillerAtsEnt30 has alarm.Detail is fluid level fault");
                            }
                            if(nTempValue & 0x2000)
                            {
                                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,"ChillerAtsEnt30 has alarm.Detail is fluid resistivity fault");
                            }
                            if(nTempValue & 0x1000)
                            {
                                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,"ChillerAtsEnt30 has alarm.Detail is facility water fault");
                            }
                            if(nTempValue & 0x0800)
                            {
                                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,"ChillerAtsEnt30 has alarm.Detail is fuse fault");
                            }
                        }
                    }
                    break;
                case 8:
                case 10:
                    if(*pValue == 0)
                    {
                        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "ChillerAtsEnt30: channel ["+Converter::convertToString(nChannelNum)+"] read back = "+strRes+" ;split value = "+strValue);
                    }
                    break;
                default:
                    break;
            }

            return true;
        }
    }
}

bool ChillerAtsEnt30::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
    string strCommand = m_cmd[nChannelNum].m_strAddress;
    if(nValue == 1)
    {
        strCommand += "8000";
    }
    else
    {
        strCommand += "0000";
    }
    strCommand += CheckCalculationTool::GetLRCCode(strCommand);
    strCommand = StrTool::toUpper(strCommand);//need test to decide if keep it
    sendCommandOnly(strCommand);
    return true;
}

void ChillerAtsEnt30::initChs(DeviceNode<ChillerAtsEnt30> *pNode)
{
    pNode->registerWriteCh(1, &ChillerAtsEnt30::writeInt);
    pNode->registerWriteCh(2, &ChillerAtsEnt30::writeDouble);
    for(int i = 3; i<=5; ++i)
    {
        pNode->registerReadCh(i, &ChillerAtsEnt30::readDouble);
    }
    for(int i = 6; i<=10; ++i)
    {
        pNode->registerReadCh(i, &ChillerAtsEnt30::readInt);
    }
    pNode->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &ChillerAtsEnt30::getStatus);//added by mujy [v1.0.8]
}

void ChillerAtsEnt30::initDevice()
{
    cout<<"Start Scan Chiller...."<<endl;
    //say hello to chiller
    double dTemp;
    try
    {
        readDouble(3,&dTemp,DoubleTypeInfo());//3 read temprature
    }
    catch(exception &ex)
    {
        cout<<"Scan chiller failed. Communication abnormal!"<<endl;
        throw;
    }
    cout<<"Scan Chiller Successfully...."<<endl;
}

void ChillerAtsEnt30::init()
{
    DeviceNode<ChillerAtsEnt30> *pNode = new DeviceNode<ChillerAtsEnt30>(m_pollPeriod, this);
    DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
    if(!isSimulated())
    {
        initChs(pNode);
        initDevice();
    }
}

IMPLEMENT_DYNAMIC(ChillerAtsEnt30, SerialDevice )

BEGIN_MSG_MAP(ChillerAtsEnt30, SerialDevice )
    SET_V( init, ChillerAtsEnt30 )
END_MSG_MAP


