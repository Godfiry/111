/*
 * SHMInitInstance.h
 *
 *  Created on: 2025年4月29日
 *      Author: wenxiang
 */

#ifndef DEVICEACCESSOR_SHMINITINSTANCE_H_
#define DEVICEACCESSOR_SHMINITINSTANCE_H_

#include "shmlib.h"
#include "ky_ecat_shm.h"
#include "IMutex.h"

#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
#endif

class SHMInitInstance
{
private:
	static SHMInitInstance m_instance;


public:
	bool InitSHM();
	bool InitEcatSHM();

	static SHMInitInstance& getInstance();

private:
	SHMInitInstance();
	~SHMInitInstance();
};

#endif /* DEVICEACCESSOR_SHMINITINSTANCE_H_ */
