/********************************************************************
** Copyright (c) 2020, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AEDualMatch2M60M.h
** Description:  Navigator 5060/5002 L-90Z Dual Match Network
*                RS232
*  				   BaudRate: 19200
* 				   Address: 2
* 				   DataBit:8
*                StopBit:1
*                Parity: ODD
*                Protocol:AE Bus communication protocol
* 				   Communication Type:All commands are hexadecimal (0xFF).
* 
** Data package format:
* |     5bit    |       3bit     |1 byte |     1 byte         |(0-255)bytes| 1 byte |
* |Address(0-31)|Data Length(0-6)|
* |            Header            |Command|Optional Data Length| Data Length|Checksum|

** Example:  
*
* (1)Host computer send message:
* DataPackage:  0x0A   0x06     0x64	 0x00	      0x68	
* decription: |Header|Command|-------Data-------|-Checksum-| 
* 
* (2)Receive ACK from Match:
* DataPackage:  0x06 
* decription:   |ACK|
* 
* (3)Receive response from Match:
* DataPackage:  0x09   0x06     0x00	    0x0F	
* decription: |Header|Command|--CSR---|-Checksum-| 
* 
* (4)Host computer send ACK:
* DataPackage:  0x06 
* decription:   |ACK|
* 
** Release: 1.0
** Modification history: 
** 					2020-04-04   mayc create
**      
*********************************************************************/

#ifndef AEDUALMATCH2M60M_H_
#define AEDUALMATCH2M60M_H_
#include "SerialDevice.h"
#include "DeviceNode.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class AEDualMatch2M60M : public SerialDevice
{
    DECLARE_DYNAMIC(AEDualMatch2M60M)	
    DECLARE_MSG_MAP
public:
    AEDualMatch2M60M();
    virtual ~AEDualMatch2M60M();
    
public:
    void init();//xml
    void InitChannels(DeviceNode<AEDualMatch2M60M> *pNode);      
    bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
    bool readInt(int nChannelNum,int *pValue,const IntTypeInfo &typeInfo);
    bool writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo);
    bool readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo);
	bool readString(int channelNum, std::string *value, const StringTypeInfo &typeInfo);
    void setAddress(int nAddr);
    void initDevice();
private:
    typedef struct
	 {
		int nCmdLen;    //Command lenth
		unsigned char cCmdNum;   //Command number  //changed by wzd 1.1.39
		int nResLen;    //Response length
	 }Com;
	 static Com m_commands[];	 
    static const int RESP_LEN = 20;
    static const int MESS_LEN = 20;
    int m_nPreC1;
    int m_nPreC2;

    char message[MESS_LEN];
    char resp[RESP_LEN];
    char ack[1];
    int m_nAddr;
    bool sendCommandAck(char *pMsg, char *pResponse, int nMsg_timeout, int nResplen, int nMsglen);
    bool readCommand(char *pMsg, char *pResponse, int nMsg_timeout, int nResplen, int nMsglen);
};

#endif /*AEDUALMATCH2M60M_H_*/
