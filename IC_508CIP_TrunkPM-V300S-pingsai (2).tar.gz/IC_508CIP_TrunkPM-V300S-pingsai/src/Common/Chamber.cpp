#include "Chamber.h"
#include "ObjectManager.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "InvalidNameException.h"
#endif
#include "ConfigException.h"
#include "SysLogger.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
#endif
Chamber::Chamber()
{
	m_OpenDoor=new OpenDoor();
	m_OpenDoor->setOwner(this);
	
	m_CloseDoor=new CloseDoor();
	m_CloseDoor->setOwner(this);

	m_IsolateDoor=new IsolateDoor();
	m_IsolateDoor->setOwner(this);
}

Chamber::~Chamber()
{
}

void Chamber::addDoor(int nPort,const std::string &strPath)
{
	ManagedObject *obj = NULL;
	try
	{
		obj = ObjectManager::getInstance()->getObject(this, strPath);
	}
	catch(const InvalidNameException &ex)
	{
		obj = ObjectManager::getInstance()->getObject(strPath);
	}
	ValveController *pDoor = dynamic_cast<ValveController*>(obj);
	if(NULL == pDoor)
	{
		std::string error = "the object under path '" + strPath + "' is not a ValveController";
		throw ConfigException(error);
	}	
	m_Doors[nPort]=pDoor;
}

void Chamber::call_OpenDoor(int nPort)
{
	m_OpenDoor->setParamValue("port",nPort);
	call(m_OpenDoor);
}

void Chamber::do_OpenDoor(int nPort)
{
	//write content here
	if (m_Doors.count(nPort) == 0)
	{
		//postAlarm("DoorNotExist");
	}
	// todo : check code ,need try catch?
	m_Doors[nPort]->call_Open();
}

void Chamber::call_CloseDoor(int nPort)
{
	m_CloseDoor->setParamValue("port",nPort);
	call(m_CloseDoor);
}

void Chamber::do_CloseDoor(int nPort)
{
	//write content here
	if (m_Doors.count(nPort) == 0)
	{
		//postAlarm("DoorNotExist");
	}
	// todo : check code ,need try catch?
	m_Doors[nPort]->call_Close();
}

void Chamber::call_IsolateDoor()
{
	call(m_IsolateDoor);
}

void Chamber::do_IsolateDoor()
{
	std::map<int ,ValveController *>::iterator it;
	for(it=m_Doors.begin();it!=m_Doors.end();++it)
	{
		(it->second)->call_Close();
	}
}

void Chamber::OpenDoor::execute()
{
	Chamber *pOwner = dynamic_cast<Chamber*>(getOwner());
	if(pOwner != NULL)
	{
		int nPort = Params["port"].Int;
		pOwner->do_OpenDoor(nPort);
	}
}

void Chamber::CloseDoor::execute()
{
	Chamber *pOwner = dynamic_cast<Chamber*>(getOwner());
	if(pOwner != NULL)
	{
		int nPort = Params["port"].Int;
		pOwner->do_CloseDoor(nPort);
	}
}

void Chamber::IsolateDoor::execute()
{
	Chamber *pOwner = dynamic_cast<Chamber*>(getOwner());
	if(pOwner != NULL)
	{
		Log_Info(pOwner->getName()+": IsolateDoor start");
		pOwner->do_IsolateDoor();
		Log_Info(pOwner->getName()+": IsolateDoor end");
	}
}

bool Chamber::isIsolatedDoor()
{
	std::map<int ,ValveController *>::iterator it;
	for(it=m_Doors.begin();it!=m_Doors.end();++it)
	{
		if((it->second)->isOpen())
		{
			return false;
		}
	}
	return true;
}

bool Chamber::isDoorOpen(int nPort)
{
	if(IsDoorExist(nPort))
	{
		return m_Doors[nPort]->isOpen();
	}
	else
	{
		//postAlarm("DoorNotExist");
		return false;
	}
}

bool Chamber::isDoorClose(int nPort)
{
	if(IsDoorExist(nPort))
	{
		return m_Doors[nPort]->isClose();
	}
	else
	{
		//postAlarm("DoorNotExist");
		return false;
	}
}

ValveController * Chamber::getDoor(int nPort)
{
	if(IsDoorExist(nPort))
	{
		return m_Doors[nPort];
	}
	else
	{
		return NULL;
	}
}

bool Chamber::IsDoorExist(int nPort)
{
	return (m_Doors.count(nPort) != 0);
}

void Chamber::initialize()
{
	Station::initialize();
	//addAlarm("DoorNotExist");
}

void Chamber::verifyInit()
{
	Station::verifyInit();
}

IMPLEMENT_DYNAMIC_SERVICE(OpenDoor, Chamber)
IMPLEMENT_DYNAMIC_SERVICE(CloseDoor, Chamber)
IMPLEMENT_DYNAMIC_SERVICE(IsolateDoor, Chamber)

BEGIN_SERVICEINFO_LIST(Chamber)
	ADD_SERVICE_INFO(Chamber, OpenDoor, The OpenDoor service )
		ADD_PARAM_INFO(Chamber, OpenDoor, port, int, )
	ADD_SERVICE_INFO(Chamber, CloseDoor, The CloseDoor service )
		ADD_PARAM_INFO(Chamber, CloseDoor, port, int, )
	ADD_SERVICE_INFO(Chamber, IsolateDoor, The IsolateDoor service )
END_SERVICEINFO_LIST(Chamber)

IMPLEMENT_DYNAMIC(Chamber, Station)

BEGIN_MSG_MAP( Chamber, Station )
    SET_IS( addDoor, Chamber )
END_MSG_MAP
