/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .cpp
** Description: 
** Release: 
** Modification history: 
** 					2013-08-01  lijj  create 
**      
***************************************************************************/
#include "CustomRecoveryWrapper.h"

CustomRecoveryWrapper::CustomRecoveryWrapper(CustomRecoveryInterface *owner)
{
	m_owner = owner;
}

CustomRecoveryWrapper::~CustomRecoveryWrapper()
{
}

bool CustomRecoveryWrapper::execute(const Alarm *alarm, Recovery *recovery)
{
	m_owner->execute(alarm, recovery);
	return true;//zhangyy add for sonar test[1.6.0]
}
