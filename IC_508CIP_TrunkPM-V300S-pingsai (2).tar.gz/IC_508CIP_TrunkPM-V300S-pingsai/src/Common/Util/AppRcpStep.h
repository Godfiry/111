/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AppRcpStep.h
** Description:  
** Release: 1.1
** Modification history: 
**                     2009-8-4   LiJuanjuan create
**      
*********************************************************************/
#ifndef APPRCPSTEP_H_
#define APPRCPSTEP_H_

#include <map>
#include <vector>
#include "DataType.h"
#include <string>
#include "IntValueInfo.h"
#include "StringValueInfo.h"
#include "DoubleValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP;
#endif
using namespace std;
typedef struct 
{
    #ifdef IAP4_0
    IAP::IO::DataType Type;
    #else
    IO::DataType Type;
    #endif
    std::string Name;
    std::string StringValue1;
    IntValueInfo IntValue;
    StringValueInfo StringValue;
    DoubleValueInfo DoubleValue;
    DoubleValueInfo finalDoubleValue; //added by th 1.1.26
    
}ParamValue;

class AppRcpStep
{
    private:
        std::string m_stepName;
        int m_stepNum;
        std::map<std::string, ParamValue> m_paramMap;
        std::vector<ParamValue> m_paramVector;
        //std::map<std::string, ParamValue>::const_iterator it;//deleted by mjr[1.5.0] for unittest
    
    public:
        AppRcpStep();
        virtual ~AppRcpStep();
        
        std::string getStepName()const;
        ParamValue getParamValue(const std::string &param)const;
        ParamValue getParamValue(int index)const;
        bool hasParam(const std::string &param)const;
        void addParam(const ParamValue &value);
        void setStepName(const std::string &name);
        int getParamSize()const;
        int getStepNum()const;        
        void setStepNum(int stepnum);
        double getParamDoubleValue(const std::string &param);
        int getParamIntValue(const std::string &param);
        std::string getParamStringValue(const std::string &param);
        
        
};

#endif /*APPRCPSTEP_H_*/
