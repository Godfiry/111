/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TCPDevice.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-7-21   LiJuanjuan create
**      
*********************************************************************/
#ifndef TCPDEVICE_H_
#define TCPDEVICE_H_


#include "AbstractDevice.h"
#include "IntTypeInfo.h"
#include "MathTool.h"
#include "DefineValue.h"
#include "CommunicationStatusEnum.h"
#include "Hex.h"
#include "CBase.h"//[zhangcx v1.1.21]
#include <unistd.h>  //add by wzd 1.1.39
#include "DriverHelper.h"//added by mujy [1.5.0] for TCPDeviceBaseClass
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class TCPConnection;

class TCPDevice:public AbstractDevice,public CBase//[zhangcx v1.1.21]
{
	DECLARE_JOINT(TCPDevice)	
	DECLARE_MSG_MAP
	public:
		virtual bool getStatus(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);//added by mujy [v1.0.8]
	
	private:
		TCPConnection *m_connection;	
		bool m_connected;	
		
	protected:
		std::string m_server;
		std::string m_port;
		int m_nodeNum;
		int m_pollInterval;//ms
		static const int s_INBUFFERSIZE = 65535;
		char m_recvBuffer[s_INBUFFERSIZE];
		int m_timeOut;//s
		int m_checkInterval;//ms	
		bool m_running;		

		int m_pingInterval;//s added by guojin[1.1.43]
		int m_pingStatus;
		long m_pingStartTime;//time as seconds
		long m_pingLastTime;//time as seconds
		
		bool isConnected()const;
		
	public:
		TCPDevice();
		virtual ~TCPDevice();
		
		void setServer(const std::string &server);
		void setPort(const std::string &port);
		virtual void init();
		virtual void acceptData()=0;
		void sendData(const char *data, int size);
		void setNodeNum(int nodeNum);
		void setPollIntervalMS(int interval);
		void setPingIntervalS(int interval);//added by guojin[1.1.43]

		void setTimeOutS(int timeOut);
		bool readData(char *buffer, int len);
		bool readFixLenData(char *buffer, int len);
		virtual bool reconnectDevice();
		virtual void setDeviceConnected(bool flag);
		virtual std::string getDeviceName();
};

#endif /*TCPDEVICE_H_*/
