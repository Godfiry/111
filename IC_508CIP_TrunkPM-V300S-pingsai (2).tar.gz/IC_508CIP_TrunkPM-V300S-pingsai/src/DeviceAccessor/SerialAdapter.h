/*
 * SerialAdaapter.h
 *
 *  Created on: 2024年12月27日
 *      Author: wenxiang
 */

#ifndef SRC_DEVICEACCESSOR_SERIALADAPTER_H_
#define SRC_DEVICEACCESSOR_SERIALADAPTER_H_

#include <string>
#include "DevicePara.h"
#include "ISerialPort.h"
#ifdef KYLAND
#include "EtherCatToSerial.h"
#endif
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class SerialAdapter
{
private:
	ISerialPort* m_dev1;
#ifdef KYLAND
	EtherCatToSerial* m_dev2;
#endif
	DeviceType m_type;
	SerialPortSettings m_portSettings;  // used to store serial port settings for EtherCatToSerial.


public:
	SerialAdapter();
	~SerialAdapter();

public:
	void init(DeviceType type);
	void init(); // only for default serial port. no need to modify driver configure file

	void closePort();
	bool openPort(const char *dev);
	bool setBaudRate(unsigned int rate);
	bool setCharSize(unsigned int size);
	bool setStopBit(unsigned int stopBit);
	bool setParity(unsigned int mode);
	bool setXonoff(bool en);
	bool setRtscts(bool en);
	bool setSlaveAddress(unsigned short slaveaddress);
	bool setDataFrame(const std::string &dataframe);
	bool setIndex(unsigned short index);
	int readStr(char *buf, int timeout, int maxread);
	int writeRaw(const char *str, int count);
};


#endif /* SRC_DEVICEACCESSOR_SERIALADAPTER_H_ */
