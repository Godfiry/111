/*
 * MatchCOMET29A.cpp
 *
 *  Created on: 2021-4-27
 *      Author: lvjiawen
 */

#include "MatchCOMET29A.h"
#include "DeviceManager.h"

#include "IStringList.h"
#include "StrTool.h"
#include "Converter.h"

#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;

string MatchCOMET29A::m_commands[] = {
		//write
		"%s",//0
		"Load%04.1f",//1--set C1
		"Tune%04.1f",//2--set C2
		"SP0",//3
		"G0",//4
		//read
		"QP##",//5
		"QP##",//6
		"QP0",//7
		"QV",//8 [zhangcx v1.1.21 //old order, reserved for YanDong first 8 inches ATM machine]
		"Zload",//9--R
		"Zload",//10--X
		"QAux"//11 [zhangcx v1.1.21 //new order alternative channel 8]
};

MatchCOMET29A::MatchCOMET29A()
{
}

MatchCOMET29A::~MatchCOMET29A()
{
}

bool MatchCOMET29A::readString(int nChannelNum, std::string *pValue, const StringTypeInfo &typeInfo)
{
	//Log_Info("PC->MatchCOMET29A:"+m_commands[nChannelNum]);

	string strResult;
	strResult=readCommand(m_commands[nChannelNum], m_timeOut);
	//Log_Info("MatchCOMET29A->PC:"+strResult);
	*pValue=strResult;
	return true;
}

bool MatchCOMET29A::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
	if(nChannelNum == 1 || nChannelNum == 2)
	{
		double dValue=nValue /10.0f;

		char strCmd[100]={0};
		sprintf(strCmd,m_commands[nChannelNum].c_str(),dValue);

		Log_Info("PC->MatchCOMET29A:%s",strCmd);
		sendCommand(strCmd, m_timeOut);
	}
	else
	{
		char strCmd[100]={0};
		sprintf(strCmd,m_commands[nChannelNum].c_str(),nValue);
		Log_Info("PC->MatchCOMET29A:%s",strCmd);
		sendCommand(strCmd, m_timeOut);
	}
	return true;
}

bool MatchCOMET29A::writeRawCommand(int nChannelNum, std::string strValue, const StringTypeInfo &typeInfo)
{
	string strResult;
	char strCmd[100]={0};
	sprintf(strCmd,m_commands[nChannelNum].c_str(),strValue.c_str());
	strResult=readCommand(strCmd, m_timeOut);
	cout<<"send = "<<strCmd<<"; response = "<<strResult<<endl;
	return true;
}

bool MatchCOMET29A::readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{

	//Log_Info("PC->MatchCOMET29A:"+m_commands[nChannelNum]);

	string strResult;
	strResult=readCommand(m_commands[nChannelNum], m_timeOut);
	//Log_Info("MatchCOMET29A->PC:"+strResult);

	if(nChannelNum == 5 || nChannelNum == 6)
	{
		vector<string> splitStrings = StrTool::split(strResult,",");
		if (splitStrings.size() != 2)
		{
			Log_Error("QP## return Err.Back string is:"+strResult);
			throw IOException("QP## return Err.Back string is:"+strResult);
		}
		double dC1,dC2;
		Converter::stringToDouble(dC1,splitStrings[0]);
		Converter::stringToDouble(dC2,splitStrings[1]);
		if(nChannelNum == 5)
		{
			*pValue=dC1*10;
		}
		if(nChannelNum == 6)
		{
			*pValue=dC2*10;
		}
	}
	if(nChannelNum == 8)
	{
		strResult = StrTool::trim_end(strResult,">");
		double dVpk;
		Converter::stringToDouble(dVpk,strResult);
		*pValue=dVpk*1.414f;
	}
	if(nChannelNum == 11)//[zhangcx v1.1.21]
	{
		strResult = StrTool::trim_end(strResult,">");
		double dVpk;
		Converter::stringToDouble(dVpk,strResult);
		*pValue=dVpk*1.0f;
	}
	return true;
}

bool MatchCOMET29A::readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo)
{
	string strResult;
	strResult=readCommand(m_commands[nChannelNum], m_timeOut);

	if(nChannelNum == 9 || nChannelNum == 10)
	{
		//return data eg.
		//"3.06 + 165 j"
		//"3.60 + 91.2j"
		//"3.60 - 91.2j"
		if(!StrTool::endWith(strResult,"j"))
		{
			Log_Error("Zload return Err.not end with 'j'!Back string is:"+strResult);
			throw IOException("Zload return Err.not end with 'j'!Back string is:"+strResult);
		}
		strResult=StrTool::trim_end(strResult," j");
		vector<string> splitStrings = StrTool::split(strResult," ");
		if (splitStrings.size() != 3)
		{
			Log_Error("Zload return Err.Back string is:"+strResult);
			throw IOException("Zload return Err.Back string is:"+strResult);
		}

		double dR,dX;
		Converter::stringToDouble(dR,splitStrings[0]);
		string strDX = splitStrings[1]+splitStrings[2];
		Converter::stringToDouble(dX,strDX);
		if(nChannelNum == 9)
		{
			*pValue=dR;
		}
		if(nChannelNum == 10)
		{
			*pValue=dX;
		}
	}
	return true;
}

void MatchCOMET29A::initChs(DeviceNode<MatchCOMET29A> *node)
{
	node->registerWriteCh(0, &MatchCOMET29A::writeRawCommand);


	for(int i = 1; i <= 4; ++i)
	{
		node->registerWriteCh(i, &MatchCOMET29A::writeInt);
	}
	for(int i = 5; i <= 8; ++i)
	{
		node->registerReadCh(i, &MatchCOMET29A::readInt);
	}
	node->registerReadCh(9, &MatchCOMET29A::readDouble);
	node->registerReadCh(10, &MatchCOMET29A::readDouble);
	node->registerReadCh(11, &MatchCOMET29A::readInt);//[zhangcx v1.1.21]

	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &MatchCOMET29A::getStatus);//[added by wangyk 1.4.0 RC03]
}

void MatchCOMET29A::initDevice()
{
	int nTemp;
	try
	{
		readInt(5,&nTemp,IntTypeInfo());//9 get Manual/Auto
	}
	catch(exception &ex)
	{
		cout<<"Scan COMET Single Match failed. Communication abnormal!"<<endl;
		throw;
	}
}

void MatchCOMET29A::init()
{
	DeviceNode<MatchCOMET29A> *node = new DeviceNode<MatchCOMET29A>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	initChs(node);
	if(!isSimulated())
	{
		initDevice();
	}
}

IMPLEMENT_DYNAMIC(MatchCOMET29A, COMETMatchDriver )
BEGIN_MSG_MAP(MatchCOMET29A, COMETMatchDriver )
    SET_V( init, MatchCOMET29A )
END_MSG_MAP
