/******************************************************************************
 * Copyrigh (C) 2008 by Lu Yiming
 *
 * File: display.h
 *
 * Date: 2008-05-14
 *
 * Author: Lu Yiming, <luym@bj-nmc.local>
 *
 * Version: 0.1
 *
 * Descriptor:
 *   display infomation
 *
 * Modified:
 *
 ******************************************************************************/

#ifndef _DISPLAY_H
#define _DISPLAY_H

#ifdef IAP4_0
#include "ITime.h"
#else
#include "Time.h"
#endif
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

#ifdef IAP4_0
#define DISPLAY(funcName) std::cout<<ITime::getCurrentTimeAsStr()<<":"<<getName()<<" :"<<funcName<<std::endl;
#else
#define DISPLAY(funcName) std::cout<<Time::getCurrentTimeAsStr()<<":"<<getName()<<" :"<<funcName<<std::endl;
#endif

#endif /* _DISPLAY_H */

