/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: M600.h
** Description:RS-232 for M600 Series OEM Fluoroptic Thermometer.
*                RS232
* 				 BaudRate:9600
*                DataBit:8
*                StopBit:1
*                Parity:none
* 1.select startup mode of device standard mode. In Standard mode the input circuits are enabled and the device begins reporting
* temperatures as soon as data are ready. Send command: ST = E
* 2.Active input channel 3. Send command: PS = 3
** Release: 1.1
** Modification history: 
** 					2009-11-25   LiJuanjuan create
**      
*********************************************************************/
#ifndef M600_H_
#define M600_H_

#include "SerialDevice.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class M600:public SerialDevice
{
	DECLARE_DYNAMIC(M600)	
	DECLARE_MSG_MAP	

	public:
		M600();
		virtual ~M600();
		
		bool readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);
		void init();		
		void setAO(double dAO);
		void setAS(double dAS);

	protected:
		void initDevice();
		void initChs(DeviceNode<M600> *node);

	private:
		double m_dAO;
		double m_dAS;
		double m_dLastTemperature;
};

#endif /*M600_H_*/
