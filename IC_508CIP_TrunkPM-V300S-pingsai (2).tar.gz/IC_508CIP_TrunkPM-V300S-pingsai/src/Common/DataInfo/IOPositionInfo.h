/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: IOPositionInfo.h
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-01-03   LiJuanjuan create
**      
*********************************************************************/
#ifndef IOPOSITIONINFO_H_
#define IOPOSITIONINFO_H_

#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class IOPositionInfo:public IntValueInfo
{
	public:
		static const int UnInit = -1;
		static const int Unknown = 2;
		static const int Open = 1;
		static const int Close = 0;
		static const int Error = 3;
		static const int SoftUp = 4;  //add by wzd 1.1.39
		static const IntTypeInfo typeInfo;
		
		IOPositionInfo():IntValueInfo(-1, typeInfo)
		{}
		
		IOPositionInfo(int i):IntValueInfo(i, typeInfo)
		{}
		
		IOPositionInfo(const std::string &s):IntValueInfo(s, typeInfo)
		{}
};

#endif /*IOPOSITIONINFO_H_*/
