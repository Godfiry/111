/********************************************************************
** Copyright (c) 2010, Beijing NMC Co.,Ltd.  product division.
** All rights reserved.
**
** File name: AlarmGetter.h
**
** Description:
**
** Modification history:
* 							2016.11.10		lvjw	created.
*********************************************************************/
#ifndef ALARMGETTER_H_
#define ALARMGETTER_H_

#include "CBase.h"
#include "BlockingAlarmEX.h"
#include "NonBlockingAlarmEX.h"

#define ALARM_PRE_PATH "/Control/Alarm/"

class AlarmGetter:virtual public CBase
{
public:
	AlarmGetter();
	virtual ~AlarmGetter();
	
public:
	static Alarm* getAlarm(std::string strAlarmResourceName , AlarmPoster* pPoster);
	static BlockingAlarmEX* getBlockingAlarmEX(std::string strAlarmResourceName , AlarmPoster* pPoster);
	static NonBlockingAlarmEX* getNonBlockingAlarmEX(std::string strAlarmResourceName , AlarmPoster* pPoster);
};

#endif /*ALARMGETTER_H_*/
