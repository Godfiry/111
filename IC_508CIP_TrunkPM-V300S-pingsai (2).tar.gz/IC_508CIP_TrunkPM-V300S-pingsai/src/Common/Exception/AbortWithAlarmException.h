/*************************************************************************************
** Copyright (c) 2007, Beijing NMC Co.Ltd.  All rights reserved.
** File name: 	AbortWithAlarmException.h
** Description: 
** Release: 		1.0
** Modification history:
** 					2008-3-27   WangYonggui create
**
*************************************************************************************/

#ifndef ABORTWITHALARMEXCEPTION_H_
#define ABORTWITHALARMEXCEPTION_H_

#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "AbortException.h"
#endif
#include "BlockingAlarm.h"
#ifdef IAP4_0
using namespace IAP;
using namespace IAP::ALARM;
#endif

class AbortWithAlarmException : public AbortException
{
	private:
		BlockingAlarm *m_alarm;
		
	public:
		AbortWithAlarmException();
		
		AbortWithAlarmException(const std::string &s);
		
		AbortWithAlarmException(const std::string &s, BlockingAlarm *alarm);
		
		//virtual ~AbortWithAlarmException();
		
		void setAlarm(BlockingAlarm *alarm);
		
		BlockingAlarm* getAlarm() const;
};

#endif /*ABORTWITHALARMEXCEPTION_H_*/
