/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MKSSingleMatch.h
** Description: This driver is used for MKS Single Match
*                RS232
* 				   BaudRate:38400
*                DataBit:8
*                StopBit:1
*                Parity:no
*
** Release: 1.1
** Modification history: 
** 					2009-11-18   LiJuanjuan create
**      
*********************************************************************/
#ifndef MKSSINGLEMATCH_H_
#define MKSSINGLEMATCH_H_

#include "MKSMatch.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#include "DescriptorList.h"
#include "StringTypeInfo.h"
#include <map>
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class MKSSingleMatch:public MKSMatch
{
	DECLARE_DYNAMIC(MKSSingleMatch)	
	DECLARE_MSG_MAP	

	private:
		typedef struct
		{
			int m_ps;
			std::string m_s1;
			int m_ps2;
		}Com;
		
		typedef std::pair<std::string,DescriptorList> ParamPair;
		
		static std::map<std::string,DescriptorList> m_params;
		static ParamPair m_paramPairs[];
		static Com m_commands[];	   
	
	protected:
		void initChs(DeviceNode<MKSSingleMatch> *node);
		void initDevice();
		
	public:
		MKSSingleMatch();
		virtual ~MKSSingleMatch();
		
		bool writeInt(int channelNum, int value, const IntTypeInfo &typeInfo);
		bool writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo);
		bool writeRawCommand(int channelNum, std::string value, const StringTypeInfo &typeInfo);
		bool readInt(int channelNum, int *value, const IntTypeInfo &typeInfo);
		bool readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo);		
		//added by liusy for checking Match0 fault word[20190806]		
		bool readString(int channelNum, std::string *pValue, const StringTypeInfo &typeInfo);
		
		void init();
};

#endif /*MKSSINGLEMATCH_H_*/
