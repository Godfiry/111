/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: ATSChiller.cpp
** Description:
** Release: 1.1
** Modification history:
** 					2021-12-03   wzd create
*********************************************************************/
#include "GmpowerLFMN6MatchDriver.h"
#include "CheckCalculationTool.h"
#include "DeviceManager.h"
#include "ObjectManager.h"
#include "Converter.h"

#include "ConfigException.h"
#include "Hex.h"
#include <sstream>
#include <stdio.h>
#include "Converter.h"
#include <sys/time.h>
#include <iostream>
#include <string.h>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;


#define RESPONSE_CMD_LENGTH      23
#define TIMEOUT                  20



GmpowerLFMN6MatchDriver::GmpowerLFMN6MatchDriver():SerialDevice(80, "")
{
	//the form of the read command 03
	m_readCmd[0] = 0x01;//controller address
	m_readCmd[1] = 0x03;//function read
	m_readCmd[2] = 0x00;//read starting at register high byte
	m_readCmd[3] = 0x00;//read starting at register low byte
	m_readCmd[4] = 0x00;//read number of consecutive register high (always 0)
	m_readCmd[5] = 0x01;//read number of consecutive register low
	m_readCmd[6] = 0x00;//Low byte of CRC
	m_readCmd[7] = 0x00;//High byte of CRC

	//the form of the write command 06
	m_writeCmd[0] = 0x01;//controller address
	m_writeCmd[1] = 0x06;//function multiple write
	m_writeCmd[2] = 0x00;//write starting at register High byte
	m_writeCmd[3] = 0x00;//write starting at register Low byte
	m_writeCmd[4] = 0x00;//data High byte of register write
	m_writeCmd[5] = 0x00;//data Low byte of register write
	m_writeCmd[6] = 0x00;//Low byte of CRC
	m_writeCmd[7] = 0x00;//High byte of CRC


}

GmpowerLFMN6MatchDriver::~GmpowerLFMN6MatchDriver()
{
}

bool GmpowerLFMN6MatchDriver::readInt(const int nChannelNum, int * pValue ,const IntTypeInfo& typeinfo)
{

    if( 1 == nChannelNum )
	{
		m_readCmd[3] = 0x00;
	}
	else if( 3 == nChannelNum )
	{
		m_readCmd[3] = 0x11;
	}
	else
	{
		m_readCmd[3] = 0x02;
	}

	

	unsigned short crc = CheckCalculationTool::GetCRC16Code( m_readCmd, sizeof(m_readCmd)-2 );
	m_readCmd[6] = (crc & 0xFF) & 0xFF;    // low byte of CRC
	m_readCmd[7] = (crc >> 8) & 0xFF;  //  high byte of CRC

	char response[RESPONSE_CMD_LENGTH];
	memset(response, 0, RESPONSE_CMD_LENGTH);
	sendCommandOnly(m_readCmd, sizeof(m_readCmd));
	if(getResultOnly(response,RESPONSE_CMD_LENGTH, TIMEOUT) < 0)
	{
		throw IOException(getDeviceName() + ": reading back times out");
	}
	

	if(response[0] == m_readCmd[0] && response[1] == 0x03)
	{
		if(response[2] == 0x02)
		{
			unsigned char  cByte[4];//save the 32-bite
			response[3] = response[3]&0x00ff;
			response[4] = response[4]&0x00ff;
			
			cByte[0] = response[3];
			cByte[1] = response[4];


			int t_val=0;
			switch (nChannelNum)
			{
			    case 1:
			    case 3:
			    {
				     t_val = (cByte[0] << 8) | cByte[1];
				     t_val = ((t_val - 4000) * 4) / 5;
				     *pValue = t_val / 10;
			    }
				break;

			    case 10:
			    {
				     t_val = cByte[0] & 0x0001 ;
					 t_val = (0 != t_val)?1:0;
				     * pValue = t_val;
			    }
				break;

			    case 11:
			    {
			         t_val = cByte[0] & 0x0002 ;
					 t_val = (0 != t_val)?1:0;
			         * pValue = t_val;
		        }
				break;

			   case 12:
			   {
			        t_val = cByte[0] & 0x0004 ;
					t_val = (0 != t_val)?1:0;
				    * pValue = t_val;
			   }
				break;

			   case 13:
			   {
			        t_val = cByte[0] & 0x0008 ;
					t_val = (0 != t_val)?1:0;
					* pValue = t_val;
			   }
				break;

			   case 15:
			   {
			      t_val = cByte[1] & 0x0001 ;
				  t_val = (0 != t_val)?1:0;
				  * pValue = t_val;
			   }
				break;

			   case 16:
			   {
			      t_val = cByte[1] & 0x0002 ;
				  t_val = (0 != t_val)?1:0;
				  * pValue = t_val;
			   }
				break;
			default: // impossible
	              * pValue = t_val;
				break;

			}
			return true;
		}
		else
		{
			throw IOException(getDeviceName() + ": reading data false, response is [" + Hex::GetHexString(response,10)+"]");
		}
	}
	else
	{
		throw IOException(getDeviceName() + ":the read data command is invalid, response is [" + Hex::GetHexString(response,10)+"]");
	}
}


//write Temperature
bool GmpowerLFMN6MatchDriver::writeInt(const int nChannelNum, const int nWriteValue, const IntTypeInfo& typeinfo)
{

	if( 2 == nChannelNum )
	{
		m_writeCmd[3] = 0x07;	
	}
	else if( 4 == nChannelNum )
	{
		m_writeCmd[3] = 0x11;
	} 
	else if( 5 == nChannelNum )
	{
		m_writeCmd[3] = 0x25;	
	} 
	else if(7 == nChannelNum)
	{
		m_writeCmd[3] = 0x0D;
	}
	else if(8 == nChannelNum)
	{
		m_writeCmd[3] = 0x0B;
	}
	else if( 9 == nChannelNum )
	{
		m_writeCmd[3] = 0x02;
	}
	
	unsigned char floatToHex[4];


	int nValue=nWriteValue;
	if ( 9 != nChannelNum)
	{
		nValue *= 10;
	}
	if(nChannelNum == 2  || nChannelNum == 4)
	{
		nValue = nValue * 1.25 + 4000;
	}

	char* pChar=(char*) & nValue;
    for(int i=0;i<sizeof(int);i++)
    {
		floatToHex[i]=*pChar;
		pChar++;
    }


	m_writeCmd[4] = floatToHex[1];
	m_writeCmd[5] = floatToHex[0];

	unsigned short crc = CheckCalculationTool::GetCRC16Code( m_writeCmd, sizeof(m_writeCmd)-2);
	m_writeCmd[6] = 0xff&(crc & 0xff);  // low byte of CRC
	m_writeCmd[7] = 0xff&( crc >> 8);    // high byte of CRC


	//if the write command failed, return error
	char response[RESPONSE_CMD_LENGTH];
	memset(response, 0, RESPONSE_CMD_LENGTH);
	sendCommandOnly(m_writeCmd, sizeof(m_writeCmd));
    //cout<<hex<<int(m_writeCmd[0])<<" "<<hex<<int(m_writeCmd[1])<<" "<<hex<<int(m_writeCmd[2])<<" "<<hex<<int(m_writeCmd[3])<<" "<<hex<<int(m_writeCmd[4])<<" "<<hex<<int(m_writeCmd[5])<<" "<<hex<<int(m_writeCmd[6])<<" "<<hex<<int(m_writeCmd[7])<<endl;
	if(getResultOnly(response,RESPONSE_CMD_LENGTH, TIMEOUT) < 0)
	{
		throw IOException(getDeviceName() + ": reading back times out");
	}
	//cout<<hex<<int(response[0])<<" "<<hex<<int(response[1])<<" "<<hex<<int(response[2])<<" "<<hex<<int(response[3])<<" "<<hex<<int(response[4])<<" "<<hex<<int(response[5])<<" "<<hex<<int(response[6])<<" "<<hex<<int(response[7])<<endl;
	//check the key bytes
	if(response[0] == m_writeCmd[0] && response[1] == m_writeCmd[1])
	{
		return true;
	}
	else
	{
		throw IOException("Chiller write command failed for unknown response [" + Hex::GetHexString(response,10)+"]");
	}

}


bool GmpowerLFMN6MatchDriver::readDouble(const int channelNum,double * value ,const DoubleTypeInfo& typeinfo)
{
	
	m_readCmd[3] = 0x2F;

	unsigned short crc = CheckCalculationTool::GetCRC16Code( m_readCmd, sizeof(m_readCmd)-2 );
	m_readCmd[6] = (crc & 0xFF) & 0xFF;    // low byte of CRC
	m_readCmd[7] = (crc >> 8) & 0xFF;  //  high byte of CRC

	char response[RESPONSE_CMD_LENGTH];
	memset(response, 0, RESPONSE_CMD_LENGTH);
	sendCommandOnly(m_readCmd, sizeof(m_readCmd));
	if(getResultOnly(response,RESPONSE_CMD_LENGTH, TIMEOUT) < 0)
	{
		throw IOException(getDeviceName() + ": reading back times out");
	}
		
	if(response[0]==0x01 && response[1]==0x03)
	{  			
  		//int dd= (int)response[3] * 128 + (int)response[4];
	    
	    unsigned char cByte[4];
	    int val;
	    response[3] = response[3]&0x00ff;
	    response[4] = response[4]&0x00ff;
	    cByte[0] = response[3];
	    cByte[1] = response[4];
	    int t_Val = (cByte[0] << 8) | cByte[1];
	    *value = (double)t_Val;

  	   // int nReadValue=(int)(response[3] <<8 | (response[4]&0x00FF));
  	    //*value = (double)nReadValue;
  	    if(*value<0)
  	    {
		   cout<<"GmpowerLFMN6MatchDriver read negative data"<<endl; 
	       *value = (double)t_Val;
  	    }
	    return true;
	}
	else
	{		
		throw IOException(getDeviceName() + ":the read data command is invalid");
	}
}



//register channel
void GmpowerLFMN6MatchDriver::initChs(DeviceNode<GmpowerLFMN6MatchDriver> *node)
{
	node->registerReadCh(1, &GmpowerLFMN6MatchDriver::readInt);
	node->registerWriteCh(2,&GmpowerLFMN6MatchDriver::writeInt);
	node->registerReadCh(3, &GmpowerLFMN6MatchDriver::readInt);
	node->registerWriteCh(4,&GmpowerLFMN6MatchDriver::writeInt);
	node->registerWriteCh(5,&GmpowerLFMN6MatchDriver::writeInt);
	node->registerReadCh(6, &GmpowerLFMN6MatchDriver::readDouble);
	node->registerWriteCh(7,&GmpowerLFMN6MatchDriver::writeInt);
	node->registerWriteCh(8,&GmpowerLFMN6MatchDriver::writeInt);
	node->registerWriteCh(9,&GmpowerLFMN6MatchDriver::writeInt);
	node->registerReadCh(10,&GmpowerLFMN6MatchDriver::readInt);
	node->registerReadCh(11,&GmpowerLFMN6MatchDriver::readInt);
	node->registerReadCh(12,&GmpowerLFMN6MatchDriver::readInt);
	node->registerReadCh(13,&GmpowerLFMN6MatchDriver::readInt);
	node->registerReadCh(14,&GmpowerLFMN6MatchDriver::readInt);
	node->registerReadCh(15,&GmpowerLFMN6MatchDriver::readInt);
	node->registerReadCh(16,&GmpowerLFMN6MatchDriver::readInt);

}


void GmpowerLFMN6MatchDriver::initDevice()
{
	cout<<"Start Scan GmpowerLFMN6MatchDriver...."<<endl;

	int nTemp;
	try
	{
		readInt(1,&nTemp,IntTypeInfo());
	}
	catch(exception &ex)
	{
		cout<<"Scan GmpowerLFMN6MatchDriver failed. Communication abnormal!"<<endl;
		return;
	}
	cout<<"Scan GmpowerLFMN6MatchDriver Successfully...."<<endl;
}
//init device
void GmpowerLFMN6MatchDriver::init()
{
	DeviceNode<GmpowerLFMN6MatchDriver> *node = new DeviceNode<GmpowerLFMN6MatchDriver>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	if(!isSimulated())
	{
		initChs(node);
		initDevice();
	}
}

string GmpowerLFMN6MatchDriver::getDeviceName()
{
	return __FILE__;
}

IMPLEMENT_DYNAMIC(GmpowerLFMN6MatchDriver, SerialDevice)

BEGIN_MSG_MAP(GmpowerLFMN6MatchDriver, SerialDevice)
	SET_V( init, GmpowerLFMN6MatchDriver)
END_MSG_MAP
