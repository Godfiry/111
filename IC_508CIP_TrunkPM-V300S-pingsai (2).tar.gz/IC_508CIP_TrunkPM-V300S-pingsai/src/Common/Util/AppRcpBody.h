/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AppRcpBody.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-8-4   LiJuanjuan create
**      
*********************************************************************/
#ifndef APPRCPBODY_H_
#define APPRCPBODY_H_

#include "ExecRcpHandler.h"
#include "AppRcpStep.h"
#ifdef IAP4_0
using namespace IAP::RECIPE;
#endif

class AppRcpBody
{
	protected:
		std::vector<AppRcpStep> m_steps;
		std::string m_rcpName;
		std::string m_rcpClass;
	
	public:
		AppRcpBody();
		virtual ~AppRcpBody();
		
        //added by taohao[v1.5.0_HotFix] for obtain the recipe from the memory
        AppRcpBody(const AppRcpBody &rcpBody);
        AppRcpBody& operator=(const AppRcpBody &rcpBody);
		virtual void clear();
		virtual void makeBody(const ExecRcpHandler &rcpHandler);
		virtual AppRcpStep getStep(int index)const;
		virtual int getStepSize()const;
		std::string getRcpName()const;
		std::string getRcpClass()const;
		bool isEmpty()const;
		virtual double getLeftProcessTime(int step)const;

		virtual void addStep(const ExecRcpHandler &rcpHandler, int nStepInRecipe,int nAddStepNum);  //add by wzd 1.1.21
		virtual int getRcpAllStepNum()const;//added by taohao[1.1.48]
};

#endif /*APPRCPBODY_H_*/
