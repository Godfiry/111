#include "CheckItem.h"
#include "GuadAction.h"
#include "StrTool.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "AbortException.h"
#include "InvalidNameException.h"
#endif
#include "SysLogger.h"
#include "ConfigException.h"
#include "ObjectManager.h"

#include "Recovery.h"
#include "UTime.h"
#include "Converter.h"
#include "AlarmReNameManager.h"
#include "StrManager.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP;
using namespace IAP::CORE;
using namespace IAP::ALARM;
using namespace IAP::IO;
using namespace IAP::CONDITION;
#endif

using namespace std;

CheckItem::CheckItem()
{
	m_triggeredTimeMS = 0;
	m_alarmMessage = "";
	m_strTriggerIODescription = "";
	m_pTriggerAlarm = NULL;
	m_trigger = NULL;
	m_enable = NULL;
	m_durativeTimeS = NULL;//ms	
	m_checkDelayS = NULL;//ms
	m_startTimeMS = 0;
	m_bEnableAtStart = true;
	m_bEnableIOValidity = true;
	m_alarmSeverity = Alarm::ERROR;
	 
	m_sEnable = new Enable();
	m_sEnable->setOwner(this);
	m_sDisable = new Disable();
	m_sDisable->setOwner(this);

	m_strTimeoutInfo = "";
	m_strAlarmDescription = "";
	m_postAlarm = true;//added by guojin[1.1.53]
	m_dTempCheckDelayTimeS = 0;
}

CheckItem::~CheckItem()
{
}

void CheckItem::Enable::execute()
{
	ControlObject *owner = getOwner();
	if (owner != NULL)
	{
		try
		{
			static_cast<CheckItem*>(owner)->do_Enable();
		}
		catch(const AbortException &ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": Enable service was aborted for:" + string(ex.what()));				
			throw;
		}
		catch(const exception &ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": Enable service has error for:" + string(ex.what()));							
			throw;
		}				
	}		
}

void CheckItem::Disable::execute()
{
	ControlObject *owner = getOwner();
	if (owner != NULL)
	{
		try
		{
			static_cast<CheckItem*>(owner)->do_Disable();
		}
		catch(const AbortException &ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": Disable service was aborted for:" + string(ex.what()));				
			throw;
		}
		catch(const exception &ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": Disable service has error for:" + string(ex.what()));							
			throw;
		}				
	}		
}

void CheckItem::call_Enable()
{
	call(m_sEnable);
}

void CheckItem::call_Disable()
{
	call(m_sDisable);
}

void CheckItem::do_Enable()
{
	IMutexLocker locker(&m_lock);
	m_enable->setValue(1);
}

void CheckItem::do_Disable()
{
	IMutexLocker locker(&m_lock);
	m_enable->setValue(0);
}

bool CheckItem::check()
{
	IMutexLocker locker(&m_lock);
	if(isEnabled())//Enabled
	{
		return doCheck();
	}
	else
	{
		return false;
	}
}
	
bool CheckItem::isEnabled()const
{
	return m_enable->getValue() == 1;
}
	
bool CheckItem::isTriggered()
{
	return m_trigger->judge() == 1;// || m_trigger->judge() == 2;
}

bool CheckItem::checkTriggered()
{
	if(isTriggered())
	{
		recordAbnormalData();
		return true;
	}
	else
	{
		clearAbnormalData();
		m_triggeredTimeMS = 0;
		return false;
	}
}


	
bool CheckItem::checkDuration()
{
	long t_durativeTimeMS = getDurativeTimeMS();

	if(t_durativeTimeMS > 0)
	{
		if(m_triggeredTimeMS == 0)
		{
			m_triggeredTimeMS = UTime::getCurrentTimeAsMSeconds();
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + ": checkDuration set m_triggeredTimeMS");	
			return false;
		}
		else
		{
			if((UTime::getCurrentTimeAsMSeconds() - m_triggeredTimeMS) < t_durativeTimeMS )
			{
				return false;
			}
			else
			{
				//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + ": checkDuration return true - Duration is "+Converter::convertToString(t_durativeTimeMS));	
				//m_triggeredTimeMS = 0;
				return true;				
			}
		}
	}
	else	
	{
		//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + ": checkDuration return true for Duration is zero");	
		return true;
	}
}

bool CheckItem::checkDelay()
{
	long t_checkDelayMS = getCheckDelayMS();
	if(t_checkDelayMS > 0)
	{
		if((UTime::getCurrentTimeAsMSeconds() - m_startTimeMS) < t_checkDelayMS)
		{
			return false;
		}
		else
		{
			//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + ": checkDelay return true - delay is "+Converter::convertToString(t_checkDelayMS));	
			return true;
		}
	}
	else
	{
		return true;
	}
}
	
bool CheckItem::isIOValidity()
{
	m_strTriggerIODescription = "";
	//check if enable the check of IO validity
	if(!m_bEnableIOValidity)
	{
		return true;
	}
	
	for(int nCount = 0;nCount < m_vTriggerIO.size();nCount++)
	{
		if(m_vTriggerIO.at(nCount)->getValidity() == IO::INVALID||m_vTriggerIO.at(nCount)->getValidity() == IO::OFFLINE)
		{
			m_strTriggerIODescription = m_strTriggerIODescription + m_vTriggerIO.at(nCount)->getName() + " ";
		}
	}
	if(m_strTriggerIODescription!="")
	{
		m_strTriggerIODescription = m_strTriggerIODescription + "have IO exception!";
		return false;
	}
	return true; //validity	
}
	
void CheckItem::executeSafeAction()
{
	for(unsigned int i=0; i<m_actions.size(); ++i)
	{
		m_actions[i]->execute(m_trigger);
	}	
}

bool CheckItem::doCheck()//true is trigger, false is not
{
	if(!m_pTriggerAlarm->isPosted())
	{
		if(checkDelay() && checkTriggered() && checkDuration())
		{
			if(m_strTriggerIODescription!="")
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": "+m_strTriggerIODescription);
				m_pTriggerAlarm->setDescription(m_strAlarmDescription+". Detail reason is IO channel invalid");
				m_strTriggerIODescription = "";
			}
			else
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": is triggered:");

				m_pTriggerAlarm->setDescription(updateAlarmMessageWithRecordData());
			}
			//added by guojin[1.1.53]
			if(m_postAlarm)//if not post, trigger safe action and no alarm
            {
            	m_pTriggerAlarm->post(this);
            }
			executeSafeAction();
			return true;
		}
		else
		{
			return false;
		}
	}
	else
	{
		//lvjw need check Trigger and do safety action.20210706

		return true;
	}
}
	
void CheckItem::make()
{
	ControlObject::make();
	m_enable = new ReadWriteInt(getName() + "/EnableCh",IntTypeInfo(DescriptorList("Disable,Enable")));
	m_enable->setValue((int)m_bEnableAtStart);
	bulidAlarm();
}

void CheckItem::bulidAlarm()
{
	string strPreName = getName();
	int nPos = strPreName.find(getSelfName());
	if(nPos != string::npos)
	{
		strPreName = strPreName.substr(0,nPos);
	}
	strPreName = AlarmReNameManager::getInstance()->GetShowName(strPreName);

	if(m_strAlarmDescription == "")
	{
		m_strAlarmDescription = m_alarmMessage;
	}

	m_pTriggerAlarm = new NonBlockingAlarm(strPreName+ "_" +getSelfName(), m_alarmMessage, m_strAlarmDescription, m_alarmSeverity);
	m_pTriggerAlarm->addRecovery(new Recovery("Clear", Recovery::CLEAR));
}

void CheckItem::configTrigger()
{
}

void CheckItem::activateTrigger()
{
	if(m_trigger != NULL)
	{
		m_trigger->activate();
	}
}

void CheckItem::deactivateTrigger()
{
	if(m_trigger != NULL)
	{
		m_trigger->deactivate();
	}	
}

void CheckItem::start()
{
/*	if(isEnabled())
	{*/
		configTrigger();
		m_trigger->activate();
		m_startTimeMS = UTime::getCurrentTimeAsMSeconds();		
		m_triggeredTimeMS = 0;
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + ": started ");
/*	}*/
}

void CheckItem::stop()
{
	if(/*isEnabled() &&*/ (m_trigger != NULL))
	{	
		m_trigger->deactivate();
		m_startTimeMS = 0;
		m_triggeredTimeMS = 0;
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + ": stopped ");	
	}
}

long CheckItem::getDurativeTimeMS()const
{
	if(m_durativeTimeS != NULL)
	{
		return (long)(m_durativeTimeS->getValue() * 1000);
	}	
	else
	{
		return 0;
	}	
}
		
long CheckItem::getCheckDelayMS()const
{
	if(m_dTempCheckDelayTimeS > 0.1)
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + ": checkDelay get TempCheckDelayTime - delay is "+Converter::convertToString(m_dTempCheckDelayTimeS));
		return (long)(m_dTempCheckDelayTimeS * 1000);
	}
	if(m_checkDelayS != NULL)
	{
		return (long)(m_checkDelayS->getValue() * 1000);
	}
	else
	{
		return 0;
	}
}

AppConditionPtr CheckItem::getTrigger()const
{
	return m_trigger;
}

string CheckItem::getAlarmDescription()const
{
	return m_strAlarmDescription;
}

string CheckItem::getAlarmMessage()const
{
	return m_alarmMessage;
}

std::string CheckItem::getTimeoutInfo()const
{
	if(m_durativeTimeS != NULL)
	{
		return "Time out :Setup ["+SetupTool::getInstance()->getNameOfParameter(m_durativeTimeS->getName())+"] is "+Converter::convertToString(m_durativeTimeS->getValue());
	}
	else
	{
		return "";
	}
}

void CheckItem::setAlarmDescription(string strDescription)
{
	m_strAlarmDescription = strDescription;
}

void CheckItem::setTrigger(AppConditionPtr trigger)
{
	m_trigger = trigger;
}

void CheckItem::setTriggerCondition(const std::string &strConditionPath)
{
	m_trigger = StrTool::stringToCondition(strConditionPath);
	//add All IOString to TriggerIO
	setAllTriggerIO(strConditionPath);
}

//added by liusy[20191104]
void CheckItem::setAllTriggerIO(const std::string &strConditionPath)
{
	string strIOResults = StrTool::getIOStringFromCondition(strConditionPath);
	vector<string> vIOResults = StrTool::split(strIOResults,"+");
	for(int nCount = 0; nCount<vIOResults.size();nCount++)
	{
		setTriggerIO(vIOResults.at(nCount));
	}
}

//added by liusy[20191104]
void CheckItem::setTriggerIO(const std::string &strPath)
{
	ManagedObject *pObj = NULL;
	try
	{
		pObj = ObjectManager::getInstance()->getObject(strPath);
	}
	catch(const InvalidNameException &e)
	{
		string strError=getName()+" make path err. Path not exist. ";
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, strError);	
		throw ConfigException(strError);
	}
	UntypedData * pCh = dynamic_cast<UntypedData*>(pObj);
	if(NULL == pCh)
	{
		string strError = getName()+" make data type err. The Data( "+strPath +" ) is not a UntypedData";
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, strError);	
		throw ConfigException(strError);
	}
	m_vTriggerIO.push_back(pCh);
}

void CheckItem::addAction(const std::string &path)
{
	ManagedObject *t_obj = NULL;
	try
	{
		t_obj = ObjectManager::getInstance()->getObject(this, path);
	}
	catch(const InvalidNameException &ex)
	{
		t_obj = ObjectManager::getInstance()->getObject(path);
	}
	GuadAction *t_obj2 = dynamic_cast<GuadAction*>(t_obj);
	if(NULL == t_obj2)
	{
		string error = "the object under path '" + path + "' is not a GuadAction";
		throw ConfigException(error);
	}
	t_obj2->setIntlkName(getSelfName());
	m_actions.push_back(t_obj2);		
}
		
void CheckItem::setDurativeTimeS(double time)
{
	if(m_durativeTimeS == NULL)
	{
		m_durativeTimeS = new ReadWriteDouble(getName()+"/DurativeTime", DoubleTypeInfo());
	}
	else
	{
		ObjectManager::getInstance()->createAlias(m_durativeTimeS->getName(), getName()+"/DurativeTime");
	}
	m_durativeTimeS->setValue(time);
}

void CheckItem::setDurativeTimeSCh(const std::string &path)
{
	ManagedObject *t_obj = NULL;
	try
	{
		t_obj = ObjectManager::getInstance()->getObject(this, path);
	}
	catch(const InvalidNameException &ex)
	{
		t_obj = ObjectManager::getInstance()->getObject(path);
	}
	ReadWriteDouble *t_obj2 = dynamic_cast<ReadWriteDouble*>(t_obj);
	if(NULL == t_obj2)
	{
		string error = "the object under path '" + path + "' is not a ReadWriteDouble";
		throw ConfigException(error);
	}
	m_durativeTimeS = t_obj2;
}

void CheckItem::setAlarmMessage(const std::string &message)
{
	m_alarmMessage = message;
}

void CheckItem::setAlarmMessageID(int nMessageID)//add for code merging
{
	m_alarmMessage = StrManager::getInstance()->GetString(nMessageID);
}

void CheckItem::setTempCheckDelaytimeS(double time)
{
	m_dTempCheckDelayTimeS = time;
}

void CheckItem::setCheckDelayS(double time)
{
	if(m_checkDelayS == NULL)
	{
		m_checkDelayS = new ReadWriteDouble(getName()+"/CheckDelay", DoubleTypeInfo());
	}
	else
	{
		ObjectManager::getInstance()->createAlias(m_checkDelayS->getName(), getName()+"/CheckDelay");
	}
	m_checkDelayS->setValue(time);	
}

		
void CheckItem::setCheckDelaySCh(const std::string &path)
{
	ManagedObject *t_obj = NULL;
	try
	{
		t_obj = ObjectManager::getInstance()->getObject(this, path);
	}
	catch(const InvalidNameException &ex)
	{
		t_obj = ObjectManager::getInstance()->getObject(path);
	}
	ReadWriteDouble *t_obj2 = dynamic_cast<ReadWriteDouble*>(t_obj);
	if(NULL == t_obj2)
	{
		string error = "the object under path '" + path + "' is not a ReadWriteDouble";
		throw ConfigException(error);
	}
	m_checkDelayS = t_obj2;	
}

void CheckItem::setEnableAtStart(bool bFlag)
{
	m_bEnableAtStart = bFlag;
}

void CheckItem::setAlarmSeverity(int severity)
{
	m_alarmSeverity = (Alarm::Severity)severity;
}

void CheckItem::setEnableIOValidity(bool bFlag)
{
	m_bEnableIOValidity = bFlag;
}

void CheckItem::recordAbnormalData()
{

}

void CheckItem::clearAbnormalData()
{

}

std::string CheckItem::updateAlarmMessageWithRecordData()
{
	return m_strAlarmDescription;
}
void CheckItem::setPostAlarm(bool post)//added by guojin[1.1.53]
{
    m_postAlarm = post;
}
IMPLEMENT_DYNAMIC_SERVICE(Enable, CheckItem)
IMPLEMENT_DYNAMIC_SERVICE(Disable, CheckItem)

BEGIN_SERVICEINFO_LIST(CheckItem)
	ADD_SERVICE_INFO(CheckItem, Enable, enable this check item )
	ADD_SERVICE_INFO(CheckItem, Disable, disable this check item)
END_SERVICEINFO_LIST(CheckItem)

IMPLEMENT_DYNAMIC(CheckItem, ControlObject)

BEGIN_MSG_MAP( CheckItem, ControlObject)
	SET_S(setTriggerCondition, CheckItem)
	SET_S(addAction, CheckItem)
	SET_D(setDurativeTimeS, CheckItem)	
	SET_S(setAlarmMessage, CheckItem)
	SET_I(setAlarmMessageID, CheckItem)
	SET_S(setAlarmDescription,CheckItem)
	SET_S(setDurativeTimeSCh, CheckItem)	
	SET_S(setCheckDelaySCh, CheckItem)
	SET_D(setCheckDelayS, CheckItem)
	SET_B(setEnableAtStart, CheckItem)
	SET_B(setEnableIOValidity, CheckItem)
	SET_I(setAlarmSeverity, CheckItem)
	SET_B(setPostAlarm, CheckItem )//added by guojin[1.1.53]
END_MSG_MAP

