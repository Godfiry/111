/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TCPConnection.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-7-30   LiJuanjuan create
**      
*********************************************************************/
#ifndef TCPCONNECTION_H_
#define TCPCONNECTION_H_

#include <string>
#include "IThread.h"
#include "IMutex.h"
#include <unistd.h>  //add by wzd 1.1.39
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

class TCPDevice;
class TCPSocket;

class TCPConnection:public IThread
{
	private:
		class ReconnectMonitor:public IThread
		{
			private:
				TCPConnection *m_connection;
				
			public:
				ReconnectMonitor(TCPConnection *owner);

				virtual void run();
		};
	
	
	private:
		static const int s_CLOSED = 0;
		static const int s_CONNECTED = 1;
		static const int s_CONNECTING = 2;
		static const int s_CLOSING = 3;
		static const int s_ERROR = 4;		
		TCPSocket *m_socket;
		TCPDevice *m_device;
		int m_state;
		bool m_running;		
		int m_timeout;
		IMutex m_lock;
		ReconnectMonitor *m_reconnectMonitor;
				
		void changeState(int newstat);
		void reconnect();
		void reconnectSocket();
		void reconnectDevice();
		void close();	
	
	public:
		TCPConnection(const std::string &server, std::string port);
		virtual ~TCPConnection();		
		
		void connect();
		void disconnect();
		void setDevice(TCPDevice *device);
		void sendData(const char *data, int size);
		bool isConnected()const;
		virtual void run();
		bool recvFixLenData(char *buffer, int len);
		bool recvData(char *buffer, int len);
		void setTimeOut(int timeout);		
};

#endif /*TCPCONNECTION_H_*/
