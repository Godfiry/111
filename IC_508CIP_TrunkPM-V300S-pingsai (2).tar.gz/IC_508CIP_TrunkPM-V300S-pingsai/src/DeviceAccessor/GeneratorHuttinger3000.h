/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: GeneratorHuttinger3000.h
** Description:
** Release: 1.1
** Modification history:
**                     2022-10   weizd create
**
*********************************************************************/
#ifndef GENERATORHUTTINGER3000_H_
#define GENERATORHUTTINGER3000_H_
#include "SerialDevice.h"
#include "DeviceNode.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class GeneratorHuttinger3000 : public SerialDevice
{
    DECLARE_DYNAMIC(GeneratorHuttinger3000)
    DECLARE_MSG_MAP

private:
    typedef struct
    {
        unsigned char m_cmdLO;
        unsigned char m_cmdHI;
    }Com;
    static Com m_commands[];
    static const int RESP_LEN = 80;
    static const int MESS_LEN = 80;

    int m_timeOut;
    int m_resLen;

    char m_writeCmd[50];    //write command array
    char m_readCmd[50];   //read command array

    char m_message[MESS_LEN];
    char m_resp[RESP_LEN];
    char m_ack[1];
    bool sendCommand(char *msg,char *response, int l_msg_timeout,int length);
    //bool sendCommandAck(char *msg, char *response, int msg_timeout,int resplen, int msglen);
    bool readCommand(char *msg, char *response, int msg_timeout,int resplen, int msglen);

public:
    GeneratorHuttinger3000();
    virtual ~GeneratorHuttinger3000();
    void init();
    void InitChannels(DeviceNode<GeneratorHuttinger3000> *node);
    bool writeInt(int channel,int value,const IntTypeInfo& typeinfo);
    bool setLoadForwordMode(int channel,int value,const IntTypeInfo& typeinfo);//added by taohao[1.3.0]
    bool writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo);
    bool getcontrol(int channel,int value,const IntTypeInfo& typeinfo);
    bool readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo);
    bool readInt(int channelNum,int *value, const IntTypeInfo &typeInfo);//[zhangcx v1.1.48]
};
#endif /*GENERATORHUTTINGER3000_H_*/
