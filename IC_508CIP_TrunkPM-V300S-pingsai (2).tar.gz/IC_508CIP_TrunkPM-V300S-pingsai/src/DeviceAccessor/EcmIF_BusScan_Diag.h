/**************************************************************************************
 Copyright (c) Hilscher Gesellschaft fuer Systemautomation mbH. All Rights Reserved.
***************************************************************************************
$Id: EcmIF_BusScan_Diag.h 58634 2016-01-15 09:45:03Z Sven $:


Changes:
 Date          Description
 -----------------------------------------------------------------------------------
 yyyy-mm-dd    created
**************************************************************************************/

#ifndef __ECM_BUS_SCAN_INFO_T__
#define __ECM_BUS_SCAN_INFO_T__

/* this structure is deliberately compatible with ECM v3.x */

typedef __PACKED_PRE struct ETHERCAT_MASTER_BUS_SCAN_INFO_Ttag
{
  uint32_t ulVendorId;
  uint32_t ulProductCode;
  uint32_t ulRevisionNumber;
  uint32_t ulSerialNumber;
  uint32_t ulPortState;
} __PACKED_POST ETHERCAT_MASTER_BUS_SCAN_INFO_T;

#endif
