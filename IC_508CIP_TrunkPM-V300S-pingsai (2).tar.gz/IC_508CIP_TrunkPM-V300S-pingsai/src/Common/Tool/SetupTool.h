/********************************************************************
** Copyright (c) 2019, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: SetupTool.h
** Description:
** Created on: Jan 9, 2019
** Author: mujy
** Modification history:
**						[V1.0.0.2] create
**
*********************************************************************/

#ifndef SETUPTOOL_H_
#define SETUPTOOL_H_

#include "SetupRepository.h"
#include "ControlObjectEX.h"
#include "Service.h"
#include "Parameter.h"
#include <string>
#ifdef IAP4_0
using namespace IAP::SETUP;
using namespace IAP::CONTROL;
using namespace IAP::RECIPE;
#endif

using namespace std;
class SetupTool :public ControlObjectEX
{
	DECLARE_DYNAMIC(SetupTool)
	DECLARE_MSG_MAP
	DECLARE_SERVICEINFO_LIST

	public:
		class PrintAll : public Service
		{
			DECLARE_DYNAMIC_SERVICE(PrintAll)

			public:
				void execute();
		};

		class SavePreservedValue : public Service
		{
			DECLARE_DYNAMIC_SERVICE(SavePreservedValue)

			public:
				void execute();
		};
	public:
		SetupTool();
		virtual ~SetupTool();

		static SetupTool *getInstance();

	public://override
		virtual void make();

	public:
		void call_PrintAll();
		virtual void do_PrintAll();

		void call_SavePreservedValue();
		void do_SavePreservedValue();

		string getNameOfParameter(string strDataObjName);
	protected:
		string getRangeInfo(const Parameter* pParam);
		string getUnitInfo(const Parameter* pParam);
		string getDefaultValueInfo(const Parameter* pParam);

	private:
		ServicePtr<PrintAll> m_PrintAll;
		ServicePtr<SavePreservedValue> m_SavePreservedValue;

		map<string,string> mapSetupParam;
	private:
		static SetupTool * m_pInstance;
};

#endif /* SETUPMANAGERTOOL_H_ */
