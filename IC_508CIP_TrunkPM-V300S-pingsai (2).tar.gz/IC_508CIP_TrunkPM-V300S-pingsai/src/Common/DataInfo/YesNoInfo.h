/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					Jan 22, 2008  shenql  create 
**      
***************************************************************************/
#ifndef YESNOINFO_H_
#define YESNOINFO_H_
#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class YesNoInfo : public IntValueInfo
{
public:
		
		static const int UnInit = -1;
		static const int NO = 0;
		static const int YES = 1;
		static const IntTypeInfo typeInfo;

	   YesNoInfo():IntValueInfo(-1, typeInfo)
	   {
	   }
	
	   YesNoInfo(int i):IntValueInfo(i, typeInfo)
	    {
	    }
	
	   YesNoInfo(std::string s):IntValueInfo(s, typeInfo)
	    {
	    }
};


#endif /*YESNOINFO_H_*/
