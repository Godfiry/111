/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					Feb 22, 2008  shenql  create 
* 					2010-01-18 lijj modified
**      
***************************************************************************/
#ifndef COUNTERTIMER_H_
#define COUNTERTIMER_H_

#include "TimerSubscriber.h"
#include "ReadWriteDouble.h"
#include "IntTypeInfo.h"
#include "Timer.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
#endif

class CounterTimer : public TimerSubscriber
{
	private:
		double m_periodInSeconds;
		int m_counterType;
		ReadWriteDouble *m_timerItem;
		IntTypeInfo m_typeInfo;
		static const int Up = 0;
		static const int Down = 1;	
		#ifdef IAP4_0
		IAP::CORE::TimerPtr m_myTimer;
		#else
		Timer *m_myTimer;
		#endif
		bool m_running;
		long m_startTime;
		double m_initialTime;
	 
	private:
		CounterTimer(const CounterTimer& pObj); //modified by chenw [1.6.0_RC02]

		CounterTimer& operator=(const CounterTimer& pObj);

	public:
		CounterTimer();

		~CounterTimer();

		CounterTimer(ReadWriteDouble *data, int counterType, double period);
		
		void setCounterType(int i);
		
		void setCounterType(std::string s);
		
		void setPeriod(double d);//seconds
		
		void setTimerItem(ReadWriteDouble* data);
		
		void start();
		
		void stop();
		
		#ifdef IAP4_0
		void updateFromTimer(const Timer * const timer);
		#else
		void updateFromTimer();
		#endif
};

#endif /*COUNTERTIMER_H_*/
