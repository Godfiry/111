#include "CBase.h"
#include <stdarg.h>
#include <iostream>
#include "StrManager.h"

using namespace std;

CBase::CBase()
{
}

CBase::~CBase()
{
}

void CBase::Log_Info(const std::string &strMsg)
{
	if(DisplayLog)
	{
		cout<<strMsg<<endl;
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, strMsg);
}

void CBase::Log_Error(const std::string &strMsg)
{
	if(DisplayLog)
	{
		cout<<strMsg<<endl;
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, strMsg);
}

void CBase::Log_Debug(const std::string &strMsg)
{
	if(DisplayLog)
	{
		cout<<strMsg<<endl;
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::FATAL, strMsg);
}

void CBase::Log_Show(const std::string &strMsg,bool nPrintTime)
{
	if(nPrintTime)
	{
		#ifdef IAP4_0
		cout<<ITime::getCurrentTimeAsStr()<<":"<<strMsg<<endl;
		#else
		cout<<Time::getCurrentTimeAsStr()<<":"<<strMsg<<endl;
		#endif
	}
	else
	{
		cout<<strMsg<<endl;
	}
}


void CBase::Log_Info(const char * pMsg , ...)
{
	char pLogStr[2048]={0};
	va_list args;
	va_start(args,pMsg);
	int n =vsprintf(pLogStr,pMsg,args);
	va_end(args);
	if(n>2048)
	{
		throw "CBase log err: string too long!";
	}
	std::string strLogStr=pLogStr;
	Log_Info(strLogStr);
}
void CBase::Log_Error(const char * pMsg , ...)
{
	char pLogStr[2048]={0};
	va_list args;
	va_start(args,pMsg);
	int n =vsprintf(pLogStr,pMsg,args);
	va_end(args);
	if(n>2048)
	{
		throw "CBase log err: string too long!";
	}
	std::string strLogStr=pLogStr;
	Log_Error(strLogStr);
}
void CBase::Log_Debug(const char * pMsg , ...)
{
	char pLogStr[2048]={0};
	va_list args;
	va_start(args,pMsg);
	int n =vsprintf(pLogStr,pMsg,args);
	va_end(args);
	if(n>2048)
	{
		throw "CBase log err: string too long!";
	}
	std::string strLogStr=pLogStr;
	Log_Debug(strLogStr);
}
	
/*void CBase::Log(LEVEL::Level l, const std::string &msg)
{
	#ifdef IAP4_0
	string logMsg=ITime::getCurrentTimeAsStr()+":"+msg;
	#else
	string logMsg=Time::getCurrentTimeAsStr()+":"+msg;
	#endif
	if(DisplayLog)
	{
		cout <<logMsg<<endl;
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, l, logMsg);
}

void CBase::Log(LEVEL::Level l,const char * pMsg, ...)
{
	char pLogStr[2048]={0};
	va_list args;
	va_start(args,pMsg);
	int n =vsprintf(pLogStr,pMsg,args);
	va_end(args);
	if(n>2048)
	{
		throw "CBase log err: string too long!";
	}
	
	std::string strLogStr=pLogStr;
	if(DisplayLog)
	{
		cout <<strLogStr<<endl;
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, l, strLogStr);
}*/

string CBase::str(int nID)
{
	return StrManager::getInstance()->GetString(nID);
}
