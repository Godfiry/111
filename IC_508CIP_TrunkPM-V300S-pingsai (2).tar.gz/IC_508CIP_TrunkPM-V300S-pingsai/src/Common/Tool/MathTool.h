#ifndef MATHTOOL_H_
#define MATHTOOL_H_

#include <math.h>
#include <vector>//added by liusy[1.1.39]
#include <string>
using namespace std;

class MathTool
{
public:
	static double Round(double dSrc ,double dAccuracy);
	//added by liusy[1.1.39]
	static void LinearFunc(double x1, double y1, double x2, double y2, double &k ,double &b);
	static void PiecewiseFunc(string X,string Y,  string &K,string &B, const string &strSeparator);
	static int getPiecewiseIndex(const double &dValue, const vector<double> &source);
	static bool isTempMeetThreshold(double dRcpTemp, double dReadTemp, double dThreshold, double &dpLower, double &dHigh);//added by zhangpf[1.8.2]
	static bool isTempStableThreshold(double dLastTemp, double dReadTemp, double dThreshold, bool bIsTempUp);//added by zhangpf[1.8.2]
    static float createRandomValue(double dMin,double dMax);//added by mujy [1.11.0] for data random change
};

#endif /*MATHTOOL_H_*/
