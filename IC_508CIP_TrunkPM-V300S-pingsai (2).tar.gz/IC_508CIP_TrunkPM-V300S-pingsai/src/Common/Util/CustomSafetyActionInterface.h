/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					2011-10-20  lijj  create 
**      
***************************************************************************/
#ifndef CUSTOMSAFETYACTIONINTERFACE_H_
#define CUSTOMSAFETYACTIONINTERFACE_H_

#include "OverrunInterlock.h"
#ifdef IAP4_0
using namespace IAP::INTERLOCK;
#endif

class CustomSafetyActionInterface
{
	public:
		CustomSafetyActionInterface(){}
		virtual ~CustomSafetyActionInterface(){}
		
		virtual void execute(OverrunInterlock *overrunInterlock) = 0;
};

#endif /*CUSTOMSAFETYACTIONINTERFACE_H_*/
