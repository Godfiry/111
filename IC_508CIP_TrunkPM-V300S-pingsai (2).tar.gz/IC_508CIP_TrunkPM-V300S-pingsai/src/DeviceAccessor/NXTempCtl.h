/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: NXTempCtl.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2013-12-31   bihuijie create
**      
*********************************************************************/

#ifndef NXTEMPCTL_H_
#define NXTEMPCTL_H_
#include "DeviceNode.h"
#include "SerialDevice.h"
#include "MonitorDoubleValue.h"   //add by wzd 1.5.0 for NXTempCtl Protect CIP
#ifdef IAP4_0
using namespace IAP::IO;
#endif

#define MONITORDOUBLEVALUEADDMAP 500



class NXTempCtl:public SerialDevice,public CMonitorDoubleValue
{
	DECLARE_DYNAMIC(NXTempCtl)	
	DECLARE_MSG_MAP
	
private:
	static const int MAX_MESSAGE_LEN = 20;
	static const int MIN_RECEIVEMSG_LEN = 20;
	int m_pollPeriod;		
	
protected:

	void initChs(DeviceNode<NXTempCtl> *node);
	void initDevice();
	
public:
	NXTempCtl();
	virtual ~NXTempCtl();
	 char writeArray[8];	
	 char readArray[8];
	static const int RESP_LEN = 80;
	void init();  
	bool writeDouble(int channnelNum,double setpt ,const DoubleTypeInfo& typeinfo);
	bool readDouble(int channnelNum,double * value ,const DoubleTypeInfo& typeinfo);
	bool readAlarm(int channelNum,int * value ,const IntTypeInfo& typeinfo);
	bool writeInt(int channelNum, int mode, const IntTypeInfo& typeinfo);
	bool readInt(int channelNum, int * value, const IntTypeInfo& typeinfo);
	unsigned short calculateLRC(char* buffer,int len);
	void differNXTempDifferMachineCh(int channelNum);
};

#endif /*SRS10ATEMPCTL_H_*/
