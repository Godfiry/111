/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: IOFailedException.h
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-07-09  LiJuanjuan create
**      
*********************************************************************/
#ifndef IOFAILEDEXCEPTION_H_
#define IOFAILEDEXCEPTION_H_

#include "TMCException.h"

class IOFailedException:public TMCException
{
	public:
		IOFailedException(const std::string &s);
};

#endif /*IOFAILEDEXCEPTION_H_*/
