/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AdvancedMFC.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2008-5-21   LiJuanjuan create
**      
*********************************************************************/
#include "AdvancedMFC.h"
#include "XmlGetter.h"
#include "DeviceManager.h"
#include "ConfigException.h"
//#include "DNSS5136.h"

#include <cmath>
#include <string.h>
#include <Hex.h>
#ifdef IAP4_0
using namespace IAP::IO;
#endif

using namespace std;
#include <iostream>
AdvancedMFC::AdvancedMFC()
{
	m_pollInterval = 300;
	m_dFullScale = 24576;//0x6000 = 24576 details please see manual

	m_nInBytesSize = 0;
	m_nOutBytesSize = 0;

	m_bMFCNegativeEnable = false;//add by guoj

	m_dPressureFullScale = 24576;
	m_dTempFullScale = 24576;
	m_nMFCMaxValue = -10000;//added by zhangyy for Gas CIP,the impossible MFC value
	m_dSimulateGasFlow = 0;//added by zhangyy for Gas CIP
}

AdvancedMFC::~AdvancedMFC()
{
}

void AdvancedMFC::setMFCNegativeEnable(bool bEnable)
{
	m_bMFCNegativeEnable = bEnable;
}

bool AdvancedMFC::setGasFlow(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
	if(isSimulated())
	{
		m_dSimulateGasFlow = dValue;
		return true;
	}
	int nMaxGasFlow;
	if(m_nMFCMaxValue != -10000)
	{
	    nMaxGasFlow = m_nMFCMaxValue;
	}
	else
	{
		nMaxGasFlow = typeInfo.getMax();
	}
	char pBuffer[m_nOutBytesSize];
	memset(pBuffer, 0, m_nOutBytesSize);
	int nTempValue =(int)((dValue / nMaxGasFlow) * m_dFullScale);
	pBuffer[0] = nTempValue & 0xff;
	pBuffer[1] = (nTempValue >> 8) & 0xff;
	return m_deviceNet->writeByte(m_macID, pBuffer);
}

bool AdvancedMFC::getGasPressure(int nChannelNum, double *pValue,const DoubleTypeInfo &typeInfo )    //add by wzd 1.1.61
{
if(isSimulated())
	{
		*pValue = 0;
		return true;
	}
	double dMaxGasPressure = typeInfo.getMax();
	char pBuffer[m_nInBytesSize];
	memset(pBuffer, 0, m_nInBytesSize);
	m_deviceNet->readByte(m_macID, pBuffer);
    int nTempValue = 0;
	if(!(pBuffer[4] & 0x80))
	{
		nTempValue = (pBuffer[3] &0xff) + ((pBuffer[4] << 8) & 0xff00);
	}
	if(nTempValue > m_dFullScale)
	{
		*pValue = dMaxGasPressure;
	}
	else
	{
		double dValue = ((((double)nTempValue) / m_dPressureFullScale) * 100) - 15;
		*pValue = MathTool::Round(dValue,typeInfo.getAccuracy());
	}
	return true;
}


bool AdvancedMFC::getGasTemp(int nChannelNum, double *pValue,const DoubleTypeInfo &typeInfo )    //add by wzd 1.1.61
{
	if(isSimulated())
	{
		*pValue = 0;
		return true;
	}
	//double nMaxGasTemp = typeInfo.getMax();
	char pBuffer[m_nInBytesSize];
	memset(pBuffer, 0, m_nInBytesSize);
	m_deviceNet->readByte(m_macID, pBuffer);
    int nTempValue = 0;
	if(!(pBuffer[4] & 0x80))
	{
		nTempValue = (pBuffer[5] &0xff) + ((pBuffer[6] << 8) & 0xff00);
	}
	if(nTempValue > m_dTempFullScale)
	{
		*pValue = 273.15 ;
	}
	else
	{
		double dValue = ((((double)nTempValue) / m_dTempFullScale) * 500) - 273.15;
		*pValue = MathTool::Round(dValue,typeInfo.getAccuracy());
	}
	return true;
}

bool AdvancedMFC::getGasFlow(int nChannelNum, double *pValue,const DoubleTypeInfo &typeInfo )
{	
	if(isSimulated())
	{
		*pValue = m_dSimulateGasFlow;
		return true;
	}
	int nMaxGasFlow;
	if(m_nMFCMaxValue != -10000)
	{
	    nMaxGasFlow = m_nMFCMaxValue;
	}
	else
	{
		nMaxGasFlow = typeInfo.getMax();
	}
	char pBuffer[m_nInBytesSize];
	memset(pBuffer, 0, m_nInBytesSize);
	m_deviceNet->readByte(m_macID, pBuffer);
	int nTempValue = 0;
	if(!(pBuffer[2] & 0x80))
	{
		nTempValue = (pBuffer[1] &0xff) + ((pBuffer[2] << 8) & 0xff00);
	}
	else//add by guoj
	{
		if(m_bMFCNegativeEnable)
		{
			short sTempValue = (short)(((pBuffer[2]  & 0xff) << 8) | (pBuffer[1]  &0xff));
			nTempValue = (int)sTempValue;
		}
	}
	if(nTempValue > m_dFullScale)
	{
		*pValue = nMaxGasFlow;
	}
	else
	{
		double dValue = (((double)nTempValue)/m_dFullScale) * nMaxGasFlow;
		*pValue = MathTool::Round(dValue,typeInfo.getAccuracy());
	}
	return true;
}
void AdvancedMFC::initDevice()
{
	m_nInBytesSize = m_deviceNet->getIBytesSize(m_macID);
	m_nOutBytesSize = m_deviceNet->getOBytesSize(m_macID);
	if(m_nInBytesSize > 10 || m_nInBytesSize < 3)
	{
		throw ConfigException("MacID "+Converter::convertToString(m_macID)+" InByteSize abnormal "+Converter::convertToString(m_nInBytesSize));
	}
	if(m_nOutBytesSize > 10 || m_nOutBytesSize < 2)
	{
		throw ConfigException("MacID "+Converter::convertToString(m_macID)+" OutByteSize abnormal "+Converter::convertToString(m_nOutBytesSize));
	}
}

void AdvancedMFC::init()
{
	DeviceNode<AdvancedMFC> * node = new DeviceNode<AdvancedMFC>(m_pollInterval,this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	node->registerReadCh(0, &AdvancedMFC::getGasFlow);
	node->registerWriteCh(1, &AdvancedMFC::setGasFlow);		
	node->registerReadCh(2, &AdvancedMFC::getGasPressure);    //add by wzd 1.1.61
	node->registerReadCh(3, &AdvancedMFC::getGasTemp);
	

	if(!isSimulated())
	{
		node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &AdvancedMFC::getStatus);//added by mujy[v1.0.8]
		initDeviceNet();
		initDevice();
	}
}

bool AdvancedMFC::getStatus(int nChannelNum, int *pBit, const IntTypeInfo &typeInfo)
{
	if (m_currentCycle == m_pollStatusInterval)
	{
		m_currentCycle = 0;
		int nStatus = m_deviceNet->readStatus(m_macID);
		if (0 == nStatus)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::FATAL,
					getSelfName() + ": Node Status is abnormal! MacID: " + Converter::convertToString(m_macID)
							+ ", Status: " + Converter::convertToString(nStatus));
			m_connectStatus = COMMUNICATION_STATUS::DISCONNECT;
		}
		else
		{
			m_connectStatus = COMMUNICATION_STATUS::CONNECT;
		}
	}
	else
	{
		m_currentCycle++;
	}
	*pBit = m_connectStatus;
	return true;
}

void AdvancedMFC::setGasPressureFullScale(double dFullScale)
{
    m_dPressureFullScale = dFullScale;
}

void AdvancedMFC::setGasTempFullScale(double dFullScale)
{
    m_dTempFullScale = dFullScale;
}

void AdvancedMFC::setMFCValue(const std::string &strPath)
{
	m_nMFCMaxValue = XmlGetter::getFromNamespace<ReadWriteInt*>(strPath)->getValue();
}

void AdvancedMFC::setSimulatedFromSetup(const std::string &strPath)
{
    if(strPath.find("/") != std::string::npos)
    {
    	ManagedObject::setSimulated((XmlGetter::getFromNamespace<ReadWriteInt*>(strPath))->getValue());//from Setup.  false:0,true:1
    }
    else
    {
        throw ConfigException("setSimulated from Setup failed:error type.");
    }
}

IMPLEMENT_DYNAMIC(AdvancedMFC, IODevice )
BEGIN_MSG_MAP( AdvancedMFC, IODevice )
	SET_B(setMFCNegativeEnable, AdvancedMFC)
	SET_D(setGasPressureFullScale, AdvancedMFC)
	SET_D(setGasTempFullScale, AdvancedMFC)
	SET_S(setMFCValue, AdvancedMFC)
	SET_S(setSimulatedFromSetup, AdvancedMFC )//zhangyy add for Gas CIP
END_MSG_MAP


