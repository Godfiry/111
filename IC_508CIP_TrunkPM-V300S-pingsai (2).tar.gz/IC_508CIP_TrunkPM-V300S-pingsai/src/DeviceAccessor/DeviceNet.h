/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: DeviceNet.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2007-9-22   LiJuanjuan create
**      
*********************************************************************/
#ifndef DEVICENET_H_
#define DEVICENET_H_


#include "IMutex.h"
#include <string>
#ifdef IAP4_0
using namespace IAP::CORE;
#endif



class DeviceNet
{
	private:
		
	protected:
		std::string m_devName;
		int m_baudRate;
		int m_masterMacID;
		unsigned short m_scannermak;	
		IMutex m_lock;
		std::string m_fwdir;//.ss2 oe ss3's dir 
	
		DeviceNet(const DeviceNet &dev);
		DeviceNet& operator = (const DeviceNet &dev);	

		int m_nHeadLen;             //add by wzd 1.1.54
		
	public:
		DeviceNet(const std::string &devName, int masterMacId, int baudRate);
		virtual ~DeviceNet();
		
		virtual bool addDevice(int inmac) = 0; 
		virtual bool readBit(int inmac, int channel, bool *bit)=0;
		virtual bool writeBit(int inmac, int channel, bool bit)=0;
		virtual bool readByte(int macid, char *buffer)=0;
		virtual bool writeByte(int inmac, char *byte)=0;
		virtual bool writeExplicit(int macid, char *buffer, int service, int Class, int instance, int datasize)=0;
		virtual bool readExplicit(int macid, char *bufferIn, int service,int Class, int instance, int datasizeIn, char *bufferOut, int *datasizeOut) = 0;
		virtual int getIBytesSize(int inmac)=0;
		virtual int getOBytesSize(int inmac)=0;
		virtual void loadDevice() = 0;		
		void setFWdir(const std::string &dir);
		virtual int readStatus(int nMacId) = 0;//added by mujy[v1.0.8]
		
		void setHeadLen(int len); //add by wzd 1.1.54
		
		
};

#endif /*DEVICENET_H_*/
