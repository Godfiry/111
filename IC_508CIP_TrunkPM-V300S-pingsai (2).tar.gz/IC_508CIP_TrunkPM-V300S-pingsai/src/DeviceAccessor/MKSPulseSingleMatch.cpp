/********************************************************************
** Copyright (c) 2016, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MKSPulseSingleMatch.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2017-6-23   xiasc creat
**      
*********************************************************************/
#include "MKSPulseSingleMatch.h"
#include <string.h>
#include "DeviceManager.h"
#include "ObjectManager.h"
#include "Converter.h"

#include <sys/time.h>
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;


MKSPulseSingleMatch::Address  MKSPulseSingleMatch::m_addInfo[] = {  {0,0},
																{505,100},//1 C1PositionAI(FLOAT32)
																{506,100},//2 C2PositionAI(FLOAT32)
																{507,100},//3 C3PositionAI(FLOAT32)
																{510,1},//4 ForwardPowerAI(UINT16)
																{511,1},//5 ReflectPowerAI(UINT16)
																{513,100},//6 GetVDC(FLOAT32)
																{551,100},//7 C1SetPositionSP(FLOAT32)
																{552,100},//8 C2SetPositionSP(FLOAT32)
																{553,100},//9 C3SetPositionSP(FLOAT32)
																{558,100},//10 C1PresetSP(FLOAT32)
																{559,100},//11 C2PresetSP(FLOAT32)
																{560,100},//12 C3PresetSP(FLOAT32)
																{554,1},//13 ManualAutoSP(UINT16)
																{555,1},//14 PresetModeSP(UINT16)
																{556,1},//15 PulseModeSP(UINT16)
																{557,1},//16FrequenceModeSP(UINT16)
																{561,1},//17 RecordPresetSP
																{554,1},//18 ManualAutoAI(UINT16)
																{569,100},//19 turnOn Delay(FLOAT32)
																{513,100},//20 GetVDC vimage(FLOAT32)//fixed by xiasc[v1.6.14]
																//add by wzd 1.1.20 for mks4kw match
																{505,100},//21 C1PositionAI(FLOAT32)
																{506,100},//22 C2PositionAI(FLOAT32)
																{507,100},//23 C3PositionAI(FLOAT32)
																{551,100},//24 C1SetPositionSP(FLOAT32)
																{552,100},//25 C2SetPositionSP(FLOAT32)
																{553,100},//26 C3SetPositionSP(FLOAT32)
																{558,100},//27 C1PresetSP(FLOAT32)
																{559,100},//28 C2PresetSP(FLOAT32)
																{560,100},//29 C3PresetSP(FLOAT32)
																{554,1},//30 ManualAutoSP(UINT16)
																{578,1},//31 C3ControlModeSP(UINT16)
																{619,1},//32 InitMotors(UINT16)
																{554,1},//33 ManualAutoAI(UINT16)
																{536,1},//34 Iratio(FLOAT32)  //1.1.23
																{579,1},//35 Targetratio(FLOAT32)  //1.1.23
																{513,100},//36 Vmag(FLOAT32)
																{515,100},//37 Imag(FLOAT32)
																{517,100},//38 phase(FLOAT32)
																{518,100},//39 Zmag(FLOAT32)
																{520,100},//40 Zreal(FLOAT32)
																{522,100},//41 Zimag(FLOAT32)
																{524,100},//42 Vmag(FLOAT32)
																{526,100},//43 Imag(FLOAT32)
																{528,100},//44 phase(FLOAT32)
																{529,100},//45 Zmag(FLOAT32)
																{531,100},//46 Zreal(FLOAT32)
																{533,100},//47 Zimag(FLOAT32)
																{7,1},//48 FaultClear(UINT16)
                                                                {578,100},//49 C3ControlMode(UINT16)
																{620,1},//50 WriteStopGamma(UINT16)
																{621,1},//51 WriteRestartGamma(UINT16)
																{622,1},//52 WriteFlagBosch(UINT16)
																{620,1},//53 ReadStopGamma(UINT16)
																{621,1},//54 ReadRestartGamma(UINT16)
																{622,1},//55 ReadFlagBosch(UINT16)
																{576,1}//56 Pulse synch source(UINT16) default :0 ; cancel relation with power:1
																	 	 	 	 	 	 	 	 	 	 	 
};

MKSPulseSingleMatch::MKSPulseSingleMatch():SerialDevice(80, "")
{
	m_resLen = 8;
	//the form of the read command
	m_readCmd[0] = 0x02;//controller address
	m_readCmd[1] = 0x03;//function read
	m_readCmd[2] = 0x00;//read starting at register high byte
	m_readCmd[3] = 0x00;//read starting at register low byte
	m_readCmd[4] = 0x00;//read number of consecutive register (always 0)
	m_readCmd[5] = 0x01;//read number of consecutive register (always 2)
	m_readCmd[6] = 0x00;//Low byte of CRC
	m_readCmd[7] = 0x00;//High byte of CRC
	
	 //the form of the write command
	m_writeCmd[0] = 0x02;//controller address
	m_writeCmd[1] = 0x10;//function multiple write
	m_writeCmd[2] = 0x00;//write starting at register High byte
	m_writeCmd[3] = 0x00;//write starting at register Low byte
	m_writeCmd[4] = 0x00;//read number of consecutive register--High byte(always 0)
	m_writeCmd[5] = 0x01;//read number of consecutive register--Low byte
	m_writeCmd[6] = 0x02;//number of byte to Write
	m_writeCmd[7] = 0x00;//data High byte of 1# register write
	m_writeCmd[8] = 0x00;//data Low byte of 1# register write
	m_writeCmd[9] = 0x00;//Low byte of CRC
	m_writeCmd[10] = 0x00;//High byte of CRC

}

MKSPulseSingleMatch::~MKSPulseSingleMatch()
{

}

unsigned short  MKSPulseSingleMatch::GetCRC16Code(char* nCmd,int nLen)
{
	unsigned short crc=0xFFFF;
	unsigned short polynomial=0xA001;
	
	unsigned int i,j;
	for(i=0;i<nLen;i++)
	{
		crc=crc^(nCmd[i]&0x00FF);
		for(j=0;j<8;j++)
		{
			if(crc&1)
			{
          		crc=crc>>1;
		   		crc=crc^polynomial;
			}
			else
			{
				crc=crc>>1;
			}
		}
	}
	return crc;
}

int MKSPulseSingleMatch::readCommand(char *command, int timeOut, int len)
{
	if(len != 8)
	{
		throw IOException(getDeviceName()+" read command failed for command length invalid");
	}
	char res[10];
	memset(res, 0, 10);
	int nReadComResLen = 7;

	if(command[5] == 0x02)
	{
		nReadComResLen = 9;
	}

	sendCommandOnly(command, len);

	int resNum = getResultOnly(res, nReadComResLen, timeOut);

	if(resNum < nReadComResLen)
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, "Match gets unknown results : "+Hex::GetHexString(res,resNum));
		throw IOException(getDeviceName()+" read command failed for unknown response [" + Hex::GetHexString(res,resNum)+"]");
	}
	if((res[0] == 0x02) && (res[1]== 0x03))
	{
	    unsigned char cByte[4];
	    int nValue = 0;
	    if(command[5] == 0x02)
	    {
			cByte[3] = res[3]&0x00ff;
			cByte[2] = res[4]&0x00ff;
			cByte[1] = res[5]&0x00ff;
			cByte[0] = res[6]&0x00ff;
	    }
	    else
	    {
			cByte[3] = 0x00;
	    	cByte[2] = 0x00;
	    	cByte[1] = res[3]&0x00ff;
			cByte[0] = res[4]&0x00ff;
        }
	    nValue=*(int*)&cByte;
	    return nValue;
	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, "Match gets unknown results : "+Hex::GetHexString(res,resNum));
		throw IOException(getDeviceName()+" read command failed for unknown response [" + Hex::GetHexString(res,resNum)+"]");
	}
}

bool MKSPulseSingleMatch::sendCommand(char *command, int timeOut, int len)
{	
	char res[m_resLen];
	memset(res, 0, m_resLen);
	sendCommandOnly(command, len);
	/*int resNum = */getResultOnly(res, m_resLen, timeOut);
	
	/*for(int i=0; i<resNum; ++i)
	{
		cout<<"sendCommand res = " << hex<<(unsigned int)res[i] << endl;
	}*/
	if((res[0] == 0x02) && (res[1]== 0x10))
	{
		return true;
	}
	else
	{
		throw IOException(getDeviceName()+" send control command failed for unknown response [" + Hex::GetHexString(res,2)+"]");
	}
}

bool MKSPulseSingleMatch::readDouble(int channelNum,double * value ,const DoubleTypeInfo& typeinfo)
{
	if (isSimulated())
	{
		struct timeval tm;
		struct timezone *tz = NULL;
		
		gettimeofday(&tm,tz);
		*value = typeinfo.getMax() * ((double)tm.tv_usec / 1000000);
		return true;
	}
	
	unsigned int t_addr = m_addInfo[channelNum].m_address;
	m_readCmd[2] = (t_addr >> 8) & 0xFF;//address high byte
	m_readCmd[3] = t_addr & 0xFF;//address low byte
	
	if(channelNum == 6 || channelNum == 20)
	{
	     m_readCmd[4] = 0x00;
	     m_readCmd[5] = 0x02;
	}
	else if((channelNum >= 36 && channelNum <= 47) && (channelNum != 38 && channelNum != 44))//add by wzd 1.1.20
	{
	     m_readCmd[4] = 0x00;
	     m_readCmd[5] = 0x02;
	}
	else 
	{
	     m_readCmd[4] = 0x00;
	     m_readCmd[5] = 0x01;
	}

	unsigned short crc = GetCRC16Code(m_readCmd, 6);
	m_readCmd[6] = (crc & 0xFF) & 0xFF;    // low byte of CRC
	m_readCmd[7] = (crc >> 8) & 0xFF;  //  high byte of CRC

	int t_value = readCommand(m_readCmd, m_timeOut, 8);	
	*value = (double)t_value / m_addInfo[channelNum].m_p1;
	return true;
}

bool MKSPulseSingleMatch::writeDouble(int channelNum, double setvalue, const DoubleTypeInfo& typeinfo)
{
	if (isSimulated())
	{
		return true;
	}
	
	unsigned int t_addr = m_addInfo[channelNum].m_address;
	m_writeCmd[2] = (t_addr >> 8) & 0xFF;//address high byte
	m_writeCmd[3] = t_addr & 0xFF;//address low byte
	unsigned int t_value = 0;
	t_value = (int)(setvalue * m_addInfo[channelNum].m_p1);
	m_writeCmd[7] = (t_value >> 8) & 0xFF;//data high byte
	m_writeCmd[8] = t_value & 0xFF;//data low byte
	unsigned short crc = GetCRC16Code(m_writeCmd, 9);//CRC
	m_writeCmd[9] = (crc & 0xFF) & 0xFF;    // low byte of CRC
	m_writeCmd[10] = (crc >> 8) & 0xFF;  //  high byte of CRC
	/*for(int i=0; i<11; ++i)
	{
		cout <<"m_writeCmd = " <<hex<<(unsigned int)m_writeCmd[i] << endl;
	}*/
	
	return sendCommand(m_writeCmd, m_timeOut, 11);
	
}

bool MKSPulseSingleMatch::writeInt(int channelNum, int value, const IntTypeInfo &typeInfo)
{
	if (isSimulated())
	{
		return true;
	} 
	unsigned int t_addr = m_addInfo[channelNum].m_address;
	m_writeCmd[2] = (t_addr >> 8) & 0xFF;//address high byte
	m_writeCmd[3] = t_addr & 0xFF;//address low byte
	if(channelNum == 50 || channelNum == 51) //add by wzd 1.1.46
	{
		unsigned int t_value = 0;
		//t_value = (int)value * (2 ^ 14);
		t_value = (int)value;
		m_writeCmd[7] = (t_value >> 8) & 0xFF;//data high byte
		m_writeCmd[8] = t_value & 0xFF;//data low byte
	}
	if(value == 0)
	{
		m_writeCmd[7] = 0x00;
		m_writeCmd[8] = 0x00;
	}
	else if(value == 1)
	{
		m_writeCmd[7] = 0x00;
		m_writeCmd[8] = 0x01;
	}
	else if(value == 2)
	{
		m_writeCmd[7] = 0x00;
		m_writeCmd[8] = 0x02;
	}
	else if(value == 3)//add by wzd 1.1.20
	{
		m_writeCmd[7] = 0x00;
		m_writeCmd[8] = 0x03;
	}

	else if(value == 4)
	{
		m_writeCmd[7] = 0x00;
		m_writeCmd[8] = 0x04;
	}
	unsigned short crc = GetCRC16Code(m_writeCmd, 9);//CRC
	m_writeCmd[9] = (crc & 0xFF) & 0xFF;    // low byte of CRC
	m_writeCmd[10] = (crc >> 8) & 0xFF;  //  high byte of CRC
	return sendCommand(m_writeCmd, m_timeOut, 11);
}

bool MKSPulseSingleMatch::readInt(int channelNum, int *value, const IntTypeInfo &typeInfo)
{
	unsigned int t_addr = m_addInfo[channelNum].m_address;
	m_readCmd[2] = (t_addr >> 8) & 0xFF;//address high byte
	m_readCmd[3] = t_addr & 0xFF;//address low byte
	m_readCmd[4] = 0x00;
	m_readCmd[5] = 0x01;
	
	unsigned short crc = GetCRC16Code(m_readCmd, 6);
	m_readCmd[6] = (crc & 0xFF) & 0xFF;    // low byte of CRC
	m_readCmd[7] = (crc >> 8) & 0xFF;  //  high byte of CRC

	int t_value = readCommand(m_readCmd, m_timeOut, 8);	
	*value = t_value;
	return true;

}

bool MKSPulseSingleMatch::writePosition(int channelNum, int value, const IntTypeInfo &typeInfo)
{
	if (isSimulated())
	{
		return true;
	}
	
	unsigned int t_addr = m_addInfo[channelNum].m_address;
	m_writeCmd[2] = (t_addr >> 8) & 0xFF;//address high byte
	m_writeCmd[3] = t_addr & 0xFF;//address low byte
	unsigned int t_value = 0;
	t_value = (int)value * 10;
	m_writeCmd[7] = (t_value >> 8) & 0xFF;//data high byte
	m_writeCmd[8] = t_value & 0xFF;//data low byte
	unsigned short crc = GetCRC16Code(m_writeCmd, 9);//CRC
	m_writeCmd[9] = (crc & 0xFF) & 0xFF;    // low byte of CRC
	m_writeCmd[10] = (crc >> 8) & 0xFF;  //  high byte of CRC
	/*for(int i=0; i<11; ++i)
	{
		cout <<"m_writeCmd = " <<hex<<(unsigned int)m_writeCmd[i] << endl;
	}*/
	
	return sendCommand(m_writeCmd, m_timeOut, 11);
}

bool MKSPulseSingleMatch::readPosition(int channelNum, int *value, const IntTypeInfo &typeInfo)
{
	unsigned int t_addr = m_addInfo[channelNum].m_address;
	m_readCmd[2] = (t_addr >> 8) & 0xFF;//address high byte
	m_readCmd[3] = t_addr & 0xFF;//address low byte
	m_readCmd[4] = 0x00;
	m_readCmd[5] = 0x01;
		
	unsigned short crc = GetCRC16Code(m_readCmd, 6);
	m_readCmd[6] = (crc & 0xFF) & 0xFF;    // low byte of CRC
	m_readCmd[7] = (crc >> 8) & 0xFF;  //  high byte of CRC

	int t_value = readCommand(m_readCmd, m_timeOut, 8);	
	*value = t_value/10;
	return true;
}

void MKSPulseSingleMatch::initChs(DeviceNode<MKSPulseSingleMatch> *node)
{
	for(int i = 1; i <= 3; ++i)
	{
		node->registerReadCh(i, &MKSPulseSingleMatch::readPosition);
	}
	for(int i = 4; i <= 6; ++i)
	{
		node->registerReadCh(i, &MKSPulseSingleMatch::readDouble);
	}
	for(int i = 7; i <= 12; ++i)
	{
		node->registerWriteCh(i, &MKSPulseSingleMatch::writePosition);
	}	
	for(int i = 13; i <= 16; ++i)
	{
		node->registerWriteCh(i, &MKSPulseSingleMatch::writeInt);
	}
	node->registerWriteCh(17, &MKSPulseSingleMatch::writePosition);
	node->registerReadCh(18, &MKSPulseSingleMatch::readInt);
	node->registerWriteCh(19, &MKSPulseSingleMatch::writeDouble);
	node->registerReadCh(20, &MKSPulseSingleMatch::readDouble);//fixed by xiasc[v1.6.14]
	//add by wzd 1.1.20
	//node->registerWriteCh(25, &MKSPulseSingleMatch::writeInt);

	for(int i = 21; i <= 23; ++i)
	{
		node->registerReadCh(i, &MKSPulseSingleMatch::readPosition);
	}
	for(int i = 24; i <= 29; ++i)
	{
		node->registerWriteCh(i, &MKSPulseSingleMatch::writePosition);
	}
	for(int i = 30; i <= 32; ++i)
	{
		node->registerWriteCh(i, &MKSPulseSingleMatch::writeInt);
	}
	node->registerReadCh(33, &MKSPulseSingleMatch::readInt);
	node->registerReadCh(34, &MKSPulseSingleMatch::readDouble);
	node->registerWriteCh(35, &MKSPulseSingleMatch::writeDouble);

	for(int i = 36; i <= 47; ++i)
	{
		node->registerReadCh(i, &MKSPulseSingleMatch::readDouble);
	}
	node->registerWriteCh(48, &MKSPulseSingleMatch::writeInt);
	node->registerReadCh(49, &MKSPulseSingleMatch::readInt);
	for(int i = 50; i <= 52; ++i)  //add by wzd 1.1.46
	{
		node->registerWriteCh(i, &MKSPulseSingleMatch::writeInt);
	}
	for(int i = 53; i <=55; ++i)
	{
		node->registerReadCh(i, &MKSPulseSingleMatch::readInt);
	}
	//node->registerWriteCh(50, &MKSPulseSingleMatch::writeInt);

	node->registerWriteCh(56, &MKSPulseSingleMatch::writeInt);
	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &MKSPulseSingleMatch::getStatus);
}

void MKSPulseSingleMatch::initDevice()
{
	cout<<"Start Scan MKS Single Match...."<<endl;
	//say hello to match
	int nTemp;
	try
	{
		readPosition(1,&nTemp,IntTypeInfo());//1 C1PositionAI(FLOAT32)
	}
	catch(exception &ex)
	{
		cout<<"Scan MKS Single Match failed. Communication abnormal!"<<endl;	
		throw;
	}
	cout<<"Scan MKS Single Match Successfully...."<<endl;
}

void MKSPulseSingleMatch::init()
{
    DeviceNode<MKSPulseSingleMatch> *node = new DeviceNode<MKSPulseSingleMatch>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	if(!isSimulated())	
	{
		initChs(node);	
		initDevice();
	}
}

IMPLEMENT_DYNAMIC(MKSPulseSingleMatch, SerialDevice)

BEGIN_MSG_MAP(MKSPulseSingleMatch, SerialDevice)
	SET_V( init, MKSPulseSingleMatch)
END_MSG_MAP
