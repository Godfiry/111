/*
 * EtherCat.h
 *
 *  Created on: 2023��11��2��
 *      Author: liusiyuan
 */

#ifndef SRC_DEVICEACCESSOR_ETHERCAT_H_
#define SRC_DEVICEACCESSOR_ETHERCAT_H_
#include <string>
#include "IMutex.h"
#include <map>
#include <vector>
#include "IStringList.h"
#ifdef IAP4_0
using namespace IAP::CORE;
#endif
using namespace std;
#define Simulated 0
#define NotSimulated 1

class IOParam
{
public:
	int m_nType;
	int m_nByteOffset;
	int m_nByteSize;
};

class AnalogParam : public IOParam
{
public:
	double m_dMax;
	double m_dMin;
	double m_dRange;// from 0 value range
};

class DigitalParam : public IOParam
{
public:
	int m_nBitOffset;
	int m_nBitSize;
};

class DeviceDataDomain
{
public:
	int m_nByteSize;

	int m_nDeviceByteOffset;

	vector<AnalogParam> m_vAIParam;
	vector<AnalogParam> m_vAOParam;

	vector<DigitalParam> m_vDIParam;
	vector<DigitalParam> m_vDOParam;
};


class DeviceParam
{
public:
	int m_nMacID;
	int m_nSimulation;
	int m_nChannelSize;
	int m_nDeviceMapIndex;
	DeviceDataDomain m_Input;
	DeviceDataDomain m_Output;

};

class EtherCat{


public:
	EtherCat();
	virtual ~EtherCat();

	virtual void loadDevice() = 0;

	virtual void addDeviceParam(int macid, DeviceParam *dp) = 0;
	virtual bool readByte(int macid, char *buffer) = 0;
	virtual bool writeByte(int inmac, char *byte) = 0;

	virtual bool writeExplicit(int macid, char *buffer, int index, int subIndex, int datasize) = 0;
	virtual bool readExplicit(int macid, char *buffer, int index, int subIndex, int &datasize) = 0;
	virtual int readStatus(int nMacId) = 0;

	void setDebugMode(bool bDebugEnable);
	void setTimeOut(int nTimeOut);
	void setDeviceNum(int nNum);


protected:

	map<int,DeviceParam*> m_EtherCatDevice; //macid,DeviceParam (map�洢Device�豸 for macid index)
	vector<DeviceParam*> m_EtherCatDeviceList;//˳��洢Device�б�,ָ��ָ��m_EtherCatDevice�е��豸


	IMutex m_lock;
	int m_TimeOut;
	bool m_bDebugEnable;
	int m_nDeviceNum;

};

#endif /* SRC_DEVICEACCESSOR_ETHERCAT_H_ */
