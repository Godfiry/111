
#ifndef PVSETSKIPROW_H_
#define PVSETSKIPROW_H_

struct PVSetSkipRow {
    int nGroup;
    int nStepIndex;
    int nSkipToStep;
    bool bSkipFlag;
    double dPVSet;

    PVSetSkipRow() :
        nGroup(0),
        nStepIndex(0),
        nSkipToStep(0),
        bSkipFlag(false),
        dPVSet(0.0)
    {
    }
};//[zhangcx v1.4.0_hotfix7]



#endif /*PVSETSKIPROW_H_*/
