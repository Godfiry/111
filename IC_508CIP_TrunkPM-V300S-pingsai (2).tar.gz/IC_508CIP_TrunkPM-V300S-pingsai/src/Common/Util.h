/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: Util.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-11-30   LiJuanjuan create
**                                                 2018-06-01    Duq update stringToCondition
**                                                 2019-04-17    Duq add isDoubleZero
*********************************************************************/

#ifndef UTIL_H_
#define UTIL_H_

#include <sstream>
#include "AppCondition.h"
#ifdef IAP4_0
using namespace IAP::CONDITION;
#endif

class Util
{
	public:
		Util();
		virtual ~Util();
		
		static bool stringToHex(int *res, const std::string &s);
		static std::string hexToString(int value);
		static std::string toUpper(const std::string &str);
		static std::string toLower(const std::string &str);
		static AppConditionPtr stringToCondition(const std::string &str);
		bool isDoubleZero(double value);
};

#endif /*UTIL_H_*/
