#include "FabDoctorTempCtl.h"
#include "ObjectManager.h"
#include "DeviceManager.h"


#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
using namespace IAP;
#endif
using namespace std;

FabDoctorTempCtl::Com FabDoctorTempCtl::m_Commands[]={
															  {4,"TS?#",3},//read cur temp
															  {4,"TO?#",3},//read set temp				
															  {4,"PP?#",3}//read Power   //zhangyy add read power[1.5.0]
};

FabDoctorTempCtl::FabDoctorTempCtl():SerialDevice(200, "")
{
	m_startCmd = "@";	//"@"
	m_strAddress = "";
	m_endCmd = "#";//"ETX@ETXETXETX"
	
	m_ForlineTempStartPos = 0;
	m_ForlineTempEndPos = 0;
	m_GaugeTempStartPos = 0;
	m_GaugeTempEndPos = 0;
	m_GaslineTempStartPos = 0;
	m_GaslineTempEndPos = 0;
	
}

FabDoctorTempCtl::~FabDoctorTempCtl()
{
}

std::string FabDoctorTempCtl::readCommand(std::string strCommand, int ntimeOut)
{
	string strReply=getCommandResult(strCommand,ntimeOut);
	
	if(strReply.find("#",7)!=string::npos)
	{
		return strReply;	
	}
	else if(strReply.find("NAK",0)!=string::npos)
	{
		throw IOException("read command error,reply is :"+strReply);
	}
	else
	{
		throw IOException("unknow read_back: " + strReply+" when send query command "+strCommand);
	}

}

bool FabDoctorTempCtl::readDouble(int nChannelNum, double *pValue,const DoubleTypeInfo &typeInfo)
{
	
	
	std::string t_sendComnd = "";
	std::string t_res = "";
	std::string t_svalue = "";
	if(0 <= nChannelNum && nChannelNum < 10)
	{
		m_strAddress = "201";
	}
	if(10 <= nChannelNum && nChannelNum < 20)
	{
		m_strAddress = "202";
		nChannelNum = nChannelNum - 10;
	}
	if(20 <= nChannelNum && nChannelNum < 30)
	{
		m_strAddress = "203";
		nChannelNum = nChannelNum - 20;
	}
	if(30 <= nChannelNum && nChannelNum < 40)
	{
		m_strAddress = "204";
		nChannelNum = nChannelNum - 30;
	}
	if(40 <= nChannelNum && nChannelNum < 50)
	{
		m_strAddress = "205";
		nChannelNum = nChannelNum - 40;
	}
	if(50 <= nChannelNum && nChannelNum < 60)
	{
		m_strAddress = "206";
		nChannelNum = nChannelNum - 50;
	}
	if(60 <= nChannelNum && nChannelNum < 70)
	{
		m_strAddress = "207";
		nChannelNum = nChannelNum - 60;
	}
	if(70 <= nChannelNum && nChannelNum < 80)
	{
		m_strAddress = "208";
		nChannelNum = nChannelNum - 70;
	}
	Com com = m_Commands[nChannelNum];	
	t_sendComnd = m_startCmd+m_strAddress+com.m_strCmd;
	
	t_res = readCommand(t_sendComnd,m_timeOut);	
	t_svalue = t_res.substr(4,com.m_nResLength);
	
	double t_double = 0.0;
	if(!Converter::stringToDouble(t_double, t_svalue))
	{
		throw IOException("read back value is not an valid double value:" + t_svalue);
	}
	*pValue = t_double;
	setDoubleValue(nChannelNum + MONITORDOUBLEVALUEADDMAP, *pValue, typeInfo.getAccuracy());//added by zhangyy 20250623 for FabDoctorTempCtl Protect CIP
	//char ack[1];
	//ack[0]=0x06;
	//sendCommandOnly(ack,1); 
	
	return true;
}

bool FabDoctorTempCtl::writeDouble(int nChannelNum, double value,const DoubleTypeInfo &typeInfo)
{
	
	std::string t_sendComnd = "";
	std::string t_res = "";
	std::string t_svalue = "";
	std::string t_setTempCmd = "TS!"; //set temp
	if(value<100)  //change by chensc
	{
		t_svalue = "0" + Converter::convertToString(value);	
	}
	else
	{
		t_svalue = Converter::convertToString(value);
	}
	
	
	if(m_ForlineTempStartPos <= nChannelNum && nChannelNum <= m_ForlineTempEndPos)
	{
		for(int i = m_ForlineTempStartPos; i <= m_ForlineTempEndPos; i++)
		{
			m_strAddress = Converter::convertToString(i);
			t_sendComnd = m_startCmd+m_strAddress+t_setTempCmd+t_svalue+m_endCmd; 
			sendCommandOnly(t_sendComnd);
			sleep(1); //change by chensc
		}
	
	}
	else if(m_GaugeTempStartPos <= nChannelNum && nChannelNum <= m_GaugeTempEndPos)
	{
		for(int i = m_GaugeTempStartPos; i <= m_GaugeTempEndPos; i++)
		{
			m_strAddress = Converter::convertToString(i);
			t_sendComnd = m_startCmd+m_strAddress+t_setTempCmd+t_svalue+m_endCmd;
			sendCommandOnly(t_sendComnd);
			sleep(1); //change by chensc
		}
	}
	else if(m_GaslineTempStartPos <= nChannelNum && nChannelNum <= m_GaslineTempEndPos)
	{
		for(int i = m_GaslineTempStartPos; i <= m_GaslineTempEndPos; i++)
		{
			m_strAddress = Converter::convertToString(i);
			t_sendComnd = m_startCmd+m_strAddress+t_setTempCmd+t_svalue+m_endCmd;
			sendCommandOnly(t_sendComnd);
			sleep(1); //change by chensc
		}
	}
	else
	{
		m_strAddress = Converter::convertToString(nChannelNum);
		t_sendComnd = m_startCmd+m_strAddress+t_setTempCmd+t_svalue+m_endCmd;
		sendCommandOnly(t_sendComnd);
		sleep(1); //change by chensc
	}
	
	return true;
}


void FabDoctorTempCtl::initChs(DeviceNode<FabDoctorTempCtl>* pNode)
{
	for(int i=0;i<=80;i++)
	{
		pNode->registerReadCh(i, &FabDoctorTempCtl::readDouble);
		pNode->registerReadCh(i + MONITORDOUBLEVALUEADDMAP, &CMonitorDoubleValue::readDoubleChange);//added by zhangyy for FabDoctorTempCtl Protect CIP[1.5.0]
		initDoubleValue(i + MONITORDOUBLEVALUEADDMAP, -1);//added by zhangyy for FabDoctorTempCtl Protect CIP[1.5.0]
	}
	for(int i = 200; i<=210; i++)
	{
		pNode->registerWriteCh(i, &FabDoctorTempCtl::writeDouble);
	}
   
}

void FabDoctorTempCtl::initDevice()
{
	cout<<"Start Scan FabDoctorTempCtl...."<<endl;
	//say hello to chiller
	double dPressure;
	try
	{
		readDouble(1,&dPressure,DoubleTypeInfo());//3 read temprature
	}
	catch(exception &ex)
	{
		cout<<"Scan FabDoctorTempCtl failed. Communication abnormal!"<<endl;
		throw;
	}
	cout<<"Scan FabDoctorTempCtl Successfully...."<<endl;
}


void FabDoctorTempCtl::init()
{
	DeviceNode<FabDoctorTempCtl> *pNode = new DeviceNode<FabDoctorTempCtl>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
	if(!isSimulated())
	{
		initChs(pNode);
		initDevice();
	}
}


void FabDoctorTempCtl::setForlineTempInfo(int tTempStartPos, int tTempEndPos)
{
	m_ForlineTempStartPos = tTempStartPos;
	m_ForlineTempEndPos = tTempEndPos;
}

void FabDoctorTempCtl::setGaugeTempInfo(int tTempStartPos, int tTempEndPos)
{
	m_GaugeTempStartPos = tTempStartPos;
	m_GaugeTempEndPos = tTempEndPos;
}

void FabDoctorTempCtl::setGaslineTempInfo(int tTempStartPos, int tTempEndPos)
{
	m_GaslineTempStartPos = tTempStartPos;
	m_GaslineTempEndPos = tTempEndPos;
}

IMPLEMENT_DYNAMIC(FabDoctorTempCtl, SerialDevice )

BEGIN_MSG_MAP(FabDoctorTempCtl, SerialDevice )
	SET_V( init, FabDoctorTempCtl )
	SET_II(setForlineTempInfo, FabDoctorTempCtl)
	SET_II(setGaugeTempInfo, FabDoctorTempCtl)
	SET_II(setGaslineTempInfo, FabDoctorTempCtl)
END_MSG_MAP
