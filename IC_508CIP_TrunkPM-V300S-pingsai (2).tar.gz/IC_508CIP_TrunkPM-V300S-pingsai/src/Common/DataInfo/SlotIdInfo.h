/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: SlotIdInfo.h
** Description: 
** Release: 
** Modification history: 
** 					Feb 22, 2008  shenql  create 
**      
***************************************************************************/
#ifndef SLOTIDINFO_H_
#define SLOTIDINFO_H_

#include "StringValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class SlotIdInfo : public StringValueInfo
{
	public:
		static const StringTypeInfo typeInfo;
		
		SlotIdInfo():StringValueInfo(){}
		SlotIdInfo(const std::string &s):StringValueInfo(s, typeInfo){}
};

#endif /*SLOTIDINFO_H_*/
