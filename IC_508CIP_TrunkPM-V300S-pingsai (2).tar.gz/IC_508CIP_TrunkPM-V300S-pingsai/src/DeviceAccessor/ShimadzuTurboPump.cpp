#include "ShimadzuTurboPump.h"
#include "DeviceManager.h"
#include "Converter.h"
#include "IStringList.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std;

ShimadzuTurboPump::ShimadzuTurboPump() :SerialDevice(20, "\x0D")
{
	m_timeOut = 100;
}

ShimadzuTurboPump::~ShimadzuTurboPump()
{
}

ShimadzuTurboPump::Com ShimadzuTurboPump::m_commands[] = {
								   {14,"MJ01PR03FD",1},//10 get speed(MJ01PA032700B5)
								   {14,"MJ01PR05FF",2},//11 get temp
								   {14,"MJ01PR04FE",3},//TMP Current
								   {14,"MJ01PR2602",4},//TMP Lx
								   {14,"MJ01PR2703",5},//TMP Ly
								   {14,"MJ01PR10FB",6},//TMP Revolution
								   {14,"MJ01PR2804",7},//TMP Ux
								   {14,"MJ01PR2905",8},//TMP Uy
								   {14,"MJ01PR30FD",9},//TMP ZA
};

int ShimadzuTurboPump::calculateCheckSum(string command)
{
	int sum = 0;
	int len = command.length();
	for (int i = 0; i < 12; i++)
	{
		sum += command.at(i);
	}
	return sum % 256;
}

string ShimadzuTurboPump::readCommand(string command, int timeOut)
{
	string res = getCommandResult(command, 1000);
	int t_lefttime = timeOut - 100;
	while (res.find("\x0D", 0) == string::npos)
	{
		res += getResultOnly(100);
		t_lefttime -= 100;
		if (t_lefttime < 0)
		{
			throw IOException("Shimadzu TurboPump command readback timeout:" + res);
		}
	}

	int sum = calculateCheckSum(res);
	char ch[3] = "0";
	int a, b;
	a = sum % 16;
	b = sum / 16;
	if (a < 10)
	{
		ch[1] = '0' + a;
	}
	else
	{
		ch[1] = 'A' + a - 10;
	}

	if (b < 10)
	{
		ch[0] = '0' + b;
	}
	else
	{
		ch[0] = 'A' + b - 10;
	}
	if (res.find("\x4D", 0) == string::npos)//find "M"
	{
		throw IOException("Shimadzu TurboPump unknow command read back:" + res);
	}
	else if ((ch[0] != res.at(12)) || (ch[1] != res.at(13)))
	{
		throw IOException("Shimadzu TurboPump checksum error:" + res);
	}
	else
	{
		res.erase(res.find_last_not_of(" ") + 1);
		return res;
	}
}

bool ShimadzuTurboPump::readInt(int channelNum, int* value, const IntTypeInfo& typeInfo)
{
	Com com = m_commands[channelNum - 1];
	string res = readCommand(com.m_cmd, m_timeOut);
	int t_value = 0;
	string t_svalue = res.substr(8, 4);
	t_value = atoi(t_svalue.c_str());
	if (channelNum == 1)//speed 
	{
		*value = t_value * 10;
	}
	else//temp
	{
		*value = t_value;
	}
	return true;
}

bool ShimadzuTurboPump::readDouble(int channelNum, double* value, const DoubleTypeInfo& typeInfo)
{
	Com com = m_commands[channelNum - 1];
	string res = readCommand(com.m_cmd, m_timeOut);
	int t_value = 0;
	string t_svalue = res.substr(8, 4);
	t_value = atoi(t_svalue.c_str());
	if (channelNum == 3 || channelNum == 6)//TMP Current || TMP Revolution
	{
		*value = t_value / 10;
	}
	else
	{
		*value = t_value;
	}
	return true;
}
void ShimadzuTurboPump::initChs(DeviceNode<ShimadzuTurboPump>* node)
{
	//node->registerReadCh(0, &SerialDevice::connectStatus);
	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &ShimadzuTurboPump::getStatus);

	for (int i = 1; i <= 9; ++i)
	{
		if (i == 3 || i == 6)
		{
			node->registerReadCh(i, &ShimadzuTurboPump::readDouble);
		}
		else
		{
			node->registerReadCh(i, &ShimadzuTurboPump::readInt);
		}
	}
}

void ShimadzuTurboPump::init()
{
	DeviceNode<ShimadzuTurboPump>* node = new DeviceNode<ShimadzuTurboPump>(m_pollPeriod, this);
	if (!isSimulated())
	{
		initChs(node);
		DeviceManager::getInstance()->registerNode(m_nodeNum, node);
		//initDevice();
	}
}

IMPLEMENT_DYNAMIC(ShimadzuTurboPump, SerialDevice)

BEGIN_MSG_MAP(ShimadzuTurboPump, SerialDevice)
	SET_V(init, ShimadzuTurboPump)
END_MSG_MAP
