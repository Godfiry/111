/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: ErrCodeCheckItem.cpp
** Description:  
** Release: 1.1
** Modification history: 
* 					2009-9-28   LiJuanjuan create
** 					2019-06-10 liuxj modified, for parse Error code [liuxj v1.0.25].
**      
*********************************************************************/
#include "ErrCodeCheckItem.h"
#include "SysLogger.h"
#include "ConfigException.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "InvalidNameException.h"
#include "IOException.h"
#endif

#include "XmlGetter.h"//added by [liuxj v1.0.25]
#include "Alarm.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
using namespace IAP::ALARM;
#endif

using namespace std;

ErrCodeCheckItem::ErrCodeCheckItem()
{
	m_pAlarmMessageGetFailedAlarm = NULL;
	m_pAlarmDescription = NULL;//add by [liuxj 1.0.25],for Alarm message danamic post.
	m_pErrorCodeParser = NULL;
}

ErrCodeCheckItem::~ErrCodeCheckItem()
{
}

//override
bool ErrCodeCheckItem::doCheck()
{
	if(!m_pTriggerAlarm->isPosted())
	{
		if(checkDelay() && checkTriggered() && checkDuration())
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": is triggered:");	
			if(m_pAlarmDescription != NULL)
			{
				try
				{
					string strErrorInfo = getDeviceErr(m_pAlarmDescription->getValue());
					m_pTriggerAlarm->setMessage(getAlarmMessage());
					m_pTriggerAlarm->setDescription(strErrorInfo);
					m_pTriggerAlarm->post(this);
				}
				catch(const IOException &ex)
				{
					SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() +" ErrCodeCheckItem: got IOException-" +ex.what());
					if(!m_pAlarmMessageGetFailedAlarm->isPosted())
					{
						m_pAlarmMessageGetFailedAlarm->setDescription(ex.what());
						m_pAlarmMessageGetFailedAlarm->post(this);
					}
				}
			}
			else
			{
				m_pTriggerAlarm->post(this);
			}
			executeSafeAction();
			return true;
		}
		else
		{
			return false;
		}
	}
	else
	{
		return true;//zhangyy add for sonar test[1.6.0]
	}
}

void ErrCodeCheckItem::make()
{
	CheckItem::make();
	if(m_pAlarmDescription != NULL)
	{
		m_pAlarmMessageGetFailedAlarm = new NonBlockingAlarmEX(getSelfName()+"_AlarmMessageGetFailedAlarm","get alarm message failed for IO exception", "get alarm message failed for IO exception", Alarm::ERROR);//modified by  [liuxj v1.0.25]
		m_pAlarmMessageGetFailedAlarm->addRecovery(new Recovery("Clear", Recovery::CLEAR));
	}
}		
//added by [liuxj v1.0.25]
std::string ErrCodeCheckItem::getDeviceErr(std::string strErrMsg)
{
	std::string strMessageInfo=strErrMsg;
	if(m_pErrorCodeParser)
	{
		strMessageInfo = m_pErrorCodeParser->parseErrorCode(strErrMsg);
	}
	return strMessageInfo;
}

//[liuxj 1.0.25] for rewrite setMessage
void ErrCodeCheckItem::setAlarmDescriptionCh(const std::string &strPath)
{
	ManagedObject *pObj = NULL;
	try
	{
		pObj = ObjectManager::getInstance()->getObject(strPath);
	}
	catch(const InvalidNameException &ex)
	{
		pObj = ObjectManager::getInstance()->getObject(strPath);
	}
	
	ReadOnlyString *pObj2 = dynamic_cast<ReadOnlyString*>(pObj);
	if(NULL == pObj2)
	{
		string error = "the object under path '" + strPath + "' is not a ReadOnlyString";
		throw ConfigException(error);
	}
	m_pAlarmDescription = pObj2;
}

//added by [liuxj 1.0.25]
void ErrCodeCheckItem::setErrorCodeParser(const std::string &strPath)
{
	ManagedObject *pObj = NULL;
	try
	{
		pObj = ObjectManager::getInstance()->getObject(this, strPath);
	}
	catch(const InvalidNameException &ex)
	{
		string strError=getName() + " setErrorCodeParser path err. Path not exist. path = " + strPath;
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, strError);
		throw ConfigException(strError);
	}
	m_pErrorCodeParser = dynamic_cast<ErrorCodeParserInterface*>(pObj);
	if(NULL == m_pErrorCodeParser)
	{
		string strError=getName() + " setErrorCodeParser data type err.The Data is not a ErrorCodeParserInterface. path = " + strPath;
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, strError);
		throw ConfigException(strError);
	}
}

IMPLEMENT_DYNAMIC(ErrCodeCheckItem, CheckItem)

BEGIN_MSG_MAP( ErrCodeCheckItem, CheckItem)
	SET_S(setAlarmDescriptionCh, ErrCodeCheckItem)//[liuxj v1.0.25]
	SET_S(setErrorCodeParser, ErrCodeCheckItem)//[liuxj v1.0.25]
END_MSG_MAP


