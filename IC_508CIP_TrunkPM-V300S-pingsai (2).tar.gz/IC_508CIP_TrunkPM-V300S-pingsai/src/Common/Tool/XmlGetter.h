/**
 * 
 * 
 */
#ifndef XMLGETTER_H_
#define XMLGETTER_H_

#include "CmdTarget.h"
#include "ObjectManager.h"
#include "SysLogger.h"
#include "ConfigException.h"
#include <typeinfo>
#include "Converter.h"
#ifdef IAP4_0
using namespace IAP::CORE;
#endif
using namespace std;

class XmlGetter
{
public:
	XmlGetter();
	virtual ~XmlGetter();
	template<class T> static T getFromNamespace(const std::string &strPath);

    template<class T> static T getFromNamespace(const ManagedObject *relObj, const std::string &relPath); //add by zhangpf[v1.6.6]
    // added by dangw
    // strPath:  xml Node path
    // typeinfo: ReadWriteInt/ReadWriteDouble/ReadWriteString
    // value:    int/double/string
    template<class T, typename I, typename V> static T* tryGetFromNamespace(const std::string &strPath, I typeinfo, V value);
    static bool isNamespaceExist(const std::string& strPath);//[wangyk 1.2.7HotFix RC02]
};

template<class T> T XmlGetter::getFromNamespace(const std::string &strPath)
{
	ManagedObject *pObj = NULL;
	try
	{
		pObj = ObjectManager::getInstance()->getObject(strPath);
	}
	catch(...)
	{
		string strErr="Get obj failed. Path("+strPath+") not exist.";
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,strErr);
		throw AbortException(strErr);
	}
	T pResult=dynamic_cast<T>(pObj);
	if(pResult==NULL)
	{
		string strErr="Get obj failed.Object at "+strPath+" is not " + typeid(T).name();
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,strErr);
		throw AbortException(strErr);
	}
	return pResult;
}
template<class T> T XmlGetter::getFromNamespace(const ManagedObject *relObj, const std::string &relPath)
{
    ManagedObject *pObj = NULL;
    try
    {
        pObj = ObjectManager::getInstance()->getObject(relObj,relPath);
    }
    catch(...)
    {
        string strErr="Get obj failed.Relative Path("+relPath+") not exist";
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,strErr);
        throw AbortException(strErr);
    }
    T pResult=dynamic_cast<T>(pObj);
    if(pResult==NULL)
    {
        string strErr="Get obj failed.Object of Relative Path"+relPath+" is not " + typeid(T).name();
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,strErr);
        throw AbortException(strErr);
    }
    return pResult;
}

template<class T, typename I, typename V> T* XmlGetter::tryGetFromNamespace(const std::string &strPath, I typeinfo, V value)
{
    ManagedObject *pObj = NULL;
    try
    {
        pObj = ObjectManager::getInstance()->getObject(strPath);
    }
    catch(...)
    {
        string strErr="Get object failed for path("+strPath+") not exist. Auto new it in code and set default value = "+Converter::convertToString(value);
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, strErr);

        T* pResult = new T();
        pResult->setTypeInfo(typeinfo);
        pResult->setValue(value);
        return pResult;
    }

    T* pResult = dynamic_cast<T*>(pObj);
    if(pResult == NULL)
    {
        string strErr="Get object failed for object at "+strPath+" is not " + typeid(T).name();
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, strErr);
        throw AbortException(strErr);
    }
    string strOK="Get object "+strPath+" ok";
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, strOK);
    return pResult;
}
#endif /*XMLGETTER_H_*/
