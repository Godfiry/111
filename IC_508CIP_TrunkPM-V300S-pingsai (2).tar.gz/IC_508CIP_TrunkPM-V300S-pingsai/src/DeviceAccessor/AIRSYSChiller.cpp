#include "AIRSYSChiller.h"
#include "CheckCalculationTool.h"
#include "DeviceManager.h"
#include "ObjectManager.h"
#include "Converter.h"

#include "ConfigException.h"
#include "Hex.h"
#include <sstream>
#include <stdio.h>
#include "Converter.h"
#include <sys/time.h>
#include <iostream>
#include <string.h>
#include <cmath>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;
//liusy [1.1.59]
AIRSYSChiller::Com AIRSYSChiller::m_commands[] = { {0, 0}, // 0 reverse
	//single channel
	{0,0x00}, // 1 on off
	{0,0x01}, // 2 set Temp
	{0,0x03}, // 3 return water temp
	{0,0x04}, // 4 give water temp
	{0,0x05}, // 5 get water flow
	
	//dual channel ch1
	{0,0x00}, // 21 on off
	{1,0x00}, // 22 leak water start/stop
	{0,0x01}, // 23 set Temp
	{0,0x03}, // 24 return water temp
	{0,0x04}, // 25 get water flow
	{0,0x05}, // 26 get water pressure
	{0,0x06}, // 27 get resistance ratio
	{0,0x04}, // 28 get run status
	//ch2
	{0,0x09}, // 29 on off
	{1,0x09}, // 30 leak water start/stop
	{0,0x0A}, // 31 set Temp
	{0,0x0C}, // 32 return water temp
	{0,0x0D}, // 33 get water flow
	{0,0x0E}, // 34 get water pressure
	{0,0x0F}, // 35 get resistance ratio
	{0,0x0D}, // 36 get run status


};

AIRSYSChiller::AIRSYSChiller():SerialDevice(80, "")
{

	m_timeOut=20;
	m_resLen=23;
	//the form of the read command 03
	m_readCmd[0] = 0x01;//controller address
	m_readCmd[1] = 0x03;//function read
	m_readCmd[2] = 0x00;//read starting at register high byte
	m_readCmd[3] = 0x00;//read starting at register low byte
	m_readCmd[4] = 0x00;//read number of consecutive register high (always 0)
	m_readCmd[5] = 0x01;//read number of consecutive register low
	m_readCmd[6] = 0x00;//Low byte of CRC
	m_readCmd[7] = 0x00;//High byte of CRC

	//the form of the write command 06
	m_writeCmd[0] = 0x01;//controller address
	m_writeCmd[1] = 0x06;//function multiple write
	m_writeCmd[2] = 0x00;//write starting at register High byte
	m_writeCmd[3] = 0x00;//write starting at register Low byte
	m_writeCmd[4] = 0x00;//data High byte of register write
	m_writeCmd[5] = 0x00;//data Low byte of register write
	m_writeCmd[6] = 0x00;//Low byte of CRC
	m_writeCmd[7] = 0x00;//High byte of CRC

	m_alarmInfo[0]="LOW TEMP";
	m_alarmInfo[1]="OVER TEMP";
	m_alarmInfo[2]="HIGH TEMP";
	m_alarmInfo[3]="E.LEVEL";
	m_alarmInfo[4]="PUMP LOAD";
	m_alarmInfo[5]="PUMP FAIL";
	m_alarmInfo[6]="WATER LEAK";

	m_pWriteReg = new char[3];
	memset(m_pWriteReg, 0, 3);

	m_bDualChannel = false;
}

AIRSYSChiller::~AIRSYSChiller()
{
	delete[] m_pWriteReg;
	m_pWriteReg = NULL;
}

bool AIRSYSChiller::readDouble(int nChannelNum, double * pValue ,const DoubleTypeInfo& typeinfo)
{
	if (m_bDualChannel)
	{
		int nIndex = 0;
		if (nChannelNum > 20)
		{
			nIndex = nChannelNum - 15;//map to array: 21 to 6
		}
		Com com = m_commands[nIndex];

		m_readCmd[2] = 0x00;
		m_readCmd[3] = com.m_addr;
	}
	else
	{
		m_readCmd[2] = 0x00;//the start of register high
		m_readCmd[3] = 0x03;//the start of register low

		if (nChannelNum == 3)
		{
			m_readCmd[3] = 0x03;
		}
		if (nChannelNum == 4)
		{
			m_readCmd[3] = 0x04;
		}
		if (nChannelNum == 5)
		{
			m_readCmd[3] = 0x05;
		}
	}
	


	unsigned short crc = CheckCalculationTool::GetCRC16Code( m_readCmd, 6 );
	m_readCmd[6] = crc & 0xFF;    // low byte of CRC.zhangyy delete the second  & 0xFF[1.8.0]
	m_readCmd[7] = (crc >> 8) & 0xFF;  //  high byte of CRC

	char response[m_resLen];
	memset(response, 0, m_resLen);
	sendCommandOnly(m_readCmd, 8);
	if(getResultOnly(response,m_resLen, m_timeOut) < 0)
	{
		throw IOException("AIRSYSChiller reading back times out");
	}


	if(response[0] == m_readCmd[0] && response[1] == 0x03)
	{
		if(response[2] == 0x02)
		{
			unsigned char  cByte[4];//save the 32-bite
			int val;
			response[3] = response[3]&0x00ff;
			response[4] = response[4]&0x00ff;
			cByte[0] = response[3];
			cByte[1] = response[4];
			int t_val = (cByte[0] << 8) | cByte[1];
			if(int(cByte[0] & 0x80) == 0x80)  //add by wzd 1.1.48
			{
				t_val -= 65536;
			}
			*pValue = (float)t_val / 10;
			return true;
		}
		else
		{
			throw IOException("AIRSYSChiller reading data false, response is [" + Hex::GetHexString(response,10)+"]");
		}
	}
	else
	{
		throw IOException("AIRSYSChiller:the read data command is invalid, response is [" + Hex::GetHexString(response,10)+"]");
	}
}

bool AIRSYSChiller::readFlow(int nChannelNum, int * pValue ,const IntTypeInfo& typeinfo)
{
	if (m_bDualChannel)
	{
		int nIndex = 0;
		if (nChannelNum > 20)
		{
			nIndex = nChannelNum - 15;//map to array: 21 to 6
		}
		Com com = m_commands[nIndex];

		m_readCmd[2] = 0x00;
		m_readCmd[3] = com.m_addr;
	}
	else
	{
		m_readCmd[2] = 0x00;//the start of register high
		m_readCmd[3] = 0x05;//the start of register low
	}
	

	//CRC16
	unsigned short crc = CheckCalculationTool::GetCRC16Code( m_readCmd, 6 );
	m_readCmd[6] = (crc & 0xFF) & 0xFF;    // low byte of CRC
	m_readCmd[7] = (crc >> 8) & 0xFF;  //  high byte of CRC

	char response[m_resLen];
	memset(response, 0, m_resLen);
	sendCommandOnly(m_readCmd, 8);
	if(getResultOnly(response,m_resLen, m_timeOut) < 0)
	{
		throw IOException("AIRSYSChiller reading back times out");
	}

	if((response[0] == 0x01) && (response[1] == 0x03))
	{
		if(response[2] == 0x02)
		{
			 if(response[3]==0x00 && response[4]==0x00)
			{
				*pValue=0;
			}
			else
			{
				*pValue=1;
			}
			return true;
		}
		else
		{
			throw IOException("AIRSYSChiller reading data false, response is [" + Hex::GetHexString(response,10)+"]");
		}
	}
	else
	{
		throw IOException("Chiller read command failed for unknown response [" + Hex::GetHexString(response,10)+"]");
	}

}

//write Temperature
bool AIRSYSChiller::writeTemperature(int nChannelNum, double dSetTemp, const DoubleTypeInfo& typeinfo)
{
	if (m_bDualChannel)
	{
		int nIndex = 0;
		if (nChannelNum > 20)
		{
			nIndex = nChannelNum - 15;//map to array: 21 to 6
		}
		Com com = m_commands[nIndex];

		m_writeCmd[2] = 0x00;
		m_writeCmd[3] = com.m_addr;
	}
	else
	{
		m_writeCmd[2] = 0x00;
		m_writeCmd[3] = 0x01;
	}
	

	unsigned char floatToHex[2];
	int nChangeSetTemp = round(dSetTemp*10);//[fixed by wangyk 1.4.0]
	char* pChar=(char*) & nChangeSetTemp;
    for(int i=0;i<2;i++)
    {
		floatToHex[i]=*pChar;
		pChar++;
    }

	m_writeCmd[4] = floatToHex[1];
	m_writeCmd[5] = floatToHex[0];

	unsigned short crc = CheckCalculationTool::GetCRC16Code( m_writeCmd, 6 );
	m_writeCmd[6] = 0xff&(crc & 0xff);  // low byte of CRC
	m_writeCmd[7] = 0xff&( crc >> 8);    // high byte of CRC


	//if the write command failed, return error
	char response[m_resLen];
	memset(response, 0, m_resLen);
	sendCommandOnly(m_writeCmd, 8);

	if(getResultOnly(response,m_resLen, m_timeOut) < 0)
	{
		throw IOException("AIRSYSChiller reading back times out");
	}
	//check the key bytes
	if(response[0] == m_writeCmd[0] && response[1] == 0x06)
	{
		return true;
	}
	else
	{
		throw IOException("Chiller write command failed for unknown response [" + Hex::GetHexString(response,10)+"]");
	}

}


//start/stop
bool AIRSYSChiller::writeOnOff(int nChannelNum, int nValue, const IntTypeInfo& typeInfo)
{

	m_writeCmd[2] = 0x00;
	m_writeCmd[3] = 0x00;
	m_writeCmd[4] = 0x00; //added by [liusy 1.1.20]

	if (nValue == 1)
	{
		m_writeCmd[5] = 0x01;
	}
	else
	{
		m_writeCmd[5] = 0x00;
	}

	unsigned short crc = CheckCalculationTool::GetCRC16Code(m_writeCmd, 6);
	m_writeCmd[6] = 0xff & (crc & 0xff);  // low byte of CRCunsigned char ss = 0x96;
	m_writeCmd[7] = 0xff & (crc >> 8);    // high byte of CRC

	char response[m_resLen];
	memset(response, 0, m_resLen);
	sendCommandOnly(m_writeCmd, 8);
	if (getResultOnly(response, m_resLen, m_timeOut) < 0)
	{
		throw IOException("AIRSYSChiller reading back times out");
	}

	//check the key bytes
	if (response[0] == m_writeCmd[0] && response[1] == 0x06)
	{
		return true;
	}
	else
	{
		throw IOException("Chiller write command failed for unknown response [" + Hex::GetHexString(response, 10) + "]");
	}

}

//start/stop
bool AIRSYSChiller::writeDualOnOff(int nChannelNum, int nValue,const IntTypeInfo &typeInfo)
{
	int nIndex = 0, nWriteRegIndex = 0;
	if (nChannelNum > 20)
	{
		nIndex = nChannelNum - 15;//map to array: 21 to 6
	}

	if (nChannelNum == 1)
	{
		nWriteRegIndex = 0;
	}
	else if (nChannelNum == 21 || nChannelNum == 22)
	{
		nWriteRegIndex = 1;
	}
	else
	{
		nWriteRegIndex = 2;
	}



	Com com = m_commands[nIndex];

	m_writeCmd[2] = 0x00;
	m_writeCmd[3] = com.m_addr;
	m_writeCmd[4] = 0x00; //added by [liusy 1.1.20]

	char cSendData = m_pWriteReg[nWriteRegIndex];

	if(nValue==1)
	{
		m_writeCmd[5]= cSendData | (0x01 << com.m_offset) ;
	}
	else
	{
		m_writeCmd[5]= cSendData  & (~(0x01<< com.m_offset));
	}

	unsigned short crc = CheckCalculationTool::GetCRC16Code( m_writeCmd, 6 );
	m_writeCmd[6] =0xff&(crc & 0xff);  // low byte of CRCunsigned char ss = 0x96;
	m_writeCmd[7] = 0xff&( crc >> 8);    // high byte of CRC

	char response[m_resLen];
	memset(response, 0, m_resLen);
	sendCommandOnly(m_writeCmd, 8);
	if(getResultOnly(response,m_resLen, m_timeOut) < 0)
	{
		throw IOException("AIRSYSChiller reading back times out");
	}

	//check the key bytes
	if(response[0] == m_writeCmd[0] && response[1] == 0x06)
	{
		m_pWriteReg[nWriteRegIndex] = m_writeCmd[5];
		return true;
	}
	else
	{
		throw IOException("Chiller write command failed for unknown response [" + Hex::GetHexString(response,10)+"]");
	}

}


//read alarm
bool AIRSYSChiller::readAlarm(int nChannelNum, int * pValue , const IntTypeInfo& typeinfo)
{
	m_readCmd[2] = 0x00;
	m_readCmd[3] = 0x07;


	unsigned short crc = CheckCalculationTool::GetCRC16Code( m_readCmd, 6 );
	m_readCmd[6] = (crc & 0xFF) & 0xFF;    // low byte of CRC
	m_readCmd[7] = (crc >> 8) & 0xFF;  //  high byte of CRC

	char response[m_resLen];
	memset(response, 0, m_resLen);
	sendCommandOnly(m_readCmd, 8);
	if(getResultOnly(response,m_resLen, m_timeOut) < 0)
	{
		throw IOException("AIRSYSChiller reading back times out");
	}

	if((response[0] == 0x01) && (response[1] == 0x03))
	{
		if(response[2] == 0x02)
		{
			int nAlarm=0;
			int nFault=0;
			*pValue=0;

			nAlarm = ((response[4] & (0x01)) != 0x00);
			nFault = ((response[4] & (0x01 << 1)) != 0x00);

			if (nChannelNum == 37 || nChannelNum == 38)
			{
				nAlarm = ((response[4] & (0x01 << 2)) != 0x00);
				nFault = ((response[4] & (0x01 << 3)) != 0x00);
			}

			if(nChannelNum==9 && nAlarm==1)//alarm
			{
				*pValue=1;
			}
			if(nChannelNum==6 && nFault==1)//fault
			{
				*pValue=1;
			}
			if (nChannelNum == 38 && nAlarm == 1)//alarm
			{
				*pValue = 1;
			}
			if (nChannelNum == 37 && nFault == 1)//fault
			{
				*pValue = 1;
			}

			return true;
		}
		else
		{
			throw IOException("AIRSYSChiller reading data false, response is [" + Hex::GetHexString(response,10)+"]");
		}
    }
	else
	{
		throw IOException("Chiller read command failed for unknown response [" + Hex::GetHexString(response,10)+"]");
	}
}

bool AIRSYSChiller::readAlarmInfo(int nChannelNum, std::string * pValue , const StringTypeInfo& typeinfo)
{
	m_readCmd[2] = 0x00;
	m_readCmd[3] = 0x08;

	unsigned short crc = CheckCalculationTool::GetCRC16Code( m_readCmd, 6 );
	m_readCmd[6] = (crc & 0xFF) & 0xFF;    // low byte of CRC
	m_readCmd[7] = (crc >> 8) & 0xFF;  //  high byte of CRC

	char response[m_resLen];
	memset(response, 0, m_resLen);
	sendCommandOnly(m_readCmd, 8);
	if(getResultOnly(response,m_resLen, m_timeOut) < 0)
	{
		throw IOException("AIRSYSChiller reading back times out");
	}

	if((response[0] == 0x01) && (response[1] == 0x03))
	{
		if(response[2] == 0x02)
		{
			int nTemp[8];
			std::string strAlarm="";

			for(int i=0;i<8;i++)
			{
			  nTemp[i]=((response[4]&(0x01<<i))!=0x00);
			  if(nTemp[i]==1)
			  {
				  strAlarm+=m_alarmInfo[i];
				  strAlarm+=" ";
			  }

			}
			*pValue="Chiller Alarm:"+strAlarm;
			return true;
		}
		else
		{
			throw IOException("AIRSYSChiller reading data false, response is [" + Hex::GetHexString(response,10)+"]");
		}
	}
	else
	{
		throw IOException("Chiller read command failed for unknown response [" + Hex::GetHexString(response,10)+"]");
	}
}

//register channel
void AIRSYSChiller::initChs(DeviceNode<AIRSYSChiller> *node)
{
	//single
	node->registerWriteCh(1, &AIRSYSChiller::writeOnOff);
	node->registerWriteCh(2, &AIRSYSChiller::writeTemperature);

	for (int i = 3; i < 6; i++)
	{
		node->registerReadCh(i, &AIRSYSChiller::readDouble);
	}


	//dual
	node->registerWriteCh(21, &AIRSYSChiller::writeDualOnOff);
	node->registerWriteCh(22, &AIRSYSChiller::writeDualOnOff);
	node->registerWriteCh(30, &AIRSYSChiller::writeDualOnOff);
	node->registerWriteCh(29, &AIRSYSChiller::writeDualOnOff);

	node->registerWriteCh(23, &AIRSYSChiller::writeTemperature);
	node->registerWriteCh(31, &AIRSYSChiller::writeTemperature);


	for (int i = 24; i < 28; i++)
	{
		node->registerReadCh(i, &AIRSYSChiller::readDouble);
	}

	node->registerReadCh(28, &AIRSYSChiller::readFlow);

	for (int i = 32; i < 35; i++)
	{
		node->registerReadCh(i, &AIRSYSChiller::readDouble);
	}
	node->registerReadCh(36, &AIRSYSChiller::readFlow);


	//same

	//ch1 single
	node->registerReadCh(6, &AIRSYSChiller::readAlarm); 
	node->registerReadCh(9, &AIRSYSChiller::readAlarm);

	//ch2
	node->registerReadCh(37, &AIRSYSChiller::readAlarm);
	node->registerReadCh(38, &AIRSYSChiller::readAlarm);

	//ch1 single
	node->registerReadCh(11, &AIRSYSChiller::readAlarmInfo);
	node->registerReadCh(10, &AIRSYSChiller::readFlow);

	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &AIRSYSChiller::getStatus);
}
void AIRSYSChiller::initDevice()
{
	cout<<"Start Scan AIRSYSChiller...."<<endl;

	double dTemp;
	try
	{
		readDouble(3,&dTemp,DoubleTypeInfo());
	}
	catch(exception &ex)
	{
		cout<<"Scan AIRSYSChiller failed. Communication abnormal!"<<endl;
		return;
	}
	cout<<"Scan AIRSYSChiller Successfully...."<<endl;
}
//init device
void AIRSYSChiller::init()
{
	DeviceNode<AIRSYSChiller> *node = new DeviceNode<AIRSYSChiller>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	if(!isSimulated())
	{
		initChs(node);
		initDevice();
	}
}

void AIRSYSChiller::setDualChannelEnable(bool bFlag)
{
	m_bDualChannel = bFlag;
}

IMPLEMENT_DYNAMIC(AIRSYSChiller, SerialDevice)

BEGIN_MSG_MAP(AIRSYSChiller, SerialDevice)
	SET_B(setDualChannelEnable, AIRSYSChiller)
	SET_V( init, AIRSYSChiller)
END_MSG_MAP
