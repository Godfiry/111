/******************************************************************************
 * Copyright (C) 2010 by NMC
 * 
 * File: DMC10D.cpp
 *
 * Date: 2008-05-14
 *
 * Author: GaoJianQiang <gaojq@bj-nmc.local>
 *
 * Descriptor:
 *   RS-485 Driver for the DMC10D  Temperature Controller
 *
 * Version: 0.1
 *
 * Modified:
 *
 ******************************************************************************/

/*-----------------------------------------------------------------------------
  System header files 
------------------------------------------------------------------------------*/
#include "DMC10D.h"
#include <string.h>
#include "DeviceManager.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

DMC10D::DMC10D():SerialDevice(200, "")
{
	status_channel = 0;
	alarm_channel = 0;
}

DMC10D::~DMC10D()
{}

/*
*	function name:  int	DMC10checkSum( char * cCommand, int nLen )   
*	description: DMC10 checksum calculate function 
*	parameter: char * cCommand--the string of command 
				int nLen --the string of string 
*	thinking:
*	return: int data for DMC10 checkSum
*/
int DMC10D::DMC10checkSum( char * cCommand, int nLen )
{
    int btSum;
    int i;
    btSum = 0;
    for( i=0; i<nLen; i++ )
    {
	btSum += cCommand[i];
    }
    btSum = -btSum;
    return (btSum & 0xFF);
}

/*************************************************************************************************************
	*	function name:  void	SetCommand( char * cCommand, int  nCmdLen )  
	*	description: ��string���ַ����ȫ��ת��Ϊ��д���
	*	parameter: char * cCommand--the string of command 
					int nLen --the string of string 
	*	thinking:
	*	return: void

*****************************************************************************************************************/
void DMC10D::SetCommand( char * cCommand, int  nCmdLen )
{
    int i;
    for( i=0; i<nCmdLen; i++ )
    {
	if( cCommand[i] >= 'a' && cCommand[i] <= 'f' )
	    cCommand[i] = cCommand[i] - 32;
    }
}

/*
 * compose the command message to be send to the device base on the given value and append crc in the end.
 * ��϶�дPVֵ�Ŀ����ַ�
 */

/************************************************************************************************************************************
	*	description: DMC10 read tempature   
	*   notes :          channel1 address         channel2 address     channel 3 address           dataFormat
                                          1004                      1005                     1006                  float
	*	description: DMC10 setpoint operation  
    *	notes :          channel1 address         channel2 address     channel 3 address      channel 4 address     dataFormat
	          SP Value:      1008                     1009                   1010                    1011			 float   

*************************************************************************************************************************************/
void DMC10D::ComposeMessage(int flag, int index, double value, char *buff)
{
    int iTempSpValue = 0;
    int nLen = 0;
    int nCmdLen = 0;
    int btCheck = 0;
    int iAddress = 0;
    
    iAddress = 1003 + index;
    if (index == 10)
	iAddress = 1001 ;


    buff[0] = 0x02;		/*STX*/
    sprintf( buff+1, "%02x", 0x04);/*mainStation address is 4*/
    sprintf( buff+3, "%02x", 0 );  /*substation address is 0  */
    buff[5]=0x58;
    double tmp = 0;
    double tmp1 = 0;
    switch(flag)
    {
	    case WRITE:
			//iTempSpValue = (int)(value*10);
			tmp = (double)(value*10);//modified by  chenmz [V2.0.4]
			tmp1 = (int)tmp;
			iTempSpValue = tmp1;
			sprintf(buff+6, "WS,%dW,%d", iAddress,iTempSpValue);
			nLen = strlen(buff);
			buff[nLen] = 0x03;
			btCheck = DMC10checkSum( buff, nLen + 1 );
			sprintf( buff + 1 + nLen, "%02x", btCheck );
			
			buff[3 + nLen] = 0x0D;		//�����־
			buff[4 + nLen] = 0x0A;
			buff[5 + nLen] = 0;
			nCmdLen = 5 + nLen;
			SetCommand( buff, nCmdLen );//Сд���д
			break;
	    case READ:
			sprintf(buff+6, "RS,%dW,%d", iAddress,1);
			nLen = strlen(buff);
			buff[nLen] = 0x03;	
			btCheck = DMC10checkSum( buff, nLen + 1 );
			sprintf( buff + 1 + nLen, "%02x", btCheck );
			
			buff[3 + nLen] = 0x0D;			//�����־
			buff[4 + nLen] = 0x0A;
			buff[5 + nLen] = 0;
			nCmdLen = 5 + nLen;
			SetCommand( buff, nCmdLen );//Сд���д
			break;
	    default:
			break;
    } /*end of switch(flag)*/
}

/************************************************************************************************************************************
	*	description: DMC10 ComposeInputTypeMessage (���DMC10D��������Э�鴮)
	*   notes :          channel1 address         channel2 address     channel 3 address          channel 4 address dataFormat
                              3405                      3423                     3441                  3459			float
	*	 
*************************************************************************************************************************************/
void DMC10D::ComposeInputTypeMessage(int flag,int nChanNum, int nType, char *buff)
{
    int nLen = 0;
    int nCmdLen = 0;
    int btCheck = 0;
    int iAddress = 0;
    
    iAddress = 3405 + (nChanNum - 1)* 18;
    
    buff[0] = 0x02;		/*STX*/
    sprintf( buff+1, "%02x", 0x04);/*mainStation address is 4*/
    sprintf( buff+3, "%02x", 0 );  /*substation address is 0  */
    buff[5]=0x58;
    
    switch (flag)
    {
    case WRITE:
	sprintf(buff+6, "WS,%dW,%d", iAddress,nType);
	nLen = strlen(buff);
	buff[nLen] = 0x03;
	btCheck = DMC10checkSum( buff, nLen + 1 );
	sprintf( buff + 1 + nLen, "%02x", btCheck );
	
	buff[3 + nLen] = 0x0D;		//�����־
	buff[4 + nLen] = 0x0A;
	buff[5 + nLen] = 0;
	nCmdLen = 5 + nLen;
	SetCommand( buff, nCmdLen );//Сд���д
	break;
    case READ:
	sprintf(buff+6, "RS,%dW,%d", iAddress,1);
	nLen = strlen(buff);
	buff[nLen] = 0x03;	
	btCheck = DMC10checkSum( buff, nLen + 1 );
	sprintf( buff + 1 + nLen, "%02x", btCheck );
	
	buff[3 + nLen] = 0x0D;			//�����־
	buff[4 + nLen] = 0x0A;
	buff[5 + nLen] = 0;
	nCmdLen = 5 + nLen;
	SetCommand( buff, nCmdLen );//Сд���д
	break;
    default:
	break;
    } /*end of switch(flag)*/
}

/************************************************************************************************************************************
	*	description: DMC10 ComposePointMessage (���DMC10DС������Э�鴮)
	*   notes :          channel1 address         channel2 address     channel 3 address          channel 4 address dataFormat
                              3405                      3423                     3441                  3459			float
	*	 
*************************************************************************************************************************************/
void DMC10D::ComposePointMessage(int flag,int nChanNum, int decPoint,char *buff)
{
    int nLen = 0;
    int nCmdLen = 0;
    int btCheck = 0;
    int iAddress = 0;
    
    iAddress = 3406 + (nChanNum - 1)* 18;
    
    
    buff[0] = 0x02;		/*STX*/
    sprintf( buff+1, "%02x", 0x04);/*mainStation address is 4*/
    sprintf( buff+3, "%02x", 0 );  /*substation address is 0  */
    buff[5]=0x58;
    
    switch (flag)
    {
	    case WRITE:
			sprintf(buff+6, "WS,%dW,%d", iAddress,decPoint);
			nLen = strlen(buff);
			buff[nLen] = 0x03;
			btCheck = DMC10checkSum( buff, nLen + 1 );
			sprintf( buff + 1 + nLen, "%02x", btCheck );
			
			buff[3 + nLen] = 0x0D;		//�����־
			buff[4 + nLen] = 0x0A;
			buff[5 + nLen] = 0;
			nCmdLen = 5 + nLen;
			SetCommand( buff, nCmdLen );//Сд���д
			break;
	    case READ:
			sprintf(buff+6, "RS,%dW,%d", iAddress,1);
			nLen = strlen(buff);
			buff[nLen] = 0x03;	
			btCheck = DMC10checkSum( buff, nLen + 1 );
			sprintf( buff + 1 + nLen, "%02x", btCheck );
			
			buff[3 + nLen] = 0x0D;			//�����־
			buff[4 + nLen] = 0x0A;
			buff[5 + nLen] = 0;
			nCmdLen = 5 + nLen;
			SetCommand( buff, nCmdLen );//Сд���д
			break;
	    default:
			break;
    } /*end of switch(flag)*/
}

/************************************************************************************************************************************
	*	description: DMC10 ComposeInputTypeMessage (���DMC10D����ʽ����Э�鴮)
	*   notes :          channel1 address         channel2 address     channel 3 address          channel 4 address dataFormat
                              3415                                                        		float
	*	 
*************************************************************************************************************************************/
void DMC10D::ComposeTurnMessage(int flag,int nChanNum, int mode,char *buff)
{
    int nLen = 0;
    int nCmdLen = 0;
    int btCheck = 0;
    int iAddress = 0;
    
    iAddress = 3415 + (nChanNum - 1)* 18;
    
    
    buff[0] = 0x02;		/*STX*/
    sprintf( buff+1, "%02x", 0x04);/*mainStation address is 4*/
    sprintf( buff+3, "%02x", 0 );  /*substation address is 0  */
    buff[5]=0x58;
    
    switch (flag)
    {
		case WRITE:
			sprintf(buff+6, "WS,%dW,%d", iAddress,mode);
			nLen = strlen(buff);
			buff[nLen] = 0x03;
			btCheck = DMC10checkSum( buff, nLen + 1 );
			sprintf( buff + 1 + nLen, "%02x", btCheck );
			
			buff[3 + nLen] = 0x0D;		//�����־
			buff[4 + nLen] = 0x0A;
			buff[5 + nLen] = 0;
			nCmdLen = 5 + nLen;
			SetCommand( buff, nCmdLen );//Сд���д
			break;
	    case READ:
			sprintf(buff+6, "RS,%dW,%d", iAddress,1);
			nLen = strlen(buff);
			buff[nLen] = 0x03;	
			btCheck = DMC10checkSum( buff, nLen + 1 );
			sprintf( buff + 1 + nLen, "%02x", btCheck );
			
			buff[3 + nLen] = 0x0D;			//�����־
			buff[4 + nLen] = 0x0A;
			buff[5 + nLen] = 0;
			nCmdLen = 5 + nLen;
			SetCommand( buff, nCmdLen );//Сд���д
			break;
	    default:
			break;
    } /*end of switch(flag)*/
}

/************************************************************************************************************************************
	*	description: DMC10 ComposeInputTypeMessage (���DMC10D����ʽ����Э�鴮)
	*   notes :          channel1 address         channel2 address     channel 3 address          channel 4 address dataFormat
                              3301                                                        		float
	*	 
*************************************************************************************************************************************/
void DMC10D::ComposeModeMessage(int flag,int nChanNum, int mode, char *buff)
{
    int nLen = 0;
    int nCmdLen = 0;
    int btCheck = 0;
    int iAddress = 0;
    
    iAddress = 3301 + (nChanNum - 1)* 12;
    
    
    buff[0] = 0x02;		/*STX*/
    sprintf( buff+1, "%02x", 0x04);/*mainStation address is 4*/
    sprintf( buff+3, "%02x", 0 );  /*substation address is 0  */
    buff[5]=0x58;
    
    switch (flag)
    {
	    case WRITE:
			sprintf(buff+6, "WS,%dW,%d", iAddress,mode);
			nLen = strlen(buff);
			buff[nLen] = 0x03;
			btCheck = DMC10checkSum( buff, nLen + 1 );
			sprintf( buff + 1 + nLen, "%02x", btCheck );
			
			buff[3 + nLen] = 0x0D;		//�����־
			buff[4 + nLen] = 0x0A;
			buff[5 + nLen] = 0;
			nCmdLen = 5 + nLen;
			SetCommand( buff, nCmdLen );//Сд���д
			break;
	    case READ:
			sprintf(buff+6, "RS,%dW,%d", iAddress,1);
			nLen = strlen(buff);
			buff[nLen] = 0x03;	
			btCheck = DMC10checkSum( buff, nLen + 1 );
			sprintf( buff + 1 + nLen, "%02x", btCheck );
			
			buff[3 + nLen] = 0x0D;			//�����־
			buff[4 + nLen] = 0x0A;
			buff[5 + nLen] = 0;
			nCmdLen = 5 + nLen;
			SetCommand( buff, nCmdLen );//Сд���д
			break;
	    default:
			break;
    } /*end of switch(flag)*/
}

/*
 * send a message to the device, and wait for the response...
 *   retries up to XXX times before abandoning hope....
 *   sets status channel to ONLINE or OFFLINE if response is received or not.
 */
bool DMC10D::SendMsg(char * Message, char * Response, int msg_type)
{
    int len;

    /* clear all input characters waiting to be read;
       if there was data cleared, then wait a bit, and try again */
    while ((len = m_dev.readStr(Response,1, MAX_MESSAGE_LEN)) > 0)
    {
		usleep(30*1000);
    }
    if (msg_type == WRITE)
    {
		m_dev.writeRaw(Message, write_message_length);
    }
    else
    {
		m_dev.writeRaw(Message, read_message_length);
    }
    
    usleep(30*1000);
    
    if (msg_type == READ)
    {
		len = m_dev.readStr(Response, 20,receive_message_length);
		
		//Modified the response data length.
		if (len < receive_message_length -1) 
		{
		    status_channel = OFFLINE;
		    return false;   
		}
    }
    
    status_channel = ONLINE;
    return true;
}

bool DMC10D::WriteCt(int channnelNum, double setpt ,const DoubleTypeInfo& typeinfo)
{
    char Message[MAX_MESSAGE_LEN];
    char Response[MAX_MESSAGE_LEN];
    
    memset(Message,0,sizeof(Message));
    memset(Response,0,sizeof(Response));

    ComposeMessage(WRITE, channnelNum, setpt, Message);
    return (SendMsg( Message, Response, WRITE));
}

bool DMC10D::ReadCt(int channelNum, double *value ,const DoubleTypeInfo& typeinfo)
{
    int	nPos[50];
    int	nComma = 0;
    int nLen = 0;
    int i = 0;
    char chTemp[20] = {0};
    int nData = 0;
    
    char Message[MAX_MESSAGE_LEN] = {0};
    char Response[MAX_MESSAGE_LEN] = {0};
    
    memset( nPos, 0, sizeof(nPos) );
    
    ComposeMessage(READ,channelNum,0,Message);
    
    if (SendMsg( Message, Response, READ))
    {
	/*add the code of parse response */
	nLen=strlen(Response);
	for( i=0; i<nLen; i++ )   /* calculate the Num of ","*/
	{
	    if( Response[i] == ',' || Response[i] == 0x03 )
	    {
		nPos[nComma] = i;
		nComma ++ ;
	    }
	}
	memcpy( chTemp, Response +nPos[0]+ 1, 4 );
	sscanf( chTemp, "%d", &nData);
	*value = (double ) nData/10;
	return true;
    } 
    return false;
}

bool DMC10D::ReadADt(int channelNum, int *value ,const IntTypeInfo& typeinfo)
{
    int	nPos[50];
    int	nComma = 0;
    int nLen = 0;
    int i = 0;

    char chTemp[20] = {0};
    int nData;
    
    char Message[MAX_MESSAGE_LEN] = {0};
    char Response[MAX_MESSAGE_LEN] = {0};

    memset( nPos, 0, sizeof(nPos) );
    
    ComposeMessage(READ,channelNum,0,Message);
    
    if (SendMsg( Message, Response, READ))
    {
	/*add the code of parse response */
	nLen=strlen(Response);
	for( i=0; i<nLen; i++ )   /* calculate the Num of ","*/
	{
	    if( Response[i] == ',' || Response[i] == 0x03 )
	    {
		nPos[nComma] = i;
		nComma ++ ;
	    }
	}
	memcpy( chTemp, Response +nPos[0]+ 1, 4 );
	sscanf( chTemp, "%d", &nData);
	
	if (nData & 0x700 )
	    alarm_channel = 1;
	else 
	    alarm_channel = 0;
	
	*value = alarm_channel;
	return true;
    } 
    return false;	
}

bool DMC10D::ReadStatus(int channelNum, int *value ,const IntTypeInfo& typeinfo)
{
	if(channelNum == 9)
	{
		*value = status_channel;
		return true;
	}
	else 
		return false;
}
void DMC10D::initDMC10Config()
{
    char Message[MAX_MESSAGE_LEN] = {0};
    char Response[MAX_MESSAGE_LEN] = {0};
    ComposeInputTypeMessage(WRITE, 1, 3, Message);
    SendMsg( Message, Response, WRITE);
    usleep(30*1000);
    
    ComposeInputTypeMessage(WRITE, 2, 3, Message);
    SendMsg( Message, Response, WRITE);
    usleep(30*1000);
    ComposeInputTypeMessage(WRITE, 3, 3, Message);
    SendMsg( Message, Response, WRITE);
    usleep(30*1000);
	
    ComposeInputTypeMessage(WRITE, 4, 6, Message);
    SendMsg( Message, Response, WRITE);
    usleep(30*1000);
    
    ComposePointMessage(WRITE,1,1,Message);
    SendMsg( Message, Response, WRITE);
    usleep(30*1000);
    ComposePointMessage(WRITE,2,1,Message);
    SendMsg( Message, Response, WRITE);
    usleep(30*1000);
    
    ComposePointMessage(WRITE,3,1,Message);
    SendMsg( Message, Response, WRITE);
    usleep(30*1000);
    
    ComposePointMessage(WRITE,4,1,Message);
    SendMsg( Message, Response, WRITE);
    usleep(30*1000);
    ComposeModeMessage(WRITE,1,2,Message);
    SendMsg( Message, Response, WRITE);
    usleep(30*1000);
    
    ComposeModeMessage(WRITE,2,2,Message);
    SendMsg( Message, Response, WRITE);
    usleep(30*1000);
    
    ComposeModeMessage(WRITE,3,2,Message);
    SendMsg( Message, Response, WRITE);
    usleep(30*1000);
    
    ComposeModeMessage(WRITE,4,2,Message);
    SendMsg( Message, Response, WRITE);
    usleep(30*1000);
}

void DMC10D::InitDMC10D()
{
    status_channel = ONLINE;
}

void DMC10D::InitChannels(DeviceNode<DMC10D> *node)
{
    for(int i=1; i<=4; i++)
    {
		node->registerReadCh(i,&DMC10D::ReadCt);
    }
	
    for(int i=5; i<=8; i++)
    {
		node->registerWriteCh(i,&DMC10D::WriteCt);
    }
	
    node->registerReadCh(9,&DMC10D::ReadStatus);
    node->registerReadCh(10,&DMC10D::ReadADt);
	status_channel = ONLINE;
	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &DMC10D::getStatus);//added by mujy [v1.0.8]
}

void DMC10D::init()
{
    DeviceNode<DMC10D> *node = new DeviceNode<DMC10D>(200,this);
    InitChannels(node);
    DeviceManager::getInstance()->registerNode(m_nodeNum, node);

    InitDMC10D();

    if (isSet && !isSimulated())
    {
    	initDMC10Config();
    }
}

void DMC10D::setParam(bool IsSet)
{
    isSet = IsSet;
}



IMPLEMENT_DYNAMIC(DMC10D, SerialDevice )
BEGIN_MSG_MAP(DMC10D, SerialDevice )
    SET_V( init, DMC10D )
    SET_B( setParam,DMC10D)
END_MSG_MAP
