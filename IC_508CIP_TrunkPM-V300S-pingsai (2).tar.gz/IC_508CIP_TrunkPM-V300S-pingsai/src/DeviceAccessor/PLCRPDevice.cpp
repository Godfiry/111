/********************************************************************
** Copyright (c) 2019 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: PLCRPDevice.h
** Description:  
** Release: 1.0
** Modification history:           
** 					2020-12-28   Duq create
**                                                 
*********************************************************************/

#include "PLCRPDevice.h"
#include <string.h>
#include <cmath>
#include <sys/time.h>
#include <iostream>
#ifdef IAP4_0
using namespace IAP;
#endif

using namespace std;

PLCRPDevice::PLCRPDevice()
{
    RFMaxSetVoltage = 0;	
}

PLCRPDevice::~PLCRPDevice()
{ 

}

bool PLCRPDevice::readDoubleAI(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	if (isSimulated())
	{
		return true;
	}
	bool result;
	int temp = 0;
	float tempvalue = 0.0;
	miter it = m_mapAIAOInfo.find(channelNum);
	
	if(it == m_mapAIAOInfo.end())
	{
		return false;
	}
	else
	{
		int addr = m_mapAIAOInfo[channelNum].startAddr * 2 + m_StatusWordSize;
		result = m_eip->getBytesInputsData(addr, m_mapAIAOInfo[channelNum].addrLength * 2, (void *)&temp);//word
		
		if(!result)
		{
			return false;
		}
		
		if(m_mapAIAOInfo[channelNum].maxBinaryValue == 1)
		{
			tempvalue = (float)temp;
		}
		else if(m_mapAIAOInfo[channelNum].maxBinaryValue > 1)
		{
			if((m_mapAIAOInfo[channelNum].maxBinaryValue == 10) || (m_mapAIAOInfo[channelNum].maxBinaryValue == 100) || (m_mapAIAOInfo[channelNum].maxBinaryValue == 1000))
			{
				if((m_plcname == "PMPLC") && (channelNum == 177))
				{
					tempvalue = ((float)temp)/m_mapAIAOInfo[channelNum].maxBinaryValue - 100;
				}
				else if((m_plcname == "ASSCPLC") && ((channelNum == 344) || (channelNum == 352)))
				{
					tempvalue = ((float)temp)/m_mapAIAOInfo[channelNum].maxBinaryValue - 100;
				}
				else
				{
					tempvalue = ((float)temp)/m_mapAIAOInfo[channelNum].maxBinaryValue;
				}
				if(m_plcname == "PMPLC")
				{
					if((channelNum == 342)||(channelNum == 343))
					{
						if(tempvalue > 3276.8)
						{
							tempvalue = tempvalue - 6553.6;
						}
					}
					
				}
                else if(m_plcname == "ASSCPLC")
                {
                    if((channelNum == 347)||(channelNum == 355))
					{
						if(tempvalue > 3276.8)
						{
							tempvalue = tempvalue - 6553.6;
						}
					}
                }
			}
			else
			{
				if(m_plcname == "TMPLC")
				{
					tempvalue = (((float)temp) / m_mapAIAOInfo[channelNum].maxBinaryValue) * (m_mapAIAOInfo[channelNum].max - m_mapAIAOInfo[channelNum].min) + m_mapAIAOInfo[channelNum].min;
				}
				else
				{
				    tempvalue = (((float)temp) / m_mapAIAOInfo[channelNum].maxBinaryValue) * (m_mapAIAOInfo[channelNum].max - m_mapAIAOInfo[channelNum].min) + m_mapAIAOInfo[channelNum].min;
				}
			}
		}
		else// read float data --- PLC real class
		{
		    memcpy(&tempvalue, &temp, 4);
			if(m_plcname == "PMPLC")
    	    {
			    if(channelNum == 289)
                {
					 tempvalue = tempvalue/10;
                }
			    else if(channelNum == 290)
                {
					 tempvalue = tempvalue/100;
                }
		    }
  		    else if(m_plcname == "ASSCPLC")
		    {
			    if(channelNum == 395)
				{
					 tempvalue = tempvalue/100;
				}
				else if(channelNum == 396)
				{
					 tempvalue = tempvalue/100;
				}
		    }
		}
		
		if(tempvalue < typeInfo.getMin())
		{
			*value = typeInfo.getMin();	
		}
		else if(tempvalue > typeInfo.getMax())
		{
			*value = typeInfo.getMax();
		}
		else
		{
			*value = (double)tempvalue;
		}
		
		setDoubleValue(channelNum + MONITORDOUBLEVALUEADDMAP, *value, typeInfo.getAccuracy());//[zhangcx v1.5.0]
		return true;
	}
}

bool PLCRPDevice::readDoubleAIWithOffSet(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	if (isSimulated())
	{
		return true;
	}
	bool result;
	int temp = 0;
	double tempvalue = 0.0;
	miter it = m_mapAIAOInfo.find(channelNum);
	
	if(it == m_mapAIAOInfo.end())
	{
		return false;
	}
	else
	{
		int addr = m_mapAIAOInfo[channelNum].startAddr * 2 + m_StatusWordSize;
		result = m_eip->getBytesInputsData(addr, m_mapAIAOInfo[channelNum].addrLength * 2, (void *)&temp);//word
		
		if(!result)
		{
			return false;
		}
		
		if(m_mapAIAOInfo[channelNum].maxBinaryValue == 1)
		{
			tempvalue = (double)temp;
            if(m_plcname == "PMPLC")
            {
			    if((channelNum == 139) || (channelNum == 140))//UpperCoolingFanSpeedAI, LowerCoolingFanSpeedAI
			    {
				    if(tempvalue > 50)
				    {
					    tempvalue += m_mapAIAOInfo[channelNum].offset2;
				    }
				    else
				    {
					    tempvalue += m_mapAIAOInfo[channelNum].offset1;
				    }
			    }
			    else
			    {
				    tempvalue += m_mapAIAOInfo[channelNum].offset1;
			    }
            }
            else
            {
                tempvalue += m_mapAIAOInfo[channelNum].offset1;
            }
		}
		else
		{
			if((m_mapAIAOInfo[channelNum].maxBinaryValue == 10) || (m_mapAIAOInfo[channelNum].maxBinaryValue == 100) || (m_mapAIAOInfo[channelNum].maxBinaryValue == 1000))
			{
				tempvalue = ((double)temp)/m_mapAIAOInfo[channelNum].maxBinaryValue;
				tempvalue += m_mapAIAOInfo[channelNum].offset1;
			}
			else
			{
                if(m_plcname == "PMPLC")
                {
				    if(channelNum == 137)//DomeDualSealPressureAI
				    {
					    tempvalue = -(((double)temp)/m_mapAIAOInfo[channelNum].maxBinaryValue) *(m_mapAIAOInfo[channelNum].max - m_mapAIAOInfo[channelNum].min) + m_mapAIAOInfo[channelNum].max;
					    if(tempvalue > -90)
					    {
						    tempvalue += m_mapAIAOInfo[channelNum].offset2;
					    }
					    else
					    {
						    tempvalue += m_mapAIAOInfo[channelNum].offset1;
					    }
				    }
				    else if(channelNum == 138)//DomeN2PressureAI
				    {
					    tempvalue = ((((double)temp)/m_mapAIAOInfo[channelNum].maxBinaryValue) *(4.5+0.5)-0.5)*145;//MPa->psi
					    if(tempvalue > 80)
					    {
						    tempvalue += m_mapAIAOInfo[channelNum].offset2;
					    }
					    else
					    {
						    tempvalue += m_mapAIAOInfo[channelNum].offset1;
					    }
				    }
				    else if((channelNum >= 162)&&(channelNum <= 165))//WaterFlow
				    {
					    tempvalue = (((double)temp -3276) / (m_mapAIAOInfo[channelNum].maxBinaryValue-3276)) * (m_mapAIAOInfo[channelNum].max - m_mapAIAOInfo[channelNum].min) + m_mapAIAOInfo[channelNum].min;
					    tempvalue += m_mapAIAOInfo[channelNum].offset1;
				    }
				    else//PT
				    {
					    tempvalue = (((double)temp) / m_mapAIAOInfo[channelNum].maxBinaryValue) * (m_mapAIAOInfo[channelNum].max - m_mapAIAOInfo[channelNum].min) + m_mapAIAOInfo[channelNum].min;
					    tempvalue += m_mapAIAOInfo[channelNum].offset1;
				    }	
                }
                else if(m_plcname == "ASSCPLC")
                {                  
				    if((channelNum == 320) || (channelNum == 321) || (channelNum == 322))//N2PressureAI NF3PressureAI CDAPressureAI
				    {
					    /*tempvalue = ((((double)temp)/m_mapAIAOInfo[channelNum].maxBinaryValue) *(2.0+0.1)-0.1)*145;//MPa->psi
                        tempvalue += m_mapAIAOInfo[channelNum].offset1;*/
                        tempvalue = ((((double)temp)/m_mapAIAOInfo[channelNum].maxBinaryValue) *(m_mapPTmax[channelNum] - m_mapPTmin[channelNum]) + m_mapPTmin[channelNum])*145;//MPa->psi
                        tempvalue += m_mapAIAOInfo[channelNum].offset1;
				    }
				    /*else if(channelNum == 321)//NF3PressureAI
				    {
					    tempvalue = (((double)temp)/m_mapAIAOInfo[channelNum].maxBinaryValue) *0.5*145;//MPa->psi
                        tempvalue += m_mapAIAOInfo[channelNum].offset1;
				    }
				    else if(channelNum == 322)//CDAPressureAI
				    {
					    tempvalue = ((((double)temp)/m_mapAIAOInfo[channelNum].maxBinaryValue) *(1.0+0.1)-0.1)*145;//MPa->psi
                        tempvalue += m_mapAIAOInfo[channelNum].offset1;
				    }*/
                }
			}
		}
		
		if(tempvalue < typeInfo.getMin())
		{
			*value = typeInfo.getMin();	
		}
		else if(tempvalue > typeInfo.getMax())
		{
			*value = typeInfo.getMax();
		}
		else
		{
			*value = tempvalue;
		}
		return true;
	}
}

bool PLCRPDevice::writeDoubleAO(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
	if (isSimulated())
	{
		return true;
	}
	bool result;
	int temp = 0;

	miter it = m_mapAIAOInfo.find(channelNum);
	if(it==m_mapAIAOInfo.end())
	{
		return false;
	}
	else
	{
		int addr = m_mapAIAOInfo[channelNum].startAddr * 2 + m_StatusWordSize;
		if(m_mapAIAOInfo[channelNum].maxBinaryValue == 1)
		{
			temp = (int)value;
		}
		else
		{
			if((m_plcname == "PMPLC") && (m_mapAIAOInfo[channelNum].min == -500))
			{
				value = (value + 500) * m_mapAIAOInfo[channelNum].maxBinaryValue;
				temp = (int)value;
			}
			else
			{
				if((m_mapAIAOInfo[channelNum].maxBinaryValue == 10) || (m_mapAIAOInfo[channelNum].maxBinaryValue == 100) || (m_mapAIAOInfo[channelNum].maxBinaryValue == 1000))
				{
					if((m_plcname == "PMPLC") && ((channelNum == 2048) || (channelNum == 2049) || (channelNum == 2050) || (channelNum == 2122) || (channelNum == 2123) || (channelNum == 2124)))
				    {
						value = value + 100;
					}
					else if((m_plcname == "TMPLC") && (((channelNum >= 1093) && (channelNum <= 1095)) || ((channelNum >= 1100) && (channelNum <= 1102))))
					{
						value = value + 100;
					}
					else if((m_plcname == "ASSCPLC") && (((channelNum >= 2011) && (channelNum <= 2016)) || ((channelNum >= 2025) && (channelNum <= 2030))))
					{
						value = value + 100;
					}
					value = value * m_mapAIAOInfo[channelNum].maxBinaryValue;
					temp = ((int)(value*10))/10;
				}
				else		
				{
					value = (value / (m_mapAIAOInfo[channelNum].max - m_mapAIAOInfo[channelNum].min)) * m_mapAIAOInfo[channelNum].maxBinaryValue + 0.5;
					temp = (int)value;
				}
			}
		}
		result = m_eip->setBytesOutputsData(addr, m_mapAIAOInfo[channelNum].addrLength * 2, (void *)&temp, true);//word
		return result;
	}
}

bool PLCRPDevice::writeRFVoltageAO(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
    if (isSimulated())
	{
		return true;
	}

	ReadWriteDouble* cfgRFMaxSetVoltage  = dynamic_cast<ReadWriteDouble*>(ObjectManager::getInstance()->getObject("/SETUP/"+ m_moduleName +"/ALCRFControl/cfgRFMaxSetVoltage"));
	if(cfgRFMaxSetVoltage != NULL)
	{
		RFMaxSetVoltage = cfgRFMaxSetVoltage->getValue();
	}
	
	bool result;
	int temp = 0;

	miter it = m_mapAIAOInfo.find(channelNum);
	if(it==m_mapAIAOInfo.end())
	{
		return false;
	}
	else
	{
		if(value > RFMaxSetVoltage)
        {
            throw IOException("PLCRPDevice["+getName()+"]::writeRFVoltageAO("+Converter::convertToString(channelNum)+"):RF set value is "+ Converter::convertToString(value) +",it is large than max set value " +Converter::convertToString(RFMaxSetVoltage) +"!");
        }
		
		int addr = m_mapAIAOInfo[channelNum].startAddr * 2 + m_StatusWordSize;
		if(m_mapAIAOInfo[channelNum].maxBinaryValue == 1)
		{
			temp = (int)value;
		}
		else
		{
		    if((m_mapAIAOInfo[channelNum].maxBinaryValue == 10) || (m_mapAIAOInfo[channelNum].maxBinaryValue == 100) || (m_mapAIAOInfo[channelNum].maxBinaryValue == 1000))
		    {
			    value = value * m_mapAIAOInfo[channelNum].maxBinaryValue;
			    temp = ((int)(value*10))/10;
	        }
		    else		
		    {
			    value = (value / (m_mapAIAOInfo[channelNum].max - m_mapAIAOInfo[channelNum].min)) * m_mapAIAOInfo[channelNum].maxBinaryValue + 0.5;
			    temp = (int)value;
		    }
		}
		result = m_eip->setBytesOutputsData(addr, m_mapAIAOInfo[channelNum].addrLength * 2, (void *)&temp, true);//word
		return result;
	}
}

void PLCRPDevice::initChs(DeviceNode<PLCRPDevice> *node)
{
	for(int i = 0; i < m_DIChsSize; ++i)
	{
		node->registerReadCh(i + m_DIStartCh, &PLCRPDevice::readBit);
	}
	
	for(int i = 0; i < m_DOChsSize; ++i)
	{
		node->registerWriteCh(i + m_DOStartCh, &PLCRPDevice::writeBit);
	}
	
	for(int i = 0; i < m_MFCOnlineChsSize; ++i)
	{
		node->registerReadCh(i + m_MFCOnlineStartCh, &PLCRPDevice::readBit);
	}
	
	for(int i = 0; i < m_IntlkDIChsSize; ++i)
	{
		node->registerReadCh(i + m_IntlkDIStartCh, &PLCRPDevice::readBit);
	}
	
	for(int i = 0; i < m_IntlkDOChsSize; ++i)
	{
		node->registerWriteCh(i + m_IntlkDOStartCh, &PLCRPDevice::writeBit);
	}
	
	for(int i = 0; i < m_DevNetDIChsSize1; ++i)
	{
		node->registerReadCh(i + m_DevNetDIStartCh1, &PLCRPDevice::readBit);
	}

	for(int i = 0; i < m_DevNetDIChsSize2; ++i)
	{
		node->registerReadCh(i + m_DevNetDIStartCh2, &PLCRPDevice::readBit);
	}
	
	for(int i = 0; i < m_DevNetDOChsSize; ++i)
	{
		node->registerWriteCh(i + m_DevNetDOStartCh, &PLCDevice::writeBit);
	}

	map<int,AIAOInfo>::iterator it;
    for(it = m_mapAIAOInfo.begin(); it != m_mapAIAOInfo.end(); ++it)
	{
		if (strcmp((m_mapAIAOInfo[it->first].mode).c_str(),"RW")==0)
		{
			if (strcmp((m_mapAIAOInfo[it->first].type).c_str(),"I")==0)
			{
				node->registerWriteCh(m_mapAIAOInfo[it->first].channelNum, &PLCRPDevice::writeIntAO);
			} 
			else
			{
				if((m_plcname == "PMPLC") && (m_mapAIAOInfo[it->first].channelNum == 2085))//UpperCoolingFanCtrlTempAO
				{
					node->registerWriteCh(m_mapAIAOInfo[it->first].channelNum, &PLCRPDevice::writeDomeTempAO);
				}
                else if((m_plcname == "ASSCPLC") && (m_mapAIAOInfo[it->first].channelNum == 2000))//RFVoltageAO
                {
                    node->registerWriteCh(m_mapAIAOInfo[it->first].channelNum, &PLCRPDevice::writeRFVoltageAO);
                }
				else
				{
					node->registerWriteCh(m_mapAIAOInfo[it->first].channelNum, &PLCRPDevice::writeDoubleAO);
				}
			}	
		} 
		else
		{
			if (strcmp((m_mapAIAOInfo[it->first].type).c_str(),"I")==0)
			{
				node->registerReadCh(m_mapAIAOInfo[it->first].channelNum, &PLCRPDevice::readIntAI);
			} 
			else
			{
				if(m_mapAIAOInfo[it->first].offsetFlag == true)
				{
					node->registerReadCh(m_mapAIAOInfo[it->first].channelNum, &PLCRPDevice::readDoubleAIWithOffSet);
				}
				else
				{
					if((m_plcname == "PMPLC") && (m_mapAIAOInfo[it->first].channelNum == 208))//DomeTempAI
					{
						node->registerReadCh(m_mapAIAOInfo[it->first].channelNum, &PLCRPDevice::readDomeTempAI);
					}
					else
					{
						node->registerReadCh(m_mapAIAOInfo[it->first].channelNum, &PLCRPDevice::readDoubleAI);
						node->registerReadCh(m_mapAIAOInfo[it->first].channelNum + MONITORDOUBLEVALUEADDMAP, &CMonitorDoubleValue::readDoubleChange);//[zhangcx v1.5.0]
						initDoubleValue(m_mapAIAOInfo[it->first].channelNum + MONITORDOUBLEVALUEADDMAP, -1);//[zhangcx v1.5.0]
					}
				}
			}	
		}		
	}
}

void PLCRPDevice::init()
{
	string error = "";
	if(m_nodeNum < 0)
	{
		error = "node number illegal, m_server is " + m_server;
		throw ConfigException(error);
	}	
	if(!isSimulated())
	{
		m_eip = EIPApplication::getEIP(m_server, m_configInstanceId, m_inputInstanceId, m_outputInstanceId, m_cycleTime, error);
		if(m_eip == NULL)
			throw ConfigException(error);
	}
	DeviceNode<PLCRPDevice> * node = new DeviceNode<PLCRPDevice>(m_pollInterval,this);
	initChs(node);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
}


IMPLEMENT_DYNAMIC(PLCRPDevice, PLCDevice )

BEGIN_MSG_MAP( PLCRPDevice, PLCDevice )
	
END_MSG_MAP
