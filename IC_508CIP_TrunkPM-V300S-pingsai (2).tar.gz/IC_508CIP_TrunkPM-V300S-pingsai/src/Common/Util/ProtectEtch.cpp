#include "ProtectEtch.h"
#include "SysLogger.h"
#include "XmlGetter.h"
#include "MapTool.h"
#include "Converter.h"
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

ProtectEtch::ProtectEtch()
{
}

ProtectEtch::~ProtectEtch()
{
}

void ProtectEtch::initialize()
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ": start to protect etch ");

	map<string,ReadWriteInt*>::iterator it = m_IntWriteChs.begin();
	for(;it != m_IntWriteChs.end(); ++it)
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ": about to close "+it->first);
		it->second->setValue(0);//off
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ": end to close "+it->first);
	}

	map<string,ReadOnlyDouble*>::iterator it2 = m_DoubleSensorChs.begin();
	for(;it2 != m_DoubleSensorChs.end(); ++it2)
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ": read "+it2->first+"'s value ="+Converter::convertToString(it2->second->getValue()));
	}

	//added by liusy [1.1.26]
	map<string,ReadWriteInt*>::iterator itOnWrite = m_IntOnWriteChs.begin();
	for(;itOnWrite != m_IntOnWriteChs.end(); ++itOnWrite)
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ": about to open "+itOnWrite->first);
		itOnWrite->second->setValue(1);//on
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ": end to open "+itOnWrite->first);
	}

	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ": end to protect etch ");
	throw "Finished to Protect Etch, exit.";
}

void ProtectEtch::addRFOnOffWCh(const string strParamName, const string &strPath)
{
	ReadWriteInt * pRWInt = XmlGetter::getFromNamespace<ReadWriteInt*>(strPath);
	if(!MapTool::addToMap<string,ReadWriteInt *>(m_IntWriteChs,strParamName,pRWInt))
	{
		throw "IntCfgParams repeat added:"+strParamName;
	}
}

//added by liusy [1.1.26]
void ProtectEtch::addOffWCh(const string strParamName, const string &strPath)
{
	ReadWriteInt * pRWInt = XmlGetter::getFromNamespace<ReadWriteInt*>(strPath);
	if(!MapTool::addToMap<string,ReadWriteInt *>(m_IntWriteChs,strParamName,pRWInt))
	{
		throw "IntCfgParams repeat added:"+strParamName;
	}
}

//added by liusy [1.1.26]
void ProtectEtch::addOnWCh(const string strParamName, const string &strPath)
{
	ReadWriteInt * pRWInt = XmlGetter::getFromNamespace<ReadWriteInt*>(strPath);
	if(!MapTool::addToMap<string,ReadWriteInt *>(m_IntOnWriteChs,strParamName,pRWInt))
	{
		throw "IntCfgParams repeat added:"+strParamName;
	}
}

void ProtectEtch::addRFForwardPowerSensorCh(const string strParamName, const string &strPath)
{
	ReadOnlyDouble * pRDouble = XmlGetter::getFromNamespace<ReadOnlyDouble*>(strPath);
	if(!MapTool::addToMap<string,ReadOnlyDouble *>(m_DoubleSensorChs,strParamName,pRDouble))
	{
		throw "Double Sensor repeat added:"+strParamName;
	}
}

IMPLEMENT_DYNAMIC(ProtectEtch, CmdTarget)

BEGIN_MSG_MAP( ProtectEtch, CmdTarget )
	SET_SS( addOffWCh, ProtectEtch )//added by liusy [1.1.26]
	SET_SS( addOnWCh, ProtectEtch )//added by liusy [1.1.26]
	SET_SS( addRFOnOffWCh, ProtectEtch )
    SET_SS( addRFForwardPowerSensorCh, ProtectEtch )
END_MSG_MAP
