/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: GuadAction.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-9-28   LiJuanjuan create
**      
*********************************************************************/
#ifndef GUADACTION_H_
#define GUADACTION_H_

#include "ControlObjectEX.h"
#include "AppCondition.h"
#include "NonBlockingAlarm.h"
#ifdef IAP4_0
using namespace IAP::CONDITION;
using namespace IAP::ALARM;
#endif

class GuadAction:public ControlObjectEX
{
	DECLARE_DYNAMIC( GuadAction )
	DECLARE_MSG_MAP
	
	protected:
		NonBlockingAlarm *m_nActionFailedAlarm;
		std::string m_vIntlkName;
		
	public:
		GuadAction();
		virtual ~GuadAction();
		
		virtual void execute(const AppConditionPtr &trigger)=0;
		
		virtual void make();
		
		void setIntlkName(const std::string &name);
};

#endif /*GUADACTION_H_*/
