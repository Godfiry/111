/*
 * TCPConnectionFesto.cpp
 *
 *  Created on: Jun 4, 2021
 *      Author: zhangyy
 */
#include "TCPConnectionFesto.h"
#include "TCPDeviceFesto.h"
#include "SysLogger.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#include "ConfigException.h"
#include "TCPSocket.h"
#include <errno.h>
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;

TCPConnectionFesto::TCPConnectionFesto(const std::string &server, std::string port)
{
	m_socket = new TCPSocket(server, port);
	m_device = NULL;
	m_state = s_CLOSED;
	m_running = false;
	m_timeout = 10;
	m_reconnectMonitor = new ReconnectMonitor(this);
}

TCPConnectionFesto::~TCPConnectionFesto()
{
	delete m_reconnectMonitor;
	m_reconnectMonitor = NULL;//mujy added 20160616[v1.0.16]
	delete m_socket;
	m_socket = NULL;//mujy added 20160616[v1.0.16]

}


TCPConnectionFesto::ReconnectMonitor::ReconnectMonitor(TCPConnectionFesto *owner)
{
	m_connection = owner;
}

void TCPConnectionFesto::ReconnectMonitor::run()
{
	string deviceName = m_connection->m_device->getDeviceName();
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, deviceName + ":ReconnectMonitor start running");
	try
	{
		m_connection->reconnectDevice();
	}
	catch(const exception &ex)
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, deviceName + ":ReconnectMonitor got exception - "+ex.what());
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, deviceName + ":ReconnectMonitor exit");
}


void TCPConnectionFesto::run()
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnectionFesto started run()");
	while(m_running)
	{
		try
		{
			if(!isConnected())
			{
				reconnect();
			}
			if(isConnected())
			{
				m_device->readInput();
				m_device->writeOutput();
				m_device->executePositionRecord();
			}
		}
		catch(const exception &ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, m_device->getDeviceName() + ":TCPConnectionFesto in run() got exception: " + string(ex.what()));
		}
		usleep(1000);
	}
}

void TCPConnectionFesto::connect()
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnectionFesto connecting");
	changeState(s_CLOSED);
	m_socket->connect();
	changeState(s_CONNECTED);
	m_running = true;
	start();
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnectionFesto connected");
}

void TCPConnectionFesto::changeState(int newstat)
{
	m_state = newstat;
}

void TCPConnectionFesto::disconnect()
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnectionFesto disconnecting");
	m_running = false;
	//m_reconnectMonitor->interupt();
	m_socket->shutdown(2);//close rw
	wait();
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnectionFesto disconnected");
}

void TCPConnectionFesto::close()
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnectionFesto closing");
	changeState(s_CLOSING);
	m_socket->shutdown(2);//close rw
	changeState(s_CLOSED);
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnectionFesto closed");
}

void TCPConnectionFesto::reconnect()
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnectionFesto reconnecting");
	reconnectSocket();
	if(!m_running)
	{
		return;
	}

	//sleep(1);//wait for device get ready
	m_reconnectMonitor->start();
	//reconnectDevice();
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnectionFesto reconnected");

}

void TCPConnectionFesto::reconnectSocket()
{
	close();
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnectionFesto reconnecting socket");
	changeState(s_CONNECTING);
	bool bPrintFlag = true;
	while(!isConnected())
	{
		if(!m_running)
		{
			return;
		}
		//sleep(1);//1s
		if(m_socket->reconnect() != 0)
		{
			if(bPrintFlag)
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnectionFesto reconnect socket failed for "+ m_socket->getErrnoStr());
				bPrintFlag = false;
			}
			continue;
		}
		changeState(s_CONNECTED);
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, m_device->getDeviceName() + ":TCPConnectionFesto reconnected socket");
}

void TCPConnectionFesto::reconnectDevice()
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnectionFesto reconnecting device");
	while(isConnected() && !m_device->reconnectDevice())
	{
		if(!m_running)
		{
			return;
		}
		sleep(1);//1s
	}
	if(isConnected())
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, m_device->getDeviceName() + ":TCPConnectionFesto reconnected device");
	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, m_device->getDeviceName() + ":TCPConnectionFesto reconnect device failed for socket disconnected");
	}
}

void TCPConnectionFesto::setDevice(TCPDeviceFesto *device)
{
	m_device = device;
}

void TCPConnectionFesto::sendData(const char *data, int size)
{
	IMutexLocker locker(&m_lock);
	//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, m_device->getDeviceName() + ":TCPConnectionFesto sending data :" + string(data));

	if(!isConnected())
	{
		throw IOException("send data failed for socked is not connected");
	}

	while(true)
	{
		if(m_socket->sendData(data, size) == -1)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, m_device->getDeviceName() + ":TCPConnectionFesto send error for " + m_socket->getErrnoStr());
/*			if(m_socket->getErrno() == EINTR )//EAGAIN  errno means the sended data is bigger than socket send buffer
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, m_device->getDeviceName() + ":TCPConnectionFesto error is EAGAIN or EINTR and continue send");
				continue;
			}
			else*/
			{
				changeState(s_ERROR);
				throw IOException("send data failed for " + m_socket->getErrnoStr());
			}
		}
		else
		{
			break;
		}
	}
	//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, m_device->getDeviceName() + ":TCPConnectionFesto sended data :" + string(data));
}


bool TCPConnectionFesto::recvFixLenData(char *buffer, int len)
{
	IMutexLocker locker(&m_lock);
	while(true)
	{
		int t_recvCount = m_socket->recvFixLenData(buffer, len);
		if(0 == t_recvCount)
		{
			//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, m_device->getDeviceName() + ":TCPConnectionFesto recv FIN and server close connection");
			changeState(s_CLOSED);
			return false;
		}
		else if (-1 == t_recvCount)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, m_device->getDeviceName() + ":TCPConnectionFesto recv error for " + m_socket->getErrnoStr());
/*			if(m_socket->getErrno() == EAGAIN || m_socket->getErrno() == EINTR)
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, m_device->getDeviceName() + ":TCPConnectionFesto error is EAGAIN or EINTR and continue recv");
				continue;
			}
			else*/
			{
				changeState(s_ERROR);
				return false;
			}
		}
		return true;
	}
}

bool TCPConnectionFesto::recvData(char *buffer, int len)
{
	IMutexLocker locker(&m_lock);
	while(true)
	{
		int t_recvCount = m_socket->recvData(buffer, len);
		if(0 == t_recvCount)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, m_device->getDeviceName() + ":TCPConnectionFesto recv FIN and server close connection");
			changeState(s_CLOSED);
			return false;
		}
		else if (-1 == t_recvCount)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, m_device->getDeviceName() + ":TCPConnectionFesto recv error for " + m_socket->getErrnoStr());
/*			if(m_socket->getErrno() == EAGAIN || m_socket->getErrno() == EINTR)//by lijj 20110519 EAGAIN means there is no data to read
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, m_device->getDeviceName() + ":TCPConnectionFesto error is EAGAIN or EINTR and continue recv");
				continue;
			}
			else*/
			{
				changeState(s_ERROR);
				return false;
			}
		}
		return true;
	}
}

bool TCPConnectionFesto::isConnected()const
{
	return (m_state == s_CONNECTED);
}

void TCPConnectionFesto::setTimeOut(int timeout)
{
	m_timeout = timeout;
}
