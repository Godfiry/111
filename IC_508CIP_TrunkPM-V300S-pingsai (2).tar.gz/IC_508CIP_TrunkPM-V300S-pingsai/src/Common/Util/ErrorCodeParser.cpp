/********************************************************************
** Copyright (c) 2019, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: DefaultErrorCodeParser.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2019-8-30   liusy create
**      
*********************************************************************/
#include "ErrorCodeParser.h"
#include "SysLogger.h"
#include "ConfigException.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
#endif
using namespace std;


ErrorCodeParser::ErrorCodeParser()
{
}

ErrorCodeParser::~ErrorCodeParser()
{
}

string ErrorCodeParser::parseErrorCode(const string strCode)
{
	string strErrMsg = "Device has error,Error Code is "+strCode;
	strErrMsg += ": " + getParseResult(strCode) + ". ";
	return strErrMsg;
}

//only get ErrorCodes' Parse value, if not exist, get unknown Err.
string ErrorCodeParser::getParseResult(const string strKey)
{
	string strParseResult = "";
	map<string, string>::iterator t_it = m_ErrorCodes.find(strKey);
	if( t_it != m_ErrorCodes.end())
	{
		strParseResult= t_it->second;
	}
	else
	{
		strParseResult = "unknown error";
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() +string( "The Error code")+ string(strKey)+string(" has no message information."));
	}
	return strParseResult;
}

void ErrorCodeParser::addErrorCode(string strErrCode, string strDecripition, string strRecommendedAction)
{
	string strErrDetail = strDecripition;
	if(strRecommendedAction != " ")
	{
		strErrDetail = strErrDetail + " RecommendedAction:"+strRecommendedAction;
	}
	if(!MapTool::addToMap<string,string>(m_ErrorCodes,strErrCode,strErrDetail))
	{
		throw ConfigException("ErrorCode repeat added:"+strErrCode);
	}
}
			
IMPLEMENT_DYNAMIC(ErrorCodeParser,CmdTarget)

BEGIN_MSG_MAP(ErrorCodeParser,CmdTarget)
	SET_SSS( addErrorCode, ErrorCodeParser )
END_MSG_MAP

