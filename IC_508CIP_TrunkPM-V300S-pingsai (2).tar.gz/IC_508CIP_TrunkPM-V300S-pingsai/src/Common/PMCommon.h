/********************************************************************
** Copyright (c) 2019 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: PMCommon.h
** Description:  
** Release: 1.0
** Modification history:           
** 					2019-06-11   Duq create
** 
*********************************************************************/

#ifndef PMCOMMON_H_
#define PMCOMMON_H_

#include <string>
#include <map>

class PMCommon
{
	public:
		static std::map<std::string, std::string> getPMRecipeParamsMap();
		static std::map<std::string, std::string> m_PMRecipeParamsMap;
	
		typedef enum
		{
			ByTime = 0,
			ByEndPoint = 1
		}RecipeEndMode;
		
		static const std::string globalRecipeStepNameSymbol;
		static const std::string globalRecipeEndModeSymbol;
		static const std::string globalRecipeStepTimeSymbol;
		static const std::string globalRecipeStepEndPointSymbol;
		static const std::string globalRecipeOffsetTableSymbol;
		static const std::string globalRecipeZoneTableSymbol;
		
		static const std::string globalRecipeTempModeSymbol;
		static const std::string globalRecipeTargetTempSymbol;
		static const std::string globalRecipeTempRampRateSymbol;
		static const std::string globalRecipeTargetPowerSymbol;
		static const std::string globalRecipePowerRampRateSymbol;
		static const std::string globalRecipePowerRatioSymbol;
		static const std::string globalRecipeDomeTempSymbol;
		
		static const std::string globalRecipeTotalProcessGasSymbol;
		static const std::string globalRecipeMainH2FlowSymbol;
		static const std::string globalRecipeSlitH2FlowSymbol;
		static const std::string globalRecipeEdgeH2FlowSymbol;
		static const std::string globalRecipePushRunSymbol;
		static const std::string globalRecipePushVentSymbol;
		
		static const std::string globalRecipeMainTCSSymbol;
		static const std::string globalRecipeMainTCSFlowSymbol;
		static const std::string globalRecipeEdgeTCSSymbol;
		static const std::string globalRecipeEdgeTCSFlowSymbol;
		
		static const std::string globalRecipeDop1DiluteFlowSymbol;
		static const std::string globalRecipeDop1FlowSymbol;
		static const std::string globalRecipeMixDop1Symbol;
		static const std::string globalRecipeMixDop1FlowSymbol;
		
		static const std::string globalRecipeDop2DiluteFlowSymbol;
		static const std::string globalRecipeDop2FlowSymbol;
		static const std::string globalRecipeMixDop2Symbol;
		static const std::string globalRecipeMixDop2FlowSymbol;
		
		static const std::string globalRecipeHCLSymbol;
		static const std::string globalRecipeHCLPolishFlowSymbol;
		static const std::string globalRecipeHCLEtchFlowSymbol;
		static const std::string globalRecipeHCLEdgeFlowSymbol;
		
		static const std::string globalRecipeAuxDopSymbol;
		static const std::string globalRecipeAuxDopInnerSymbol;
		static const std::string globalRecipeAuxDopMiddleSymbol;
		static const std::string globalRecipeAuxDopInnerFlowSymbol;
		static const std::string globalRecipeAuxDopMiddleFlowSymbol;
		
		static const std::string globalRecipeBlowerCtrlModeSymbol;	
		static const std::string globalRecipeUpperBlowerSpeedSymbol;	
		static const std::string globalRecipeLowerBlowerSpeedSymbol;

		static const std::string globalRecipeLiftPosSymbol;
		static const std::string globalRecipeRotateSpeedSymbol;
		static const std::string globalRecipeRotateSpeedRampRateSymbol;
		
		//RP
		static const std::string globalRecipeDop1DiluteFlowRPSymbol;
		static const std::string globalRecipeDop2DiluteFlowRPSymbol;
		static const std::string globalRecipePressureModeSymbol;
		static const std::string globalRecipePressureSymbol;
		static const std::string globalRecipePressureRampRateSymbol;
		static const std::string globalRecipePCVSymbol;
		static const std::string globalRecipePCVRampRateSymbol;
		
		static const std::string globalRecipePushRunRPSymbol;
		static const std::string globalRecipePushVentRPSymbol;
        static const std::string globalRecipePushH2RunRPSymbol;
		static const std::string globalRecipePushH2VentRPSymbol;
		
		static const std::string globalRecipeMainH2RampModeSymbol;
		static const std::string globalRecipeMainH2StartFlowSymbol;
		static const std::string globalRecipeMainH2EndFlowSymbol;
		static const std::string globalRecipeSlitH2RampModeSymbol;
		static const std::string globalRecipeSlitH2StartFlowSymbol;
		static const std::string globalRecipeSlitH2EndFlowSymbol;
		static const std::string globalRecipeEPurgeRPSymbol;
		static const std::string globalRecipeEPurgeRampModeRPSymbol;
		static const std::string globalRecipeEPurgeStartFlowRPSymbol;
		static const std::string globalRecipeEPurgeEndFlowRPSymbol;
        static const std::string globalRecipeEH2RPSymbol;
		static const std::string globalRecipeEH2RampModeRPSymbol;
		static const std::string globalRecipeEH2StartFlowRPSymbol;
		static const std::string globalRecipeEH2EndFlowRPSymbol;
		
		static const std::string globalRecipeDCSSymbol;
		static const std::string globalRecipeDCSRampModeSymbol;
		static const std::string globalRecipeDCSStartFlowSymbol;
		static const std::string globalRecipeDCSEndFlowSymbol;
		static const std::string globalRecipeEDCSSymbol;
		static const std::string globalRecipeEDCSRampModeSymbol;
		static const std::string globalRecipeEDCSStartFlowSymbol;
		static const std::string globalRecipeEDCSEndFlowSymbol;
		
		static const std::string globalRecipeSiH4Symbol;
		static const std::string globalRecipeSiH4RampModeSymbol;
		static const std::string globalRecipeSiH4StartFlowSymbol;
		static const std::string globalRecipeSiH4EndFlowSymbol;
		static const std::string globalRecipeESiH4Symbol;
		static const std::string globalRecipeESiH4RampModeSymbol;
		static const std::string globalRecipeESiH4StartFlowSymbol;
		static const std::string globalRecipeESiH4EndFlowSymbol;
		
		static const std::string globalRecipeGeH4Symbol;
		static const std::string globalRecipeGeH4RampModeSymbol;
		static const std::string globalRecipeGeH4StartFlowSymbol;
		static const std::string globalRecipeGeH4EndFlowSymbol;
		static const std::string globalRecipeEGeH4Symbol;
		static const std::string globalRecipeEGeH4RampModeSymbol;
		static const std::string globalRecipeEGeH4StartFlowSymbol;
		static const std::string globalRecipeEGeH4EndFlowSymbol;
		
		static const std::string globalRecipeHCLSelectSymbol;
		static const std::string globalRecipeHCLSelectRampModeSymbol;
		static const std::string globalRecipeHCLSelectStartFlowSymbol;
		static const std::string globalRecipeHCLSelectEndFlowSymbol;
		static const std::string globalRecipeHCLEtchSymbol;
		static const std::string globalRecipeHCLEtchRampModeSymbol;
		static const std::string globalRecipeHCLEtchStartFlowSymbol;
		static const std::string globalRecipeHCLEtchEndFlowSymbol;
		static const std::string globalRecipeEHCLSymbol;
		static const std::string globalRecipeEHCLRampModeSymbol;
		static const std::string globalRecipeEHCLStartFlowSymbol;
		static const std::string globalRecipeEHCLEndFlowSymbol;
		
		static const std::string globalRecipeDDop1Symbol;
		static const std::string globalRecipeDDop1RampModeSymbol;
		static const std::string globalRecipeDDop1StartFlowSymbol;
		static const std::string globalRecipeDDop1EndFlowSymbol;
		
		static const std::string globalRecipeDDop2Symbol;
		static const std::string globalRecipeDDop2RampModeSymbol;
		static const std::string globalRecipeDDop2StartFlowSymbol;
		static const std::string globalRecipeDDop2EndFlowSymbol;
		
		static const std::string globalRecipeMixDop1RampModeSymbol;
		static const std::string globalRecipeMixDop1StartFlowSymbol;
		static const std::string globalRecipeMixDop1EndFlowSymbol;
		static const std::string globalRecipeMixDop2RampModeSymbol;
		static const std::string globalRecipeMixDop2StartFlowSymbol;
		static const std::string globalRecipeMixDop2EndFlowSymbol;
		static const std::string globalRecipeEMixDopRampModeSymbol;
		static const std::string globalRecipeEMixDopSymbol;
		static const std::string globalRecipeEMixDopStartFlowSymbol;
		static const std::string globalRecipeEMixDopEndFlowSymbol;
		
		static const std::string globalRecipeAuxSymbol;
		static const std::string globalRecipeAuxGeH4RampModeSymbol;
		static const std::string globalRecipeAuxGeH4StartFlowSymbol;
		static const std::string globalRecipeAuxGeH4EndFlowSymbol;
		static const std::string globalRecipeAuxDADopRampModeSymbol;
		static const std::string globalRecipeAuxDADopStartFlowSymbol;
		static const std::string globalRecipeAuxDADopEndFlowSymbol;
		static const std::string globalRecipeAuxMixDopSymbol;
		static const std::string globalRecipeAuxMixDopRampModeSymbol;
		static const std::string globalRecipeAuxMixDopStartFlowSymbol;
		static const std::string globalRecipeAuxMixDopEndFlowSymbol;
		
		static const std::string globalRecipeBPCModeSymbol;
		static const std::string globalRecipeBPC01OffsetPressureSymbol;
		static const std::string globalRecipeBPC02OffsetPressureSymbol;
		static const std::string globalRecipeBPC03OffsetPressureSymbol;
		static const std::string globalRecipeBPC01PressureSymbol;
		static const std::string globalRecipeBPC02PressureSymbol;
		static const std::string globalRecipeBPC03PressureSymbol;
		static const std::string globalRecipeDop1FlowRPSymbol;
		static const std::string globalRecipeDop2FlowRPSymbol;
		static const std::string globalRecipeMixDop1RPSymbol;
		static const std::string globalRecipeMixDop2RPSymbol;

		static const std::string globalRecipePurgeGasRPSymbol;
		static const std::string globalRecipeMainPurgeRampModeRPSymbol;
		static const std::string globalRecipeMainPurgeStartFlowRPSymbol;
		static const std::string globalRecipeMainPurgeEndFlowRPSymbol;
		static const std::string globalRecipeSlitPurgeRampModeRPSymbol;
		static const std::string globalRecipeSlitPurgeStartFlowRPSymbol;
		static const std::string globalRecipeSlitPurgeEndFlowRPSymbol;
		
		//single
		static const std::string globalRecipeAuxDopOuterSymbol;
		static const std::string globalRecipeAuxDopOuterFlowSymbol;
		static const std::string globalRecipeEdgeGasSymbol;
		static const std::string globalRecipeEdgeHCLSymbol;
		static const std::string globalRecipePushH2RunSymbol;
		static const std::string globalRecipePushH2VentSymbol;
		static const std::string globalRecipeEH2Symbol;
		static const std::string globalRecipeEH2RampModeSymbol;
		static const std::string globalRecipeEH2StartFlowSymbol;
		static const std::string globalRecipeEH2EndFlowSymbol;
		static const std::string globalRecipeDop1DiluteFlowRPSSymbol;
		static const std::string globalRecipeMixDop1RampModeAPSymbol;
		static const std::string globalRecipeMixDop1StartFlowAPSymbol;
		static const std::string globalRecipeMixDop1EndFlowAPSymbol;
		static const std::string globalRecipeDop1FlowRPSSymbol;
		static const std::string globalRecipeMixDop1RPSSymbol;
		
		//ALC
		static const std::string RPN_AHFDiluteGasType;
		static const std::string RPN_AHFDiluteGas;
		static const std::string RPN_AHFGasType;
		static const std::string RPN_AHFGas;
		static const std::string RPN_NH3DiluteGasType;
		static const std::string RPN_NH3DiluteGas;
		static const std::string RPN_NH3GasType;
		static const std::string RPN_NH3Gas;
		static const std::string RPN_N2GasType;
		static const std::string RPN_N2Gas;
		static const std::string RPN_H2GasType;
		static const std::string RPN_H2Gas;
		static const std::string RPN_ArGasType;
		static const std::string RPN_ArGas;
		static const std::string RPN_NF3GasType;
		static const std::string RPN_NF3Gas;
		static const std::string MI_ArGasFlow;
		static const std::string MI_NF3GasFlow;
		static const std::string RPN_BottomPurgeGas;
		static const std::string RPN_SlitPurgeGas;
		static const std::string RPN_ValveMode;
		static const std::string RPN_ValveSetPoint;
		static const std::string RPN_HeaterPos;
		static const std::string RPN_PosSpacing;
		static const std::string RPN_PinSpacing;

		static const std::string MI_N2GasFlow;
		static const std::string MI_H2GasFlow;
		static const std::string MI_AHFGasFlow;
		static const std::string MI_AHFDiluteGasFlow;
		static const std::string MI_NH3GasFlow;
		static const std::string MI_NH3DiluteGasFlow;
		static const std::string MI_BottomPurgeGasFlow;
		static const std::string MI_SlitPurgeGasFlow;
		static const std::string MI_ProcPress;    // Monitor item about process pressure
		static const std::string RPN_Pressure;
		static const std::string RPN_StepName;    // recipe param name about step name
		static const std::string RPN_StepTime;    // recipe param name about step time
		static const std::string RPN_PedTemp;
		static const std::string RPN_SHDTemp;
		static const std::string RPN_OffsetTable;
        static const std::string globalRecipeBackSideModeSymbol;
		static const std::string globalRecipeBackSidePressureSymbol;
		static const std::string globalRecipeBackSideFlowSymbol;
        static const std::string globalRecipePedSpacingSymbol;
        static const std::string globalRecipePinSpacingSymbol;
		static const std::string globalRecipeNH3FlowSymbol;
		static const std::string globalRecipeNF3FlowSymbol;
		static const std::string globalRecipeH2FlowSymbol;
		static const std::string globalRecipeHeFlowSymbol;
		static const std::string globalRecipeArFlowSymbol;
		static const std::string globalRecipeSlitPurgeFlowSymbol;
        static const std::string globalRecipeBottomPurgeFlowSymbol;
        static const std::string globalRecipeEdgePurgeFlowSymbol;
        static const std::string globalRecipeProcessPosSymbol;
        static const std::string globalRecipeRFPowerSymbol;
        static const std::string globalRecipeSHDTempSymbol;
        static const std::string globalRecipePedTempSymbol;

		//for e630r plus
		static const std::string globalRecipeLinerPurgeRampModeRPSymbol;
		static const std::string globalRecipeLinerPurgeStartFlowRPSymbol;
		static const std::string globalRecipeLinerPurgeEndFlowRPSymbol;
		static const std::string globalRecipeRotPurgeRampModeRPSymbol;
		static const std::string globalRecipeRotPurgeStartFlowRPSymbol;
		static const std::string globalRecipeRotPurgeEndFlowRPSymbol;
};

#endif /*PMCOMMON_H_*/
