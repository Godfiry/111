/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AEDualMatchDriver.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2015-04-24   gaozl create
**      
*********************************************************************/
#ifndef AEDUALMATCHDRIVER_H_
#define AEDUALMATCHDRIVER_H_
#include "SerialDevice.h"
#include "DeviceNode.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class AEDualMatchDriver : public SerialDevice
{
    DECLARE_DYNAMIC(AEDualMatchDriver)	
    DECLARE_MSG_MAP

private:
    typedef struct
	 {
		int m_type;//total cmd length
		unsigned char m_cmd;  //changed by wzd 1.1.39
		int m_relen;
	 }Com;
	static Com m_commands[];	 
    static const int RESP_LEN = 100;
    static const int MESS_LEN = 20;
    int m_preC1;
    int m_preC2;

    char message[MESS_LEN];
    char resp[RESP_LEN];
    char ack[1];
    int addr;
    bool sendCommand(char *msg,char *response, int l_msg_timeout,int length);
    bool sendCommandAck(char *msg, char *response, int msg_timeout,int resplen, int msglen);
    bool readCommand(char *msg, char *response, int msg_timeout,int resplen, int msglen);
		 
public:
    AEDualMatchDriver();
    virtual ~AEDualMatchDriver();
    void init();
    void InitChannels(DeviceNode<AEDualMatchDriver> *node);   
    bool writeInt(int channel,int value,const IntTypeInfo& typeinfo);
    bool readInt(int channel,int *value,const IntTypeInfo& typeinfo);	
    bool readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo);
	 double realToDouble(long value);
	 void setAddress(int ad);
	 void selectNetWork(int value);
};
#endif /*AEDUALMATCHDRIVER_H_*/
