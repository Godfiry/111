/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MKSFRC.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-12-02   LiJuanjuan create
**      
*********************************************************************/
#include "MKSFRC.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#include "Converter.h"
#include "DeviceManager.h"
#include <iostream>
#include <string.h>
#ifdef IAP4_0
using namespace IAP;
using namespace IAP::CORE;
using namespace IAP::IO;
#endif

using namespace std;

MKSFRC::MKSFRC()
{
	m_pollInterval = 500;
	m_outputByte = 5;
	m_inputByte = 6;
	m_scale = 20;
}

MKSFRC::~MKSFRC()
{
}

bool MKSFRC::writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
	char buffer[m_outputByte];
	memset(buffer, 0, m_outputByte);	
	float t_value = 0;
	if(value < 1 && value != 0)//Q1:Q2
	{
		buffer[0] = 1;
		t_value = (float)(1/value);
	}
	else//Q2:Q1
	{
		buffer[0] = 2;
		t_value = (float)value;
	}
	*((float*)(buffer+1)) = t_value;
	/*cout << "buffer:"<<*((float*)(buffer+1))<<endl;
	for(int i=0; i<m_outputByte; ++i)
	{
		cout << (unsigned int)buffer[i] <<endl;
	}*/	
	return m_deviceNet->writeByte(m_macID, buffer);		
}
		
bool MKSFRC::readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	char buffer[m_inputByte];
	memset(buffer, 0, m_inputByte);
	m_deviceNet->readByte(m_macID, buffer);
	if(buffer[0] != 0)
	{
		//cout<< "MKSFRC::readDouble(), status:"<<(int)buffer[0]<<endl;		
		//throw IOException("error status: "+Converter::convertToString((int)buffer[0]));
	}	
	int type = buffer[1];
	/*
	for(int i=0; i<m_inputByte; ++i)
	{
		cout << (int)buffer[i] <<endl;
	}*/

	*value = *((float*)(buffer+2));
	//cout << *value << endl;
	if(type == 1 && ((*value) !=0))
	{
		*value = 1/(*value);
		//return true;
	}
	else if(type == 2)
	{
		//return true; 
	}
	else
	{
		//cout << "MKSFRC unknow read back type :"+Converter::convertToString(type) << endl;
		throw IOException("MKSFRC unknown read back type :"+Converter::convertToString(type));
	}
	if(*value > typeInfo.getMax())
	{
		*value = typeInfo.getMax();
		return true;
	}
	if(*value < typeInfo.getMin())
	{
		*value = typeInfo.getMin();
		return true;		
	}
	return true;
}
	
bool MKSFRC::writeInt(int channelNum, int value, const IntTypeInfo &typeInfo)
{
	char buffer[2] = {0x05,0};
	if(value == 0)//close
	{
		buffer[1] = 0x01;
		m_deviceNet->writeExplicit(m_macID, buffer, 0x10, 0x33, 0x01, 2);
	}
	else
	{
		buffer[1] = 0x02;
		m_deviceNet->writeExplicit(m_macID, buffer, 0x10, 0x33, 0x01, 2);
	}
	return true;
}
		
void MKSFRC::initChs(DeviceNode<MKSFRC> *node)
{
	node->registerWriteCh(1, &MKSFRC::writeDouble);//set ratio
	node->registerReadCh(2, &MKSFRC::readDouble);//read ratio
	node->registerWriteCh(3, &MKSFRC::writeInt);//open close
}
		
void MKSFRC::initDevice()
{	
	m_deviceNet->writeExplicit(m_macID, NULL, 0x06, 0x30, 0x01, 0);//start
	char buffer[2] = {0x05,0};
	m_deviceNet->writeExplicit(m_macID, buffer, 0x10, 0x33, 0x01, 2);//normal
}
		
void MKSFRC::init()
{
	DeviceNode<MKSFRC> *node = new DeviceNode<MKSFRC>(m_pollInterval,this);				
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	if(!isSimulated())
	{	
		initChs(node);
		initDeviceNet();
		initDevice();
		m_outputByte = m_deviceNet->getOBytesSize(m_macID);
		m_inputByte = m_deviceNet->getIBytesSize(m_macID);
	}	
}

void MKSFRC::setScale(int scale)
{
	m_scale = scale;
}

IMPLEMENT_DYNAMIC(MKSFRC, IODevice )
BEGIN_MSG_MAP( MKSFRC, IODevice )
	SET_I( setScale, MKSFRC )
END_MSG_MAP


