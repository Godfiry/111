/********************************************************************
** Copyright (c) 2021, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: ChillerZkmaZ600.cpp
** Description:
** Release: 1.1
** Modification history:
** 					2021-6-16   zhangyy create
**
*********************************************************************/
#include "ChillerZkmaZ600.h"
#include "DeviceManager.h"
#include "ObjectManager.h"

#include "Converter.h"
#include "StrTool.h"
#include "Hex.h"
#include "CheckCalculationTool.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "InvalidNameException.h"
#endif
#include "ConfigException.h"
#include <cctype>
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;

ChillerZkmaZ600::ChillerZkmaZ600():SerialDevice(200, "\x0D\x0A")
{
	m_timeOut = 50;//5s
	m_pollPeriod = 1000; //1s
	m_strCommand = ":0117010000060109000204";
	m_strStartStop = "4000";//First time, set 4000,Chiller will not start or stop,remain the original value
	m_cfgChillerTempSetpoint = NULL;
	m_cfgChillerTempOffset = NULL;
	m_strTemp = "6E8B";//if not config m_cfgChillerTempSetpoint, set a suggested value
	m_strChillerTempSetupPath = "";
	m_strChillerOffsetSetupPath = "";
}

ChillerZkmaZ600::~ChillerZkmaZ600()
{
}

std::string ChillerZkmaZ600::SendReadWriteCmd(const std::string &strCommand)
{
	std::string strTotalResponse = getCommandResult(strCommand, m_timeOut);
	size_t nPos = strTotalResponse.find(":", 0);  //changed by wzd 1.1.39
	if(nPos == string::npos)
	{
		throw IOException("Chiller SendReadWriteCmd failed for unknown response [" + strTotalResponse+"]");
	}
	if(strTotalResponse.length() != 35)
	{
		throw IOException("Chiller SendReadWriteCmd get response with unknown length: [" +Converter::convertToString(strTotalResponse.length())+"]");
	}
	return strTotalResponse;
}

std::string ChillerZkmaZ600::ConstructTotalCmd()
{
	std::string strTotalCommand = m_strCommand + m_strStartStop + m_strTemp;
	strTotalCommand += CheckCalculationTool::GetLRCCode(strTotalCommand);
	strTotalCommand = StrTool::toUpper(strTotalCommand);
	//cout<<"$$$$$$$$strTotalCommand = "<<strTotalCommand<<endl;
	return strTotalCommand;

}
bool ChillerZkmaZ600::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
	if(nValue == 1)
	{
		m_strStartStop = "8000";
	}
	else
	{
		m_strStartStop = "0000";
	}
	string strTemp = SendReadWriteCmd( ConstructTotalCmd() );
	return true;
}

bool ChillerZkmaZ600::writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
	double dTmp = (double)((dValue + 60) * 65535 / 220);
	double dTmp1 = (int) dTmp;
	int nTemp = dTmp1;
	m_strTemp = Hex::hexToString(nTemp,4);
	string strTemp = SendReadWriteCmd( ConstructTotalCmd() );
	return true;
}

bool ChillerZkmaZ600::readDouble(int nChannelNum, double *dValue, const DoubleTypeInfo &typeInfo)
{
	if(m_cfgChillerTempSetpoint == NULL)
	{
		try
		{
			m_cfgChillerTempSetpoint = dynamic_cast<ReadWriteDouble*>(ObjectManager::getInstance()->getObject(m_strChillerTempSetupPath));
		}
		catch(InvalidNameException ex)
		{

			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ":no cfgTempSetpoint"+ex.what());
			*dValue = 0;
			return true;
		}
		double dChillerTempSetpoint = m_cfgChillerTempSetpoint->getValue();//Get setup
		try
		{
			m_cfgChillerTempOffset = dynamic_cast<ReadWriteDouble*>(ObjectManager::getInstance()->getObject(m_strChillerOffsetSetupPath));
		}
		catch(InvalidNameException ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ":no cfgTempOffSet"+ex.what());
		}
		double dTmpoffset = 0.0;
		if(m_cfgChillerTempOffset != NULL)
		{
			dTmpoffset = m_cfgChillerTempOffset->getValue();
		}
		double dTmp = (double)((dChillerTempSetpoint + dTmpoffset + 60) * 65535 / 220);
		double dTmp1 = (int) dTmp;
		int nTemp = dTmp1;
		m_strTemp = Hex::hexToString(nTemp,4);
	}
	string strResponse = SendReadWriteCmd( ConstructTotalCmd() );
	if(nChannelNum == 3)//read temperature
	{
		size_t nPos = strResponse.find(":", 0);  //changed by wzd 1.1.39
		if(nPos == string::npos)
		{
			throw IOException("Chiller read temperature failed for unknown response [" + strResponse+"]");
		}
		string strSplitValue = strResponse.substr(nPos+11, 4);//read temperature
		int nValue = 0;
		if(!Hex::stringToHex(&nValue, strSplitValue))
		{
			throw IOException("Chiller read temperature failed for can't convert response ["+ strSplitValue +"] to double value.");
		}
		else
		{
			*dValue = nValue * 220.0/65535.0-60;//value range is from -60 to 160,see the manual
			return true;
		}
	}
	else
	{
		*dValue = 0;//ChannelNum = 4 or 5
	}
}

bool ChillerZkmaZ600::readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
	if(m_cfgChillerTempSetpoint == NULL)
	{
		try
		{
			m_cfgChillerTempSetpoint = dynamic_cast<ReadWriteDouble*>(ObjectManager::getInstance()->getObject(m_strChillerTempSetupPath));
		}
		catch(InvalidNameException ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ":no cfgTempSetpoint"+ex.what());
			if( (nChannelNum == 8) || (nChannelNum == 10) )
			{
				*pValue = 1;
			}
			else if( (nChannelNum == 6) || (nChannelNum == 7) || (nChannelNum == 9) )
			{
				*pValue = 0;
			}
			return true;
		}
		double dChillerTempSetpoint = m_cfgChillerTempSetpoint->getValue();//Get setup
		try
		{
			m_cfgChillerTempOffset = dynamic_cast<ReadWriteDouble*>(ObjectManager::getInstance()->getObject(m_strChillerOffsetSetupPath));
		}
		catch(InvalidNameException ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ":no cfgTempOffSet"+ex.what());
		}
		double dTmpoffset = 0.0;
		if(m_cfgChillerTempOffset != NULL)
		{
			dTmpoffset = m_cfgChillerTempOffset->getValue();
		}
		double dTmp = (double)((dChillerTempSetpoint + dTmpoffset + 60) * 65535 / 220);
		double dTmp1 = (int) dTmp;
		int nTemp = dTmp1;
		m_strTemp = Hex::hexToString(nTemp,4);
	}
	string strResponse = SendReadWriteCmd( ConstructTotalCmd() );
	size_t nPos = strResponse.find(":", 0);  //changed by wzd 1.1.39
	if(nPos == string::npos)
	{
		throw IOException("Chiller read status failed for unknown response [" + strResponse+"]");
	}
	else
	{
		string strSplitValue1 = strResponse.substr(nPos+7, 4);
		string strSplitValue2 = strResponse.substr(nPos+15, 4);
		int nValue = 0;
		if(!Hex::stringToHex(&nValue, strSplitValue1) || !Hex::stringToHex(&nValue, strSplitValue2))
		{
			throw IOException("Chiller read status failed for can't convert response ["+strSplitValue1+ "] [" +strSplitValue2 + "] to integer value.");
		}
		else
		{
			switch(nChannelNum)
			{
				case 6:
				case 7://Warning
					if(strSplitValue1 == "7000" && strSplitValue2 == "8000")
					{
						*pValue = 1;
						SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "ChillerZkmaZ600 get Warning: Chiller start but Low liquid-level" );
					}
					else if (strSplitValue1 == "6000" && strSplitValue2 == "8000")
					{
						*pValue = 1;
						SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "ChillerZkmaZ600 get Warning: Chiller stop but Low liquid-level" );
					}
					else
					{
						*pValue = 0;
					}
					break;
				case 8:
					*pValue = 1;
					break;
				case 9://Alarm
					if(strSplitValue1 == "A000" && strSplitValue2 == "0000")
					{
						*pValue = 1;
						SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "ChillerZkmaZ600 get Alarm: Chiller is offline for OverTemperature" );
					}
					else if (strSplitValue1 == "E000" && strSplitValue2 == "8000")
					{
						*pValue = 1;
						SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "ChillerZkmaZ600 get Alarm: Chiller is offline for Low liquid-level" );
					}
					else
					{
						*pValue = 0;
					}
					break;
				case 10://RunStatusAT
					if( (strSplitValue1 == "3000" && strSplitValue2 == "0000") || (strSplitValue1 == "7000" && strSplitValue2 == "8000"))//Chiller is started
					{
						*pValue = 1;
					}
					else if ( (strSplitValue1 == "2000" && strSplitValue2 == "0000") || (strSplitValue1 == "6000" && strSplitValue2 == "8000"))//Chiller is stopped
					{
						*pValue = 0;
					}
					break;
				default:
					break;
			}
			return true;
		}
	}
}

void ChillerZkmaZ600::initChs(DeviceNode<ChillerZkmaZ600> *pNode)
{
	pNode->registerWriteCh(1, &ChillerZkmaZ600::writeInt);
	pNode->registerWriteCh(2, &ChillerZkmaZ600::writeDouble);
	for(int i = 3; i<=5; ++i)
	{
		pNode->registerReadCh(i, &ChillerZkmaZ600::readDouble);
	}
	for(int i = 6; i<=10; ++i)// modified by mujy [V1.5.16]
	{
		pNode->registerReadCh(i, &ChillerZkmaZ600::readInt);
	}
	pNode->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &ChillerZkmaZ600::getStatus);//added by mujy [v1.0.8]
}

void ChillerZkmaZ600::initDevice()
{
	cout<<"Start Scan Chiller...."<<endl;
	//say hello to chiller
	double dTemp;
	try
	{
		readDouble(3,&dTemp,DoubleTypeInfo());//3 read temprature
	}
	catch(exception &ex)
	{
		cout<<"Scan chiller failed. Communication abnormal!"<<endl;
		throw;
	}
	cout<<"Scan Chiller Successfully...."<<endl;
}

void ChillerZkmaZ600::init()
{
	DeviceNode<ChillerZkmaZ600> *pNode = new DeviceNode<ChillerZkmaZ600>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
	if(!isSimulated())
	{
		initChs(pNode);
		//initDevice();
	}

	else
	{
		initChs(pNode);
	}

}

void ChillerZkmaZ600::setChillerTempSetupCh(const std::string &strName)
{
	if(strName == "")
	{
		throw ConfigException("path can not be empty");
	}
	m_strChillerTempSetupPath = strName;
}

void ChillerZkmaZ600::setChillerOffsetSetupCh(const std::string &strName)
{
	if(strName == "")
	{
		throw ConfigException("path can not be empty");
	}
	m_strChillerOffsetSetupPath = strName;
}
IMPLEMENT_DYNAMIC(ChillerZkmaZ600, SerialDevice )

BEGIN_MSG_MAP(ChillerZkmaZ600, SerialDevice )
	SET_V( init, ChillerZkmaZ600 )
	SET_S( setChillerTempSetupCh, ChillerZkmaZ600 )
	SET_S( setChillerOffsetSetupCh, ChillerZkmaZ600 )
END_MSG_MAP
