#include "AlarmReNameManager.h"
#include "SysLogger.h"
#include "Converter.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

using namespace std;



AlarmReNameManager* AlarmReNameManager::m_pInstance=NULL;
AlarmReNameManager::AlarmReNameManager()
{
}

AlarmReNameManager::~AlarmReNameManager()
{
}

bool AlarmReNameManager::AddAlarmNames(const string& strOriginalName , const string& strShowName)
{
    bool bResult=true;
    if(strOriginalName == "")
    {
        //throw exception
    }
    if(IsAlarmNameExist(strOriginalName))
    {
        throw strOriginalName+" has exist.";
        //bResult=false;
    }
    m_names[strOriginalName]=strShowName;
    return bResult;
}

string AlarmReNameManager::GetShowName(const string& strOriginalName)
{
    if(m_names.count(strOriginalName)>0)//nID exist
    {
        return m_names[strOriginalName];
    }
    else
    {
        cout<<"getShowName of["<<strOriginalName<<"] failed."<<endl;
        return strOriginalName;
    }
}

bool AlarmReNameManager::IsAlarmNameExist(const string& strOriginalName)
{
    if(m_names.count(strOriginalName)>0)//nID exist
    {
        return true;
    }
    else
    {
        return false;
    }
}

AlarmReNameManager* AlarmReNameManager::getInstance()
{
    if(m_pInstance == NULL)
    {
        m_pInstance= new AlarmReNameManager();
    }
    return m_pInstance;
}




