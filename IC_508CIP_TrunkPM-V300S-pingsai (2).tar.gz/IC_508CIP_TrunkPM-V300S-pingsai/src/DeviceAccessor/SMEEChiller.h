#ifndef SMEECHILLER_H_
#define SMEECHILLER_H_

#include "SerialDevice.h"
#include "DeviceNode.h"
#include "ControlObject.h"
#include "ReadWriteInt.h"
#include "ReadOnlyInt.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::CONTROL;
using namespace IAP::IO;
#endif
using namespace std;


class SMEEChiller:public SerialDevice
{
private:
	
	typedef struct
	{
		std::string m_address;
		int m_p1;
	}Cmd;
		
	static Cmd m_cmd[];
	int m_channel;
	DECLARE_DYNAMIC(SMEEChiller)	
	DECLARE_MSG_MAP	
 public:
	SMEEChiller();
	virtual ~SMEEChiller();
	void init();
	void setChannel(int chanNum);
	bool writeDouble(int channelNum, double value,const DoubleTypeInfo &typeInfo);
	bool readDouble(int channelNum, double *value,const DoubleTypeInfo &typeInfo);
    bool writeInt(int channelNum, int value,const IntTypeInfo &typeInfo);
	bool readInt(int channelNum, int *value,const IntTypeInfo &typeInfo);
protected:
    void initDevice();
    void initChs(DeviceNode<SMEEChiller>* node);
    bool readAlarm(int channelNum, string &strValue);
    double stringToDouble(string strValue);
};

#endif /*SMEECHILLER_H_*/
