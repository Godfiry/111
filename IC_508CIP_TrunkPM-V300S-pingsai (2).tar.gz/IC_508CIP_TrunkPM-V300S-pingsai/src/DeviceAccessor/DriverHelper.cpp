/********************************************************************
** Copyright (c) 2025, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: DriverHelper.h
** Description: This driver is 
*                          
** Release: 1.1
** Modification history: 
** 					2025-7-7   mujy create [1.5.0]
**      
*********************************************************************/
#include "DriverHelper.h"
#include "Hex.h"

DriverHelper::DriverHelper()
{
}

DriverHelper::~DriverHelper()
{
}

bool DriverHelper::isSystem64bit()
{
	if (sizeof(void*) == 8) 
	{
		return true;
	}
	else if (sizeof(void*) == 4) 
	{
		return false;
	}
    else
	{
		return false;
	}   
}


int32_t DriverHelper::littleEndianToInt(const uint8_t * bytes,int nLength) 
{
	if(nLength != 4)
	{
		return -1;
	}
	else
	{
		return (static_cast<int32_t>(bytes[0]) << 0) |
           (static_cast<int32_t>(bytes[1]) << 8) |
           (static_cast<int32_t>(bytes[2]) << 16) |
           (static_cast<int32_t>(bytes[3]) << 24);
	}
}

