/*
 * TimeScale.cpp
 *
 *  Created on: 2021-03-04
 *      Author: lvjiawen
 */

#include "TimeScale.h"
#include "Converter.h"
#include "StrTool.h"
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

TimeScale::TimeScale()
{
    m_strName ="";
    setStartPoint();
}

TimeScale::TimeScale(string strName)
{
    m_strName = strName;
    setStartPoint();
}

TimeScale::~TimeScale()
{
}

void TimeScale::setPoint(int nID)
{
    if(nID<0)
    {
        Log_Error("PointID less then 0!");
        return;
    }
    timeval t;
    gettimeofday(&t, 0);
    m_TimePoint[nID] = t;
}

void TimeScale::setStartPoint()
{
    timeval t;
    gettimeofday(&t, 0);
    m_TimePoint[-1] = t;
    Log_Info("TimeScale "+m_strName+" setStartPoint!");
}

void TimeScale::setFinishPoint()
{
    timeval t;
    gettimeofday(&t, 0);
    m_TimePoint[-2] = t;
    if (m_strName != "")
    {
        string strResult =getTimeScale();

        Log_Info(m_strName+":"+strResult);
    }
}

string TimeScale::getTimeScale(int nStartID, int nFinishID)
{
    if(m_TimePoint.count(nStartID)!=0 && m_TimePoint.count(nFinishID)!=0)
    {
        timeval t1=m_TimePoint[nFinishID];
        timeval t=m_TimePoint[nStartID];
        int nTimeUse_ms=((t1.tv_sec-t.tv_sec)*1000000+(t1.tv_usec-t.tv_usec))/1000;
        double dTimeUse_s=nTimeUse_ms/1000.0f;
        string strTimeUse_s=Converter::convertToString(dTimeUse_s);
        return strTimeUse_s+"s";
    }
    else
    {
        Log_Error("Time Point ID not exist!");
        return "error time.";
    }
}

string TimeScale::getTimeScale()
{
    return getTimeScale(-1,-2);
}


long TimeScale::getLongTimeScale(int nStartID, int nFinishID)//added by liusy[1.1.38]
{
    if(m_TimePoint.count(nStartID)!=0 && m_TimePoint.count(nFinishID)!=0)
    {
        timeval t1=m_TimePoint[nFinishID];
        timeval t=m_TimePoint[nStartID];
        int nTimeUse_ms=((t1.tv_sec-t.tv_sec)*1000000+(t1.tv_usec-t.tv_usec))/1000;
        return nTimeUse_ms;
    }
    else
    {
        Log_Error("Time Point ID not exist!");
        return 0;
    }
}

long TimeScale::getLongTimeScale()//added by liusy[1.1.38]
{
    return getLongTimeScale(-1,-2);
}

bool TimeScale::isReach(int nID, int nTimeLasting_ms)
{
    if(m_TimePoint.count(nID)==0)
    {
        Log_Error("Time Point ID not exist!");
        return false;
    }

    timeval t1;
    gettimeofday(&t1, 0);
    timeval t=m_TimePoint[nID];
    int nTimeUse_ms=((t1.tv_sec-t.tv_sec)*1000000+(t1.tv_usec-t.tv_usec))/1000;
    if(nTimeUse_ms>nTimeLasting_ms)
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool TimeScale::isReach(int nTimeLasting_ms)
{
    return isReach(-1,nTimeLasting_ms);
}


void TimeScale::waitForReach(int nTimeLasting_ms)
{
    while(!isReach(nTimeLasting_ms))
    {
        usleep(10000);
    }
    Log_Info("TimeScale reach!");
}

void TimeScale::logForLongTimeMs(int nStartID, int nFinishID, int nMoreThanTimeMs)//added by mujy [1.6.0]
{
    long nTime = getLongTimeScale(nStartID,nFinishID);
    if(nTime > nMoreThanTimeMs)
    {
        Log_Error("TimeScale "+m_strName+":"+Converter::convertToString(nStartID)+"-"+Converter::convertToString(nFinishID)+" run time = "+Converter::convertToString(nTime) +" more than "+Converter::convertToString(nMoreThanTimeMs));
    }
}
