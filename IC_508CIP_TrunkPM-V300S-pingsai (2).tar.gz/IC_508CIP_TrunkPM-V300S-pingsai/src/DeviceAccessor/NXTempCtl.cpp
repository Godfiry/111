/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: NXTempCtl.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2013-12-31   bihuijie create
**      
*********************************************************************/

#include "NXTempCtl.h"
#include <string.h>
#include <iostream>
#include "DeviceManager.h"
#include "SysLogger.h"
#include<string.h>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std;
NXTempCtl::NXTempCtl():SerialDevice(100, "")
{
		m_pollPeriod = 500;		
		m_timeOut = 20;
		readArray[0]=0x01;
		readArray[1]=0x03;
		readArray[2]=0x00;
		readArray[3]=0x00;
		readArray[4]=0x00;
		readArray[5]=0x01;
		readArray[6]=0x00;
		readArray[7]=0x00;
		writeArray[0]=0x01;
		writeArray[1]=0x06;
		writeArray[2]=0x00;
		writeArray[3]=0x00;
		writeArray[4]=0x00;
		writeArray[5]=0x00;
		writeArray[6]=0x00;
		writeArray[7]=0x00;

		}

NXTempCtl::~NXTempCtl()
{
}

unsigned short NXTempCtl::calculateLRC(char* buffer,int len)
{
	unsigned short wcrc = 0xffff;
	int temp;
	char *pushmsg = buffer;
	for(int j=0;j<len;j++)
	{
		temp = *pushmsg & 0x00FF;
		pushmsg++;
		wcrc ^= temp;
		for(int i=0;i<8;i++)
		{
			if(wcrc & 0x0001)
			{
				wcrc >>= 1;
				wcrc ^= 0xA001;	
			}else{
				wcrc >>= 1;
			}
		}
	}
	return wcrc;
	
}

void NXTempCtl::differNXTempDifferMachineCh(int channelNum)
{

	if(channelNum >=1 && channelNum<=30)
	{
		readArray[0]=0x01;
		writeArray[0]=0x01;
		
		return ;
	}	
	
	else if(channelNum >=31 && channelNum<=60)
	{
		readArray[0]=0x02;
		writeArray[0]=0x02;
		return ;
	}	

	else if(channelNum >=61 && channelNum<=90)
	{
		readArray[0]=0x03;
		writeArray[0]=0x03;
		return ;
	}	
	else if(channelNum >=91 && channelNum<=120)
	{
		readArray[0]=0x04;
		writeArray[0]=0x04;
		return ;
	}	

}

// 地址为01 02 03 04 所有温控器的 1 2 3 4 通道为设置LSP
// 地址为01 02 03 04 所有温控器的 5 6 7 8 通道为设置功率

bool NXTempCtl::writeDouble(int channelNum, double settemp, const DoubleTypeInfo& typeinfo)
{

	differNXTempDifferMachineCh(channelNum);
	if (isSimulated())
	{
		return true;
	}

	int checkChannel=channelNum%30;
	switch (checkChannel)
	{

		case 1:
				writeArray[2]=0x39;	
				writeArray[3]=0x01;
				break;
		case 2:
				writeArray[2]=0x39;	
				writeArray[3]=0x09;
				break;
		case 3:
				writeArray[2]=0x39;	
				writeArray[3]=0x11;
				break;
		case 4:
				writeArray[2]=0x39;	
				writeArray[3]=0x19;
				break;
		case 5:
				writeArray[2]=0x39;	
				writeArray[3]=0x02;
				break;
		case 6:
				writeArray[2]=0x39;	
				writeArray[3]=0x0A;
				break;
		case 7:
				writeArray[2]=0x39;	
				writeArray[3]=0x12;
				break;
		case 8:
				writeArray[2]=0x39;	
				writeArray[3]=0x1A;
				break;
		default:
				break;

	}

	double data=settemp*10.0;
	short temp=(short)(data);

	writeArray[4]=(temp>>8)&0xff;
	writeArray[5]=temp&0xff;
	unsigned short t_crc = calculateLRC(writeArray,6);
	writeArray[6] = t_crc&0xff;
	writeArray[7] = t_crc>>8;
//	cout<<"The send Write Double Command is as Follow"<<endl;
	unsigned char result[8];
	for(int i=0;i<8;i++)
	{
		result[i]=writeArray[i];
//		cout<<hex<<showbase<<uppercase<<(unsigned short)result[i]<<" - ";

	}
//	cout<<endl;
    char response[RESP_LEN];
	bzero(response, RESP_LEN);//reset the response
	sendCommandOnly(writeArray, 8);
	if(getResultOnly(response, RESP_LEN, m_timeOut) < 0)
	{
		throw IOException("NXTemp reading back times out");
	}
	else
	{
//		cout<<"The WriteDouble Channel Num is $$$$$$$$$$$$$$$  "<<dec<<noshowbase<<channelNum<<" $$$$$$$$$$$ The Command is as follow"<<endl;
		unsigned char res[8];
		for(int i=0;i<8;i++)
		{
			res[i]=response[i];
//			cout<<hex<<showbase<<uppercase<<(unsigned short)res[i]<<" - ";

		}
//		cout<<"\n"<<endl;
		if(response[1]!=0x06)
		{
			throw IOException("receive  an invalid command ,make sure the current mode is manual");
		}
		
	}
	
	return true;
}


//01 02 03 04 所有温控器的 9 10 11 12 通道为设置Auto或Manual
bool NXTempCtl::writeInt(int channelNum, int mode, const IntTypeInfo& typeinfo)
{

	differNXTempDifferMachineCh(channelNum);
	if (isSimulated())
	{
		return true;
	}

	int checkChannel=channelNum%30;
	switch (checkChannel)
	{

		case 9:
				writeArray[2]=0x39;	
				writeArray[3]=0x04;
				break;
		case 10:
				writeArray[2]=0x39;	
				writeArray[3]=0x0C;
				break;
		case 11:
				writeArray[2]=0x39;	
				writeArray[3]=0x14;
				break;
		case 12:
				writeArray[2]=0x39;	
				writeArray[3]=0x1C;
				break;
		default:
				break;

	}
	if(channelNum == 300)  //add by wzd 1.1.43
	{
	    writeArray[2]=0x22;	
	    writeArray[3]=0xB2;
	}
	if(channelNum == 301)
	{
	    writeArray[2]=0x24;	
	    writeArray[3]=0x71;
	}
	if(channelNum == 302)
	{
	    writeArray[2]=0x24;	
	    writeArray[3]=0x81;
	}
	if(channelNum == 303)
	{
	    writeArray[2]=0x24;	
	    writeArray[3]=0x91;
	}
	if(channelNum == 304)
	{
	    writeArray[2]=0x24;	
	    writeArray[3]=0xA1;
	}
	if(channelNum == 305)
	{
	    writeArray[2]=0x24;	
	    writeArray[3]=0xB1;
	}
	if(channelNum == 306)
	{
	    writeArray[2]=0x24;	
	    writeArray[3]=0xC1;
	}
	if(channelNum == 307)
	{
	    writeArray[2]=0x24;	
	    writeArray[3]=0xD1;
	}
	if(channelNum == 308)
	{
	    writeArray[2]=0x24;	
	    writeArray[3]=0xE1;
	}


	if(channelNum == 311)
	{
	    writeArray[0]=0x02;
	    writeArray[2]=0x24;	
	    writeArray[3]=0x71;
	}
	if(channelNum == 312)
	{
	    writeArray[0]=0x02;
	    writeArray[2]=0x24;	
	    writeArray[3]=0x81;
	}
	if(channelNum == 313)
	{
            writeArray[0]=0x02;
	    writeArray[2]=0x24;	
	    writeArray[3]=0x91;
	}
	if(channelNum == 314)
	{
            writeArray[0]=0x02;
	    writeArray[2]=0x24;	
	    writeArray[3]=0xA1;
	}
	if(channelNum == 315)
	{
            writeArray[0]=0x02;
	    writeArray[2]=0x24;	
	    writeArray[3]=0xB1;
	}
	if(channelNum == 316)
	{
            writeArray[0]=0x02;
	    writeArray[2]=0x24;	
	    writeArray[3]=0xC1;
	}
	if(channelNum == 317)
	{
            writeArray[0]=0x02;
	    writeArray[2]=0x24;	
	    writeArray[3]=0xD1;
	}
	if(channelNum == 318)
	{
            writeArray[0]=0x02;
	    writeArray[2]=0x24;	
	    writeArray[3]=0xE1;
	}
	int data=mode;
	short temp=(short)(data);

	writeArray[4]=(temp>>8)&0xff;
	writeArray[5]=temp&0xff;
	unsigned short t_crc = calculateLRC(writeArray,6);

	writeArray[6] = t_crc&0xff;
	writeArray[7] = t_crc>>8;
//	cout<<"The send Write Int Command is as Follow"<<endl;
	unsigned char result[8];
	for(int i=0;i<8;i++)
	{
		result[i]=writeArray[i];
//		cout<<hex<<showbase<<uppercase<<(unsigned short)result[i]<<" - ";

	}
//	cout<<endl;
 	char response[RESP_LEN];
	bzero(response, RESP_LEN);
	sendCommandOnly(writeArray, 8);
	if(getResultOnly(response, RESP_LEN, m_timeOut) < 0)
	{
		throw IOException("NXTemp reading back times out");
	}
	else
	{
		unsigned char res[8];
//		cout<<"The WriteInt Channel Num is %%%%%%%%%%%%%%%%  "<<dec<<noshowbase<<channelNum<<"%%%%%%%%%%% The Command is as follow"<<endl;
		for(int i=0;i<8;i++)
		{
			res[i]=response[i];
//			cout<<hex<<showbase<<uppercase<<(unsigned short)res[i]<<" - ";
		}
//		cout<<endl;
		if(response[1]!=0x06)
		{
			throw IOException("receive  an invalid command ,make sure the current mode is manual");
		}
		
	}
	
	return true;
}


//01 02 03 04 所有温控器的 13 14 15 16 通道为 读Auto或Maual通道
bool NXTempCtl::readInt(int channelNum,int * value ,const IntTypeInfo& typeinfo)
{	     	

	differNXTempDifferMachineCh(channelNum);

	int checkChannel=channelNum%30;
	switch (checkChannel)
	{

		case 13:
				readArray[2]=0x38;	
				readArray[3]=0x11;
				break;
		case 14:
				readArray[2]=0x38;	
				readArray[3]=0x19;
				break;
		case 15:
				readArray[2]=0x38;	
				readArray[3]=0x21;
				break;
		case 16:
				readArray[2]=0x38;	
				readArray[3]=0x29;
				break;
		default:
				break;

	}
	unsigned short t_crc = calculateLRC(readArray,6);
	readArray[6] = t_crc&0xff;
	readArray[7] = (t_crc>>8)&0xff;
	unsigned char res[8];
//	cout<<"The Int Channel Num is #######"<<dec<<noshowbase<<channelNum<<" ######The Command is as follow"<<endl;
	for(int i=0;i<8;i++)
	{
		res[i]=readArray[i];
//		cout<<hex<<showbase<<uppercase<<(unsigned short)res[i]<<" - ";
	}
//	cout<<endl;
	char response[RESP_LEN];
	bzero(response, RESP_LEN);
	sendCommandOnly(readArray, 8);
	if(getResultOnly(response, RESP_LEN, m_timeOut) < 0)
	{
		throw IOException("WatLow reading back times out");
	}
	unsigned char result[8];
//	cout<<"########The ReadDouble Response  Command is as follow########"<<endl;
	for(int i=0;i<7;i++)
	{
		result[i]=response[i];
//		cout<<hex<<showbase<<uppercase<<"-"<<(unsigned short)result[i];
	}
//	cout<<"\n"<<endl;
	if(response[1]==0x03)
	{		
		response[3]=response[3]&0x00ff;
		response[4]=response[4]&0x00ff;
		unsigned char s[2]={response[3],response[4]};	
		short dd=s[0]<<8|s[1];
		*value = (int)dd;
		return true;

	}
	else
	{
		
		throw IOException("NXTempDriver:the Response is invalid");
	}

		return true;
}


//地址为01 02 03 04 温控器的17 18 19 20 通道为读取PV的温度
//地址为01 02 03 04 温控器的21 22 23 24 通道为读取SP通道
//地址为01 02 03 04 温控器的 25 26 27 28 通道为读取MV的通道
bool NXTempCtl::readDouble(int channelNum,double * value ,const DoubleTypeInfo& typeinfo)
{	
	
	differNXTempDifferMachineCh(channelNum);
	int checkChannel=channelNum%30;
	switch (checkChannel)
	{


		case 17:
				readArray[2]=0x38;	
				readArray[3]=0x14;
				break;
		case 18:
				readArray[2]=0x38;	
				readArray[3]=0x1C;
				break;
		case 19:
				readArray[2]=0x38;	
				readArray[3]=0x24;
				break;
		case 20:
				readArray[2]=0x38;	
				readArray[3]=0x2C;
				break;

		case 21:
				readArray[2]=0x38;	
				readArray[3]=0x15;
				break;
		case 22:
				readArray[2]=0x38;	
				readArray[3]=0x1D;
				break;
		case 23:
				readArray[2]=0x38;	
				readArray[3]=0x25;
				break;
		case 24:
				readArray[2]=0x38;	
				readArray[3]=0x2D;
				break;

		case 25:
				readArray[2]=0x38;	
				readArray[3]=0x16;
				break;
		case 26:
				readArray[2]=0x38;	
				readArray[3]=0x1E;
				break;
		case 27:
				readArray[2]=0x38;	
				readArray[3]=0x26;
				break;
		case 28:
				readArray[2]=0x38;	
				readArray[3]=0x2E;
				break;
		default:
				break;

	}
	unsigned short t_crc = calculateLRC(readArray,6);
	readArray[6] = t_crc&0xff;
	readArray[7] = (t_crc>>8)&0xff;
//	cout<<"The ReadDouble Channel Num is @@@@@@  "<<dec<<noshowbase<<channelNum<<"  @@@@@@@ The Command is as follow"<<endl;

	for(int i=0;i<8;i++)
	{	
		unsigned char sendomand[8];
		sendomand[i]=readArray[i];
//		cout<<hex<<showbase<<uppercase<<"-"<<(unsigned short)sendomand[i];
	}
//	cout<<endl;
	char response[RESP_LEN];
	bzero(response, RESP_LEN);
	sendCommandOnly(readArray, 8);
	if(getResultOnly(response, RESP_LEN, m_timeOut) < 0)
	{
		throw IOException("WatLow reading back times out");
	}
	unsigned char res[7];
//	cout<<"@@@@@@The ReadDouble Response  Command is as follow@@@@@@"<<endl;
	for(int i=0;i<7;i++)
	{
		res[i]=response[i];
//		cout<<hex<<showbase<<uppercase<<(unsigned short)res[i]<<" - ";
	}
//	cout<<"\n"<<endl;

	if(response[1]==0x03)
	{		
		response[3]=response[3]&0x00ff;
		response[4]=response[4]&0x00ff;
		unsigned char s[2]={response[3],response[4]};	
		short dd=s[0]<<8|s[1];
		/*if(checkChannel ==17 || checkChannel ==18 ||checkChannel ==19 || checkChannel ==20)
		{
			*value = (double)dd/10.0;
			return true;
		}*/
		
		*value = (double)dd/10.0;
		setDoubleValue(channelNum + MONITORDOUBLEVALUEADDMAP, *value, typeinfo.getAccuracy());//add by wzd 1.5.0 for NXTempCtl Protect CIP
		return true;

	}
	else
	{
		
		throw IOException("NXTempDriver:the read data command is invalid");
	}
}

bool NXTempCtl::readAlarm(int channelNum,int * value ,const IntTypeInfo& typeinfo)
{
	if( (channelNum%200) >= 0 && (channelNum%200) <= 3)
	{
		readArray[0]=0x01;
	}
	else if( (channelNum%200) >= 4 && (channelNum%200) <= 7)
	{
		readArray[0]=0x02;
	}
	else if( (channelNum%200) >= 8 && (channelNum%200) <= 11)
	{
		readArray[0]=0x03;
	}
	else if( (channelNum%200) >= 12 && (channelNum%200) <= 15)
	{
		readArray[0]=0x04;
	}
	readArray[2]=0x28;
	readArray[3]=0x30;


	unsigned short t_crc = calculateLRC(readArray,6);
	readArray[6] = t_crc&0xff;
	readArray[7] = (t_crc>>8)&0xff;
	unsigned char res[8];
//	cout<<"The Int Channel Num is #######"<<dec<<noshowbase<<channelNum<<" ######The Command is as follow"<<endl;
	for(int i=0;i<8;i++)
	{
		res[i]=readArray[i];
//		cout<<hex<<showbase<<uppercase<<(unsigned short)res[i]<<" - ";
	}
//	cout<<endl;
	char response[RESP_LEN];
	bzero(response, RESP_LEN);
	sendCommandOnly(readArray, 8);
	if(getResultOnly(response, RESP_LEN, m_timeOut) < 0)
	{
		throw IOException("WatLow reading back times out");
	}
	unsigned char result[8];
//	cout<<"########The ReadAlarm Response  Command is as follow########"<<endl;
	for(int i=0;i<7;i++)
	{
		result[i]=response[i];
//		cout<<hex<<showbase<<uppercase<<"-"<<(unsigned short)result[i];
	}
//	cout<<"\n"<<endl;
	if(response[1]==0x03)
	{
		response[3]=response[3]&0x00ff;
		response[4]=response[4]&0x00ff;
		unsigned char s[2]={response[3],response[4]};
		short dd=s[0]<<8|s[1];
		int nTempValue = (int)dd;

		if(channelNum == 200||channelNum == 204||channelNum == 208||channelNum == 212)
		{
			if(nTempValue & 0x1)
			{
				*value = 1;//Has Alarm
			}
			else
			{
				*value = 0;//No Alarm
			}
		}
		if(channelNum == 201||channelNum == 205||channelNum == 209||channelNum == 213)
		{
			if(nTempValue & 0x4)
			{
				*value = 1;//Has Alarm
			}
			else
			{
				*value = 0;//No Alarm
			}
		}
		if(channelNum == 202||channelNum == 206||channelNum == 210||channelNum == 214)
		{
			if(nTempValue & 0x10)
			{
				*value = 1;//Has Alarm
			}
			else
			{
				*value = 0;//No Alarm
			}
		}
		if(channelNum == 203||channelNum == 207||channelNum == 211||channelNum == 215)
		{
			if(nTempValue & 0x40)
			{
				*value = 1;//Has Alarm
			}
			else
			{
				*value = 0;//No Alarm
			}
		}
		return true;

	}
	else
	{

		throw IOException("NXTempDriver:the Response is invalid");
	}

		return true;
}



void NXTempCtl::initChs(DeviceNode<NXTempCtl> *node)
{	

	//node->registerReadCh(0, &SerialDevice::connectStatus);

	for(int i=0;i<12;i=i+3)
	{
		int checkChannel=i*10;
		for( int j=checkChannel+1; j<checkChannel+9;j++)
		{
			node->registerWriteCh(j, &NXTempCtl::writeDouble);
		}

		for( int j=checkChannel+9;j<checkChannel+13;j++)
		{
			node->registerWriteCh(j, &NXTempCtl::writeInt);
		}

		for(int j=checkChannel+13 ; j<checkChannel+17;j++)
		{
			node->registerReadCh(j, &NXTempCtl::readInt);
		}

		for( int j= checkChannel +17 ;j< checkChannel +29;j++)
		{
			node->registerReadCh(j, &NXTempCtl::readDouble);
			node->registerReadCh(j + MONITORDOUBLEVALUEADDMAP, &CMonitorDoubleValue::readDoubleChange);//add by wzd 1.5.0 for NXTempCtl Protect CIP
	        initDoubleValue(j + MONITORDOUBLEVALUEADDMAP, -1);//add by wzd 1.5.0 for NXTempCtl Protect CIP
		}
	}
	for(int i=200;i<216;i++)
	{
		node->registerReadCh(i, &NXTempCtl::readAlarm);
	}
	for(int i=300;i<319;i++)  //add by wzd 1.1.43
	{
	    node->registerWriteCh(i, &NXTempCtl::writeInt);
	}
    

	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &NXTempCtl::getStatus);
}
void NXTempCtl::initDevice()
{

}

void NXTempCtl::init()
{
	cout<<getName()+"NXTempCtl init start"<<endl;
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "NXTempCtl start");
	DeviceNode<NXTempCtl> *node = new DeviceNode<NXTempCtl>(m_pollPeriod, this);
	initChs(node);		
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	initDevice();
	cout<<getName()+"NXTempCtl end start"<<endl;
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "NXTempCtl end");

}

IMPLEMENT_DYNAMIC(NXTempCtl, SerialDevice)

BEGIN_MSG_MAP(NXTempCtl, SerialDevice)
	SET_V( init, NXTempCtl)
END_MSG_MAP
