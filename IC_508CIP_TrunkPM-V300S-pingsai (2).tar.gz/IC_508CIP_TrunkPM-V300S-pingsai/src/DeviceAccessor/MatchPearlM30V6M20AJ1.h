/********************************************************************
** Copyright (c) 2020, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MatchPearlM30V6M20AJ1.h
** Description: This driver is used for Pearl match of M30V6M20AJ1
*                RS232
* 				 Communication Type:Modbus protocol,ASCII Mode
* 				 BaudRate:38400
*              DataBit:7
*              StopBit:1
*              Parity:Even
* In the code, we use function code 03 to read ; function code 10 to write
* Slave address is 01 as the default.
*
** Release: 1.0
** Modification history: 
** 					2020-05-16   mayc create
**      
*********************************************************************/
#ifndef MatchPearlM30V6M20AJ1_H_
#define MatchPearlM30V6M20AJ1_H_

#include "SerialDevice.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class MatchPearlM30V6M20AJ1:public SerialDevice
{
	DECLARE_DYNAMIC(MatchPearlM30V6M20AJ1)
	DECLARE_MSG_MAP	
	
	public:
		MatchPearlM30V6M20AJ1();
		virtual ~MatchPearlM30V6M20AJ1();
		
		bool readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);
		bool readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);
		bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
		void init();

	protected:
		void initDevice();
		void initChs(DeviceNode<MatchPearlM30V6M20AJ1> *pNode);
		string sendCommandAndReadResponse(string &strCommond, int nTimeOut);
		int readAddress6000(int nTimeOut);
		void set2MFlag(bool flag);
	private:
		typedef struct
		{
			std::string m_strCmd;
			int m_nDeal;
		}Cmd;
		
		static Cmd m_cmd[];
		int m_nFullScale;
		int m_nPreC1;
		int m_nPreC2;
		bool m_b2MFlag;
};

#endif /*MatchPearlM30V6M20AJ1_H_*/
