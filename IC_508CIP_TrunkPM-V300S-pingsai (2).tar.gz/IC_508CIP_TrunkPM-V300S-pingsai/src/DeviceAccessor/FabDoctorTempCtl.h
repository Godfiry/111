/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: IR422GasMonitorDriver.h
** Description: This driver is used for IR-422 GasMonitor
*                  RS485 communication protocol 
* 				   Communication Type:ASCII Mode
* 				   BaudRate:38400
*                  DataBit:7
* 				   StartBit:1
*                  StopBit:1
*                  Parity:odd
*                          
** Release: 1.1
** Modification history: 
** 					
     
*********************************************************************/
#ifndef FABDOCTORTEMPCTL_H_
#define FABDOCTORTEMPCTL_H_

#include "SerialDevice.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#include "MonitorDoubleValue.h" //added by zhangyy for FabDoctorTempCtl Protect CIP[1.5.0]
#ifdef IAP4_0
using namespace IAP::IO;
#endif


#define MONITORDOUBLEVALUEADDMAP 300//added by zhangyy for FabDoctorTempCtl Protect CIP[1.5.0]

class FabDoctorTempCtl : public SerialDevice, public CMonitorDoubleValue
{
	DECLARE_DYNAMIC(FabDoctorTempCtl)	
	DECLARE_MSG_MAP	
	
	public:
		FabDoctorTempCtl();
		virtual ~FabDoctorTempCtl();
		
		bool readDouble(int nChannelNum, double *pValue,const DoubleTypeInfo &typeInfo);
		bool writeDouble(int nChannelNum, double value,const DoubleTypeInfo &typeInfo);
		void setForlineTempInfo(int tTempStartPos, int tTempEndPos);
		void setGaugeTempInfo(int tTempStartPos, int tTempEndPos);
		void setGaslineTempInfo(int tTempStartPos, int tTempEndPos);
		void init();
		
	protected:
		std::string readCommand(std::string strCommand, int ntimeOut);	
	    void initDevice();
	    void initChs(DeviceNode<FabDoctorTempCtl>* pNode);
	    int m_ForlineTempStartPos;
	    int m_ForlineTempEndPos;
	    int m_GaugeTempStartPos;
	    int m_GaugeTempEndPos;
	    int m_GaslineTempStartPos;
	    int m_GaslineTempEndPos;
	    
		
	private:
		typedef struct
		{
			int m_nCmdSize;
			std::string m_strCmd;
			int m_nResLength;
		}Com; 
	static Com m_Commands[];
	
	std::string m_startCmd;
	std::string m_strAddress;
	std::string m_endCmd;
};

#endif /*FABDOCTORTEMPCTL_H_*/
