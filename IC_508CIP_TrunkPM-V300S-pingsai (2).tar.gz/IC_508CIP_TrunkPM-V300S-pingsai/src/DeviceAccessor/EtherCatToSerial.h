/*
 * EtherCatToSerial.h
 *
 *  Created on: 2024年12月27日
 *      Author: wenxiang
 */

#ifndef SRC_DEVICEACCESSOR_ETHERCATTOSERIAL_H_
#define SRC_DEVICEACCESSOR_ETHERCATTOSERIAL_H_

#include "DevicePara.h"
#include "SHMInitInstance.h"
#include "IMutex.h"
#include "IWaitCondition.h"
#include <list>
#include <string>

#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
#endif
class EtherCatToSerial
{

private:
	int m_fd;
	unsigned short m_slaveAddress;
	unsigned short m_index;
	bool m_beckHoffFlag;
	SerialPortMap m_serialPortMap;

	static std::list<int> m_availabeSDONum;
	static IMutex m_SDONumMutex;
	static IWaitCondition m_SDONumCond;


public:
	EtherCatToSerial();
	~EtherCatToSerial();

public:
	bool Convert(const SerialPortSettings portsettings);

	bool ConvertBaudRate(unsigned int baudrate);

	bool ConvertBeckHoffBaudRate(unsigned int baudrate);

	bool ConvertDataBit(unsigned int databit);

	bool ConvertStopBit(unsigned int stopbit);

	bool ConvertParity(unsigned int paritymode);

	bool ConvertDataFrame(const std::string &dataframe);

	bool shmSerialOpen(const char *dev, const SerialPortSettings portsettings);

	static void ReleaseSDONum(int num);

	void setBeckHoffFlag(bool flag);

	void closePort();

	void InitSDONumPOOL();

	int SerialSetBySDO(unsigned short slaveaddress, unsigned short index, unsigned char subIndex, unsigned int length, unsigned char * data);

	static int AcquireSDONum();

	int shmSerialReadStr(char * readBuf,int timeOutMs,int readLength, short *error);

	int shmSerialWriteRaw(const char * writeBuf,int writeLength, short *error);

	std::string unsignedToHexString(unsigned char uc);

};

#endif /* SRC_DEVICEACCESSOR_ETHERCATTOSERIAL_H_ */
