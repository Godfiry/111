/*
 * EtherCatBaseDevice.h
 *
 *  Created on: 2023��11��2��
 *      Author: liusiyuan
 */

#ifndef SRC_DEVICEACCESSOR_EtherCatBaseDevice_H_
#define SRC_DEVICEACCESSOR_EtherCatBaseDevice_H_

#include "AbstractDevice.h"
#include "DeviceNode.h"
#include "EtherCat.h"
#include "IntTypeInfo.h"
#include "DoubleTypeInfo.h"
#include <vector>
#include "MathTool.h"
#include "DefineValue.h"
#include "CommunicationStatusEnum.h"
#include "Hex.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class EtherCatBaseDevice :public AbstractDevice{

	DECLARE_DYNAMIC(EtherCatBaseDevice)
	DECLARE_MSG_MAP

public:
	EtherCatBaseDevice();
	virtual ~EtherCatBaseDevice();

	virtual bool readBit(int channelNum, int *bit, const IntTypeInfo &typeInfo);
	virtual bool writeBit(int channelNum, int bit, const IntTypeInfo &typeInfo);
	virtual bool readAnalog(int channelNum, double *value, const DoubleTypeInfo &typeInfo);
	virtual bool writeAnalog(int channelNum, double value, const DoubleTypeInfo &typeInfo);
	virtual bool readInt(int channelNum, int *value, const IntTypeInfo &typeInfo); //add by zhangpf[1.1.57_HotFix2]
	virtual bool writeInt(int channelNum, int value, const IntTypeInfo &typeInfo);//add by zhangpf[1.1.57_HotFix2]
 
	virtual bool readEcatStatus(int channelNum, int *value, const IntTypeInfo &typeInfo);   //add by wzd 1.1.65 hotfix4

	virtual void initDevice();
	virtual void initDeviceNet();
	virtual void init();

	//xml
	void setDebugMode(bool bEnable);
	void setTimeOut(int time);
	void setNodeNum(int nodeNum);
	void setEtherCatDeviceTotalNum(int nNum);
	void setMacMap(string strData);
	void addDeviceAO(string strData);
	void addDeviceAI(string strData);
	void addDeviceDI(string strData);
	void addDeviceDO(string strData);
	void setPollIntervalMS(int interval);

protected:
	bool StringToList(string strSource, vector<int> &vlist);
	void FloatToByte(float floatNum, unsigned char* byteArry);

	virtual void initChs(DeviceNode<EtherCatBaseDevice> *node);



	static EtherCat *m_EtherCat;
	char* m_pWriteBuffer;
	char* m_pReadBuffer;
	DeviceParam m_deviceParam;
	int m_nMacID;

	int m_nodeNum; //modify by zhangpf[1.1.57_HotFix2]

	typedef struct
	{
		int m_index;
		int m_subIndex;
		int m_datasize;
	}Com;

private:
	
	//int m_nodeNum;
	int m_nEtherCatTotalNum;
	bool m_bDebugEnable;
	int m_pollInterval;
	int m_TimeOut;
};

#endif /* SRC_DEVICEACCESSOR_EtherCatBaseDevice_H_ */
