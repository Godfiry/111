/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: StatusMonitor.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-9-28   LiJuanjuan create
**      			2016-10-18   mujy added [V1.5.16] 
*********************************************************************/
#include "StatusMonitor.h"
#include "SysLogger.h"
#include "ConfigException.h"
#include "ObjectManager.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "InvalidNameException.h"
#endif
#include "CheckItem.h"
#include "UTime.h"
#include "Converter.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;

StatusMonitor::StatusMonitor()
{
	m_intervalS = NULL;//ms
	m_startDelayS = NULL;	
	m_autoStart = false;
	m_monitorEnable = false;//added by mujy [V1.5.16]
	m_waitstableFlag = false;
}

StatusMonitor::~StatusMonitor()
{
}

void StatusMonitor::internalExecute()
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": start running");
	while(m_monitorEnable && getStatus() == RUN)//modified by mujy [V1.5.16]
	{
		m_mutex.lock();
		if(getName().find("ProcessMonitor") != string::npos)
		{
			//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + ": while start..");
		}
		if(m_waitstableFlag && m_startDelayS != NULL)//added by xiasc for 508M time test
		{
		  usleep((long)(m_startDelayS->getValue() * 1000000));
		  m_waitstableFlag = false;//execute only one time every step
		  SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,"monitor sleep stable time "+Converter::convertToString(m_startDelayS->getValue())+"s");
		}
		//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + ": ABOUT TO CHECK");
		for(unsigned int i=0; i<m_checkItems.size() && getStatus() == RUN; ++i)
		{
			try
			{
				m_checkItems[i]->check();
			}
			catch(const exception &ex)
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": got exception:" + string(ex.what()));								
			}
		}
		m_mutex.unlock();
		if(getName().find("ProcessMonitor") != string::npos)
		{
			//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + ": while middle..");
		}
		if(m_intervalS != NULL && getStatus() == RUN)
		{
			usleep((long)(m_intervalS->getValue() * 1000000));
		}
		if(getName().find("ProcessMonitor") != string::npos)
		{
			//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + ": while end..");
		}
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": stop running");
}
	
void StatusMonitor::startup()
{
	if(m_autoStart)
	{
		BeginMonitor();//added by mujy [V1.5.16]
		usleep(200*1000);
		start();
	}
}

void StatusMonitor::shutdown()
{
	stop();
	EndMonitor();
}

void StatusMonitor::BeginMonitor()//added by mujy [V1.5.16]
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": about to BeginMonitor");							
	if(!isSimulated())
	{
		if(!startMonitoring())
		{
			usleep(200*1000);
			startMonitoring();
		}
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": done BeginMonitor");							
}

void StatusMonitor::start()
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": about to start");							
	IMutexLocker locker(&m_mutex);
	if(!isSimulated())
	{
		for(unsigned int i=0; i<m_checkItems.size(); ++i)
		{
			m_checkItems[i]->start();
		}
		m_monitorEnable = true;//modified by mujy [V1.5.16]
		m_waitstableFlag = true;
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": done start");							
}

void StatusMonitor::EndMonitor()//added by mujy [V1.5.16]
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": about to EndMonitor");							
	if(!isSimulated())
	{
		if(!exitMonitoring())
		{
			usleep(200*1000);
		}
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": done EndMonitor");							
}
		
void StatusMonitor::stop()
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": about to stop");
	IMutexLocker locker(&m_mutex);
	if(!isSimulated())
	{	
		m_monitorEnable = false;//modified by mujy [V1.5.16]
		for(unsigned int i=0; i<m_checkItems.size(); ++i)
		{
			m_checkItems[i]->stop();
		}	
		m_waitstableFlag = false;	
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": done stop");							
}

void StatusMonitor::enableAllCheckItem() //added by heyj[1.2.7HotFix]
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": about to enableAllCheckItem");
	IMutexLocker locker(&m_mutex);
	for (unsigned int i = 0; i < m_checkItems.size(); ++i)
	{
		if (!m_checkItems[i]->isEnabled())
		{
			m_checkItems[i]->do_Enable();
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": checkItem " + m_checkItems[i]->getName() + " was previously disabled and is now enabled.");
		}		
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": done enableAllCheckItem");
}

int StatusMonitor::getCheckItemSize()const
{
	return m_checkItems.size();
}

CheckItem* StatusMonitor::getCheckItem(int index)const
{
	if(index >= 0 && index< getCheckItemSize())
	{
		return m_checkItems[index];
	}
	else
	{
		return NULL;
	}
}
/*
void StatusMonitor::setStartTimeToItems()
{
	long t_time = UTime::getCurrentTimeAsMSeconds();
	for(unsigned int i=0; i<m_checkItems.size(); ++i)
	{
		m_checkItems[i]->setStartTime(t_time);
	}	
}*/
		
void StatusMonitor::setIntervalS(double timeS)
{
	if(m_intervalS == NULL)
	{
		m_intervalS = new ReadWriteDouble(getName()+"/Interval", DoubleTypeInfo());
	}
	else
	{
		ObjectManager::getInstance()->createAlias(m_intervalS->getName(), getName()+"/Interval");
	}
	m_intervalS->setValue(timeS);	
}
		
void StatusMonitor::setStartDelayS(double timeS)
{
	if(m_startDelayS == NULL)
	{
		m_startDelayS = new ReadWriteDouble(getName()+"/StartDelay", DoubleTypeInfo());
	}
	else
	{
		ObjectManager::getInstance()->createAlias(m_startDelayS->getName(), getName()+"/StartDelay");
	}
	m_startDelayS->setValue(timeS);		
}
	
void StatusMonitor::setIntervalSCh(const std::string &path)
{
	ManagedObject *t_obj = NULL;
	try
	{
		t_obj = ObjectManager::getInstance()->getObject(this, path);
	}
	catch(const InvalidNameException &ex)
	{
		t_obj = ObjectManager::getInstance()->getObject(path);
	}
	ReadWriteDouble *t_obj2 = dynamic_cast<ReadWriteDouble*>(t_obj);
	if(NULL == t_obj2)
	{
		string error = "the object under path '" + path + "' is not a ReadWriteDouble";
		throw ConfigException(error);
	}
	m_intervalS = t_obj2;		
}
		
void StatusMonitor::setStartDelaySCh(const std::string &path)
{
	ManagedObject *t_obj = NULL;
	try
	{
		t_obj = ObjectManager::getInstance()->getObject(this, path);
	}
	catch(const InvalidNameException &ex)
	{
		t_obj = ObjectManager::getInstance()->getObject(path);
	}
	ReadWriteDouble *t_obj2 = dynamic_cast<ReadWriteDouble*>(t_obj);
	if(NULL == t_obj2)
	{
		string error = "the object under path '" + path + "' is not a ReadWriteDouble";
		throw ConfigException(error);
	}
	m_startDelayS = t_obj2;		
}		
		
void StatusMonitor::addCheckItem(const std::string &path)
{
	ManagedObject *t_obj = NULL;
	try
	{
		t_obj = ObjectManager::getInstance()->getObject(this, path);
	}
	catch(const InvalidNameException &ex)
	{
		t_obj = ObjectManager::getInstance()->getObject(path);
	}
	CheckItem *t_obj2 = dynamic_cast<CheckItem*>(t_obj);
	if(NULL == t_obj2)
	{
		string error = "the object under path '" + path + "' is not a CheckItem";
		throw ConfigException(error);
	}
	addToCheckItems(t_obj2);		
}
		
void StatusMonitor::addToCheckItems(CheckItem *item)
{
	m_checkItems.push_back(item);
}

void StatusMonitor::setAutoStart(bool flag)
{
	m_autoStart = flag;
}

IMPLEMENT_DYNAMIC(StatusMonitor, ControlMonitor)

BEGIN_MSG_MAP(StatusMonitor, ControlMonitor)
	SET_S(addCheckItem, StatusMonitor)
	SET_S(setIntervalSCh, StatusMonitor)
	SET_S(setStartDelaySCh, StatusMonitor)		
	SET_D(setStartDelayS, StatusMonitor)
	SET_D(setIntervalS, StatusMonitor)
	SET_B(setAutoStart, StatusMonitor)
END_MSG_MAP

