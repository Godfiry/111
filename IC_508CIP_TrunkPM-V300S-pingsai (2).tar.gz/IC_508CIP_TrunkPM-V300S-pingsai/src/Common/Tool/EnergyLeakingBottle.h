/*
 * EnergyBlock.h
 *
 *  Created on: 2021-11-17
 *      Author: lvjiawen
 */

#ifndef SRC_COMMON_TOOL_ENERGYLEAKINGBOTTLE_H_
#define SRC_COMMON_TOOL_ENERGYLEAKINGBOTTLE_H_

#include "TimerEx.h"
#include "IMutex.h"
#include "CBase.h"
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

class IEnergyLeakingBottleEmptyListener
{
public:
    virtual void onEnergyLeakingBottleEmpty() = 0;
};

class EnergyLeakingBottle:public ITimeTicker,virtual public CBase
{
private:
    EnergyLeakingBottle(const EnergyLeakingBottle& pObj); //modified by chenw [1.6.0_RC02]

    EnergyLeakingBottle& operator=(const EnergyLeakingBottle& pObj);

public:
    EnergyLeakingBottle();

    virtual ~EnergyLeakingBottle();

public:
    void fillUp();
    void flush();
    bool isEmpty();

    //void AddEnergy_ms(int nEnergy);
    //void AddEnergy_s(int nEnergy);
    //void AddEnergy_min(int nEnergy);

public:
    void setCapacity_ms(int nCapcity);
    void setCapacity_s(int nCapcity);
    void setCapacity_min(int nCapcity);

    void setEmptyListener(IEnergyLeakingBottleEmptyListener *pEmptyListener);

public:
    virtual void updateFromTimer(TimerEx * pSender);

protected:
    virtual void leaking();
    virtual void onEmpty();

private:
    int m_nEnergy;//ms
    int m_nCapcity;

private:
    TimerEx * m_pTimer;
    IEnergyLeakingBottleEmptyListener * m_pEmptyListener;
    mutable IMutex *m_pMutex; //lock m_strDestinationPos
};

#endif /* SRC_COMMON_TOOL_ENERGYLEAKINGBOTTLE_H_ */
