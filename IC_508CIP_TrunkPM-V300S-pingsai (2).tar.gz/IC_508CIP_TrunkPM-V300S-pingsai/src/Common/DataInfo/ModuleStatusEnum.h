#ifndef MODULESTATUSENUM_H_
#define MODULESTATUSENUM_H_
       
namespace MODULE_STATUS
{
	enum ModuleStatusEnum
	{
		InfoIsNew=-1,
		Offline,
		UnInit,
		NotReady,
		Standby,
		CTCInUse,
		MaintReq,
		MaintPend,
		MaintMode
	};
}

#endif /*MODULESTATUSENUM_H_*/
