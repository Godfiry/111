#!/bin/bash

#CopyRight:
#Author:	lv Jiawen
#Date:		2014.08.06
#Descript:	back-up
#Version:	1.1

Path=$(pwd)
echo $Path

find $Path -name '*~' -type f -print -exec rm -rf {} \;
find $Path -name '*.bak' -type f -print -exec rm -rf {} \;
find $Path -name '*.o' -type f -print -exec rm -rf {} \;
find $Path -name 'core.*' -type f -print -exec rm -rf {} \;
find $Path -name '*.keep' -type f -print -exec rm -rf {} \;
find $Path -name '*.cproject' -type f -print -exec rm -rf {} \;
find $Path -name '*.project' -type f -print -exec rm -rf {} \;
find $Path -name 'led.sh' -type f -print -exec chmod 777 {} \;
read -p "Press Enter to exit..."
