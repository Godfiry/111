/********************************************************************
** Copyright (c) 2020, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: EPDHoribaLEM.h
** Description:
** Release: 1.1
** Modification history:
** 					2020-4-20   zhangyy create
**
** Product type: Horiba LEM G50
** Device communication setting:
** 			Control mode:      TCP/IP
**     	
*********************************************************************/
#ifndef EPDHORIBALEM_H_
#define EPDHORIBALEM_H_

#include "TCPDeviceHoriba.h"
#include "DeviceNode.h"
#include "IntTypeInfo.h"
#include "StringTypeInfo.h"
#include "ReadWriteDouble.h"
#include <string>
#include <vector>
#include <map>
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class EpdHoribaLem:public TCPDeviceHoriba
{
	DECLARE_DYNAMIC(EpdHoribaLem)	
	DECLARE_MSG_MAP	
	
public:
	EpdHoribaLem();
	virtual ~EpdHoribaLem();
	
public:
	virtual void acceptData();
	virtual std::string getDeviceName();
	void setEventError(const std::string &strError);
	std::string getEventError();
	bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
	bool writeString(int nChannelNum, std::string pValue, const StringTypeInfo &typeInfo);
	bool readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);
	bool readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);
	bool readString(int nChannelNum, std::string *pValue, const StringTypeInfo &typeInfo);

public://xml
	virtual void init();
	void setNameOfSPCV(const std::string &strName);
	void setLogOn(bool bFlag);

protected:
	void flush();
	void parseCmd();
	void parseEvent();
	std::string splitNul(char Array[], unsigned int nDataSegmentNum);
	double getTraceData(const std::string &strDataName);
	void sendCmd(const char *pData, int nLength);

private:
	void initDevice();
	void initChannels(DeviceNode<EpdHoribaLem> *pNode);

private:
	typedef struct
	{
		int nCmdID;
		char cParamNum;
		std::string strBody;
		int nCmdLength;
	}Cmd;
	static Cmd m_commands[];
	std::string m_strError;
	std::string m_strEventError;
	std::map<std::string, double> m_MapTraceDatas;
	
	std::string m_strConfigList;//RecipeList
	std::string m_strConfigName;
	std::string m_strWaferID;
	std::string m_strLotID;
	std::string m_strCassetID;
	std::string m_strStepName;
	std::string m_strSenderID;
	std::string m_strReceiverID;
	
	int m_nEpdStatus;//0:unknown 1:disconnect 2:ready 3:notready
	int m_nEndPoint;//1 reach endpoint; 0 not
	double m_dEndPointTime;
	bool m_bWaiting;
	bool m_bLogOn;
		
};

#endif /*EPDHORIBALEM_H_*/
