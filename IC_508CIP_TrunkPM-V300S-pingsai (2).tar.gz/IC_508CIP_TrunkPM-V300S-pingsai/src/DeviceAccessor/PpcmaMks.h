/********************************************************************
** Copyright (c) 2017, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: PpcmaMks.cpp
** Description: PpcmaMks is the class of  PPCMA   instead of 649 gauge
** Release: 1.1
** Modification history: 
** 					2019-01-19   maxm create
**      
*********************************************************************/
#ifndef PPCMAMKS_H_
#define PPCMAMKS_H_

#include "IODevice.h"
#include "DeviceNode.h"
#include "DeviceManager.h"
#include "ConfigException.h"
#include "ReadWriteInt.h"

#include "DoubleTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif
//using namespace std;
class PpcmaMks:public IODevice
{
	DECLARE_DYNAMIC(PpcmaMks)	
	DECLARE_MSG_MAP		
	public:
		PpcmaMks();
		virtual ~PpcmaMks();

	
	public://for config					
		virtual void init();
		bool setMaxBinaryValue(int value);
		bool setMaxFlowBinaryValue(int value);

	public:		
		bool writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo);
		bool readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo);
		
	private:
		char m_pBufferSave[5];
		int m_nStatus;
		double m_maxBinaryValue;
		double m_maxFlowBinaryValue;
};
#endif /*PPCMAMKS_H_*/
