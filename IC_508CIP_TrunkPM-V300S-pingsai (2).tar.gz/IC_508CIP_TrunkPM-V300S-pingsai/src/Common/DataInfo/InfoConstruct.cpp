#include "SlotMapInfo.h"
#include "ChamberOperatingModeInfo.h"
#include "DisableEnableInfo.h"
#include "HandoffModeInfo.h"

#include "PMAnmInfo.h"

#include "PMStatusInfo.h"

#include "PMStateInfo.h"

#include "PressureConditionInfo.h"
#include "IdleActiveInfo.h"

#include "ServiceResultInfo.h"
#include "SlotSensorInfo.h"
#include "TransferOperationInfo.h"
#include "XferAnmInfo.h"
#include "XferStsInfo.h"
#include "YesNoInfo.h"
#include "VacuumTypeInfo.h"//lijj
#include "SlotInfo.h"//shenql
#include "RecipeNameInfo.h"//shenql

#include "LotIdInfo.h"//shenql

#include "IOPositionInfo.h"//lijj
#include "IntTypeInfo.h"//lijj
#include "MaterialIdInfo.h"//wangyg
#include "RecipeTimeInfo.h"//wangyg
#include "SlotIdInfo.h"//lijj
#include "StepNumInfo.h"//lijj
#include "InterruptRcpStepInfo.h"//lijj
#include "RecipeControlInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

const IntTypeInfo SlotMapInfo::typeInfo(DescriptorList("UnInit:-1,Unknown,Absent,Present,XSlotted,Doubled,Present200,Present300"));
const IntTypeInfo ChamberOperatingModeInfo::typeInfo(DescriptorList("UnInit:-1,VAC,ATM"));
const IntTypeInfo DisableEnableInfo::typeInfo(DescriptorList("UnInit:-1,Disable,Enable"));
const IntTypeInfo HandoffModeInfo::typeInfo(DescriptorList("UnInit:-1,Unknown,Passive,Active"));
const IntTypeInfo IdleActiveInfo::typeInfo(DescriptorList("UnInit:-1,Idle,Active"));
const IntTypeInfo PMAnmInfo::typeInfo(DescriptorList("UnInit:-1,Init,Preparing,Prepared,Processing,Processed,Aborted"));

const IntTypeInfo PMStateInfo::typeInfo(DescriptorList("UnInit:-1,Init,Rd4Next,Rd4Clean,Rd2ClnEmp,NotRd"));

const IntTypeInfo PMStatusInfo::typeInfo(DescriptorList("UnInit:-1,Unknown,Preparing,Prepared,Processing,Processed,Paused,Aborted,BadWfr"));

const IntTypeInfo PressureConditionInfo::typeInfo(DescriptorList("UnInit:-1,Unknown,AtAtm,InBetWeen,AtHiVac"));
const IntTypeInfo ServiceResultInfo::typeInfo(DescriptorList("UnInit:-1,Success,Failure,BROKEN_SUBSTRATE"));
const IntTypeInfo SlotSensorInfo::typeInfo(DescriptorList("UnInit:-1,Unknown,Opened,Closed,Error,None"));
const IntTypeInfo TransferOperationInfo::typeInfo(DescriptorList("UnInit:-1,Receive,Send,Swap,Xfer"));
const IntTypeInfo XferAnmInfo::typeInfo(DescriptorList("UnInit:-1,Init,PreChming,PreChmbed,Moving,Moved,Mapping,Mapped,Starting,Started,Ending,Ended"));
const IntTypeInfo XferStsInfo::typeInfo(DescriptorList("UnInit:-1,Unknown,PreChming,PreChmbed,PrpWfring,PrpWfred,XfrWfring,XfrWfred,CmtWfring,CmtWfred,Cleaning,Cleaned,Rd4Cln,Mapping,Mapped,Initting,Initted,Shutdown,Shut,Paused,Aborted"));
const IntTypeInfo YesNoInfo::typeInfo(DescriptorList("UnInit:-1,NO,YES"));
const IntTypeInfo VacuumTypeInfo::TimeTypeInfo(0, 9999);//lijj
const DoubleTypeInfo VacuumTypeInfo::PressureTypeInfo(0.0, 9999, "torr", 0.001);//lijj
const DoubleTypeInfo VacuumTypeInfo::FlowTypeInfo(-3.0, 100000, "", 0.1);//changed 1000 to 10000 by mujy [v1.0.5]  chensc changed 0 and 10000 to -3 and 100000
const IntTypeInfo VacuumTypeInfo::TimeOut(1,0xf4240);//lijj
const IntTypeInfo SlotInfo::typeInfo(DescriptorList("UnInit:-1,All:0,1:1,2:2,3:3,4:4,5:5,6:6,7:7,8:8,9:9,10:10,11:11,12:12,13:13,14:14,15:15,16:16,17:17,18:18,19:19,20:20,21:21,22:22,23:23,24:24,25:25,26:26,27:27,28:28,29:29,30:30,31:31,32:32,33:33,34:34,35:35,36:36,37:37,38:38,39:39,40:40,41:41,42:42,43:43,44:44,45:45,46:46,47:47,48:48,49:49,50:50,51:51,52:52,53:53,54:54,55:55,56:56,57:57,58:58,59:59,60:60"));//shenql
const SlotInfo	SlotInfo::all = SlotInfo(0);//shenql
const StringTypeInfo RecipeNameInfo::typeInfo(100);//shenql  //change 39 to 100 by wzd [1.1.39]
const StringTypeInfo LotIdInfo::typeInfo(10000);//shenql //change 100 to 10000 by liusy [1.1.35]
const IntTypeInfo IOPositionInfo::typeInfo(DescriptorList("UnInit:-1,Close, Open, Unknown, Error"));//lijj
const IntTypeInfo MaterialIdInfo::typeInfo = IntTypeInfo(-1000, 32000);
const DoubleTypeInfo RecipeTimeInfo::typeInfo = DoubleTypeInfo(-1.0, 360000.0, "sec", 0.1);
const IntTypeInfo InterruptRcpStepInfo::typeInfo = IntTypeInfo(DescriptorList("Continue,Cancel,Pause"));
const StringTypeInfo SlotIdInfo::typeInfo = StringTypeInfo(50);
const IntTypeInfo StepNumInfo::typeInfo = IntTypeInfo(-1, 200);    //change from 50 to 200 for XMC by xiezr v1.2.1_Hotfix, change from 0 to -1 for BD by wangyk v1.2.7_HotFix2
const IntTypeInfo RecipeControlInfo::typeInfo(DescriptorList("None:0,Run:1,Hold:2,Resume:3,EndCurrentStep:4,RestartCurrentStep:5,EndRecipe:6,Abort:7"));
