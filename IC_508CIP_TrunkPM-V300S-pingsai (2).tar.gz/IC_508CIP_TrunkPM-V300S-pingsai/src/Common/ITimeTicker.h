/*
 * ITimeTicker.h
 *
 *  Created on: 20210716
 *      Author: lvjiawen
 */

#ifndef ITIMETICKER_H_
#define ITIMETICKER_H_

class TimerEx;

class ITimeTicker
{
public:
	virtual void updateFromTimer(TimerEx * pSender) = 0;
};

#endif
