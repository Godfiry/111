/*
 * DevicePara.h
 *
 *  Created on: 2024年12月30日
 *      Author: wenxiang
 */

#ifndef DEVICEPARA_H_
#define DEVICEPARA_H_

#include <string>

enum DeviceType
{
	SERIALPORT,

	ETHERCAT_TO_SERIAL
};

//
typedef struct SerialPara
{
	unsigned short index;
	unsigned char subIndex;
	unsigned int length;
	unsigned char data;
};

//serial port settings got from config file.
typedef struct SerialPortSettings
{
	std::string DataFrame;
	unsigned short Index;
	unsigned short SlaveAddress;
	unsigned int BodeRate;
	unsigned int DataBit;
	unsigned int StopBit;
	unsigned int ParityMode;
};

// serial port settings needed to be set
typedef struct SerialPortMap
{
	unsigned char BodeRate;
	unsigned char DataBit;
	unsigned char StopBit;
	unsigned char ParityMode;
	unsigned char DataFrame;
};

#endif
