/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: RMHTempCtl.h
** Description: This driver is used by WATLOW EZ-ZONE RM TempCtl
*                   RS485
*                  BaudRate:38400
*                DataBit:8
*                StopBit:1
*                Parity:Even
** Release: 1.1
** Modification history: 
**                  2013-12-31   bihuijie create
**      
*********************************************************************/
#ifndef RMHTEMPCTL_H_
#define RMHTEMPCTL_H_

#include "DeviceNode.h"
#include "SerialDevice.h"
#include "MonitorDoubleValue.h" //added by liuxj v1.5.0 20250622 for TempCtl Protect CIP
#ifdef IAP4_0
using namespace IAP::IO;
#endif

#define MONITORDOUBLEVALUEADDMAP 200//added by liuxj v1.5.0 20250622 for TempCtl Protect CIP



class RMHTempCtl : public SerialDevice,public CMonitorDoubleValue //added by liuxj v1.5.0 20250622 for TempCtl Protect CIP
{
    DECLARE_DYNAMIC(RMHTempCtl) 
    DECLARE_MSG_MAP
    
private:
    static const int MAX_MESSAGE_LEN = 20;
    static const int MIN_RECEIVEMSG_LEN = 20;
    static const unsigned char regReadAddress[26]; // Register of read address  //changed by wzd 1.1.20
    static const unsigned char regWriteAddress[16];// Register of Write address
    static const unsigned char regReadErrorAddress[16];//added by liusy for reading error[20190809]
    static const unsigned char regReadAlarmAddress[16]; // Register of read Alarm address
    static const unsigned char regWriteOffsetAddress[16];// Register of write calibration offset address
    static const unsigned char regReadOffsetAddress[16]; // Register of read calibration offset address
    unsigned char unm_writeCmd[13]; //write command array   
    char m_writeCmd[13];    //write command array   
    char m_readCmd[8];   //read command array
    
    static const int RESP_LEN = 80;//the buff length
    
    double m_heatPower1;    
    double m_heatPower2;
    double m_heatPower3;
    double m_heatPower4; //add by wzd 1.1.20
    double m_heatPower5; //add by wzd 1.1.20
protected:

    void initChs(DeviceNode<RMHTempCtl> *node);//inint channel
    void initDevice();
    
public:
    RMHTempCtl();
    virtual ~RMHTempCtl();
    void init();  //init the device 

    bool writeDouble(int channnelNum,double setpt ,const DoubleTypeInfo& typeinfo);
    bool readDouble(int channnelNum,double * value ,const DoubleTypeInfo& typeinfo);
    
    void setHeatPower(int num,double power);
    //added by liusy for reading error[20190809]
    bool readString(int channnelNum,std::string * pValue ,const StringTypeInfo& typeinfo);
    bool readAlarm(int nChannnelNum,int * pValue ,const IntTypeInfo& typeinfo);//add for code merging
};

#endif /*RMHTEMPCTL_H_*/
