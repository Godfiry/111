/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: ATSChiller.cpp
** Description:
** Release: 1.1
** Modification history:
** 					2021-12-03   wzd create
*********************************************************************/
#include "GmpowerDM4MatchDriver.h"
#include "CheckCalculationTool.h"
#include "DeviceManager.h"
#include "ObjectManager.h"
#include "Converter.h"

#include "ConfigException.h"
#include "Hex.h"
#include <sstream>
#include <stdio.h>
#include "Converter.h"
#include <sys/time.h>
#include <iostream>
#include <string.h>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;


GmpowerDM4MatchDriver::GmpowerDM4MatchDriver():SerialDevice(80, "")
{

	m_timeOut=20;
	m_resLen=23;
	//the form of the read command 03
	m_readCmd[0] = 0x01;//controller address
	m_readCmd[1] = 0x03;//function read
	m_readCmd[2] = 0x00;//read starting at register high byte
	m_readCmd[3] = 0x00;//read starting at register low byte
	m_readCmd[4] = 0x00;//read number of consecutive register high (always 0)
	m_readCmd[5] = 0x01;//read number of consecutive register low
	m_readCmd[6] = 0x00;//Low byte of CRC
	m_readCmd[7] = 0x00;//High byte of CRC

	//the form of the write command 06
	m_writeCmd[0] = 0x01;//controller address
	m_writeCmd[1] = 0x06;//function multiple write
	m_writeCmd[2] = 0x00;//write starting at register High byte
	m_writeCmd[3] = 0x00;//write starting at register Low byte
	m_writeCmd[4] = 0x00;//data High byte of register write
	m_writeCmd[5] = 0x00;//data Low byte of register write
	m_writeCmd[6] = 0x00;//Low byte of CRC
	m_writeCmd[7] = 0x00;//High byte of CRC


}

GmpowerDM4MatchDriver::~GmpowerDM4MatchDriver()
{
}

bool GmpowerDM4MatchDriver::readInt(int nChannelNum, int * pValue ,const IntTypeInfo& typeinfo)
{

    if( nChannelNum == 1 )
	{
		m_readCmd[3] = 0x00;
	}
	if( nChannelNum == 2 )
	{
		m_readCmd[3] = 0x01;
	}

	unsigned short crc = CheckCalculationTool::GetCRC16Code( m_readCmd, 6 );
	m_readCmd[6] = (crc & 0xFF) & 0xFF;    // low byte of CRC
	m_readCmd[7] = (crc >> 8) & 0xFF;  //  high byte of CRC

	char response[m_resLen];
	memset(response, 0, m_resLen);
	sendCommandOnly(m_readCmd, 8);
	if(getResultOnly(response,m_resLen, m_timeOut) < 0)
	{
		throw IOException("GmpowerDM4MatchDriver reading back times out");
	}
	//cout<<hex<<int(response[3])<<hex<<int(response[4])<<endl;

	if(response[0] == m_readCmd[0] && response[1] == 0x03)
	{
		if(response[2] == 0x02)
		{
			unsigned char  cByte[4];//save the 32-bite
			int val;
			response[3] = response[3]&0x00ff;
			response[4] = response[4]&0x00ff;
			cByte[0] = response[3];
			cByte[1] = response[4];
			int t_val = (cByte[0] << 8) | cByte[1];
			*pValue = t_val / 10;
			return true;
		}
		else
		{
			throw IOException("GmpowerDM4MatchDriver reading data false, response is [" + Hex::GetHexString(response,10)+"]");
		}
	}
	else
	{
		throw IOException("GmpowerDM4MatchDriver:the read data command is invalid, response is [" + Hex::GetHexString(response,10)+"]");
	}
}


//write Temperature
bool GmpowerDM4MatchDriver::writeInt(int nChannelNum, int nSetTemp, const IntTypeInfo& typeinfo)
{

	if( nChannelNum == 3 )
	{
		m_writeCmd[3] = 0x07;
	}
	if( nChannelNum == 4 )
	{
		m_writeCmd[3] = 0x08;
	}
	unsigned char floatToHex[4];
	int nChangeSetTemp;
	nChangeSetTemp=nSetTemp*10;
	char* pChar=(char*) & nChangeSetTemp;
    for(int i=0;i<sizeof(int);i++)
    {
		floatToHex[i]=*pChar;
		pChar++;
    }

	m_writeCmd[4] = floatToHex[1];
	m_writeCmd[5] = floatToHex[0];

	unsigned short crc = CheckCalculationTool::GetCRC16Code( m_writeCmd, 6 );
	m_writeCmd[6] = 0xff&(crc & 0xff);  // low byte of CRC
	m_writeCmd[7] = 0xff&( crc >> 8);    // high byte of CRC


	//if the write command failed, return error
	char response[m_resLen];
	memset(response, 0, m_resLen);
	sendCommandOnly(m_writeCmd, 8);
        cout<<hex<<int(m_writeCmd[0])<<" "<<hex<<int(m_writeCmd[1])<<" "<<hex<<int(m_writeCmd[2])<<" "<<hex<<int(m_writeCmd[3])<<" "<<hex<<int(m_writeCmd[4])<<" "<<hex<<int(m_writeCmd[5])<<" "<<hex<<int(m_writeCmd[6])<<" "<<hex<<int(m_writeCmd[7])<<endl;
	if(getResultOnly(response,m_resLen, m_timeOut) < 0)
	{
		throw IOException("GmpowerDM4MatchDriver reading back times out");
	}
cout<<hex<<int(response[0])<<" "<<hex<<int(response[1])<<" "<<hex<<int(response[2])<<" "<<hex<<int(response[3])<<" "<<hex<<int(response[4])<<" "<<hex<<int(response[5])<<" "<<hex<<int(response[6])<<" "<<hex<<int(response[7])<<endl;
	//check the key bytes
	if(response[0] == m_writeCmd[0] && response[1] == 0x06)
	{
		return true;
	}
	else
	{
		throw IOException("Chiller write command failed for unknown response [" + Hex::GetHexString(response,10)+"]");
	}

}

//register channel
void GmpowerDM4MatchDriver::initChs(DeviceNode<GmpowerDM4MatchDriver> *node)
{
	node->registerReadCh(1, &GmpowerDM4MatchDriver::readInt);
	node->registerReadCh(2, &GmpowerDM4MatchDriver::readInt);
	node->registerWriteCh(3, &GmpowerDM4MatchDriver::writeInt);
	node->registerWriteCh(4, &GmpowerDM4MatchDriver::writeInt);
	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &GmpowerDM4MatchDriver::getStatus);
}
void GmpowerDM4MatchDriver::initDevice()
{
	cout<<"Start Scan GmpowerDM4MatchDriver...."<<endl;

	int nTemp;
	try
	{
		readInt(1,&nTemp,IntTypeInfo());
	}
	catch(exception &ex)
	{
		cout<<"Scan GmpowerDM4MatchDriver failed. Communication abnormal!"<<endl;
		return;
	}
	cout<<"Scan GmpowerDM4MatchDriver Successfully...."<<endl;
}
//init device
void GmpowerDM4MatchDriver::init()
{
	DeviceNode<GmpowerDM4MatchDriver> *node = new DeviceNode<GmpowerDM4MatchDriver>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	if(!isSimulated())
	{
		initChs(node);
		initDevice();
	}
}

IMPLEMENT_DYNAMIC(GmpowerDM4MatchDriver, SerialDevice)

BEGIN_MSG_MAP(GmpowerDM4MatchDriver, SerialDevice)
	SET_V( init, GmpowerDM4MatchDriver)
END_MSG_MAP
