/********************************************************************
** Copyright (c) 2017, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: PpcmaMks.cpp
** Description: PpcmaMks is the class of  PPCMA   instead of 649 gauge
** Release: 1.1
** Modification history: 
** 					2019-01-19   maxm create
**      
*********************************************************************/
#include "PpcmaMks.h"

#include "DeviceManager.h"
#include "ConfigException.h"

#include <cmath>
#include <sys/time.h>
#include <iostream>
#include <string.h>
#ifdef IAP4_0
using namespace IAP::IO;
#endif
using namespace std;

PpcmaMks::PpcmaMks()
{
	m_nStatus = -1;
	m_maxBinaryValue = 24576;
	m_maxFlowBinaryValue = 24576;
}

PpcmaMks::~PpcmaMks()
{
}

bool PpcmaMks::writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
	int outputBytes = m_deviceNet->getOBytesSize(m_macID);
	char buffer[outputBytes];
	memset(buffer, 0, outputBytes);	
	unsigned long  temp =(unsigned long)((value / typeInfo.getMax()) * m_maxBinaryValue);
	buffer[0] = temp & 0xff;
	buffer[1] = (temp >> 8) & 0xff;
	buffer[2] = 0x01;
	buffer[3] = 0x00;
//	m_pBufferSave[0]=buffer[0];
//	m_pBufferSave[1]=buffer[1];
	return m_deviceNet->writeByte(m_macID, buffer);
}

bool PpcmaMks::readDouble(int channelNum, double *pValue,const DoubleTypeInfo &typeInfo )
{
	int inputBytes = m_deviceNet->getIBytesSize(m_macID);
	char buffer[inputBytes];
	memset(buffer, 0, inputBytes);
	m_deviceNet->readByte(m_macID, buffer);

	unsigned long nTempValue = 0;
	
	if(channelNum == 2)
	{
		nTempValue = 0;
		if(!(buffer[2] & 0x80))
		{
			nTempValue = (buffer[1] &0xff) + ((buffer[2] << 8) & 0xff00);	
		}
		if(nTempValue >= 32767)
		{
			*pValue = typeInfo.getMax();
		}
		else
		{
			double dValue = (((double)nTempValue)/m_maxBinaryValue) * typeInfo.getMax();
			*pValue = MathTool::Round(dValue,typeInfo.getAccuracy());
		}
	}
	if(channelNum == 3)
	{
		nTempValue = 0;
		if(!(buffer[4] & 0x80))
		{
			nTempValue = (buffer[3] &0xff) + ((buffer[4] << 8) & 0xff00);
		}
		if(nTempValue >= 32767)
		{
			*pValue = typeInfo.getMax();
		}
		else
		{
			if(m_maxFlowBinaryValue != 24576)
			{
				double dValue = (((double)nTempValue)/m_maxFlowBinaryValue) * typeInfo.getMax();
				*pValue = MathTool::Round(dValue,typeInfo.getAccuracy());
			}
			else
			{
				double dValue = (((double)nTempValue)/m_maxBinaryValue) * typeInfo.getMax();
				*pValue = MathTool::Round(dValue,typeInfo.getAccuracy());
			}
		}	
		
	}
	m_nStatus = buffer[0] & 0xFF;
	return true;	
}

bool PpcmaMks::setMaxBinaryValue(int value)
{
	m_maxBinaryValue = value;
	return true;
}

bool PpcmaMks::setMaxFlowBinaryValue(int value)
{
	m_maxFlowBinaryValue = value;
	return true;
}
void PpcmaMks::init()
{
	if(!isSimulated())
	{
		initDeviceNet();
	}
	DeviceNode<PpcmaMks> * node = new DeviceNode<PpcmaMks>(m_pollInterval,this);
		
	node->registerWriteCh(1, &PpcmaMks::writeDouble);//
	node->registerReadCh(2, &PpcmaMks::readDouble);//
	node->registerReadCh(3, &PpcmaMks::readDouble);//
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
}

IMPLEMENT_DYNAMIC(PpcmaMks, IODevice )
BEGIN_MSG_MAP( PpcmaMks, IODevice )
	SET_I(setMaxBinaryValue, PpcmaMks)
	SET_I(setMaxFlowBinaryValue, PpcmaMks)
END_MSG_MAP


