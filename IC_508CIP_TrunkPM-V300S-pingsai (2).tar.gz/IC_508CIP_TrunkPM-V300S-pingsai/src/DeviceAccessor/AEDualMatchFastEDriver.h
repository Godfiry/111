/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AEDualMatchFastEDriver.h
** Description:  
** Release: 1.1
** Modification history: 
** 					20220501 songpan create
**      
*********************************************************************/
#ifndef AEDUALMATCHFASTEDRIVER_H_
#define AEDUALMATCHFASTEDRIVER_H_
#include "SerialDevice.h"
#include "DeviceNode.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class AEDualMatchFastEDriver : public SerialDevice
{
    DECLARE_DYNAMIC(AEDualMatchFastEDriver)	
    DECLARE_MSG_MAP

private:
    typedef struct
	 {
		int m_type;
		unsigned char m_cmd;
		int m_relen;
	 }Com;
	static Com m_commands[];	 
    static const int RESP_LEN = 100;
    static const int MESS_LEN = 20;
    static const int RESP_ALL_LEN = 100;
    int m_preC1;
    int m_preC2;

    char message[MESS_LEN];
    char resp[RESP_LEN];
    char respall[RESP_ALL_LEN];
    char ack[1];
    int addr;
    bool sendCommand(char *msg,char *response, int l_msg_timeout,int length);
    bool sendCommandAck(char *msg, char *response, int msg_timeout,int resplen, int msglen);
    bool readCommand(char *msg, char *response, int msg_timeout,int resplen, int msglen);
		 
public:
    AEDualMatchFastEDriver();
    virtual ~AEDualMatchFastEDriver();
    void init();
    void InitChannels(DeviceNode<AEDualMatchFastEDriver> *node);   
    bool writeInt(int channel,int value,const IntTypeInfo& typeinfo);
    bool readInt(int channel,int *value,const IntTypeInfo& typeinfo);	
    bool readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo);
    bool readDoubleFake(int channelNum, double *value, const DoubleTypeInfo &typeInfo);
    bool readIntFake(int channelNum, int *value, const IntTypeInfo &typeInfo);
    bool readAll(int channelNum, int *value, const IntTypeInfo &typeInfo);
	double realToDouble(long value);
    void setAddress(int ad);
	void selectNetWork(int value);
};
#endif /*AEDUALMATCHFASTEDRIVER_H_*/
