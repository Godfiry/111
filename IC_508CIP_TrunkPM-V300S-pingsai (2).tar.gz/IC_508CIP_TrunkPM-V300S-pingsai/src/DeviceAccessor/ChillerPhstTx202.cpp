/********************************************************************
** Copyright (c) 2018, Beijing NAURA Co.,Ltd.  All rights reserved.
** File name: ChillerPhstTx202.cpp
** Description:  

** Release: 1.1
** Modification history: 
*  					2020-5-12   chenmz create
**			
*********************************************************************/
#include "ChillerPhstTx202.h"
#include "DeviceManager.h"

#include "Converter.h"
#include "Hex.h"
#include "StrTool.h"
#include "CheckCalculationTool.h"
#include "SysLogger.h"
#include "ObjectManager.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "InvalidNameException.h"
#endif
#include <cctype>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

ChillerPhstTx202::Cmd ChillerPhstTx202::m_cmd[] = {{""},//reserved
											{":0117010000000109000204",0},//1 stop/start
											{":011701000000010A0002048000",0},//2 set temprature
											{":0117010100020000000000",11},//3 read temprature
											{""},  //4 read pump pressure 
											{":0117010500020000000000",27},//5read water flow
											{":0117010000020000000000",0x8000},//6 read fault summary
											{":0117010000020000000000",0x4000},//7 read warn summary
											{":0117010200020000000000",0x400},//8  read local remote
											{":0117010200020000000000",0xC000},//9 read alarm
											{""},//10 read on/off
											{":0217010000000109000204",0},//11 stop/start
											{":021701000000010A0002048000",0},//12 set temprature
											{":0217010100020000000000",11},//13 read temprature
											{""},  //14 read pump pressure
											{":0217010500020000000000",27},//15read water flow
											{":0217010000020000000000",0x8000},//16 read fault summary
											{":0217010000020000000000",0x4000},//17 read warn summary
											{":0217010200020000000000",0x400},//18  read local remote
											{":0217010200020000000000",0xC000},//19 read alarm
											{""}//20 read on/off
											};
																							
ChillerPhstTx202::ChillerPhstTx202():SerialDevice(200, "\x0D\x0A")
{
	m_timeOut = 50;//5s
	m_pollPeriod = 1000; //1s	
	m_nChillerTemp1SetValue = 0;
	m_nChillerTemp2SetValue = 0;
}	

ChillerPhstTx202::~ChillerPhstTx202()
{
}										
											
bool ChillerPhstTx202::writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
	string strCommand =  m_cmd[nChannelNum].m_strAddress;
	double dTemp = (double)((dValue + 60) * 65535 / 220);
	double dTemp1 = (int) dTemp;
	if(nChannelNum == 2)
	{
		m_nChillerTemp1SetValue = dTemp1;
		strCommand +=  Hex::hexToString(m_nChillerTemp1SetValue,4);
	}
	else if(nChannelNum == 12)
	{
		m_nChillerTemp2SetValue = dTemp1;
		strCommand +=  Hex::hexToString(m_nChillerTemp2SetValue,4);
	}
	strCommand += CheckCalculationTool::GetLRCCode(strCommand);
	strCommand = StrTool::toUpper(strCommand);
	string strResponse = getCommandResult(strCommand, m_timeOut);
	int nPos = strResponse.find(":", 0);
	if(nPos == string::npos)
	{
		if(strCommand.find(":02") != string::npos)
		{
			throw IOException("Chiller channel2 write temperature ["+Converter::convertToString(dValue)+"] failed for unknown response [" + strResponse+"]");
		}
		else
		{
			throw IOException("Chiller write temperature ["+Converter::convertToString(dValue)+"] failed for unknown response [" + strResponse+"]");
		}
	}
	return true;
}

bool ChillerPhstTx202::readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo)
{
	string strCommand =  m_cmd[nChannelNum].m_strAddress;
	if(nChannelNum == 4 || nChannelNum == 14)
	{
		*pValue = 0;
		return true;
	}	
	strCommand += CheckCalculationTool::GetLRCCode(strCommand);
	strCommand = StrTool::toUpper(strCommand);
	string strResponse = getFixCommandResult(strCommand, m_timeOut,35,5);
	size_t nPos = strResponse.find(":", 0);  //changed by wzd 1.1.39
	if(nPos == string::npos)
	{
		if(strCommand.find(":02") != string::npos)
		{
			throw IOException("Chiller channel2 read temperature failed for unknown response [" + strResponse+"]");
		}
		else
		{
			throw IOException("Chiller read temperature failed for unknown response [" + strResponse+"]");
		}
	}
	else
	{
		 nPos +=  m_cmd[nChannelNum].m_nPos;
		string strValue = strResponse.substr(nPos, 4);
		int nValue = 0;
		if(!Hex::stringToHex(&nValue, strValue))
		{
			throw IOException("Chiller channel ["+Converter::convertToString(nChannelNum)+"] read value failed for can't convert response ["+strValue+"] to double value.");
		}
		switch(nChannelNum)
		{
			case 3:
			case 13:
				*pValue = nValue * 220.0/65535.0-60;//value range is from -60 to 160,see the manual
				break;
			case 5:
			case 15:
				*pValue = nValue *  10/65535.0*3.785;//value range is from 0 to 20,see the manual
				break;
			
			default:
				break;
		}
		return true;
	}
}
		
bool ChillerPhstTx202::readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
	string strCommand = m_cmd[nChannelNum].m_strAddress;
	if(nChannelNum == 10 || nChannelNum == 20)
	{
		*pValue = 1;
		return true;
	}	
	strCommand += CheckCalculationTool::GetLRCCode(strCommand);
	strCommand = StrTool::toUpper(strCommand);
	string strResponse = getFixCommandResult(strCommand, m_timeOut,35,5);
	size_t nPos = strResponse.find(":", 0);  //changed by wzd 1.1.39
	if(nPos == string::npos)
	{
		if(strCommand.find(":02") != string::npos)
		{
			throw IOException("Chiller channel2 read status failed for unknown response [" + strResponse+"]");
		}
		else
		{
			throw IOException("Chiller read status failed for unknown response [" + strResponse+"]");
		}
	}
	else
	{
		nPos += 7;
		if(nChannelNum == 8 ||nChannelNum == 9 || nChannelNum == 18 ||nChannelNum == 19)
		{
			nPos += 8;
		}
		string strValue = strResponse.substr(nPos, 4);
		int nTempValue = 0;
		if(!Hex::stringToHex(&nTempValue, strValue))
		{
			throw IOException("Chiller read status failed for can't convert response ["+strValue+"] to integer value.");
		}
		else
		{
			*pValue = (nTempValue & m_cmd[nChannelNum].m_nPos) != 0;
			if((nChannelNum == 9 || nChannelNum == 19) && *pValue==1)
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "ChillerPhstTx202: channel ["+Converter::convertToString(nChannelNum)+"] read back = "+strResponse +" ;split value = "+strValue);
				string strError = "ChillerPhstTx202 has alarm.Error is as follows: ";
				if(nTempValue & 0x8000)
				{
					strError += "fluid level fault, ";
				}
				if(nTempValue & 0x4000)
				{
					strError += "fluid flow fault, ";
				}
				if(nTempValue & 0x2000)
				{
					strError += "fluid resistivity fault, ";
				}
				if(nTempValue & 0x0800)
				{
					strError += "high temperature fault, ";
				}
				if(nTempValue & 0x0200)
				{
					strError += "low temperature fault, ";
				}
				if(nTempValue & 0x0100)
				{
					strError += "add fluid fault, ";
				}
				if(nTempValue & 0x0080)
				{
					strError += "over temperature fault, ";
				}
				strError += "please check!";
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,strError);
			}
			return true;
		}
	}
	
}
		
bool ChillerPhstTx202::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
	string strCommand = m_cmd[nChannelNum].m_strAddress;
	string strAction;
	if(nValue == 1)
	{
		strCommand += "8000";
		strAction = "start";
	}
	else
	{
		strCommand += "0000";
		strAction = "stop";
	}
	if(nChannelNum == 1)
	{
		strCommand +=  Hex::hexToString(m_nChillerTemp1SetValue,4);
	}
	else if(nChannelNum == 11)
	{
		strCommand +=  Hex::hexToString(m_nChillerTemp2SetValue,4);
	}
	strCommand += CheckCalculationTool::GetLRCCode(strCommand);
	strCommand = StrTool::toUpper(strCommand);
	string strResponse = getCommandResult(strCommand, m_timeOut);
	size_t nPos = strResponse.find(":", 0);  //changed by wzd 1.1.39
	if(nPos == string::npos)
	{
		if(strCommand.find(":02") != string::npos)
		{
			throw IOException("Chiller channel2 "+strAction+" failed for unknown response [" + strResponse+"]");
		}
		else
		{
			throw IOException("Chiller "+strAction+" failed for unknown response [" + strResponse+"]");
		}
	}
	return true;
}

void ChillerPhstTx202::initChs(DeviceNode<ChillerPhstTx202> *pNode)
{
	pNode->registerWriteCh(1, &ChillerPhstTx202::writeInt);
	pNode->registerWriteCh(2, &ChillerPhstTx202::writeDouble);
	for(int i = 3; i<=5; ++i)
	{
		pNode->registerReadCh(i, &ChillerPhstTx202::readDouble);
	}
	for(int i = 6; i<=10; ++i)
	{
		pNode->registerReadCh(i, &ChillerPhstTx202::readInt);
	}

	pNode->registerWriteCh(11, &ChillerPhstTx202::writeInt);
	pNode->registerWriteCh(12, &ChillerPhstTx202::writeDouble);
	for(int i = 13; i<=15; ++i)
	{
		pNode->registerReadCh(i, &ChillerPhstTx202::readDouble);
	}
	for(int i = 16; i<=20; ++i)
	{
		pNode->registerReadCh(i, &ChillerPhstTx202::readInt);
	}
	pNode->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &ChillerPhstTx202::getStatus);
}

void ChillerPhstTx202::initDevice()
{
	cout<<"Start Scan Chiller...."<<endl;
	//say hello to chiller
	double dTemp;
	try
	{
		readDouble(3,&dTemp,DoubleTypeInfo());//3 read temprature
	}
	catch(exception &ex)
	{
		cout<<"Scan chiller failed. Communication abnormal!"<<endl;	
		throw;
	}
	cout<<"Scan Chiller Successfully...."<<endl;
}

void ChillerPhstTx202::init()
{
	DeviceNode<ChillerPhstTx202> *pNode = new DeviceNode<ChillerPhstTx202>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
	if(!isSimulated())
	{
		initChs(pNode);	
		initDevice();
	}	
}

IMPLEMENT_DYNAMIC(ChillerPhstTx202, SerialDevice )

BEGIN_MSG_MAP(ChillerPhstTx202, SerialDevice )
	SET_V( init, ChillerPhstTx202 )
END_MSG_MAP										
											
