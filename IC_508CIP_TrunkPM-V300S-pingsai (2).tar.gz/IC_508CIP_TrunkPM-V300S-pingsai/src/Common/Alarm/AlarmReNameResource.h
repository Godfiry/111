#ifndef STRINGRESOURCE_H_
#define STRINGRESOURCE_H_
#include "CmdTarget.h"
#ifdef IAP4_0
using namespace IAP::CORE;
#endif
using namespace std;

class AlarmReNameResource:public CmdTarget
{
	DECLARE_DYNAMIC( AlarmReNameResource ) 
	DECLARE_MSG_MAP
public:
	AlarmReNameResource();
	virtual ~AlarmReNameResource();
	
public:
	bool AddAlarmName(const string& strOriginalName , const string& strShowName);
};

#endif /*STRINGRESOURCE_H_*/
