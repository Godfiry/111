/************************************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: DefaultIOMonitorLogThread.h
** Description: This file includes declaration of class DefaultIOMonitorLogThread.          
** Release: 1.0
** Modification history: 
*************************************************************************************/




#ifndef DEFAULTIOMONITORTHREAD_H_
#define DEFAULTIOMONITORTHREAD_H_

#include "IOMonitorLogThread.h"
class DefaultIOMonitorLogThread : public IOMonitorLogThread
{
	DECLARE_DYNAMIC( DefaultIOMonitorLogThread )
	
	public:
		DefaultIOMonitorLogThread();
		virtual ~DefaultIOMonitorLogThread();
	protected:
		virtual void dealWithTheData(MonitorData &pData);
};
#endif /*DEFAULTIOMONITORTHREAD_H_*/
