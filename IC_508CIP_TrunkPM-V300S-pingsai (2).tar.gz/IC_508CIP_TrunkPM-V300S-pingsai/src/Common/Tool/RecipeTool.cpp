/********************************************************************
** Copyright (c) 2019, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: RecipeTool.h
** Description:
** Created on: Jan 9, 2019
** Author: mujy
** Modification history:
**                      [V1.0.0.2] create
**
*********************************************************************/

#include "RecipeTool.h"
#include "SysLogger.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "AbortException.h"
#endif
#include "Setup.h"
#include "IntTypeInfo.h"
#include "DoubleTypeInfo.h"
#include "StringTypeInfo.h"
#include "IntValueInfo.h"
#include "Converter.h"
#include "ExecRcpHandler.h"
#include "RecipeMgmtSession.h"
#include "StrTool.h"
#include "AppRcpStep.h"
#include <dirent.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <iostream>
#include <iomanip>
#include "ConfigException.h"
#include <algorithm>
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
using namespace IAP::SETUP;
using namespace IAP::IO;
using namespace IAP::RECIPE;
#endif
bool RecipeTool::m_bIsRcpHasESCHeaterParam = false; //added by zhangpf[1.8.2]
RecipeTool::RecipeTool() {
    // TODO Auto-generated constructor stub
    m_pSession = NULL;
}

RecipeTool::~RecipeTool() {
    // TODO Auto-generated destructor stub

}

void RecipeTool::verifyInit()
{
    cout<<"start verify recipe ..."<<endl;
    ExecRcpHandler currentRcp;
    RecipeMgmtSession *pSession = RecipeNamespaceManager::buildSession(this, getName());
    AppRcpBody *pRcpBody = new AppRcpBody();
    //ofstream in;//zhangyy delete for sonar[1.5.0]

    vector<string> rcpClassVector = RecipeNamespaceManager::getInstance()->getAllRcpClasses();
    SysLogger::getInstance()->logMsg(LOGBRANCH::ALARM, LEVEL::EVENT, "getAllRecipe");
    try
    {
        for(int i = 0 ; i < rcpClassVector.size(); ++i)
        {
            vector<string> recipeNames = RecipeNamespaceManager::getInstance()->getRcpIDsUnder(rcpClassVector[i]);

            for(int j=0;j<recipeNames.size();++j)
            {
                pSession->releaseRecipe(currentRcp); // m_handler is reset to NULL, no exception in here context
                currentRcp = pSession->retrieveRecipe(recipeNames[j], false);
            }
        }
    }
    catch(exception &ex)
    {
        delete pRcpBody;
        pRcpBody = NULL;
        pSession->clear();
        RecipeNamespaceManager::closeSession(&pSession);
        throw ConfigException(ex.what());
    }
    delete pRcpBody;
    pRcpBody = NULL;
    pSession->clear();
    RecipeNamespaceManager::closeSession(&pSession);

    cout<<"verify recipe successfully"<<endl;
}


void RecipeTool::startup()
{
    m_pSession = RecipeNamespaceManager::buildSession(this, getName());
    if(m_pSession == NULL)
    {
        throw AbortException("Recipe Tool build Session failed!");
    }
}
void RecipeTool::initialize() //add by zhangpf[1.8.2]
{
    ControlObject::initialize();
    bool bHasInnerESCTemp = RecipeTool::hasParamInRecipeTemplate("InnerESCTemp(degC)");
    bool bHasMidInnerESCTemp = RecipeTool::hasParamInRecipeTemplate("MidInnerESCTemp(degC)");
    bool bHasMidOuterESCTemp = RecipeTool::hasParamInRecipeTemplate("MidOuterESCTemp(degC)");
    bool bHasOuterESCTemp = RecipeTool::hasParamInRecipeTemplate("OuterESCTemp(degC)");
    m_bIsRcpHasESCHeaterParam = bHasInnerESCTemp && bHasMidInnerESCTemp && bHasMidOuterESCTemp && bHasOuterESCTemp;
}

void RecipeTool::shutdown()
{
    if (m_pSession != NULL)
    {
        m_pSession->clear();
        RecipeNamespaceManager::closeSession(&m_pSession);
    }
}
void RecipeTool::PrintAll::execute()
{
    ControlObject *pOwner = getOwner();
    if (pOwner != NULL)
    {
        try
        {
            static_cast<RecipeTool*>(pOwner)->do_PrintAll();
        }
        catch(const AbortException &ex)
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, pOwner->getName() + ": Start service was aborted for:" + string(ex.what()));
            throw;
        }
        catch(const exception &ex)
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, pOwner->getName() + ": Start service has error for:" + string(ex.what()));
            throw;
        }
    }
}

void RecipeTool::call_PrintAll()
{
    call(m_PrintAll);
}

void RecipeTool::do_PrintAll()
{
    cout<<"-------------------------------------------------"<<endl;
    cout<<"Start to print recipe information..."<<endl;
    char current_absolute_path[300];
    if(NULL == getcwd(current_absolute_path,300))
    {
        cout<<"Cannot get current absolute path!"<<endl;
        return;
    }

    string strPath = string(current_absolute_path)+"/Information/AllRecipes/";

    //Delete file under AllRecipes //added by mujy [v1.0.0.3]
    struct dirent *pPtr;
    DIR *pDir = opendir(strPath.substr(0,strPath.size()-1).c_str());
    if(pDir != NULL)
    {
        string strFileName;
        while((pPtr = readdir(pDir)) != NULL)
        {
            cout<<"Delete file "<<pPtr->d_name<<endl;
            strFileName = strPath + string(pPtr->d_name);
            remove(strFileName.c_str());
        }
        closedir(pDir);
    }
    //Delete end

    cout<<"Print recipe to path ["<<strPath<<"]"<<endl;

    //Create directory start //added by mujy [v1.0.0.3]
    int nIndex = 0;
    string str1 = strPath;
    string str2;
    str1 = str1.substr(1,str1.size());
    while(nIndex>=0)
    {
        nIndex = str1.find("/");
        str2 +="/"+ str1.substr(0,nIndex);

        if(access(str2.c_str(), F_OK) != 0)
        {
            cout<<"Create directory "<<str2<<endl;
            if(mkdir(str2.c_str(),S_IRWXU|S_IRWXG|S_IRWXO) != 0)
            {
                cout<<"Cannot creat specified directory "<<str2<<endl;
                throw string("Cannot creat specified directory "+str2);
            }
        }
        str1 = str1.substr(nIndex+1,str1.size());
    }
    //End

    ExecRcpHandler currentRcp;

    AppRcpBody *pRcpBody = new AppRcpBody();
    ofstream in;

    vector<string> rcpClassVector = RecipeNamespaceManager::getInstance()->getAllRcpClasses();
    SysLogger::getInstance()->logMsg(LOGBRANCH::ALARM, LEVEL::EVENT, "getAllRecipe");
    try
    {
        for(int i = 0 ; i < rcpClassVector.size(); ++i)
        {
            vector<string> recipeNames = RecipeNamespaceManager::getInstance()->getRcpIDsUnder(rcpClassVector[i]);
            cout<<"Recipe class = "<<rcpClassVector[i]<<endl;
            for(int j=0;j<recipeNames.size();++j)
            {
                cout<<"Print recipe "<<recipeNames[j]<<endl;
                string strRecipeName = recipeNames[j]+".txt";
                StrTool::string_replace(strRecipeName,"/","_");
                StrTool::string_replace(strRecipeName,";","_");
                strRecipeName = strRecipeName.substr(1,strRecipeName.length());
                strRecipeName = strPath+strRecipeName;
                in.open(strRecipeName.c_str(), ios::trunc);
                m_pSession->releaseRecipe(currentRcp); // m_handler is reset to NULL, no exception in here context
                currentRcp = m_pSession->retrieveRecipe(recipeNames[j], false);
                pRcpBody->clear();
                pRcpBody->makeBody(currentRcp);

                in <<setiosflags(ios::left)<<setw(30)<<"ParamName";
                for(int nStep=1; nStep<=pRcpBody->getStepSize(); ++nStep)
                {
                        AppRcpStep rcpStep = pRcpBody->getStep(nStep);
                        in <<setiosflags(ios::left)<<setw(15)<<rcpStep.getStepName();
                }
                in<<endl;
                vector<const Parameter*> parameter = RecipeNamespaceManager::getInstance()->getRcpClassTemplate(rcpClassVector[i]);
                for (unsigned int nParamNum = 0; nParamNum < parameter.size(); ++nParamNum)
                {
                    if(parameter[nParamNum]->getName().find("_") != string::npos)
                    {
                        continue;
                    }
                    in <<setiosflags(ios::left)<<setw(30)<<parameter[nParamNum]->getName();

                    for(int nStep=1; nStep<=pRcpBody->getStepSize(); ++nStep)
                    {
                        AppRcpStep rcpStep = pRcpBody->getStep(nStep);
                        ParamValue paramValue = rcpStep.getParamValue(parameter[nParamNum]->getName());

                        switch(paramValue.Type)
                        {
                            case IO::INTDATA:
                                try // maybe no descriptor
                                {
                                    in <<setiosflags(ios::left)<<setw(15)<<paramValue.IntValue.getValueAsDescriptor();
                                }
                                catch (const exception&)
                                {
                                    in <<setiosflags(ios::left)<<setw(15)<<paramValue.IntValue.getValueAsString();
                                }
                                break;

                            case IO::STRINGDATA:
                                in <<setiosflags(ios::left)<<setw(15)<<paramValue.StringValue.getValueAsString();
                                break;

                            case IO::DOUBLEDATA:
                                in <<setiosflags(ios::left)<<setw(15)<<paramValue.DoubleValue.getValueAsString();
                                break;

                            default:
                                break;
                        }
                    }
                    in<<endl;
                }

                m_pSession->releaseRecipe(currentRcp); // m_handler is reset to NULL, no exception in here context
                in.close();
            }
        }
    }
    catch(exception &ex)
    {
        cout<<"exception is "<<ex.what();
    }
    delete pRcpBody;
    pRcpBody = NULL;

    in.close();
    cout<<"Print recipe information end."<<endl;
    cout<<"-------------------------------------------------"<<endl;
}

//This method is no longer used, must use AppRecipeManager::getInstance()->retrieveRecipe(strRecipeID,false)
ExecRcpHandler RecipeTool::getRecipeHandler(const string &strRecipe)
{
    //retrive recipe
    ExecRcpHandler CurrentRcpHandler;

    try
    {
        RecipeMgmtSession::CriticalZone cz;
        m_pSession->clear();
        CurrentRcpHandler = m_pSession->retrieveRecipe(strRecipe, false);
    }
    catch(const exception &err)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + strRecipe +": retrieve recipe failed for: " +string(err.what()));
        m_pSession->clear();
        throw AbortException("Failed to retrieve the recipe ["+strRecipe+"]");
    }

    if (!CurrentRcpHandler.verify()) // verify failed
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + strRecipe +": recipe verify failed.");
        m_pSession->releaseRecipe(CurrentRcpHandler);
        m_pSession->clear();
        throw AbortException("Failed to verify the recipe ["+CurrentRcpHandler.getName()+"]");
    }

    if(CurrentRcpHandler.getNumOfSteps() == 0)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + strRecipe +": recipe body is empty.");
        m_pSession->releaseRecipe(CurrentRcpHandler);
        m_pSession->clear();
        throw AbortException("Recipe ["+CurrentRcpHandler.getName()+"] is NULL, please add step.");
    }

    return CurrentRcpHandler;
}

bool RecipeTool::IsRecipeParamExist(const string &strRecipeClassName,const string &strParamName)
{
    bool bExist = false;
    vector<const Parameter*> parameter = RecipeNamespaceManager::getInstance()->getRcpClassTemplate(strRecipeClassName);
    for(int i = 0; i < parameter.size(); i++)
    {
        string strParameterName = parameter[i]->getName();

        if(strParameterName.find(strParamName) != string::npos)
        {
            bExist = true;
            return bExist;
        }
    }
    return bExist;
}

bool RecipeTool::hasParamInRecipeTemplate(const string &strParamName) // add by mjy for LVC [1.4.0_HotFix2]
{
    bool bExist = false;
    vector<string> rcpClassVector = RecipeNamespaceManager::getInstance()->getAllRcpClasses();
    string strRecipeClassName = "/Process";

    if (std::find(rcpClassVector.begin(), rcpClassVector.end(), "/ChildProcess") != rcpClassVector.end())
    {
        strRecipeClassName = "/ChildProcess";
    }

    vector<const Parameter*> parameter = RecipeNamespaceManager::getInstance()->getRcpClassTemplate(strRecipeClassName);
    for(size_t i = 0; i < parameter.size(); i++)
    {
        string strParameterName = parameter[i]->getName();

        if(strParameterName == strParamName)
        {
            bExist = true;
            return bExist;
        }
    }
    return bExist;
}

bool RecipeTool::isRcpHasESCHeaterParam() //added by zhangpf[1.8.2]
{
    return m_bIsRcpHasESCHeaterParam;
}

void RecipeTool::releaseRecipeHandler(ExecRcpHandler rcpHandler)
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + "about to do releaseRecipeHandler ");

	if (m_pSession != NULL)
	{
		m_pSession->releaseRecipe(rcpHandler);
	}

	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + "done releaseRecipeHandler ");

}

IMPLEMENT_DYNAMIC_SERVICE(PrintAll, RecipeTool)

BEGIN_SERVICEINFO_LIST(RecipeTool)
    ADD_SERVICE_INFO(RecipeTool, PrintAll, Print All setup value)
END_SERVICEINFO_LIST(RecipeTool)

IMPLEMENT_DYNAMIC(RecipeTool, ControlObject)

BEGIN_MSG_MAP( RecipeTool, ControlObject)

END_MSG_MAP
