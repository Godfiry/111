#ifndef NULLPOINTEREXCEPTION_H_
#define NULLPOINTEREXCEPTION_H_

#include "TMCException.h"

class NullPointerException : public TMCException
{
    public:
		NullPointerException(const std::string &err) : TMCException(err) {}
};
#endif /*NULLPOINTEREXCEPTION_H_*/
