#include "NonBlockingAlarmEX.h"
using namespace std;

NonBlockingAlarmEX::NonBlockingAlarmEX(const string &name, const string &message, const string &description, 
								Severity severity):NonBlockingAlarm(name, message, description, severity)
{
}

NonBlockingAlarmEX::~NonBlockingAlarmEX()
{
}

void NonBlockingAlarmEX::setMessage(const std::string &strMessage)
{
	Alarm::setMessage(strMessage);
}

void NonBlockingAlarmEX::setDescription(const std::string &strDescription)
{
	Alarm::setDescription(strDescription);
}

void NonBlockingAlarmEX::setMessage(int nStringID)
{
	setMessage(str(nStringID));
}

void NonBlockingAlarmEX::setDescription(int nStringID)
{
	setDescription(str(nStringID));
}


