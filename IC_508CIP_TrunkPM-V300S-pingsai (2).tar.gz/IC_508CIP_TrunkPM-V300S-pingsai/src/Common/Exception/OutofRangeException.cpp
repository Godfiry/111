#include "OutofRangeException.h"

OutofRangeException::OutofRangeException(const std::string &s):TMCException(s)
{
}


