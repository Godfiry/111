/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: NMCMatchDriver.h
** Description:  
** Release: 1.1
** Modification history: 
**                     2014-09-11   bihuijie create
**      
*********************************************************************/
#ifndef NMCMATCHDRIVER_H_
#define NMCMATCHDRIVER_H_

#include "MKSMatch.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#include "DescriptorList.h"
#include "StringTypeInfo.h"
#include <map>
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class NMCMatchDriver:public MKSMatch
{
    DECLARE_DYNAMIC(NMCMatchDriver)    
    DECLARE_MSG_MAP    

    private:
        typedef struct
        {
            int m_ps;
            std::string m_s1;
            int m_ps2;
        }Com;
        
        typedef std::pair<std::string,DescriptorList> ParamPair;
        
        static std::map<std::string,DescriptorList> m_params;
        static ParamPair m_paramPairs[];
        static Com m_commands[];       
    
    protected:
        void initChs(DeviceNode<NMCMatchDriver> *node);
        void initDevice();
        
    public:
        NMCMatchDriver();
        virtual ~NMCMatchDriver();
        
        bool writeInt(int channelNum, int value, const IntTypeInfo &typeInfo);
        bool writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo);
        bool writeRawCommand(int channelNum, std::string value, const StringTypeInfo &typeInfo);
        bool readInt(int channelNum, int *value, const IntTypeInfo &typeInfo);
        bool readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo);        
        
        void init();
};

#endif /*NMCMATCHDRIVER_H_*/
