/*
 * EtherCatCIFX.cpp
 *
 *  Created on: 2024��1��5��
 *      Author: liusiyuan
 */

#include "EtherCatCIFX.h"
#include "ConfigException.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#include "EtherCATMaster_AP_Public.h"
#include "SysLogger.h"
#include "EtherCATMaster_Public.h"
#include "EcmIF_Public.h"
#include "Hex.h"
#include "Converter.h"
#include <iostream>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#ifdef IAP4_0
using namespace IAP;
using namespace IAP::CORE;
#endif

#define CIFX_ECAT "cifX0"

EtherCatCIFX::EtherCatCIFX() {
	// TODO Auto-generated constructor stub
	m_ptApp = NULL;

	m_hDriver = NULL;
	m_hChannel = NULL;

	m_Init.init_options = CIFX_DRIVER_INIT_AUTOSCAN;
	m_Init.iCardNumber = 0;
	m_Init.fEnableCardLocking = 0;
	m_Init.base_dir = NULL;
	m_Init.poll_interval = 0;
	m_Init.poll_StackSize = 0;   /* set to 0 to use default */
	m_Init.trace_level = 255;
	m_Init.user_card_cnt = 0;
	m_Init.user_cards = NULL;
	m_Init.poll_priority = 0;
#ifdef SUSE
	m_Init.logfd = 0;  //add by wzd 1.1.39
#endif
}

EtherCatCIFX::~EtherCatCIFX() {
	// TODO Auto-generated destructor stub

	CloseAll(m_ptApp);
	cifXDriverDeinit();
	FreeResources(m_ptApp);
}


TLR_RESULT EtherCatCIFX::CreateResources(APPLICATION_T** pptApp)
{
	cout << "Allocating resources...\n" << endl;

	/* return value of function */
	TLR_RESULT tResult = TLR_S_OK;

	/* at the end of the function we will return the pointer */
	*pptApp = NULL;

	/* allocate memory for application data */
	APPLICATION_T* ptApp = (APPLICATION_T*)malloc(sizeof(APPLICATION_T));
	memset(ptApp, 0, sizeof(APPLICATION_T));

	/* return the pointer */
	*pptApp = ptApp;

	cout << "Successful.\n" << endl;
	return tResult;
}


TLR_RESULT EtherCatCIFX::FreeResources(APPLICATION_T* ptApp)
{
	cout << "Free resources...\n" << endl;

	/* return value of function */
	TLR_RESULT tResult = TLR_S_OK;

	/* free application data container */
	free(ptApp);

	return tResult;
}

TLR_RESULT EtherCatCIFX::CloseAll(APPLICATION_T* ptApp)
{
	TLR_RESULT tResult = TLR_S_OK;
	//TLR_UINT32 ulChannel = 0;


	tResult = xChannelHostState(m_hChannel, CIFX_HOST_STATE_READY, 0, 100);
	cout << "Close host Successful.\n" << endl;

	tResult = xChannelBusState(m_hChannel, CIFX_BUS_STATE_OFF, 0, 2000);
	cout << "Close bus Successful.\n" << endl;

	tResult = xChannelClose(m_hChannel);
	cout << "Close channel Successful.\n" << endl;

	tResult = xDriverClose(m_hDriver);
	cout << "Close driver Successful.\n" << endl;

	return tResult;
}

TLR_RESULT EtherCatCIFX::PromptIntro(APPLICATION_T* ptApp)
{
	/* return value of function */
	TLR_RESULT tResult = TLR_S_OK;

	cout << "\n" << endl;
	cout << "**********************************************************\n" << endl;
	cout << "*                                                        *\n" << endl;
	cout << "*   Starting program for EtherCatCIFX Master                 *\n" << endl;
	cout << "*                                                        *\n" << endl;
	cout << "*   Copyright (c) Naura etch1 All Rights Reserved.       *\n" << endl;
	cout << "*                                                        *\n" << endl;
	cout << "**********************************************************\n" << endl;
	cout << "\n" << endl;

	return tResult;
}

TLR_RESULT EtherCatCIFX::Startup(APPLICATION_T* ptApp)
{

	TLR_RESULT tResult = TLR_S_OK;
	TLR_UINT32 ulChannel = 0;
	m_hDriver = NULL;
	m_hChannel = NULL;

	/* common variables for packets */
	CIFX_PACKET tSendPkt = { {0} };
	CIFX_PACKET tRecvPkt = { {0} };
	CIFX_PACKET* ptRecvPkt = NULL;

	/* variable for host state */
	TLR_UINT32  ulState = 0;

	/* default timeout for driver api calls */
	TLR_UINT32  ulTimeout = m_TimeOut;


	/* prompt a startup screen when running in debug mode */
	tResult = PromptIntro(ptApp);

	if (TLR_S_OK != tResult)
	{
		return tResult;
	}

	/* place default timeout value in resources */
	ptApp->tCommon.ulTimeout = ulTimeout;

	cout << "Opening driver...\n" << endl;
	tResult = xDriverOpen(&m_hDriver);

	if (CIFX_NO_ERROR == tResult)
	{
		ptApp->tCommon.hDriver = m_hDriver;
		/* Open channel */
		cout << "Opening channel %d on board %s...\n" << ulChannel << " " << endl;
		tResult = xChannelOpen(m_hDriver, CIFX_ECAT, ulChannel, &m_hChannel);


		if (CIFX_NO_ERROR == tResult)
		{
			/* place channel handle in application resources */
			ptApp->tCommon.hChannel = m_hChannel;
			do
			{
				tResult = xChannelHostState(m_hChannel, CIFX_HOST_STATE_READY, &ulState, ulTimeout);
				/* if Dev is not ready, retry that action */
				if (CIFX_DEV_NOT_READY == tResult)
				{
					/* retry after 500 ms */
					usleep(500*1000);//change by mujy for bug [1.6.0]
				}
			} while (tResult == CIFX_DEV_NOT_READY);

			//tResult = Initialize(ptApp);
			/* check for CIFX_NO_ERROR added because return value  of xChannelHostState() changed */
			/* between SHM-lib <=0.930 and >=0.940 */

			if ((CIFX_NO_ERROR == tResult) || (CIFX_DEV_NOT_RUNNING == tResult))
			{
				cout << "Assuming configuration to exist in EtherCatCIFX Master.\n" << endl;
				if (CIFX_NO_ERROR == tResult)
				{
					/* Waiting for netX to use configuration */
					/*            do
					{
					tResult = xChannelHostState(hChannel, CIFX_HOST_STATE_READY, &ulState, ulTimeout);
					}
					while (CIFX_DEV_NOT_RUNNING == tResult);
					*/
					/* check CifX state */
					if ((CIFX_NO_ERROR == tResult) || (CIFX_DEV_NO_COM_FLAG == tResult))
					{
						/* bus on */
						cout << "Setting bus state on and wait for communication to be established...\n" << endl;
						tResult = xChannelBusState(m_hChannel, CIFX_BUS_STATE_ON, &ulState, 2000);

						if (CIFX_BUS_STATE_ON == ulState)
						{
							cout << "Entering endless loop...\n" << endl;

							/* get and show handles of configured devices */
							//GetHandles(ptApp);
						}
					} /* Bus on */
					else
					{
						cout << "bus on FAILED: " << ulState << "\n" << endl;
					}
				}
				else
				{
					cout << "error: " << tResult << "\n" << endl;
				}
			}
			else
			{
				cout << "error: " << tResult << "\n" << endl;
			}
		}
		else
		{
			cout << "open Channel returned: " << tResult << "\n" << endl;
			cout << "Closing Channel...\n" << endl;
			tResult = xChannelClose(m_hChannel);
		}
	}
	else
	{
		cout << "Closing Driver...\n" << endl;
		tResult = xDriverClose(m_hDriver);
	}

	return tResult;
}

void EtherCatCIFX::initDeviceListMapTable()
{
	/*
	 * init DeviceList
	 */
	m_EtherCatDeviceList.resize(m_EtherCatDevice.size() + 1);

	map<int, DeviceParam*>::iterator it;
	for (it = m_EtherCatDevice.begin(); it != m_EtherCatDevice.end(); it++)
	{
		m_EtherCatDeviceList[((it->second)->m_nDeviceMapIndex)] = it->second;
		if (m_bDebugEnable)
		{
			cout << "EtherCatCIFX::m_EtherCatCIFXDeviceList i = " << ((it->second)->m_nDeviceMapIndex) << endl; // 1-2
		}
	}


	/*
	 * init map table
	 */
	(m_EtherCatDeviceList[1]->m_Input).m_nDeviceByteOffset = 0;
	(m_EtherCatDeviceList[1]->m_Output).m_nDeviceByteOffset = 0;

	int i = 1;

	while (i < m_EtherCatDeviceList.size() - 1)
	{

		if (m_EtherCatDeviceList[i]->m_nSimulation == NotSimulated)
		{
			(m_EtherCatDeviceList[i + 1]->m_Input).m_nDeviceByteOffset = (m_EtherCatDeviceList[i]->m_Input).m_nByteSize +
				(m_EtherCatDeviceList[i]->m_Input).m_nDeviceByteOffset;
			(m_EtherCatDeviceList[i + 1]->m_Output).m_nDeviceByteOffset = (m_EtherCatDeviceList[i]->m_Output).m_nByteSize +
				(m_EtherCatDeviceList[i]->m_Output).m_nDeviceByteOffset;
		}
		else
		{
			(m_EtherCatDeviceList[i + 1]->m_Input).m_nDeviceByteOffset = (m_EtherCatDeviceList[i]->m_Input).m_nDeviceByteOffset;
			(m_EtherCatDeviceList[i + 1]->m_Output).m_nDeviceByteOffset = (m_EtherCatDeviceList[i]->m_Output).m_nDeviceByteOffset;

		}
		i++;
	}
}

void EtherCatCIFX::loadDevice() // m_EtherCatDevice has all
{
	if (m_EtherCatDevice.size() != m_nDeviceNum) // is used to confirm all device is config
	{
		cout << "skip device " << m_EtherCatDevice.size() << endl;
		return;
	}

	TLR_RESULT tResult = TLR_S_OK;

	tResult = cifXDriverInit(&m_Init);
	/*init Map Table*/
	initDeviceListMapTable();
	/* create resources */
	tResult = CreateResources(&m_ptApp);
	if (TLR_S_OK != tResult)
	{
		throw ConfigException("CreateResources is wrong");
	}

	/* enter the startup sequence of the application */
	tResult = Startup(m_ptApp);

	sleep(2);

	//read status for single mac 
	for (int i = 1; i < m_EtherCatDeviceList.size(); i++)
	{
		if (m_EtherCatDeviceList[i]->m_nSimulation == Simulated)
		{
			continue;
		}

		//notSimulated

		if (readStatus(m_EtherCatDeviceList[i]->m_nMacID) < 0)
		{
			cout << "scan failed, rescan..." << endl;
			sleep(3);
			if (readStatus(m_EtherCatDeviceList[i]->m_nMacID) < 0)
			{
				throw ConfigException("EtherCate add Mac " + Converter::convertToString(m_EtherCatDeviceList[i]->m_nMacID) + " failed,Please check and rescan!");
			}
		}
	}

}

int EtherCatCIFX::readStatus(int nMacId)
{
	IMutexLocker locker(&m_lock);
	int nConnectStatus = 2;
	int32_t lRet;
	uint32_t ulReceiveCount = 0;
	uint32_t ulSendCount = 0;

	CIFX_PACKET tRecvPacket = { {0} };


	//Get actual packe state
	lRet = xChannelGetMBXState(m_ptApp->tCommon.hChannel, &ulReceiveCount, &ulSendCount);
	while (ulReceiveCount > 0)
	{
		//Read packet
		lRet = xChannelGetPacket(m_ptApp->tCommon.hChannel, sizeof(tRecvPacket), &tRecvPacket, 1000);
		ulReceiveCount--;
	}

	//send packet
	ECM_IF_GET_SLAVE_CURRENT_STATE_REQ_T tRequestPck = { {0} };
	ECM_IF_GET_SLAVE_CURRENT_STATE_CNF_T tRecvPck = { {0} };

	tRequestPck.tHead.ulCmd = ECM_IF_CMD_GET_SLAVE_CURRENT_STATE_REQ;
	tRequestPck.tHead.ulDest = 0x20;//dest queue handler
	tRequestPck.tHead.ulLen = 2;

	tRequestPck.tData.usStationAddress = nMacId & 0xFFFF;

	//Send Packet
	if (CIFX_NO_ERROR != (lRet = xChannelPutPacket(m_ptApp->tCommon.hChannel, (CIFX_PACKET*)&tRequestPck, 1000)))
	{
		ShowError(lRet);
		return -1;
	}
	//Wait packet
	int nWaitPacket = 100;//1s

	while (nWaitPacket > 0)
	{
		lRet = xChannelGetMBXState(m_ptApp->tCommon.hChannel, &ulReceiveCount, &ulSendCount);
		if (ulReceiveCount > 0)
		{
			//Read packet
			if (CIFX_NO_ERROR != (lRet = xChannelGetPacket(m_ptApp->tCommon.hChannel, sizeof(tRecvPck), (CIFX_PACKET*)&tRecvPck, 1000)))
			{
				ShowError(lRet);
				return -1;
			}


			if (tRecvPck.tHead.ulCmd == ECM_IF_CMD_GET_SLAVE_CURRENT_STATE_CNF && tRecvPck.tData.usStationAddress == nMacId)
			{
				cout << " receive device -> host: macid=" << (int)tRecvPck.tData.usStationAddress << endl;
				cout << "tRecvPck.tData.bCurrentState=" << (int)tRecvPck.tData.bCurrentState << endl;
				cout << "tRecvPck.tData.ulActiveError=" << (int)tRecvPck.tData.ulActiveError << endl;

				return nConnectStatus;
			}
			else
			{
				cout << "receive device -> host: macid=" << (int)tRecvPck.tData.usStationAddress << endl;
				cout << "tRecvPck.tHead.ulCmd=" << (int)tRecvPck.tHead.ulCmd << endl;
				cout << "tRecvPck.tData.bCurrentState=" << (int)tRecvPck.tData.bCurrentState << endl;
				cout << "tRecvPck.tData.ulActiveError=" << (int)tRecvPck.tData.ulActiveError << endl;
				return -1;
			}
		}
		usleep(10 * 1000);
		--nWaitPacket;
	}

	if (nWaitPacket == 0)
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::FATAL, "CIFXEtherCat::readStatus() MacId=" + Converter::convertToString(nMacId) + " wait packet time out(1s)");
		return -1;
	}
}

void EtherCatCIFX::ShowError(int32_t lError)
{
	if (lError != CIFX_NO_ERROR)
	{
		char szError[1024] = { 0 };
		xDriverGetErrorDescription(lError, szError, sizeof(szError));
		printf("Error : 0x%X,<%s>\n", (unsigned int)lError, szError);
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::FATAL, "CIFXEtherCat::ShowError() ErrorCode=" + Converter::convertToString((unsigned int)lError) + string(szError));
	}
}

void EtherCatCIFX::addDeviceParam(int macid, DeviceParam* dp)
{

	m_EtherCatDevice[macid] = dp;
	cout << "macid :" << macid << ",device size = " << m_EtherCatDevice.size() << endl;
}

int EtherCatCIFX::getOutputByteSize(const int& macid)
{
	DeviceParam* pDevice = m_EtherCatDevice[macid];
	return pDevice->m_Output.m_nByteSize;
}

int EtherCatCIFX::getInputByteSize(const int& macid)
{
	DeviceParam* pDevice = m_EtherCatDevice[macid];
	return pDevice->m_Input.m_nByteSize;
}

int EtherCatCIFX::getOutputOffset(const int& macid)
{
	DeviceParam* pDevice = m_EtherCatDevice[macid];
	return pDevice->m_Output.m_nDeviceByteOffset;
}

int EtherCatCIFX::getInputOffset(const int& macid)
{
	DeviceParam* pDevice = m_EtherCatDevice[macid];
	return pDevice->m_Input.m_nDeviceByteOffset;
}


bool EtherCatCIFX::readByte(int macid, char* buffer)
{
	IMutexLocker locker(&m_lock);

	TLR_RESULT tResult = xChannelIORead(m_ptApp->tCommon.hChannel, 0,
		getInputOffset(macid), getInputByteSize(macid), buffer, m_ptApp->tCommon.ulTimeout);

	if (m_bDebugEnable)
	{
		
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, " EtherCat macid = " + Converter::convertToString(macid) + ", recv: " + Hex::GetHexString(buffer, getInputByteSize(macid)));
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, " EtherCat macid = " + Converter::convertToString(macid) + ", recv inputoffset: " + Converter::convertToString(getInputOffset(macid)) + ", size: = " + Converter::convertToString(getInputByteSize(macid)));
	}
	if (CIFX_NO_ERROR != tResult)
	{
		throw IOException("failed to read data in device macid = " + Converter::convertToString(macid) + ", Error code:" + Converter::convertToString(tResult));
	}

	return true;
}

bool EtherCatCIFX::writeByte(int macid, char* byte)
{
	IMutexLocker locker(&m_lock);

	TLR_RESULT tResult = xChannelIOWrite(m_ptApp->tCommon.hChannel, 0,
		getOutputOffset(macid), getOutputByteSize(macid), byte, m_ptApp->tCommon.ulTimeout);
	if (m_bDebugEnable)
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, " EtherCat macid = " + Converter::convertToString(macid) + ", send: " + Hex::GetHexString(byte, getOutputByteSize(macid)));
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, " EtherCat macid = " + Converter::convertToString(macid) + ", send outputoffset: " + Converter::convertToString(getOutputOffset(macid)) + ", size: = " + Converter::convertToString(getOutputByteSize(macid)));
	}

	if (tResult != CIFX_NO_ERROR)
	{
		throw IOException("failed to write data in device macid = " + Converter::convertToString(macid) + ", Error code:" + Converter::convertToString(tResult));
	}

	return true;
}

bool EtherCatCIFX::writeExplicit(int macid, char* buffer, int index, int subIndex, int datasize)
{
	IMutexLocker locker(&m_lock);
	ETHERCAT_MASTER_PACKET_SDO_DOWNLOAD_REQ_T tRequestPck = { {0} };
	ETHERCAT_MASTER_PACKET_SDO_DOWNLOAD_CNF_T tRecvPck = { {0} };

	TLR_RESULT tResult = TLR_S_OK;

	memset(&tRequestPck, 0, sizeof(tRequestPck));
	memset(&tRecvPck, 0, sizeof(tRecvPck));

	tRequestPck.tHead.ulCmd = ETHERCAT_MASTER_CMD_SDO_DOWNLOAD_REQ;
	tRequestPck.tHead.ulDest = 0x20;//dest queue handler
	tRequestPck.tHead.ulLen = 16 + datasize;

	tRequestPck.tData.ulNodeId = macid;
	tRequestPck.tData.ulIndex = index;
	tRequestPck.tData.ulSubIndex = subIndex;
	tRequestPck.tData.ulDataCnt = datasize;


	memcpy(tRequestPck.tData.abSdoData, buffer, datasize);


	tResult = sendRecvPkt(m_ptApp, (CIFX_PACKET*)&tRequestPck, (CIFX_PACKET*)&tRecvPck);


	if (TLR_S_OK != tResult)
	{
		ShowError(tResult);
		throw IOException("writeExplicit has a error ");
	}

	return true;
}

bool EtherCatCIFX::readExplicit(int macid, char* buffer, int index, int subIndex, int& datasize)
{
	IMutexLocker locker(&m_lock);

	ETHERCAT_MASTER_PACKET_SDO_UPLOAD_REQ_T tRequestPck = { {0} };
	ETHERCAT_MASTER_PACKET_SDO_UPLOAD_CNF_T tRecvPck = { {0} };

	TLR_RESULT tResult = TLR_S_OK;


	memset(&tRequestPck, 0, sizeof(tRequestPck));
	memset(&tRecvPck, 0, sizeof(tRecvPck));


	tRequestPck.tHead.ulCmd = ETHERCAT_MASTER_CMD_SDO_UPLOAD_REQ;
	tRequestPck.tHead.ulDest = 0x20;//dest queue handler
	tRequestPck.tHead.ulLen = sizeof(tRequestPck.tData);

	//DEBUG("Specify Node Address, e. g. \"256\"  ");
	//fgets(cBuf, 128, stdin);
	tRequestPck.tData.ulNodeId = macid;

	//DEBUG("Specify Index, e.g. \"4096\"  ");
	//fgets(cBuf, 128, stdin);
	tRequestPck.tData.ulIndex = index;

	//DEBUG("Specify Subindex, e.g. \"1\"  ");
	//fgets(cBuf, 128, stdin);
	tRequestPck.tData.ulSubIndex = subIndex;



	tResult = sendRecvPkt(m_ptApp, (CIFX_PACKET*)&tRequestPck, (CIFX_PACKET*)&tRecvPck);

	if (tResult != TLR_S_OK)
	{
		throw IOException("readExplicit has a error ");
	}


	//UINT32 ulTemp;
	memcpy(buffer, tRecvPck.tData.abSdoData, datasize);

	datasize = tRecvPck.tData.ulDataCnt;
	cout << "SDO Upload: nodeID: " << tRecvPck.tData.ulNodeId << ", index: " <<
		tRecvPck.tData.ulIndex << ", subindex: " << tRecvPck.tData.ulSubIndex << endl;

	return true;
}


TLR_RESULT EtherCatCIFX::sendRecvPkt(APPLICATION_T* ptApp, CIFX_PACKET* ptSendPkt, CIFX_PACKET* ptRecvPkt)
{
	TLR_RESULT tResult = TLR_S_OK;

	/* fire the packet */
	tResult = xChannelPutPacket(ptApp->tCommon.hChannel, ptSendPkt, ptApp->tCommon.ulTimeout);
	if (TLR_S_OK != tResult)
	{
		return tResult;
	}

	/* ok, at this point we have successfully sent a packet */

	/* check for packets to receive */
	/* the ulCnfCmd is always: ulReqCmd | 0x01 */
	TLR_UINT32 ulCnfCmd = ptSendPkt->tHeader.ulCmd | 0x01;

	while (CIFX_NO_ERROR == (tResult = xChannelGetPacket(ptApp->tCommon.hChannel, sizeof(*ptRecvPkt), ptRecvPkt, ptApp->tCommon.ulTimeout)))
	{
		/* check for our packet */
		if (ptRecvPkt->tHeader.ulCmd == ulCnfCmd)
		{
			/* it is our packet, so return its status as result */
			tResult = ptRecvPkt->tHeader.ulState;

			/* Note: we also return the packet which we have received (by reference, see signature of function) */

			/* we have received our packet, so we can break here */
			break;
		}
		else
		{
			/* it is something else, so place it in the application packet handler */
			handlePacket(ptApp, ptRecvPkt);
		}
	}

	return tResult;
}

void EtherCatCIFX::sendEmplyPkt(APPLICATION_T* ptApp)
{

}

void EtherCatCIFX::handlePacket(APPLICATION_T* ptApp, CIFX_PACKET* ptPacket)
{
	TLR_PACKET_HEADER_T* ptPck = (TLR_PACKET_HEADER_T*)ptPacket;


	cout << "receive other packet" << endl;

}

