/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .cpp
** Description: 
** Release: 
** Modification history: 
** 					2015-07-01  lvjw  create 
**      
***************************************************************************/
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <map>
#include <iostream>

#include "FileLogger.h"
#include "Converter.h"
#ifdef IAP4_0
#include "ITime.h"
#else
#include "Time.h"
#endif
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

using namespace std;

FileLogger::FileLogger() :  m_dir("/tmp"), 
	m_threshold(string::npos), m_sizeLimit(1024*1024), m_exit(false) 
{
}

FileLogger::~FileLogger()
{
	m_waitLock.lock();
	m_exit = true;
	m_waitLock.unlock();
	
	m_waitCond.wakeAll();

	// wait for exiting from run()
	wait();
}

void FileLogger::init(const string &dir, unsigned int threshold, long fileSizeLimit)
{
	if (!dir.empty()) // dir is specified 
	{
		m_dir = dir;
	}
	
	if (m_dir != "/")
	{
		while (m_dir.at(m_dir.size() - 1) == '/')
			m_dir.erase(m_dir.size() - 1);
	}
	
	if (access(m_dir.c_str(), R_OK|W_OK) != 0) // cannot obtain 'rw' permission of dir
	{
		throw string("FileLogger::init(): Failed! Cannot access specified syslog directory '"+dir+"'.");
	}
	
	getDateDir();
	initFileQueue();
	
	if (threshold > 0)
	{
		m_threshold = threshold;
	}
	
	if (fileSizeLimit > m_sizeLimit)
	{
		m_sizeLimit = fileSizeLimit;
	}
}

void FileLogger::logMsg(const string &msg)
{
	if (m_exit) // return when logger exits
	{
		return;
	}
	m_queueLock.lock();
	#ifdef IAP4_0
	m_logMessage.push(ITime::getCurrentTimeAsStr()+" "+(msg.size()<=500 ? msg : msg.substr(0,497).append("...")));
	#else
	m_logMessage.push(Time::getCurrentTimeAsStr()+" "+(msg.size()<=500 ? msg : msg.substr(0,497).append("...")));
	#endif
	m_queueLock.unlock();
	
	m_waitLock.lock();
	m_waitLock.unlock();
	m_waitCond.wakeAll();
}

string FileLogger::getCurrentDate() const
{
	#ifdef IAP4_0
	ITime::TimeItem tv;
	#else
	Time::TimeItem tv;
	#endif
	#ifdef IAP4_0
	ITime::getCurrentTime(tv);
	#else
	Time::getCurrentTime(tv);
	#endif
	string ret = Converter::convertToString(tv.m_year);
	tv.m_month >= 10 ?
	ret.append(Converter::convertToString(tv.m_month)):
	ret.append("0").append(Converter::convertToString(tv.m_month));
	return tv.m_day >= 10 ? ret.append(Converter::convertToString(tv.m_day)):
				ret.append("0").append(Converter::convertToString(tv.m_day));
}

void FileLogger::getDateDir()
{
	m_strDateDir=m_dir+"/"+getCurrentDate();
	if (access(m_strDateDir.c_str(), F_OK) != 0)
	{
		if(mkdir(m_strDateDir.c_str(),S_IRWXU|S_IRWXG|S_IRWXO) != 0)
		{
			throw string("FileLogger::init(): Failed! Cannot creat specified syslog directory '"+m_strDateDir+"'.");
		}
	}
	else
	{
		if (access(m_strDateDir.c_str(), R_OK|W_OK) != 0) // cannot obtain 'rw' permission of dir
		{
			throw string("FileLogger::init(): Failed! Cannot access specified syslog directory '"+m_strDateDir+"'.");
			
		}
	}
}

void FileLogger::initFileQueue()
{
	while(!m_fileQueue.empty())
	{
		m_fileQueue.pop();
	}
	DIR *dp = opendir(m_strDateDir.c_str());

    if (dp == NULL)
    {
		throw string("SysLogger::initFileQueue(): Failed! Cannot open '"+m_strDateDir+"'.");
    }

    struct dirent *dirp = NULL;

    map< int, map<unsigned int, string> > files;

    string fName;
    int date = 0;
    unsigned int index = 0;
    while ((dirp = readdir(dp)) != NULL)
    {
        fName = dirp->d_name;
        
        if (fName.size() < 18)
        {
        	// invalid log file name, skip
        	continue;
        }
        
        if (fName.substr(0, 6)!="syslog" 
        		|| fName.substr(fName.size()-4)!=".txt"
                    || (fName.size()>19 && fName.substr(14, 1)!="-"))
        {
        	// Not match: syslog*.txt or syslog*-*.txt, skip
            continue;
        }
        
        if (Converter::stringToInt(date, fName.substr(6, 8)))
        {
        	// file date is ok
        	
        	if (fName.size() == 18)
        	{
        		// file without index
                index = 0;
        	}
            else if (fName.size()<20 || !Converter::stringToUInt(index, fName.substr(15, fName.size() - 19)))
            {
            	// fName invalid, or index invalid, skip
            	continue;
            }

            if (files.find(date) == files.end())
            {
            	// new date
                map<unsigned int, string> mm;
                mm[index] = fName;
                files[date] = mm;
            }
            else
            {
            	// date already exist, add new index 
                files[date][index] = fName;
            }
        }
    }
    
    if (closedir(dp) != 0)
    {
		throw string("SysLogger::initFileQueue(): Failed! Cannot close '"+m_strDateDir+"'.");
    }

	string curFileDate = getCurrentDate();
	
	// keep sorted file names in m_fileQueue
	//
    map<int, map<unsigned int, string> >::iterator it;
    map<unsigned int, string>::iterator itt;
    for (it = files.begin(); it != files.end(); ++it)
    {
        for (itt = (it->second).begin(); itt != (it->second).end(); ++itt)
        {
        	m_fileQueue.push(m_strDateDir + "/" + itt->second);

        	if ((itt->second).substr(6, 8) == curFileDate)
        		m_fileName = m_strDateDir + "/" + itt->second; // keep the file as start file
        }
    }
}

void FileLogger::openFile()
{
	// internal invocation

	string curFileDate = getCurrentDate();
	unsigned int index = 0;
	
	if (curFileDate==m_lastFileDate && !m_fileQueue.empty())
	{
		// Not first start, same date log, and file list contains files
		
		m_fileName = m_fileQueue.back(); // get last file name
		if ((m_fileName.size() - m_strDateDir.size()) > 20) // remember '/' between dir and file name
		{
			// file with index
			Converter::stringToUInt(index, m_fileName.substr(16 + m_strDateDir.size(), m_fileName.size() - 20 - m_strDateDir.size())); // get index, must be successfully!
		}
	}
	else if (m_lastFileDate.empty() && !m_fileName.empty())
	{
		// First start and m_fileName exists
		if ((m_fileName.size() - m_strDateDir.size()) > 20) // remember '/' between dir and file name
		{
			// file with index
			Converter::stringToUInt(index, m_fileName.substr(16 + m_strDateDir.size(), m_fileName.size() - 20 - m_strDateDir.size())); // get index, must be successfully!
		}
	}
	else
	{
		// Not first start and it is a new date log, or First start but no init m_fileName
		m_fileName = m_strDateDir + "/syslog" + curFileDate + ".txt";
	}
	
	// count the log file's index, and reset file name
	while (fileExist(m_fileName) && fileSizeOverflow(m_fileName))
	{
		m_fileName = m_strDateDir + "/syslog" + curFileDate + "-" + Converter::convertToString(++index) + ".txt";
	}
	
	if (!fileExist(m_fileName))
	{
		m_fileQueue.push(m_fileName); // add new file in list
	}

	m_file.open(m_fileName.c_str(), ios::out | ios::app); // previous file has been closed in writeMsgToFile()
	if (m_file.fail()) // either badbit or failbit is set
	{
		throw string("SysLogger: Open file("+m_fileName+") failed!"); // Syslogger will exit!
	}
	
	m_lastFileDate = curFileDate; // update
	
	// <> remove old log files base on m_threshold
	string rmFile;
	while (m_fileQueue.size() > m_threshold)
	{
		rmFile = m_fileQueue.front();
		if (remove(rmFile.c_str()) != 0)
		{
			// remove failed!
			cout << "@@ SysLogger: Remove '" << rmFile << "' failed!" << endl;
		}
		
		m_fileQueue.pop(); // remove file from list anyway
	}
}

void FileLogger::writeMsgToFile(const string &msg)
{
	if(m_lastFileDate.compare(getCurrentDate())!=0)
	{
		getDateDir();
		initFileQueue();
		m_file.close();
		openFile();
	}
	if (fileSizeOverflow(m_fileName) )
	{
		m_file.close();
		openFile(); // open a new file. may throw string
	}
	
	m_file << msg << "\n";
	//m_file << msg; // <>for batch log<> msg with a '\n' inside
	if (m_file.fail()) // either badbit or failbit is set
	{
		throw string("SysLogger: Write to file("+m_fileName+") failed!");
	}
	m_file.flush();
} 

bool FileLogger::hasMsgInQueue() const
{
	IMutexLocker locker(&m_queueLock);
	return !m_logMessage.empty();
}

string FileLogger::popMsgFromQueue()
{
	IMutexLocker locker(&m_queueLock); //lock the queue
	
	/* <><> string msg;
	int i = 0;
	while (!m_logMessage.empty() && i<10)
	{
		msg.append(m_logMessage.front() + "\n");
		m_logMessage.pop();
		++i;
	}*/
	string msg = m_logMessage.front();
	m_logMessage.pop();
	return msg;
}

bool FileLogger::fileExist(const string &fn) const
{
	return ::access(fn.c_str(), F_OK) == 0;
}

bool FileLogger::fileSizeOverflow(const string &fn) const
{
	struct stat st;
    if (stat(fn.c_str(), &st) == -1)
    { 
		return true; // treat errors as file-size is overflow -> about to create a new file
    }
		
    return st.st_size > m_sizeLimit;
}

void FileLogger::run()
{
	try
	{
		openFile(); //may throw string from here <><><>
		
		while (true)
		{
			m_waitLock.lock();
			while (!hasMsgInQueue() && !m_exit)//no message to write
				m_waitCond.wait(&m_waitLock);
			m_waitLock.unlock();
			
			if (m_exit)
			{
				m_file.close();
				return;
			}
			
			writeMsgToFile(popMsgFromQueue()); //may throw string from here
		}
	}
	catch (const string &e)
	{
		m_exit = true;
		m_file.close();
		cerr << "@@ SysLogger exited! Reason: " << e << endl;
	}
}

void FileLogger::saveMsg(const std::string &msg)
{
	#ifdef IAP4_0
	m_saveMessage.push(ITime::getCurrentTimeAsStr()+" "+(msg.size()<=500 ? msg : msg.substr(0,497).append("...")));
	#else
	m_saveMessage.push(Time::getCurrentTimeAsStr()+" "+(msg.size()<=500 ? msg : msg.substr(0,497).append("...")));
	#endif
}

void FileLogger::logSaveMsg()
{
	m_queueLock.lock();
	while(!m_saveMessage.empty())
	{
		string msg = m_saveMessage.front();
		m_saveMessage.pop();
		m_logMessage.push(msg);
	}
	
	m_queueLock.unlock();
	
	m_waitLock.lock();
	m_waitLock.unlock();
	m_waitCond.wakeAll();
}

