/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: FailedToReachSetpoint.cpp
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-03-17   LiJuanjuan create
**      
*********************************************************************/
#include "FailedToReachSetpoint.h"

FailedToReachSetpoint::FailedToReachSetpoint(const std::string &s):TMCException(s)
{
}


