/********************************************************************
** Copyright (c) 2019, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: EPD.h
** Description: Verity EPD
*                RS232
* 				   Communication Type:All commans are ASCII, <LF> = line feed, <CR> = carrige return 
* 				 BaudRate:9600
*                DataBit:8
*                StopBit:1
*                Parity: none
*                FlowControl:no flow control 
*                         
** Release: 1.1
** Modification history: 
** 					2019-11-13   mujy create
**      
*********************************************************************/

#ifndef EPD_H_
#define EPD_H_

#include "IWaitCondition.h"
#include "DeviceNode.h"
#include "SerialDevice.h"
#include "IThread.h"
#include "IntTypeInfo.h"
#include "StringTypeInfo.h"
#include "DoubleTypeInfo.h"
#include "CBase.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
#endif


using namespace std;

class EPD:public SerialDevice,public IThread
{
	DECLARE_DYNAMIC(EPD)
	DECLARE_MSG_MAP
	
	struct Cmd
	{
		string strCommand;
		int nActionTimeOutS;
	};
public://
	EPD();
	virtual ~EPD();
	
public:
	bool writeI(int nChannelNum, int setpt, const IntTypeInfo &);
	bool readI(int nChannelNum, int *value, const IntTypeInfo &);
	bool readS(int nChannelNum, std::string *value, const StringTypeInfo &);
	bool writeS(int nChannelNum, std::string value, const StringTypeInfo &);
	bool readD(int nChannelNum, double *value, const DoubleTypeInfo &);
	
public://xml
	void init();
	
public://voerride
	
	virtual void clearPort(){}
	
protected:
	virtual void run();
	virtual void initDevice();

protected:
	bool writeRawCmd(int nnChannelNum, std::string strCommand, const StringTypeInfo &typeInfo);
	bool changeDebugMode(int nnChannelNum, int nValue, const IntTypeInfo &typeInfo);

	void logSendCommand(const std::string &strCommand);
	void logRecieveCommand(const std::string &strCommand);
private:
	void initChs(DeviceNode<EPD> *pNode);
	
	void Subpackage(string &strData);
	void dealWithMsg(string &strData);

	void OnReadACK(string &strData);
	void OnReadErr(string &strData);
	void OnReadTrendData(string &strData);
private:
	mutable IMutex *m_mutex;
	IWaitCondition m_waitAction;

	std::string m_strConfigList;
	std::string m_strConfigName;
	double m_dTrendData;

	int m_nEndPoint;//1 reach endpoint; 0 not
	int m_nEpdStatus;
	
	string m_strError;

	static Cmd m_WriteIntCommands[];
	static Cmd m_WriteStrCommands[];

	string m_strACK;
	bool m_bDebugMode;
};

#endif /*EPD_H_*/
