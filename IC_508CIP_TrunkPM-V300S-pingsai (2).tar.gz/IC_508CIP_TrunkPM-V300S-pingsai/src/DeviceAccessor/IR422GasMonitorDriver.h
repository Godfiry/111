/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: IR422GasMonitorDriver.h
** Description: This driver is used for IR-422 GasMonitor
*                  RS485 communication protocol 
* 				   Communication Type:ASCII Mode
* 				   BaudRate:38400
*                  DataBit:7
* 				   StartBit:1
*                  StopBit:1
*                  Parity:odd
*                          
** Release: 1.1
** Modification history: 
** 					
     
*********************************************************************/
#ifndef IR422GASMONITORDRIVER_H_
#define IR422GASMONITORDRIVER_H_

#include "SerialDevice.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif


class IR422GasMonitorDriver : public SerialDevice
{
	DECLARE_DYNAMIC(IR422GasMonitorDriver)	
	DECLARE_MSG_MAP	
	
	public:
		IR422GasMonitorDriver();
		virtual ~IR422GasMonitorDriver();
		
		bool readDouble(int nChannelNum, double *pValue,const DoubleTypeInfo &typeInfo);
		bool readInt(int nChannelNum, int *pValue,const IntTypeInfo &typeInfo);
		bool writeInt(int nChannelNum, int Value,const IntTypeInfo &typeInfo);
		void init();
		
	protected:
		std::string readCommand(std::string strCommand, int ntimeOut);	
	    void initDevice();
	    void initChs(DeviceNode<IR422GasMonitorDriver>* pNode);
		
	private:
		typedef struct
		{
			int m_nCmdSize;
			std::string m_strCmd;
			int m_nResLength;
		}Com; 
	static Com m_Commands[];
	
	std::string m_startCmd;
	char m_cStartCmd;
	std::string m_strAddress;
	std::string m_endCmd;
};

#endif /*IR422GASMONITORDRIVER_H_*/
