/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: IOInterlockException.h
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-01-03   LiJuanjuan create
**      
*********************************************************************/
#ifndef IOINTERLOCKEXCEPTION_H_
#define IOINTERLOCKEXCEPTION_H_

#include "BlockingAlarm.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "AbortException.h"
#endif
#ifdef IAP4_0
using namespace IAP::ALARM;
using namespace IAP;
#endif

class IOInterlockException:public AbortException
{
	private:
		BlockingAlarm *m_alarm;
		
	public:
		IOInterlockException(const std::string &s, BlockingAlarm *alarm);
		
		BlockingAlarm* getAlarm()const;
};

#endif /*IOINTERLOCKEXCEPTION_H_*/
