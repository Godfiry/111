/********************************************************************
** Copyright (c) 2019 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: ProcessStatusInfo.h
** Description:  
** Release: 1.0
** Modification history:           
** 					2019-04-24   Duq create
** 
*********************************************************************/

#ifndef PROCESSSTATUSINFO_H_
#define PROCESSSTATUSINFO_H_

#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class ProcessStatusInfo : public IntValueInfo
{
	public:
		//Unknown:0,Processing,Processed,Aborted
		static const int Unknown = 0;
		static const int Processing = 1;
		static const int Processed = 2;
		static const int Aborted = 3;
		
		static const IntTypeInfo typeInfo;

	    ProcessStatusInfo():IntValueInfo(0, typeInfo)
	    {
	    }
	
	    ProcessStatusInfo(int i):IntValueInfo(i, typeInfo)
	    {
	    }
	
	    ProcessStatusInfo(std::string s):IntValueInfo(s, typeInfo)
	    {
	    }
};

#endif  /*PROCESSSTATUSINFO_H_*/
