/********************************************************************
** Copyright (c) 2020, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TCPFestoMotor.h
** Description:
** Release: 1.1
** Modification history:
**                  2021-5-14   zhangyy create
**
** Product type: Festo CMMT Servo Drive
** Device communication setting:
**          Control mode:      Modbus TCP Protocol
**          Port:              502
*********************************************************************/
#ifndef TCPFESTOMOTOR_H_
#define TCPFESTOMOTOR_H_

#include "TCPDeviceFesto.h"
#include "DeviceNode.h"
#include "ReadWriteDouble.h"
#include "MathTool.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class TCPFestoMotor :public TCPDeviceFesto
{
    DECLARE_DYNAMIC(TCPFestoMotor)
    DECLARE_MSG_MAP

private:
    typedef enum    //[zhangcx v1.1.65_HotFix5]
    {   //Set in order
        Mode1 = 1,//PositionControlError
        Mode2 = 2,//Torque,Temperature
    }AdditionalDataMode;
    
public:
    TCPFestoMotor();
    virtual ~TCPFestoMotor();
    virtual void init();
    virtual std::string getDeviceName();
    //virtual void acceptData();
    bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
    bool readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);
    bool writePositionRecord(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
    bool readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);
    bool readPosition(int nChannelNum, int* pValue, const IntTypeInfo &typeInfo);
    bool writeTargetVelocity(int nChannelNum, double dVelocity,const DoubleTypeInfo &typeinfo);
    bool writeAbsolutePosition(int nChannelNum, double dPosition, const DoubleTypeInfo &typeinfo);
    bool writeRelativePosition(int nChannelNum, double dPosition, const DoubleTypeInfo &typeinfo);
    virtual void readInput();
    virtual void writeOutput();
    virtual void executePositionRecord();
    void constructOutWCmd(unsigned char Controlword);
    void parseInWCmd();
    bool GetBitfromInt(int myInt, int bitNumber);
    int GetWord(unsigned char Upper, unsigned char Lower);
    float GetFloat(char char1,char char2,char char3,char char4);
    double GetDouble(char char1,char char2,char char3,char char4,char char5,char char6,char char7,char char8);

    virtual void updateModbusTimeOut();

    void queryWriteMultipleRegister();
    void answerWriteHoldingRegister();

    void queryReadInputRegister();
    void answerReadInputRegister();

    void queryReadHoldingRegister();
    void answerReadHoldingRegister();

    bool queryWriteSingleRegister();
    bool answerWriteSingleRegister();

    void setPinMaxPosition(double dValue);
    void setPinMinPosition(double dValue);
    void setUpPositionTol(double dValue);
    void setDownPositionTol(double dValue);
    //zhangpf add
    void setPinUpTimeOut(int nValue);
    void setPinDownTimeOut(int nValue);

    void setRecord2Position(double dValue);
    void setRecord3Position(double dValue);
    void setRecord4Position(double dValue);
    void setPinupConfigName(string strValue);//added by liusy[1.1.57]
    void setPindownConfigName(string strValue);
    
    void setAdditionalDataMode(int nMode);//[zhangcx v1.1.65_HotFix5]
protected:
    void initChannels(DeviceNode<TCPFestoMotor> *node);

private:
    double m_dRecord2Position;
    double m_dRecord3Position;
    double m_dRecord4Position;
    double m_dPinUpPosition;
    double m_dPinDownPosition;
    double m_dUpPositionTol;
    double m_dDownPositionTol;
    string m_strPinupConfigName;//added by liusy[1.1.57]
        string m_strPindownConfigName;
    ReadWriteDouble* m_pCfgMotorPinUpPosition;//added by zhangyy[1.8.15]
    ReadWriteDouble* m_pCfgMotorPinDownPosition;

    //zhangpf add
    int m_nPinUpTimeOut;
    int m_nPinDownTimeOut;
    
    int m_nAdditionalDataMode;//[zhangcx v1.1.65_HotFix5]

    bool m_bWaiting;
    bool m_bReadCmd;
    bool m_bExecuteRecordFlag;
    bool m_bConfigMotorPositionInSetup;//added by zhangyy
    std::string m_strError;
    std::string m_strRawResult;
    std::string m_strResult;

    //zhangyy add
    char m_modbusSend[64];
    char m_modbusRead[64];

    int m_nPositioningRecord;

    int m_nTransactionId;
    int m_outW[30];//12 word = 24 byte
    int m_inW[30];//12 word = 24 byte
    int m_nModbusTimeOut;
    int m_nModbusTimeOutCurrent;

    int m_nPinStatus;
    int m_nFinishPositionRecord;

    double m_dTargetPosition;
    double m_dTargetVelocity;

    double m_dOverride;
    double m_dAcceleration;
    double m_dDeceleration;
    double m_dConvertPositionOutput;
    double m_ConvertVelocityOutput;
    double m_ConvertPositionInput;
    double m_ConvertVelocityInput;

    double m_dActualPosition;
    double m_dActualVelocity;

    double m_dActualTorque;//[zhangcx v1.1.65_HotFix5]
    double m_dPositionControlError;
    //double m_dActualAccelerate;
    //double m_dActualCurrent;
    //double m_dActualI2t;
    double m_dTemperature;//[zhangcx v1.1.65_HotFix5]

    //Telegram 111 WriteCommand contain following 11 word
    int nSTW1;
    int nPOS_STW1;
    int nPOS_STW2;
    int STW2;
    int nOverride;
    int nMDI_TarPos1;
    int nMDI_TarPos2;
    int nMDI_Velocity1;
    int nMDI_Velocity2;
    int nMDI_ACC;
    int nMDI_DEC;

    //Telegram 111 ReadCommand contain following 11 word
    int nZSW1;
    int nPOS_ZSW1;
    int nPOS_ZSW2;
    int nZSW2;
    int nMELDW;
    int nXIST_A1;
    int nXIST_A2;
    int nIST_B1;
    int nIST_B2;
    int nFault_Code;
    int nWarn_Code;

    float m_fTorque;//[zhangcx v1.1.65_HotFix5]
    float fPositionControlError;
    //float fAccelerate;
    //float fCurrent;
    //float fI2t;
    float m_fTemperature;//[zhangcx v1.1.65_HotFix5]

    //nSTW1 word contain following 13 Bits
    bool m_bOutputStageEnable;// Bit 0
    bool m_bDriveCoast;// Bit 1
    bool m_bFastStop;// Bit 2
    bool m_bEnableOperation;// Bit 3
    bool m_bRampGenerator; // Bit 4
    bool m_bRejectPositioningTask; //Bit 4, use this
    bool m_bStartRampGenerator;// Bit 5
    bool m_bIntermediateStop;// Bit 5, use this
    bool m_bRotationalSpeedSetPoint;// Bit 6
    bool m_bActivatePositioningTask;// Bit 6, use this
    bool m_bAcknowledgeMalfunction;// Bit 7
    bool m_bJogging1;// Bit 8
    bool m_bJogging2;// Bit 9
    bool m_bPLCMasterControl;// Bit 10
    bool m_bInvertSetPointValue;// Bit 11
    bool m_bStartHoming;// Bit 11, use this
    bool m_bReleaseHoldingBrake;// Bit 12
    bool m_bStartRecordChange;// Bit 13

    //nPOS_STW1 word contain following Bits
    bool m_bPositioningRecordSelectionBit0;
    bool m_bPositioningRecordSelectionBit1;
    bool m_bPositioningRecordSelectionBit2;
    bool m_bPositioningRecordSelectionBit3;
    bool m_bPositioningRecordSelectionBit4;
    bool m_bPositioningRecordSelectionBit5;
    bool m_bPositioningRecordSelectionBit6;
    bool m_bRelativePositioning;
    bool m_bAbsolutePositioning;
    bool m_bMDISelection;

    //nPOS_STW2 word contain following Bits
    //bool m_bTrackingMode; // bit 0
    //bool m_bCurrentPositionasHome;// bit 1
    //bool m_bIncrementalJogging;// bit 5: 1=incremental, 0=velocity
    //bool m_bTouchProbeSource;// bit 10: 1=secondary, 0=primary
    //bool m_bTouchProbeEdge;// bit 11: 1=falling edge, 0=rising edge
    bool m_bActivateSoftwareLimitSwitch; // bit 14: 1=active, 0=deactive
    bool m_bActivateHardwareLimitSwitch;// bit 15: 1=active, 0=deactive

    //nZSW1 word contain following 16 Bits
    bool m_bReadytobeSwitchOn;
    bool m_bReadyforOperation;
    bool m_bOperationEnabled;
    bool m_bMalfunctionEffective;
    bool m_bCoastingActive;
    bool m_bFastStopActive;
    bool m_bSwitchOnLockActive;
    bool m_bWarningEffective;
    bool m_bVelocityInRange;
    bool m_bPositionInRange;
    bool m_bGuideRequired;
    bool m_bVelocityComparisonValueReached;
    bool m_bTargetPositionReached;// m_bTargetPositionReached
    bool m_bIMPLimitNotReached;
    bool m_bReferencePointSet;
    bool m_bHoldingBrakeReleased;
    bool m_bPositioningTaskActivated;
    bool m_bNoWarningifMotorOvertemperature;
    bool m_bDriveisStationary;
    bool m_bMotorDirectionofRotation;
    bool m_bAxisAccelerated;
    bool m_bNoPowerUnitOvertemperatureWarning;
    bool m_bDriveDecelerated;

    /**********nPOS_ZSW1***From Bit 0 to Bit 15******************/
    bool m_bActivePositioningRecordBit0;
    bool m_bActivePositioningRecordBit1;
    bool m_bActivePositioningRecordBit2;
    bool m_bActivePositioningRecordBit3;
    bool m_bActivePositioningRecordBit4;
    bool m_bActivePositioningRecordBit5;
    bool m_bActivePositioningRecordBit6;
    bool m_bActivePositioningRecord;
    bool m_bNegativeLimitSwitchActive;
    bool m_bPositiveLimitSwitchActive;
    bool m_bJoggingActive;
    bool m_bHomingActive;
    bool m_bPositioningRecordActive;
    bool m_bMDIActive;

    /**********nPOS_ZSW2***From Bit 0 to Bit 15******************/
    bool m_bTrackingModeActive;
    bool m_bVelocityLimitingActive;
    bool m_bSetPointValueStopped;
    bool m_bDriveTravelsForward;
    bool m_bDriveTravelsBackward;
    bool m_bNegativeSoftwareLimitSwitchActive;
    bool m_bPositiveSoftwareLimitSwitchActive;
    bool m_bActualPositionLessEqualThanCamSwitch0;
    bool m_bActualPositionLessEqualThanCamSwitch1;
    bool m_bDirectOutput1ViaPositioningRecord;
    bool m_bDirectOutput2ViaPositioningRecord;
    bool m_bFixedStopReached;
    bool m_bFixedStopClampingTorqueReached;
    bool m_bTravelToFixedStopActive;
    bool m_bPositionCommandActive;
};
#endif /* TCPFESTOMOTOR_H_ */
