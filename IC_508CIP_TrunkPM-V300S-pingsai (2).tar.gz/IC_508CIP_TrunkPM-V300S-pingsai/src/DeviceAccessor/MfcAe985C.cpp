/********************************************************************
** Copyright (c) 2020, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MfcAe985C.cpp
** Description: This driver applys to AE MFC 985C
** Release: 1.1
** Modification history: 
** 					2020-7-21   Mujy create
*********************************************************************/
#include "MfcAe985C.h"
#include <string.h>
#include "DeviceManager.h"

#include "Converter.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#include <iostream>//added by mujy 20151027
#include <sstream>//added by mujy 20151027
#include "StrTool.h"
#include "Hex.h"
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;

MfcAe985C::MfcAe985C():SerialDevice(100, "")
{
	m_vectorBrooksMFC.resize(13,0);
}

MfcAe985C::~MfcAe985C()
{
    
}

/*		MfcAe985C device ID MAC_ID
		MFC1 33 MFC2 34 MFC3 35 MFC4 36 MFC5 37 MFC6 38 
		MFC7 39 MFC8 40 MFC9 41 MFC10 42 MFC11 43  MFC12 44
*/


/*function discripts :
 *	NewSetpoint = setpoint  / Fullscale *100.0
 */
bool MfcAe985C::WriteCt(int nChannelNum,double dSetValue ,const DoubleTypeInfo& typeinfo)
{ 
    if( dSetValue < (double)(typeinfo.getMin()) || dSetValue > (double)(typeinfo.getMax()))
    {
		return false;
    }
    string strResponse = "";
    //////////////////////////////One way/////////////////////////////////////
    //string strMFCID = Converter::convertToString(nChannelNum+32);
    string strMFCID = Hex::hexToString(nChannelNum+32,2);
    strMFCID = StrTool::toUpper(strMFCID);
    char pSetValue[20] = {0};
	sprintf(pSetValue,"%.2f",(dSetValue/typeinfo.getMax()) * 100.0);
	string strSetValue = string(pSetValue);
    strResponse = getCommandResult("\x02"+strMFCID+"SDC"+strSetValue+"\x0D",m_timeOut);

    //////////////////////////////Another way/////////////////////////////////////
    /*memset(Message,0,MAX_MESSAGE_LEN);
    memset(Response,0,MAX_MESSAGE_LEN);
    clearPort();
    sprintf(Message,"%s%X%s%.2f%s","\x02",nChannelNum+32,"SDC",(dSetValue/typeinfo.getMax()) * 100.0,"\x0D");
  
    if(m_dev.writeRaw(Message, strlen(Message)) <= 0)
    {
    	return false;
    }
    usleep(30*1000);
  
    if(m_dev.readStr(Response,1,3) <= 0)
    {
    	throw IOException(getDeviceName()+"  send command to set flow rate failed for no response");
    }
    strResponse = string(Response);*/
    ///////////////////////////////////////////////////

    //if(Response[0] == 'O' && Resonpse[1] == 'K')
    if(strResponse.find("OK",0) != string::npos)
    {
    	return true;
    }
    else
    {
    	throw IOException(getDeviceName()+"  send command to set flow rate failed for response is "+strResponse);
    }
}

bool MfcAe985C::ReadCt(int nChannelNum, double *value ,const DoubleTypeInfo& typeinfo )
{
    int nLen = 0;
    double dTempValue = 0.0;
    string strResponse;

    //////////////////////////////One way/////////////////////////////////////
    //string strMFCID = Converter::convertToString(nChannelNum+20);
    string strMFCID = Hex::hexToString(nChannelNum+20,2);
    strMFCID = StrTool::toUpper(strMFCID);
    strResponse = getCommandResult("\x02"+strMFCID+"RFX\x0D",m_timeOut);//

    //////////////////////////////Another way/////////////////////////////////////
    /*memset(Message,0,MAX_MESSAGE_LEN);
    memset(Response,0,MAX_MESSAGE_LEN);
    
    sprintf(Message,"%s%X%s","\x02",nChannelNum+20,"RFX\x0D");
    
    while ((nLen = m_dev.readStr(Response,1,MAX_MESSAGE_LEN)) > 0)//modified by mujy 20151103;change timeout parameter 2 to 1
    {
		usleep(30*1000);
    }
    
    if(m_dev.writeRaw(Message, 6) <= 0)
    {
    	return false;
    }
    
    usleep(30*1000);
    
    memset(Response,0,MAX_MESSAGE_LEN);
    nLen = m_dev.readStr(Response, m_timeOut,8);

    if (nLen < 3)
    {
    	SysLogger::getInstance()->logMsg(LOGBRANCH::IO, LEVEL::ERROR, "MfcAe985C::ReadCt error at nChannelNum = " + Converter::convertToString(nChannelNum)+" and retry.");
		while ((nLen = m_dev.readStr(Response,1,MAX_MESSAGE_LEN)) > 0)//modified by mujy 20151103 ;change timeout parameter 2 to 1
	    {
			usleep(30*1000);
	    }
	    
	    if(m_dev.writeRaw(Message, 6) <= 0)
			return false;
	    
	    usleep(30*1000);
	    
	    memset(Response,0,MAX_MESSAGE_LEN);
	    nLen = m_dev.readStr(Response, m_timeOut,8);

	    if (nLen < 3)
	    {
			return false;
	    }
    }
    strResponse = string(Response);*/
    //////////////////////////////////////////////////

    size_t nPos = strResponse.find("\x0D",0);  //changed by wzd 1.1.39
    if(nPos == string::npos)
    {
    	throw IOException("read flow rate failed for response not include 0x0D, response is "+strResponse);
    }
    string strSplitValue = "";
    switch(strResponse[0])
    {
    	case 'N':
    		strSplitValue = strResponse.substr(1, nPos-1);

			if(!Converter::stringToDouble(dTempValue, strSplitValue))
			{
				throw IOException(getDeviceName()+" read flow rate failed for can't convert response ["+strSplitValue+"] to double value.");
			}
			if(dTempValue > 100.0)
			{
				dTempValue = 100.0;
			}
			else if(dTempValue < 0)
			{
				dTempValue = 0.0;
			}
			*value = dTempValue * (typeinfo.getMax() - typeinfo.getMin())/100.0;
			break;
    	case 'A':
    	case 'E':
    	case 'X':
    	case 'Z':
    	default:
    		SysLogger::getInstance()->logMsg(LOGBRANCH::IO, LEVEL::ERROR, "MfcAe985C::ReadCt error at nChannelNum = " + Converter::convertToString(nChannelNum) +", response is "+ strResponse);
    		*value = 0;
    		break;
    }
    return true;
}

bool MfcAe985C::WriteVDt( int nChannelNum, int dSetValue,const IntTypeInfo& typeinfo)
{
	string strResponse = "";
    //////////////////////////////One way/////////////////////////////////////
	//string strMFCID = Converter::convertToString(nChannelNum-22);
	string strMFCID = Hex::hexToString(nChannelNum-22,2);
	strMFCID = StrTool::toUpper(strMFCID);
    string strCmd = "";
	if(dSetValue == 0)//normal
	{
		strCmd = "\x02"+strMFCID+"SVN\x0D";
	}
	else if(dSetValue == 1)//Close
	{
		strCmd = "\x02"+strMFCID+"SVC\x0D";
	}
	else if(dSetValue == 2)//Open
	{
		strCmd = "\x02"+strMFCID+"SVO\x0D";
	}
    strResponse = getCommandResult(strCmd,m_timeOut);

    //////////////////////////////Another way/////////////////////////////////////


   /* memset(Message,0,MAX_MESSAGE_LEN);
    memset(Response,0,MAX_MESSAGE_LEN);
    
    if((dSetValue==0||dSetValue==1||dSetValue==2)==false)
    {
    	return false;
    }
    memset(Message,0,MAX_MESSAGE_LEN);
    memset(Response,0,MAX_MESSAGE_LEN);
    clearPort();
    switch(dSetValue)
    {
    	case 0://normal
    		sprintf(Message,"%s%X%s","\x02",nChannelNum-22,"SVN\x0D");
    		break;
    	case 1://close
    		sprintf(Message,"%s%X%s","\x02",nChannelNum-22,"SVC\x0D");
    		break;
    	case 2://open
    		sprintf(Message,"%s%X%s","\x02",nChannelNum-22,"SVO\x0D");
    		break;
    	default:
    		break;
    }

    if(m_dev.writeRaw(Message, strlen(Message)) <= 0)
    {
    	return false;
    }
    usleep(30*1000);
  
    if(m_dev.readStr(Response,1,3) <= 0)
    {
    	throw IOException(getDeviceName()+"  send command to set flow rate failed for no response");
    }
    strResponse = string(Response);*/
    /////////////////////////////////////////

    //if(Response[0] == 'O' && Resonpse[1] == 'K')
    if(strResponse.find("OK",0) != string::npos)
    {
    	return true;
    }
    else
    {
    	throw IOException(getDeviceName()+"  send command to valve failed for response is "+strResponse);
    }
}

/////////////////////////////Brook MFC GF100/GF125//////////////////////////
int  MfcAe985C::GetBrooksMFCCheckSum(char * buff)
{
    int iLen = 0;
    int iLoop = 0;
    int nData[10] = {0};
    char cTemp[5] = {0};
    int nCheckSum = 0;

    iLen = strlen(buff);
    for (iLoop = 1 ; iLoop < iLen/2; iLoop ++)
    {
		memcpy( cTemp, buff +iLoop*2, 2 );
		sscanf( cTemp, "%x", &nData[iLoop] );
		nCheckSum += nData[iLoop];
    }
    return (nCheckSum &0xff);
}

/*		MFC device ID MAC_ID
		MFC1 33 MFC2 34 MFC3 35 MFC4 36 MFC5 37 MFC6 38
		MFC7 39 MFC8 40 MFC9 41 MFC10 42 MFC11 43  MFC12 44
*/


/*function discripts :
 *	NewSetpoint = (32768 * setpoint  / Fullscale) + 16384
 */
bool MfcAe985C::WriteBrooksMFCFlowRate(int channnelNum,double setpt ,const DoubleTypeInfo& typeinfo)
{
    if( setpt < (double)(typeinfo.getMin()) || setpt > (double)(typeinfo.getMax()))
    {
		return false;
    }
    int nCheckSum = 0;
    int nLData = 0;
    int nHData = 0;
    int value = 0;
    int nLen = 0;
    memset(Message,0,MAX_MESSAGE_LEN);
    memset(Response,0,MAX_MESSAGE_LEN);

    sprintf(Message,"%2x%s",channnelNum+32,"0281056901A4");
    // value = (int)((32768 * setpt / (typeinfo.getMax() - typeinfo.getMin()) ) + 16384);
  	 double tmp = (double)((32768 * setpt / (typeinfo.getMax() - typeinfo.getMin()) ) + 16384);//modified by chenmz [V2.0.4]
 	 double tmp1 = (int)tmp;
  	value = tmp1;
    nLData = value & 0xff;
    nHData = (value >>8) & 0xff;
    nLen = strlen(Message);
    sprintf(Message + nLen,"%2x%2x%s",nLData,nHData,"00");
    nCheckSum = GetBrooksMFCCheckSum(Message);

    Message[0] = channnelNum+32;
    sprintf(Message +1,"%s","\x02\x81\x05\x69\x01\xA4");
    Message[7] = nLData;
    Message[8] = nHData;
    Message[9] = 0;
    Message[10] = nCheckSum;
    Message[11] = 0;

    if(m_dev.writeRaw(Message, 11) <= 0)
    {
    	return false;
    }
    usleep(30*1000);

    if(m_dev.readStr(Response,1,4) < 0)
    {
    	return false;
    }
	return true;
}

bool MfcAe985C::ReadBrooksMFCFlowRate(int channnelNum, double *value ,const DoubleTypeInfo& typeinfo )
{
    int nCheckSum = 0;
    char cTemp[4] = {0};
    int nLData = 0;
    int nHData = 0;
    int nValue = 0;
    int nLen = 0;
    double fData = 0;

    memset(Message,0,MAX_MESSAGE_LEN);
    memset(Response,0,MAX_MESSAGE_LEN);

    sprintf(Message,"%2x%s",channnelNum+20,"0280036A01A900");
    nCheckSum = GetBrooksMFCCheckSum(Message);

    Message[0] = channnelNum+20;
    sprintf(Message +1,"%s","\x02\x80\x03\x6A\x01\xA9");
    nLen = strlen(Message);
    Message[nLen] = 0;
    Message[nLen + 1] = nCheckSum;
    Message[nLen + 2] = 0;

    while ((nLen = m_dev.readStr(Response,1,MAX_MESSAGE_LEN)) > 0)//modified by mujy 20151103;change timeout parameter 2 to 1
    {
		usleep(30*1000);
    }

    if(m_dev.writeRaw(Message, read_message_length) <= 0)
	return false;

    usleep(30*1000);

    memset(Response,0,MAX_MESSAGE_LEN);
    nLen = m_dev.readStr(Response, msg_timeout,receive_message_length - read_message_length);

    if (nLen < (receive_message_length - read_message_length) )
    {
    	SysLogger::getInstance()->logMsg(LOGBRANCH::IO, LEVEL::ERROR, "MFC::ReadCt error at channnelNum = " + Converter::convertToString(channnelNum)+" and retry.");
		while ((nLen = m_dev.readStr(Response,1,MAX_MESSAGE_LEN)) > 0)//modified by mujy 20151103 ;change timeout parameter 2 to 1
	    {
			usleep(30*1000);
	    }

	    if(m_dev.writeRaw(Message, read_message_length) <= 0)
			return false;

	    usleep(30*1000);

	    memset(Response,0,MAX_MESSAGE_LEN);
	    nLen = m_dev.readStr(Response, msg_timeout,receive_message_length - read_message_length);
	    if (nLen < (receive_message_length - read_message_length) )
	    {
			return false;
	    }
    }

    memcpy(cTemp,Response - read_message_length + 17 ,2);
    nLData=cTemp[0];
    nHData = cTemp[1];
    nValue =(( nHData<<8 ) + (nLData &0xff))&0xffff;
    fData =(double)((double) nValue/65535.0*1000)/1000.0;   //return value  fron MFC
    if (fData < 0.25)
	fData = 0.25 ;

    *value = (fData - 0.25) *2 * (typeinfo.getMax() - typeinfo.getMin()) ;
    if((*value)<(double)(typeinfo.getMin()))
     	*value = typeinfo.getMin();

    if ((*value)>(double)(typeinfo.getMax()))
     	*value = typeinfo.getMax();

    return true;
}

void MfcAe985C::InitMFC()
{

}
 
void MfcAe985C::InitChannels(DeviceNode<MfcAe985C> *node)
{    
    for(int i=1; i<=12; i++)
    {
    	if(m_vectorBrooksMFC[i] == 1)
    	{
    		cout<<"MFC"<<i<<" is Brooks MFC"<<endl;
    		node->registerWriteCh(i,&MfcAe985C::WriteBrooksMFCFlowRate);
    	}
    	else
    	{
    		node->registerWriteCh(i,&MfcAe985C::WriteCt);
    	}
    }
    
    for(int i=13; i<=24; i++)
    {
    	if(m_vectorBrooksMFC[i-12] == 1)
    	{
    		node->registerReadCh(i,&MfcAe985C::ReadBrooksMFCFlowRate);
    	}
    	else
    	{
    		node->registerReadCh(i,&MfcAe985C::ReadCt);
    	}
    }

    for(int i=55; i<=66; i++)
    {
    	node->registerWriteCh(i,&MfcAe985C::WriteVDt);
    }
}

void MfcAe985C::init()
{
    DeviceNode<MfcAe985C> *node = new DeviceNode<MfcAe985C>(m_pollPeriod,this);
    InitChannels(node);
    DeviceManager::getInstance()->registerNode(m_nodeNum, node);
    if(!isSimulated())
    {
    	InitMFC();
    }
}

void MfcAe985C::setBrooksMFC(string strBrooksMFC)
{
	vector<string> result=StrTool::split(strBrooksMFC,",");
	int nMFC = 0;
	for(int i = 0; i < result.size(); i++)
	{
		if(!Converter::stringToInt(nMFC,result[i]))
		{
			throw "Configure error, the correct format is such as 6,9";
		}
		if(nMFC < 1 || nMFC > 12)
		{
			throw "Configure error, MFC must be from 1 to 12, the correct format is such as 6,9";
		}
		m_vectorBrooksMFC[nMFC] = 1;
	}
}

IMPLEMENT_DYNAMIC(MfcAe985C, SerialDevice )
BEGIN_MSG_MAP(MfcAe985C, SerialDevice )
    SET_V( init, MfcAe985C )
    SET_S( setBrooksMFC, MfcAe985C )
END_MSG_MAP
