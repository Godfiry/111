/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					2023-10-31   GuoJin create
**      
***************************************************************************/
#ifndef TRANSMODEINFO_H_
#define TRANSMODEINFO_H_
#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class TransModeInfo : public IntValueInfo
{
	public:
		//UnInit:-1,Receive,Send
		static const int UnInit = -1;
		static const int Receive = 0;
		static const int Send = 1;

		static const IntTypeInfo typeInfo;

		TransModeInfo():IntValueInfo(-1, typeInfo)
		{
		}

		TransModeInfo(int i):IntValueInfo(i, typeInfo)
		{
		}

		TransModeInfo(const std::string s):IntValueInfo(s, typeInfo)
		{
		}
};


#endif /*TRANSMODEINFO_H_*/
