/********************************************************************
** Copyright (c) 2016, Beijing NMC Co.,Ltd. All rights reserved.
** All rights reserved.
**
** File name: StrManager.h
**
** Description:
**
** Modification history:
* 							2016.10.31		lvjw	created.
*********************************************************************/

#ifndef STRMANAGER_H_
#define STRMANAGER_H_

#include <map>
#include <string.h>
#include <iostream>
using namespace std;


class StrManager 
{
	
//constructer and Destructer
private:
	StrManager();
public:
	virtual ~StrManager();
	static StrManager *getInstance();
private:
	static StrManager * m_pInstance;
	
//xml function
public:
	bool AddString(int nID , const string& strData);
	
public:
	bool GetString(int nID , string& strData);
	string GetString(int nID);
	
	bool IsStrExist(int nID);
	
private:
	virtual void GetStrErrAction(int nID);
	virtual void AddStrErrAction(int nID);
private:
	map<int,string> m_data;
};

#endif /*STRMANAGER_H_*/
