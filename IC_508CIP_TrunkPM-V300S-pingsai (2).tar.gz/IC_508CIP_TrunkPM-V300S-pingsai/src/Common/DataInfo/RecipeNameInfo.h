#ifndef RECIPENAMEINFO_H_
#define RECIPENAMEINFO_H_

#include "StringValueInfo.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class RecipeNameInfo : public StringValueInfo
{
public:
   static const StringTypeInfo typeInfo;

	RecipeNameInfo()
	{
	}

	RecipeNameInfo(std::string s):StringValueInfo(s)
	{
	}
};
#endif /*RECIPENAMEINFO_H_*/
