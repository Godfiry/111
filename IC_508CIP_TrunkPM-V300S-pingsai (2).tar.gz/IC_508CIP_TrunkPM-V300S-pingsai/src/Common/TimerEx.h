/*
 * TimerEx.h
 *
 *  Created on: 20210716
 *      Author: lvjiawen
 */

#ifndef SRC_COMMON_TIMEREX_H_
#define SRC_COMMON_TIMEREX_H_

#include "Timer.h"
#include "ITimeTicker.h"
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

class TimerEx : public Timer,public TimerSubscriber
{
public:
	TimerEx();
	virtual ~TimerEx();

public:
	void setTicker(ITimeTicker * pTicker);

public:
	#ifdef IAP4_0
	virtual void updateFromTimer(const Timer * const timer);
	#else
	virtual void updateFromTimer();
	#endif

private:
	ITimeTicker * m_pTicker;
};

#endif /* SRC_COMMON_TIMEREX_H_ */
