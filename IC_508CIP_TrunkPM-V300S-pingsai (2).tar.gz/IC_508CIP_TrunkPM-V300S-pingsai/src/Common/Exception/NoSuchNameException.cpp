#include "NoSuchNameException.h"

NoSuchNameException::NoSuchNameException(const std::string &s):TMCException(s)
{
}


