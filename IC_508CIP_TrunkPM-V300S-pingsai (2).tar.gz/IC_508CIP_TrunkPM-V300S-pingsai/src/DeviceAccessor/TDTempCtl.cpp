/*
 * TDTempCtl.cpp
 *
 *  Created on: 2023-9-25
 *      Author: taohao
 */

/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TDTempCtl.cpp
** Description:
** Release: 1.1
** Modification history:
**                     2013-12-31   bihuijie creat
**
*********************************************************************/
#include "TDTempCtl.h"
#include <string.h>
#include "DeviceManager.h"
#include "ObjectManager.h"
#include "Converter.h"

#include <sys/time.h>
#include <iostream>
#include "SysLogger.h"
#include <math.h>
#include "ReadWriteDouble.h"
#include "ConfigException.h"
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std;
/*
    0x00 setSV
    0xF0 setSlope
    0xE0 setPower1
    0x20 setPower2
    0XC0 setAutoOrManual
    0x48 setStopOrStart
    0x68 readPV
    0x70 readSV
    0x78 readPower1
    0x80 readPower2

*/
const unsigned char TDTempCtl::wrAddr[10] = {
            0x00,0xF0,0xE0,0x20,0xC0,0x48,0x68,0x70,0X78,0X80};


TDTempCtl::TDTempCtl():SerialDevice(80, "")
{

    m_timeOut = 200;//2s
    readArray[0]=0x01;
    readArray[1]=0x03;
    readArray[2]=0x00;
    readArray[3]=0x00;
    readArray[4]=0x00;
    readArray[5]=0x01;
    readArray[6]=0x00;
    readArray[7]=0x00;
    writeArray[0]=0x01;
    writeArray[1]=0x06;
    writeArray[2]=0x00;
    writeArray[3]=0x00;
    writeArray[4]=0x00;
    writeArray[5]=0x00;
    writeArray[6]=0x00;
    writeArray[7]=0x00;

    m_nCalibrationInitChannel = 800;//added by taohao [1.1.65]

}

TDTempCtl::~TDTempCtl()
{
}

void TDTempCtl::convertDecToHex(int d,char *result)
{
    sprintf(result,"%X",d);
}

void  TDTempCtl::differTDTempDifferMachineCh(int channelNum)
{
    int t_nChannelNum;
    if(channelNum > m_nCalibrationInitChannel)//added by taohao [1.1.65]
    {
        t_nChannelNum = channelNum - m_nCalibrationInitChannel;
    }
    else
    {
        t_nChannelNum = channelNum;
    }

    int setAddrChanel=fmod((t_nChannelNum-1),8);
    int wrAddrSelect=(t_nChannelNum-1)/8;//modify by mujy [1.5.0] for bug fix
    int newSelectAddr=fmod(wrAddrSelect,10);
    unsigned char result[1]={0};
    result[0]=(unsigned char)(setAddrChanel&0xff);

    switch (wrAddrSelect)
    {

        case 0  :
        case 10 :
            writeArray[2] = (t_nChannelNum <=80 ? 0x00 :0x10);
            writeArray[3]=wrAddr[newSelectAddr] +result[0];
            break;
        case 1:
                case 11:
            writeArray[2] = (t_nChannelNum <=80 ? 0x03 :0x13);
            writeArray[3]=wrAddr[newSelectAddr] +result[0];
            break;


        case 2:
                case 12:
            writeArray[2] = (t_nChannelNum <=80 ? 0x00 :0x10);
            writeArray[3]=wrAddr[newSelectAddr] +result[0];
            break;


        case 3:
                case 13:
            writeArray[2] = (t_nChannelNum <=80 ? 0x01 :0x11);
            writeArray[3]=wrAddr[newSelectAddr] +result[0];

            break;

        case 4:
                case 14:
            writeArray[2] = (t_nChannelNum <=80 ? 0x00 :0x10);
            writeArray[3]=wrAddr[newSelectAddr] +result[0];
            break;
        case 5:
                case 15:
            writeArray[2] = (t_nChannelNum <=80 ? 0x02 :0x12);
            writeArray[3]=wrAddr[newSelectAddr] +result[0];
            break;

        case 6:
                case 16:
        case 7:
                case 17:

        case 8:
                case 18:

        case 9:
                case 19:
            readArray[2]= (t_nChannelNum <=80 ? 0x02 :0x12);
            readArray[3]=wrAddr[newSelectAddr] +result[0];
        if(136 == t_nChannelNum)
        {
            readArray[3] = 0x6F;
        }
            break;
                default :
            break;
    }
}

unsigned short TDTempCtl::calculateCRC(char* buffer,int len)
{
    unsigned short wcrc = 0xffff;
    int temp;
    char *pushmsg = buffer;
    for(int j=0;j<len;j++)
    {
        temp = *pushmsg & 0x00FF;
        pushmsg++;
        wcrc ^= temp;
        for(int i=0;i<8;i++)
        {
            if(wcrc & 0x0001)
            {
                wcrc >>= 1;
                wcrc ^= 0xA001;
            }else{
                wcrc >>= 1;
            }
        }
    }
    return wcrc;

}

bool TDTempCtl::writeDouble(int channelNum, double settemp, const DoubleTypeInfo& typeinfo)
{

    if (isSimulated())
    {
        return true;
    }

    differTDTempDifferMachineCh(channelNum);

    //double data=settemp*10.0;
    double data=calculateWriteCarTemp(channelNum, settemp)*10.0;

    short temp=(short)(data);
    writeArray[4]=(temp>>8)&0xff;
    writeArray[5]=temp&0xff;
    unsigned short t_crc = calculateCRC(writeArray,6);
    writeArray[6] = t_crc&0xff;
    writeArray[7] = t_crc>>8;

    unsigned char result[8];
    for(int i=0;i<8;i++)
    {
        result[i]=writeArray[i];
        cout<<showbase<<uppercase<<hex<<(unsigned int)result[i]<<" ";

    }

    char response[RESP_LEN];
    bzero(response, RESP_LEN);//reset the response
    sendCommandOnly(writeArray, 8);
    if(getResultOnly(response, RESP_LEN, m_timeOut) < 0)
    {
        setCommunicationStatus(COMMUNICATION_STATUS::DISCONNECT);
        throw IOException("TDTemp reading back times out");
    }
    else
    {
        unsigned char res[8];
        for(int i=0;i<8;i++)
        {
            res[i]=response[i];
            cout<<showbase<<uppercase<<hex<<(unsigned int)res[i]<<" ";
        }

        if(response[1]!=0x06)
        {
            setCommunicationStatus(COMMUNICATION_STATUS::DISCONNECT);
            throw IOException("receive  an invalid command ,make sure the current mode is manual");
        }

    }
    setCommunicationStatus(COMMUNICATION_STATUS::CONNECT);
    return true;
}

bool TDTempCtl::writeInt(int channelNum, int mode, const IntTypeInfo& typeinfo)
{
    if (isSimulated())
    {
        return true;
    }
    differTDTempDifferMachineCh(channelNum);

    int data=mode;
    short temp=(short)(data);
    writeArray[4]=(temp>>8)&0xff;
    writeArray[5]=temp&0xff;
    unsigned short t_crc = calculateCRC(writeArray,6);
    writeArray[6] = t_crc&0xff;
    writeArray[7] = t_crc>>8;

    unsigned char result[8];

    for(int i=0;i<8;i++)
    {
        result[i]=writeArray[i];
        cout<<showbase<<uppercase<<hex<<(unsigned int)result[i]<<" ";
    }

    char response[RESP_LEN];
    bzero(response, RESP_LEN);
    sendCommandOnly(writeArray, 8);
    if(getResultOnly(response, RESP_LEN, m_timeOut) < 0)
    {
        setCommunicationStatus(COMMUNICATION_STATUS::DISCONNECT);
        throw IOException("TDTemp reading back times out");
    }
    else
    {
        unsigned char res[8];
        for(int i=0;i<8;i++)
        {
            res[i]=response[i];
            cout<<showbase<<uppercase<<hex<<(unsigned int)res[i]<<" ";
        }

        if(response[1]!=0x06)
        {
            setCommunicationStatus(COMMUNICATION_STATUS::DISCONNECT);
            throw IOException("receive  an invalid command ,make sure the current mode is manual");
        }
    }
    setCommunicationStatus(COMMUNICATION_STATUS::CONNECT);
    return true;
}

bool TDTempCtl::readDouble(int channelNum,double * value ,const DoubleTypeInfo& typeinfo)
{
    if (isSimulated())
    {
        return true;
    }

    differTDTempDifferMachineCh(channelNum);

    unsigned short t_crc = calculateCRC(readArray,6);
    readArray[6] = t_crc&0xff;
    readArray[7] = (t_crc>>8)&0xff;

    for(int i=0;i<8;i++)
    {
        unsigned char sendomand[8];
        sendomand[i]=readArray[i];
    }
    char response[RESP_LEN];
    bzero(response, RESP_LEN);
    sendCommandOnly(readArray, 8);
    if(getResultOnly(response, RESP_LEN, m_timeOut) < 0)
    {
        setCommunicationStatus(COMMUNICATION_STATUS::DISCONNECT);
        throw IOException("WatLow reading back times out");
    }
    unsigned char res[7];
    for(int i=0;i<7;i++)
    {
        res[i]=response[i];
    }
    unsigned char result[2]={0};
    if(response[1]==0x03)
    {
         result[0]=(unsigned char)(response[3]&0x00ff);
         result[1]=(unsigned char)(response[4]&0x00ff);

        short dd=result[0]<<8|result[1];
        if(m_pHeatPowerPar.find(channelNum) != m_pHeatPowerPar.end())
        {
        	//added by guojin[20250515][1.4.0]for read current
        	double dPowerValue = 0.0;
        	double dHeatPower = 0.0;
        	double dCurrentValue = 0.0;
        	dPowerValue = calculateReadCarTemp(channelNum,(double)dd/10.0);
        	dHeatPower = m_pHeatPowerPar[channelNum];
        	dCurrentValue = (dPowerValue/100.0 )*dHeatPower/208.0;
        	*value = MathTool::Round(dCurrentValue,typeinfo.getAccuracy());
        }
        else
        {
        	*value = calculateReadCarTemp(channelNum,(double)dd/10.0);
        }
        setDoubleValue(channelNum + MONITORDOUBLEVALUEADDMAP, *value, typeinfo.getAccuracy());//added by mujy 20250602 for TempCtl Protect CIP
        setCommunicationStatus(COMMUNICATION_STATUS::CONNECT);
        return true;
    }
    else
    {
        setCommunicationStatus(COMMUNICATION_STATUS::DISCONNECT);
        throw IOException("TDTempDriver:the read data command is invalid");
    }
}

void TDTempCtl::initChs(DeviceNode<TDTempCtl> *node)
{
    //node->registerReadCh(0, &SerialDevice::connectStatus);
    for(int i=0;i<2;i++)
    {
        int checkChannel=i*80;
        for( int j=checkChannel+1; j<=checkChannel+32;j++)// 1~32, 81~112
        {
            node->registerWriteCh(j, &TDTempCtl::writeDouble);
        }

        for(int j=checkChannel+33 ; j<=checkChannel+48;j++)//33~48, 113~128
        {
            node->registerWriteCh(j, &TDTempCtl::writeInt);
        }

        for( int j= checkChannel +49 ;j<= checkChannel +80 ;j++)//49~80,129~160; valueChangeChannel 249~280, 329~360
        {
            node->registerReadCh(j, &TDTempCtl::readDouble);
            node->registerReadCh(j + MONITORDOUBLEVALUEADDMAP, &CMonitorDoubleValue::readDoubleChange);//added by mujy 20250602 for TempCtl Protect CIP
            initDoubleValue(j + MONITORDOUBLEVALUEADDMAP, -1);//added by mujy 20250602 for TempCtl Protect CIP
        }
        //added by taohao [1.1.65]
        for( int j= checkChannel + m_nCalibrationInitChannel + 49 ;j<= checkChannel + m_nCalibrationInitChannel + 80 ;j++)//849~880,929~960
        {
            node->registerReadCh(j, &TDTempCtl::readDouble);
        }
    }

    node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &TDTempCtl::getStatus);

}
void TDTempCtl::initDevice()
{
    //added by liuxj v1.8.26
    cout<<"Start Scan TempCtl...."<<endl;
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "TDTempCtl start");
    //say hello to tempctl
    double dTemp;
    try
    {
        readDouble(49,&dTemp,DoubleTypeInfo());
    }
    catch(exception &ex)
    {
        cout<<"Scan TempCtl failed. Communication abnormal!"<<endl;
        throw;
    }
    cout<<"Scan TempCtl Successfully...."<<endl;
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "TDTempCtl end");
}

double TDTempCtl::calculateReadCarTemp(int nChannelNum, double value)
{
    if(m_pCalibrationPar.find(nChannelNum)!=m_pCalibrationPar.end())
    {
        string cfgCalAPath =  m_pCalibrationPar[nChannelNum]->m_tempCalibrationA;
        string cfgCalBPath =  m_pCalibrationPar[nChannelNum]->m_tempCalibrationB;

        if((cfgCalAPath == "NULL") && (cfgCalBPath != "NULL"))
        {
            //ReadWriteDouble *cfgTempCalibrationA = (ReadWriteDouble*)(ObjectManager::getInstance()->getObject(cfgCalAPath));
            ReadWriteDouble *cfgTempCalibrationB = (ReadWriteDouble*)(ObjectManager::getInstance()->getObject(cfgCalBPath));


            double fReadValue = value-(cfgTempCalibrationB->getValue());
            return fReadValue;

        }
        else if((cfgCalBPath == "NULL") && (cfgCalAPath != "NULL"))
        {
            ReadWriteDouble *cfgTempCalibrationA = (ReadWriteDouble*)(ObjectManager::getInstance()->getObject(cfgCalAPath));
            //ReadWriteDouble *cfgTempCalibrationB = (ReadWriteDouble*)(ObjectManager::getInstance()->getObject(cfgCalBPath));


            double fReadValue = (cfgTempCalibrationA->getValue()*value);
            return fReadValue;
        }
        else if((cfgCalAPath != "NULL") && (cfgCalBPath != "NULL"))
        {
            ReadWriteDouble *cfgTempCalibrationA = (ReadWriteDouble*)(ObjectManager::getInstance()->getObject(cfgCalAPath));
            ReadWriteDouble *cfgTempCalibrationB = (ReadWriteDouble*)(ObjectManager::getInstance()->getObject(cfgCalBPath));


            double fReadValue = (cfgTempCalibrationA->getValue()*value)-(cfgTempCalibrationB->getValue());
            return fReadValue;

        }
    }
    else
    {
        return value;
    }

}

double TDTempCtl::calculateWriteCarTemp(int nChannelNum, double value)
{
    if(m_pCalibrationPar.find(nChannelNum)!=m_pCalibrationPar.end())
    {

        string cfgCalAPath =  m_pCalibrationPar[nChannelNum]->m_tempCalibrationA;
        string cfgCalBPath =  m_pCalibrationPar[nChannelNum]->m_tempCalibrationB;

        if((cfgCalAPath == "NULL") && (cfgCalBPath != "NULL"))
        {
            //ReadWriteDouble *cfgTempCalibrationA = (ReadWriteDouble*)(ObjectManager::getInstance()->getObject(cfgCalAPath));
            ReadWriteDouble *cfgTempCalibrationB = (ReadWriteDouble*)(ObjectManager::getInstance()->getObject(cfgCalBPath));

            //changesettemp = (float)((dValue+cfgST1TempCalibrationB->getValue())/cfgST1TempCalibrationA->getValue());
            double fWriteValue = value+(cfgTempCalibrationB->getValue());
            return fWriteValue;

        }
        else if((cfgCalBPath == "NULL") && (cfgCalAPath != "NULL"))
        {
            ReadWriteDouble *cfgTempCalibrationA = (ReadWriteDouble*)(ObjectManager::getInstance()->getObject(cfgCalAPath));
            //ReadWriteDouble *cfgTempCalibrationB = (ReadWriteDouble*)(ObjectManager::getInstance()->getObject(cfgCalBPath));

            //changesettemp = (float)((value+cfgTempCalibrationB->getValue())/cfgTempCalibrationA->getValue());
            double fWriteValue = (float)(value/cfgTempCalibrationA->getValue());
            return fWriteValue;
        }
        else if((cfgCalAPath != "NULL") && (cfgCalBPath != "NULL"))
        {
            ReadWriteDouble *cfgTempCalibrationA = (ReadWriteDouble*)(ObjectManager::getInstance()->getObject(cfgCalAPath));
            ReadWriteDouble *cfgTempCalibrationB = (ReadWriteDouble*)(ObjectManager::getInstance()->getObject(cfgCalBPath));

            //changesettemp = (float)((value+cfgTempCalibrationB->getValue())/cfgTempCalibrationA->getValue());
            double fWriteValue = (float)((value+cfgTempCalibrationB->getValue())/cfgTempCalibrationA->getValue());
            return fWriteValue;

        }

    }
    else
    {
        return value;
    }

}

void TDTempCtl::init()
{
//    cout<<getName()+"TDTempCtl init start"<<endl;
//    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "TDTempCtl start");

    DeviceNode<TDTempCtl> *node = new DeviceNode<TDTempCtl>(m_pollPeriod, this);
    DeviceManager::getInstance()->registerNode(m_nodeNum, node);
    if(!isSimulated())
    {
        initChs(node);
        initDevice();
    }

//    cout<<getName()+"TDTempCtl end start"<<endl;
//    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "TDTempCtl end");
}

void TDTempCtl::addCalibrationPar(int nChannelNum,std::string cfgtempCalibrationA, std::string cfgtempCalibrationB)
{
    CalibrationPar* pCalibrationPar=new CalibrationPar;
    //pCalibrationPar->m_nChannelNum=nChannelNum;
    pCalibrationPar->m_tempCalibrationA=cfgtempCalibrationA;
    pCalibrationPar->m_tempCalibrationB=cfgtempCalibrationB;

    m_pCalibrationPar[nChannelNum]=pCalibrationPar;
}

void TDTempCtl::setCalibrationInitChannel(int nChannelNum )//added by taohao [1.1.65]
{
    m_nCalibrationInitChannel = nChannelNum;
}

//added by guojin[20250515][1.4.0]for power
void TDTempCtl::addHeatPowerPar(int nChannelNum,double dPower)
{
   if(nChannelNum >= 65 && nChannelNum <= 67)
   {
	   m_pHeatPowerPar.insert(pair<int,double>(nChannelNum, dPower));
   }
   else
   {
     throw ConfigException("TDTempctl current channel number is out of range 65~67");
   }
}

IMPLEMENT_DYNAMIC(TDTempCtl, SerialDevice)

BEGIN_MSG_MAP(TDTempCtl, SerialDevice)
    SET_V( init, TDTempCtl)
    SET_ISS(addCalibrationPar, TDTempCtl)
    SET_I(setCalibrationInitChannel,TDTempCtl)//added by taohao [1.1.65]
	SET_ID(addHeatPowerPar, TDTempCtl )//added by guojin[20250515][1.4.0]
END_MSG_MAP
