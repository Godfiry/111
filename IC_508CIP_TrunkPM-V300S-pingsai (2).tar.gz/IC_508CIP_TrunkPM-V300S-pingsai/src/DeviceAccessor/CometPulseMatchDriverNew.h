/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: CometPulseMatchDriverNew.h
** Description: This driver is used for comet Pluse Match New version .
*                RS232 communication protocol 
* 				 Communication Type: ASCII Mode
* 				 BaudRate:19200
*                DataBit:8
* 				 StartBit:0
*                StopBit:1
*                Parity:no
*                          
** Release: 1.1
** Modification history: 
** 					
**      
*********************************************************************/
#ifndef COMETPULSEMATCHDRIVERNEW_H_
#define COMETPULSEMATCHDRIVERNEW_H_
#include "COMETMatchDriver.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#include "DescriptorList.h"
#include "StringTypeInfo.h"
#include <map>
#ifdef IAP4_0
using namespace IAP::IO;
#endif


class CometPulseMatchDriverNew :public COMETMatchDriver
{
	DECLARE_DYNAMIC(CometPulseMatchDriverNew)	
	DECLARE_MSG_MAP	
	
public:
	CometPulseMatchDriverNew();
	virtual ~CometPulseMatchDriverNew();
	
public://xml
	void init();	
	
public://read and write function 
	bool writeInt(int channelNum, int value, const IntTypeInfo &typeInfo);
	bool writeRawCommand(int channelNum, std::string value, const StringTypeInfo &typeInfo);
	bool readInt(int channelNum, int *value, const IntTypeInfo &typeInfo);
	bool readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo);
	bool readString(int channelNum, std::string *value, const StringTypeInfo &typeInfo);
	
protected:
	void initChs(DeviceNode<CometPulseMatchDriverNew> *node);
	void initDevice();	
	
private:
	typedef struct
	{
		int m_ps;
		std::string m_s1;
		int m_ps2;
	}Com;
		
	typedef std::pair<std::string,DescriptorList> ParamPair;
		
	static std::map<std::string,DescriptorList> m_params;
	static ParamPair m_paramPairs[];
	static Com m_commands[];	

};

#endif /*COMETPULSEMATCHDRIVERNEW_H_*/
