/********************************************************************
** Copyright (c) 2010, Beijing NMC Co.,Ltd.  product division.
** All rights reserved.
**
** File name: NonBlockingAlarmEX.h
**
** Description:
**
** Modification history:
* 							2016.11.10		lvjw	created.
*********************************************************************/
#ifndef NONBLOCKINGALARMEX_H_
#define NONBLOCKINGALARMEX_H_

#include "NonBlockingAlarm.h"
#include "CBase.h"
#ifdef IAP4_0
using namespace IAP::ALARM;
#endif

class NonBlockingAlarmEX:public NonBlockingAlarm,virtual public CBase
{
public:
	NonBlockingAlarmEX(const std::string &name, const std::string &message, 
								const std::string &description, Severity severity);
	
	virtual ~NonBlockingAlarmEX();
	
public:
	void setMessage(const std::string &s);
	void setDescription(const std::string &s);
	
	void setMessage(int nStringID);
	void setDescription(int nStringID);
	
};

#endif /*NONBLOCKINGALARMEX_H_*/
