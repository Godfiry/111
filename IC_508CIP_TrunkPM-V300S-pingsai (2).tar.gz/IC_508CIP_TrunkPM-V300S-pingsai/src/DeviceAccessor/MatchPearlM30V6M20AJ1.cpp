/********************************************************************
** Copyright (c) 2020, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MatchPearlM30V6M20AJ1.cpp
** Description:  
** Release: 1.0
** Modification history: 
**					2020-05-16   mayc create
*********************************************************************/
#include "MatchPearlM30V6M20AJ1.h"
#include "DeviceManager.h"

#include "Converter.h"
#include "StrTool.h"
#include "Hex.h"
#include "CheckCalculationTool.h"
#include <cctype>
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std; 

MatchPearlM30V6M20AJ1::Cmd MatchPearlM30V6M20AJ1::m_cmd[] = 
{
	{""},//reserved
	{":01106000000102",2},//1.1:Parallel Pre  0:Serial Pre
	{":01106000000102",3},//2.Reset all faults, 1:Fault Reset,0:Normal state
	{":01106000000102",4},//3.auto-tuning  0:disable(Manual) 1:enable(Auto)
	{":01106000000102",11},//4.1:Preset enable  0:Preset disable
	{":01106000000102",12},//5.Recall preset position
	{":01106001000102",0},//6.Set C1 position (0-11 bit) or VL1 position for 2M
	{":01106002000102",0},//7.Set C2 position (0-11 bit)
	{":01106003000102",0},//8.Store preset position
	{""},//9.reserved
	{""},//10.reserved
	{":010370000001",0x0001},//11.get status, bit 0 is RF off/on
	{":010370000001",0x0004},//12.get status, bit 2 is normal/fault
	{":010370000001",0x0008},//13.get status, bit 3 is manual/auto
	{":010370000001",0x0040},//14.get status, bit 6 is serial/parallel
	{":010370000001",0x0800},//15.get status, bit 11 is preset disable/enable
	{":010370000001",0x1000},//16, get status, bit 12 is preset channel
	{":010370010001",0x0FFF},//17.get c1 position or VL1 position for 2M
	{":010370020001",0x0FFF},//18.get c2 position
	{""},//19.reserved
	{""},//20.reserved
	{":010370060001",0x0FFF},//21.get DCBias
};

MatchPearlM30V6M20AJ1::MatchPearlM30V6M20AJ1():SerialDevice(200, "\x0D\x0A")
{
	m_timeOut = 50;//5s
	m_pollPeriod = 200; //200ms
	m_nFullScale = 3916;//0%~0x0040  100%~0x0F8C         0x0F8C - 0x0040
	m_nPreC1 = 0;
	m_nPreC2 = 0;
	m_b2MFlag = false;
}

MatchPearlM30V6M20AJ1::~MatchPearlM30V6M20AJ1()
{
}

string MatchPearlM30V6M20AJ1::sendCommandAndReadResponse(string &strCommond, int nTimeOut)
{
	string strResponse = getCommandResult(strCommond, nTimeOut);
	if(strResponse.find("\x0D\x0A",0) == string::npos)
	{
		throw IOException("Match send command ["+strCommond+"] occurred error [" + strResponse+"]");
	}
	size_t nPos = 0;  //changed by wzd 1.1.39
	string strCommondHead = strCommond.substr(0,5);
	if(strResponse.find(strCommondHead,0) != string::npos)
	{
		return strResponse;
	}
	else if((nPos = strResponse.find(":0190",0)) != string::npos || (nPos = strResponse.find(":0183",0)) != string::npos)
	{
		cout << "MatchPearlM30V6M20AJ1::sendCommandAndReadResponse error response is" << strResponse << endl;
		string strErrorCode;
		if (strResponse.size() > nPos+5)
		{
			strErrorCode = strResponse.substr(nPos+5, 2);
		}
		else
		{
			throw IOException("strResponse size:" + Converter::convertToString(strResponse.size())
			 + " is not bigger than " + Converter::convertToString(nPos+5));
		}

		throw IOException("Match send command ["+strCommond+"] occurred error, error code is [" + strErrorCode+"]");
	}
	else
	{
		throw IOException("Match send command ["+strCommond+"] failed for unknown response [" + strResponse+"]");
	}
}

int MatchPearlM30V6M20AJ1::readAddress6000(int nTimeOut)
{
	string strCommand = ":0103600000019B";

	string strResponse = sendCommandAndReadResponse(strCommand, nTimeOut);
	cout<<strResponse<<endl;
	size_t nPos = strResponse.find(":");  //changed by wzd 1.1.39
	int nValueInAddress6000 = 0;
	
	string strSplitValue;
	if (strResponse.size() > nPos+5)
	{
		strSplitValue = strResponse.substr(nPos+7,4);
	}
	else
	{
		throw IOException("strResponse size:" + Converter::convertToString(strResponse.size())
		 + " is not bigger than " + Converter::convertToString(nPos+7));
	}
	 
	if(!Hex::stringToHex(&nValueInAddress6000, strSplitValue))
	{
		cout<<"response "<<strSplitValue <<" invalid."<<endl;
		throw IOException(strSplitValue + " is invalid.");
	}
	if(nValueInAddress6000 & 0x0008)
	{
		cout<<"In write register 0x6000, Reset is On"<<endl;
	}
	else
	{
		cout<<"In write register 0x6000, Reset is Off"<<endl;
	}
	//
	if(nValueInAddress6000 & 0x0010)
	{
		cout<<"In write register 0x6000, Auto-tuning is enable"<<endl;
	}
	else
	{
		cout<<"In write register 0x6000, Auto-tuning is disable"<<endl;
	}

	return nValueInAddress6000;
}
	
bool MatchPearlM30V6M20AJ1::readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
	Cmd cmd = m_cmd[nChannelNum];
	string strCommand = cmd.m_strCmd + CheckCalculationTool::GetLRCCode(cmd.m_strCmd);
	strCommand = StrTool::toUpper(strCommand);
	string strResponse = sendCommandAndReadResponse(strCommand, m_timeOut);
	size_t nPos = strResponse.find(":");  //changed by wzd 1.1.39
	string strSplitValue;
	if (strResponse.size() > nPos+7)
	{
		strSplitValue = strResponse.substr(nPos+7, 4);
	}
	else
	{
		throw IOException("strResponse size:" + Converter::convertToString(strResponse.size())
		 + " is not bigger than " + Converter::convertToString(nPos+7));
	}

	int nValue = 0;
	if(!Hex::stringToHex(&nValue, strSplitValue))
	{
		throw IOException("Match read status failed for can't convert response ["+strSplitValue+"] to integer value.");
	}
	else
	{
		// get C1, C2
		if (nChannelNum == 17 || nChannelNum == 18)
		{
			if( m_b2MFlag && nChannelNum == 17)
			{
				*pValue = ((nValue & cmd.m_nDeal) - 64) * typeInfo.getMax() / 204; //0x010C-0x0040 = 204
			}
			else
			{
				*pValue = ((nValue & cmd.m_nDeal) - 64) * typeInfo.getMax() / m_nFullScale; //64~0x0040
			}
			//*pValue = nValue & cmd.m_nDeal;
		}
		else
		{
			*pValue = (nValue & cmd.m_nDeal) != 0;
		}
		switch(nChannelNum)
		{
			case 11:
			case 12:
			case 13:
			case 14:
			case 15:
			case 16:
				if(*pValue == 1)
				{
					SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "MatchPearlM30V6M20AJ1: channel ["+Converter::convertToString(nChannelNum)+"] read back = "+strResponse +" ;split value = "+strSplitValue);
				}
				break;
			default:
				break;
		}
		return true;
	}	
}

bool MatchPearlM30V6M20AJ1::readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo)
{
	Cmd cmd = m_cmd[nChannelNum];
	string strCommand = cmd.m_strCmd + CheckCalculationTool::GetLRCCode(cmd.m_strCmd);
	strCommand = StrTool::toUpper(strCommand);
	string strResponse = sendCommandAndReadResponse(strCommand, m_timeOut);
	size_t nPos = strResponse.find(":");  //changed by wzd 1.1.39
	string strSplitValue;
	
	if (strResponse.size() > nPos+7)
	{
		strSplitValue = strResponse.substr(nPos+7, 4);
	}
	else
	{
		throw IOException("strResponse size:" + Converter::convertToString(strResponse.size())
		 + " is not bigger than " + Converter::convertToString(nPos+7));
	}
	
	int nValue = 0;

	if(!Hex::stringToHex(&nValue, strSplitValue))
	{
		throw IOException("Generator read VDC failed for can't convert response ["+strSplitValue+"] to integer value.");
	}
	else
	{
		//*pValue = (double)(nValue & cmd.m_nDeal) * typeInfo.getMax() / m_nFullScale;
		*pValue = (double)(nValue & cmd.m_nDeal);
		return true;
	}
}
		
bool MatchPearlM30V6M20AJ1::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
	string strCommand = "";
	string strData = "";
	if(nChannelNum >= 1 && nChannelNum <= 5) //6000 Control register
	{
		int nTempAddress0000 = readAddress6000(m_timeOut);
	
		unsigned int bitmask = 1;
		bitmask = bitmask << m_cmd[nChannelNum].m_nDeal;
		

		if(nValue == 1)
		{
			nTempAddress0000 = nTempAddress0000 | bitmask;
		}
		else
		{
			bitmask = ~bitmask;
			nTempAddress0000 = nTempAddress0000 & bitmask;
		}
		strData = Hex::hexToString(nTempAddress0000,4);
	}
	else if(nChannelNum == 6 || nChannelNum == 7) // setC1, setC2
	{
		if( m_b2MFlag && nChannelNum == 6)
		{
			nValue = (int)(nValue * ((double) 204 / typeInfo.getMax()) + 64);//0x010C-0x0040
		}
		else
		{
			nValue = (int)(nValue * ((double) m_nFullScale / typeInfo.getMax()) + 64);//64~0x0040
		}
		int iData = nValue & 0x0FFF;
		if(nChannelNum == 6)
			m_nPreC1 = iData;
		else
			m_nPreC2 = iData;
		strData = Hex::hexToString(iData,4);
	}
	else if(nChannelNum == 8)// store preset c1, c2
	{
		if(nValue == 0) // preset 0 position
		{
			strData = Hex::hexToString(m_nPreC1,4);
			strCommand = ":01106003000102" + strData;
			strCommand += CheckCalculationTool::GetLRCCode(strCommand);
			strCommand = StrTool::toUpper(strCommand);
			cout << "MatchPearlM30V6M20AJ1::writeInt strCommand=" << strCommand << endl;
			sendCommandAndReadResponse(strCommand,m_timeOut);
	
			strData = Hex::hexToString(m_nPreC2,4);
			strCommand = ":01106004000102" + strData;
			strCommand += CheckCalculationTool::GetLRCCode(strCommand);
			strCommand = StrTool::toUpper(strCommand);
			cout << "MatchPearlM30V6M20AJ1::writeInt strCommand=" << strCommand << endl;
			sendCommandAndReadResponse(strCommand,m_timeOut);
		}
		else // preset 1 position
		{
			strData = Hex::hexToString(m_nPreC1,4);
			strCommand = ":01106005000102" + strData;
			strCommand += CheckCalculationTool::GetLRCCode(strCommand);
			strCommand = StrTool::toUpper(strCommand);
			cout << "MatchPearlM30V6M20AJ1::writeInt strCommand=" << strCommand << endl;
			sendCommandAndReadResponse(strCommand,m_timeOut);
	
			strData = Hex::hexToString(m_nPreC2,4);
			strCommand = ":01106006000102" + strData;
			strCommand += CheckCalculationTool::GetLRCCode(strCommand);
			strCommand = StrTool::toUpper(strCommand);
			cout << "MatchPearlM30V6M20AJ1::writeInt strCommand=" << strCommand << endl;
			sendCommandAndReadResponse(strCommand,m_timeOut);
		}	
		
		return true;
	}
	
	strCommand = m_cmd[nChannelNum].m_strCmd + strData;
	strCommand += CheckCalculationTool::GetLRCCode(strCommand);
	strCommand = StrTool::toUpper(strCommand);
	cout << "MatchPearlM30V6M20AJ1::writeInt strCommand=" << strCommand << endl;
	sendCommandAndReadResponse(strCommand,m_timeOut);
	if (nChannelNum == 3) // if set manual, also need set preset disable
	{
		int nTempAddress0000 = readAddress6000(m_timeOut);
		if(nValue == 0)
		{
			unsigned int bitmask = 1;
			bitmask = bitmask << m_cmd[4].m_nDeal;
			bitmask = ~bitmask;
			nTempAddress0000 = nTempAddress0000 & bitmask;
			strData = Hex::hexToString(nTempAddress0000,4);
			strCommand = m_cmd[4].m_strCmd + strData;
			strCommand += CheckCalculationTool::GetLRCCode(strCommand);
			strCommand = StrTool::toUpper(strCommand);
			cout << "MatchPearlM30V6M20AJ1::writeInt strCommand=" << strCommand << endl;
			sendCommandAndReadResponse(strCommand,m_timeOut);
		}
	}
	if (nChannelNum == 5) // if recall preset, also set preset enable
	{
		int nTempAddress0000 = readAddress6000(m_timeOut);
		unsigned int bitmask = 1;
		bitmask = bitmask << m_cmd[4].m_nDeal;
		nTempAddress0000 = nTempAddress0000 | bitmask;
		strData = Hex::hexToString(nTempAddress0000,4);
		strCommand = m_cmd[4].m_strCmd + strData;
		strCommand += CheckCalculationTool::GetLRCCode(strCommand);
		strCommand = StrTool::toUpper(strCommand);
		cout << "MatchPearlM30V6M20AJ1::writeInt strCommand=" << strCommand << endl;
		sendCommandAndReadResponse(strCommand,m_timeOut);
	}
	//m_nAddress0000 = nTempAddress0000;
	return true;
}

void MatchPearlM30V6M20AJ1::initChs(DeviceNode<MatchPearlM30V6M20AJ1> *pNode)
{
	for(int i = 1; i<=10; ++i)
	{
		pNode->registerWriteCh(i, &MatchPearlM30V6M20AJ1::writeInt);
	}

	for(int i = 11; i<=20; ++i)
	{
		pNode->registerReadCh(i, &MatchPearlM30V6M20AJ1::readInt);
	}
	
	pNode->registerReadCh(21, &MatchPearlM30V6M20AJ1::readDouble);
	
	pNode->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &MatchPearlM30V6M20AJ1::getStatus);
}

void MatchPearlM30V6M20AJ1::initDevice()
{
	cout<<"Start Scan pearl match...."<<endl;
	//say hello to Match
	try
	{
		readAddress6000(m_timeOut);
		//set serial control
		writeInt(1, 0, IntTypeInfo());
	}
	catch(exception &ex)
	{
		cout<<"Scan pearl match failed. Communication abnormal!"<<endl;
		throw;
	}
	cout<<"Scan pearl match Successfully...."<<endl;
}

void MatchPearlM30V6M20AJ1::init()
{
	DeviceNode<MatchPearlM30V6M20AJ1> *pNode = new DeviceNode<MatchPearlM30V6M20AJ1>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
	if(!isSimulated())
	{
		initChs(pNode);
		initDevice();
	}	
}

void MatchPearlM30V6M20AJ1::set2MFlag(bool flag)
{
	m_b2MFlag = flag;
}

IMPLEMENT_DYNAMIC(MatchPearlM30V6M20AJ1, SerialDevice )

BEGIN_MSG_MAP(MatchPearlM30V6M20AJ1, SerialDevice )
	SET_V( init, MatchPearlM30V6M20AJ1 )
	SET_B( set2MFlag, MatchPearlM30V6M20AJ1 )
END_MSG_MAP
