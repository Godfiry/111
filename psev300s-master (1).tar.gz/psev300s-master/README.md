# PSEV300S待办事项 

## 配置相关 

- [ ] 信号表梳理完成，待射频确认新增通道是都使用，工艺相关射频参数 别名已确定

- [ ] 逐个梳理功能层所使用IO通道是否符合原有功能

  > 1. ![image-20260701160040598](README.assets/image-20260701160040598.png)
  >
  > GasSource.xml
  >
  > GaugeSource.xml 
  >
  > 后续需单独复核。

- [ ] 摆阀读字节

- [ ] SDO 读字节驱动

- [x] he阀相关 文件

- [ ] v4阀 和原有逻辑不一样 ，暂时注释v4相关互锁

- [ ] tempctl 232/484 的通道  需要根据实际硬件配置

- [x] 分子泵 相关信号 待复核 更换品牌 VacuumValueIntlk.xml互锁不一致 

- [x] 互锁和setup配置完成





## 特殊通道记录 

```xml
<PrimaryPurgeByPassDO dataType="I" accessMode="RW" alias="/Control/PMCExports/Datas/PrimaryPurgeByPassDO">
      <Bd>1</Bd>
      <Ch>15309</Ch>
      <DescriptorList>NO,Bypass</DescriptorList>
    &KylandShmSimulated;
</PrimaryPurgeByPassDO>
	
<DPControlDO dataType="I" accessMode="RW" alias="/Control/PMCExports/Datas/DPControlDO">
      <Bd></Bd>
      <Ch></Ch>
      <DescriptorList>Local,Remote</DescriptorList>
    &SetNotSimulated;
</DPControlDO>

  
  
  
```





1. 控制drypump

    

   ![image-20260701163323006](README.assets/image-20260701163323006.png)

   

   ![37a9e5e9438e9ed9857204cc36d373f9.png](file:///C:/Users/pingsai/.config/joplin-desktop/resources/876da7cb1aad47808a862b6abb9d8d76.png?t=1782892253315)







2. ESC  PinDownDO    EPRUpDO  是逻辑通道   

```xml
<PINUP_DO dataType="I" accessMode="RW" alias="/Control/PMCExports/Datas/PinUpDO">
      <Bd>1</Bd>
      <Ch>18216</Ch>
      <DescriptorList>Close,Open</DescriptorList>
    &KylandShmSimulated;
    </PINUP_DO>
	
<PinDownDO dataType="I" accessMode="RW" alias="/Control/PMCExports/InnerDatas/PinDownDO">
      <Bd></Bd>
      <Ch></Ch>
      <DescriptorList>No,Down</DescriptorList>
    &SetNotSimulated;
    </PinDownDO>
    
<EPRUpDO dataType="I" accessMode="RW" alias="/Control/PMCExports/InnerDatas/EPRUpDO">
      <Bd></Bd>
      <Ch></Ch>
      <DescriptorList>No,Up</DescriptorList>
    &SetNotSimulated;
    </EPRUpDO>
  </DigitalOutput_LowElectrodeControlESCSystem>
```

3. 缺少 这个通道   需要SDO配置 

4. ![image-20260702112715984](README.assets/image-20260702112715984.png)

5. SRFOverheatDI 目前配置也存在问题 需要从 SDO里配置

6. ![image-20260702112807327](README.assets/image-20260702112807327.png)

7. 

8.  LFOverheatDI  目前配置也存在问题 需要从 SDO里配置 

9. 

10. 摆阀 增加以下逻辑通道 

11. ```xml
     <PendulumValve_ZeroTargetPressure dataType="D" accessMode="RW" alias="/Control/PMCExports/Datas/PV_ZeroTargetPressureAO">
          <Bd>1</Bd>
          <Ch>27703</Ch>
          <Min>0</Min>
          <Max>10000</Max>
          <Accuracy>1</Accuracy>
          <Unit>mtorr</Unit>
        &KylandShmSimulated;
        </PendulumValve_ZeroTargetPressure>
    
    	<PendulumValve_LocalRemoteRCh dataType="I" accessMode="R" alias="/Control/PMCExports/InnerDatas/PendulumValve_LocalRemoteRCh">
          <Bd></Bd>
          <Ch></Ch>
          <DescriptorList>Local,Remote,Remote_Locked</DescriptorList>
        &KylandShmSimulated;
        </PendulumValve_LocalRemoteRCh>
    
        <PendulumValveStatusDI dataType="I" accessMode="R" alias="/Control/PMCExports/InnerDatas/PendulumValveStatusDI">
          <Bd></Bd>
          <Ch></Ch>
          <DescriptorList></DescriptorList>
        &KylandShmSimulated;
        </PendulumValveStatusDI>
    
    <PendulumValve_LearnSP dataType="D" accessMode="RW" alias="/Control/PMCExports/Datas/PendulumValve_LearnSP">
          <Bd></Bd>
          <Ch></Ch>
          <Min>0</Min>
          <Max>1000</Max>
          <Accuracy>1</Accuracy>
        &SetNotSimulated;
        </PendulumValve_LearnSP>
    ```

    ![image-20260703102744658](README.assets/image-20260703102744658.png)

12. 分子泵  信号变化

13. ![image-20260703211330581](README.assets/image-20260703211330581.png)  

```xml
  <TurboPump>
	<TMPInterlockBypassDO dataType="I" accessMode="RW" alias="/Control/PMCExports/Datas/TMPInterlockBypassDO">
      <Bd>1</Bd>
      <Ch>15306</Ch>
      <DescriptorList>NO,Bypass</DescriptorList>
    &KylandShmSimulated;
    </TMPInterlockBypassDO>
    <TMPStopDO dataType="I" accessMode="RW" alias="/Control/PMCExports/Datas/TMPStopDO">
      <Bd>1</Bd>
      <Ch>15005</Ch>
      <DescriptorList>Stop,Start</DescriptorList>
    &KylandShmSimulated;
    </TMPStopDO>
    <TMPInhibitDO dataType="I" accessMode="RW" alias="/Control/PMCExports/Datas/TMPInhibitDO">
      <Bd>1</Bd>
      <Ch>15006</Ch>
      <DescriptorList>Normal,Inhibit</DescriptorList>
    &KylandShmSimulated;
    </TMPInhibitDO>
    <TMPStartDO dataType="I" accessMode="RW" alias="/Control/PMCExports/Datas/TMPStartDO">
      <Bd>1</Bd>
      <Ch>15007</Ch>
      <DescriptorList>Stop,Start</DescriptorList>
    &KylandShmSimulated;
    </TMPStartDO>
    <TMPWaterLeakSWDI dataType="I" accessMode="R" alias="/Control/PMCExports/Datas/TMPWaterLeakSWDI">
      <Bd>1</Bd>
      <Ch>2013</Ch>
      <DescriptorList>Abnormal,Normal</DescriptorList>
    &KylandShmSimulated;
    </TMPWaterLeakSWDI>
	<TMPResetDO dataType="I" accessMode="RW" alias="/Control/PMCExports/Datas/TMPResetDO">
      <Bd>1</Bd>
      <Ch>15017</Ch>
      <DescriptorList>NotReset,Reset</DescriptorList>
    &KylandShmSimulated;
    </TMPResetDO>
    <TMPOPTDO dataType="I" accessMode="RW" alias="/Control/PMCExports/Datas/TMPOPTDO">
      <Bd>1</Bd>
      <Ch>15018</Ch>
      <DescriptorList>Off,On</DescriptorList>
    &KylandShmSimulated;
    </TMPOPTDO>
    <TMPAcceleratingDI dataType="I" accessMode="R" alias="/Control/PMCExports/Datas/TMPAcceleratingDI">
      <Bd>1</Bd>
      <Ch>12</Ch>
      <DescriptorList>NO,Accelerating</DescriptorList>
    &KylandShmSimulated;
    </TMPAcceleratingDI>
    <TMPFaultDI dataType="I" accessMode="R" alias="/Control/PMCExports/Datas/TMPAlarmDI">
      <Bd>1</Bd>
      <Ch>13</Ch>
      <DescriptorList>Normal,Fault</DescriptorList>
    &KylandShmSimulated;
    </TMPFaultDI>
    <TMPBrakingDI dataType="I" accessMode="R" alias="/Control/PMCExports/Datas/TMPBrakingDI">
      <Bd>1</Bd>
      <Ch>14</Ch>
      <DescriptorList>NO,Braking</DescriptorList>
    &KylandShmSimulated;
    </TMPBrakingDI>
    <TMPRemoteDI dataType="I" accessMode="R" alias="/Control/PMCExports/Datas/TMPRemoteDI">
      <Bd>1</Bd>
      <Ch>15</Ch>
      <DescriptorList>Local,Remote</DescriptorList>
    &KylandShmSimulated;
    </TMPRemoteDI>
    <TMPTempWarningDI dataType="I" accessMode="R" alias="/Control/PMCExports/Datas/TMPTempWarningDI">
      <Bd>1</Bd>
      <Ch>16</Ch>
      <DescriptorList>Abnormal,Normal</DescriptorList>
    &KylandShmSimulated;
    </TMPTempWarningDI>
    <TMPOPDI_TMPStartDI dataType="I" accessMode="R" alias="/Control/PMCExports/Datas/TMPRotationDI">
      <Bd>1</Bd>
      <Ch>27</Ch>
      <DescriptorList>NO,Start</DescriptorList>
    &KylandShmSimulated;
    </TMPOPDI_TMPStartDI>
    <TMPWarningDI_TMPAtSpdDI dataType="I" accessMode="R" alias="/Control/PMCExports/Datas/TMPWarningDI">
      <Bd>1</Bd>
      <Ch>28</Ch>
      <DescriptorList>Normal,Alarm</DescriptorList>
    &KylandShmSimulated;
    </TMPWarningDI_TMPAtSpdDI>
    <TMPNormalDI_TMPAtSpeedDI dataType="I" accessMode="R" alias="/Control/PMCExports/Datas/TMPAtSpeedDI">
      <Bd>1</Bd>
      <Ch>29</Ch>
      <DescriptorList>NO,Reached</DescriptorList>
    &KylandShmSimulated;
    </TMPNormalDI_TMPAtSpeedDI>
  </TurboPump>
```

![image-20260703151208137](README.assets/image-20260703151208137.png)