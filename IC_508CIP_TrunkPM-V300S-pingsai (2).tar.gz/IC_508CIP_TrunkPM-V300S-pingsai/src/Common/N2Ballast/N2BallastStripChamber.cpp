/*
 * N2BallastStripChamber.cpp
 *
 *  Created on: 2022-10-03
 *      Author: liusiyuan
 */

#include "N2BallastStripChamber.h"
#include "BFVlvController.h"
#include "BufferFlyValve.h"
#include "PendulumGasRecipe.h"
#include "GasRecipe.h"
#include "SysLogger.h"
#include "ObjectManager.h"
#include "ConfigException.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "RetryException.h"
#include "InvalidNameException.h"
#endif

#include "TransferOperationInfo.h"
#include "ValveController.h"
#include "GasSource.h"
#include "Gasses.h"
//#include "PendulumController.h"
#include "XmlGetter.h"
#include "ReadWriteInt.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
using namespace IAP::IO;
#endif


N2BallastStripChamber::N2BallastStripChamber() {
    // TODO Auto-generated constructor stub

}

N2BallastStripChamber::~N2BallastStripChamber() {
    // TODO Auto-generated destructor stub
}

void N2BallastStripChamber::doPostExecuteRecipe(GassesToFlow *pGassesToFlow)//added by liusy[1.1.43]
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": about to do PostExecuteRecipe");
    try
    {
        for(int i = 0; i < m_pProcessGasIDs->getSize(); ++i)
        {
            if(m_pProcessGasIDs->getGasID(i) == "PendulumValve")
            {
                continue;
            }
            else
            {
                pGassesToFlow->getRecipeForGasAtIndex(i)->setGasFlowRate(0);
            }
        }
        m_pPressureController->beginToFlowGassesWith(pGassesToFlow);
        ((BufferFlyValve*)(m_pPressureController->getGasSource()->getTheGasses()->getGasValveForGasID("PendulumValve")))->getPendulumController()->do_SetPosition(1000);

        if(m_pPressureController->hasSequence("OpenValvesAfterProcessAndWACBeforeN2Ballast"))
        {
            m_pPressureController->call_RunSequence("OpenValvesAfterProcessAndWACBeforeN2Ballast");
        }


        if(m_pRecipeBody == NULL)//added by liusy[1.1.43]
        {
            usleep((long)(getN2BallastPumpTimeAfterProcess() * 1000000));
        }
        else if(m_pRecipeBody->getRcpClass() == "/DryClean")//added by liusy[1.1.43]
        {
            usleep((long)(getN2BallastPumpTimeAfterWAC() * 1000000));
        }
        else
        {
            usleep((long)(getN2BallastPumpTimeAfterProcess()* 1000000));
        }

        m_pPressureController->call_RunSequence("N2Ballast");
    }
    catch(const RetryException &ex)
    {
        throw;
    }
    catch(const exception &ex)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": PostExecuteRecipe failed for "+ ex.what());
        throw;
    }
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": done PostExecuteRecipe");
}

void N2BallastStripChamber::doPreExecuteRecipe()//added by liusy[1.1.43]
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": about to do PreExecuteRecipe");
    try
    {

        if(m_pInnerDoor != NULL)
                m_pInnerDoor->call_Close();

        m_pPressureController->call_RunSequence("StopN2Ballast");

        ((BufferFlyValve*)(m_pPressureController->getGasSource()->getTheGasses()->getGasValveForGasID("PendulumValve")))->getPendulumController()->do_SetPosition(1000);

        if(m_pRecipeBody == NULL)//added by liusy[1.1.43]
        {
            usleep((long)(getN2BallastPumpTimeBeforeProcess() * 1000000));
        }
        else if(m_pRecipeBody->getRcpClass() == "/DryClean")//added by liusy[1.1.43]
        {
            usleep((long)(getN2BallastPumpTimeBeforeWAC() * 1000000));
        }
        else
        {
            usleep((long)(getN2BallastPumpTimeBeforeProcess() * 1000000));
        }
    }
    catch(const RetryException &ex)
    {
        throw;
    }
    catch(const exception &ex)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": PreExecuteRecipe failed for "+ ex.what());
        throw;
    }
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": done PreExecuteRecipe");
}

void N2BallastStripChamber::doCompleteTransferMaterial(int status, int slot)
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": about to do CompleteTransferMaterial");

    try
    {
        if(m_pInnerDoor != NULL)
        {
            m_pInnerDoor->call_Close();
        }

        if(status==TransferOperationInfo::Receive)
        {
            //checkSlotValveClosed();//20180825lijj
            m_pPressureController->call_RunSequence("StopN2Ballast");

            if(m_pRecipeBody == NULL || m_pRecipeBody->getRcpClass() == "/Process")//added by liusy[1.1.43]
            {
                usleep(getN2BallastPumpOutBeforePinDown());
            }
            else
            {
                usleep(1000*m_nWACTimeMsBeforePinDown);
            }
        }
        else
        {
            ReadWriteDouble* m_cfgChamberBallastPressure = (ReadWriteDouble*)ObjectManager::getInstance()->getObject("/SETUP/Vacuum/cfgChamberBallastPressure");
            if(NULL != m_cfgChamberBallastPressure)
            {
                ((BufferFlyValve*)(m_pPressureController->getGasSource()->getTheGasses()->getGasValveForGasID("PendulumValve")))->getPendulumController()->do_SetPressure(m_cfgChamberBallastPressure->getValue());
                //((PendulumValve*)(m_pPressureController->getGasSource()->getTheGasses()->getGasValveForGasID("PendulumValve")))->getPendulumController()->do_SetPressure(m_cfgChamberBallastPressure->getValue());
            }
        }

    }
    catch(const exception &ex)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": CompleteTransferMaterial failed for "+ ex.what());
        throw;
    }

    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": done CompleteTransferMaterial");
}

IMPLEMENT_DYNAMIC(N2BallastStripChamber, N2BallastChamber)

BEGIN_MSG_MAP( N2BallastStripChamber, N2BallastChamber)
END_MSG_MAP
