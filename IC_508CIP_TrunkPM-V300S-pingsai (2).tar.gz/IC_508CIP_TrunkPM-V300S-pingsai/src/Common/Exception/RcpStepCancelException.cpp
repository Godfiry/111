/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: RcpStepCancelException.cpp
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-09-2  LiJuanjuan create
**      
*********************************************************************/
#include "RcpStepCancelException.h"

RcpStepCancelException::RcpStepCancelException(const std::string &s):TMCException(s)
{
}
