/********************************************************************
** Copyright (c) 2019 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: PLCDevice.h
** Description:  
** Release: 1.0
** Modification history:           
** 					2019-06-05   Duq create
**                                                 2020-06-03   Duq update
*********************************************************************/

#ifndef PLCDEVICE_H_
#define PLCDEVICE_H_

#include "AbstractDevice.h"
#include "IntTypeInfo.h"
#include "DoubleTypeInfo.h"
#include "EIPApplication.h"
#include "DeviceNode.h"
#include "DeviceManager.h"
#include "ConfigException.h"
#include <map>
#include "ObjectManager.h"
#include "ReadWriteDouble.h"
#include <fstream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
#endif


class PLCDevice:public AbstractDevice
{
	DECLARE_DYNAMIC(PLCDevice)
	DECLARE_MSG_MAP	
	
	protected:
		typedef struct _AIAOInfo
		{
			int channelNum;
			std::string type;
			std::string mode;
			int startAddr;
			int addrLength;
			double min;
			double max;
			double maxBinaryValue;
			bool offsetFlag;
			double offset1;
			double offset2;
		}AIAOInfo;
		std::map<int,AIAOInfo> m_mapAIAOInfo;
		typedef std::map<int,AIAOInfo>::iterator miter;
		bool m_result;
		std::string m_plcname;
        std::map<int,double> m_mapPTmin;
        std::map<int,double> m_mapPTmax;
		std::map<int,double>::iterator m_PT;
		
	protected:
		int m_nodeNum;	
		int m_DIStartCh;
		int m_DIStartAd;
		int m_DIChsSize;
		int m_DOStartCh;
		int m_DOStartAd;
		int m_DOChsSize;
		int m_pollInterval;
		int m_StatusWordSize;
		int m_IntlkDIStartCh;
		int m_IntlkDIStartAd;
		int m_IntlkDIChsSize;
		int m_IntlkDOStartCh;
		int m_IntlkDOStartAd;
		int m_IntlkDOChsSize;
		int m_DevNetDIStartCh1;
		int m_DevNetDIStartAd1;
		int m_DevNetDIChsSize1;
		
		int m_DevNetDIStartCh2;
		int m_DevNetDIStartAd2;
		int m_DevNetDIChsSize2;

		int m_DevNetDOStartCh;
		int m_DevNetDOStartAd;
		int m_DevNetDOChsSize;
		int m_MFCOnlineStartCh;
		int m_MFCOnlineStartAd;
		int m_MFCOnlineChsSize;
		double setdometemp1;
		double setdometemp2;
		double modifydometemp1;
		double modifydometemp2;
		double A1;
		double A2;
		double B1;
		double B2;
	
		std::string m_server;//192.168.250.x
		uint16_t m_inputInstanceId;
		uint16_t m_outputInstanceId;
		uint16_t m_configInstanceId;
		unsigned int m_cycleTime;
		EIPApplication *m_eip;
		std::string m_moduleName;
	public:
		
		PLCDevice();
		virtual ~PLCDevice();
		
		//configurate EIP
		void setServer(const std::string &server);
		void setConfigInputOutputInstanceID(int ConfigIid, int InputIid, int OutputIid);
		void setConnectionCycleTime(int cycleTime);
		void setStatusWord(bool flag);
		void setModuleName(const std::string& name);
		
		//configurate IAP IO
		void setPLCDeviceName(std::string name);
		void setPollIntervalMillSec(int ms);	
		void setNodeNum(int nodeNum);
		void setDIChsSize(int startCh, int startAd, int num);
		void setDOChsSize(int startCh, int startAd, int num);
		void setSpecialAIAOInfo(int channelNum, std::string info);
		void setIntlkDIChsSize(int startCh, int startAd, int num);
		void setIntlkDOChsSize(int startCh, int startAd, int num);

		void setDevNetDIChsSize1(int startCh, int startAd, int num);
		void setDevNetDIChsSize2(int startCh, int startAd, int num);

		void setDevNetDOChsSize(int startCh, int startAd, int num);
		void setMFCOnlineChsSize(int startCh, int startAd, int num);
		
		bool readBit(int channelNum, int *bit, const IntTypeInfo &typeInfo);//read DI
		bool writeBit(int channelNum, int bit, const IntTypeInfo &typeInfo);//write DO
		bool readIntAI(int channelNum, int *value, const IntTypeInfo &typeInfo);//read int AI
		bool writeIntAO(int channelNum, int value, const IntTypeInfo &typeInfo);//write int AO
		bool readDoubleAI(int channelNum, double *value, const DoubleTypeInfo &typeInfo);//read double AI
		bool writeDoubleAO(int channelNum, double value, const DoubleTypeInfo &typeInfo);//write double AO
		bool readDoubleAIWithOffSet(int channelNum, double *value, const DoubleTypeInfo &typeInfo);//read double AI with OffSet
		bool readDomeTempAI(int channelNum, double *value, const DoubleTypeInfo &typeInfo);//read double DomeTemp AI 
		bool writeDomeTempAO(int channelNum, double value, const DoubleTypeInfo &typeInfo);//write double DomeTemp AO 
		
		void setDoubleOffSetInfo(int channelNum, double offset1, double offset2);
		void setOffSetInfo(int channelNum, double offset);

        void setMFCAIAOInfo(int channelNum, std::string info);
        static void setConfigDir(const std::string &path);
        static std::string m_configDir; 	// the config dir 
        void setPTRange(int channelNum, double min, double max);
		
		virtual void init();
		virtual void initChs(DeviceNode<PLCDevice> *node);
};

#endif  /*PLCDEVICE_H_*/
