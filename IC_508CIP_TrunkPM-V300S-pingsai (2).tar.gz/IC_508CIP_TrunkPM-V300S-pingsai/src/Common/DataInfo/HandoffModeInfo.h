/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: HandoffModeInfo.h
** Description: 
** Release: 
** Modification history: 
** 					2011-5-17   ChenPengfei create  
**      
***************************************************************************/
#ifndef HANDOFFMODEINFO_H_
#define HANDOFFMODEINFO_H_
#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class HandoffModeInfo : public IntValueInfo
{
public:

		static const int UnInit = -1;
		static const int Unknown = 0;
		static const int Passive = 1;
		static const int Active = 2;
		static const IntTypeInfo typeInfo;

	   HandoffModeInfo():IntValueInfo(-1, typeInfo)
	   {
	   }
	
	   HandoffModeInfo(int i):IntValueInfo(i, typeInfo)
	    {
	    }
	
	   HandoffModeInfo(std::string s):IntValueInfo(s, typeInfo)
	    {
	    }
};



#endif /*HANDOFFMODEINFO_H_*/
