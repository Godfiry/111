/********************************************************************
** Copyright (c) 2006, Beijing COMDEL Co.,Ltd.  All rights reserved.
** File name: COMDELMatchDriver.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2016-06-08   mujy create
**      
*********************************************************************/
#ifndef COMDELMATCHDRIVER_H_
#define COMDELMATCHDRIVER_H_

#include "SerialDevice.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#include "DescriptorList.h"
#include "StringTypeInfo.h"
#include <map>
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class COMDELMatchDriver:public SerialDevice
{
	DECLARE_DYNAMIC(COMDELMatchDriver)	
	DECLARE_MSG_MAP	

	private:
		typedef struct
		{
			int m_ps;
			std::string m_s1;
			int m_ps2;
		}Com;
		
		typedef std::pair<std::string,DescriptorList> ParamPair;
		
		static std::map<std::string,DescriptorList> m_params;
		static ParamPair m_paramPairs[];
		static Com m_commands[];	   
	
	protected:
		bool sendCommand(std::string command, int timeOut);
		std::string readCommand(std::string command, int timeOut);	
		void initChs(DeviceNode<COMDELMatchDriver> *node);
		void initDevice();
		
	public:
		COMDELMatchDriver();
		virtual ~COMDELMatchDriver();
		
		bool writeInt(int channelNum, int value, const IntTypeInfo &typeInfo);
		bool writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo);
		bool writeRawCommand(int channelNum, std::string value, const StringTypeInfo &typeInfo);
		bool readInt(int channelNum, int *value, const IntTypeInfo &typeInfo);
		bool readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo);		
		
		void init();
};

#endif /*COMDELMATCHDRIVER_H_*/
