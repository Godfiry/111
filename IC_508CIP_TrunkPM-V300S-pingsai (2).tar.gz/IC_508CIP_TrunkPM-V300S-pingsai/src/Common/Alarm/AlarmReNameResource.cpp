#include "AlarmReNameResource.h"
#include "AlarmReNameManager.h"
#include "Converter.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

AlarmReNameResource::AlarmReNameResource()
{
}

AlarmReNameResource::~AlarmReNameResource()
{
}

bool AlarmReNameResource::AddAlarmName(const string& strOriginalName , const string& strShowName)
{
    if(AlarmReNameManager::getInstance()->AddAlarmNames(strOriginalName,strShowName))
    {
        return true;
    }
    else
    {
        throw "Add AlarmName ERR:"+strOriginalName+" has already exist.";
        //return false;
    }
}

IMPLEMENT_DYNAMIC(AlarmReNameResource,CmdTarget )

BEGIN_MSG_MAP(AlarmReNameResource,CmdTarget )
    SET_SS(AddAlarmName, AlarmReNameResource)
END_MSG_MAP
