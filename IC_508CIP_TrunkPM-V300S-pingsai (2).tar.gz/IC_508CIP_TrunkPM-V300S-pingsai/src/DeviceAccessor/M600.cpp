/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: M600.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-11-25   LiJuanjuan create
**      
*********************************************************************/
#include "M600.h"
#include "DeviceManager.h"

#include "Converter.h"
#include <iostream>
#include "SysLogger.h"
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std; 

M600::M600():SerialDevice(80, "\x0D\x0A")
{
	m_timeOut = 1;//0.1s
	m_pollPeriod = 1000; //1s	
	m_dAO = 0;
	m_dAS = 1;
	m_dLastTemperature = 0;
}

M600::~M600()
{
}


bool M600::readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo)
{
	string strResponse = getResultOnly(m_timeOut,30);
	size_t nPos = strResponse.find("1:");  //changed by wzd 1.1.39
	if(nPos == string::npos)
	{
		throw IOException("M600 invalid read back:" + strResponse);
	}
	else
	{
		strResponse = strResponse.substr(nPos+2, 8);
		double dValue;
		if(!Converter::stringToDouble(dValue, strResponse))
		{
			throw IOException("M600 invalid read back double value :"+strResponse);
		}
		else
		{
			double dTempValue = (dValue - m_dAO)*m_dAS;
			if((dTempValue - m_dLastTemperature > 5 || dTempValue - m_dLastTemperature < -5 ) && m_dLastTemperature!=0)
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": The temperature is abnormal ");
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": result is :" + strResponse);
				for(int i=0; i<strResponse.length(); i++)
				{
					int t = (unsigned char)strResponse[i];
					SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": result is :" + Converter::convertToString(t));
				}
				strResponse = getResultOnly(m_timeOut,30);
				nPos = strResponse.find("1:");
				if(nPos == string::npos)
				{
					throw IOException("M600 invalid read back:" + strResponse);
				}
				else
				{
					strResponse = strResponse.substr(nPos+2, 8);
					if(!Converter::stringToDouble(dValue, strResponse))
					{
						throw IOException("M600 invalid read back double value :"+strResponse);
					}
					else
					{
						*pValue = (dValue - m_dAO)*m_dAS;
					}
				}
			}
			else
			{
				*pValue = (dValue - m_dAO)*m_dAS;
			}
			m_dLastTemperature = *pValue;
			return true;
		}
	}
}

void M600::initChs(DeviceNode<M600> *node)
{
	node->registerReadCh(1, &M600::readDouble);
	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &SerialDevice::getStatus);
}

void M600::initDevice()
{
	cout<<"start scan M600..."<<endl;
	sendCommandOnly("\x1BST = E");
	sendCommandOnly("\x1BPS = 1");
	cout<<"scan M600 successfully."<<endl;
}

void M600::init()
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "M600 start");
	DeviceNode<M600> *node = new DeviceNode<M600>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	if(!isSimulated())
	{
		initChs(node);	
		initDevice();
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "M600 end");
}

void M600::setAO(double dAO)
{
	m_dAO = dAO;
}
		
void M600::setAS(double dAS)
{
	m_dAS = dAS;
}

IMPLEMENT_DYNAMIC(M600, SerialDevice )

BEGIN_MSG_MAP(M600, SerialDevice )
	SET_V( init, M600 )
	SET_D( setAO, M600 )
	SET_D( setAS, M600 )
END_MSG_MAP
