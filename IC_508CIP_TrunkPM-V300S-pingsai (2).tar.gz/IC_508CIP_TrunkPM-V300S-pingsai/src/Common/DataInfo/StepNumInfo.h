/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: StepNameInfo.h
** Description: 
** Release: 
** Modification history: 
** 					Feb 22, 2008  shenql  create 
**      
***************************************************************************/
#ifndef STEPNUMINFO_H_
#define STEPNUMINFO_H_

#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class StepNumInfo : public IntValueInfo
{
	public:
		static const IntTypeInfo typeInfo;
		
		StepNumInfo():IntValueInfo(0,typeInfo){}
		StepNumInfo(int i):IntValueInfo(i, typeInfo){}
};

#endif /*STEPNUMINFO_H_*/
