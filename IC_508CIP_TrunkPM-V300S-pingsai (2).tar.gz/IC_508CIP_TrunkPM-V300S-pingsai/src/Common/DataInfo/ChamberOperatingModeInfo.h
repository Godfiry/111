/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					Jan 22, 2008  shenql  create 
**      
***************************************************************************/
#ifndef CHAMBEROPERATINGMODEINFO_H_
#define CHAMBEROPERATINGMODEINFO_H_
#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class ChamberOperatingModeInfo : public IntValueInfo
{
public:

		static const int UnInit = -1;
		static const int VAC = 0;
		static const int ATM = 1;
		
		static const IntTypeInfo typeInfo;

	   ChamberOperatingModeInfo():IntValueInfo(-1, typeInfo)
	   {
	   }
	
	   ChamberOperatingModeInfo(int i):IntValueInfo(i, typeInfo)
	    {
	    }
	
	   ChamberOperatingModeInfo(std::string s):IntValueInfo(s, typeInfo)
	    {
	    }
};


#endif /*CHAMBEROPERATINGMODEINFO_H_*/
