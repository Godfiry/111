/*
 * N2BallastChamber.h
 *
 *  Created on: 2022-06-20
 *      Author: liusiyuan
 */

#ifndef _N2BALLASTCHAMBER_H_
#define _N2BALLASTCHAMBER_H_

#include "CmdTarget.h"
#include "GasIDs.h"
#include "PressureController.h"
#include "AppRcpBody.h"
#include "GassesToFlow.h"
#include <unistd.h>  //add by wzd 1.1.39
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

class N2BallastChamber :public CmdTarget{

    DECLARE_DYNAMIC(N2BallastChamber)
    DECLARE_MSG_MAP


public:
    N2BallastChamber();
    virtual ~N2BallastChamber();

    //virtual void doPrepChamber();
    virtual void doPostExecuteRecipe(GassesToFlow *pGassesToFlow);//added by liusy[1.1.43]
    virtual void doPreExecuteRecipe();//added by liusy[1.1.43]

    virtual void doGoToTransferPositionNoWait();
    virtual void doGoToTransferPosition();//added by guojin[1.1.37]
    virtual void doCompleteTransferMaterialNoWait(int status, int slot);
    virtual void doCompleteTransferMaterial(int status, int slot);//added by guojin[1.1.37]

    virtual bool isEnabled();

public:
    virtual void make();
    virtual void initialize();
    virtual void verifyInit();

public:
    void setProcessGasIDs(const std::string &path);
    void setPressureController(const std::string &path);

    void setInnerDoorOpenSensor(const std::string &path);
    void setInnerDoorCloseSensor(const std::string &path);
    void setInnerDoorOpenWch(const std::string &path);
    void setInnerDoorCloseWch(const std::string &path);
    void setInnerDoor(const std::string &path);
    //added by liusy[1.1.43]
    void setRcpBody(AppRcpBody *body);
    void setWACTimeMsBeforePinDown(int nTimeMs);


    bool isInnerDoorOpen();
    bool isInnerDoorClose();
    double getN2BallastPumpTimeAfterWAC();//added by guojin[1.1.37]
    double getN2BallastPumpTimeAfterProcess();//added by guojin[1.1.37]
    double getN2BallastPumpTimeBeforeWAC();//added by guojin[1.1.37]
    double getN2BallastPumpTimeBeforeProcess();//added by guojin[1.1.37]
    double getN2BallastPumpOutBeforePinDown();//added by guojin[1.1.37]

	void setIsOpenInnerDoorWhenPostFlag(ReadWriteInt *pOpenInnerDoorWhenPost);//added by mujy [1.2.3]  for PSEV300 WPH
protected:
    PressureController *m_pPressureController;
    GasIDs *m_pProcessGasIDs;
    ValveController *m_pInnerDoor;
    //added by liusy[1.1.43]
    AppRcpBody *m_pRecipeBody;
    int m_nWACTimeMsBeforePinDown;

    ReadOnlyInt *m_pInnerDoorOpenSensor;//added by xiasc[201706]
    ReadOnlyInt *m_pInnerDoorCloseSensor;
    ReadWriteInt *m_pInnerDoorOpenWch;
    ReadWriteInt *m_pInnerDoorCloseWch;
    ReadWriteInt *m_pPendulumValveFullyOpenAfterStopN2Ballast;//added by liwh[1.8.0]

private:

    ReadWriteDouble* m_pN2BallastPumpTimeAfterWAC;
    ReadWriteDouble* m_pN2BallastPumpTimeAfterProcess;
    ReadWriteDouble* m_pN2BallastPumpTimeBeforeWAC;
    ReadWriteDouble* m_pN2BallastPumpTimeBeforeProcess;
    ReadWriteDouble* m_pN2BallastPumpOutBeforePinDown;

	ReadWriteInt *m_pCfgPostOpenInnerDoorEnabled;;//added by mujy [1.2.3] for PSEV300 WPH
};

#endif /*_N2BALLASTCHAMBER_H_ */
