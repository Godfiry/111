/********************************************************************
** Copyright (c) 2020, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: GaugeHoribaGR300.h
** Description:This Driver is use for Horiba GR300 Series(GR-314F). Using GR-300 for back side wafer cooling, accurate pressure control of helium gas.
** Release: 1.1
** Modification history: 
** 					2020-10-26   Mujy create
**      
*********************************************************************/
#ifndef GAUGEHORIBAGR300_H_
#define GAUGEHORIBAGR300_H_

#include "IODevice.h"
#include "DoubleTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class GaugeHoribaGR300:public IODevice
{
	DECLARE_DYNAMIC(GaugeHoribaGR300)
	DECLARE_MSG_MAP
	public:
		GaugeHoribaGR300();
		virtual ~GaugeHoribaGR300();

	public://override
		virtual void init();
		virtual void initDevice();

	public:
		bool writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo);
		bool readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);
		
		void setFlagForMatch649(bool bEnable);
		void setChangeCoefficientForMatch649(double dCoefficient);

	private:
		int m_nInBytesSize;
		int m_nOutBytesSize;
		
		bool m_bEnable;//default false;
		double m_dCoefficient;//default 1; He-->N2:1.415
};

#endif /*GAUGEHORIBAGR300_H_*/
