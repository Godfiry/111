/********************************************************************
** Copyright (c) 2019, Beijing NAURA Co.,Ltd.  All rights reserved.
** File name: ChannelStatus.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2019-1-8   mujy create
*********************************************************************/

#include "ChannelStatus.h"
#include "SysLogger.h"
#ifdef IAP4_0
#include "ITime.h"
#else
#include "Time.h"
#endif
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "InvalidNameException.h"
#endif
#include "ConfigException.h"
#include "ObjectManager.h"
#include "CTCExport.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
using namespace IAP::IO;
#endif
using namespace std;

ChannelStatus::ChannelStatus():Subscriber(IO::UNKNOWN)
{
	m_pMonitorChannel = NULL;
	m_pChannelStatus = NULL;
}

ChannelStatus::~ChannelStatus()
{
}

void ChannelStatus::verifyInit()
{
	if(m_pMonitorChannel == NULL)
	{
		throw getName()+" not config MonitorChannel!";
	}
	if(m_pChannelStatus == NULL)
	{
		throw getName()+" not config UpdateChannel!";
	}
}

void ChannelStatus::startup()
{
	m_pMonitorChannel->subscribe(this);
}

void ChannelStatus::update(UntypedData *pData, const ValueInfo &value)
{
	try
	{
		UntypedData *pChannel = dynamic_cast<UntypedData*>(pData);
		if(pChannel!=NULL)
		{
			if(pChannel->getValidity() == IO::INVALID||pChannel->getValidity() == IO::OFFLINE)
			{	
				m_pChannelStatus->setValue(1);
			}
			else
			{
				m_pChannelStatus->setValue(0);
			}
		}
		else
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + "can't convert data to channel.");
		}
	}
	catch(exception &ex)
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": got exception:" + string(ex.what()));
	}
	
}


void ChannelStatus::setMonitorChannel(const std::string &strMonitorPath,const std::string &strUpdatePath)
{
	ManagedObject *obj = NULL;
	try
	{
		obj = ObjectManager::getInstance()->getObject(strMonitorPath);
	}
	catch(const InvalidNameException &e)
	{
		obj = ObjectManager::getInstance()->getObject(this,strMonitorPath);
	}
	UntypedData * pCh = dynamic_cast<UntypedData*>(obj);
	if(NULL == pCh)
	{
		string error = "the object under path '" + strMonitorPath + "' is not a UntypedData";
		throw ConfigException(error);
	}
	m_pMonitorChannel = pCh;

	try
	{
		obj = ObjectManager::getInstance()->getObject(strUpdatePath);
	}
	catch(const InvalidNameException &e)
	{
		obj = ObjectManager::getInstance()->getObject(this,strUpdatePath);
	}
	ReadWriteInt * pUpdateCh = dynamic_cast<ReadWriteInt*>(obj);
	if(NULL == pUpdateCh)
	{
		string error = "the object under path '" + strUpdatePath + "' is not a ReadWriteInt";
		throw ConfigException(error);
	}
	m_pChannelStatus = pUpdateCh;
}

IMPLEMENT_DYNAMIC(ChannelStatus, ControlObject)
BEGIN_MSG_MAP(ChannelStatus, ControlObject)
	SET_SS(setMonitorChannel, ChannelStatus)
END_MSG_MAP	
