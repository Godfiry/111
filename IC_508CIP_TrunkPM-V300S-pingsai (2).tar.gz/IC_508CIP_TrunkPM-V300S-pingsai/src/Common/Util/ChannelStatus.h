/********************************************************************
** Copyright (c) 2019, Beijing NAURA Co.,Ltd.  All rights reserved.
** File name: ChannelStatus.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2019-1-8   mujy create
*********************************************************************/
#ifndef CHANNELSTATUS_H_
#define CHANNELSTATUS_H_

#include "ControlObjectEX.h"
#include "Subscriber.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class ChannelStatus :public ControlObjectEX, public Subscriber
{
	DECLARE_DYNAMIC(ChannelStatus )
	DECLARE_MSG_MAP	

		
	public:
		ChannelStatus();
		virtual ~ChannelStatus();

	public://xml
		void setMonitorChannel(const std::string &strMonitorPath,const std::string &strUpdatePath);

	public://override
		virtual void startup();
		virtual void verifyInit();
		virtual void update(UntypedData *pData, const ValueInfo &value);

	private:
		UntypedData * m_pMonitorChannel;
		ReadWriteInt * m_pChannelStatus;
};		
#endif 
