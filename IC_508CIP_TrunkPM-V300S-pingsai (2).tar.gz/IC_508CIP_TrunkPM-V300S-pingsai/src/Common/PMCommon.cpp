/********************************************************************
** Copyright (c) 2019 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: PMCommon.h
** Description:  
** Release: 1.0
** Modification history:           
** 					2019-06-11   Duq create
** 
*********************************************************************/

#include "PMCommon.h"
#include <iostream>

using namespace std;

const string PMCommon::globalRecipeStepNameSymbol = "Step_Name";
const string PMCommon::globalRecipeEndModeSymbol = "End_Mode";
const string PMCommon::globalRecipeStepTimeSymbol = "ProcessTime";
const string PMCommon::globalRecipeStepEndPointSymbol = "Step_EndPoint";
const string PMCommon::globalRecipeOffsetTableSymbol = "OffsetTable";
const string PMCommon::globalRecipeZoneTableSymbol = "ZoneTable";

const string PMCommon::globalRecipeTempModeSymbol = "Temp_Mode";
const string PMCommon::globalRecipeTargetTempSymbol = "Target_Temp(degC)";
const string PMCommon::globalRecipeTempRampRateSymbol = "Temp_RampRate(degC/s)";
const string PMCommon::globalRecipeTargetPowerSymbol = "Target_Power(kW)";
const string PMCommon::globalRecipePowerRampRateSymbol = "Power_RampRate(kW/s)";
const string PMCommon::globalRecipePowerRatioSymbol = "PowerRatio";
const string PMCommon::globalRecipeDomeTempSymbol = "Dome_Temp(degC)";

const string PMCommon::globalRecipeTotalProcessGasSymbol = "TotalProcessGas";
const string PMCommon::globalRecipeMainH2FlowSymbol = "Main_H2_Flow(SLM)";
const string PMCommon::globalRecipeSlitH2FlowSymbol = "Slit_H2_Flow(SLM)";
const string PMCommon::globalRecipeEdgeH2FlowSymbol = "Edge_H2";
const string PMCommon::globalRecipePushRunSymbol = "Push_Run(SCCM)";
const string PMCommon::globalRecipePushVentSymbol = "Push_Vent(SCCM)";

const string PMCommon::globalRecipeMainTCSSymbol = "Main_TCS";
const string PMCommon::globalRecipeMainTCSFlowSymbol = "Main_TCS_Flow(SLM)";
const string PMCommon::globalRecipeEdgeTCSSymbol = "Edge_TCS";
const string PMCommon::globalRecipeEdgeTCSFlowSymbol = "Edge_TCS_Flow(SCCM)";

const string PMCommon::globalRecipeDop1DiluteFlowSymbol = "Dop1(N-Type)_Dilute_Flow(SLM)";
const string PMCommon::globalRecipeDop1FlowSymbol = "Dop1(N-Type)_Flow(SCCM)";
const string PMCommon::globalRecipeMixDop1Symbol = "MixDop1(N-Type)";
const string PMCommon::globalRecipeMixDop1FlowSymbol = "MixDop1(N-Type)_Flow(SCCM)";

const string PMCommon::globalRecipeDop2DiluteFlowSymbol = "Dop2(P-Type)_Dilute_Flow(SLM)";
const string PMCommon::globalRecipeDop2FlowSymbol = "Dop2(P-Type)_Flow(SCCM)";
const string PMCommon::globalRecipeMixDop2Symbol = "MixDop2(P-Type)";
const string PMCommon::globalRecipeMixDop2FlowSymbol = "MixDop2(P-Type)_Flow(SCCM)";

const string PMCommon::globalRecipeHCLSymbol = "HCL";
const string PMCommon::globalRecipeHCLPolishFlowSymbol = "HCL_Polish_Flow(SCCM)";
const string PMCommon::globalRecipeHCLEtchFlowSymbol = "HCL_Etch_Flow(SLM)";
const string PMCommon::globalRecipeHCLEdgeFlowSymbol = "HCL_Edge_Flow(SLM)";

const string PMCommon::globalRecipeAuxDopSymbol = "AuxDop";	
const string PMCommon::globalRecipeAuxDopInnerSymbol = "AuxDop_Inner";	
const string PMCommon::globalRecipeAuxDopMiddleSymbol = "AuxDop_Middle";	
const string PMCommon::globalRecipeAuxDopInnerFlowSymbol = "AuxDop_Inner_Flow(SCCM)";	
const string PMCommon::globalRecipeAuxDopMiddleFlowSymbol = "AuxDop_Middle_Flow(SCCM)";	

const string PMCommon::globalRecipeBlowerCtrlModeSymbol = "BlowerCtrlMode";	
const string PMCommon::globalRecipeUpperBlowerSpeedSymbol = "UpperBlowerSpeed(%)";	
const string PMCommon::globalRecipeLowerBlowerSpeedSymbol = "LowerBlowerSpeed(%)";	

const string PMCommon::globalRecipeLiftPosSymbol = "Lift_Pos(mm)";
const string PMCommon::globalRecipeRotateSpeedSymbol = "Rotate_Speed(rpm)";
const string PMCommon::globalRecipeRotateSpeedRampRateSymbol = "Rotate_SpeedRampRate(rps)";

//RP
const string PMCommon::globalRecipePressureModeSymbol = "Pressure_Mode";
const string PMCommon::globalRecipePressureSymbol = "Pressure(Torr)";
const string PMCommon::globalRecipePressureRampRateSymbol = "Pressure_RampRate(Torr/s)";
const string PMCommon::globalRecipePCVSymbol = "PCV(%)";
const string PMCommon::globalRecipePCVRampRateSymbol = "PCV_RampRate(%/s)";

const string PMCommon::globalRecipePushRunRPSymbol = "PushRun";
const string PMCommon::globalRecipePushVentRPSymbol = "PushVent";

const string PMCommon::globalRecipeMainH2RampModeSymbol = "Main_H2_RampMode";
const string PMCommon::globalRecipeMainH2StartFlowSymbol = "Main_H2_StartFlow(SLM)";
const string PMCommon::globalRecipeMainH2EndFlowSymbol = "Main_H2_EndFlow(SLM)";
const string PMCommon::globalRecipeSlitH2RampModeSymbol = "Slit_H2_RampMode";
const string PMCommon::globalRecipeSlitH2StartFlowSymbol = "Slit_H2_StartFlow(SLM)";
const string PMCommon::globalRecipeSlitH2EndFlowSymbol = "Slit_H2_EndFlow(SLM)";

const string PMCommon::globalRecipeDCSSymbol = "DCS";
const string PMCommon::globalRecipeDCSRampModeSymbol = "DCS_RampMode";
const string PMCommon::globalRecipeDCSStartFlowSymbol = "DCS_StartFlow(SCCM)";
const string PMCommon::globalRecipeDCSEndFlowSymbol = "DCS_EndFlow(SCCM)";
const string PMCommon::globalRecipeEDCSSymbol = "E_DCS";
const string PMCommon::globalRecipeEDCSRampModeSymbol = "E_DCS_RampMode";
const string PMCommon::globalRecipeEDCSStartFlowSymbol = "E_DCS_StartFlow(SCCM)";
const string PMCommon::globalRecipeEDCSEndFlowSymbol = "E_DCS_EndFlow(SCCM)";

const string PMCommon::globalRecipeSiH4Symbol = "SiH4";
const string PMCommon::globalRecipeSiH4RampModeSymbol = "SiH4_RampMode";
const string PMCommon::globalRecipeSiH4StartFlowSymbol = "SiH4_StartFlow(SCCM)";
const string PMCommon::globalRecipeSiH4EndFlowSymbol = "SiH4_EndFlow(SCCM)";
const string PMCommon::globalRecipeESiH4Symbol = "E_SiH4";
const string PMCommon::globalRecipeESiH4RampModeSymbol = "E_SiH4_RampMode";
const string PMCommon::globalRecipeESiH4StartFlowSymbol = "E_SiH4_StartFlow(SCCM)";
const string PMCommon::globalRecipeESiH4EndFlowSymbol = "E_SiH4_EndFlow(SCCM)";

const string PMCommon::globalRecipeGeH4Symbol = "GeH4";
const string PMCommon::globalRecipeGeH4RampModeSymbol = "GeH4_RampMode";
const string PMCommon::globalRecipeGeH4StartFlowSymbol = "GeH4_StartFlow(SCCM)";
const string PMCommon::globalRecipeGeH4EndFlowSymbol = "GeH4_EndFlow(SCCM)";
const string PMCommon::globalRecipeEGeH4Symbol = "E_GeH4";
const string PMCommon::globalRecipeEGeH4RampModeSymbol = "E_GeH4_RampMode";
const string PMCommon::globalRecipeEGeH4StartFlowSymbol = "E_GeH4_StartFlow(SCCM)";
const string PMCommon::globalRecipeEGeH4EndFlowSymbol = "E_GeH4_EndFlow(SCCM)";

const string PMCommon::globalRecipeHCLSelectSymbol = "HCL_Select";
const string PMCommon::globalRecipeHCLSelectRampModeSymbol = "HCL_Select_RampMode";
const string PMCommon::globalRecipeHCLSelectStartFlowSymbol = "HCL_Select_StartFlow(SCCM)";
const string PMCommon::globalRecipeHCLSelectEndFlowSymbol = "HCL_Select_EndFlow(SCCM)";
const string PMCommon::globalRecipeHCLEtchSymbol = "HCL_Etch";
const string PMCommon::globalRecipeHCLEtchRampModeSymbol = "HCL_Etch_RampMode";
const string PMCommon::globalRecipeHCLEtchStartFlowSymbol = "HCL_Etch_StartFlow(SLM)";
const string PMCommon::globalRecipeHCLEtchEndFlowSymbol = "HCL_Etch_EndFlow(SLM)";
const string PMCommon::globalRecipeEHCLSymbol = "E_HCL";
const string PMCommon::globalRecipeEHCLRampModeSymbol = "E_HCL_RampMode";
const string PMCommon::globalRecipeEHCLStartFlowSymbol = "E_HCL_StartFlow(SCCM)";
const string PMCommon::globalRecipeEHCLEndFlowSymbol = "E_HCL_EndFlow(SCCM)";

const string PMCommon::globalRecipeDDop1Symbol = "DDop1";	
const string PMCommon::globalRecipeDDop1RampModeSymbol = "DDop1_RampMode";
const string PMCommon::globalRecipeDDop1StartFlowSymbol = "DDop1_StartFlow(SCCM)";
const string PMCommon::globalRecipeDDop1EndFlowSymbol = "DDop1_EndFlow(SCCM)";
	
const string PMCommon::globalRecipeDDop2Symbol = "DDop2";	
const string PMCommon::globalRecipeDDop2RampModeSymbol = "DDop2_RampMode";
const string PMCommon::globalRecipeDDop2StartFlowSymbol = "DDop2_StartFlow(SCCM)";	
const string PMCommon::globalRecipeDDop2EndFlowSymbol = "DDop2_EndFlow(SCCM)";	

const string PMCommon::globalRecipeMixDop1RampModeSymbol = "MixDop1_RampMode";
const string PMCommon::globalRecipeMixDop1StartFlowSymbol = "MixDop1_StartFlow(SCCM)";	
const string PMCommon::globalRecipeMixDop1EndFlowSymbol = "MixDop1_EndFlow(SCCM)";	
const string PMCommon::globalRecipeMixDop2RampModeSymbol = "MixDop2_RampMode";
const string PMCommon::globalRecipeMixDop2StartFlowSymbol = "MixDop2_StartFlow(SCCM)";	
const string PMCommon::globalRecipeMixDop2EndFlowSymbol = "MixDop2_EndFlow(SCCM)";	
const string PMCommon::globalRecipeEMixDopSymbol = "E_MixDop";
const string PMCommon::globalRecipeEMixDopRampModeSymbol = "E_MixDop_RampMode";
const string PMCommon::globalRecipeEMixDopStartFlowSymbol = "E_MixDop_StartFlow(SCCM)";
const string PMCommon::globalRecipeEMixDopEndFlowSymbol = "E_MixDop_EndFlow(SCCM)";

const string PMCommon::globalRecipeAuxSymbol = "Aux";	
const string PMCommon::globalRecipeAuxGeH4RampModeSymbol = "Aux_GeH4_RampMode";
const string PMCommon::globalRecipeAuxGeH4StartFlowSymbol = "Aux_GeH4_StartFlow(SCCM)";
const string PMCommon::globalRecipeAuxGeH4EndFlowSymbol = "Aux_GeH4_EndFlow(SCCM)";
const string PMCommon::globalRecipeAuxDADopRampModeSymbol = "Aux_DADop_RampMode";
const string PMCommon::globalRecipeAuxDADopStartFlowSymbol = "Aux_DADop_StartFlow(SCCM)";
const string PMCommon::globalRecipeAuxDADopEndFlowSymbol = "Aux_DADop_EndFlow(SCCM)";
const string PMCommon::globalRecipeAuxMixDopSymbol = "Aux_MixDop";	
const string PMCommon::globalRecipeAuxMixDopRampModeSymbol = "Aux_MixDop_RampMode";
const string PMCommon::globalRecipeAuxMixDopStartFlowSymbol = "Aux_MixDop_StartFlow(SCCM)";
const string PMCommon::globalRecipeAuxMixDopEndFlowSymbol = "Aux_MixDop_EndFlow(SCCM)";
const string PMCommon::globalRecipeDop1FlowRPSymbol = "Dop1_Flow(SCCM)";
const string PMCommon::globalRecipeDop2FlowRPSymbol = "Dop2_Flow(SCCM)";
const string PMCommon::globalRecipeMixDop1RPSymbol = "MixDop1";
const string PMCommon::globalRecipeMixDop2RPSymbol = "MixDop2";
const string PMCommon::globalRecipeDop1DiluteFlowRPSymbol = "Dop1_Dilute_Flow(SCCM)";
const string PMCommon::globalRecipeDop2DiluteFlowRPSymbol = "Dop2_Dilute_Flow(SCCM)";

const string PMCommon::globalRecipeBPCModeSymbol = "BPC_Mode";
const string PMCommon::globalRecipeBPC01OffsetPressureSymbol = "BPC01_OffsetPressure(Torr)";
const string PMCommon::globalRecipeBPC02OffsetPressureSymbol = "BPC02_OffsetPressure(Torr)";
const string PMCommon::globalRecipeBPC03OffsetPressureSymbol = "BPC03_OffsetPressure(Torr)";
const string PMCommon::globalRecipeBPC01PressureSymbol = "BPC01_Pressure(Torr)";
const string PMCommon::globalRecipeBPC02PressureSymbol = "BPC02_Pressure(Torr)";
const string PMCommon::globalRecipeBPC03PressureSymbol = "BPC03_Pressure(Torr)";

const string PMCommon::globalRecipePurgeGasRPSymbol = "Purge_Gas";
const string PMCommon::globalRecipeMainPurgeRampModeRPSymbol = "Main_Purge_RampMode";
const string PMCommon::globalRecipeMainPurgeStartFlowRPSymbol = "Main_Purge_StartFlow(SLM)";
const string PMCommon::globalRecipeMainPurgeEndFlowRPSymbol = "Main_Purge_EndFlow(SLM)";
const string PMCommon::globalRecipeSlitPurgeRampModeRPSymbol = "Slit_Purge_RampMode";
const string PMCommon::globalRecipeSlitPurgeStartFlowRPSymbol = "Slit_Purge_StartFlow(SLM)";
const string PMCommon::globalRecipeSlitPurgeEndFlowRPSymbol = "Slit_Purge_EndFlow(SLM)";
//for e630r plus
/*const string PMCommon::globalRecipeLinerPurgeRampModeRPSymbol = "Liner_Purge_RampMode";
const string PMCommon::globalRecipeLinerPurgeStartFlowRPSymbol = "Liner_Purge_StartFlow(SLM)";
const string PMCommon::globalRecipeLinerPurgeEndFlowRPSymbol = "Liner_Purge_EndFlow(SLM)";
const string PMCommon::globalRecipeRotPurgeRampModeRPSymbol = "Rot_Purge_RampMode";
const string PMCommon::globalRecipeRotPurgeStartFlowRPSymbol = "Rot_Purge_StartFlow(SLM)";
const string PMCommon::globalRecipeRotPurgeEndFlowRPSymbol = "Rot_Purge_EndFlow(SLM)";*/


const string PMCommon::globalRecipeEPurgeRPSymbol = "E_Purge";
const string PMCommon::globalRecipeEPurgeRampModeRPSymbol = "E_Purge_RampMode";
const string PMCommon::globalRecipeEPurgeStartFlowRPSymbol = "E_Purge_StartFlow(SCCM)";
const string PMCommon::globalRecipeEPurgeEndFlowRPSymbol = "E_Purge_EndFlow(SCCM)";
const string PMCommon::globalRecipeEH2RPSymbol = "E_H2";
const string PMCommon::globalRecipeEH2RampModeRPSymbol = "E_H2_RampMode";
const string PMCommon::globalRecipeEH2StartFlowRPSymbol = "E_H2_StartFlow(SCCM)";
const string PMCommon::globalRecipeEH2EndFlowRPSymbol = "E_H2_EndFlow(SCCM)";
const string PMCommon::globalRecipePushH2RunRPSymbol = "PushH2Run";
const string PMCommon::globalRecipePushH2VentRPSymbol = "PushH2Vent";
//single
const string PMCommon::globalRecipeAuxDopOuterSymbol = "AuxDop_Outer";	
const string PMCommon::globalRecipeAuxDopOuterFlowSymbol = "AuxDop_Outer_Flow(SCCM)";
const string PMCommon::globalRecipeEdgeGasSymbol = "Edge_Gas";
const string PMCommon::globalRecipeEdgeHCLSymbol = "Edge_HCL";
const string PMCommon::globalRecipePushH2RunSymbol = "PushH2Run";
const string PMCommon::globalRecipePushH2VentSymbol = "PushH2Vent";
const string PMCommon::globalRecipeEH2Symbol = "E_H2";
const string PMCommon::globalRecipeEH2RampModeSymbol = "E_H2_RampMode";
const string PMCommon::globalRecipeEH2StartFlowSymbol = "E_H2_StartFlow(SCCM)";
const string PMCommon::globalRecipeEH2EndFlowSymbol = "E_H2_EndFlow(SCCM)";
const string PMCommon::globalRecipeMixDop1RampModeAPSymbol = "MixB2H6_RampMode";
const string PMCommon::globalRecipeMixDop1StartFlowAPSymbol = "MixB2H6_StartFlow(SCCM)";	
const string PMCommon::globalRecipeMixDop1EndFlowAPSymbol = "MixB2H6_EndFlow(SCCM)";
const string PMCommon::globalRecipeDop1FlowRPSSymbol = "B2H6_Flow(SCCM)";
const string PMCommon::globalRecipeMixDop1RPSSymbol = "MixB2H6";
const string PMCommon::globalRecipeDop1DiluteFlowRPSSymbol = "B2H6_Dilute_Flow(SCCM)";

//ALC
const string PMCommon::RPN_AHFDiluteGasType = "AHFDiluteGasFlowType";
const string PMCommon::RPN_AHFDiluteGas = "AHFDiluteGas(SCCM)";
const string PMCommon::RPN_AHFGasType = "AHFGasFlowType";
const string PMCommon::RPN_AHFGas = "AHFGas(SCCM)";
const string PMCommon::RPN_NH3DiluteGasType = "NH3DiluteGasFlowType";
const string PMCommon::RPN_NH3DiluteGas = "NH3DiluteGas(SCCM)";
const string PMCommon::RPN_NH3GasType = "NH3GasFlowType";
const string PMCommon::RPN_NH3Gas = "NH3Gas(SCCM)";
const string PMCommon::RPN_N2GasType = "N2FlowType";
const string PMCommon::RPN_N2Gas = "N2Gas(SCCM)";
const string PMCommon::RPN_H2GasType = "H2FlowType";
const string PMCommon::RPN_H2Gas = "H2Gas(SCCM)";
const string PMCommon::RPN_ArGasType = "ArFlowType";
const string PMCommon::RPN_ArGas = "ArGas(SCCM)";
const string PMCommon::RPN_NF3GasType = "NF3FlowType";
const string PMCommon::RPN_NF3Gas = "NF3Gas(SCCM)";
const string PMCommon::RPN_BottomPurgeGas = "Bottom Purge(SCCM)";
const string PMCommon::RPN_SlitPurgeGas = "Slit Purge(SCCM)";
const string PMCommon::RPN_ValveMode = "Pressure Mode";
const string PMCommon::RPN_ValveSetPoint = "Butterfly Valve Pos";
const string PMCommon::RPN_HeaterPos = "HeaterPos";
const string PMCommon::RPN_PosSpacing = "Heater Spacing";
const string PMCommon::RPN_PinSpacing = "Pin Spacing";

const string PMCommon::MI_N2GasFlow = "N2Flow";
const string PMCommon::MI_H2GasFlow = "H2Flow";
const string PMCommon::MI_AHFGasFlow = "AHFGasFlow";
const string PMCommon::MI_AHFDiluteGasFlow = "AHFDiluteGasFlow";
const string PMCommon::MI_NH3GasFlow = "NH3GasFlow";
const string PMCommon::MI_NH3DiluteGasFlow = "NH3DiluteGasFlow";
const string PMCommon::MI_ArGasFlow = "ArFlow";
const string PMCommon::MI_NF3GasFlow = "NF3Flow";
const string PMCommon::MI_BottomPurgeGasFlow = "BottomPurgeGasFlow";
const string PMCommon::MI_SlitPurgeGasFlow = "SlitPurgeGasFlow";
const string PMCommon::MI_ProcPress = "ProcPressure";    // Monitor item about process pressure
const string PMCommon::RPN_Pressure = "Pressure(Torr)";
const string PMCommon::RPN_StepName = "Step Name";    // recipe param name about step name
const string PMCommon::RPN_StepTime = "Time(s)";    // recipe param name about step time
const string PMCommon::RPN_PedTemp = "Heater Temp(degC)";
const string PMCommon::RPN_SHDTemp = "SHD Temp(degC)";
const string PMCommon::RPN_OffsetTable = "OffsetTable";
const string PMCommon::globalRecipeBackSideModeSymbol = "Vacuum_Chuck";
const string PMCommon::globalRecipeBackSidePressureSymbol = "BackSide_Pressure(Torr)";
const string PMCommon::globalRecipeBackSideFlowSymbol = "BackSide_Flow(SCCM)";
const string PMCommon::globalRecipePedSpacingSymbol = "PedToSHD_Distance(mm)";
const string PMCommon::globalRecipePinSpacingSymbol = "PinToSHD_Distance(mm)";
const string PMCommon::globalRecipeNH3FlowSymbol = "NH3";
const string PMCommon::globalRecipeNF3FlowSymbol = "NF3";
const string PMCommon::globalRecipeH2FlowSymbol = "H2";
const string PMCommon::globalRecipeHeFlowSymbol = "He";
const string PMCommon::globalRecipeArFlowSymbol = "Ar";
const string PMCommon::globalRecipeSlitPurgeFlowSymbol = "SlitPurge";
const string PMCommon::globalRecipeBottomPurgeFlowSymbol = "BottomPurge";
const string PMCommon::globalRecipeEdgePurgeFlowSymbol = "EdgePurge";
const string PMCommon::globalRecipeProcessPosSymbol = "ProcessPos";
const string PMCommon::globalRecipeRFPowerSymbol = "RPS_Power(W)";
const string PMCommon::globalRecipeSHDTempSymbol = "SHD_Temp(degC)";
const string PMCommon::globalRecipePedTempSymbol = "Ped_Temp(degC)";
std::map<string, string> PMCommon::m_PMRecipeParamsMap = PMCommon::getPMRecipeParamsMap();

std::map<string, string>  PMCommon::getPMRecipeParamsMap()
{
	std::map<string, string> tempMaps;
	tempMaps.insert(pair<string, string>(globalRecipeStepTimeSymbol, "Time(s)"));
	tempMaps.insert(pair<string, string>(globalRecipeTargetTempSymbol, "Temperature(degC)"));
	tempMaps.insert(pair<string, string>(globalRecipeTargetPowerSymbol, "Power(kW)"));
	tempMaps.insert(pair<string, string>(globalRecipeMainH2FlowSymbol, "Main_H2(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeSlitH2FlowSymbol, "Slit_H2(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeEdgeH2FlowSymbol, "Edge_H2(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeMainTCSFlowSymbol, "Main_TCS(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeEdgeTCSFlowSymbol, "Edge_Gas(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeDop1DiluteFlowSymbol, "Dop1_Dilute(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeDop1FlowSymbol, "Dop1(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeMixDop1FlowSymbol, "MixDop1(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeDop2DiluteFlowSymbol, "Dop2_Dilute(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeDop2FlowSymbol, "Dop2(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeMixDop2FlowSymbol, "MixDop2(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeHCLPolishFlowSymbol, "HCL_Polish(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeHCLEtchFlowSymbol, "HCL_Etch(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeHCLEdgeFlowSymbol, "Edge_Gas(%)"));
	tempMaps.insert(pair<string, string>(globalRecipePushRunSymbol, "Push_Run(%)"));
	tempMaps.insert(pair<string, string>(globalRecipePushVentSymbol, "Push_Vent(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeAuxDopInnerFlowSymbol, "AuxDop_Inner(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeAuxDopMiddleFlowSymbol, "AuxDop_Middle(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeAuxDopOuterFlowSymbol, "AuxDop_Outer(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeDomeTempSymbol, "DomeTemp(degC)"));
	tempMaps.insert(pair<string, string>(globalRecipeUpperBlowerSpeedSymbol, "UpperBlowerSpeed(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeLowerBlowerSpeedSymbol, "LowerBlowerSpeed(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeLiftPosSymbol, "LiftPos(mm)"));
	tempMaps.insert(pair<string, string>(globalRecipeRotateSpeedSymbol, "RotateSpeed(rpm)"));
	tempMaps.insert(pair<string, string>(globalRecipeDop1DiluteFlowRPSymbol, "Dop1_Dilute(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeDop2DiluteFlowRPSymbol, "Dop2_Dilute(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeDop1FlowRPSymbol, "Dop1(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeDop2FlowRPSymbol, "Dop2(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeMixDop1RPSymbol, "MixDop1(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeMixDop2RPSymbol, "MixDop2(%)"));
	tempMaps.insert(pair<string, string>(globalRecipePressureSymbol, "Pressure(%)"));
	tempMaps.insert(pair<string, string>(globalRecipePCVSymbol, "PCV(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeMainH2StartFlowSymbol, "Main_H2(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeMainH2EndFlowSymbol, "Main_H2(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeSlitH2StartFlowSymbol, "Slit_H2(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeSlitH2EndFlowSymbol, "Slit_H2(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeDCSStartFlowSymbol, "DCS(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeDCSEndFlowSymbol, "DCS(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeEDCSStartFlowSymbol, "E_DCS(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeEDCSEndFlowSymbol, "E_DCS(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeSiH4StartFlowSymbol, "SiH4(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeSiH4EndFlowSymbol, "SiH4(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeESiH4StartFlowSymbol, "E_SiH4(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeESiH4EndFlowSymbol, "E_SiH4(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeGeH4StartFlowSymbol, "GeH4(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeGeH4EndFlowSymbol, "GeH4(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeEGeH4StartFlowSymbol, "E_GeH4(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeEGeH4EndFlowSymbol, "E_GeH4(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeHCLSelectStartFlowSymbol, "HCL_Select(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeHCLSelectEndFlowSymbol, "HCL_Select(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeHCLEtchStartFlowSymbol, "HCL_Etch(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeHCLEtchEndFlowSymbol, "HCL_Etch(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeEHCLStartFlowSymbol, "E_HCL(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeEHCLEndFlowSymbol, "E_HCL(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeDDop1StartFlowSymbol, "DDop1(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeDDop1EndFlowSymbol, "DDop1(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeDDop2StartFlowSymbol, "DDop2(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeDDop2EndFlowSymbol, "DDop2(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeMixDop1StartFlowSymbol, "MixDop1(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeMixDop1EndFlowSymbol, "MixDop1(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeMixDop2StartFlowSymbol, "MixDop2(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeMixDop2EndFlowSymbol, "MixDop2(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeEMixDopStartFlowSymbol, "E_MixDop(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeEMixDopEndFlowSymbol, "E_MixDop(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeAuxGeH4StartFlowSymbol, "Aux_GeH4(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeAuxGeH4EndFlowSymbol, "Aux_GeH4(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeAuxDADopStartFlowSymbol, "Aux_DADop(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeAuxDADopEndFlowSymbol, "Aux_DADop(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeAuxMixDopStartFlowSymbol, "Aux_MixDop(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeAuxMixDopEndFlowSymbol, "Aux_MixDop(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeBPC01OffsetPressureSymbol, "BPC01Pressure(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeBPC02OffsetPressureSymbol, "BPC02Pressure(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeBPC03OffsetPressureSymbol, "BPC03Pressure(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeBPC01PressureSymbol, "BPC01Pressure(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeBPC02PressureSymbol, "BPC02Pressure(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeBPC03PressureSymbol, "BPC03Pressure(%)"));

	tempMaps.insert(pair<string, string>(globalRecipeMainPurgeStartFlowRPSymbol, "Main_Purge(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeMainPurgeEndFlowRPSymbol, "Main_Purge(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeSlitPurgeStartFlowRPSymbol, "Slit_Purge(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeSlitPurgeEndFlowRPSymbol, "Slit_Purge(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeEPurgeStartFlowRPSymbol, "E_Purge(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeEPurgeEndFlowRPSymbol, "E_Purge(%)"));
    tempMaps.insert(pair<string, string>(globalRecipeEH2StartFlowRPSymbol, "E_H2(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeEH2EndFlowRPSymbol, "E_H2(%)"));
	//for e630r plus
	/*tempMaps.insert(pair<string, string>(globalRecipeLinerPurgeStartFlowRPSymbol, "Liner_Purge(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeLinerPurgeEndFlowRPSymbol, "Liner_Purge(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeRotPurgeStartFlowRPSymbol, "Rot_Purge(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeRotPurgeEndFlowRPSymbol, "Rot_Purge(%)"));*/
	
	//single
	tempMaps.insert(pair<string, string>(globalRecipeAuxDopOuterFlowSymbol, "AuxDop_Outer"));
	tempMaps.insert(pair<string, string>(globalRecipeDop1DiluteFlowRPSSymbol, "B2H6_Dilute"));
	tempMaps.insert(pair<string, string>(globalRecipeDop1FlowRPSSymbol, "B2H6"));
	tempMaps.insert(pair<string, string>(globalRecipeMixDop1RPSSymbol, "MixB2H6"));
	tempMaps.insert(pair<string, string>(globalRecipeEH2StartFlowSymbol, "E_H2"));
	tempMaps.insert(pair<string, string>(globalRecipeEH2EndFlowSymbol, "E_H2"));
	tempMaps.insert(pair<string, string>(globalRecipeMixDop1StartFlowAPSymbol, "MixB2H6"));
	tempMaps.insert(pair<string, string>(globalRecipeMixDop1EndFlowAPSymbol, "MixB2H6"));
	
	//ALC
	tempMaps.insert(pair<string, string>(RPN_StepTime, "Time(s)"));
	tempMaps.insert(pair<string, string>(RPN_AHFDiluteGas, "AHFDiluteGas(%)"));
	tempMaps.insert(pair<string, string>(RPN_AHFGas, "AHFGas(%)"));
	tempMaps.insert(pair<string, string>(RPN_NH3DiluteGas, "NH3DiluteGas(%)"));
	tempMaps.insert(pair<string, string>(RPN_NH3Gas, "NH3Gas(%)"));
	tempMaps.insert(pair<string, string>(RPN_N2Gas, "N2Gas(%)"));
	tempMaps.insert(pair<string, string>(RPN_H2Gas, "H2Gas(%)"));
	tempMaps.insert(pair<string, string>(RPN_BottomPurgeGas, "BottomPurge(%)"));
	tempMaps.insert(pair<string, string>(RPN_SlitPurgeGas, "SlitPurge(%)"));
	tempMaps.insert(pair<string, string>(RPN_ValveSetPoint, "ButterflyValvePos(%)"));
	tempMaps.insert(pair<string, string>(RPN_Pressure, "Pressure(%)"));
	tempMaps.insert(pair<string, string>(RPN_PosSpacing, "HeaterSpacing(mm)"));
	tempMaps.insert(pair<string, string>(RPN_PinSpacing, "PinSpacing(mm)"));
	tempMaps.insert(pair<string, string>(globalRecipeNH3FlowSymbol, "NH3(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeNF3FlowSymbol, "NF3(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeH2FlowSymbol, "H2(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeHeFlowSymbol, "He(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeArFlowSymbol, "Ar(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeSlitPurgeFlowSymbol, "Slit(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeBottomPurgeFlowSymbol, "Bottom(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeEdgePurgeFlowSymbol, "Edge(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeBackSidePressureSymbol, "BackSidePressure(%)"));
	tempMaps.insert(pair<string, string>(globalRecipeBackSideFlowSymbol, "BackSide(%)"));
	tempMaps.insert(pair<string, string>(globalRecipePedSpacingSymbol, "PedToSHDDistance(mm)"));
	tempMaps.insert(pair<string, string>(globalRecipePinSpacingSymbol, "PinToSHDDistance(mm)"));
    tempMaps.insert(pair<string, string>(globalRecipeRFPowerSymbol, "RPS_Power(%)"));
	return tempMaps;
}
