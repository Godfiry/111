/********************************************************************
** Copyright (c) 2019 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: PLCDevice.cpp
** Description:  
** Release: 1.0
** Modification history:           
** 					2019-06-05   Duq create
**                                                 2020-06-03   Duq update
*********************************************************************/

#include "PLCDevice.h"
#include <string.h>
#include <stdlib.h>
#include <cmath>
#include <sys/time.h>
#include <iostream>
#include "IStringList.h"
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

using namespace std;

string PLCDevice::m_configDir = "";

PLCDevice::PLCDevice()
{
	m_result = true;
	m_pollInterval = 200;
	m_server = "";

	m_nodeNum = -1;
	m_DIChsSize = -1;
	m_DIStartCh = -1;
	m_DIStartAd = -1;
	m_DOChsSize = -1;
	m_DOStartCh = -1;
	m_DOStartAd = -1;
	m_IntlkDIStartCh = -1;
	m_IntlkDIStartAd = -1;
	m_IntlkDIChsSize = -1;
	m_IntlkDOStartCh = -1;
	m_IntlkDOStartAd = -1;
	m_IntlkDOChsSize = -1;
	m_DevNetDIStartCh1 = -1;
	m_DevNetDIStartAd1 = -1;
	m_DevNetDIChsSize1 = -1;
	
	m_DevNetDIStartCh2 = -1;
	m_DevNetDIStartAd2 = -1;
	m_DevNetDIChsSize2 = -1;

	m_DevNetDOStartCh = -1;
	m_DevNetDOStartAd = -1;
	m_DevNetDOChsSize = -1;
	m_MFCOnlineStartCh = -1;
	m_MFCOnlineStartAd = -1;
	m_MFCOnlineChsSize = -1;
	
	m_StatusWordSize = 4;//UDINT = 4bytes
	m_eip = NULL;
	setdometemp1 = -1;
	setdometemp2 = -1;
	modifydometemp1 = -1;
	modifydometemp2 = -1;
	m_plcname = "PMPLC";
}

PLCDevice::~PLCDevice()
{ 
	if(!isSimulated())
	{
		m_eip->shutdownDevice();
	}
}

void PLCDevice::setPLCDeviceName(std::string name)
{
	m_plcname = name;
}

void PLCDevice::setServer(const std::string &server)
{
	m_server = server;
}
void PLCDevice::setModuleName(const std::string &name)
{
	m_moduleName = name;
}
void PLCDevice::setConfigInputOutputInstanceID(int ConfigIid, int InputIid, int OutputIid)
{
	m_configInstanceId = ConfigIid;
	m_inputInstanceId = InputIid;
	m_outputInstanceId = OutputIid;
}

void PLCDevice::setConnectionCycleTime(int cycleTime)
{
	m_cycleTime = cycleTime * 1000;//ms
}

void PLCDevice::setStatusWord(bool flag)
{
	if(flag)
	{
		m_StatusWordSize = 4;
	}
	else
	{
		m_StatusWordSize = 0;
	}
}

void PLCDevice::setPollIntervalMillSec(int ms)
{
	m_pollInterval = ms;
}

void PLCDevice::setNodeNum(int nodeNum)
{
	if(nodeNum < 0)
	{
		throw ConfigException("PLCDevice: illegal NodeNum");
	}
	m_nodeNum = nodeNum;
}

void PLCDevice::setDIChsSize(int startCh, int startAd, int num)
{
	if(num < 0)
	{
		throw ConfigException("PLCDevice: illegal DIChsSize");
	}
	m_DIStartCh = startCh;
	m_DIStartAd = startAd;
	m_DIChsSize = num;
}

void PLCDevice::setDOChsSize(int startCh, int startAd, int num)
{
	if(num < 0)
	{
		throw ConfigException("PLCDevice: illegal DOChsSize");
	}
	m_DOStartCh = startCh;
	m_DOStartAd = startAd;
	m_DOChsSize = num;
}

void PLCDevice::setIntlkDIChsSize(int startCh, int startAd, int num)
{
	if(num < 0)
	{
		throw ConfigException("PLCDevice: illegal IntlkDIChsSize");
	}
	m_IntlkDIStartCh = startCh;
	m_IntlkDIStartAd = startAd;
	m_IntlkDIChsSize = num;
}

void PLCDevice::setIntlkDOChsSize(int startCh, int startAd, int num)
{
	if(num < 0)
	{
		throw ConfigException("PLCDevice: illegal IntlkDOChsSize");
	}
	m_IntlkDOStartCh = startCh;
	m_IntlkDOStartAd = startAd;
	m_IntlkDOChsSize = num;
}

void PLCDevice::setDevNetDIChsSize1(int startCh, int startAd, int num)
{
	if(num < 0)
	{
		throw ConfigException("PLCDevice: illegal DevNetDIChsSize");
	}
	m_DevNetDIStartCh1 = startCh;
	m_DevNetDIStartAd1 = startAd;
	m_DevNetDIChsSize1 = num;
}

void PLCDevice::setDevNetDIChsSize2(int startCh, int startAd, int num)
{
	if(num < 0)
	{
		throw ConfigException("PLCDevice: illegal DevNetDIChsSize");
	}
	m_DevNetDIStartCh2 = startCh;
	m_DevNetDIStartAd2 = startAd;
	m_DevNetDIChsSize2 = num;
}
void PLCDevice::setDevNetDOChsSize(int startCh, int startAd, int num)
{
	if(num < 0)
	{
		throw ConfigException("PLCDevice: illegal DevNetDOChsSize");
	}
	m_DevNetDOStartCh = startCh;
	m_DevNetDOStartAd = startAd;
	m_DevNetDOChsSize = num;
}

void PLCDevice::setMFCOnlineChsSize(int startCh, int startAd, int num)
{
	if(num < 0)
	{
		throw ConfigException("PLCDevice: illegal DevNetDIChsSize");
	}
	m_MFCOnlineStartCh = startCh;
	m_MFCOnlineStartAd = startAd;
	m_MFCOnlineChsSize = num;
}

void PLCDevice::setSpecialAIAOInfo(int channelNum, string info)
{
	AIAOInfo tmp;
	vector<string> infos;
	//split(info,";",infos);
	size_t len = 0;
	size_t pos = info.find_first_of(":");
	while(pos != string::npos)
	{
		len = info.size();
		infos.push_back(info.substr(0,pos));
		info = info.substr(pos+1,len-pos);	
		pos = info.find_first_of(":");
	}
	if(infos.size() != 8)
	{
		throw ConfigException("setSpecialInfo " + Converter::convertToString(channelNum) + " error.");
	}
	
	tmp.channelNum=channelNum;
	tmp.type=infos[1];
	tmp.mode=infos[2];
	Converter::stringToInt(tmp.startAddr,infos[3]);//atoi(infos[2].c_str());
	Converter::stringToInt(tmp.addrLength,infos[4]);//atoi(infos[3].c_str());
	Converter::stringToDouble(tmp.min,infos[5]);//atof(infos[4].c_str());
	Converter::stringToDouble(tmp.max,infos[6]);//atof(infos[5].c_str());
	Converter::stringToDouble(tmp.maxBinaryValue,infos[7]);
	tmp.offsetFlag = false;
	tmp.offset1 = 0;
	tmp.offset2 = 0;
    m_mapAIAOInfo.insert(pair<int,AIAOInfo>(channelNum,tmp));
}

void PLCDevice::setMFCAIAOInfo(int channelNum, string info)
{
    AIAOInfo tmp;
	vector<string> infos;
	//split(info,";",infos);
	size_t len = 0;
	size_t pos = info.find_first_of(":");
	while(pos != string::npos)
	{
		len = info.size();
		infos.push_back(info.substr(0,pos));
		info = info.substr(pos+1,len-pos);	
		pos = info.find_first_of(":");
	}
	if(infos.size() != 8)
	{
		throw ConfigException("setMFCInfo " + Converter::convertToString(channelNum) + " error.");
	}
	
	tmp.channelNum=channelNum;
	tmp.type=infos[1];
	tmp.mode=infos[2];
	Converter::stringToInt(tmp.startAddr,infos[3]);//atoi(infos[2].c_str());
	Converter::stringToInt(tmp.addrLength,infos[4]);//atoi(infos[3].c_str());
	Converter::stringToDouble(tmp.min,infos[5]);//atof(infos[4].c_str());

    size_t pos_path = m_configDir.find_last_of('/');
    if (pos_path != (string(m_configDir).length() - 1)) // '/' is the last letter
	{
		m_configDir = m_configDir + "/";
	}
    
    string path = m_configDir + infos[6] + ".xml";
    ifstream file;
    file.open(path.c_str(),ios::in);
	if(!file.is_open())
	{
		file.close();
		cout<<"PLCDevice:: setMFCInfo is exists, file: "<<endl;
	}
    string ss;
    stringstream s;
    s<<file.rdbuf();
	ss = s.str();

	Converter::stringToDouble(tmp.max,ss);//atof(infos[5].c_str());
	Converter::stringToDouble(tmp.maxBinaryValue,infos[7]);
	tmp.offsetFlag = false;
	tmp.offset1 = 0;
	tmp.offset2 = 0;
    m_mapAIAOInfo.insert(pair<int,AIAOInfo>(channelNum,tmp));
}

// set the path of epitool config directory
void PLCDevice::setConfigDir(const string &path)
{
	if (m_configDir.empty() && !path.empty())
	{
		vector<string> vstr = IStringList::split(path, "/",true);
		for (unsigned int i = 0; i < vstr.size(); ++i)
		{
			m_configDir += ("/" + vstr[i]);
            
		}
	}
}

void PLCDevice::setDoubleOffSetInfo(int channelNum, double offset1, double offset2)
{
	miter it = m_mapAIAOInfo.find(channelNum);
	
	if(it == m_mapAIAOInfo.end())
	{
		throw ConfigException("setDoubleOffSetInfo " + Converter::convertToString(channelNum) + " error.");
	}
	m_mapAIAOInfo[channelNum].offsetFlag = true;
	m_mapAIAOInfo[channelNum].offset1 = offset1;
	m_mapAIAOInfo[channelNum].offset2 = offset2;
}

void PLCDevice::setPTRange(int channelNum, double min, double max)
{
    miter it = m_mapAIAOInfo.find(channelNum);
	
	if(it == m_mapAIAOInfo.end())
	{
		throw ConfigException("setDoubleOffSetInfo " + Converter::convertToString(channelNum) + " error.");
	}
    m_mapPTmin.insert(pair<int,double>(channelNum,min));
    m_mapPTmax.insert(pair<int,double>(channelNum,max));
}

void PLCDevice::setOffSetInfo(int channelNum, double offset)
{
	miter it = m_mapAIAOInfo.find(channelNum);
	
	if(it == m_mapAIAOInfo.end())
	{
		throw ConfigException("setOffSetInfo " + Converter::convertToString(channelNum) + " error.");
	}
	m_mapAIAOInfo[channelNum].offsetFlag = true;
	m_mapAIAOInfo[channelNum].offset1 = offset;
}

bool PLCDevice::readBit(int channelNum, int *bit, const IntTypeInfo &typeInfo)
{
	if (isSimulated())
	{
		struct timeval tm;
		struct timezone *tz = NULL;
		
		gettimeofday(&tm,tz);
		//*bit = tm.tv_usec % 2;
		return true;
	}
	
	bool result = false;
	int byteno = 0;
	int bitno = 0;
	unsigned int movebit = 0;
	int temp = 0;
	unsigned int dd = 0;
	
	if((channelNum >= m_DIStartCh)&&(channelNum < (m_DIStartCh + m_DIChsSize)))//DI
	{
		byteno = (channelNum - m_DIStartCh + m_DIStartAd*16) / 8;
		bitno = (channelNum - m_DIStartCh + m_DIStartAd*16) % 8;
	}
	else if((channelNum >= m_IntlkDIStartCh)&&(channelNum < (m_IntlkDIStartCh + m_IntlkDIChsSize)))//IntlkDI
	{
		byteno = (channelNum - m_IntlkDIStartCh + m_IntlkDIStartAd*16) / 8;
		bitno = (channelNum - m_IntlkDIStartCh + m_IntlkDIStartAd*16) % 8;
	}
	else if((channelNum >= m_DevNetDIStartCh1)&&(channelNum < (m_DevNetDIStartCh1 + m_DevNetDIChsSize1)))//DevNetDI
	{
		byteno = (channelNum - m_DevNetDIStartCh1 + m_DevNetDIStartAd1*16) / 8;
		bitno = (channelNum - m_DevNetDIStartCh1 + m_DevNetDIStartAd1*16) % 8;
	}
	else if((channelNum >= m_DevNetDIStartCh2)&&(channelNum < (m_DevNetDIStartCh2 + m_DevNetDIChsSize2)))//DevNetDI
	{
		byteno = (channelNum - m_DevNetDIStartCh2 + m_DevNetDIStartAd2*16) / 8;
		bitno = (channelNum - m_DevNetDIStartCh2 + m_DevNetDIStartAd2*16) % 8;
	}
	else if((channelNum >= m_MFCOnlineStartCh)&&(channelNum < (m_MFCOnlineStartCh + m_MFCOnlineChsSize)))//MFCOnlineDI
	{
		byteno = (channelNum - m_MFCOnlineStartCh + m_MFCOnlineStartAd*16) / 8;
		bitno = (channelNum - m_MFCOnlineStartCh + m_MFCOnlineStartAd*16) % 8;
	}
	else
		return false;
	
	movebit = 1 << bitno;
	byteno = byteno + m_StatusWordSize;
	result = m_eip->getBytesInputsData(byteno, 1, (void *)&temp);
	if(!result)
		return false;
	dd = ((unsigned int)temp) & movebit;
	int value = dd >> bitno;
	if(value == 0 || value == 1)
	{
		*bit = value;
		return true;
	}
	else
		return false;
}

bool PLCDevice::writeBit(int channelNum, int bit, const IntTypeInfo &typeInfo)
{
	if (isSimulated())
	{
		return true;
	}
	
	if(bit < 0 || bit > 1)
	{
		return false;
	}
	bool result;
	int byteno = 0;
	int bitno = 0;
	
	if((channelNum >= m_DOStartCh)&&(channelNum < (m_DOStartCh + m_DOChsSize)))//DO
	{
		byteno = (channelNum - m_DOStartCh + m_DOStartAd*16) / 8;
		bitno = (channelNum - m_DOStartCh + m_DOStartAd*16) % 8;
	}
	else if((channelNum >= m_IntlkDOStartCh)&&(channelNum < (m_IntlkDOStartCh + m_IntlkDOChsSize)))//IntlkDO
	{
		byteno = (channelNum - m_IntlkDOStartCh + m_IntlkDOStartAd*16) / 8;
		bitno = (channelNum - m_IntlkDOStartCh + m_IntlkDOStartAd*16) % 8;
	}
	else if((channelNum >= m_DevNetDOStartCh)&&(channelNum < (m_DevNetDOStartCh + m_DevNetDOChsSize)))//IntlkDO
	{
		byteno = (channelNum - m_DevNetDOStartCh + m_DevNetDOStartAd*16) / 8;
		bitno = (channelNum - m_DevNetDOStartCh + m_DevNetDOStartAd*16) % 8;
	}
	else
		return false;
	
	byteno = byteno + m_StatusWordSize;
	result = m_eip->setBytesOutputsData(byteno, bitno, (void *)&bit, false);
	return result;
}

bool PLCDevice::readIntAI(int channelNum, int *value, const IntTypeInfo &typeInfo)
{
	if (isSimulated())
	{
		struct timeval tm;
		struct timezone *tz = NULL;
		
		gettimeofday(&tm,tz);
		//*value = tm.tv_usec % 2;
		return true;
	}

	bool result;
	int temp = 0;
	miter it = m_mapAIAOInfo.find(channelNum);
	if(it == m_mapAIAOInfo.end())
	{
		return false;
	}
	else
	{
		int addr = m_mapAIAOInfo[channelNum].startAddr * 2 + m_StatusWordSize;
		result = m_eip->getBytesInputsData(addr, m_mapAIAOInfo[channelNum].addrLength * 2, (void *)&temp);//word
		if(!result)
		{
			return false;
		}
		if(temp < typeInfo.getMin())
		{
			*value = typeInfo.getMin();	
		}
		else if(temp > typeInfo.getMax())
		{
			*value = typeInfo.getMax();
		}
		else
			*value = temp;
		return true;
	}
}

bool PLCDevice::writeIntAO(int channelNum, int value, const IntTypeInfo &typeInfo)
{
	if (isSimulated())
	{
		return true;
	}
	bool result;
	miter it = m_mapAIAOInfo.find(channelNum);
	if(it == m_mapAIAOInfo.end())
	{
		return false;
	}
	else
	{
		int addr = m_mapAIAOInfo[channelNum].startAddr * 2 + m_StatusWordSize;
		result = m_eip->setBytesOutputsData(addr, m_mapAIAOInfo[channelNum].addrLength * 2, (void *)&value, true);//word
		return result;
	}
}

bool PLCDevice::readDoubleAIWithOffSet(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	if (isSimulated())
	{
		return true;
	}
	bool result;
	int temp = 0;
	double tempvalue = 0.0;
	miter it = m_mapAIAOInfo.find(channelNum);
	
	if(it == m_mapAIAOInfo.end())
	{
		return false;
	}
	else
	{
		int addr = m_mapAIAOInfo[channelNum].startAddr * 2 + m_StatusWordSize;
		result = m_eip->getBytesInputsData(addr, m_mapAIAOInfo[channelNum].addrLength * 2, (void *)&temp);//word
		
		if(!result)
		{
			return false;
		}
		
		if(m_mapAIAOInfo[channelNum].maxBinaryValue == 1)
		{
			tempvalue = (double)temp;
			if((channelNum == 137) || (channelNum == 138))//UpperCoolingFanSpeedAI, LowerCoolingFanSpeedAI
			{
				if(tempvalue > 50)
				{
					tempvalue += m_mapAIAOInfo[channelNum].offset2;
				}
				else
				{
					tempvalue += m_mapAIAOInfo[channelNum].offset1;
				}
			}
			else
			{
				tempvalue += m_mapAIAOInfo[channelNum].offset1;
			}
		}
		else
		{
			if((m_mapAIAOInfo[channelNum].maxBinaryValue == 10) || (m_mapAIAOInfo[channelNum].maxBinaryValue == 100) || (m_mapAIAOInfo[channelNum].maxBinaryValue == 1000))
			{
				tempvalue = ((double)temp)/m_mapAIAOInfo[channelNum].maxBinaryValue;
				tempvalue += m_mapAIAOInfo[channelNum].offset1;
			}
			else
			{
				if(channelNum == 135)//DomeDualSealPressureAI
				{
					tempvalue = -(((double)temp)/m_mapAIAOInfo[channelNum].maxBinaryValue) *(m_mapAIAOInfo[channelNum].max - m_mapAIAOInfo[channelNum].min) + m_mapAIAOInfo[channelNum].max;
					if(tempvalue > -90)
					{
						tempvalue += m_mapAIAOInfo[channelNum].offset2;
					}
					else
					{
						tempvalue += m_mapAIAOInfo[channelNum].offset1;
					}
				}
				else if(channelNum == 136)//DomeN2PressureAI
				{
					tempvalue = ((((double)temp)/m_mapAIAOInfo[channelNum].maxBinaryValue) *(4.5+0.5)-0.5)*145;//MPa->psi
					if(tempvalue > 80)
					{
						tempvalue += m_mapAIAOInfo[channelNum].offset2;
					}
					else
					{
						tempvalue += m_mapAIAOInfo[channelNum].offset1;
					}
				}
				else if((channelNum >= 153)&&(channelNum <= 156))//WaterFlow
				{
					tempvalue = (((double)temp -3276) / (m_mapAIAOInfo[channelNum].maxBinaryValue-3276)) * (m_mapAIAOInfo[channelNum].max - m_mapAIAOInfo[channelNum].min) + m_mapAIAOInfo[channelNum].min;
					tempvalue += m_mapAIAOInfo[channelNum].offset1;
				}
				else//PT
				{
					tempvalue = (((double)temp) / m_mapAIAOInfo[channelNum].maxBinaryValue) * (m_mapAIAOInfo[channelNum].max - m_mapAIAOInfo[channelNum].min) + m_mapAIAOInfo[channelNum].min;
					tempvalue += m_mapAIAOInfo[channelNum].offset1;
				}	
			}
		}
		
		if(tempvalue < typeInfo.getMin())
		{
			*value = typeInfo.getMin();	
		}
		else if(tempvalue > typeInfo.getMax())
		{
			*value = typeInfo.getMax();
		}
		else
		{
			*value = tempvalue;
		}
		return true;
	}
}

bool PLCDevice::readDomeTempAI(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	ReadWriteDouble* domeTempPtr1  = dynamic_cast<ReadWriteDouble*>(ObjectManager::getInstance()->getObject("/SETUP/"+m_moduleName+"/TempCtrlConfig/cfgDomePyrometer1"));
	if(domeTempPtr1 != NULL)
	{
		setdometemp1 = domeTempPtr1->getValue();
	}
	ReadWriteDouble* domeTempPtr2 = dynamic_cast<ReadWriteDouble*>(ObjectManager::getInstance()->getObject("/SETUP/"+m_moduleName+"/TempCtrlConfig/cfgDomePyrometer2"));
	if(domeTempPtr2 != NULL)
	{
		setdometemp2 = domeTempPtr2->getValue();
	}
	ReadWriteDouble* modifyDomeTempPtr1 = dynamic_cast<ReadWriteDouble*>(ObjectManager::getInstance()->getObject("/SETUP/"+m_moduleName+"/TempCtrlConfig/cfgDomePyrometerCorrect1"));
	if(modifyDomeTempPtr1 != NULL)
	{
		modifydometemp1 = modifyDomeTempPtr1->getValue();
	}
	ReadWriteDouble* modifyDomeTempPtr2 =  dynamic_cast<ReadWriteDouble*>(ObjectManager::getInstance()->getObject("/SETUP/"+m_moduleName+"/TempCtrlConfig/cfgDomePyrometerCorrect2"));
	if(modifyDomeTempPtr2 != NULL)
	{
		modifydometemp2 = modifyDomeTempPtr2->getValue();
	}
	if (isSimulated())
	{
		return true;
	}
	bool result;
	int temp = 0;
	double tempvalue = 0.0;
	miter it = m_mapAIAOInfo.find(channelNum);
	
	if(it == m_mapAIAOInfo.end())
	{
		return false;
	}
	else
	{
		int addr = m_mapAIAOInfo[channelNum].startAddr * 2 + m_StatusWordSize;
		result = m_eip->getBytesInputsData(addr, m_mapAIAOInfo[channelNum].addrLength * 2, (void *)&temp);//word
		
		if(!result)
		{
			return false;
		}
		
		tempvalue = ((double)temp)/m_mapAIAOInfo[channelNum].maxBinaryValue;
        if(isnan(tempvalue))
        {
            cout<<"0 tempvalue is "<<tempvalue<<endl;
            cout<<"0 m_mapInfo[channelNum].maxBinaryValue is "<<m_mapAIAOInfo[channelNum].maxBinaryValue<<endl;
        }
		
		if((tempvalue >= typeInfo.getMin()) && (tempvalue < setdometemp1))
		{
			A1 = typeInfo.getMin();
			A2 = setdometemp1;
			B1 = typeInfo.getMin();
			B2 = modifydometemp1;
		}
		else if((tempvalue >= setdometemp1) && (tempvalue < setdometemp2))
		{
			A1 = setdometemp1;
			A2 = setdometemp2;
			B1 = modifydometemp1;
			B2 = modifydometemp2;			
		}
		else if((tempvalue >= setdometemp2) && (tempvalue <= typeInfo.getMax()))
		{
			A1 = setdometemp2;
			A2 = typeInfo.getMax();
			B1 = modifydometemp2;
			B2 = typeInfo.getMax();				
		}
		
		if((A1 != A2) && (B1 != B2))
		{
			tempvalue = (tempvalue-A1)/(A2-A1)*(B2-B1)+B1;
		}
		if(isnan(tempvalue))
        {
            cout<<"1 (A2-A1)*(B2-B1)+B1 is "<<((A2-A1)*(B2-B1)+B1)<<endl;
            cout<<"1 tempvalue is "<<tempvalue<<endl;
        }
		if(tempvalue < typeInfo.getMin())
		{
			*value = typeInfo.getMin();	
		}
		else if(tempvalue > typeInfo.getMax())
		{
			*value = typeInfo.getMax();
		}
		else
		{
			*value = tempvalue;
		}
		return true;
	}
}

bool PLCDevice::writeDomeTempAO(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
	if (isSimulated())
	{
		return true;
	}

	ReadWriteDouble* domeTempPtr1  = dynamic_cast<ReadWriteDouble*>(ObjectManager::getInstance()->getObject("/SETUP/"+m_moduleName+"/TempCtrlConfig/cfgDomePyrometer1"));
	if(domeTempPtr1 != NULL)
	{
		setdometemp1 = domeTempPtr1->getValue();
	}
	ReadWriteDouble* domeTempPtr2 = dynamic_cast<ReadWriteDouble*>(ObjectManager::getInstance()->getObject("/SETUP/"+m_moduleName+"/TempCtrlConfig/cfgDomePyrometer2"));
	if(domeTempPtr2 != NULL)
	{
		setdometemp2 = domeTempPtr2->getValue();
	}
	ReadWriteDouble* modifyDomeTempPtr1 = dynamic_cast<ReadWriteDouble*>(ObjectManager::getInstance()->getObject("/SETUP/"+m_moduleName+"/TempCtrlConfig/cfgDomePyrometerCorrect1"));
	if(modifyDomeTempPtr1 != NULL)
	{
		modifydometemp1 = modifyDomeTempPtr1->getValue();
	}
	ReadWriteDouble* modifyDomeTempPtr2 =  dynamic_cast<ReadWriteDouble*>(ObjectManager::getInstance()->getObject("/SETUP/"+m_moduleName+"/TempCtrlConfig/cfgDomePyrometerCorrect2"));
	if(modifyDomeTempPtr2 != NULL)
	{
		modifydometemp2 = modifyDomeTempPtr2->getValue();
	}
	bool result;
	int temp = 0;

	miter it = m_mapAIAOInfo.find(channelNum);
	if(it==m_mapAIAOInfo.end())
	{
		return false;
	}
	else
	{
		if((value >= typeInfo.getMin()) && (value < modifydometemp1))
		{
			A1 = typeInfo.getMin();
			A2 = setdometemp1;
			B1 = typeInfo.getMin();
			B2 = modifydometemp1;
		}
		else if((value >= modifydometemp1) && (value < modifydometemp2))
		{
			A1 = setdometemp1;
			A2 = setdometemp2;
			B1 = modifydometemp1;
			B2 = modifydometemp2;			
		}
		else if((value >= modifydometemp2) && (value <= typeInfo.getMax()))
		{
			A1 = setdometemp2;
			A2 = typeInfo.getMax();
			B1 = modifydometemp2;
			B2 = typeInfo.getMax();				
		}
		
		if((A1 != A2) && (B1 != B2))
		{
			value = (value-B1)/(B2-B1)*(A2-A1)+A1;
		}
		
		int addr = m_mapAIAOInfo[channelNum].startAddr * 2 + m_StatusWordSize;
		value = value * m_mapAIAOInfo[channelNum].maxBinaryValue + 0.5;
		temp = (int)value;
			
		result = m_eip->setBytesOutputsData(addr, m_mapAIAOInfo[channelNum].addrLength * 2, (void *)&temp, true);//word
		return result;
	}
}

bool PLCDevice::readDoubleAI(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	if (isSimulated())
	{
		return true;
	}
	bool result;
	int temp = 0;
	float tempvalue = 0.0;
	miter it = m_mapAIAOInfo.find(channelNum);
	
	if(it == m_mapAIAOInfo.end())
	{
		return false;
	}
	else
	{
		int addr = m_mapAIAOInfo[channelNum].startAddr * 2 + m_StatusWordSize;
		result = m_eip->getBytesInputsData(addr, m_mapAIAOInfo[channelNum].addrLength * 2, (void *)&temp);//word
		
		if(!result)
		{
			return false;
		}
		
		if(m_mapAIAOInfo[channelNum].maxBinaryValue == 1)
		{
			tempvalue = (float)temp;
		}
		else if(m_mapAIAOInfo[channelNum].maxBinaryValue > 1)
		{
			if((m_mapAIAOInfo[channelNum].maxBinaryValue == 10) || (m_mapAIAOInfo[channelNum].maxBinaryValue == 100) || (m_mapAIAOInfo[channelNum].maxBinaryValue == 1000))
			{
				tempvalue = ((float)temp)/m_mapAIAOInfo[channelNum].maxBinaryValue;

                if(m_plcname == "PMPLC") // Rotate&Lift Torque special deal,20221107
                {
                    if((channelNum == 5112)||(channelNum == 5113))
                    {
                        if(tempvalue > 3276.8)
                        {
                            tempvalue = tempvalue - 6553.6;
                        }
                    }
                }
			}
			else
			{
				if(m_plcname == "TMPLC")
				{
                    if((channelNum >= 219)&&(channelNum <= 223))// LL,TC,Pump,TM WaterFlow
                    {
                        tempvalue = (((double)temp -3276) / (m_mapAIAOInfo[channelNum].maxBinaryValue-3276)) * (m_mapAIAOInfo[channelNum].max - m_mapAIAOInfo[channelNum].min) + m_mapAIAOInfo[channelNum].min;
                    }
                    else
                    {
					tempvalue = (((float)temp) / m_mapAIAOInfo[channelNum].maxBinaryValue) * (m_mapAIAOInfo[channelNum].max - m_mapAIAOInfo[channelNum].min) + m_mapAIAOInfo[channelNum].min;
                    }
				}
				else
				{
                    if((channelNum == 5108)|| (channelNum == 5109)|| (channelNum == 5110))// CDAPressure 
                    {
                        tempvalue = (((double)temp -3276) / (m_mapAIAOInfo[channelNum].maxBinaryValue-3276)) * (m_mapAIAOInfo[channelNum].max - m_mapAIAOInfo[channelNum].min) + m_mapAIAOInfo[channelNum].min;
                    }
                    else
                    {
                        tempvalue = (((float)temp) / m_mapAIAOInfo[channelNum].maxBinaryValue) * (m_mapAIAOInfo[channelNum].max - m_mapAIAOInfo[channelNum].min) + m_mapAIAOInfo[channelNum].min;
                    }
				}
			}
		}
		else// read float data --- PLC real class
		{
			memcpy(&tempvalue, &temp, 4);
			if(m_plcname == "TMPLC")
			{
				if((channelNum == 217)||(channelNum == 477)||(channelNum == 480))
				{
					tempvalue = tempvalue/10;
				}
				else if((channelNum == 218)||(channelNum == 478)||(channelNum == 481))
				{
					tempvalue = tempvalue/100;
				}
			}
		}
		
		if(tempvalue < typeInfo.getMin())
		{
			*value = typeInfo.getMin();	
		}
		else if(tempvalue > typeInfo.getMax())
		{
			*value = typeInfo.getMax();
		}
		else
		{
			*value = (double)tempvalue;
		}
		return true;
	}
}

bool PLCDevice::writeDoubleAO(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
	if (isSimulated())
	{
		return true;
	}
	bool result;
	int temp = 0;

	miter it = m_mapAIAOInfo.find(channelNum);
	if(it==m_mapAIAOInfo.end())
	{
		return false;
	}
	else
	{
		int addr = m_mapAIAOInfo[channelNum].startAddr * 2 + m_StatusWordSize;
		if(m_mapAIAOInfo[channelNum].maxBinaryValue == 1)
		{
			temp = (int)value;
		}
		else
		{
			if((m_plcname == "PMPLC") && (channelNum >= 2119) && (channelNum <= 2138))
			{
				value = (value + 500) * m_mapAIAOInfo[channelNum].maxBinaryValue;
				temp = (int)value;
			}
			else
			{
				if((m_mapAIAOInfo[channelNum].maxBinaryValue == 10) || (m_mapAIAOInfo[channelNum].maxBinaryValue == 100) || (m_mapAIAOInfo[channelNum].maxBinaryValue == 1000))
				{
					if((m_plcname == "PMPLC") && ((channelNum == 2034) || (channelNum == 2035) || (channelNum == 2098) || (channelNum == 2099) || (channelNum == 2100)))
						value = value + 100;
					else if((m_plcname == "TMPLC") && (((channelNum >= 1093) && (channelNum <= 1095)) || ((channelNum >= 1100) && (channelNum <= 1102))))
						value = value + 100;
					value = value * m_mapAIAOInfo[channelNum].maxBinaryValue;
					temp = (int)value;
				}
				else		
				{
					value = (value / (m_mapAIAOInfo[channelNum].max - m_mapAIAOInfo[channelNum].min)) * m_mapAIAOInfo[channelNum].maxBinaryValue + 0.5;
					temp = (int)value;
				}
			}
		}
		result = m_eip->setBytesOutputsData(addr, m_mapAIAOInfo[channelNum].addrLength * 2, (void *)&temp, true);//word
		return result;
	}
}

void PLCDevice::initChs(DeviceNode<PLCDevice> *node)
{
	for(int i = 0; i < m_DIChsSize; ++i)
	{
		node->registerReadCh(i + m_DIStartCh, &PLCDevice::readBit);
	}
	
	for(int i = 0; i < m_DOChsSize; ++i)
	{
		node->registerWriteCh(i + m_DOStartCh, &PLCDevice::writeBit);
	}
	
	for(int i = 0; i < m_MFCOnlineChsSize; ++i)
	{
		node->registerReadCh(i + m_MFCOnlineStartCh, &PLCDevice::readBit);
	}
	
	for(int i = 0; i < m_IntlkDIChsSize; ++i)
	{
		node->registerReadCh(i + m_IntlkDIStartCh, &PLCDevice::readBit);
	}
	
	for(int i = 0; i < m_IntlkDOChsSize; ++i)
	{
		node->registerWriteCh(i + m_IntlkDOStartCh, &PLCDevice::writeBit);
	}
	
	for(int i = 0; i < m_DevNetDIChsSize1; ++i)
	{
		node->registerReadCh(i + m_DevNetDIStartCh1, &PLCDevice::readBit);
	}

	for(int i = 0; i < m_DevNetDIChsSize2; ++i)
	{
		node->registerReadCh(i + m_DevNetDIStartCh2, &PLCDevice::readBit);
	}
	
	for(int i = 0; i < m_DevNetDOChsSize; ++i)
	{
		node->registerWriteCh(i + m_DevNetDOStartCh, &PLCDevice::writeBit);
	}
	
	map<int,AIAOInfo>::iterator it;
    for(it = m_mapAIAOInfo.begin(); it != m_mapAIAOInfo.end(); ++it)
	{
		if (strcmp((m_mapAIAOInfo[it->first].mode).c_str(),"RW")==0)
		{
			if (strcmp((m_mapAIAOInfo[it->first].type).c_str(),"I")==0)
			{
				node->registerWriteCh(m_mapAIAOInfo[it->first].channelNum, &PLCDevice::writeIntAO);
			} 
			else
			{
				if((m_plcname == "PMPLC") && (m_mapAIAOInfo[it->first].channelNum == 2061))//UpperCoolingFanCtrlTempAO
				{
					node->registerWriteCh(m_mapAIAOInfo[it->first].channelNum, &PLCDevice::writeDomeTempAO);
				}
				else
				{
					node->registerWriteCh(m_mapAIAOInfo[it->first].channelNum, &PLCDevice::writeDoubleAO);
				}
			}	
		} 
		else
		{
			if (strcmp((m_mapAIAOInfo[it->first].type).c_str(),"I")==0)
			{
				node->registerReadCh(m_mapAIAOInfo[it->first].channelNum, &PLCDevice::readIntAI);
			} 
			else
			{
				if(m_mapAIAOInfo[it->first].offsetFlag == true)
				{
					node->registerReadCh(m_mapAIAOInfo[it->first].channelNum, &PLCDevice::readDoubleAIWithOffSet);
				}
				else
				{
					if((m_plcname == "PMPLC") && (m_mapAIAOInfo[it->first].channelNum == 216))//DomeTempAI
					{
						node->registerReadCh(m_mapAIAOInfo[it->first].channelNum, &PLCDevice::readDomeTempAI);
					}
					else
					{
						node->registerReadCh(m_mapAIAOInfo[it->first].channelNum, &PLCDevice::readDoubleAI);
					}
				}
			}	
		}		
	}
}

void PLCDevice::init()
{

	string error = "";
	if(m_nodeNum < 0)
	{
		error = "node number illegal, m_server is " + m_server;
		throw ConfigException(error);
	}	
	if(!isSimulated())
	{
		m_eip = EIPApplication::getEIP(m_server, m_configInstanceId, m_inputInstanceId, m_outputInstanceId, m_cycleTime, error);
		if(m_eip == NULL)
			throw ConfigException(error);
	}
	DeviceNode<PLCDevice> * node = new DeviceNode<PLCDevice>(m_pollInterval,this);
	initChs(node);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
}

IMPLEMENT_DYNAMIC(PLCDevice, AbstractDevice )
BEGIN_MSG_MAP( PLCDevice, AbstractDevice )
	SET_S( setPLCDeviceName, PLCDevice ) 
	SET_S( setServer, PLCDevice ) 
	SET_S( setModuleName, PLCDevice ) 
	SET_III( setConfigInputOutputInstanceID, PLCDevice )  
	SET_I( setConnectionCycleTime, PLCDevice )
	SET_B( setStatusWord, PLCDevice )
	
	SET_I( setPollIntervalMillSec, PLCDevice ) 
	SET_I( setNodeNum, PLCDevice )  
	SET_III( setDIChsSize, PLCDevice )  
	SET_III( setDOChsSize, PLCDevice ) 
	SET_III( setIntlkDIChsSize, PLCDevice )  
	SET_III( setIntlkDOChsSize, PLCDevice ) 
	SET_III( setDevNetDIChsSize1, PLCDevice ) 
	SET_III( setDevNetDIChsSize2, PLCDevice ) 
	SET_III( setDevNetDOChsSize, PLCDevice ) 
	SET_III( setMFCOnlineChsSize, PLCDevice ) 
	SET_IS(setSpecialAIAOInfo, PLCDevice)
	SET_IDD( setDoubleOffSetInfo, PLCDevice ) 
	SET_ID( setOffSetInfo, PLCDevice ) 
	SET_V( init, PLCDevice )
    SET_IS(setMFCAIAOInfo, PLCDevice)
    SET_IDD( setPTRange, PLCDevice ) 
END_MSG_MAP
