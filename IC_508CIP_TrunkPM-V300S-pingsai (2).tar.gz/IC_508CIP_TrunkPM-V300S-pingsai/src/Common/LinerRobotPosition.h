/*
 * LinerRobotPosition.h
 *
 *  Created on: 20210712
 *      Author: lvjiawen
 */

#ifndef SRC_COMMON_LINERROBOTPOSITION_H_
#define SRC_COMMON_LINERROBOTPOSITION_H_

#include "CBase.h"
#include <vector>
#include "ReadWriteInt.h"
#include "ReadOnlyInt.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class LinerRobotPosition: virtual public CBase
{
public:
	LinerRobotPosition();
	virtual ~LinerRobotPosition();

public:
	void setDOState(vector<int> DoList);
	void setDIState(vector<int> DIList);

	void setDO(vector<ReadWriteInt*> DoList);
	void setDI(vector<ReadOnlyInt*> DIList);

public:
	void go();
	bool isAt();

public:
	void simulateArrive();

private:
	vector<int> m_DoState;
	vector<int> m_DIState;

	vector<ReadWriteInt*> m_DO;
	vector<ReadOnlyInt*> m_DI;
};

#endif /* SRC_COMMON_LINERROBOTPOSITION_H_ */
