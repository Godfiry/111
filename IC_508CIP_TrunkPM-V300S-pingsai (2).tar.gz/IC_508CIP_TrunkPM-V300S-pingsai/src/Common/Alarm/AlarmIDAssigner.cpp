/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AlarmIDAssigner.cpp
** Description: 
** Release: 
** Modification history: 
**                   2010-03-06   lijj create
**      
***************************************************************************/
#include "AlarmIDAssigner.h"
#include "AlarmManager.h"
#include "Alarm.h"
#ifdef IAP4_0
using namespace IAP::ALARM;
#endif

using namespace std;

int AlarmIDAssigner::m_id = 0;

AlarmIDAssigner::AlarmIDAssigner()
{
}

AlarmIDAssigner::~AlarmIDAssigner()
{
}

void AlarmIDAssigner::startup()
{
	CmdTarget::startup();
	vector<Alarm*> t_allAlarms = AlarmManager::getInstance()->getAllAlarms();
	map<std::string, int>::const_iterator it = m_alarmIDsMap.begin(); //added by chensc[1.1.57_HotFix3]
	for(unsigned int i=0; i<t_allAlarms.size(); ++i)
	{
		t_allAlarms[i]->setNumber(assignAnID(t_allAlarms[i]->getName()));
	}
}

int AlarmIDAssigner::assignAnID(const std::string &alarmName)
{
	if(m_alarmIDsMap.empty())
	{
		return m_id++;
	}
	else
	{
		if(m_alarmIDsMap.find(alarmName) != m_alarmIDsMap.end())
		{
			return m_alarmIDsMap[alarmName];
		}
		else
		{
			return m_id++;
		}
	}
}

void AlarmIDAssigner::setStartID(int id)
{
	m_id = id;
}

void AlarmIDAssigner::addAlarm(const std::string &alarmName, int alarmID) //added by chensc[1.1.57_HotFix3]
{
	m_alarmIDsMap.insert(pair<string, int>(alarmName, alarmID));
}

IMPLEMENT_DYNAMIC(AlarmIDAssigner, CmdTarget)
	
BEGIN_MSG_MAP( AlarmIDAssigner, CmdTarget )
	SET_I(setStartID, AlarmIDAssigner)
	SET_SI(addAlarm, AlarmIDAssigner) //added by chensc[1.1.57_HotFix3]
END_MSG_MAP
