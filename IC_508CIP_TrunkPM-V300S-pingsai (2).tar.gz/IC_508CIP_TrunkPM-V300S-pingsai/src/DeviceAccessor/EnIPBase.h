/********************************************************************
** Copyright (c) 2019 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: EnIPBase.h
** Description:  
** Release: 1.0
** Modification history:           
** 					2019-05-30   Duq create
**                                                 2019-08-30   Duq update
**                                                 2020-06-04   Duq update
*********************************************************************/

#ifndef ENIPBASE_H_
#define ENIPBASE_H_

#include "Enums.h"
#include <string>
#include <cstring>

//EPATH: get path -- Padded Path (indicated as data type Padded EPATH) and Packed Path (indicated as data type Packed EPATH)
class EnIPPath
{
	public:
		//get Logical Segment  path:C-1.4.2 Logical Segment  16 bits address : (0x21 or 0x25 or 0x31) - 0x00 - 0xPF - 0xpf
		static std::string GetPath(uint16_t* Class, uint16_t Instance, uint16_t* Attribut, bool IsConnectionPoint=false);
		static void Fit(char* path, int &offset, uint16_t value, char code);
};

//CIP head(24bytes) + CIP data(CPF format)
//Table 2-3.1 Encapsulation Packet
//No explicit information to distinguish between a request and a reply
class Encapsulation_Packet
{
	public:
		EncapsulationCommands m_Command;
		uint16_t m_Length;
		uint32_t m_Sessionhandle;
		EncapsulationStatus m_Status;
		char m_SenderContext[8];
		uint32_t m_Options;
		std::string m_Encapsulateddata;
	
	public:
		Encapsulation_Packet(EncapsulationCommands Command, unsigned int Sessionhandle, std::string &Encapsulateddata);
		virtual ~Encapsulation_Packet() {}
		
		bool analysisEncapsulationPacket(std::string &Packet, int &Offset, int Length);
		std::string toByteArray();
};

//CIP data: UCMM SendRRData packet
//paragraph 2-4 Message Router Request/Response Formats
class UCMM_RR_Packet
{
	public:
		uint16_t m_ItemCount;
		CommonPacketItemIdNumbers m_IdemId;
		uint16_t m_DataLength;
		uint8_t m_Service;
		CIPGeneralSatusCode m_GeneralStatus;
		uint8_t m_AdditionalStatus_Size;
		uint16_t* m_AdditionalStatus;
		std::string m_Path;
		std::string m_Data;
	
	public:
		UCMM_RR_Packet(CIPServiceCodes Service, bool IsRequest, std::string &Path, std::string &Data);
		virtual ~UCMM_RR_Packet();
		
		bool analysisUCMMRRPacket(std::string &DataArray, int &Offset, int Lenght);
		std::string toByteArray();
		bool IsService(CIPServiceCodes Service);
};

//forward open config
class ForwardOpen_Config
{
	public:
		//O --->  T : output
		bool IsO2T;
		bool O2T_Exculsive;
		bool O2T_P2P;
		uint8_t O2T_Priority; // Priorit: 0=Low; 1=High; 2=Scheduled; 3=Urgent
		uint16_t O2T_datasize;
		unsigned int O2T_RPI; // 200 ms
		
		//T --->  O : input
		bool IsT2O;
		bool T2O_Exculsive;
		bool T2O_P2P;
		uint8_t T2O_Priority; 
		uint16_t T2O_datasize;
		unsigned int T2O_RPI; // 200 ms
		
	public:
		ForwardOpen_Config(uint16_t InputDataSize, uint16_t OutputDataSize, bool InputP2P, unsigned int cycleTime);
};

//CIP data: Forward Open Packet
//Table 3-5.9  3-5.10 Forward_Open
//class for both request and response
class ForwardOpen_Packet
{
	public:
		bool m_IsLargeForwardOpen;
		// TimeOut (duration) in ms = 2^Priority_TimeTick * Timeout_Ticks
        // So with Priority_TimeTick=10, Timeout_Ticks is ~ the number of seconds
        uint8_t m_Priority_TimeTick;
        uint8_t m_Timeout_Ticks;
        unsigned int m_O2T_ConnectionId;
        unsigned int m_T2O_ConnectionId;

        // Assume only one client in this application
        static uint16_t m_ConnectionSerialNumber;
        static uint16_t m_OriginatorVendorId;
        static unsigned int m_OriginatorSerialNumber;

        // 0 => *4
        uint8_t m_ConnectionTimeoutMultiplier;
        uint8_t m_Reserved[3];
        // It's O2T_API for reply, in microseconde
        unsigned int m_O2T_RPI;
        unsigned int m_O2T_ConnectionParameters; // size OK for ForwardOpen & LargeForwardOpen
        // It's T2A_API for reply
        unsigned int m_T2O_RPI;
        unsigned int m_T2O_ConnectionParameters; // size OK for ForwardOpen & LargeForwardOpen
        // Figure 3-4.2 Transport Class Trigger Attribute
        uint8_t m_TransportTrigger; // Client class 1, cyclic;
        uint8_t m_Connection_Path_Size;
        std::string m_Connection_Path;
		
	private:
		static unsigned int m_ConnectionId;	
	
	public:	
		// Only use for request up to now
        // O2T & T2O could be use at the same time
        // using a Connection_Path with more than 1 reference
        // 1 Path : path is for Consumption & Production
        // 2 Path : First path is for Consumption, second path is for Production.
		ForwardOpen_Packet(std::string &Connection_Path, ForwardOpen_Config* conf, unsigned int* ConnectionId = NULL);
		virtual ~ForwardOpen_Packet() {}
		std::string toByteArray();		
};

//CIP data: Forward Close Packet
//Table 3-5.11 Forward_Open
//class for both request and response
class ForwardClose_Packet
{
	private:
		ForwardOpen_Packet *m_OrignalPkt;
	public:
		ForwardClose_Packet(ForwardOpen_Packet *FwOpen) { m_OrignalPkt = FwOpen; }
		virtual ~ForwardClose_Packet() {}
		std::string toByteArray();
};

//CIP data address item: SequencedAddressItem  +  ConnectedDataItem
//Receive via Udp after a ForwardOpen  ---  class0 and class1  CID and Sequence ID
//Table 3-5.1 – UDP data format for class 0 and class 1
class SequencedAddressItem_Packet
{
	public:
		//data: input packet   datelen:packet len   offset:packet data start address  connectionId:input connectionId  
		static bool analysisGetItem(char *data, int packetlen, int &offset, unsigned int &connectionId);
		//data: output packet   datelen:packet data len   connectionId:output connectionId   sequenceNumber:0,1,2,3....
		static bool fillSendItemPacketHead(char *data, int datelen, unsigned int connectionId, unsigned int sequenceNumber);
		//sequenceNumber:0,1,2,3....
		static void updateSequenceNumber(char *data, unsigned int &sequenceNumber);
};
#endif  /*ENIPBASE_H_*/
