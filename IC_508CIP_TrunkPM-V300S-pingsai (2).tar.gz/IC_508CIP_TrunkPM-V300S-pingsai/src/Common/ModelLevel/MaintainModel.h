#ifndef MAINTAINMODEL_H_
#define MAINTAINMODEL_H_

#include "ControlObjectEX.h"
#include "FunctionalModel.h"
#include "NonBlockingAlarm.h"
#include "BlockingAlarm.h"
#include "ManagedObject.h"
#include "ObjectManager.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "InvalidNameException.h"
#include "RetryException.h"
#include "InterruptException.h"
#endif
#include "ConfigException.h"


#include "RecoveryAction.h"
#ifdef IAP4_0
using namespace IAP::ALARM;
using namespace IAP::CORE;
using namespace IAP;
#endif

class MaintainModel:public ControlObjectEX
{
    DECLARE_DYNAMIC( MaintainModel ) 
    DECLARE_MSG_MAP
    DECLARE_SERVICEINFO_LIST

    class Init : public Service
    {
        DECLARE_DYNAMIC_SERVICE(Init)
        
        public:
            void execute();
    };
    
    class SetOpMode : public Service
    {
        DECLARE_DYNAMIC_SERVICE(SetOpMode)
        
        public:
            void execute();
    };
    
    class Shutdown : public Service
    {
        DECLARE_DYNAMIC_SERVICE(Shutdown)
        
        public:
            void execute();
    };
    class OverrideAction : public RecoveryAction
    {
        private:
            MaintainModel *m_pOwner;

        public:
            virtual bool execute(const Alarm *pAlarm, Recovery *pRecovery);
            void setOwner(MaintainModel *pModel);
            OverrideAction()
            {
                m_pOwner = NULL;
            }
    };

	class SynchronizeClocks : public Service
	{
		DECLARE_DYNAMIC_SERVICE(SynchronizeClocks)

	public:
		void execute();
	};
    
public:
    MaintainModel();
    virtual ~MaintainModel();

	virtual void make();        	                                //add by ps 1.10.0
	void setCurrentEpochTime();                                     //add by ps 1.10.0
	virtual void do_SynchronizeClocks(const std::string& strIP);    //add by ps 1.10.0

    
public://xml
    void setFunctionalModel(std::string &strPath);

public://service
    void call_Init();
    void call_SetOpMode(int nMode, bool override);
    void call_Shutdown();
	void call_SynchronizeClocks();                                  //add by ps 1.10.0


protected://service
    virtual void do_Init();
    virtual void do_SetOpMode(int nMode, bool override = false);
    virtual void do_Shutdown();
    
protected://override
    virtual void initialize();
    
protected:
    bool checkModeAndPostAlarm();//if in maintainMode return true
    bool checkModeByBlackListAndPostAlm(std::list<int> blackList);//if in black list return true
    
protected:
    FunctionalModel * m_pFunctionalModel;
	ServicePtr<SynchronizeClocks> m_sSynchronizeClocks;             //add by ps 1.10.0

    NonBlockingAlarm *m_pServiceFailedAlarm;
    ReadWriteString *m_pErrorDescription;
    ReadWriteString *m_pServiceName;
	ReadWriteDouble* m_pCurrentEpochTime;                           //add by ps 1.10.0
private:
    ServicePtr<Init> m_Init;
    ServicePtr<SetOpMode> m_SetOpMode;
    ServicePtr<Shutdown> m_Shutdown;

private:
    BlockingAlarm * m_pNotInMaintModeAlarm;
    bool m_bOverrideActionRecovery;
    NonBlockingAlarm *m_pFuncModelBusyAlarm;

};

#endif /*MAINTAINMODEL_H_*/
