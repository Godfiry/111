#ifndef NODESCRIPTOREXCEPTION_H_
#define NODESCRIPTOREXCEPTION_H_
#include "TMCException.h"

class NoDescriptorException : public TMCException
{
    public:
		NoDescriptorException(const std::string &err) : TMCException(err) {}
};
#endif /*NODESCRIPTOREXCEPTION_H_*/
