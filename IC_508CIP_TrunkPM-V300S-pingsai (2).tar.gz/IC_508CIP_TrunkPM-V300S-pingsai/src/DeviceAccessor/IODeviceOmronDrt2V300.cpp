/*
 * IODeviceOmronDrt2V300.cpp
 *
 *  Created on: Sep 19, 2021
 *      Author: weizd
 */

#include "IODeviceOmronDrt2V300.h"

#include "DeviceManager.h"
#include "ConfigException.h"
#include <string.h>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP;
#endif




IODeviceOmronDrt2V300::IODeviceOmronDrt2V300()
{

	//m_nFullScale = 6000;
}

IODeviceOmronDrt2V300::~IODeviceOmronDrt2V300()
{

}

bool IODeviceOmronDrt2V300::setFire(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
	char pBuffer[m_nOutBytesSize];
	memset(pBuffer, 0, m_nOutBytesSize);//
	bool bFlag = m_deviceNet->readByte(m_macID, pBuffer);
	if(!bFlag)
    {
    	return false;
    }
	if(nChannelNum == 0)
	{
		if(nValue == 0)
		{
			pBuffer[0] = pBuffer[0] & 0xFB;
		}
		if(nValue == 1)
		{
			pBuffer[0] = pBuffer[0] | 0x04;
		}
	}
	else if(nChannelNum == 1)
	{
		if(nValue == 0)
		{
			pBuffer[1] = pBuffer[1] & 0xFE;
		}
		if(nValue == 1)
		{
			pBuffer[1] = pBuffer[1] | 0x01;
		}
	}
	else
	{
		throw IOException(getDeviceName() + ": unknown channel num");
	}
	return m_deviceNet->writeByte(m_macID, pBuffer);//only one bit
}

bool IODeviceOmronDrt2V300::readWarning(int nChannelNum, int * pValue, const IntTypeInfo &typeInfo)
{
	char pBuffer[m_nInBytesSize];
	memset(pBuffer, 0, m_nInBytesSize);
    bool bFlag = m_deviceNet->readByte(m_macID, pBuffer);
    *pValue = 1;
    char cTemp;
    if(!bFlag)
    {
    	return false;
    }
    if(nChannelNum == 2)
    {
    	cTemp = pBuffer[0] & 0x01;
    	if(cTemp == 0x00)
    	{
			*pValue = 0;
    	}
    	if(cTemp == 0x01)
    	{
    	    *pValue = 1;
    	}
    }
    else if(nChannelNum == 3)
    {
    	cTemp = pBuffer[0] & 0x02;
    	if(cTemp == 0x00)
    	{
    	    *pValue = 0;
    	}
    	if(cTemp == 0x02)
    	{
    	    *pValue = 1;
    	}
    }
    else
    {
        	throw IOException(getDeviceName() + ": unknown channel num");
    }
    return true;
}

void IODeviceOmronDrt2V300::initDevice()
{
	m_nInBytesSize = m_deviceNet->getIBytesSize(m_macID);
	m_nOutBytesSize = m_deviceNet->getOBytesSize(m_macID);


	if(m_nInBytesSize != IODevice::m_DIChsSize)
	{
		throw ConfigException("MacID "+Converter::convertToString(m_macID)+" InByteSize abnormal "+Converter::convertToString(m_nInBytesSize));
	}

	if(m_nOutBytesSize != IODevice::m_DOChsSize)
	{
		throw ConfigException("MacID "+Converter::convertToString(m_macID)+" OutByteSize abnormal "+Converter::convertToString(m_nOutBytesSize));
	}

}

void IODeviceOmronDrt2V300::init()
{
	DeviceNode<IODeviceOmronDrt2V300> * node = new DeviceNode<IODeviceOmronDrt2V300>(m_pollInterval,this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	if(!isSimulated())
	{
		node->registerWriteCh(0, &IODeviceOmronDrt2V300::setFire);
		node->registerWriteCh(1, &IODeviceOmronDrt2V300::setFire);
		node->registerReadCh(2, &IODeviceOmronDrt2V300::readWarning);
		node->registerReadCh(3, &IODeviceOmronDrt2V300::readWarning);
		node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &IODeviceOmronDrt2V300::getStatus);
		initDeviceNet();
		initDevice();
	}
}

string IODeviceOmronDrt2V300::getDeviceName()
{
	return __FILE__;
}

IMPLEMENT_DYNAMIC(IODeviceOmronDrt2V300, IODevice )
BEGIN_MSG_MAP( IODeviceOmronDrt2V300, IODevice )

END_MSG_MAP
