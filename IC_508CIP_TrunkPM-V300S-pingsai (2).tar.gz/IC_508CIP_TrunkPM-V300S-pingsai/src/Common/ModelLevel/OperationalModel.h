#ifndef OPERATIONALMODEL_H_
#define OPERATIONALMODEL_H_

#include "ControlObjectEX.h"
#include "FunctionalModel.h"
#include "NonBlockingAlarm.h"
#include "BlockingAlarm.h"
#include "SysLogger.h"
#include "ManagedObject.h"
#include "ObjectManager.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "InvalidNameException.h"
#include "RetryException.h"
#include "InterruptException.h"
#endif
#include "ConfigException.h"


#include "RecoveryAction.h"
#ifdef IAP4_0
using namespace IAP::ALARM;
using namespace IAP::CORE;
using namespace IAP;
#endif

class OperationalModel:public ControlObjectEX
{
    DECLARE_DYNAMIC( OperationalModel )
    DECLARE_MSG_MAP
    DECLARE_SERVICEINFO_LIST
    class Init : public Service
    {
        DECLARE_DYNAMIC_SERVICE(Init)
        
        public:
            void execute();
    };
    
    class SetMaintMode : public Service
    {
        DECLARE_DYNAMIC_SERVICE(SetMaintMode)
        
        public:
            void execute();
    };
    
    class SetOpMode : public Service
    {
        DECLARE_DYNAMIC_SERVICE(SetOpMode)
        
        public:
            void execute();
    };
    
    class Shutdown : public Service
    {
        DECLARE_DYNAMIC_SERVICE(Shutdown)
        
        public:
            void execute();
    };
    class OverrideAction : public RecoveryAction
    {
        private:
            OperationalModel *m_pOwner;

        public:
            virtual bool execute(const Alarm *pAlarm, Recovery *pRecovery);
            void setOwner(OperationalModel *pModel);
            OverrideAction()
            {
                m_pOwner = NULL;
            }
    };
    
public:
    OperationalModel();
    virtual ~OperationalModel();
    virtual void defaultAbort();//maxm added for samplify maintianmode 
        

    public:
        bool ifNeedtomakeLearnRcp()const;//added by liusy[1.1.52]
        bool ifProcessAutoLearnEnable()const;
        bool ifDryCleanAutoLearnEnable()const;

public://xml
    void setFunctionalModel(std::string &strPath);
    void setMakeLearnRcpEnable(bool choice);//added by liusy[1.1.52]
    
public://service
    void call_Init();
    void call_SetMaintMode();
    void call_SetOpMode(int nMode, bool override);
    void call_Shutdown();

public:
    bool checkMode_JobService(AlarmPoster *pPoster);//added by xiasc [V1.7.07]
    int getModuleStatus();//for maxm simplify maintMode [v1.0.10]
    void changeModuleStatus(int nMode);
    
    
protected://service
    virtual void do_Init();
    virtual void do_SetMaintMode();
    virtual void do_SetOpMode(int nMode, bool override = false);
    virtual void do_Shutdown();
    
protected://override
    virtual void initialize();
    
protected:
    bool checkModeByWhiteListAndPostAlm(std::list<int> whiteList);//if in white list return true
    bool checkModeByBlackListAndPostAlm(std::list<int> blackList);//if in black list return true
    bool checkMode_JobService();
    
protected:
    FunctionalModel * m_pFunctionalModel;
    NonBlockingAlarm *m_pServiceFailedAlarm;
    ReadWriteString *m_pErrorDescription;
    ReadWriteString *m_pServiceName;
    
private:
    ServicePtr<Init> m_Init;
    ServicePtr<SetMaintMode> m_SetMaintMode;
    ServicePtr<SetOpMode> m_SetOpMode;
    ServicePtr<Shutdown> m_Shutdown;

private:
    BlockingAlarm * m_pInvalidModeAlarm;

    bool m_bOverrideActionRecovery;

    NonBlockingAlarm *m_pFuncModelBusyAlarm;

    bool m_bNeedtomakeLearnRcp; //added by liusy[1.1.52]
    bool m_bProcessAutoLearnEnable; 
    bool m_bDryCleanAutoLearnEnable; 
};

#endif /*OPERATIONALMODEL_H_*/
