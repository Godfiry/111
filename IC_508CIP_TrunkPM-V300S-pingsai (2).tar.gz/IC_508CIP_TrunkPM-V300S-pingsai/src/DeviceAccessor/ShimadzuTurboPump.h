#ifndef ShimadzuTurboPump_H_
#define ShimadzuTurboPump_H_

#include "SerialDevice.h"
#include "IntTypeInfo.h"
#include "IntTypeInfo.h"
#include "DeviceNode.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif
using namespace std;



class ShimadzuTurboPump :public SerialDevice
{
	DECLARE_DYNAMIC(ShimadzuTurboPump)
	DECLARE_MSG_MAP

private:
	typedef struct
	{
		int m_resLen;
		std::string m_cmd;
		int m_ps;
	}Com;

	static Com m_commands[];

protected:
	std::string readCommand(std::string command, int timeOut);
	void initChs(DeviceNode<ShimadzuTurboPump>* node);
	//void initDevice();
public:
	ShimadzuTurboPump();
	virtual ~ShimadzuTurboPump();
	int calculateCheckSum(string command);
	bool readInt(int channelNum, int* value, const IntTypeInfo& typeInfo);
	bool readDouble(int channelNum, double* value, const DoubleTypeInfo& typeInfo);
	void init();
};
#endif /*ShimadzuTurboPump_H_*/
