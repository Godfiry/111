/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AlarmParser.cpp
** Description:  
** Release: 1.1
** Modification history: 
**                  2012-4-12   Lanf create
**      
*********************************************************************/
#include "AlarmParser.h"
#include <iomanip>
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "ConstructFailedException.h"
#include "XMLParseException.h"
#endif
#include "IStringList.h"
#include "SysLogger.h"

#include "Converter.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP;
using namespace IAP::CORE;
#endif
using namespace std;

std::map<std::string,AlarmElement> AlarmParser::Dscs;
AlarmParser* AlarmParser::m_instance = NULL;


AlarmParser::AlarmParser()
{
    try
    {
        XMLPlatformUtils::Initialize();
    }
    catch (const XMLException &err)
    {
        //string msg = string(XStr(err.getMessage()).self());
        //string fatal = "Construct XMLProcessor failed!" + msg;
        //SysLogger::getInstance()->logMsg(LOGBRANCH::RECIPE, LEVEL::FATAL, fatal);
        throw ConstructFailedException("Construct XMLProcessor failed!"+string(XStr(err.getMessage()).self()));
    }
    
    //get 'LS' DOMImplementation
    DOMImplementation *impl = DOMImplementationRegistry::getDOMImplementation(XCh("LS").self());
    
    //the m_parser is a default DOMBuilder:
    //          do not support XML namespace
    //          do not support XML schema
    //          do not support XML schema full checking
    m_parser = impl->createDOMBuilder(DOMImplementationLS::MODE_SYNCHRONOUS, 0); 

    /*             ????????????????
    // And create our error handler and install it
    DOMCountErrorHandler errorHandler;
    parser->setErrorHandler(&errorHandler);
    */
    
    // set features
    m_parser->setFeature(XMLUni::fgDOMEntities, false); // false means substitute entities, NOT append
    
}

AlarmParser::~AlarmParser()
{
    m_parser->release();
    XMLPlatformUtils::Terminate();
}



AlarmParser* AlarmParser::getInstance()
{
    if (m_instance == NULL)
    {
        m_instance = new AlarmParser();
    }
    
    return m_instance;
}

/*!
    This method is used to delete the unique instance of XMLProcessor.
*/
void AlarmParser::shutdown()
{
    size_t pos = m_configDir.find_last_of('/');
    string intlkFileName="";
    if (pos == (m_configDir.length() - 1)) // '/' is the last letter
    {
        intlkFileName = m_configDir + "Control/Interlock/Interlocks.xml";
    }
    else
    {
        intlkFileName = m_configDir + "/Control/Interlock/Interlocks.xml";
    }
    if(remove(intlkFileName.c_str())==0)
    {
        cout<<"remove Interlocks backup successful."<<endl;
    }
    delete m_instance;
    m_instance = NULL;
}

// set the path of IAP app's config directory
void AlarmParser::setConfigDir(const string &path)
{
    if (m_configDir.empty() && !path.empty())
    {
        vector<string> vstr = IStringList::split(path, "/",true);
        for (unsigned int i = 0; i < vstr.size(); ++i)
        {
            m_configDir += ("/" + vstr[i]);
        }
    }
}

DOMNode* AlarmParser::parseXMLFile(const char* const xmlPath)
{
    DOMDocument *doc = NULL;

    try
    {
        // reset document pool
        m_parser->resetDocumentPool();
        
        doc = m_parser->parseURI(xmlPath);
    }
    catch (const XMLException &err)
    {
        string msg = string(XStr(err.getMessage()).self());
        string fatal = "Parse XML file: " + string(xmlPath) + " failed! " + msg;
        SysLogger::getInstance()->logMsg(LOGBRANCH::RECIPE, LEVEL::FATAL, fatal);
        throw XMLParseException(fatal);
    }
    catch (const DOMException &err)
    {
        string fatal = "Parse XML file: " + string(xmlPath) + " failed! ";
        const unsigned int maxChars = 2047;
        XMLCh errText[maxChars + 1];
        if (DOMImplementation::loadDOMExceptionMsg(err.code, errText, maxChars))
        {
            string msg = string((XStr(errText)).self());
            fatal += msg;
        }
        SysLogger::getInstance()->logMsg(LOGBRANCH::RECIPE, LEVEL::FATAL, fatal);
        throw XMLParseException(fatal);
    }
    catch (...)
    {
        string fatal = "Parse XML file: " + string(xmlPath) + " failed!";
        SysLogger::getInstance()->logMsg(LOGBRANCH::RECIPE, LEVEL::FATAL, fatal);
        throw XMLParseException(fatal);
    }
    
    if (doc == NULL)
    {
        string fatal = "Parse XML file: " + string(xmlPath) + " failed! The XML parser created a NULL DOMDocument.";
       SysLogger::getInstance()->logMsg(LOGBRANCH::RECIPE, LEVEL::FATAL, fatal);
        throw XMLParseException(fatal);
    }

    return (DOMNode*)doc->getDocumentElement(); //return the root element node
}

bool AlarmParser::isElementNode(DOMNode *node, const string &n)
{
    //  for internal invocation: 
    //      the input node is not NULL
    //      
    if (n.empty())
    {
        return (node->getNodeType()==DOMNode::ELEMENT_NODE);
    }
    else if (node->getNodeType() == DOMNode::ELEMENT_NODE)
    {
        return (n.compare(XMLString::transcode(node->getNodeName()))==0); //check if the element node has the same name
    }
    
    return false;
}

void AlarmParser::buildAlarmElements()
{
    string xmlFile="";
    size_t pos = m_configDir.find_last_of('/');
    string path="";
    if (pos == (string(m_configDir).length() - 1)) // '/' is the last letter
    {
        xmlFile = m_configDir + "Alarm.xml";
    }
    else
    {
        xmlFile = m_configDir + "/Alarm.xml";
    }
    DOMNode *root_node = parseXMLFile(xmlFile.c_str()); // may throw XMLParseException
    
    if (root_node != NULL) // the first element node in XML doc is NOT NULL.
    {
        XStr str(root_node->getNodeName()); //get name of the node
        if (strcmp(str.self(), "Alarm") == 0) //check if the first node is named after "Control"
        {
            
            for (DOMNode *node = root_node->getFirstChild(); node != NULL; node = node->getNextSibling())
            {                       
//              cout<<"in for loop:"<<endl;
                //if(node==NULL) continue; //[zhangcx v1.5.0 sonar]

                if(isElementNode(node, "Language"))
                {
                    m_lang = XMLString::transcode(node->getTextContent());  
                    m_lang = Util::toUpper(m_lang.append("01").substr(0,2));
                    if(m_lang != "EN")
                        m_lang = "ZH";
                }
                else if(isElementNode(node, "FileName"))
                {
//                  cout<<"file:"<<XMLString::transcode(node->getTextContent())<<endl;
                    m_rcfiles.push_back( XMLString::transcode(node->getTextContent()));
                }
                
            }
        }
        else
        {
            throw XMLParseException("Build namespace failed! The first element node in XML file: '"
                                                            +xmlFile+"' isn't named after 'Control'.");
        }
    }
    else
    {
        throw XMLParseException("Build namespace failed! There is no element node in XML file: '"+xmlFile+"'.");
    }
    
    
    /*if (pos == (string(m_configDir).length() - 1)) // '/' is the last letter
    {
        path=m_configDir+"AlarmInfo/"+m_lang+"/";
    }
    else
    {
        path=m_configDir+"/AlarmInfo/"+m_lang+"/";
    }
    for(unsigned int i=0;i<m_rcfiles.size();i++)
    {
//      cout<<"******************"<<path+m_rcfiles[i]<<endl;
        parseFile(path+m_rcfiles[i]);
    }*/
}

void AlarmParser::parseFile(const std::string &fileName)
{
    ifstream file;
    file.open(fileName.c_str());
    char buf[1024];
    string message;
    string key="";
    string msg="",des="",alarmId="";
    if(file.is_open())
    {
        while(file.good()&&!file.eof())
        {
            memset(buf,0,1024);
            file.getline(buf,1024);
            message=buf;
//          cout<<message<<endl;
            if(message.find("KEY")!=string::npos)
            {
//              cout<<"key"<<endl;
                key=message.substr(4,message.length()-4);
            }
            else if(message.find("MSG")!=string::npos)
            {
//              cout<<"MSG"<<endl;
                msg=message.substr(4,message.length()-4);
//              Msgs.insert(pair<string,string>(key,msg));
            }
            else if(message.find("DES")!=string::npos)
            {
//              cout<<"DEC"<<endl;
                des=message.substr(4,message.length()-4);
//              Dscs.insert(pair<string,string>(key,des));
//              key="";
//              msg="";
//              des="";
            }   
            else if(message.find("ALARMID")!=string::npos)
            {
                alarmId=message.substr(8,message.length()-8);
//              cout<<"alarmParser:alarmId:"<<alarmId<<endl;
                int id;
                if(alarmId.empty()) 
                {
                    id=-1;
                }
                else
                {
                    //id=atoi(alarmId.c_str());
                    Converter::stringToInt(id,alarmId);
                }
//              cout<<"after converter:"<<id;
                AlarmElement element={msg,des,id};
                Dscs.insert(pair<string,AlarmElement>(key,element));
                key="";
                msg="";
                des="";
                alarmId="";
            }       
            else
            {
                if(msg!=""&&des!="")
                {
                    AlarmElement element={msg,des,-1};
                    Dscs.insert(pair<string,AlarmElement>(key,element));
                    key="";
                    msg="";
                    des="";
                    alarmId="";
                }               
            }
        }
        file.close();
    }
    else
    {
        cout<<"file is not open!"<<endl;
    }
}


std::string AlarmParser::getMsg(std::string key)
{
    return Dscs[key].msg;
}

std::string AlarmParser::getDes(std::string key)
{
    return Dscs[key].des;
}

int AlarmParser::getAlarmId(std::string key)
{
    return Dscs[key].id;
}

int AlarmParser::replace(std::string &src_str,const std::string old_str,const std::string new_str)
{
    int old_strlen=old_str.length();
    size_t pos=0;
//  cout<<"in fileparser :replace:"<<src_str<<" "<<old_str<<" "<<new_str<<endl;
    if((pos=src_str.find(old_str,pos))!=string::npos)       
    {
        src_str.replace(pos,old_strlen,new_str);
        pos+=new_str.length();
        return 1;
    }
    return 0;
}

bool AlarmParser::isEnVer()
{
    return (Util::toLower(m_lang.append("01").substr(0,2)) == "en")? true: false ;
}
