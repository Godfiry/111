#ifndef PSDCOLLECTMODEENUM_H_
#define PSDCOLLECTMODEENUM_H_

namespace PSD_COLLECTMODE
{
	enum PSDCollectModeEnum
	{
		CollectAfterStable,
		CollectWholeStep
	};
}

#endif /*MODULESTATUSENUM_H_*/
