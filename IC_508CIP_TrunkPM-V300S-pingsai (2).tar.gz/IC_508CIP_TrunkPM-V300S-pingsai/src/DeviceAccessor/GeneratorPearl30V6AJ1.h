/********************************************************************
** Copyright (c) 2020, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: GeneratorPearl30V6AJ1.h
** Description: This driver is used for Pearl generator of 30V6AJ1
*                RS232
* 				 Communication Type:Modbus protocol,ASCII Mode
* 				 BaudRate:38400
*                DataBit:7
*                StopBit:1
*                Parity:Even
* In the code, we use function code 03 to read ; function code 10 to write
* Slave address is 01 as the default.
*
** Release: 1.1
** Modification history: 
** 					2020-04-20   mayc create
**      
*********************************************************************/
#ifndef GeneratorPearl30V6AJ1_H_
#define GeneratorPearl30V6AJ1_H_

#include "SerialDevice.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class GeneratorPearl30V6AJ1:public SerialDevice
{
	DECLARE_DYNAMIC(GeneratorPearl30V6AJ1)
	DECLARE_MSG_MAP	
	
	public:
		GeneratorPearl30V6AJ1();
		virtual ~GeneratorPearl30V6AJ1();
		
		bool writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo);
		bool readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);
		bool readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);
		bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
		void init();

	protected:
		void initDevice();
		void initChs(DeviceNode<GeneratorPearl30V6AJ1> *pNode);
		string sendCommandAndReadResponse(string &strCommond, int nTimeOut);
		int readAddress0000(int nTimeOut);
	private:
		typedef struct
		{
			std::string m_strAddress;
			int m_nDeal;
		}Cmd;
		
		static Cmd m_cmd[];
		//int m_nAddress0000;
		int m_nFullScale;
};

#endif /*GeneratorPearl30V6AJ1_H_*/
