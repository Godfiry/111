/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: BoshRcpBody.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2014-1-8   LiJuanjuan create
**      
*********************************************************************/
#include "BoshRcpBody.h"
#include "RecipeNamespaceManager.h"
#include "RecipeUser.h"
#include "ControlObjectEX.h"
#include "ObjectManager.h"
#include "RecipeMgmtSession.h"
#include "SysLogger.h"
#include "StrManager.h"
//#include "StringResourceID.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "InvalidParameterException.h"
#endif
#include <iostream>
#include "StrTool.h"  //add by wzd 1.1.21
#include <string> //add by wzd 1.1.21
#include <sstream> //add by wzd 1.1.21
#include "RecipeTypeValueInfo.h"//added by mujy 20250526 for RecipeType Code CIP
#ifdef IAP4_0
using namespace IAP::RECIPE;
using namespace IAP::CORE;
using namespace IAP;
using namespace IAP::IO;
#endif
using namespace std;

BoshRcpBody::BoshRcpBody()
{
	m_currentChildRcpIndex = 0;
	m_currentChildRcpCycle = 0;
	//m_childRcpClass = "/ChildProcess/";
	m_pRecipeType = NULL; //add by wzd 1.1.21
	m_currentChildRcpCycleStep = 0;//added by taohao[1.1.48]
    m_totalProcessTime = 0.0;
}

BoshRcpBody::~BoshRcpBody()
{
}

void BoshRcpBody::ChildRcpBodyMaker::addStep(const ExecRcpHandler &rcpHandler, int nStepInRecipe,int nAddStepNum, int cycleNum, int cycleIdex)  //add by wzd 1.1.21
{
	AppRcpStep t_step;
	t_step.setStepNum(nAddStepNum);
	t_step.setStepName(rcpHandler.getStepName(nStepInRecipe));
	
	for(unsigned int j=1; j<= rcpHandler.getNumOfParams(); ++j)
	{
		ParamValue t_value;
		t_value.Name = rcpHandler.getParamName(j);
		IntValueInfo t_initI;
		IntValueInfo t_finalI;
		DoubleValueInfo t_initD;
		DoubleValueInfo t_finalD;
		size_t t_pos = t_value.Name.find("_Init", 0);  //changed by wzd 1.1.39
		if(t_pos != string::npos)
		{
			t_value.Name = t_value.Name.substr(0, t_pos);
			switch(rcpHandler.getParamType(j))
			{
				case IO::INTDATA:
					t_value.Type = IO::INTDATA;
					rcpHandler.getStepValue(nStepInRecipe, j, t_initI);
					rcpHandler.getStepValue(nStepInRecipe, ++j, t_finalI);
					if(cycleNum == 1)
					{
						t_value.IntValue = t_initI;
					}
					else
					{
						t_value.IntValue = IntValueInfo(t_initI.getValue() + ((t_finalI.getValue() - t_initI.getValue())/(cycleNum-1) )* (cycleIdex-1));
					}
					break;

				case IO::DOUBLEDATA:
					t_value.Type = IO::DOUBLEDATA;
					rcpHandler.getStepValue(nStepInRecipe, j, t_initD);
					rcpHandler.getStepValue(nStepInRecipe, ++j, t_finalD);
					if(cycleNum == 1)
					{
						t_value.DoubleValue = t_initD;
						t_value.finalDoubleValue = t_finalD;  //added by th 1.1.26
					}
					else
					{
						t_value.DoubleValue = DoubleValueInfo(t_initD.getValue() + ((t_finalD.getValue() - t_initD.getValue())/(cycleNum-1)) * (cycleIdex-1));
					}
					break;

				default:
					t_value.Type = IO::UNKNOWN;
					break;
			}

		}
		else
		{
			switch(rcpHandler.getParamType(j))
			{
				case IO::INTDATA:
					t_value.Type = IO::INTDATA;
					rcpHandler.getStepValue(nStepInRecipe, j, t_value.IntValue);
					break;

				case IO::STRINGDATA:
					t_value.Type = IO::STRINGDATA;
					rcpHandler.getStepValue(nStepInRecipe, j, t_value.StringValue);
					break;

				case IO::DOUBLEDATA:
					t_value.Type = IO::DOUBLEDATA;
					rcpHandler.getStepValue(nStepInRecipe, j, t_value.DoubleValue);
					break;

				default:
					t_value.Type = IO::UNKNOWN;
					break;
			}
		}
		t_step.addParam(t_value);
	}
	m_steps.push_back(t_step);
}

void BoshRcpBody::ChildRcpBodyMaker::setRcpName(string strName) //add by wzd 1.1.21
{
	m_rcpName = strName;
	m_rcpClass = "";
}

void BoshRcpBody::ChildRcpBodyMaker::makeBody(const ExecRcpHandler &rcpHandler, int cycleNum, int cycleIdex)
{
	m_rcpName = rcpHandler.getName();
	m_rcpClass = 	rcpHandler.getClass();	

	if(rcpHandler.getNumOfSteps() <= 0)
	{
		throw InvalidParameterException("RecipeType ["+m_rcpClass +"], RecipeName [ "+m_rcpName + "] is null. please check.");
	}
	for(unsigned int i=1; i<= rcpHandler.getNumOfSteps(); ++i)
	{
		AppRcpStep t_step;
		t_step.setStepNum(i);
		t_step.setStepName(rcpHandler.getStepName(i));
								
		for(unsigned int j=1; j<= rcpHandler.getNumOfParams(); ++j)
		{
			ParamValue t_value;		
			t_value.Name = rcpHandler.getParamName(j);
			IntValueInfo t_initI;
			IntValueInfo t_finalI;
			DoubleValueInfo t_initD;
			DoubleValueInfo t_finalD;				
			size_t t_pos = t_value.Name.find("_Init", 0);  //changed by wzd 1.1.39
			if(t_pos != string::npos)
			{
				t_value.Name = t_value.Name.substr(0, t_pos);
				switch(rcpHandler.getParamType(j))
				{
					case IO::INTDATA:
						t_value.Type = IO::INTDATA;
						rcpHandler.getStepValue(i, j, t_initI);
						rcpHandler.getStepValue(i, ++j, t_finalI);
						if(cycleNum == 1)
						{
							t_value.IntValue = t_initI;
						}
						else
						{
							t_value.IntValue = IntValueInfo(t_initI.getValue() + ((t_finalI.getValue() - t_initI.getValue())/(cycleNum-1) )* (cycleIdex-1));
						}
						break;
						
					case IO::DOUBLEDATA:
						t_value.Type = IO::DOUBLEDATA;
						rcpHandler.getStepValue(i, j, t_initD);
						rcpHandler.getStepValue(i, ++j, t_finalD);
						if(cycleNum == 1)
						{
							t_value.DoubleValue = t_initD;
						}
						else
						{						
							t_value.DoubleValue = DoubleValueInfo(t_initD.getValue() + ((t_finalD.getValue() - t_initD.getValue())/(cycleNum-1)) * (cycleIdex-1));
						}
						break;
						
					default:
						t_value.Type = IO::UNKNOWN;
						break;
				}				
				
			}
			else
			{
				switch(rcpHandler.getParamType(j))
				{
					case IO::INTDATA:
						t_value.Type = IO::INTDATA;
						rcpHandler.getStepValue(i, j, t_value.IntValue);
						break;
						
					case IO::STRINGDATA:
						t_value.Type = IO::STRINGDATA;
						rcpHandler.getStepValue(i, j, t_value.StringValue);
						break;
						
					case IO::DOUBLEDATA:
						t_value.Type = IO::DOUBLEDATA;
						rcpHandler.getStepValue(i, j, t_value.DoubleValue);
						break;
						
					default:
						t_value.Type = IO::UNKNOWN;
						break;
				}	
			}		
			t_step.addParam(t_value);
		}		
		m_steps.push_back(t_step);
	}	
}

void BoshRcpBody::clear()
{
	AppRcpBody::clear();
	m_childRcps.clear();
	m_currentChildRcpIndex = 0;
	m_currentChildRcpCycle = 0;
}

void BoshRcpBody::makeGroupBody(const ExecRcpHandler &rcpHandler)  //add by wzd 1.1.21
{
	RecipeMgmtSession *t_session = RecipeNamespaceManager::buildSession(this, "BoshRcpBody");

	m_rcpName = rcpHandler.getName();
	m_rcpClass = 	rcpHandler.getClass();

	for(unsigned int i=1; i<= rcpHandler.getNumOfSteps(); ++i)
	{
		//rcpHandler.getParamName(1)=="";
		int nIsGroup;
		int nCycleNum;
		string strGroupName;

		IntValueInfo IsGroup;
		IntValueInfo CycleNum;
		IntValueInfo GroupName;

		rcpHandler.getStepValue(i, "RampMode", IsGroup);
		rcpHandler.getStepValue(i, "CycleNum", CycleNum);
		rcpHandler.getStepValue(i, "GroupName", GroupName);

		nIsGroup=IsGroup.getValue();
		nCycleNum=CycleNum.getValue();
		if(GroupName.getValue() == 0)
		{
			strGroupName = "None";
		}
		else
		{
			stringstream st;
			st<<GroupName.getValue();
			//strGroupName = "Group";
			strGroupName = "Group" + st.str();
		}
		
		if(nIsGroup == 0 || nIsGroup == 2)
		{
			vector<AppRcpBody> childRcp;
			ChildRcpBodyMaker childRcpBody;
			childRcpBody.addStep(rcpHandler, i, 1, 1, 0);
			childRcpBody.setRcpName(strGroupName);
			childRcp.push_back(childRcpBody);
			m_childRcps.push_back(childRcp);
		}
		else
		{
			int nPartStart = i;
			int nPartEnd = i;
			for(int j = i ;j<= rcpHandler.getNumOfSteps(); ++j)
			{
				IntValueInfo TempGroupName;
				rcpHandler.getStepValue(j, "GroupName", TempGroupName);
				string strTempGroupName;
				//if(TempGroupName.getValue() == 0)
				//{
					//strTempGroupName = "None";
				//}
				//else
				//{
					stringstream Tempst;
					Tempst<<TempGroupName.getValue();
					//cout<<Tempst.str()<<endl;
					strTempGroupName = "Group" + Tempst.str();
				//}
				//cout<<strTempGroupName<<endl;
				if(strTempGroupName != strGroupName)
				{
					 break;
				}
				else
				{
					nPartEnd = j;
				}
			}
			int nStepNum=nPartEnd - nPartStart + 1 ;
			vector<AppRcpBody> childRcp;
			for(int j = 1; j <= nCycleNum; ++j)
			{
				ChildRcpBodyMaker childRcpBody;
				for(int nStepID = 1 ; nStepID <= nStepNum ; ++nStepID)
				{
					//void addStep(const ExecRcpHandler &rcpHandler, int nStepInRecipe,int nAddStepNum, int cycleNum, int cycleIdex);
					childRcpBody.addStep(rcpHandler, i + nStepID -1 , nStepID, nCycleNum, j);
				}
				childRcpBody.setRcpName(strGroupName);
				childRcp.push_back(childRcpBody);
			}
			m_childRcps.push_back(childRcp);

			i = nPartEnd;
		}
	}
	t_session->clear();
	RecipeNamespaceManager::closeSession(&t_session);	
	m_totalProcessTime = getTotalProcessTime();//added by mujy[v1.5.17]
	setCurrentChildRcp(1);
	setCurrentCycle(1);
}

void BoshRcpBody::makeChildBody(const ExecRcpHandler &rcpHandler)  //changed by wzd 1.1.21
{
	RecipeMgmtSession *t_session = RecipeNamespaceManager::buildSession(this, "BoshRcpBody");
	ExecRcpHandler t_childRcpHandler;	
	try
	{
		AppRcpBody::makeBody(rcpHandler);
		int t_cycle = 0;
		string t_childRcpName = "";
		string t_childRcpPath = "";	
		string t_childClass = rcpHandler.getClass();	
		t_childClass = t_childClass.substr(1,t_childClass.size()-1);
		for(int i=1; i<=getStepSize(); ++i)
		{
			vector<AppRcpBody> t_childRcp;
			t_cycle = getStep(i).getParamValue("Cycle").IntValue.getValue();
			t_childRcpName = getStep(i).getParamValue("Child" + t_childClass +"Name").StringValue.getValue();
			/*if(t_cycle > 1)
			{
				t_childRcpPath = "/ChildBosh" + t_childClass + "/"+ t_childRcpName + ";1";
			}
			else
			{*/
				t_childRcpPath = "/Child" + t_childClass + "/"+ t_childRcpName + ";1";
			//}
			RecipeMgmtSession::CriticalZone cz;
			t_childRcpHandler = t_session->retrieveRecipe(t_childRcpPath, false); // <><><> retrieve recipe as shared		
			for(int j=1; j<=t_cycle; ++j)
			{
				ChildRcpBodyMaker t_childRcpBody;
				t_childRcpBody.makeBody(t_childRcpHandler, t_cycle, j);	
				t_childRcp.push_back(t_childRcpBody);		
			}	
			m_childRcps.push_back(t_childRcp);
			t_session->releaseRecipe(t_childRcpHandler);
		}
		t_session->clear();
		RecipeNamespaceManager::closeSession(&t_session);	
		m_totalProcessTime = getTotalProcessTime();//added by mujy[v1.5.17]
		setCurrentChildRcp(1);
		setCurrentCycle(1);
	}
	catch(const exception &ex)
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "BoshRcpBody::makeBody got exception- " + string(ex.what()) );				
		if(t_session != NULL)
		{
			t_session->releaseRecipe(t_childRcpHandler);
			t_session->clear();
			RecipeNamespaceManager::closeSession(&t_session);	
		}		
		throw;//added by xiasc[20180915]		
	}
}

void BoshRcpBody::makeBody(const ExecRcpHandler &rcpHandler)  //changed by wzd 1.1.21
{
	if(RecipeTypeValueInfo::getInstance()->isGroupRecipe())//changed by mujy 20250526 for RecipeType Code CIP
	{
		makeGroupBody(rcpHandler);
	}
	else
	{
		makeChildBody(rcpHandler);
	}
}

/*AppRcpStep BoshRcpBody::getStep(int index)const
{
	if(m_currentChildRcpIndex == 0)
	{
		return AppRcpBody::getStep(index);
	}
	if((m_currentChildRcpIndex < 1 ||m_currentChildRcpIndex > getChildRcpSize()) || (m_currentChildRcpCycle < 1 ||m_currentChildRcpCycle > getChildRcpCycleNum()))//added by xiasc[v1.7.03]
	{
		throw InvalidParameterException("Current recipe index or recipe cycle is invalid.");
	}
	return m_childRcps[m_currentChildRcpIndex-1][m_currentChildRcpCycle-1].getStep(index);
}*/

AppRcpStep BoshRcpBody::getStep(int index)const
{
	if(m_currentChildRcpIndex == 0)
	{
		return AppRcpBody::getStep(index);
	}
	if((m_currentChildRcpIndex < 1 ||m_currentChildRcpIndex > getChildRcpSize()) || (m_currentChildRcpCycle < 1 ||m_currentChildRcpCycle > getChildRcpCycleNum()))//added by xiasc[v1.7.03]
	{
		throw InvalidParameterException("Current recipe index or recipe cycle is invalid.");
	}
	int tmpCurrentRecipeStepSize = m_childRcps[m_currentChildRcpIndex-1][m_currentChildRcpCycle-1].getStepSize();
	if(index > tmpCurrentRecipeStepSize)
	{
		if(m_currentChildRcpIndex + index - 1 > m_childRcps.size())
		{
			throw InvalidParameterException("Current recipe index or step index is invalid.");
		}
		else
		{
			////get step  from other recipe basing on m_currentChildRcpIndex for group recipe mode
			//m_childRcps[[[step1]],[[step2]],[[step3,step4],[step3,step4]],[[step5]]]
			if(m_childRcps[m_currentChildRcpIndex - 1].size() == 1 && m_childRcps[m_currentChildRcpIndex].size()>1)
			{
				//eg: when index = 3 and current step is step2,the method is to get step4
				if(index-1 > m_childRcps[m_currentChildRcpIndex].size())
				{
					throw InvalidParameterException("Current bosh recipe index is invalid.");
				}
				else
				{
					return m_childRcps[m_currentChildRcpIndex][0].getStep(index-1);
				}

			}
			else
			{
				//eg: when index = 2 and current step is step1,the method is to get step2
				return m_childRcps[m_currentChildRcpIndex + index - 2][0].getStep(1);
			}

		}
	}
	else
	{
		return m_childRcps[m_currentChildRcpIndex-1][m_currentChildRcpCycle-1].getStep(index);
	}
}

int BoshRcpBody::getStepSize()const
{
	if(m_currentChildRcpIndex == 0)
	{
		return AppRcpBody::getStepSize();
	}
	if(m_currentChildRcpIndex <1 || m_currentChildRcpIndex > getChildRcpSize())//added by xiasc[v1.7.03]
	{
		//string str;
		//str=StrManager::getInstance()->GetString(APPRCPBODY_STEPNUM_INVALID);
		throw InvalidParameterException("Current recipe index is invalid.");
	}
	return m_childRcps[m_currentChildRcpIndex-1][0].getStepSize();
}

int BoshRcpBody::getRcpAllStepNum()const  //added by taohao[1.1.48]
{
    int nRcpAllStepNum = 0;
    for(int i=0;i<m_childRcps.size();i++)
    {
    	nRcpAllStepNum += m_childRcps[i][0].getStepSize();
    }
	return nRcpAllStepNum;
}

int BoshRcpBody::getCurrentStepIndex()const//added by taohao[1.1.48]
{
    int nCurrentStepIndex = 0;

    for(int i=0;i<m_currentChildRcpIndex;i++)
    {
        nCurrentStepIndex += m_childRcps[i][0].getStepSize() + m_currentChildRcpCycleStep;
    }
	return nCurrentStepIndex;
}
//add by xiezr 1.1.26
int BoshRcpBody::getPredecessorStepSize(int nChildIndex)
{
    int nAllPreStepSize = 0;
    for(int i=0;i<nChildIndex;i++)//modified by mujy for Bug 77425 [1.8.0]
    {
    	nAllPreStepSize += m_childRcps[i][0].getStepSize();
    }
    return nAllPreStepSize;
}
int BoshRcpBody::getChildRcpCycleNum()const
{
	if(m_currentChildRcpIndex == 0)
	{
		return 0;
	}
	if(m_currentChildRcpIndex < 1 || m_currentChildRcpIndex > getChildRcpSize())//added by xiasc[v1.7.03]
	{
		//string str;
		//str=StrManager::getInstance()->GetString(APPRCPBODY_STEPNUM_INVALID);
		throw InvalidParameterException("Current recipe index is invalid.");
	}	
	return m_childRcps[m_currentChildRcpIndex-1].size();
}

std::string BoshRcpBody::getChildRcpName() const
{
	if(m_currentChildRcpIndex == 0)
	{
		return "";
	}
	if(m_currentChildRcpIndex < 1 || m_currentChildRcpIndex > getChildRcpSize())//added by xiasc[v1.7.03]
	{
		//string str;
		//str=StrManager::getInstance()->GetString(APPRCPBODY_STEPNUM_INVALID);
		throw InvalidParameterException("Current recipe index is invalid.");
	}	
	return m_childRcps[m_currentChildRcpIndex-1][0].getRcpName();
}

int BoshRcpBody::getChildRcpSize() const
{
	return m_childRcps.size();
}
		
void BoshRcpBody::setCurrentChildRcp(int index)
{
	m_currentChildRcpIndex = index;
}

void BoshRcpBody::setCurrentCycle(int cycle)
{
	m_currentChildRcpCycle = cycle;
}

void BoshRcpBody::setCurrentCycleStep(int step)//added by taohao[1.1.48]
{
	m_currentChildRcpCycleStep = step;
}
double BoshRcpBody::getLeftProcessTime(int step)const //added by mujy[v1.5.17]
{
	int nStepCounter = 0;

	for(int i = 1; i <= m_currentChildRcpIndex-1; i++)
	{
		nStepCounter += m_childRcps[i-1].size() * m_childRcps[i-1][0].getStepSize();
	}
	if(m_currentChildRcpCycle > 1)
	{
		nStepCounter += (m_currentChildRcpCycle-1)*m_childRcps[m_currentChildRcpIndex-1][0].getStepSize();
	}
	nStepCounter += step;
	return m_totalProcessTime - m_leftProcessTime[nStepCounter-1];
}

double BoshRcpBody::getTotalProcessTime()//added by mujy[v1.5.17]
{
	m_leftProcessTime.clear();
	m_leftProcessTime.push_back(0);
	double dToaltime = 0;
	for(int i=1; i<=getChildRcpSize();++i)
	{
		setCurrentChildRcp(i);
		for(int j=1; j<=getChildRcpCycleNum(); ++j)
		{
			setCurrentCycle(j);
			for(int n=1; n<=getStepSize(); ++n)
			{
				dToaltime += getStep(n).getParamValue("ProcessTime").DoubleValue.getValue();
				m_leftProcessTime.push_back(dToaltime);
			}
		}
	}
	setCurrentChildRcp(1);
	setCurrentCycle(1);
	return dToaltime;
}

/*
// Reserved interface, Need Test
int BoshRcpBody::getCurrentChildRcpIndex() const     //huoxb [v1.1.43]
{
	return m_currentChildRcpIndex;
}

// Reserved interface, Need Test
AppRcpStep BoshRcpBody::getChildRcpStep(int index, int cycle)     //huoxb [v1.1.43]
{
	if(index < 1 ||index > getChildRcpSize() || cycle < 1 || cycle > m_childRcps[index-1].size())
	{
		throw InvalidParameterException("recipe index or recipe cycle is invalid.");
	}
	return m_childRcps[index-1][cycle-1].getStep(1);
}
*/
