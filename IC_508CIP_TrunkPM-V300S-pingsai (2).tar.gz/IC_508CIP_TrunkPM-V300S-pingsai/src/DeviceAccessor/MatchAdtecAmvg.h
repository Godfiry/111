/********************************************************************
** Copyright (c) 2020, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MatchAdtecAmvg.h
** Description:
** Release: 1.1
** Modification history:
** 					2020-2-7   zhangyy create
**
** Product type: Adtec Match AMVG-300-QS
** Device communication setting:
** 			Control mode:      RS232C
**     	BaudRate:          9600 bps
**   		Character length:  8 bit
**  		Stop bit length:   1 bit
**			Parity checking:   None
*********************************************************************/
#ifndef MATCHADTECAMVG_H_
#define MATCHADTECAMVG_H_
#include "SerialDevice.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#include "StringTypeInfo.h"
#include "ReadWriteDouble.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class MatchAdtecAmvg : public SerialDevice
{
    DECLARE_DYNAMIC(MatchAdtecAmvg)
    DECLARE_MSG_MAP
public:
    MatchAdtecAmvg();
    virtual ~MatchAdtecAmvg();

public:
    bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
    bool writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo);
    bool readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);
    bool readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);
    bool readDCBias(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);

	virtual std::string getDeviceName();

public://xml
	void init();

protected:
	 void initDevice();
	 void InitChannels(DeviceNode<MatchAdtecAmvg> *pNode);
	 int SubAndConvert(std::string strSource, int nSubStartPos, int nSubLength);
	 bool CheckValidity(std::string strSource, std::string strKeyCommand);

private:
    typedef struct
	 {
    	int nType;
    	std::string strCmd;
    	int nReserved;
	 }Cmd;	 
	 typedef struct
	 {
	 	 int nSubStartPos;
		 std::string strCmd;
		 int nSubLength;
		 int nCorrectResponseLen;
		 int nRetryTime;
	 }ReadCmd;	 
	 static Cmd m_commands[];
	 static ReadCmd m_readCommands[];
	 int m_nReadTimeOut;// 1/10 s
	 int m_nPreC1;
	 int m_nPreC2;
};

#endif /*MATCHADTECAMVG_H_*/
