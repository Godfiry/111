/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: OutofRangeException.h
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-03-17   LiJuanjuan create
**      
*********************************************************************/
#ifndef OUTOFRANGEEXCEPTION_H_
#define OUTOFRANGEEXCEPTION_H_

#include "TMCException.h"

class OutofRangeException:public TMCException
{
	public:
		OutofRangeException(const std::string &s);
};

#endif /*OUTOFRANGEEXCEPTION_H_*/
