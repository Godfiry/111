/******************************************************************************
 ** Date: 2018-10-23 
 ** File name: ChillerJulaboFP50.cpp 
 ** Author: Zhang Yuanyuan
 ** product module: Julabo FP50-ME Refrigerated/Heating Circulator  
 ** Device communication setting:
     		BaudRate:  4800
     		CharSize:   7
			StopBit:    1
			Parity:     1 (Even check)
 ** Modification history:  
 ** 			2018-10-23   Zhangyy create
 ******************************************************************************/
#include "ChillerJulaboFP50.h"
#include "DeviceManager.h"
#include "Converter.h"
#include <sys/time.h>

#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std;

string ChillerJulaboFP50::m_commands[] = {
		                            "out_sp_00",   // 0, Set Temperature
		                            "in_pv_00",    // 1, Read actual bath Temperature
		                            "out_mode_05", // 2, Param =0:Stop Chiller; Param =1:Start Chiller
		                            "out_mode_04", // 3, Set control mode. Param =0:internal bath control, Param =1:external Pt100 sensor control
									"in_mode_05",  // 4, Read Chiller in Stop(Response=0) or Start(Response=1) condition
									"status",		 // 5, Read Manual or Remote
									"in_mode_04",  // 6, Read Chiller in internal control(Response=0) or external Pt100 sensor control(Response=1)
									"status",      // 7, Read Alarm
									"in_pv_02"     // 8, Read Temperature by external Pt100 sensor
								};
								
ChillerJulaboFP50::ChillerJulaboFP50():SerialDevice(200, "\x0D")
{
	m_timeOut=200;
	//m_pollInterval=1000; 
}

ChillerJulaboFP50::~ChillerJulaboFP50()
{
	
}

/*
 * Channel =2 :Start or Stop chiller, setpt = 0 represents stop, setpt = 1 represents start;
 * Channel =3 :Set internal bath control or external Pt100 sensor control, setpt = 0 represents internal bath control, setpt = 1 represents external Pt100 sensor control
 */
bool ChillerJulaboFP50::writeInt(int channelNum, int setpt, const IntTypeInfo &typeinfo)
{
	if (isSimulated())
	{
		return true;
	}
    string strCmd;
   /*compose command string*/
  	strCmd = m_commands[channelNum] +"\x20"+ Converter::convertToString(setpt); 	
	sendCommandOnly(strCmd);
	return true;
}

/*
 * Channel =4 :Read Chiller in Stop(Response=0) or Start(Response=1) condition
 * Channel =5 :Read Chiller in Manual(Response=0) or Remote(Response=0) control
 * Channel =6 :Read Chiller in internal(Response=0) or external(Response=1) Pt100 sensor control(Response=1)
 */
bool ChillerJulaboFP50::readInt(int channelNum, int *value, const IntTypeInfo &typeinfo)
{
	string strCmd;
	/*compose command string*/
  	strCmd = m_commands[channelNum];
  	string res = getCommandResult(strCmd, m_timeOut);	
  	size_t t_pos  = res.find("\x0D",0);  //changed by wzd 1.1.39
  	int result = 0;
  	string res1;
	if(t_pos == string::npos)
	{	
		throw IOException("PC get unknown read_back from JulaboChiller: " + res);		
	}
	else
	{
		//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, string("-----PC get a normal reply from JulaboChiller!-----"));
		if(channelNum==4||channelNum==6)
		{
			res1 = res.substr(0, t_pos);
			if(!Converter::stringToInt(result, res1))
			{
				throw IOException("read_back value is not a valid int value:" + res1);
			}
			*value = (int)result; 
			return true;
		}
		else if(channelNum==5)
		{
			size_t t_pos1  = res.find_first_of("\x20",0);//Find the first position of space in res  //changed by wzd 1.1.39
			res1 = res.substr(0, t_pos1);
			if(!Converter::stringToInt(result, res1))//convert string to int using Converter
			{
				throw IOException("read_back value is not a valid int value:" + res);
			}
			if(result >= 0)
			{
				if(result==00||result==01)
		 		{
		   			*value =0;
					//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "JulaboChiller is in Manual mode!");
					return true;
		  		}
				else if(result==02||result==03)
		 		{
		   			*value =1;
					//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "JulaboChiller is in Remote mode!");
					return true;
		   		}
				
			}
			else
			{
				*value =-1;
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "JulaboChiller is in Error Status!");
				return true;
			}
			
		}
		
	}

}

/*
 * set temperature, type = double
 */
bool ChillerJulaboFP50::writeDouble(int channelNum, double setpt, const DoubleTypeInfo &typeinfo)
{
	if (isSimulated())
	{
		return true;
	}
	string strCmd;
	/*compose command string*/
  	strCmd = m_commands[channelNum] +"\x20"+ Converter::convertToString(setpt);	
  	//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, string("-----PC send a set-temperature message to JulaboChiller!-----")); 	
	sendCommandOnly(strCmd);
	return true;
}
 
/*
 * read temperature
 */
bool ChillerJulaboFP50::readDouble(int channelNum, double *value, const DoubleTypeInfo &typeinfo)
{
	string strCmd;
	/*compose command string*/
  	strCmd = m_commands[channelNum];
  	//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, string("-----PC send a read-temperature message to JulaboChiller!-----"));
  	string res = getCommandResult(strCmd, m_timeOut);	
	size_t t_pos  = res.find("\x0D",0);  //changed by wzd 1.1.39
	if(t_pos == string::npos)
	{	
		throw IOException("PC get unknown read_back from JulaboChiller: " + res);		
	}
	else
	{
		//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, string("-----PC get a normal reply from JulaboChiller!-----"));
		string res1 = res.substr(0, t_pos);
		double result = 0;
		if(!Converter::stringToDouble(result, res1))
		{
			throw IOException("read back value is not a valid double value:" + res1);
		}
		else
		{
			*value = (double)result; 
			return true;
		}
	}
	
}

bool ChillerJulaboFP50::readAlarm(int channelNum,int * value ,const IntTypeInfo& typeinfo)
{
	string strCmd;
	/*compose command string*/
  	strCmd = m_commands[channelNum];
  	//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, string("-----PC send a read-Alarm message to JulaboChiller!-----"));
  	string res = getCommandResult(strCmd, m_timeOut);	
	size_t t_pos  = res.find_first_of("\x20",0);//Find the first position of space in res  //changed by wzd 1.1.39
	string res1 = res.substr(0, t_pos);
	int result = 0;
	if(!Converter::stringToInt(result, res1))//convert string to int using Converter
	{
		throw IOException("read_back value is not a valid alarm reply:" + res);
	}
	if(result < 0)
	{
		*value =1; //PC got an Alarm
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "JulaboChiller Alarm:" + res);
		return true;
	}
	else
	{
		*value =0;
		//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "JulaboChiller is in normal status:"+ res);
		return true;
	}
	
}



void ChillerJulaboFP50::initDevice()
{
 
}

void ChillerJulaboFP50::initChannels(DeviceNode<ChillerJulaboFP50> *node)
{
    
    node->registerWriteCh(0, &ChillerJulaboFP50::writeDouble); //set temperature
    node->registerReadCh(1, &ChillerJulaboFP50::readDouble); //Read actual bath Temperature
    for(int i = 2; i<=3; ++i)   //start or stop chiller;Set internal  or external  control
	{
		node->registerWriteCh(i, &ChillerJulaboFP50::writeInt);
	}
      for(int i = 4; i<=6; ++i)  //Read Chiller Condition,read remote,read internal or external  control
	{
		node->registerReadCh(i, &ChillerJulaboFP50::readInt);
	}
    node->registerReadCh(7, &ChillerJulaboFP50::readAlarm);  //Read  Alarm message
    node->registerReadCh(8, &ChillerJulaboFP50::readDouble); //Read Temperature by external Pt100 sensor
    node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &ChillerJulaboFP50::getStatus);
}
  
void ChillerJulaboFP50::init()
{
    DeviceNode<ChillerJulaboFP50> *node = new DeviceNode<ChillerJulaboFP50>(m_pollPeriod, this);
    DeviceManager::getInstance()->registerNode(m_nodeNum, node);
    if(!isSimulated())
    {
    	initChannels(node);
    	initDevice();
    }
	
}

IMPLEMENT_DYNAMIC(ChillerJulaboFP50, SerialDevice )

BEGIN_MSG_MAP(ChillerJulaboFP50, SerialDevice )
	SET_V( init, ChillerJulaboFP50 )
END_MSG_MAP
