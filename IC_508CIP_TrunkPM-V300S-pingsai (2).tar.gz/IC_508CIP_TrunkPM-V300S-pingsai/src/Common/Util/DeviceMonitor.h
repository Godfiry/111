/************************************************************************************
** Copyright (c) 2016, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: DeviceMonitor.h
** Description:  
** Release: 1.1
** Modification history: 
**					2016-10-18   mujy create [V1.5.16]
*************************************************************************************/

#ifndef DEVICEMONITOR_H_
#define DEVICEMONITOR_H_

#include "ControlObject.h"
#include "Subscriber.h"
#include "Service.h"
#include "ReadOnlyData.h"
#include "NonBlockingAlarm.h"
#include "OverrunInterlock.h"
#include "Timer.h"
#include "ControlMonitor.h"
#include <vector>
#include <unistd.h>  //add by wzd 1.1.39
#ifdef IAP4_0
using namespace IAP::CONTROL;
using namespace IAP::IO;
using namespace IAP::ALARM;
using namespace IAP::INTERLOCK;
using namespace IAP::CORE;
#endif
	
class DeviceMonitor : public ControlMonitor, public Subscriber
{
	DECLARE_DYNAMIC( DeviceMonitor )
	DECLARE_MSG_MAP
	
	public:
		DeviceMonitor();
		virtual ~DeviceMonitor();
		
	public:
		
		virtual void update(UntypedData *data, const ValueInfo &value);
		virtual void internalExecute();
		virtual void make();
		virtual void startup();
		virtual void shutdown();
		
		void addMonitorIO(const std::string &);
		void setIntervalS(int nInterval);
	private:
		
	private:
		std::vector<UntypedData*> m_IODatas;
		
		NonBlockingAlarm *m_nDeviceOfflineAlarm;
		int m_IntervalS;
		bool m_lastIsOffline;
};
#endif /*DEVICEMONITOR_H_*/
