/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .cpp
** Description: 
** Release: 
** Modification history: 
** 					Feb 22, 2008  shenql  create 
*                   2010-0118 lijj modified
**      
***************************************************************************/
#include "CounterTimer.h"
#include "ConfigException.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "AbortException.h"
#endif
#include "Converter.h"
#include "SysLogger.h"
#include "Converter.h"
#ifdef IAP4_0
#include "ITime.h"
#else
#include "Time.h"
#endif
#include "UTime.h"
#ifdef IAP4_0
using namespace IAP;
using namespace IAP::CORE;
#endif

using namespace std;

CounterTimer::CounterTimer()
{
	m_initialTime = 0;
	m_startTime = 0;
	m_running = false;
	m_counterType = 0;
	m_timerItem = NULL;
	m_periodInSeconds = 1.0;
	m_typeInfo = IntTypeInfo(DescriptorList("Up, Down"));
	m_myTimer = new Timer();
	m_myTimer->subscribe(this);	
}

CounterTimer::CounterTimer(const CounterTimer& pObj)
{
	m_initialTime = pObj.m_initialTime;
	m_startTime = pObj.m_startTime;
	m_running = pObj.m_running;
	m_counterType = pObj.m_counterType;
	m_timerItem = pObj.m_timerItem;
	m_periodInSeconds = pObj.m_periodInSeconds;
	m_typeInfo = IntTypeInfo(DescriptorList("Up, Down"));
	m_myTimer = new Timer();
	m_myTimer->subscribe(this);
}

CounterTimer& CounterTimer::operator=(const CounterTimer& pObj)
{
	if (this != &pObj)
	{
		m_initialTime = pObj.m_initialTime;
		m_startTime = pObj.m_startTime;
		m_running = pObj.m_running;
		m_counterType = pObj.m_counterType;
		m_timerItem = pObj.m_timerItem;
		m_periodInSeconds = pObj.m_periodInSeconds;
		m_typeInfo = IntTypeInfo(DescriptorList("Up, Down"));
		m_myTimer = new Timer();
		m_myTimer->subscribe(this);
	}
	return *this;
}

CounterTimer::~CounterTimer()
{
	#ifndef IAP4_0
	delete m_myTimer;
	m_myTimer = NULL;
	#endif

}

CounterTimer::CounterTimer(ReadWriteDouble *data, int counterType, double period)
{
	m_initialTime = data->getValue();
	m_startTime = 0;	
	m_running = false;
	m_timerItem = data;
	m_typeInfo =  IntTypeInfo(DescriptorList("Up, Down"));
	setCounterType(counterType);
	m_myTimer = new Timer();
	m_myTimer->subscribe(this);
	setPeriod(period);
}

void CounterTimer::setCounterType(int i)
{
	if(i < m_typeInfo.getMin() || i > m_typeInfo.getMax())
	{
		string s = "Counter type " + i;
	    throw ConfigException( s + " out of range");
	} 
	else
	{
	    m_counterType = i;
	}
}

void CounterTimer::setCounterType(string s)
{
	m_counterType = m_typeInfo.getDescriptorList().getDescriptorValue(s);
}

void CounterTimer::setPeriod(double d)
{
	if(d < 0.01)
	{
		throw ConfigException("Period must be positive");
	} 
	else
	{
		m_periodInSeconds = d;
	}
}

void CounterTimer::setTimerItem(ReadWriteDouble* data)
{
	m_timerItem = data;
}

void CounterTimer::start()
{	
	if(m_running)
	{
		return;
	}
	m_initialTime = m_timerItem->getValue();
	m_running = true;
	#ifdef IAP4_0
	m_startTime = ITime::getCurrentTimeAsSeconds();
	#else
	m_startTime = Time::getCurrentTimeAsSeconds();
	#endif
	m_myTimer->setDuration((long)(m_periodInSeconds*1000));	
	m_myTimer->start();
}

void CounterTimer::stop()
{
	if(!m_running)
	{
		return;
	}	
	#ifndef IAP4_0
	updateFromTimer();
	#endif
	m_running = false;
	m_myTimer->stop();
	m_startTime = 0;
}

#ifdef IAP4_0
void CounterTimer::updateFromTimer(const Timer * const timer)
#else
void CounterTimer::updateFromTimer()
#endif
{
	if(!m_running)
	{
		return;
	}
	double t_newValue = 0;
	#ifdef IAP4_0
	double t_passedTimeInSeconds = ITime::getCurrentTimeAsSeconds() - m_startTime;
	#else
	double t_passedTimeInSeconds = Time::getCurrentTimeAsSeconds() - m_startTime;
	#endif
	//double t_passedTimeInSeconds =	(UTime::getCurrentTimeAsMSeconds() - m_startTime)/1000.0;
	switch(m_counterType)
	{
		case 0: // up
		    t_newValue = m_initialTime + t_passedTimeInSeconds;
		    break;
		
		case 1: // down
			if(m_initialTime - t_passedTimeInSeconds > 0)
			{
				t_newValue = m_initialTime - t_passedTimeInSeconds;
			}
			break;
			
		default:
		    break;
	}
	try
	{
		m_timerItem->setValue(t_newValue);
	}
	catch(const exception &ex)
	{
	}

}
