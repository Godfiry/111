/********************************************************************
** Copyright (c) 2019 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: MaterialEnumInfo.h
** Description:
** Release: 1.0
** Modification history:
** 					2019-04-16   Duq create
**
*********************************************************************/

#ifndef MATERIALENUMINFO_H_
#define MATERIALENUMINFO_H_

#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class MaterialEnumInfo : public IntValueInfo
{
	public:
		//Unknown:-1,Absent,Present,Double,Cross
		static const int Unknown = -1;
		static const int Absent = 0;
		static const int Present = 1;
		static const int Double = 2;
		static const int Cross = 3;
		static const int Shuttered=4;

		static const IntTypeInfo typeInfo;
		
		MaterialEnumInfo():IntValueInfo(-1, typeInfo)
		{
		}

		MaterialEnumInfo(int i):IntValueInfo(i, typeInfo)
		{
		}
		
		MaterialEnumInfo(const std::string s):IntValueInfo(s, typeInfo)
		{
		}
};

#endif  /*MATERIALENUMINFO_H_*/
