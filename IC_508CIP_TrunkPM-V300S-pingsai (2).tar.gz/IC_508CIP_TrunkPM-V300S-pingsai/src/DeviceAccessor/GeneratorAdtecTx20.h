/********************************************************************
** Copyright (c) 2020, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: GeneratorAdtecTx03.h
** Description:
** Release: 1.1
** Modification history:
** 					2020-2-5   zhangyy create
**
** Product type: Adtec RF Plasma Generator TX03-D001-00
** Details: 13.56MHz, Continuous Output, Output Power = 0.0-300.0W
** Device communication setting:
** 			Control mode:      RS232C
**     	BaudRate:          9600 bps
**   		Character length:  8 bit
**  		Stop bit length:   1 bit
**			Parity checking:   None
**Status Confirmation Command Detail:
**Send:    Q[CR]
**Reply:   MPK00A1A2 S1S2S3S4S5 F1F2F3F4F5 R1R2R3R4R5 V1V2V3V4V5[CR][CR]
* Meanings: M--[Control Mode]-----0:Manual Mode  1:Analog Mode  2:RS232C Mode
*           P--[Output Mode]------0:Continuous Wave  1:Pulse Wave
*           K--[Output Status]----0:RF-OFF status  1:RF-ON status
*           A1A2--[Alarm Status]--00:No Alarm  01-99:Alarm Code
*           S1S2S3S4S5--[Set Power (10 times notation)]
*           F1F2F3F4F5--[Fwd Power (10 times notation)]
*           R1R2R3R4R5--[Ref Power (10 times notation)]
*           V1V2V3V4V5--[Max Power (1 times notation)]
* Example: 2000000 01056 00000 00000 00300[CR][CR]
* Meaning: RS232C Control Mode,Continuous Wave,RF-OFF status,No Alarm,Set Power=105.6W,Fwd Power=0W,Ref Power=0W,Max Power=300W
**Any Question Please see the manual for the meaning of each character above
* For set output power command, 00000 W[CR] means 0W,  00100 means 10W,  00299 means 29.9W, 01995 means 199.5W, 01000 means 100W
*********************************************************************/

#ifndef GeneratorAdtecTx20_H_
#define GeneratorAdtecTx20_H_
#include "SerialDevice.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#include "StringTypeInfo.h"
#include "ReadWriteDouble.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class GeneratorAdtecTx20 : public SerialDevice
{
    DECLARE_DYNAMIC(GeneratorAdtecTx20)
    DECLARE_MSG_MAP
public:
    GeneratorAdtecTx20();
    virtual ~GeneratorAdtecTx20();

public:
    bool sendCommand(const std::string &strCommand);
    bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
    bool writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo);
    bool writeRawCommand(int nChannelNum, std::string strValue, const StringTypeInfo &typeInfo);
    bool requestInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);
    bool requestDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);
    bool getErrorCode(int nChannelNum, std::string *pValue, const StringTypeInfo &typeInfo);
	virtual std::string getDeviceName();
public://xml
	void init();

protected:
	 void initDevice();
	 void InitChannels(DeviceNode<GeneratorAdtecTx20> *pNode);

private:
    typedef struct
	 {
    	int nType;
    	std::string strCmd;
    	int nReserved;
	 }Cmd;

	 typedef struct
	 {
		 std::string strCmd;
		 int nSubStartPos;
		 int nSubLength;
		 int nCorrectResponseLen;
		 int nRetryTime;
		 DescriptorList Descriptor;
	 }ReadCmd;

	 static Cmd m_commands[];
	 static ReadCmd m_readCommands[];
	 std::string m_strErrorCode;
	 int m_nReadTimeOut;// 1/10 s
	 std::string m_strRFStatus;
	 std::string m_strRFMode;
};

#endif /*GeneratorAdtecTx20_H_*/
