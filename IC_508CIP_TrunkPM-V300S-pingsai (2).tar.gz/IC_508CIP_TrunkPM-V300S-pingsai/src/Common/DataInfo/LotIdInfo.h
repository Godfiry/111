#ifndef LOTIDINFO_H_
#define LOTIDINFO_H_

#include "StringValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class LotIdInfo : public StringValueInfo
{
public:
    static const StringTypeInfo typeInfo;
// = new TextTypeInfo()

	LotIdInfo():StringValueInfo()
	{}
	
	LotIdInfo(std::string s):StringValueInfo(s, this->typeInfo)
	{}

};

#endif /*LOTIDINFO_H_*/
