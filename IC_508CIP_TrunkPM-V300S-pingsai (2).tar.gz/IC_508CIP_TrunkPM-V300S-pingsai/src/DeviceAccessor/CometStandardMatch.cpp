/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: COMETSingleMatchDriver.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					
**                  2014-11-21   lijj	create
**                  2018-03-14   xiasc modify for HSEP230 new CometMatch
*********************************************************************/
#include "CometStandardMatch.h"
#include "DeviceManager.h"

#include "IStringList.h"
#include <iostream>
#include "Converter.h"
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std; 

CometStandardMatch::ParamPair CometStandardMatch::m_paramPairs[] = {ParamPair("manaut",DescriptorList("4,3"))};//0="4"="manual" 1="3"="auto"
										 
map<string,DescriptorList> CometStandardMatch::m_params = map<string,DescriptorList>(m_paramPairs, m_paramPairs+1);

CometStandardMatch::Com CometStandardMatch::m_commands[] = {{0, ""}, //0	reserved						
											{0, "SM", 0},//1 (CH,value)manual
											{0, "SA", 0},//2 auto
											{0, "Rest", 0},//3 fault reset
											{2, "SP",0},  //4 save preset
											{2, "G",0},  //5 goto preset																	
											{1, "Load", 0},//6 set c1
											{1, "Tune", 0},//7 set c2		
											{1, "C3Pos", 0},//8 set c3 										
											 
											{19, "QAllValues", 1},//9 get Manual/Auto
											{2, "QP##", 1},//10 get c1
											{2, "QP##", 2},//11 get c2
											{4, "QP##", 3},//12 get c3  //[zhangcx v1.1.48]
											{2, "PriorTime", 0},//13 set PriorTime						 
											{1, "QPriorTime", 1},//14 get PriorTime
											{2, "QAux1", 1},//15 get voltage  //[liusy v1.1.50]
											{2, "QAux1", 2},//16 get current
								
											{3, "SetRFonDelay,", 0},//17 set RF on Delay//[zhangcx v1.1.56]
											{3, "SetRFoffDelay,", 0},//18 set RF off Delay
											{1, "QMode",0},        //19 get C1 C2 mode
											{1, "GetRFoffDelay",0} //20 get RF off Delay
											};
											


CometStandardMatch::CometStandardMatch()
{
}

CometStandardMatch::~CometStandardMatch()
{
}

bool CometStandardMatch::writeInt(int channelNum, int nValue, const IntTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	int ps = com.m_ps;
	char format[5]={0};
	double t_c = 0.0;
	string msg = "";
	switch(ps)
	{
		case 0:
			msg = m_commands[channelNum + nValue].m_s1;
			break;
		case 1:
			t_c = nValue / 10.0;
			sprintf(format,"%04.1f",t_c);
			msg = com.m_s1 + format;
			break;
		case 2:
			sprintf(format,"%03d",nValue);
		    msg = com.m_s1 + format;
			break;	
		case 3://[zhangcx v1.1.56]
			msg = com.m_s1 + Converter::convertToString(nValue);
			break;
	
	}
	return sendCommand(msg, m_timeOut);
}

bool CometStandardMatch::writeRawCommand(int channelNum, std::string value, const StringTypeInfo &typeInfo)
{
	return sendCommand(value, m_timeOut);
}

bool CometStandardMatch::readInt(int channelNum, int *nValue, const IntTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	string res = readCommand(com.m_s1, m_timeOut);
	std::vector<std::string> t_vlist = IStringList::split(res, ",");

	if(t_vlist.size() != com.m_ps && t_vlist.size() > 19)
	{
		throw IOException("read back value is not valid:" + res);
	}
	
	if(t_vlist.size() > 4)
	{
		string t_svalue = t_vlist[com.m_ps2 -1];
		*nValue = m_params["manaut"].getDescriptorValue(t_svalue);	
	}
	else if(t_vlist.size() == 2)
	{
		string t_svalue = t_vlist[com.m_ps2 -1];
		double t_dvalue = 0;
		if(!Converter::stringToDouble(t_dvalue, t_svalue))
		{
			throw IOException("read back value is not an valid double value:" + t_svalue);
		}
		*nValue = (int)(t_dvalue * 10);
	}
	else if(t_vlist.size() == 1)//[zhangcx v1.1.48]
	{
		string t_svalue = t_vlist[0];
		int t_nvalue =0;
		if(!Converter::stringToInt(t_nvalue, t_svalue))
		{
			throw IOException("read back value is not a valid int value:" + t_svalue);
		}

		*nValue = t_nvalue;
	}
	return true;
}

void CometStandardMatch::initChs(DeviceNode<CometStandardMatch> *node)
{
	node->registerWriteCh(0, &CometStandardMatch::writeRawCommand);
	for(int i = 1; i <= 8; ++i)
	{
		node->registerWriteCh(i, &CometStandardMatch::writeInt);
	}
	for(int i = 9; i <= 12; ++i)
	{
		node->registerReadCh(i, &CometStandardMatch::readInt);
	}
	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &CometStandardMatch::getStatus);		

	node->registerWriteCh(13, &CometStandardMatch::writeInt);//[zhangcx v1.1.48]
	node->registerReadCh(14, &CometStandardMatch::readInt);
	node->registerReadCh(15, &CometStandardMatch::readDouble);////[liusy v1.1.50]
	node->registerReadCh(16, &CometStandardMatch::readDouble);

	node->registerWriteCh(17, &CometStandardMatch::writeInt);//[zhangcx v1.1.56]
	node->registerWriteCh(18, &CometStandardMatch::writeInt);
	node->registerReadCh(19, &CometStandardMatch::readInt);
	node->registerReadCh(20, &CometStandardMatch::readInt);
}
//[liusy v1.1.50]
bool CometStandardMatch::readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo)//[zhangcx v1.1.49]
{
	Com com = m_commands[nChannelNum];
	string res = readCommand(com.m_s1, m_timeOut);
	std::vector<std::string> t_vlist = IStringList::split(res, ",");

	if(t_vlist.size() != com.m_ps && t_vlist.size() > 19)
	{
		throw IOException("read back value is not valid:" + res);
	}

	if(t_vlist.size() == 2)
	{
		string t_svalue = t_vlist[com.m_ps2 -1];
		double t_dvalue = 0;
		if(!Converter::stringToDouble(t_dvalue, t_svalue))
		{
			throw IOException("read back value is not an valid double value:" + t_svalue);
		}
		*pValue = t_dvalue;
	}
	else
	{
		*pValue = 0;
	}

	return true;
}

void CometStandardMatch::initDevice()
{
	cout<<"Start Scan COMET Standard Match...."<<endl;//merged from 1.6.3 by zhangyy[1.9.0]
	//say hello to match
	int nTemp;
	try
	{
		readInt(10,&nTemp,IntTypeInfo()); //read C1
	}
	catch(exception &ex)
	{
		cout<<"Scan COMET Standard Match first failed. Try again!"<<endl;
	}
	try
	{
		readInt(10,&nTemp,IntTypeInfo()); //read C1
	}
	catch(exception &ex)
	{
		cout<<"Scan COMET Standard Match failed. Communication abnormal!"<<endl;
		throw;
	}
	
	cout<<"Scan COMET Standard Match Successfully...."<<endl;
}
		
void CometStandardMatch::init()
{
	DeviceNode<CometStandardMatch> *node = new DeviceNode<CometStandardMatch>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	if(!isSimulated())
	{
		initChs(node);		
		initDevice();
	}
}

IMPLEMENT_DYNAMIC(CometStandardMatch, COMETMatchDriver )
BEGIN_MSG_MAP(CometStandardMatch, COMETMatchDriver )
    SET_V( init, CometStandardMatch )
END_MSG_MAP

