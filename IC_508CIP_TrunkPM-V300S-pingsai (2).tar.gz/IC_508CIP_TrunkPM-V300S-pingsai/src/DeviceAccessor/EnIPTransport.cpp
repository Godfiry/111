/********************************************************************
** Copyright (c) 2019 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: EnIPTransport.cpp
** Description:  
** Release: 1.0
** Modification history:           
** 					2019-06-03   Duq create
** 
*********************************************************************/

#include "EnIPTransport.h"
#include <string.h>
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#include "ConfigException.h"
#include <signal.h>
#include "RegiserEIPApplication.h"
#include <iostream>
#include <unistd.h>
#ifdef IAP4_0
using namespace IAP;
#endif
using namespace std;

//EnIPUDPServerTransport class
EnIPUDPServerTransport* EnIPUDPServerTransport::m_Instance = NULL;
bool EnIPUDPServerTransport::startflag = false;

EnIPUDPServerTransport* EnIPUDPServerTransport::getInstance()
{
	if(m_Instance == NULL)
	{
		m_Instance = new EnIPUDPServerTransport();
	}
	return m_Instance;
}

EnIPUDPServerTransport::EnIPUDPServerTransport()
{
	m_socketfd = socket(AF_INET, SOCK_DGRAM, 0);//IPV4  SOCK_DGRAM---UDP
	if(m_socketfd < 0)
	{
		throw ConfigException("creating UDP socketfailed");
	}
	struct timeval t_timeout;
	t_timeout.tv_sec = 10;
    t_timeout.tv_usec = 0;
    if(setsockopt(m_socketfd, SOL_SOCKET, SO_RCVTIMEO, &t_timeout, sizeof(t_timeout)) != 0)
    {
       throw IOException("EnIPUDPServerTransport::EnIPUDPServerTransport(): set socket SO_RCVTIMEO option failed!");
    }   
    t_timeout.tv_sec = 10;
    t_timeout.tv_usec = 0;  
    if(setsockopt(m_socketfd, SOL_SOCKET, SO_SNDTIMEO, &t_timeout, sizeof(t_timeout)) != 0)
    {
        throw IOException("EnIPUDPServerTransport::EnIPUDPServerTransport(): set socket SO_SNDTIMEO option failed!");
    }
	memset(&m_clientAddr, 0, sizeof(struct sockaddr_in));
	m_clientAddrLen = sizeof(m_clientAddr);
	memset(&m_serverAddr, 0, sizeof(struct sockaddr_in));
	m_serverAddr.sin_family = AF_INET;//IPV4
	m_serverAddr.sin_port = htons(2222);//port: 2222 --- 0x08AE
	m_serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);//auto get local IP
	if(bind(m_socketfd, (struct sockaddr *)&m_serverAddr, sizeof(m_serverAddr)) < 0)
	{
		throw ConfigException("binding UDP socketfailed");
	}
	m_running = true;
	m_runningstatus = false;
	memset(m_recvBuf,0,UDPServerRecvLength);
}

void EnIPUDPServerTransport::startRecvData()
{
	if(m_Instance == NULL)
	{
		m_Instance = new EnIPUDPServerTransport();
	}
	if(!startflag)
	{
		m_Instance->start();
		startflag = true;
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "EnIPUDPServerTransport::startRecvData()");
	}
}

EnIPUDPServerTransport::~EnIPUDPServerTransport()
{
	m_running = false;
	while(m_runningstatus)
	{
		usleep(10);
    }
	close(m_socketfd);
}

void EnIPUDPServerTransport::run()
{
	while(m_running)
	{
		try
		{
			m_runningstatus = true;
			memset(&m_clientAddr, 0, sizeof(struct sockaddr_in));
			m_recvLength = recvfrom(m_socketfd, m_recvBuf, UDPServerRecvLength, 0, (struct sockaddr *)&m_clientAddr, &m_clientAddrLen);
			if(m_recvLength <= 0)
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "EnIPUDPServerTransport::run() recvfrom failed. ");
			}
			else
			{
				//get data to atrribut
				serverIP = inet_ntoa(m_clientAddr.sin_addr);
				RegiserEIPApplication::getInstance()->NoticeRegiseredAttribut(serverIP, m_recvBuf, m_recvLength);
				memset(m_recvBuf,0,m_recvLength);
			}
		}
		catch(const exception &ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "EnIPUDPServerTransport::run() got exception: " + string(ex.what()));
		}
		catch(...)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "EnIPUDPServerTransport::run() got exception.");
		}
	}
	m_runningstatus = false;
	exit();	
}
//EnIPUDPServerTransport class

//EnIPUDPClientTransport class
EnIPUDPClientTransport::EnIPUDPClientTransport(const std::string &server)
{
	m_server = server;
	m_socketfd = socket(AF_INET, SOCK_DGRAM, 0);//IPV4  SOCK_DGRAM---UDP
	if(m_socketfd < 0)
	{
		throw ConfigException("creating UDP socketfailed");
	}
	struct timeval t_timeout;
	t_timeout.tv_sec = 10;
    t_timeout.tv_usec = 0;
    if(setsockopt(m_socketfd, SOL_SOCKET, SO_RCVTIMEO, &t_timeout, sizeof(t_timeout)) != 0)
    {
		throw IOException("EnIPUDPClientTransport::EnIPUDPClientTransport(): set socket SO_RCVTIMEO option failed!");
    }   
    t_timeout.tv_sec = 10;
    t_timeout.tv_usec = 0;  
    if(setsockopt(m_socketfd, SOL_SOCKET, SO_SNDTIMEO, &t_timeout, sizeof(t_timeout)) != 0)
    {
        throw IOException("EnIPUDPClientTransport::EnIPUDPClientTransport(): set socket SO_SNDTIMEO option failed!");
    }
	memset(&m_serverAddr, 0, sizeof(struct sockaddr_in));
	m_serverAddr.sin_family = AF_INET;//IPV4
	m_serverAddr.sin_port = htons(2222);//port: 2222 --- 0x08AE
	const char* serverIP = server.data();
	inet_pton(AF_INET,serverIP,&m_serverAddr.sin_addr.s_addr);//get server IP
	m_serverAddrLen = sizeof(m_serverAddr);
}

EnIPUDPClientTransport::~EnIPUDPClientTransport()
{
	close(m_socketfd);
}

int EnIPUDPClientTransport::sendData(const char *buffer, int length)
{
	try
	{
		m_sendLength = sendto(m_socketfd, buffer, length, 0, (struct sockaddr *)&m_serverAddr, m_serverAddrLen);
		if(m_sendLength < 0)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "EnIPUDPClientTransport::sendData failed, server is " + m_server);
		}
	}
	catch(const exception &ex)
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "EnIPUDPClientTransport::sendData got exception: " + string(ex.what()));
	}
	catch(...)
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "EnIPUDPClientTransport::sendData got exception.");
	}
	return m_sendLength;
}
//EnIPUDPClientTransport class

//EnIPTCPClientTransport class
EnIPTCPClientTransport::EnIPTCPClientTransport(const std::string &server)
{
	m_server = server;
	m_socket = new TCPSocket(server, "44818");//port: 44818 --- 0xAF12
	m_socket->connect();
}

EnIPTCPClientTransport::~EnIPTCPClientTransport()
{
	m_socket->close();
	delete m_socket;
	m_socket = NULL;
}

bool EnIPTCPClientTransport::isConnected()
{
	return m_socket->isConnected();
}

int EnIPTCPClientTransport::sendData(const char *buffer, int length)
{
	if(!isConnected())
	{
		throw IOException("send data failed for socked is not connected, server is " + m_server);
	}
	int sendLen = 0;
	while(sendLen < length)
	{
		signal(SIGPIPE,SIG_IGN);
		int ret = m_socket->sendData(buffer+sendLen, length-sendLen);
		if(ret == -1)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "send data failed for server " + m_server + " , error is " + m_socket->getErrnoStr());		
			if(m_socket->isConnected())
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "send data failed for socked is not connected, server is " + m_server);	
			}
			
			if(m_socket->getErrno() == EINTR)
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "send data failed for server " + m_server + " , error is EINTR and continue send");
				continue;	
			}
			else if(m_socket->getErrno() == EAGAIN)//EAGAIN  errno means the sended data is bigger than socket send buffer 
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "send data failed for server " + m_server + " , error is EAGAIN and continue send");
				sleep(1);
				continue;
			}
			else
			{						
				throw IOException("send data failed for server " + m_server + " , error is " + m_socket->getErrnoStr());
			}		
		} 
		else
		{
			sendLen += ret;
		}
	}
	return sendLen;
}

int EnIPTCPClientTransport::recvData(char *buffer)
{
	signal(SIGPIPE,SIG_IGN);
	int t_recvCount = m_socket->recvData(buffer, TCPClientRecvLength);
	if(t_recvCount > 0)
	{
		return t_recvCount;
	}
	else
	{
		string templog = "recv data failed for server " + m_server + " , error is " + m_socket->getErrnoStr();
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, templog);				
		throw IOException(templog);
	}
}

int EnIPTCPClientTransport::SendReceive(const char *senddata, int sendlength, char *recvdata)
{
	IMutexLocker locker(&m_lock);
	int length = 0;
	//send
	length = sendData(senddata, sendlength);
	//cout<<"length: "<<length<<endl;
	//recv
	if(recvdata != NULL)
	{
		length = recvData(recvdata);
		//cout<<"length: "<<length<<endl;
	}
	return length;
}
//EnIPTCPClientTransport class
