/*
 * TimeScale.h
 *
 *  Created on: 2021-03-04
 *      Author: lvjiawen
 */

#ifndef SRC_COMMON_TOOL_TIMESCALE_H_
#define SRC_COMMON_TOOL_TIMESCALE_H_

#include "CBase.h"
#include <sys/time.h>

class TimeScale :virtual public CBase
{
public:
    TimeScale();
    TimeScale(string strName);
    virtual ~TimeScale();

public:
    void setPoint(int nID);
    void setStartPoint();
    void setFinishPoint();

    string getTimeScale(int nStartID, int nFinishID);
    string getTimeScale();


    long getLongTimeScale(int nStartID, int nFinishID);//added by liusy[1.1.38]
    long getLongTimeScale();//added by liusy[1.1.38]

    bool isReach(int nID, int nTimeLasting_ms);
    bool isReach(int nTimeLasting_ms);

    void waitForReach(int nTimeLasting_ms);

    void logForLongTimeMs(int nStartID, int nFinishID, int nMoreThanTimeMs);//added by mujy [1.6.0]
private:
    string  m_strName;
    map<int,timeval> m_TimePoint;
};

#endif /* SRC_COMMON_TOOL_TIMESCALE_H_ */
