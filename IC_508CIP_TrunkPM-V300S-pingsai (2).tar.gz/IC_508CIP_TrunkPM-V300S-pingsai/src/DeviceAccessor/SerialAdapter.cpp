/*
 * SerialAdapter.cpp
 *
 *  Created on: 2024年12月27日
 *      Author: wenxiang
 */

#include "SerialAdapter.h"
#include "shmlib.h"
#include "SysLogger.h"
#include "Converter.h"
#ifdef IAP4_0
using namespace IAP;
using namespace IAP::CORE;
#endif
SerialAdapter::SerialAdapter()
{
	m_dev1 = NULL;
#ifdef KYLAND
	m_dev2 = NULL;
#endif
	m_type = SERIALPORT;
}

SerialAdapter::~SerialAdapter()
{
	if(m_dev1 != NULL)
	{
		delete m_dev1;
		m_dev1 = NULL;
	}
#ifdef KYLAND
	else if(m_dev2 != NULL)
	{
		delete m_dev2;
		m_dev2 = NULL;
	}
#endif
}

void SerialAdapter::init(DeviceType type)
{
	m_type = type;

	if(m_type == SERIALPORT)
	{
		m_dev1 = new ISerialPort();
	}
#ifdef KYLAND
	else if(m_type == ETHERCAT_TO_SERIAL)
	{
		m_dev2 = new EtherCatToSerial();
	}
#endif
}

void SerialAdapter::init()
{
	if(m_type != SERIALPORT)
	{
    	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
                    "Serial port error.Unknown serial device type.");
    	return;
	}
	m_dev1 = new ISerialPort();
}

void SerialAdapter::closePort()
{
	if(m_type==SERIALPORT && m_dev1!=NULL)
	{
		m_dev1->closePort();
	}
#ifdef KYLAND
	else if(m_type==ETHERCAT_TO_SERIAL && m_dev2!=NULL)
	{
		m_dev2->closePort();
	}
#endif
}

bool SerialAdapter::openPort(const char *dev)
{
	if(m_type==SERIALPORT && m_dev1!=NULL)
	{
		return m_dev1->openPort(dev);
	}
#ifdef KYLAND
	else if(m_type == ETHERCAT_TO_SERIAL && m_dev2 != NULL)
	{
		return m_dev2->shmSerialOpen(dev, m_portSettings);
	}
#endif
	return false;
}

bool SerialAdapter::setBaudRate(unsigned int rate)
{
	if(m_type==SERIALPORT && m_dev1!=NULL)
	{
		return m_dev1->setBaudRate(rate);
	}
#ifdef KYLAND
	else if(m_type == ETHERCAT_TO_SERIAL && m_dev2 != NULL)
	{
		m_portSettings.BodeRate = rate;
		return true;
	}
#endif
	return false;
}

bool SerialAdapter::setCharSize(unsigned int size)
{
	if(m_type==SERIALPORT && m_dev1!=NULL)
	{
		return m_dev1->setCharSize(size);
	}
#ifdef KYLAND
	else if(m_type == ETHERCAT_TO_SERIAL && m_dev2 != NULL)
	{
		m_portSettings.DataBit = size;
		return true;
	}
#endif
	return false;
}

bool SerialAdapter::setStopBit(unsigned int stopBit)
{
	if(m_type==SERIALPORT && m_dev1!=NULL)
	{
		return m_dev1->setStopBit(stopBit);
	}
#ifdef KYLAND
	else if(m_type == ETHERCAT_TO_SERIAL && m_dev2 != NULL)
	{
		m_portSettings.StopBit = stopBit;
		return true;
	}
#endif
	return false;
}

bool SerialAdapter::setParity(unsigned int mode)
{
	if(m_type==SERIALPORT && m_dev1!=NULL)
	{
		return m_dev1->setParity(mode);
	}
#ifdef KYLAND
	else if(m_type == ETHERCAT_TO_SERIAL && m_dev2 != NULL)
	{
		m_portSettings.ParityMode = mode;
		return true;
	}
#endif
	return false;
}

bool SerialAdapter::setXonoff(bool en)
{
	if(m_type==SERIALPORT && m_dev1!=NULL)
	{
		return m_dev1->setXonoff(en);
	}
	else
	{
		return true;
	}
	return false;
}

bool SerialAdapter::setRtscts(bool en)
{
	if(m_type==SERIALPORT && m_dev1!=NULL)
	{
		return m_dev1->setRtscts(en);
	}
	else
	{
		return true;
	}
	return false;
}

bool SerialAdapter::setSlaveAddress(unsigned short slaveaddress)
{
#ifdef KYLAND
	if(m_type == ETHERCAT_TO_SERIAL && m_dev2 != NULL)
	{
		m_portSettings.SlaveAddress = slaveaddress;
		return true;
	}
	else
	{
    	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
                    "Failed to set slave address.Serial type is not ETHERCAT_TO_SERIAL or it is null.");
		return false;
	}
#endif
	return true;
}

bool SerialAdapter::setDataFrame(const std::string &dataframe)
{
#ifdef KYLAND
	if(m_type == ETHERCAT_TO_SERIAL && m_dev2 != NULL)
	{
		m_portSettings.DataFrame = dataframe;
		m_dev2->setBeckHoffFlag(true);
		return true;
	}
	else
	{
    	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
                    "Failed to set data frame.Serial type is not ETHERCAT_TO_SERIAL or it is null.");
		return false;
	}
#endif
    return true;
}

bool SerialAdapter::setIndex(unsigned short index)
{
#ifdef KYLAND
	if(m_type == ETHERCAT_TO_SERIAL && m_dev2 != NULL)
	{
		m_portSettings.Index = index;
		return true;
	}
	else
	{
    	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
                    "Failed to set index.Serial type is not ETHERCAT_TO_SERIAL or it is null.");
		return false;
	}
#endif
    return true;
}

int SerialAdapter::readStr(char *buf, int timeout, int maxread)
{
	if(m_type==SERIALPORT && m_dev1!=NULL)
	{
		return m_dev1->readStr(buf, timeout, maxread);
	}
#ifdef KYLAND
	else if(m_type == ETHERCAT_TO_SERIAL && m_dev2 != NULL)
	{
		short error = 1;
		int ret = m_dev2->shmSerialReadStr(buf, timeout, maxread, &error);
		if(ret < 0)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
						"Read failed.Error code: '"+Converter::convertToString(ret)+"' ");
		}
		switch(error)
		{
			case SERIAL_PARITY_ERROR:
	        	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
	                        "Serial Port Error:Parity Error.");
	        break;

			case SERIAL_FRAMING_ERROR:
	        	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
	                        "Serial Port Error:Framing Error.");
	        break;

			case SERIAL_OVERRUN_ERROR:
	        	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
	                        "Serial Port Error:Overrun Error.");
	        break;

			case SERIAL_SLAVE_NOT_OP_ERROR:
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
					        "Serial Port Error:Slave No OP Error.");
			break;

			case SERIAL_NOT_INIT_ERROR:
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
					        "Serial Port Error:Serial Port Not Initialized Error.");
			break;

			case SERIAL_LENGTH_ERROR:
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
					        "Serial Port Error:Write Length Exceeds 128 Error.");
			break;

			default:
				;
		}
		return ret;
	}
#endif
	return -1;
}

int SerialAdapter::writeRaw(const char *str, int count)
{
	if(m_type==SERIALPORT && m_dev1!=NULL)
	{
		return m_dev1->writeRaw(str, count);
	}
#ifdef KYLAND
	else if(m_type == ETHERCAT_TO_SERIAL && m_dev2 != NULL)
	{
		short error = 1;
		int ret = m_dev2->shmSerialWriteRaw(str, count, &error);
		if(ret < 0)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
						"Write failed.Error code: '"+Converter::convertToString(ret)+"' ");
		}
		switch(error)
		{
			case SERIAL_PARITY_ERROR:
	        	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
	                        "Serial Port Error:Parity Error.");
	        break;

			case SERIAL_FRAMING_ERROR:
	        	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
	                        "Serial Port Error:Framing Error.");
	        break;

			case SERIAL_OVERRUN_ERROR:
	        	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
	                        "Serial Port Error:Overrun Error.");
	        break;

			case SERIAL_SLAVE_NOT_OP_ERROR:
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
					        "Serial Port Error:Slave No OP Error.");
			break;

			case SERIAL_NOT_INIT_ERROR:
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
					        "Serial Port Error:Serial Port Not Initialized Error.");
			break;

			case SERIAL_LENGTH_ERROR:
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
					        "Serial Port Error:Write Length Exceeds 128 Error.");
			break;

			default:
				;
		}
		return ret;
	}
#endif
	return -1;
}
