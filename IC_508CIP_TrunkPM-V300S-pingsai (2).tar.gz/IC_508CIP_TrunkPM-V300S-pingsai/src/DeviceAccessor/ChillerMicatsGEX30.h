/********************************************************************
** Copyright (c) 2021, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: ChillerMicatsGEX30.h
** Description: This driver is used for Institute of Micats GEX_30 Chiller
*                RS485 communication protocol GEX_30
* 				 Communication Type:Modbus protocol,ASCII Mode
* 				 BaudRate:9600
*                DataBit:7
* 				 StartBit:1
*                StopBit:1
*                Parity:Even
*                FlowControl:no flow control
*
** Release: 1.1
** Modification history:
** 					2021-10-28   zhangyy create
**
*********************************************************************/
#ifndef CHILLERMICATSGEX30_H_
#define CHILLERMICATSGEX30_H_


#include "SerialDevice.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class ChillerMicatsGEX30:public SerialDevice
{
	DECLARE_DYNAMIC(ChillerMicatsGEX30)
	DECLARE_MSG_MAP

	public:
		ChillerMicatsGEX30();
		virtual ~ChillerMicatsGEX30();

	public:
		bool writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo);
		bool readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);
		bool readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);
		bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
		void init();

	protected:
		void initDevice();
		void initChs(DeviceNode<ChillerMicatsGEX30> *pNode);

	private:
		typedef struct
		{
			std::string m_strAddress;
			int m_nDeal;
		}Cmd;

		static Cmd m_cmd[];
};


#endif /* CHILLERMICATSGEX30_H_ */
