/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: NoSuchNameException.h
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-03-24   WangYonggui create
**      
*********************************************************************/
#ifndef NOSUCHNAMEEXCEPTION_H_
#define NOSUCHNAMEEXCEPTION_H_

#include "TMCException.h"

class NoSuchNameException:public TMCException
{
	public:
		NoSuchNameException(const std::string &s);
};

#endif /*NOSUCHNAMEEXCEPTION_H_*/
