/************************************************************************************
** Copyright (c) 2018, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MonitorData.h
** Description: This file includes declaration of class MonitorData.          
** Release: 1.2
** Modification history: 
* 					2018-10-16  lvjw	
* 						cover bug:exit has err.
* 						compatible linux 6.4.
*					2018-12-27	mujy
*						1) set auto start monitor
*						2) modify MonitorData struct
*************************************************************************************/



#ifndef IOMONITOR_H_
#define IOMONITOR_H_

#define TIME_INTERVAL "time_interval"
#define VALUE_CHANGE "value_change"

#include "ControlObjectEX.h"
#include "Subscriber.h"
#include "Service.h"
#include "ReadOnlyData.h"
#include "NonBlockingAlarm.h"
#include "Timer.h"
#include <queue>
#include <list>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CONTROL;
using namespace IAP::ALARM;
using namespace IAP::CORE;
#endif

class IOMonitorLogThread;
		
struct MonitorData
{
	std::string strName;//added by mujy [1.2]
	int nNodeNum;
	int nChannelNum;
	ValueInfo * pValueInfo;
	std::string TimeStamp;
};
	
class IOMonitor : public ControlObjectEX, public Subscriber, public TimerSubscriber
{
	DECLARE_DYNAMIC( IOMonitor )
	DECLARE_MSG_MAP
	DECLARE_SERVICEINFO_LIST
	
	class  MonitorUp: public Service
	{
		DECLARE_DYNAMIC_SERVICE(MonitorUp)
			
			public:
				void execute();	
	};
	class  MonitorDown: public Service
	{
		DECLARE_DYNAMIC_SERVICE(MonitorDown)
			
			public:
				void execute();	
	};
	
	public:
		IOMonitor();
		virtual ~IOMonitor();
		
	public://xml
		void setLogPath(const std::string &);
		void addMonitorIO(const std::string &);
		void setAutoStart(bool bFlag);//added by mujy [1.2]
		void setLogThreadCh(std::string &strPath);
		void setMode(std::string &strMode);
		void setUpdataTimeInterval(int nInterval);//ms

	public:
		virtual void update(UntypedData *data, const ValueInfo &value);
		#ifdef IAP4_0
		virtual void updateFromTimer(const Timer * const timer);	
		#else
		virtual void updateFromTimer();	
		#endif
		void getData(MonitorData &data) ;
		void setLogThread(IOMonitorLogThread *);

	protected:
		virtual void do_MonitorUp();
		virtual void do_MonitorDown();
		virtual void make();
		virtual void startup();//added by mujy [1.2]
		
	private:
		void addData(MonitorData *);
		void startThread();
		
	private:
		std::queue<MonitorData *> 			m_Data;
		IMutex									m_DataQueueMutex;
		std::list<UntypedData*> 				m_IOList;
		
		IOMonitorLogThread 					*m_pThread;
		
		ServicePtr<MonitorUp> 				m_sMonitorUp;
		ServicePtr<MonitorDown> 				m_sMonitorDown;
		
		//NonBlockingAlarm						*m_QueueTooLongAlarm;
		std::string							m_strLogPath;
		bool									m_bThreadStarted;
		bool									m_bDefaultThread;
		bool									m_bAutoStart;//added by mujy [1.2]
		std::string							m_strMode;
		Timer									*m_UpdataTimer;
		int										m_nUpdataTimeInterval;//ms
};
#endif /*IOMONITOR_H_*/
