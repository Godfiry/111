#include "EtherCatPLC_E300.h"
#include "Converter.h"
#include "StrTool.h"
#include <iostream>
#include <unistd.h>
#include <string.h>

#include "DeviceManager.h"
#include "IODevice.h"
#include "Hex.h"
#include <string.h>
#include "ConfigException.h"
#include "MathTool.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
using namespace IAP;
#endif

EtherCatPLC_E300::EtherCatPLC_E300() {
	// TODO Auto-generated constructor stub
	//test
}

EtherCatPLC_E300::~EtherCatPLC_E300() {   
	// TODO Auto-generated destructor stub

}

/*bool EtherCatPLC_E300::readBit(int channelNum, int *bit, const IntTypeInfo &typeInfo)
{
	int nIndex = channelNum;

	DigitalParam* dp = &(m_deviceParam.m_Input.m_vDIParam.at(nIndex));

	m_EtherCat->readByte(m_nMacID, m_pReadBuffer);

	//char bitTemp = m_pReadBuffer[dp->m_nByteOffset];
	//char bitTemp2 = m_pReadBuffer[dp->m_nByteOffset+1];


	int datalow = (m_pReadBuffer[dp->m_nByteOffset] & 0xff); 
	int datahigh = (m_pReadBuffer[dp->m_nByteOffset+1] & 0xff);
	int data = ((datahigh << 8) | datalow);
//cout<<"int size"<<sizeof(int)<<"********"<<endl;

	//*bit = (data & (0x01 << (dp->m_nBitOffset - 1))); // every bit has a meaning
	*bit = (data >>(dp->m_nBitOffset - 1)) & 0x01; // every bit has a meaning

	

//int a= (0x01 << (dp->m_nBitOffset - 1));

//cout<<"*bit : "<<*bit<<"********"<<endl;
//cout<<"a : "<<a<<"********"<<endl;

	return true;
}*/

bool EtherCatPLC_E300::writeBit(int channelNum, int bit, const IntTypeInfo &typeInfo)
{
	int nIndex = channelNum - 200;
	DigitalParam* dp = &(m_deviceParam.m_Output.m_vDOParam.at(nIndex));

	if(channelNum == 334)//BV close/open
	{
		int nOffset = dp->m_nByteOffset;

		if(bit == 0)
		{
			m_pWriteBuffer[nOffset+0] = (unsigned char)(1 & 0xff);
			m_pWriteBuffer[nOffset+2] = (unsigned char)(0 & 0xff);
			m_pWriteBuffer[nOffset+4] = (unsigned char)(0 & 0xff);
			m_pWriteBuffer[nOffset+6] = (unsigned char)(0 & 0xff);
		}
		if(bit == 1)
		{
			m_pWriteBuffer[nOffset+0] = (unsigned char)(2 & 0xff);
			m_pWriteBuffer[nOffset+2] = (unsigned char)(0 & 0xff);
			m_pWriteBuffer[nOffset+4] = (unsigned char)(0 & 0xff);
			m_pWriteBuffer[nOffset+6] = (unsigned char)(0 & 0xff);
		}
		m_EtherCat->writeByte(m_nMacID, m_pWriteBuffer);
		return true;
	}

	//only support 2 byte 16bit
	if (dp->m_nBitOffset > 16)
	{
		throw IOException(" bit offset need less than 8, support 2 byte");
	}
	
	if (dp->m_nByteSize == 2 && dp->m_nBitOffset > 8)//high 8 bit
	{
		if (bit == 1)
		{
			m_pWriteBuffer[dp->m_nByteOffset + 1] |= (0x01 << (dp->m_nBitOffset - 9));//set 1
		}
		else
		{
			m_pWriteBuffer[dp->m_nByteOffset + 1] &= (~(0x01 << (dp->m_nBitOffset - 9)));//set 0	
		}

	}
	else if (dp->m_nBitOffset > 0 && dp->m_nBitOffset <= 8)//low 8 bit
	{
		if (bit == 1)
		{
			m_pWriteBuffer[dp->m_nByteOffset] |= (0x01 << (dp->m_nBitOffset - 1));//set 1
		}
		else
		{
			m_pWriteBuffer[dp->m_nByteOffset] &= (~(0x01 << (dp->m_nBitOffset - 1)));//set 0	
		}
	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, " the Byte > 2 !");
		return false;
	}
	
	m_EtherCat->writeByte(m_nMacID, m_pWriteBuffer);
	return true;
}

bool EtherCatPLC_E300::readAnalog(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	int nIndex = channelNum - 400;

	AnalogParam* ap = &(m_deviceParam.m_Input.m_vAIParam.at(nIndex));
	int nType = ap->m_nType;
	bool flag = m_EtherCat->readByte(m_nMacID, m_pReadBuffer);
	
	double pdValue = 0.0;
	
	if(1 == nType || 2 == nType)//sint || usint
	{
		unsigned char cByte[1];
		memcpy(cByte, m_pReadBuffer + ap->m_nByteOffset, 1);
		int data = (cByte[0] & 0xff);
		pdValue = (double)data;
	}
	else if(3 == nType || 4 == nType || 7 == nType)//int || uint || word
	{
		unsigned char cByte[2];
		memcpy(cByte, m_pReadBuffer + ap->m_nByteOffset, 2);
		short sTempValue = (short)(((cByte[1] & 0xff) << 8) | (cByte[0] & 0xff));
		pdValue = (double)sTempValue;
	}
	else if(5 == nType || 6 == nType || 8 == nType)//dint || udint || dword
	{
		unsigned char cByte[4];
		memcpy(cByte, m_pReadBuffer + ap->m_nByteOffset, 4);
		int data1 = (cByte[0] & 0xff);
		int data2 = (cByte[1] & 0xff);
		int data3 = (cByte[2] & 0xff);
		int data4 = (cByte[3] & 0xff);
		
		int data = (data4 << 24) |(data3 << 16) |(data2 << 8) | data1;
		pdValue = (double)data;
	}
	else if(9 == nType)//real
	{
		unsigned char cByte[4];
		memcpy(cByte, m_pReadBuffer + ap->m_nByteOffset, 4);
		pdValue = *(float*)&cByte;
		
		if(401 == channelNum)
		{
			pdValue = floor(pdValue * 10000.000f + 0.5)/10000.000f;

			int nMaxGasFlow = typeInfo.getMax();
			if(pdValue > nMaxGasFlow)
			{
				pdValue = nMaxGasFlow;				
			}
		}
	}	
	else if(20 == nType)//BV
	{
		unsigned long temp;
		unsigned char cByte[10];
		memcpy(cByte, m_pReadBuffer+ap->m_nByteOffset,10);
		if(!isSimulated())
		{
			if(channelNum==436)//positionAT
			{
				temp = (((unsigned long)cByte[6]) & 0xff) + ((((unsigned long)cByte[8]) << 8) & 0xff00);
				if(temp<1)
				{
					*value=0;
				}
				else
				{
					*value = temp * typeInfo.getMax() / 10000;
				}
			}
			else if(channelNum==437)//pressureAT
			{
				double dTemp;
				//temp = (((unsigned long)cByte[2]) & 0xff) + ((((unsigned long)cByte[4]) << 8) & 0xff00);
				short sTempValue = (short)(((cByte[4] & 0xff) << 8) | (cByte[2] & 0xff));
				dTemp = (double)sTempValue;
				if(dTemp<1)
				{
					*value=0;
				}
				else
				{
					double dValue = dTemp / 1000.0f;
					if(dValue > typeInfo.getMax())
					{
						*value = typeInfo.getMax();
					}
					else
					{
						*value = dValue;
					}
				}
			}
			else if(channelNum==8)//vlvstatus
			{
				temp = (((unsigned long)cByte[0]) & 0xff);
				*value = temp;
			}
		}
		return true;
	}
	else if(21 == nType)//314
	{
		int nMax = typeInfo.getMax();

		unsigned char cByte[10];
		memcpy(cByte, m_pReadBuffer+ap->m_nByteOffset,10);
		int nTempValue = 0;

		if(channelNum == 438)
		{
			if(!(cByte[4] & 0x80))
			{
				nTempValue = (cByte[2] &0xff) + ((cByte[4] << 8) & 0xff00);
			}
		}
		else if(channelNum == 439)
		{
			if(!(cByte[8] & 0x80))
			{
				nTempValue = (cByte[6] &0xff) + ((cByte[8] << 8) & 0xff00);
			}
		}
		else
		{
			return false;
		}

		if(nTempValue > 32767)
		{
			*value = nMax;
		}
		else
		{
			double dValue = (((double)nTempValue)/32767) * nMax;
			*value = MathTool::Round(dValue,typeInfo.getAccuracy());
		}
		return true;
	}

	double dTempValue = pdValue*(ap->m_dMax - ap->m_dMin)/ap->m_dRange +ap->m_dMin;
	*value = MathTool::Round(dTempValue,typeInfo.getAccuracy());//[zhangcx v1.1.52]
	//*value = dTempValue;

	return true;
}

bool EtherCatPLC_E300::writeAnalog(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
	int nIndex = channelNum - 600;

	AnalogParam* ap = &(m_deviceParam.m_Output.m_vAOParam.at(nIndex));
	int nOffset = ap->m_nByteOffset;
	int nType = ap->m_nType;
	
	//double dTempValue = pdValue*(ap->m_dMax - ap->m_dMin)/ap->m_dRange +ap->m_dMin;
	//AnalogParam temp = m_EtherCatDevice[nMacID].m_Output.m_vAOParam.at(nVectorIndex);	
	double dTempValue = (value - ap->m_dMin)*ap->m_dRange/(ap->m_dMax - ap->m_dMin);
	cout<<dTempValue<<endl;
	if(1 == nType || 2 == nType)//sint || usint
	{
		m_pWriteBuffer[nOffset] = ((int)dTempValue & 0xff);
	}
	else if(3 == nType || 4 == nType || 7 == nType)//int || uint || word
	{
		m_pWriteBuffer[nOffset] = ((int)dTempValue & 0xff);	
		m_pWriteBuffer[nOffset+1] = (((int)dTempValue >> 8) & 0xff);
		//cout<<m_pWriteBuffer[nOffset] <<","<<m_pWriteBuffer[nOffset+1]<<endl;
					
	}
	else if(5 == nType || 6 == nType || 8 == nType)//dint || udint || dword
	{
		m_pWriteBuffer[nOffset] = ((int)dTempValue & 0xff);	
		m_pWriteBuffer[nOffset+1] = (((int)dTempValue >> 8) & 0xff);	
		m_pWriteBuffer[nOffset+2] = (((int)dTempValue >> 16) & 0xff);	
		m_pWriteBuffer[nOffset+3] = (((int)dTempValue >> 24) & 0xff);
	}
	else if(9 == nType)//real
	{
		unsigned char msg[4];

		FloatToByte(dTempValue, msg);

		m_pWriteBuffer[nOffset] = msg[0];
		m_pWriteBuffer[nOffset+1] = msg[1];
		m_pWriteBuffer[nOffset+2] = msg[2];
		m_pWriteBuffer[nOffset+3] = msg[3];	
	}
	else if(20 == nType)//BV
	{
		long temp;
		if(channelNum==606)//presureSP
		{
			temp = value*1000.0f;
			m_pWriteBuffer[nOffset+0] = (unsigned char)(0 & 0xff);
			m_pWriteBuffer[nOffset+2] = (unsigned char)(temp & 0xff);
			m_pWriteBuffer[nOffset+4] = (unsigned char)((temp>>8) & 0xff);
			m_pWriteBuffer[nOffset+6] = (unsigned char)(0 & 0xff);
		}
		else if(channelNum==607)//positionSP
		{
			temp = value*10000/typeInfo.getMax();
			cout<<dTempValue<<endl;
			cout<<typeInfo.getMax()<<endl;
			cout<<"temp = "<<temp<<endl;
			m_pWriteBuffer[nOffset+0] = (unsigned char)(0 & 0xff);
			m_pWriteBuffer[nOffset+2] = (unsigned char)(temp & 0x00ff);
			m_pWriteBuffer[nOffset+4] = (unsigned char)((temp>>8) & 0x00ff);
			m_pWriteBuffer[nOffset+6] = (unsigned char)(1 & 0xff);
		}
	}
	else if(21 == nType)//314
	{
		int nMaxPressure = typeInfo.getMax();
		int nTempValue =(int)((value / nMaxPressure) * 32767);
		m_pWriteBuffer[nOffset+0] = nTempValue & 0xff;
		m_pWriteBuffer[nOffset+1] = (nTempValue >> 8) & 0xff;
	}
	
	m_EtherCat->writeByte(m_nMacID, m_pWriteBuffer);

	return true;
}

IMPLEMENT_DYNAMIC(EtherCatPLC_E300, EtherCatBaseDevice )
BEGIN_MSG_MAP( EtherCatPLC_E300, EtherCatBaseDevice )


END_MSG_MAP
