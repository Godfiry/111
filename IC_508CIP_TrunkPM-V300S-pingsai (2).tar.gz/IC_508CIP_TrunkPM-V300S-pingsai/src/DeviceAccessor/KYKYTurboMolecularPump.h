/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: KYKYTurboMolecularPump.h
** Description:   for Shimadzu TMP 
** Release: 1.1
** Modification history: 
**                     chensc create 20230411
*********************************************************************/

#ifndef KYKYTURBOMOLECULARPUMP_H_
#define KYKYTURBOMOLECULARPUMP_H_

#include "DeviceNode.h"
#include "SerialDevice.h"
#include <string>
#include<iostream>
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class KYKYTurboMolecularPump: public SerialDevice
{
	DECLARE_DYNAMIC(KYKYTurboMolecularPump)
	DECLARE_MSG_MAP
	
	public:
		KYKYTurboMolecularPump();
		virtual ~KYKYTurboMolecularPump();
		
	public://override
		 void init();  //init the device 
		 virtual std::string getDeviceName();
	
	public://interface
		bool readDouble(int channelNum,double * dValue ,const DoubleTypeInfo& typeinfo);//Read Double
		bool readInt(int channelNum,int * value ,const IntTypeInfo& typeinfo);

		
	protected://override
		void initChs(DeviceNode<KYKYTurboMolecularPump> *node);//inint channel
		void initDevice();
				
	private:
		char m_pReadCmd[8];   //read command array	
		static const int RESP_LEN = 200;//the buff length
};

#endif /*KYKYTURBOMOLECULARPUMP_H_*/
