/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					Jan 22, 2008  shenql  create 
**      
***************************************************************************/
#ifndef PMANMINFO_H_
#define PMANMINFO_H_
class PMAnmInfo : public IntValueInfo
{
public:

		static const int UnInit = -1;
		static const int Init = 0;
		static const int Preparing = 1;
		static const int Prepared = 2;
		static const int Processing = 3;
		static const int Processed = 4;
		static const int Aborted = 5;
		static const IntTypeInfo typeInfo;

	   PMAnmInfo():IntValueInfo(-1, typeInfo)
	   {
	   }
	
	   PMAnmInfo(int i):IntValueInfo(i, typeInfo)
	    {
	    }
	
	   PMAnmInfo(std::string s):IntValueInfo(s, typeInfo)
	    {
	    }
};


#endif /*PMANMINFO_H_*/
