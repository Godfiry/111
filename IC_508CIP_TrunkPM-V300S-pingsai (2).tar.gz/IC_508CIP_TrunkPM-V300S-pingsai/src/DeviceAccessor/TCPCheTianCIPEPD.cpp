﻿/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TCPCheTianEPD.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2021-6-25   Zhongchenyu create
**      
*********************************************************************/
#include "TCPCheTianCIPEPD.h"
#include "DeviceManager.h"
#include "SysLogger.h"
#include "ConfigException.h"
#include <iostream>
#include <string.h>
#include <ctype.h>
#include <sstream>
#include "Converter.h"
#include "Hex.h"
#include "IStringList.h"
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std;

TCPCheTianCIPEPD::TCPCheTianCIPEPD()
{
	m_RecpName = "";
	m_x1=0.0;
	m_x2=0.0;
	//[wangyk 1.10.0 change]
	for(int i = 0; i < 2; i++)
	{
		m_eventstart[i] = -1;
		m_eventdelay[i] = -1;
		m_eventnormaliazation[i] = -1;
		m_eventsatisfy[i] = -1;
		m_eventstop[i] = -1;
		m_runstatus[i] = -1;
		m_setrunstatus[i] = -1;
		m_operatestatus[i] = -1;
		m_trenddata1[i]=0.0;
		m_trenddata2[i]=0.0;
		m_trenddata3[i]=0.0;
		m_trenddata4[i]=0.0;
		m_trenddata5[i]=0.0;
		m_trenddata6[i]=0.0;
		m_readx1[i]=0.0;
		m_readx2[i]=0.0;
	    m_lot[i] = "";
	    m_slot[i] = "";
	    m_Waferid[i] = "";
	}
	m_bDoubleChannelEnabled = false;
}

TCPCheTianCIPEPD::~TCPCheTianCIPEPD()
{
}

bool TCPCheTianCIPEPD::writeI(int channelNum, int setpt, const IntTypeInfo &)
{
	//sendCmd(&m_CONNECT);
	switch(channelNum)
	{	
		case 1://recipestart
			sendCmd(&m_RECIPESTART);
			if(m_bDoubleChannelEnabled)	//[wangyk 1.10.0 add]
			{
				sendCmd(&m_RECIPESTART, 1);
			}
			break;
			
		case 2://recipestop
			sendCmd(&m_RECIPESTOP);
			if(m_bDoubleChannelEnabled)	//[wangyk 1.10.0 add]
			{
				sendCmd(&m_RECIPESTOP, 1);
			}
			break;

		case 3://complete
			sendCmd(&m_COMPLETED);
			if(m_bDoubleChannelEnabled)//[wangyk 1.10.0 add]
			{
				sendCmd(&m_COMPLETED, 1);
			}
			break;	
			
		case 4://start
			m_endpoint[0] = 0;//[wangyk 1.10.0 change]
			m_endpoint[1] = 0;
			m_epdtime[0] = 0.0;
			m_epdtime[1] = 0.0;
			sendCmd(&m_START);
			if(m_bDoubleChannelEnabled)//[wangyk 1.10.0 add]
			{
				sendCmd(&m_START, 1);
			}
			break;	
			
		case 5://stop
			sendCmd(&m_STOP);
			if(m_bDoubleChannelEnabled)//[wangyk 1.10.0 add]
			{
				sendCmd(&m_STOP, 1);
			}
			m_endpoint[0] = 0;//[wangyk 1.10.0 change]
			m_endpoint[1] = 0;
			//m_epdtime = 0.0;//delete sp 20240607
			break;	
		case 12://cfglist
			sendCmd(&m_CFGLIST);
			if(m_bDoubleChannelEnabled)//[wangyk 1.10.0 add]
			{
				sendCmd(&m_CFGLIST, 1);
			}
			break;	
		case 13://version
			sendCmd(&m_VERSION);
			if(m_bDoubleChannelEnabled)//[wangyk 1.10.0 add]
			{
				sendCmd(&m_VERSION, 1);
			}
			break;
		case 26://reset
			sendCmd(&m_RESET);
			if(m_bDoubleChannelEnabled)//[wangyk 1.10.0 add]
			{
				sendCmd(&m_RESET, 1);
			}
			break;	
		case 27://connect
			//setPort(CheTian_TCPIP_PORT);
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianCIPEPD sending cmd -ZZZZZZ");
			TCPDevice::init();	//??
			sendCmd(&m_CONNECT);
			if(m_bDoubleChannelEnabled)//[wangyk 1.10.0 add]
			{
				sendCmd(&m_CONNECT, 1);
			}
			break;
		case 28://disconnect
			sendCmd(&m_DISCONNECT);
			if(m_bDoubleChannelEnabled)//[wangyk 1.10.0 add]
			{
				sendCmd(&m_DISCONNECT, 1);
			}
			break;
		case 32://SetRunStatus
			m_setrunstatus[0] = setpt;//[wangyk 1.10.0 change]
			m_setrunstatus[1] = setpt;
			sendCmd(&m_SETRUNSTATUS);
			if(m_bDoubleChannelEnabled)//[wangyk 1.10.0 add]
			{
				sendCmd(&m_SETRUNSTATUS, 1);
			}
	
			break;		
		case 34://SetoperateStatus
			m_setoperatestatus[0] = setpt;
			m_setoperatestatus[1] = setpt;
			sendCmd(&m_SETOPERATESTATUS);
			if(m_bDoubleChannelEnabled)//[wangyk 1.10.0 add]
			{
				sendCmd(&m_SETOPERATESTATUS, 1);
			}
		
			break;	

			default:
			break;	
	}
	return true;
	
}

bool TCPCheTianCIPEPD::writeD(int channelNum, double value, const DoubleTypeInfo &)
{
	if (!isConnected())
	{
		throw IOException("device is not connected! ");
	}
	switch(channelNum)
	{
		case 42: // setx1
			m_x1 = value;
			sendCmd(&m_SETX1);
			if(m_bDoubleChannelEnabled)//[wangyk 1.10.0 add]
			{
				sendCmd(&m_SETX1, 1);
			}
			break;
		case 44: // setx1
			m_x2 = value;
			sendCmd(&m_SETX2);
			if(m_bDoubleChannelEnabled)//[wangyk 1.10.0 add]
			{
				sendCmd(&m_SETX2, 1);
			}
			break;
		
		default:
		break;
	}

	return true;

}

bool TCPCheTianCIPEPD::writeS(int channelNum, std::string value, const StringTypeInfo &)
{
	if (!isConnected())
	{
		throw IOException("device is not connected! ");
	}
	int p_nChannelNo = channelNum/100;//[wangyk 1.10.0 add]
	channelNum = (channelNum % 100 >= 7 && channelNum % 100 < 10) ? channelNum % 100 : channelNum;

	switch(channelNum)
	{
		case 6: // configname
			m_configName = value;
			return true;
			
		case 7: //lot
			m_lot[p_nChannelNo] = value;//[wangyk 1.10.0 change]
			break;
			
		case 8: //slot
			m_slot[p_nChannelNo] = value;
			break;
			
		case 9: // wafer
			m_Waferid[p_nChannelNo] = value;
			break;
			
		case 10: //recipe
			m_RecpName = value;
			break;
			
		case 11: //step
			m_Step = value;
			break;
		case 30: //querydata
			//m_querydatda = value;
			break;
	}
	if(channelNum != 6)
	{
		sendWfrInfo(channelNum, 0);
		if(m_bDoubleChannelEnabled)//[wangyk 1.10.0 add]
		{
			sendWfrInfo(channelNum, 1);
		}
	}
	
	return true;
}


bool TCPCheTianCIPEPD::readI(int channelNum, int *value, const IntTypeInfo &)
{
	if (!isConnected())
	{
		throw IOException("device is not connected! ");
	}
	int p_nChannelNo = channelNum/100;//[wangyk 1.10.0 add]
	int p_nChannelNum = channelNum%100;
	switch(p_nChannelNum)
	{
		case 14: // state
			sendCmd(&m_STATE);
			//sendCmd(&m_DISCONNECT);
			*value = m_status[p_nChannelNo];//[wangyk 1.10.0 change]
			break;
			
		case 15: //EndPoint			
			*value = m_endpoint[p_nChannelNo];
			break;
		case 29://HEATBEAT
			//sendCmd(&m_HEATBEAT);
			if(isConnected())
			{
				sendCmd(&m_HEATBEAT);
			}
			*value = 1;
			break;	
		case 31: //RunStatus		
			//sendCmd(&m_QUERYRUNSTATUS);
			*value = m_runstatus[p_nChannelNo];
			break;	
		case 33: //OperateStatus	
			//sendCmd(&m_QUERYOPERATESTATUS);
			*value = m_operatestatus[p_nChannelNo];
			break;
	}
	return true;
}

bool TCPCheTianCIPEPD::readD(int channelNum, double *value, const DoubleTypeInfo &)
{
	if (!isConnected())
	{
		throw IOException("device is not connected! ");
	}
	int p_nChannelNo = channelNum/100;//[wangyk 1.10.0 add]
	int p_nChannelNum = channelNum%100;
	switch(p_nChannelNum)
	{
		case 16: // time
			*value = m_epdtime[p_nChannelNo];//[wangyk 1.10.0 change]
			break;
			
		//case 15: //EndPoint			
			//*value = m_endpoint;
			//break;
		case 35: //querydata1			
			*value = m_trenddata1[p_nChannelNo];
			break;	
		case 36: //querydata2	
			*value = m_trenddata2[p_nChannelNo];
			break;			
		case 37: //querydata3			
			*value = m_trenddata3[p_nChannelNo];
			break;	
		case 38: //querydata4			
			*value = m_trenddata4[p_nChannelNo];
			break;	

		case 39: //querydata5			
			*value = m_trenddata5[p_nChannelNo];
			break;	

		case 40: //querydata6			
			*value = m_trenddata6[p_nChannelNo];
			break;	
		
		case 41: //queryx1	
		    sendCmd(&m_QUERYX1, p_nChannelNo);
			*value = m_readx1[p_nChannelNo];
			break;
		
		case 43: //queryx2	
		    sendCmd(&m_QUERYX2, p_nChannelNo);
			*value = m_readx2[p_nChannelNo];
			break;	
	}

	return true;
}


void TCPCheTianCIPEPD::sendWfrInfo(int channelNum, int nChannelNo)
{
	int t_size = 0;
        std::string value;
        switch(channelNum)
        {
			case 7: //lot
				value = "LotName:" + m_lot[nChannelNo];
				break;

			case 8: //slot
				value = "Slot:" + m_slot[nChannelNo];
				break;

			case 9: // wafer
				value = "WaferID:" + m_Waferid[nChannelNo];
				break;

		case 10: //recipe
			value = "Recipe:" + m_RecpName;
			break;
			
		case 11: //step
			value = "Step:" + m_Step;
			break;

		case 30: //querydata
			//m_querydatda = value;
			break;
        }
        int len = value.length();
        char swi[10+len];
        memset(swi, 0, sizeof(swi));
        swi[0] = 0x01;
        swi[1] = 0x01;
        swi[2] = 0x00;
        swi[3] = 0x00;
        swi[4] = 0x00;
        swi[5] = 0x06;
        memcpy(swi+6, &len, 4);
        memcpy(swi+10, value.c_str(), len);
        t_size = 10 + len;
        sendData(swi, t_size);
}

void TCPCheTianCIPEPD::initChannels(DeviceNode<TCPCheTianCIPEPD> *node)
{
	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &TCPDevice::getStatus);
    for(int i = 0; i < 2; i++)//[wangyk 1.10.0 change]
    {
    	int t_nChannelNum = i * 100;
        for(int j = t_nChannelNum + 1; j <= t_nChannelNum + 5; j++)
        {
            node->registerWriteCh(j,&TCPCheTianCIPEPD::writeI);
        }
        for(int j = t_nChannelNum + 6; j <= t_nChannelNum + 11; j++)
        {
            node->registerWriteCh(j,&TCPCheTianCIPEPD::writeS);
        }
        for(int j = t_nChannelNum + 12; j <= t_nChannelNum + 13; j++)
        {
            node->registerWriteCh(j,&TCPCheTianCIPEPD::writeI);
        }
        node->registerReadCh(t_nChannelNum + 14,&TCPCheTianCIPEPD::readI);
        node->registerReadCh(t_nChannelNum + 15,&TCPCheTianCIPEPD::readI);
        for(int j = t_nChannelNum + 16; j <= t_nChannelNum + 22; j++)
        {
            node->registerReadCh(j,&TCPCheTianCIPEPD::readD);
        }
        for(int j = t_nChannelNum + 23; j <= t_nChannelNum + 25; j++)
        {
            node->registerReadCh(j,&TCPCheTianCIPEPD::readS);
        }
        for(int j = t_nChannelNum + 26; j <= t_nChannelNum + 28; j++)
        {
            node->registerWriteCh(j,&TCPCheTianCIPEPD::writeI);
        }
    	node->registerReadCh(t_nChannelNum + 29,&TCPCheTianCIPEPD::readI);
    	node->registerReadCh(t_nChannelNum + 31,&TCPCheTianCIPEPD::readI);//querystatus
    	node->registerWriteCh(t_nChannelNum + 32,&TCPCheTianCIPEPD::writeI);//setRunstatus
    	node->registerReadCh(t_nChannelNum + 33,&TCPCheTianCIPEPD::readI);//queryOperatestatus
    	node->registerWriteCh(t_nChannelNum + 34,&TCPCheTianCIPEPD::writeI);//setOperatestatus
    	for(int j = t_nChannelNum + 35; j <= t_nChannelNum + 40; j++)
    	{
    		node->registerReadCh(j,&TCPCheTianCIPEPD::readD);//querydata
    	}
    	node->registerReadCh(t_nChannelNum + 41,&TCPCheTianCIPEPD::readD);//queryx1
    	node->registerWriteCh(t_nChannelNum + 42,&TCPCheTianCIPEPD::writeD);//setx1
    	node->registerReadCh(t_nChannelNum + 43,&TCPCheTianCIPEPD::readD);//queryx2
    	node->registerWriteCh(t_nChannelNum + 44,&TCPCheTianCIPEPD::writeD);//setx2
    }
}

void TCPCheTianCIPEPD::initCmd()
{
    TCPCheTianEPD::initCmd();
	m_QUERYRUNSTATUS.m_name = "QUERYRUNSTATUS";
	m_QUERYRUNSTATUS.m_cmd = 0x31;
	m_QUERYRUNSTATUS.m_status[0] = 0x00;
	m_QUERYRUNSTATUS.m_status[1] = 0x00;
	m_QUERYRUNSTATUS.m_errormsg = "";
	m_QUERYRUNSTATUS.m_datalength = 4;
	m_QUERYRUNSTATUS.m_reslength = 0;
	
	m_SETRUNSTATUS.m_name = "SETRUNSTATUS";
	m_SETRUNSTATUS.m_cmd = 0x32;
	m_SETRUNSTATUS.m_status[0] = 0x00;
	m_SETRUNSTATUS.m_status[1] = 0x00;
	m_SETRUNSTATUS.m_errormsg = "";
	m_SETRUNSTATUS.m_datalength = 4;
	m_SETRUNSTATUS.m_reslength = 0;

	/*m_SETRUNSTATUS.m_name = "QUERYRUNSTATUS";
	m_SETRUNSTATUS.m_cmd = 0x31;
	m_SETRUNSTATUS.m_status[0] = 0x00;
	m_SETRUNSTATUS.m_status[1] = 0x00;
	m_SETRUNSTATUS.m_errormsg = "";
	m_SETRUNSTATUS.m_datalength = 0;
	m_SETRUNSTATUS.m_reslength = 0;*/

	m_SETOPERATESTATUS.m_name = "SETOPERATESTATUS";
	m_SETOPERATESTATUS.m_cmd = 0x34;
	m_SETOPERATESTATUS.m_status[0] = 0x00;
	m_SETOPERATESTATUS.m_status[1] = 0x00;
	m_SETOPERATESTATUS.m_errormsg = "";
	m_SETOPERATESTATUS.m_datalength = 4;
	m_SETOPERATESTATUS.m_reslength = 0;

	m_QUERYOPERATESTATUS.m_name = "QUERYOPERATESTATUS";
	m_QUERYOPERATESTATUS.m_cmd = 0x33;
	m_QUERYOPERATESTATUS.m_status[0] = 0x00;
	m_QUERYOPERATESTATUS.m_status[1] = 0x00;
	m_QUERYOPERATESTATUS.m_errormsg = "";
	m_QUERYOPERATESTATUS.m_datalength = 4;
	m_QUERYOPERATESTATUS.m_reslength = 0;

	m_SETX1.m_name = "SETX1";
	m_SETX1.m_cmd = 0x36;
	m_SETX1.m_status[0] = 0x00;
	m_SETX1.m_status[1] = 0x00;
	m_SETX1.m_errormsg = "";
	m_SETX1.m_datalength = 4;
	m_SETX1.m_reslength = 0;

	m_QUERYX1.m_name = "QUERYX1";
	m_QUERYX1.m_cmd = 0x35;
	m_QUERYX1.m_status[0] = 0x00;
	m_QUERYX1.m_status[1] = 0x00;
	m_QUERYX1.m_errormsg = "";
	m_QUERYX1.m_datalength = 4;
	m_QUERYX1.m_reslength = 0;

	m_SETX2.m_name = "SETX2";
	m_SETX2.m_cmd = 0x38;
	m_SETX2.m_status[0] = 0x00;
	m_SETX2.m_status[1] = 0x00;
	m_SETX2.m_errormsg = "";
	m_SETX2.m_datalength = 4;
	m_SETX2.m_reslength = 0;

	m_QUERYX2.m_name = "QUERYX2";
	m_QUERYX2.m_cmd = 0x37;
	m_QUERYX2.m_status[0] = 0x00;
	m_QUERYX2.m_status[1] = 0x00;
	m_QUERYX2.m_errormsg = "";
	m_QUERYX2.m_datalength = 4;
	m_QUERYX2.m_reslength = 0;

}

void TCPCheTianCIPEPD::init()
{
	DeviceNode<TCPCheTianCIPEPD> *node = new DeviceNode<TCPCheTianCIPEPD>(m_pollInterval,this);
	DeviceManager::getInstance()->registerNode(m_nodeNum,node);	
	if(!isSimulated())
	{
		initChannels(node);
		setPort(CheTian_TCPIP_PORT);
		TCPDevice::init();	
		initEPD();
	}
}

bool TCPCheTianCIPEPD::reconnectDevice()
{
	if(!m_running)
	{
		return false;
	}
	try
	{
		connectEPD();
	}
	catch(const exception &ex)
	{
		return false;
	}
	return TCPDevice::reconnectDevice();
}
void TCPCheTianCIPEPD::sendCmd(Cmd *cmd, int nChannelNo)//[wangyk 1.10.0 change]
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianCIPEPD sending cmd -" + cmd->m_name + " channelNo = " + Converter::convertToString(nChannelNo));		
	memset(m_sndBuffer, 0, sizeof(m_sndBuffer));

	//added by liusy[1.1.39]  
	cmd->m_status[0] = 0xFFFFFFFF;
	m_RESPONSE.m_status[0] = 0X00;
	m_RESPONSE.m_status[1] = 0X00;
	char t_orgdata[4];
	for(int i=0;i<4;i++)
	{
		t_orgdata[i] = 0x00;
	}
	m_head[0]=0x01;
	m_head[1]=0x01;
	m_head[2]=0x00;
	m_head[3]=0x00;
	int t_size = 4;
	
	for(int i=0;i<t_size;i++)
	{
		m_sndBuffer[i] = m_head[i];
		//cout<<"buffer["<<i<<"]"<<hex<<(int)m_sndBuffer[i]<<endl;
	}
    if(nChannelNo == 0)//[wangyk 1.10.0 change]
    {
        m_sndBuffer[t_size] = 0x00;
    }
    else
    {
        m_sndBuffer[t_size] = 0x01;
    }
	//cout<<"buffer["<<t_size<<"]"<<hex<<(int)m_sndBuffer[t_size]<<endl;
	t_size = t_size+1;
	m_sndBuffer[t_size] = cmd->m_cmd;
	//cout<<"buffer["<<t_size<<"]"<<hex<<(int)m_sndBuffer[t_size]<<endl;
	
	if(cmd->m_name == "START")	
	{
		t_orgdata[0] = 0xFF;
		//cout<<"buffercmd["<<t_size<<"]"<<hex<<(int)m_sndBuffer[t_size]<<endl;
		for(int i=0;i< 4; i++)
		{
			t_size ++;
			m_sndBuffer[t_size] = t_orgdata[i];
			//cout<<"buffer1["<<t_size<<"]"<<hex<<(int)m_sndBuffer[t_size]<<endl;
		}
		for(int i=0;i< m_configName.length(); i++)
		{
			t_size++;
			m_sndBuffer[t_size] = m_configName[i];
			//cout<<"buffer2["<<t_size<<"]"<<hex<<(int)m_sndBuffer[t_size]<<endl;
		}
		t_size = 266;
		sendData(m_sndBuffer, t_size);
	}
	else if(cmd->m_name == "RECIPESTART")	
	{
		t_orgdata[0] = 0xFF;
		//cout<<"buffercmd["<<t_size<<"]"<<hex<<(int)m_sndBuffer[t_size]<<endl;
		for(int i=0;i< 4; i++)
		{
			t_size ++;
			m_sndBuffer[t_size] = t_orgdata[i];
			//cout<<"buffer1["<<t_size<<"]"<<hex<<(int)m_sndBuffer[t_size]<<endl;
		}
		for(int i=0;i< m_RecpName.length(); i++)
		{
			t_size++;
			m_sndBuffer[t_size] = m_RecpName[i];
			//cout<<"buffer2["<<t_size<<"]"<<hex<<(int)m_sndBuffer[t_size]<<endl;
		}
		t_size = 266;
		sendData(m_sndBuffer, t_size);
	}
	else if(cmd->m_name == "SETRUNSTATUS")
	{
		t_orgdata[0] = 0x04;
		for(int i=0;i< 4; i++)
		{
			t_size ++;
			m_sndBuffer[t_size] = t_orgdata[i];
			//cout<<"bufferorgrun["<<t_size<<"]"<<hex<<(int)m_sndBuffer[t_size]<<endl;
		}

		if(m_setrunstatus[nChannelNo] == 1)//[wangyk 1.10.0 change]
		{
			m_sndBuffer[t_size+1] =0x01;
		}
		else if(m_setrunstatus[nChannelNo] == 2)
		{
			m_sndBuffer[t_size+1] =0x02;
		}
		else if(m_setrunstatus[nChannelNo] == 3)
		{
			m_sndBuffer[t_size+1] =0x03;
		}
		else if(m_setrunstatus[nChannelNo] == 4)
		{
			m_sndBuffer[t_size+1] =0x04;
		}			
		t_size = 14;
		sendData(m_sndBuffer, t_size);
	}
	else if(cmd->m_name == "SETOPERATESTATUS")
	{
		
		t_orgdata[0] = 0x04;
		for(int i=0;i< 4; i++)
		{
			t_size ++;
			m_sndBuffer[t_size] = t_orgdata[i];
			//cout<<"bufferorgope["<<t_size<<"]"<<hex<<(int)m_sndBuffer[t_size]<<endl;
		}

			if(m_setoperatestatus[nChannelNo] == 1)//[wangyk 1.10.0 change]
			{
				m_sndBuffer[t_size+1] =0x01;
			}
			else if(m_setoperatestatus[nChannelNo] == 2)
			{
				m_sndBuffer[t_size+1] =0x02;
			}

		t_size = 14;

		sendData(m_sndBuffer, t_size);
	}	
	else if(cmd->m_name == "SETX1")
	{
		t_orgdata[0] = 0x04;
		for(int i=0;i< 4; i++)
		{
			t_size ++;
			m_sndBuffer[t_size] = t_orgdata[i];
			//cout<<"bufferorgope["<<t_size<<"]"<<hex<<(int)m_sndBuffer[t_size]<<endl;
		}
		if(m_x1 == -1)
		{
			m_sndBuffer[t_size+1]=0x9c;		
		}
		else
		{				
			m_sndBuffer[t_size+1] =(int)(100*m_x1);
			m_sndBuffer[t_size+2] =((int)(100*m_x1)>>8);
			m_sndBuffer[t_size+3] =((int)(100*m_x1)>>16);
			m_sndBuffer[t_size+4] =((int)(100*m_x1)>>24);
		}

		t_size = 14;

		sendData(m_sndBuffer, t_size);


	}
	else if(cmd->m_name == "SETX2")
	{
		t_orgdata[0] = 0x04;
		for(int i=0;i< 4; i++)
		{
			t_size ++;
			m_sndBuffer[t_size] = t_orgdata[i];
			//cout<<"bufferorgope["<<t_size<<"]"<<hex<<(int)m_sndBuffer[t_size]<<endl;
		}

		if(m_x2 == -1)
		{
			m_sndBuffer[t_size+1]=0x9c;		
		}

		else
		{
			m_sndBuffer[t_size+1] =(int)(100*m_x2);
			m_sndBuffer[t_size+2] =((int)(100*m_x2)>>8);
			m_sndBuffer[t_size+3] =((int)(100*m_x2)>>16);
			m_sndBuffer[t_size+4] =((int)(100*m_x2)>>24);
		}
		t_size = 14;

		sendData(m_sndBuffer, t_size);

	}
	else if(cmd->m_name == "QUERYX1")
	{
		t_orgdata[0] = 0x04;
		for(int i=0;i< 4; i++)
		{
			t_size ++;
			m_sndBuffer[t_size] = t_orgdata[i];
			//cout<<"bufferorgope["<<t_size<<"]"<<hex<<(int)m_sndBuffer[t_size]<<endl;
		}

		if(m_readx1[nChannelNo] == -1)//[wangyk 1.10.0 change]
		{
			m_sndBuffer[t_size+1]=0x9c;		
		}
		//[wangyk 1.10.0 change]
		else
		{
			m_sndBuffer[t_size+1] =(int)(100*m_readx1[nChannelNo]);//[wangyk 1.10.0 change]
			m_sndBuffer[t_size+2] =((int)(100*m_readx1[nChannelNo])>>8);
			m_sndBuffer[t_size+3] =((int)(100*m_readx1[nChannelNo])>>16);
			m_sndBuffer[t_size+4] =((int)(100*m_readx1[nChannelNo])>>24);
		}
		t_size = 14;

		sendData(m_sndBuffer, t_size);

	}
	else if(cmd->m_name == "QUERYX2")
	{
		t_orgdata[0] = 0x04;
		for(int i=0;i< 4; i++)
		{
			t_size ++;
			m_sndBuffer[t_size] = t_orgdata[i];
			//cout<<"bufferorgope["<<t_size<<"]"<<hex<<(int)m_sndBuffer[t_size]<<endl;
		}
		//[wangyk 1.10.0 change]
		if(m_readx2[nChannelNo] == -1)
		{
			m_sndBuffer[t_size+1]=0x9c;		
		}

		else
		{
			m_sndBuffer[t_size+1] =(int)(100*m_readx2[nChannelNo]);
			m_sndBuffer[t_size+2] =((int)(100*m_readx2[nChannelNo])>>8);
			m_sndBuffer[t_size+3] =((int)(100*m_readx2[nChannelNo])>>16);
			m_sndBuffer[t_size+4] =((int)(100*m_readx2[nChannelNo])>>24);
		}
		t_size = 14;

		sendData(m_sndBuffer, t_size);

	}
	else
	{
		for(int i=0;i< 4; i++)
		{
			t_size = t_size+1;
			m_sndBuffer[t_size] = t_orgdata[i];
			//cout<<"buffer["<<t_size<<"]"<<hex<<(int)m_sndBuffer[t_size]<<endl;
		}
		t_size = t_size+1;
		//cout<<"t_size is "<<t_size<<endl;
		//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianCIPEPD other sending cmd -"+ Hex::GetHexString(m_sndBuffer,t_size));
		sendData(m_sndBuffer, t_size);
		
	}
	
	
	int t_leftcount = m_timeOut*1000/m_checkInterval;

	while(t_leftcount > 0)//added by liusy[1.1.39]  
	{
		if(cmd->m_status[0] == 0xFFFFFFFF)
		{

		}
		else
		{ 
			if(cmd->m_status[0] == 0x00)
			{	
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianCIPEPD sended cmd -" + cmd->m_name);		
				return;
			}
			else 
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": TCPCheTianCIPEPD get fail ack for cmd - "+ cmd->m_name + ".error is " + cmd->m_errormsg);
				throw IOException("get fail ack for cmd - "+ cmd->m_name + ".error is " + cmd->m_errormsg);
			}
		}
		usleep(m_checkInterval*1000);
		--t_leftcount;
	}	
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": TCPCheTianCIPEPD waiting for cmd ack time out-" + cmd->m_name);	
	throw IOException("waiting for cmd ack time out-" + cmd->m_name);
}

void TCPCheTianCIPEPD::acceptData()
{
	IMutexLocker t_locker(&m_lock);
	memset(m_recvBuffer, 0, sizeof(m_recvBuffer));

	if(readData(m_recvBuffer,14))
	{
		//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianCIPEPD receive data -"+ Hex::GetHexString(m_recvBuffer,14));
		/*for(int i = 0; i < 14; i++)
		{
			cout<<"result is : "<<i<<hex<<(int)m_recvBuffer[0]<<endl;
		}*/
		preRead(m_recvBuffer);
		if(m_RESPONSE.m_cmd != 0x0A)
		{
			replyCmd();
		}
		else
		{
			replyEvent();
		}
	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": TCPCheTianCIPEPD reading header failed in acceptData()");			
	}
}

void TCPCheTianCIPEPD::preRead(char *buffer)
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD preread");
	char t_status[4];
	char t_length[4];
	int t_len;
	
	
	if(m_recvBuffer[0]==0x01 && m_recvBuffer[1] == 0x01)
	{
		//[wangyk 1.10.0 change]
		//cout<<"recvbuffer"<<endl;
		m_RESPONSE.m_channel = m_recvBuffer[4];
		m_RESPONSE.m_cmd = m_recvBuffer[5];
		m_RESPONSE.m_status[0] =0x00;
		m_RESPONSE.m_status[1] = 0x00;

		int m_nChannelNum = (m_RESPONSE.m_channel==0x00)?0:1;
		if(m_recvBuffer[7] == 0x10)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": TCPCheTianCIPEPD have received ErrorCode :" + Converter::convertToString(m_recvBuffer[7]) + "  "+Converter::convertToString(m_recvBuffer[6]));
			m_RESPONSE.m_status[0] = m_recvBuffer[7];
			m_RESPONSE.m_status[1] = m_recvBuffer[6];
			m_error[m_nChannelNum] =  replyErrorMsg(m_RESPONSE.m_status);
			return;
		}
		else
		{
			//m_RESPONSE.m_status[0] = 0X00;
			//m_RESPONSE.m_status[1] = 0X00;
			m_error[m_nChannelNum] = "";//added by liusy[1.1.39]
		}
		if(m_RESPONSE.m_cmd == 0x0A)
		{
			unsigned int result = 0;
			char ch;
			result = ((m_recvBuffer[13]<<24)&0xff000000) + ((m_recvBuffer[12]<<16)&0xff0000) + ((m_recvBuffer[11]<<8)&0xff00) + (m_recvBuffer[10]&0xff);	
		
			if (BUFFER_SIZE >= result) //add by chenw [1.5.0]
			{
			    readData(m_recvBuffer,result);
			}
			else
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": TCPCheTianCIPEPD get data len more than BUFFER_SIZE, need check chetian OES log for more info ."+"Result is "+Converter::convertToString(result));
				throw IOException(getDeviceName() + " get data len more than BUFFER_SIZE");
			}
			//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianCIPEPD receive data -"+ Hex::GetHexString(m_recvBuffer,result));

			if(m_recvBuffer[0]==0x07)
			{
				m_endpoint[m_nChannelNum] = 1;
				char t_epdtime[256];
				int t_epdtimeInt=0;
			    //string t_epdtimelist[256];
				//string t_epdtimeFinal = "";
				
				t_epdtimeInt = ((m_recvBuffer[15]<<24)&0xff000000) + ((m_recvBuffer[14]<<16)&0xff0000) + ((m_recvBuffer[13]<<8)&0xff00) + (m_recvBuffer[12]&0xff);	

				m_epdtime[m_nChannelNum]=(double)t_epdtimeInt/1000;
		        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of epdtime,  "+ Converter::convertToString(m_epdtime));

			}
			else if(m_recvBuffer[0]==0x03)
			{
		        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of eventstart,  ");

				m_eventstart[m_nChannelNum] = 1;

			}
			else if(m_recvBuffer[0]==0x04)
			{
		        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of eventdelay,  ");
	
			    m_eventdelay[m_nChannelNum] = 1;

			}
			else if(m_recvBuffer[0]==0x05)
			{
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of event normalization,  ");

				m_eventnormaliazation[m_nChannelNum] = 1;

			}
			else if(m_recvBuffer[0]==0x06)
			{
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of eventsatisfy,  ");

				m_eventsatisfy[m_nChannelNum] = 1;
			
			}
			else if(m_recvBuffer[0]==0x08)
			{
		        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of eventstop,  ");

				m_eventstop[m_nChannelNum] = 1;
			
			}
		    else if(m_recvBuffer[0]==0x01)
			{
		        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of stringout,  ");
				
			}
			else if(m_recvBuffer[0]==0x10)
			{
					char t_trenddata[256];
					
					string t_trenddatalist[256];   //changed by wzd 1.1.65 hotfix3 for SUSE offline
					string t_trenddataFinal = "";
					vector<string> t_trenddatasplit;
					string temp[5];         //changed by wzd 1.1.65 hotfix3 for SUSE offline
					//m_configlist = "D";
		            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of trenddata,  ");
					
					for(int i = 0;i< 256;i++)
					{
					    t_trenddata[i] = m_recvBuffer[28+i];
						t_trenddatalist[i] = t_trenddata[i];
						t_trenddataFinal += t_trenddatalist[i];
				
					}
						t_trenddatasplit =IStringList::split(t_trenddataFinal,",");
                    if(t_trenddatasplit.size() == 7)
            	    {
						//[wangyk 1.10.0 change]
            			Converter::stringToDouble(m_trenddata1[m_nChannelNum],t_trenddatasplit[0]);
						Converter::stringToDouble(m_trenddata2[m_nChannelNum],t_trenddatasplit[1]);
						Converter::stringToDouble(m_trenddata3[m_nChannelNum],t_trenddatasplit[2]);
						Converter::stringToDouble(m_trenddata4[m_nChannelNum],t_trenddatasplit[3]);
						Converter::stringToDouble(m_trenddata5[m_nChannelNum],t_trenddatasplit[4]);
					    Converter::stringToDouble(m_trenddata6[m_nChannelNum],t_trenddatasplit[5]);
            		
            	    }
            	    else
                    {
            			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": get no enough treaddata(6), need check chetian OES log for more info ");
			            throw IOException(getDeviceName() + ": get no enough treaddata(6) ");
            	    }
			}
			
		}
		else if(m_RESPONSE.m_cmd == 0x07)
		{
			readData(m_recvBuffer,4);
			//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianCIPEPD receive data -"+ Hex::GetHexString(m_recvBuffer,4));
			int t_cfgnum = (int)m_recvBuffer[0];

			// add by pingsai Solve the problem that ePD only displays the first six correctly  [1.2.3hotfix]
			std::ostringstream oss;
			oss << t_cfgnum;
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianCIPEPD receive EPD Config Num-" + oss.str());

			char t_cfg[256];
			int t_cfgint[256];
			string t_cfglist[256];
			string t_cfglistFinal = "";
			//m_configlist = "D";
			//[wangyk 1.10.0 change]
			m_configlist[m_nChannelNum] = "";
			for(int j = 0; j < t_cfgnum; j++)
			{
				usleep(500);//added by zhangyy to fix bug[1.8.0]
				memset(m_recvBuffer, 0, 256);
				readData(m_recvBuffer,256);
				//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianCIPEPD receive data -"+ Hex::GetHexString(m_recvBuffer,256));
				for(int i = 0;i< 256;i++)
				{
					t_cfg[i] = m_recvBuffer[i];
					t_cfglist[i] = t_cfg[i];
					
					if(t_cfglistFinal == "")
					{
						t_cfglistFinal = t_cfglist[i];
					}
					else
					{
						t_cfglistFinal += t_cfglist[i];
					}
				}
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianCIPEPD receive EPDConfig :" + t_cfglistFinal);

				//t_cfglist=t_cfgint;
				//m_configlist = "D";
				//[wangyk 1.10.0 change]
				m_configlist[m_nChannelNum] = m_configlist[m_nChannelNum]+t_cfglistFinal.substr(0,t_cfglistFinal.find("."))+".epd,";
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianCIPEPD EPDConfigList :" + m_configlist[m_nChannelNum]);
				t_cfglistFinal = "";
			}
			
			
		}
		else if(m_RESPONSE.m_cmd == 0x08)
		{
			readData(m_recvBuffer,4);
			//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianCIPEPD receive data -"+ Hex::GetHexString(m_recvBuffer,4));
			//[wangyk 1.10.0 change]
			m_status[m_nChannelNum]= (int)m_recvBuffer[0];
			
		}
		else if(m_RESPONSE.m_cmd == 0x09)
		{
			readData(m_recvBuffer,32);
			//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianCIPEPD receive data -"+ Hex::GetHexString(m_recvBuffer,32));
			char t_ver[32];
			int t_verint[32];
			string t_verstr[32];
			string t_verFinal = "";
			for(int i = 0;i< 32;i++)
			{
				t_ver[i] = m_recvBuffer[i];
				t_verint[i] = t_ver[i];
				t_verstr[i] = t_verint[i];
				t_verFinal = t_verFinal + t_verstr[i];
			}
			m_version = t_verFinal;
			
		}
		else if(m_RESPONSE.m_cmd == 0x31 )
		{
			readData(m_recvBuffer,4);
			//cout<<"ch=31"<<endl;		
			m_runstatus[m_nChannelNum]= (int)m_recvBuffer[0];//[wangyk 1.10.0 change]
		}	
		else if(m_RESPONSE.m_cmd == 0x33 )
		{
			readData(m_recvBuffer,4);	
			//cout<<"ch=33"<<endl;
			m_operatestatus[m_nChannelNum]= (int)m_recvBuffer[0];//[wangyk 1.10.0 change]
		}	
		else if(m_RESPONSE.m_cmd == 0x35)
		{
			readData(m_recvBuffer,4);	
            unsigned char m_recvBuffer1[4];
            m_recvBuffer1[0] = m_recvBuffer[0];
            m_recvBuffer1[1] = m_recvBuffer[1];
            m_recvBuffer1[2] = m_recvBuffer[2];
            m_recvBuffer1[3] = m_recvBuffer[3];
			//cout<<hex<<(int)m_recvBuffer[0]<<" "<<(int)m_recvBuffer[1]<<" "<<(int)m_recvBuffer[2]<<" "<<(int)m_recvBuffer[3]<<endl;
			m_readx1[m_nChannelNum]=  (double)(((m_recvBuffer1[3]<<24)) + ((m_recvBuffer1[2]<<16)) + ((m_recvBuffer1[1]<<8)) + m_recvBuffer1[0])/100;
            //cout<<m_readx1<<endl;
		}	
		else if(m_RESPONSE.m_cmd == 0x37)
		{
			readData(m_recvBuffer,4);	
            unsigned char m_recvBuffer1[4];
            m_recvBuffer1[0] = m_recvBuffer[0];
            m_recvBuffer1[1] = m_recvBuffer[1];
            m_recvBuffer1[2] = m_recvBuffer[2];
            m_recvBuffer1[3] = m_recvBuffer[3];
			//cout<<hex<<(int)m_recvBuffer[0]<<" "<<(int)m_recvBuffer[1]<<" "<<(int)m_recvBuffer[2]<<" "<<(int)m_recvBuffer[3]<<endl;
			m_readx2[m_nChannelNum]=  (double)(((m_recvBuffer1[3]<<24)) + ((m_recvBuffer1[2]<<16)) + ((m_recvBuffer1[1]<<8)) + m_recvBuffer1[0])/100;
            //cout<<m_readx1<<endl;
		}

							
	}
} 
void TCPCheTianCIPEPD::replyCmd(Cmd *cmd)
{
	TCPCheTianEPD::replyCmd(cmd);

}

void TCPCheTianCIPEPD::replyEvent()
{
	readDatas();
	if(m_RESPONSE.m_res.empty())  //add by wzd 1.2.0
	{
		return;
	}
	const char *t_event = (m_RESPONSE.m_res).data();

	switch( t_event[8])
	{
		case 0x01://message
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got event MESSAGE, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			flush();
			break;
			
		case 0x02://error
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got event ERROR, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			m_RESPONSE.m_status[0] == 0x30;
			break;
 
		case 0x03://endpoint
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got event ENDPOINT, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			flush();
			break;
		default:
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got UNKNOWN EVENT:" + t_event[8] + ", length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			flush();
			break;
	}	
}

void TCPCheTianCIPEPD::replyCmd()
{
	switch(m_RESPONSE.m_cmd)
	{
		case 0x01://recipestart
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of RECIPESTART, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			replyCmd(&m_RECIPESTART);
			break;
			
		case 0x02://recipestop
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of RECIPESTOP, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			replyCmd(&m_RECIPESTOP);
			break;			
			
		case 0x03://complete
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of COMPLETED, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			replyCmd(&m_COMPLETED);
			break;
			
		case 0x04://start
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of START, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			replyCmd(&m_START);
			break;
			
		case 0x05://stop
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of STOP, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			replyCmd(&m_STOP);
			break;			
			
		case 0x06://waferinfo
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of WAFERINFO, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			replyCmd(&m_WAFERINFO);
			break;
			
		case 0x07://cfglist
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of CFGLIST, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			replyCmd(&m_CFGLIST);
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got CFGLIST :" );
			break;
			
		case 0x08://epd state
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of STATE, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			replyCmd(&m_STATE);
			m_STATE.m_res = m_RESPONSE.m_res;
	   	 	break;
	   	 	
		case 0x09://version			
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of VERSION, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
	   	 	replyCmd(&m_VERSION);
			m_VERSION.m_res = m_RESPONSE.m_res;
	   	 	break;
	   	 	
		case 0x0A://event
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of EVENT, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			replyCmd(&m_EVENT);
	   	 	break;

		case 0x10://CONNECT
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of CONNECT, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			replyCmd(&m_CONNECT);
	   	 	break;

		case 0x11://DISCONNECT
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of DISCONNECT, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			replyCmd(&m_DISCONNECT);
	   	 	break;

		case 0x20://HAERTBEAT
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of HEATBEAT, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			replyCmd(&m_HEATBEAT);
	   	 	break;
	   	 	
		case 0x32://SETRUNSTATUS
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of SETRUNSTATUS, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			replyCmd(&m_HEATBEAT);
	   	 	break;
	   	 	
	  case 0x34://SETOPERATESTATUS
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of SETOPERATESTATUS, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			replyCmd(&m_HEATBEAT);
	   	 	break;
	   	 	
		case 0x36://SETX1
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of SETX1, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			replyCmd(&m_SETX1);
	   	 	break;
	   	 	
	  case 0x38://SETX2
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of SETX2, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			replyCmd(&m_SETX2);
	   	 	break;   
           case 0x35://QUERYX1
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of QUERYX1, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			replyCmd(&m_QUERYX1);
	   	 	break;
	   	 	
	  case 0x37://QUERYX2
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of QUERYX2, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			replyCmd(&m_QUERYX2);
	   	 	break; 	 	
		default:
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianCIPEPD got ack of UNKNOWN COMMAND:" + Converter::convertToString(m_RESPONSE.m_cmd) + ", length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
			flush();	  	  
	  	  	break;
	}
	
}


string TCPCheTianCIPEPD::replyErrorMsg(char *error)
{
	if(TCPCheTianEPD::replyErrorMsg(error) == "")
	{
		if(error[1] == 0x06)
		{
			return "EPD mode is Local.";
		}
	}
	else
	{
		
		return TCPCheTianEPD::replyErrorMsg(error);
	}
	return "";
}

string TCPCheTianCIPEPD::getDeviceName()
{
	return __FILE__;
}

bool TCPCheTianCIPEPD::setDoubleChannelEnabled(bool bDoubleChannelEnabled)//[wangyk 1.10.0 add]
{
	m_bDoubleChannelEnabled = bDoubleChannelEnabled;
}

IMPLEMENT_DYNAMIC(TCPCheTianCIPEPD, TCPCheTianEPD )

BEGIN_MSG_MAP( TCPCheTianCIPEPD, TCPCheTianEPD )	
	//SET_S( setNameOfSPCV, TCPEPD ) 
	SET_B( setDoubleChannelEnabled, TCPCheTianCIPEPD )//[wangyk 1.10.0 add]
END_MSG_MAP

