/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: DefaultGuadAction.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-9-28   LiJuanjuan create
**      
*********************************************************************/
#ifndef DEFAULTGUADACTION_H_
#define DEFAULTGUADACTION_H_

#include "GuadAction.h"
#ifdef IAP4_0
using namespace IAP::CONDITION;
#endif

class Actuator;

class DefaultGuadAction:public GuadAction
{
	DECLARE_DYNAMIC( DefaultGuadAction )
	DECLARE_MSG_MAP	
	
	private:
		std::vector<Actuator*> m_actuators;
	
	public:
		DefaultGuadAction();
		virtual ~DefaultGuadAction();
		
		virtual void execute(const AppConditionPtr &trigger);
		
		void addActuator(const std::string &path);
};

#endif /*DEFAULTGUADACTION_H_*/
