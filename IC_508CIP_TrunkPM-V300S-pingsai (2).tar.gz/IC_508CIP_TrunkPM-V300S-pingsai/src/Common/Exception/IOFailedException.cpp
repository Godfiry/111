/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: IOFailedException.cpp
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-07-09  LiJuanjuan create
**      
*********************************************************************/
#include "IOFailedException.h"

IOFailedException::IOFailedException(const std::string &s):TMCException(s)
{
}
