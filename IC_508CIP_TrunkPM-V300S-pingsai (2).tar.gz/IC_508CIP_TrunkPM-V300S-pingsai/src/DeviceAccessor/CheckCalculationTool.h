/********************************************************************
** Copyright (c) 2019, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: CheckCalculationTool.h
** Description: This driver is used for Calculation CheckSum
*                          
** Release: 1.1
** Modification history: 
** 					2018-10-3   mujy create
**      
*********************************************************************/
#ifndef CHECKCALCULATIONTOOL_H_
#define CHECKCALCULATIONTOOL_H_
#include <string>

class CheckCalculationTool
{
public:
	CheckCalculationTool();
	virtual ~CheckCalculationTool();
	
	static unsigned short GetCRCCode(char* nCmd,int nLen);
	static unsigned short GetCRCCode(char* nCmd, int nPosBegin, int nPosEnd);//[wangyk 1.4.0]
	static std::string GetLRCCode(const std::string &buffer);
	static int GetLRCCode( char * pCommand, int nLen );
	static unsigned short GetXORCode(char* nCmd,int nLen);
	static unsigned short GetCRC16Code(char *cCommand, int nLen);
	static unsigned short GetCRC16CodeCCITT(char *cCommand, int nLen);  //add by wzd 1.1.39
	static unsigned short GetModbusCRC16Code( char *cCommand, int nLen);//added by guojin[1.1.42]

};

#endif /*CHECKCALCULATIONTOOL_H_*/
