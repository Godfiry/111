/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: DnGaugeInficon.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2018-8-12   DuWenbin create
**      
*********************************************************************/
#include "DnGaugeInficon.h"

#include "DeviceManager.h"
#include "ConfigException.h"
//#include "DNSS5136.h"

#include <cmath>
#include <string.h>
#ifdef IAP4_0
using namespace IAP::IO;
#endif

using namespace std;

DnGaugeInficon::Com DnGaugeInficon::m_commands[] = {{0, 0, 0, 0, 0},//0 reserved for read pressure (ReadOnlyDouble)
																	{4, 0x4B, 0x31, 1, 0},//1 zero adjust (ReadWriteDouble)
																	{4, 0x4C, 0x31, 1, 0},//2 gain adjust (ReadWriteDouble)
																	{5, 0x10, 0xC7, 1, 0x0A},//3 hysteries1 (ReadWriteDouble)
																	{5, 0x10, 0xC7, 2, 0x0A},//4 hysteries2 (ReadWriteDouble)
																	{5, 0x10, 0xC7, 1, 0x05},//5 relay1 (ReadWriteDouble)
																	{5, 0x10, 0xC7, 2, 0x05}};//6 relay2 (ReadWriteDouble)

DnGaugeInficon::DnGaugeInficon()
{
	m_pollInterval = 300;
}

DnGaugeInficon::~DnGaugeInficon()
{
}

bool DnGaugeInficon::readPressure(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	int inputBytes = m_deviceNet->getIBytesSize(m_macID);
	char buffer[inputBytes];
	memset(buffer, 0, inputBytes);
	m_deviceNet->readByte(m_macID, buffer);
	//cout<< "status:"<<buffer[0]<<endl;
	double rawValue = 0.0;
	short temp = (((short)buffer[1]) & 0xff) + ((((short)buffer[2]) << 8) & 0xff00);//duwenbin
	//rawValue = pow(10.0,(double)(temp-1)/3511.0)/pow(2.0,20.0)/1.33;
	*value = (temp *10000.0) / 32000.0;   //mtorr

	//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::FATAL, getSelfName()+"DnGaugeInficon PC->Device:receive buffer "+Hex::GetHexString(buffer,inputBytes));
	return true;
}

bool DnGaugeInficon::writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	char buffer[com.m_datasize];
	memset(buffer, 0, com.m_datasize);
	int i = 0;
	if(com.m_attribute != 0)
	{
		buffer[i++] = com.m_attribute;
	}
	short temp =  (short)value;
	buffer[i++] = (unsigned char)(temp & 0xff);
	buffer[i++] = (unsigned char)((temp>>8) & 0xff);
	buffer[i++] = (unsigned char)((temp>>16) & 0xff);
	buffer[i++] = (unsigned char)((temp>>24) & 0xff);
	return m_deviceNet->writeExplicit(m_macID, buffer, com.m_service, com.m_class, com.m_instance, com.m_datasize);
}


void DnGaugeInficon::initChs(DeviceNode<DnGaugeInficon> *node)
{
	node->registerReadCh(0, &DnGaugeInficon::readPressure);
	for(int i=1; i<=6; ++i)
	{
		node->registerWriteCh(i, &DnGaugeInficon::writeDouble);
	}	
	//node->registerReadCh(7, &DnGaugeInficon::getStatus);
}

void DnGaugeInficon::init()
{
	DeviceNode<DnGaugeInficon> * node = new DeviceNode<DnGaugeInficon>(m_pollInterval,this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	if(!isSimulated())
	{	
		initChs(node);
		initDeviceNet();
	}
}

IMPLEMENT_DYNAMIC(DnGaugeInficon, IODevice )
BEGIN_MSG_MAP( DnGaugeInficon, IODevice )

END_MSG_MAP
