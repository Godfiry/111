/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					2013-08-01  lijj  create 
**      
***************************************************************************/
#ifndef CUSTOMRECOVERYINTERFACE_H_
#define CUSTOMRECOVERYINTERFACE_H_

#include "Alarm.h"
#include "Recovery.h"
#ifdef IAP4_0
using namespace IAP::ALARM;
#endif

class CustomRecoveryInterface
{
	public:
		CustomRecoveryInterface(){}
		virtual ~CustomRecoveryInterface(){}
		
		virtual bool execute(const Alarm *alarm, Recovery *recovery) = 0;
};

#endif /*CUSTOMRECOVERYINTERFACE_H_*/
