/********************************************************************
** Copyright (c) 2019, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: RecipeTool.h
** Description:
** Created on: Jan 9, 2019
** Author: mujy
** Modification history:
**                      [V1.0.0.2] create
**
*********************************************************************/

#ifndef RECIPETOOL_H_
#define RECIPETOOL_H_

#include "RecipeNamespaceManager.h"
#include "ControlObjectEX.h"
#include "Service.h"
#include "Parameter.h"
#include "RecipeUser.h"
#include "ExecRcpHandler.h"
#include "AppRcpBody.h"
#include <string>
#ifdef IAP4_0
using namespace IAP::RECIPE;
using namespace IAP::CONTROL;
#endif

using namespace std;
class RecipeTool :public ControlObjectEX, public RecipeUser
{
    DECLARE_DYNAMIC(RecipeTool)
    DECLARE_MSG_MAP
    DECLARE_SERVICEINFO_LIST

    public:
        class PrintAll : public Service
        {
            DECLARE_DYNAMIC_SERVICE(PrintAll)

            public:
                void execute();
        };

    public:
        RecipeTool();
        virtual ~RecipeTool();

    public:
        void call_PrintAll();
        virtual void do_PrintAll();

    public:
        ExecRcpHandler getRecipeHandler(const string &strRecipe);
        bool IsRecipeParamExist(const string &strRecipeClassName,const string &strParamName);
        static bool hasParamInRecipeTemplate(const string &strParamNmae); // add by mjy for LVC [1.4.0_HotFix2]
        static bool isRcpHasESCHeaterParam();     //added by zhangpf[1.8.2]
        void releaseRecipeHandler(ExecRcpHandler rcpHandler);   // add by ps 1.11.0

    public:
        virtual void verifyInit();
        virtual void startup();
        virtual void initialize(); //add by zhangpf[1.8.2]
        virtual void shutdown();
    private:
        ServicePtr<PrintAll> m_PrintAll;
        RecipeMgmtSession *m_pSession;
        //This method is no longer used, must use AppRecipeManager::getInstance()->retrieveRecipe(strRecipeID,false)
        static bool m_bIsRcpHasESCHeaterParam; //add by zhangpf[1.8.2]
};

#endif /* SETUPMANAGERTOOL_H_ */
