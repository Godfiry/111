/********************************************************************
** Copyright (c) 2019, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: DefaultErrorCodeParser.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2019-8-30   liusy create
**      
*********************************************************************/
#ifndef ERRORCODEPARSER_H_
#define ERRORCODEPARSER_H_
#include "CmdTarget.h"
#include "ErrorCodeParserInterface.h"
#include "MapTool.h"
#include <string>
#ifdef IAP4_0
using namespace IAP::CORE;
#endif
using namespace std;

class ErrorCodeParser: public CmdTarget,public ErrorCodeParserInterface
{
	DECLARE_DYNAMIC(ErrorCodeParser)
	DECLARE_MSG_MAP
	
public:
	ErrorCodeParser();
	virtual ~ErrorCodeParser();

public://override
	virtual string parseErrorCode(const string strCode);

protected://get the Parser results
	string getParseResult(const string strKey);

public://for xml config
	void addErrorCode(string strErrCode, string strDecripition, string strRecommendedAction);

private:
	map<string,string> m_ErrorCodes;
};

#endif /*OPRPM_H_*/




