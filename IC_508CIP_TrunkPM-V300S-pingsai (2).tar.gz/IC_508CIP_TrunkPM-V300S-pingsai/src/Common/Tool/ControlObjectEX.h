﻿#ifndef CONTROLOBJECTEX_H_
#define CONTROLOBJECTEX_H_

#include "ControlObject.h"
#include "CBase.h"
#include "Alarm.h"
#include "Service.h"
#include "ReadOnlyInt.h"
#include "ReadOnlyDouble.h"
#include "ReadOnlyString.h"
#include "ReadWriteInt.h"
#include "ReadWriteDouble.h"
#include "ReadWriteString.h"
#ifdef IAP4_0
using namespace IAP::CONTROL;
using namespace IAP::ALARM;
using namespace IAP::IO;
#endif

class ControlObjectEX : public ControlObject, virtual public CBase
{
	DECLARE_DYNAMIC(ControlObjectEX)
		DECLARE_MSG_MAP
public:
	ControlObjectEX();
	virtual ~ControlObjectEX();

public:
	bool isStartuped() const;

public:
	virtual void startup();

public://for xml
	void addIntSensors(const string& strChName, const string& strPath);
	void addDoubleSensors(const string& strChName, const string& strPath);
	void addStringSensors(const string& strChName, const string& strPath);

	void addIntCfgParams(const string& strParamName, const string& strpath);
	void addDoubleCfgParams(const string& strParamName, const string& strpath);
	void addStringCfgParams(const string& strParamName, const string& strpath);
	//[chensc v1.1.19]
	void addIntActuators(const string& strChName, const string& strPath);
	void addDoubleActuators(const string& strChName, const string& strPath);
	void addStringActuators(const string& strChName, const string& strPath);

protected:
	void addAlarm(string strName);
	void addRecovery(string strName, Recovery* pRecoveryAction);

	virtual void postAlarm(Alarm* pAlarm);
	virtual void postAlarm(const string& strName);
	virtual void postAlarm(const string& strName, string strDescription);

	bool checkIntSensorList(string* pSensorNameList, int nLength);
	bool checkDoubleSensorList(string* pSensorNameList, int nLength);
	bool checkStringSensorList(string* pSensorNameList, int nLength);

	bool checkIntCfgParamList(string* pCfgParamList, int nLength);
	bool checkDoubleCfgParamList(string* pCfgParamList, int nLength);
	bool checkStringCfgParamList(string* pCfgParamList, int nLength);
	//[chensc v1.1.19]
	bool checkIntActuatorList(string* pActuatorNameList, int nLength);
	bool checkDoubleActuatorList(string* pActuatorNameList, int nLength);
	bool checkStringActuatorList(string* pActuatorNameList, int nLength);
	void usleepChange(unsigned long usec);
	void sleepChange(unsigned long sec);		// add by pingsai 1.10.0

protected:
	map<string, Alarm*> m_Alarms;

	map<string, ReadOnlyInt*> m_IntSensorChs;
	map<string, ReadOnlyDouble*> m_DoubleSensorChs;
	map<string, ReadOnlyString*> m_StringSensorChs;

	map<string, ReadWriteInt*> m_IntCfgParams;
	map<string, ReadWriteDouble*> m_DoubleCfgParams;
	map<string, ReadWriteString*> m_StringCfgParams;
	//[chensc v1.1.19]
	map<string, ReadWriteInt*> m_IntActuatorChs;
	map<string, ReadWriteDouble*> m_DoubleActuatorChs;
	map<string, ReadWriteString*> m_StringActuatorChs;

private:
	std::list<string> m_AlarmNames;

private:
	bool m_isStartuped;        // whether or not this object finishes making
};

#endif /*CONTROLOBJECTEX_H_*/
