#ifndef CIFXDEVNET_H_
#define CIFXDEVNET_H_

#include "DeviceNet.h"
#include "cifxdevnet_lib.h"
#include <unistd.h>  //add by wzd 1.1.39

extern CIFXHANDLE hChannel;
extern DNS_DEVICE_CFG * DevicesList[64];

class CIFXDEVNET:public DeviceNet
{
public:
	CIFXDEVNET(const std::string &devName, int masterMacId, int baudRate);
	virtual ~CIFXDEVNET();

public:
		int loadFile(const std::string strFileName);
		virtual void loadDevice(); 
		virtual bool addDevice(int inmac); 
		virtual int getIBytesSize(int inmac);
		virtual int getOBytesSize(int inmac);
		virtual bool readByte(int macid, char *buffer);
		virtual bool writeByte(int inmac, char *byte);
		virtual bool readBit(int inmac, int channel, bool *bit);
		virtual bool writeBit(int inmac, int channel, bool bit);
		virtual bool writeExplicit(int macid, char *buffer, int service, int Class, int instance, int datasize);
		virtual bool readExplicit(int macid, char *bufferIn, int service,int Class, int instance, int datasizeIn, char *bufferOut, int *datasizeOut);
		virtual int readStatus(int nMacId);
		
protected:
		void ShowError(int32_t lError);
private:
	CIFX_LINUX_INIT m_Init;	
	CIFXHANDLE m_hDriver;
	
};

#endif /*CIFXDEVNET_H_*/
