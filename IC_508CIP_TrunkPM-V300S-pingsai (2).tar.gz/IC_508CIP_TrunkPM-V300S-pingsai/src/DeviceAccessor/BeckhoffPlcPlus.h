/*
 * BeckhoffPlcPlus.h
 *
 *  Created on: 2023��9��28��
 *      Author: liusiyuan
 */

#ifndef SRC_DEVICEACCESSOR_BECKHOFFPLCPLUS_H_
#define SRC_DEVICEACCESSOR_BECKHOFFPLCPLUS_H_

#include "TCPDevice.h"
#include "DeviceNode.h"
#include "IMutex.h"
#include "ReadWriteDouble.h"
#include "IThread.h"
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
#endif

class ParamBase
{
    public:
        unsigned char m_cUid; //unit identifier('slave address', 255 if not used)
        unsigned char m_cFuncCode;
        unsigned char m_cLenH; // Variable Length high byte.
        unsigned char m_cLenL; // Variable Length low byte.
        unsigned char m_cAddrH;    // Variable ADDRESS high byte.
        unsigned char m_cAddrL;    // Variable ADDRESS low byte.
        int m_nRegisterNum; // register num /read/write
        int m_nAreaAddr;
        ParamBase();
        ParamBase(int nAreaCode, int nAreaAddr, int nRegisterNum);
};

class DIDOParam : public ParamBase
{
    public:
        int m_nOffset;

        DIDOParam();
        DIDOParam(int nAreaCode, int nAreaAddr, int nOffset);
        bool operator==(const DIDOParam &right) const;
};

class AIAOParam : public ParamBase
{
    public:
        double m_dMax;                //3000W or 10Torr
        double m_dMin;                // 0W or 0Torr
        int m_nVoltageRange;     // 10V or 5V

        AIAOParam();
        AIAOParam(int nAreaCode, int nAreaAddr, double nMax);
        bool operator==(const AIAOParam &right) const;
};

typedef enum 
{
    UNINIT,
    RUN,
    EXITED,
    EXITING
} ThreadStatus;

class BeckhoffPlcPlus :public TCPDevice , public IThread{


    DECLARE_DYNAMIC(BeckhoffPlcPlus)
    DECLARE_MSG_MAP

public:
    BeckhoffPlcPlus();
    virtual ~BeckhoffPlcPlus();


protected:
    void initChannels(DeviceNode<BeckhoffPlcPlus> *node);
    //void parseReply();
    void parseReadReply();
    void parseWriteReply();

    void flush();
    void modbusSendCommand(ParamBase *param, void *val, const std::string &strErrTitle, std::string &strErrorMsg);
    void initDIDORegister();

    void readPLCRegisterData(int nAddr, int nReadSize, char *pResult, int &nResultSize);

    void readWriteRegister(int nAddr, int nReadSize = 1);//added by liusy[1.1.52]
    void readAIDIRegister();
    bool checkParamValid(int nAreaCode, int nAreaAddr, std::string &strErrorMsg);

protected:
    virtual void run();

public:



    virtual void init();
    virtual std::string getDeviceName();
    virtual void acceptData();
    bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
    bool readInt(int nChannelNum, int *nValue, const IntTypeInfo &typeInfo);

    bool writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo);
    bool readDouble(int nChannelNum, double *dValue, const DoubleTypeInfo &typeInfo);



    void addParamDI(int nAreaCode, int nAreaAddr, int nOffsetAddr);
    void addParamDO(int nAreaCode, int nAreaAddr, int nOffsetAddr);

    void addParamAI(int nAreaCode, int nAreaAddr, double dMax);
    void addParamAO(int nAreaCode, int nAreaAddr, double dMax);

    void setAOOtherParam(int nChannelNum, double nMin, int nVoltageRange);
    void setAIOtherParam(int nChannelNum, double nMin, int nVoltageRange);

    void setAIFilterParam(int nChannelNum, int nAIFilterValue);
    
    void setDebugLog(int nIndex);

    void setReadPollIntervalMs(double dTimeMs);
    void setWritePollTimeUs(int dTimeUs);

    void recordLog(string strLog);
private:

    static const unsigned char R_COILBITS = 0x01; //read digital outputs,but only use one bit
    static const unsigned char R_INPUTBITS = 0x02; //read digital inputs,but only use one bit
    static const unsigned char R_HREGWORD = 0x03; //read holding register,but only use one or two words.
    static const unsigned char R_IREGWORD = 0x04; //read the inputs basis word,but only use one or two words.

    static const unsigned char WR_BIT = 0x05; //write single coil
    static const unsigned char MWR_BIT = 0x0f; //write multiple coils
    static const unsigned char WR_WORD = 0x06; //write single holding register
    static const unsigned char MWR_WORD = 0x10; //write single holding registers

    char m_modbusSend[64];

    std::vector<DIDOParam> m_diParam; // DI channel cmd Param list
    std::vector<DIDOParam> m_doParam; // DO channel cmd Param list

    std::vector<AIAOParam> m_aoParam; // AO channel cmd Param list
    std::vector<AIAOParam> m_aiParam; // AI channel cmd Param list

    std::map<int, int> m_aiFilter; //channel - value(key - value)

    bool m_bWaiting;
    bool m_bReadCmd;
    std::string    m_strReadError;
    std::string    m_strWriteError;
    std::string m_strResult;
    std::string m_strRawResult;

    std::map<int, int> m_WriteDORegister; //addr - value(key - value)

    std::map<int, int> m_ReadDIRegister; //addr - value(key - value) DI AI
    std::map<int, int> m_ReadAIRegister; //addr - value(key - value) DI AI
    //std::map<int, int> m_ReadContiuneRegister; //addr - registerNum



    bool m_bFastRead;
    int m_nDebugEnable;

    //Thread
    bool m_bExist;
    volatile ThreadStatus m_nThreadStatus;
    mutable IMutex *m_pAIRegisterRWMutex; // ReadAIRegister lock
    mutable IMutex *m_pDIRegisterRWMutex; // ReadDIRegister lock
    //added by liusy[1.1.52]
    bool m_bWriteFlag;
    IWaitCondition m_waitWrtieCond;
    IWaitCondition m_waitReadCond;
    mutable IMutex* m_pReadMutex;
    mutable IMutex* m_pWriteMutex;
    int m_nMainThreadCount;
    int m_nReadPollIntervalCount;
    int m_nWritePollTimeUs;
};

#endif /* SRC_DEVICEACCESSOR_BECKHOFFPLCPLUS_H_ */
