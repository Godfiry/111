#include "NumberArrayTool.h"

int NumberArrayTool::getMinNum(int * pData , int nLength)
{
	int nResult=0;
	for(int i = 1 ; i < nLength ; ++i)
	{
		if(pData[i]<pData[nResult])
		{
			nResult=i;
		}
	}
	return nResult;
}

int NumberArrayTool::getMinNumExcept(int * pData , int nLength,int nExcept)
{
	int nResult=nLength;
	for(int i = 0 ; i < nLength ; ++i)
	{
		if(pData[i]!=nExcept)
		{
			nResult=i;
			break;
		}
	}
	
	for(int i = nResult+1 ; i < nLength ; ++i)
	{
		if(pData[i]!=nExcept && pData[i]<pData[nResult])
		{
			nResult=i;
		}
	}
	
	if(nResult<nLength)
	{
		return nResult;
	}
	else
	{
		return -1;
	}
}