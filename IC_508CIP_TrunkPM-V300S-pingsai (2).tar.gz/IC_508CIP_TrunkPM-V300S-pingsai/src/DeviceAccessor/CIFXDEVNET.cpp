#include "CIFXDEVNET.h"
#include "ConfigException.h"
#include "Converter.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#include "rcX_Public.h"
#include "rcX_User.h"
#include "DevNetFal_Public.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <string.h>
#include "SysLogger.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
#endif
#define CIFX_DEV "cifX0"

using namespace std;
CIFXDEVNET::CIFXDEVNET(const std::string &devName, int masterMacId, int baudRate):DeviceNet(devName,masterMacId,baudRate)
{
	m_Init.init_options        = CIFX_DRIVER_INIT_AUTOSCAN;
	m_Init.iCardNumber         = 0;
	m_Init.fEnableCardLocking  = 0;
	m_Init.base_dir            = NULL;
	m_Init.poll_interval       = 0;
	m_Init.poll_StackSize      = 0;   /* set to 0 to use default */
	m_Init.trace_level         = 255;
	m_Init.user_card_cnt       = 0;
 	m_Init.user_cards          = NULL;
  	m_Init.poll_priority       = 0;
  	m_Init.poll_schedpolicy    = 0;
	#ifdef SUSE
	m_Init.logfd = 0;  //add by wzd 1.1.39
  	#endif
  	m_hDriver = NULL;
  	hChannel = NULL;
	
	
}

CIFXDEVNET::~CIFXDEVNET()
{
	for (int i=0;i<64;i++)
	{
		if(DevicesList[i] != NULL)
		{
			delete DevicesList[i];
			DevicesList[i] = NULL;
		}
	}

	unsigned long ulState;
	if(hChannel != NULL)
	{
		if(CIFX_NO_ERROR != xChannelBusState(hChannel, CIFX_BUS_STATE_OFF, (TLR_UINT32*)&ulState, 10000))
		{
			cout<<"Error setting Bus state lRet"<<endl;
		}
	}
	if(m_hDriver != NULL)
	{
		xDriverClose(m_hDriver);
	}
	if(hChannel != NULL)
	{
		xChannelClose(hChannel);
	}
	cifXDriverDeinit();
}

void CIFXDEVNET::ShowError(int32_t lError)
{
	if(lError != CIFX_NO_ERROR)
	{
		char szError[1024] = {0};
		xDriverGetErrorDescription(lError ,szError,sizeof(szError));
		printf("Error : 0x%X,<%s>\n",(unsigned int)lError,szError);
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::FATAL, "CIFXDeviceNet::ShowError() ErrorCode=" + Converter::convertToString((unsigned int)lError)+string(szError));
	}
}

/*----------------------------------------------------------------------
 load firmware.
--------------------------------------------------------------------*/
int CIFXDEVNET::loadFile(const string strFileName)
{
	ifstream infile(strFileName.c_str());
	if(!infile)
	{
		throw ConfigException("Open CIFX file "+strFileName + " failed.");
	}
	
	string strTemp = "";
	vector<string> resVector;
	string strResult;
	char pData[100] = {0};
	
	int nMacID = 0;	
	int nOutputOffSet = 0;
	int nOutputSize = 0;	
	int nInputOffSet = 0;
	int nInputSize = 0;
	
	resVector.clear();
	memset(pData,0,100);
	
	while(infile.getline(pData,100))
	{
		strTemp = string(pData);
		
		if(strTemp.find("MacID") == string::npos)
		{
			stringstream input(strTemp);
			while(input>>strResult)
			{
				resVector.push_back(strResult);
			}
			if(resVector.size() == 6)
			{
				Converter::stringToInt(nMacID,resVector[1]);
				Converter::stringToInt(nOutputOffSet,resVector[2]);
				Converter::stringToInt(nOutputSize,resVector[3]);
				Converter::stringToInt(nInputOffSet,resVector[4]);
				Converter::stringToInt(nInputSize,resVector[5]);
				
				DevicesList[nMacID] = new DNS_DEVICE_CFG;
				
				(*DevicesList[nMacID]).MacId = nMacID;
				(*DevicesList[nMacID]).Output1Offset = nOutputOffSet;
				(*DevicesList[nMacID]).Output1Size = nOutputSize;
				(*DevicesList[nMacID]).Input1Offset = nInputOffSet;
				(*DevicesList[nMacID]).Input1Size = nInputSize;
			}
			else
			{
				throw ConfigException("CIFX "+strFileName + " file content error.");
			}
		}
		resVector.clear();
		memset(pData,0,100);
	}
	infile.close();
  
  	return(0);
}
void CIFXDEVNET::loadDevice()
{
	unsigned long ulState;
	
	for (int i=0;i<64;i++)
	{
		DevicesList[i]=NULL;
	}

	string strFileName = m_fwdir + "/DnCifx.txt";
	loadFile(strFileName);
		
	/* First of all initialize toolkit */
	int32_t lRet = cifXDriverInit(&m_Init);
	if(CIFX_NO_ERROR != lRet)
	{
		ShowError(lRet);
		throw ConfigException("CIFX Error Open Driver,Error is " + Converter::convertToString((unsigned int)lRet));
	}  
	lRet    = xDriverOpen(&m_hDriver);
	if(CIFX_NO_ERROR != lRet)
	{
		ShowError(lRet);
		throw ConfigException("CIFX Error Open Driver,Error is " + Converter::convertToString((unsigned int)lRet));
	}
	/* Driver/Toolkit successfully opened */
	lRet = xChannelOpen(NULL, CIFX_DEV, 0, &hChannel);

	if(CIFX_NO_ERROR != lRet)
	{
		ShowError(lRet);
		throw ConfigException("CIFX Error Open Channel,Error is " + Converter::convertToString((unsigned int)lRet));
	}
  
	CHANNEL_INFORMATION tChannelInfo = {{0}};

	/* Channel successfully opened, so query basic information */
	if( CIFX_NO_ERROR != (lRet = xChannelInfo(hChannel, sizeof(CHANNEL_INFORMATION), &tChannelInfo)))
	{
		ShowError(lRet);
		throw ConfigException("CIFX Error querying system information block ");
	} 
	else
	{
        cout<<"Communication Channel Info"<<endl;
        cout<<"Device Number    : "<<(long unsigned int)tChannelInfo.ulDeviceNumber<<endl;
        cout<<"Serial Number    : "<<(long unsigned int)tChannelInfo.ulSerialNumber<<endl;
        cout<<"Firmware         : "<<tChannelInfo.abFWName<<endl;
        cout<<"FW Version       : "<<tChannelInfo.usFWMajor<<"."<<tChannelInfo.usFWMinor
        	  <<"."<<tChannelInfo.usFWRevision<<" build "<<tChannelInfo.usFWBuild<<endl;
        cout<<"FW Date          : "<<tChannelInfo.usFWYear<<tChannelInfo.bFWMonth<<tChannelInfo.bFWDay<<endl;

        cout<<"Mailbox Size     : "<<(long unsigned int)tChannelInfo.ulMailboxSize<<endl;
   }
   	if(CIFX_NO_ERROR != (lRet = xChannelBusState(hChannel, CIFX_BUS_STATE_ON,(TLR_UINT32*) &ulState, 10000)))
	{
   		ShowError(lRet);
	   xChannelClose(hChannel);
	   xDriverClose(m_hDriver);
	   throw ConfigException("CIFX Error setting Bus state,Error is " + Converter::convertToString((unsigned int)lRet));
	}

   	NETX_COMMON_STATUS_BLOCK tCommonStatusBlock = {0};
   	if(CIFX_NO_ERROR != (lRet = xChannelCommonStatusBlock(hChannel, CIFX_CMD_READ_DATA,0,sizeof(tCommonStatusBlock),(void*)&tCommonStatusBlock)))
   	{
   		ShowError(lRet);
 	   xChannelClose(hChannel);
 	   xDriverClose(m_hDriver);
 	   throw ConfigException("CIFX Error read CommonStatusBlock,Error is " + Converter::convertToString((unsigned int)lRet));
   	}
   	else
   	{
   		if((tCommonStatusBlock.ulCommunicationCOS & RCX_COMM_COS_BUS_ON) != RCX_COMM_COS_BUS_ON)
   		{
   			throw ConfigException("CIFX Error Bus state is not on");
   		}
   		if((tCommonStatusBlock.ulCommunicationState & RCX_COMM_STATE_IDLE) != RCX_COMM_STATE_IDLE)
   		{
			cout<<"CIFX Communication State is "<<tCommonStatusBlock.ulCommunicationState<<endl;
   			//throw ConfigException("CIFX Error Communication State is not Idle");
   		}
   		if(tCommonStatusBlock.ulCommunicationError != RCX_S_OK)
   		{
   			throw ConfigException("CIFX has Communication Error");
   		}

        cout<<"Communication Channel Slave Infor"<<endl;
        cout<<"Number of Config Slaves    : "<<(long unsigned int)tCommonStatusBlock.uStackDepended.tMasterStatusBlock.ulNumOfConfigSlaves<<endl;
        cout<<"Number of Active Slaves    : "<<(long unsigned int)tCommonStatusBlock.uStackDepended.tMasterStatusBlock.ulNumOfActiveSlaves<<endl;
        cout<<"Number of Faulted Slaves   : "<<(long unsigned int)tCommonStatusBlock.uStackDepended.tMasterStatusBlock.ulNumOfDiagSlaves<<endl;
   	}

   	/*
	CIFX_PACKET tSendPacket = {{0}};
	CIFX_PACKET tRecvPacket = {{0}};

	uint32_t ulReceiveCount = 0;
	uint32_t ulSendCount = 0;

	//------------------------------
	//Read all available packet
	//------------------------------
	//Get actual packe state
	lRet = xChannelGetMBXState(hChannel,&ulReceiveCount,&ulSendCount);
	cout<<"CIFX Get actual packet count is "<<ulReceiveCount<<endl;
	while(ulReceiveCount > 0)
	{
		//Read packet
		lRet = xChannelGetPacket(hChannel,sizeof(tRecvPacket),&tRecvPacket,1000);
		ulReceiveCount--;
	}

	//-----------------------
	//send packet to hardware
	//------------------------
	DN_FAL_PACKET_LIFELIST_REQ_T tLifeListReq = {{0}};
	DN_FAL_PACKET_LIFELIST_CNF_T tLifeListCnf = {{0}};
	tLifeListReq.tHead.ulSrc = 0;
	tLifeListReq.tHead.ulDest = RCX_PACKET_DEST_DEFAULT_CHANNEL;
	tLifeListReq.tHead.ulCmd = 0x3814;
	tLifeListReq.tHead.ulLen = 4;
	tLifeListReq.tData.ulTimeOut = 1000;

	//Send Packet
	if(CIFX_NO_ERROR != (lRet = xChannelPutPacket(hChannel,(CIFX_PACKET*)&tLifeListReq,tLifeListReq.tData.ulTimeOut)))
	{
		ShowError(lRet);
		throw ConfigException("CIFX's put packet error.");
	}

	//Wait packet
	int nWaitPacket = 5;//5s
	while(nWaitPacket > 0)
	{
		cout<<"Wait packet back..."<<endl;
		lRet = xChannelGetMBXState(hChannel,&ulReceiveCount,&ulSendCount);
		if(ulReceiveCount > 0)
		{
			cout<<"Get actual packet count is "<<ulReceiveCount<<endl;
			//Read packet
			if(CIFX_NO_ERROR != (lRet = xChannelGetPacket(hChannel,sizeof(tLifeListCnf),(CIFX_PACKET*)&tLifeListCnf,1000)))
			{
				ShowError(lRet);
				throw ConfigException("CIFX's get packet error.");
			}
			break;
		}
		sleep(1);
		--nWaitPacket;
	}
	if(nWaitPacket == 0)
	{
		throw ConfigException("CIFX's get packet time out(5s).");
	}

	 cout<<"LifeList Len = "<<tLifeListCnf.tHead.ulLen<<endl;
	 cout<<"LifeList Cmd = "<<tLifeListCnf.tHead.ulCmd<<endl;//0x3815 or 14357

	if(tLifeListCnf.tHead.ulLen != 64 || tLifeListCnf.tHead.ulCmd != 14357)
	{
		throw ConfigException("CIFX's get packet wrong.");
	}
	bool bScanFlag = true;
	 for(int i = 1; i <= tLifeListCnf.tHead.ulLen; i++)
	 {
		 //Check config MacID is online or not
		 if(DevicesList[i] != NULL)// config MacID
		 {
			 if(tLifeListCnf.tData.abDevices[i] != NULL && tLifeListCnf.tData.abDevices[i] == 1)
			 {
				 cout<<"config MacID "<<i<<" is online on bus."<<endl;
			 }
			 else
			 {
				 cout<<"!!!Cannot connect the MacID "<<i<<endl;
				 bScanFlag = false;
				 //throw "Cannot connect the MacID "+Converter::convertToString(i)+",Please check or rescan.";
			 }
		 }
	 }
	 if(!bScanFlag)
	 {
		 throw "Cannot connect the DeviceNet device ,Please check or rescan.";
	 }
	 */
}

bool CIFXDEVNET::addDevice(int inmac)
{
	if(DevicesList[inmac] == NULL)
	{
		throw ConfigException("CIFX add Mac " + Converter::convertToString(inmac) + " failed,because the DnCifx.conf don't config this MacID");
	}
	cout<<"start scan MacID "<<inmac<<endl;
	if(readStatus(inmac) < 0)
	{
		cout<<"scan failed, rescan..."<<endl;
		sleep(3);
		if(readStatus(inmac) < 0)
		{
			throw ConfigException("CIFX add Mac " + Converter::convertToString(inmac) + " failed,Please check and rescan!");
		}
	}
	cout<<"MacID "<<inmac<<" is online"<<endl;
	return true;	
}

//int CIFXDEVNET::readStatus(int nMacId)
//{
//	IMutexLocker locker(&m_lock);
//	int nConnectStatus = 2;
//	int32_t lRet;
//	uint32_t ulReceiveCount = 0;
//	uint32_t ulSendCount = 0;
//
//	CIFX_PACKET tRecvPacket = {{0}};
//
//	//------------------------------
//	//Read all available packet
//	//------------------------------
//	//Get actual packe state
//	lRet = xChannelGetMBXState(hChannel,&ulReceiveCount,&ulSendCount);
//	while(ulReceiveCount > 0)
//	{
//		//Read packet
//		lRet = xChannelGetPacket(hChannel,sizeof(tRecvPacket),&tRecvPacket,1000);
//		ulReceiveCount--;
//	}
//
//	DN_FAL_PACKET_DEV_DIAG_REQ_T tDevDiagReq = {{0}};
//	DN_FAL_PACKET_DEV_DIAG_CNF_T tDevDiagCnf = {{0}};
//
//	tDevDiagReq.tHead.ulSrc = 0;
//	tDevDiagReq.tHead.ulDest = RCX_PACKET_DEST_DEFAULT_CHANNEL;
//	tDevDiagReq.tHead.ulCmd = DEVNET_FAL_CMD_DEV_DIAG_REQ;
//	tDevDiagReq.tHead.ulLen = 6;
//	tDevDiagReq.tData.ubDevMacId = nMacId;
//	tDevDiagReq.tData.fGetOnly = 1;// test
//
//	//Send Packet
//	if(CIFX_NO_ERROR != (lRet = xChannelPutPacket(hChannel,(CIFX_PACKET*)&tDevDiagReq,1000)))
//	{
//		ShowError(lRet);
//		return -1;
//	}
//	//Wait packet
//	int nWaitPacket = 100;//1s
//	while(nWaitPacket > 0)
//	{
//		lRet = xChannelGetMBXState(hChannel,&ulReceiveCount,&ulSendCount);
//		if(ulReceiveCount > 0)
//		{
//			//Read packet
//			if(CIFX_NO_ERROR != (lRet = xChannelGetPacket(hChannel,sizeof(tDevDiagCnf),(CIFX_PACKET*)&tDevDiagCnf,1000)))
//			{
//				ShowError(lRet);
//				return -1;
//			}
//			if(tDevDiagCnf.tHead.ulCmd == DEVNET_FAL_CMD_DEV_DIAG_CNF && tDevDiagCnf.tData.ubDevMacId == nMacId)
//			{
//				/*cout<<"NodeExtraDiag="<<hex<<(long unsigned int)tDevDiagCnf.tData.tDataLoad.tDiagData.bNodeExtraDiag<<endl;
//
//				cout<<"DevMainState="<<hex<<(long unsigned int)tDevDiagCnf.tData.tDataLoad.tDiagData.bDevMainState<<endl;
//				cout<<"OnlineError="<<hex<<(long unsigned int)tDevDiagCnf.tData.tDataLoad.tDiagData.bOnlineError<<endl;
//				cout<<"GeneralErrorCode="<<hex<<(long unsigned int)tDevDiagCnf.tData.tDataLoad.tDiagData.bGeneralErrorCode<<endl;
//				cout<<"AdditionalCode="<<hex<<(long unsigned int)tDevDiagCnf.tData.tDataLoad.tDiagData.bAdditionalCode<<endl;*/
//				if(tDevDiagCnf.tData.tDataLoad.tDiagData.bNodeExtraDiag & DN_FAL_NODE_DIAG_NO_RES)
//				{
//					cout<<"tDevDiagCnf.tData.tDataLoad.tDiagData.bNodeExtraDiag="<<tDevDiagCnf.tData.tDataLoad.tDiagData.bNodeExtraDiag<<endl;
//					SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::FATAL, "CIFXDeviceNet::readStatus() MacId=" + Converter::convertToString(nMacId)+" tDevDiagCnf.tData.tDataLoad.tDiagData.bNodeExtraDiag="+Converter::convertToString(tDevDiagCnf.tData.tDataLoad.tDiagData.bNodeExtraDiag));
//					return -1;
//				}
//				return nConnectStatus;
//			}
//			else
//			{
//				cout<<"tDevDiagCnf.tHead.ulCmd="<<tDevDiagCnf.tHead.ulCmd<<endl;
//				cout<<"tDevDiagCnf.tData.ubDevMacId="<<tDevDiagCnf.tData.ubDevMacId<<endl;
//				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::FATAL, "CIFXDeviceNet::readStatus() MacId= " + Converter::convertToString(nMacId)+" tDevDiagCnf.tHead.ulCmd="+Converter::convertToString(tDevDiagCnf.tHead.ulCmd));
//				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::FATAL, "CIFXDeviceNet::readStatus() MacId= " + Converter::convertToString(nMacId)+" tDevDiagCnf.tData.ubDevMacId="+Converter::convertToString(tDevDiagCnf.tData.ubDevMacId));
//				return -1;
//			}
//		}
//		usleep(10*1000);
//		--nWaitPacket;
//	}
//	if(nWaitPacket == 0)
//	{
//		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::FATAL, "CIFXDeviceNet::readStatus() MacId=" + Converter::convertToString(nMacId)+" wait packet time out(1s)");
//		return -1;
//	}
//	/*//Register Application Service Confirmation
//	DN_FAL_PACKET_AP_REGISTER_CNF_T tAPRegisterCnf={{0}};
//
//	lRet = xChannelGetMBXState(hChannel,&ulReceiveCount,&ulSendCount);
//	if(ulReceiveCount > 0)
//	{
//		//Read packet
//		if(CIFX_NO_ERROR != (lRet = xChannelGetPacket(hChannel,sizeof(tAPRegisterCnf),(CIFX_PACKET*)&tAPRegisterCnf,1000)))
//		{
//			ShowError(lRet);
//			return -1;
//		}
//	}
//	else
//	{
//		return nConnectStatus;
//	}
//	if(tAPRegisterCnf.tHead.ulCmd == DEVNET_FAL_CMD_FAULT_IND)
//	{
//		return -1;
//	}
//	else
//	{
//		return nConnectStatus;
//	}*/
//}

int CIFXDEVNET::readStatus(int nMacId)
{
	IMutexLocker locker(&m_lock);
	char buffer[64];
	memset(buffer, 0, sizeof(buffer));
	int lRet = xChannelExtendedStatusBlock(hChannel, CIFX_CMD_READ_DATA, 0, 64, &buffer[0]);
	//slave io states(mac id:1~64) stored in buffer[40]~buffer[47]
//	for (int i = 0; i < 64; i++)
//	{
//		printf( "%d:%02X ", i + 50, buffer[i]);
//		if ((i + 1) % 8 == 0)
//		{
//			printf("\n");
//		}
//	}

	bool let = (0xff & buffer[40 + nMacId / 8]) & (0x01 << (nMacId % 8));
//	printf("%d:state is %d\n", nMacId, let);
	return let;
}

bool CIFXDEVNET::readByte(int inmac, char *byte)
{
	IMutexLocker locker(&m_lock);
	if(DevicesList[inmac] == NULL)
	{
		throw IOException("CIFXDEVNET::there is no device for MacID '" +Converter::convertToString(inmac)+ "'");
	}	
	int foo = readDeviceIO(0,inmac,0, byte);
	if(foo < 0)
	{
		throw IOException("CIFXDEVNET::read data from MacID '" +Converter::convertToString(inmac)+"' failed");
	}
	return true;
}

bool CIFXDEVNET::writeByte(int inmac, char *byte)
{
	IMutexLocker locker(&m_lock);
	if(DevicesList[inmac] == NULL)
	{
		throw IOException("CIFXDEVNET::there is no device for MacID '" +Converter::convertToString(inmac)+ "'");
	}	
	int foo = writeDeviceIO(0, inmac, 0, byte);
	if(foo < 0)
	{
		throw IOException("CIFXDEVNET::write data to MacID '" +Converter::convertToString(inmac)+"' failed");
	}
	return true;
}

int CIFXDEVNET::getIBytesSize(int inmac)
{
	return DevicesList[inmac]->Input1Size;
}

int CIFXDEVNET::getOBytesSize(int inmac)
{
	return DevicesList[inmac]->Output1Size;
}

bool CIFXDEVNET::readBit(int inmac, int channel, bool *bit)
{
	int inputBytes = (*DevicesList[inmac]).Input1Size;
	if(channel >= inputBytes*8)
	{
		throw IOException("CIFXDEVNET::the channel to read is bigger than allowed channels for MacID '" +Converter::convertToString(inmac)+"'");
	}
	char buffer[inputBytes];
	memset(buffer, 0, inputBytes);
	bool foo = readByte(inmac, buffer);
	if(foo)
	{
		int byteno = channel / 8;
		int bitno = channel % 8;
		unsigned char bitmask = 1;
		bitmask = bitmask << bitno;
		*bit = (bool)(buffer[byteno] & bitmask);
		return true;		
	}
	else
	{
		return false;
	}
}

bool CIFXDEVNET::writeBit(int inmac, int channel, bool bit)
{
	int outputBytes = (*DevicesList[inmac]).Output1Size;
	if(channel >= outputBytes*8)
	{
		throw IOException("CIFXDEVNET::the channel to write is bigger than allowed channels for MacID '" +Converter::convertToString(inmac)+"'");
	}	
	char buffer[outputBytes];
	memset(buffer, 0, outputBytes);
	if(bit == 1)
	{
		int byteno = channel / 8;
		int bitno = channel % 8;
		unsigned char bitmask = 1;
		bitmask = bitmask << bitno;	
		buffer[byteno] = 	buffer[byteno] | bitmask;
	}
	return writeByte(inmac, buffer);
}

bool CIFXDEVNET::writeExplicit(int macid, char *buffer, int service, int Class, int instance, int datasize)
{
	
	IMutexLocker locker(&m_lock);
	unsigned long lRet = 0;
	uint32_t ulReceiveCount = 0;
	uint32_t ulSendCount = 0;
  	DN_FAL_PACKET_SERVICE_REQ_T  tServiceReq = {{0}};
  	//DN_FAL_PACKET_SERVICE_CNF_T  tRecvPacket  ={{0}};//cnf
	CIFX_PACKET tRecvPacket = {{0}};

	// Prepare packet
	tServiceReq.tHead.ulSrc    = 0;
	tServiceReq.tHead.ulDest   = 0x00000020;    
	tServiceReq.tHead.ulCmd    = DEVNET_FAL_CMD_REMOTE_SERVICE_REQ;
	//tServiceReq.tHead.ulLen    = DN_FAL_SERVICE_REQ_SIZE;
	tServiceReq.tHead.ulLen    = datasize+11;
	tServiceReq.tHead.ulSta    = 0;
	tServiceReq.tHead.ulExt    = 0;
	  
	tServiceReq.tData.bDevMacId  = (unsigned char)macid;
	tServiceReq.tData.usSrvDatLen  = datasize - 1;
	tServiceReq.tData.ubServiceCode  = (unsigned char)service;
	tServiceReq.tData.usClass      = Class; 
	tServiceReq.tData.usInstance   = instance;
	tServiceReq.tData.usAttribute  = buffer[0];
	//tServiceReq.tData.usSrvTimeOut = 100;//ms Trunk Code Version
	tServiceReq.tData.usSrvTimeOut = 50000; //ms PM2 1.8.6 Version
	
	
	for(int i=0; i<datasize-1; ++i)
	{
		tServiceReq.tData.abSrvData[i] = buffer[i+1];
	}	

//	tServiceReq.tHead.ulLen += datasize;
//	memcpy(&tServiceReq.tData.abAttData[0],buffer,datasize); 


	printf( "\n"\
          "--------------------------------\n"\
          "SetAtt.Req                      \n"\
          "-------------------             \n" );  
	printf( "Source : 0x%08X\n" \
          "Dest   : 0x%08X\n" \
          "Cmd    : 0x%08X\n" \
          "Len    : 0x%08X\n" \
          "State  : 0x%08X\n" \
          "Ext    : 0x%08X\n",       
          tServiceReq.tHead.ulSrc, tServiceReq.tHead.ulDest, 
          tServiceReq.tHead.ulCmd, tServiceReq.tHead.ulLen,
          tServiceReq.tHead.ulSta, tServiceReq.tHead.ulExt );
         
	printf( "DeviceAddr : %u\n" \
          "Class      : %u\n" \
          "Instance   : %u\n" \
          "Attribute  : %u\n" \
          "--------------------------------\n",

          tServiceReq.tData.bDevMacId,
          tServiceReq.tData.usClass,
          tServiceReq.tData.usInstance,
          tServiceReq.tData.usAttribute    );

	for(int i=0; i<datasize-1; ++i)  //add by wzd 1.1.54
	{
		printf( "Data : %u\n",tServiceReq.tData.abSrvData[i]);
	}

	//Get actual packe state
	lRet = xChannelGetMBXState(hChannel,&ulReceiveCount,&ulSendCount);
	if(lRet != CIFX_NO_ERROR)
	{
		ShowError(lRet);
		return false;
	}
	int nNum=0;
	while (ulReceiveCount > 0 && nNum < 10)
	{
		//Read packet
		//lRet = xChannelGetPacket(hChannel,sizeof(tRecvPacket),&tRecvPacket,1000); //Trunk Code Version
		lRet = xChannelGetPacket(hChannel, sizeof(tRecvPacket), &tRecvPacket, 100000); //PM2 1.8.6 Version
		if (lRet != CIFX_NO_ERROR)
		{
			ShowError(lRet);
			return false;
		}
		ulReceiveCount--;
		nNum++;
	}
    if(nNum >= 10)
    {
    	 SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::FATAL, "CIFXDeviceNet::writeExplicit failed for ReceiveCount over 10");
        return false;
    }
	//send packet to hardware
	//lRet = xChannelPutPacket(hChannel, (CIFX_PACKET*)&tServiceReq, 1000); //Trunk Code Version
	lRet = xChannelPutPacket(hChannel, (CIFX_PACKET*) &tServiceReq, 100000); //PM2 1.8.6 Version
	if (lRet != CIFX_NO_ERROR)
	{
		ShowError(lRet);
		return false;
	}
	//Read packet
	//if(CIFX_NO_ERROR != (lRet = xChannelGetPacket(hChannel,sizeof(tRecvPacket),(CIFX_PACKET*)&tRecvPacket,1000))) //Trunk Code Version
	if (CIFX_NO_ERROR != (lRet = xChannelGetPacket(hChannel, sizeof(tRecvPacket), (CIFX_PACKET*) &tRecvPacket, 100000))) // PM2 1.8.6 Version
	{
		ShowError(lRet);
		return false;
	}
	return true;
}

bool CIFXDEVNET::readExplicit(int macid, char *bufferIn, int service,int Class, int instance, int datasizeIn, char *bufferOut, int *datasizeOut)
{
	IMutexLocker locker(&m_lock);
	unsigned long lRet = 0;
  	uint32_t  ulReceiveCount  = 0;
  	uint32_t  ulSendCount     = 0;
  	int len = 0;
	DN_FAL_PACKET_SERVICE_REQ_T  tServiceReq = {{0}};//req
	DN_FAL_PACKET_SERVICE_CNF_T  tRecvPacket  ={{0}};//cnf

	// Prepare packet
	tServiceReq.tHead.ulSrc    = 0;
	tServiceReq.tHead.ulDest   = 0x20;    
	tServiceReq.tHead.ulCmd    = DEVNET_FAL_CMD_REMOTE_SERVICE_REQ;
	if(m_nHeadLen == -1)
	{
		tServiceReq.tHead.ulLen    = DN_FAL_SERVICE_REQ_SIZE;
	}
	else
	{
		tServiceReq.tHead.ulLen    = m_nHeadLen;   //add by wzd 1.1.54
	}
	tServiceReq.tHead.ulSta    = 0;
	tServiceReq.tHead.ulExt    = 0;
	  
	tServiceReq.tData.bDevMacId  = (unsigned char)macid;
	tServiceReq.tData.usSrvDatLen  = datasizeIn;
	tServiceReq.tData.ubServiceCode  = service;
	tServiceReq.tData.usClass      = Class; 
	tServiceReq.tData.usInstance   = instance;
	tServiceReq.tData.usAttribute  = bufferIn[0];
	tServiceReq.tData.usSrvTimeOut = 100;//ms
	
	for(int i=0; i<datasizeIn; ++i)
	{
		tServiceReq.tData.abSrvData[i] = bufferIn[i+1];
	}	

//	tServiceReq.tHead.ulLen += datasize;
//	memcpy(&tServiceReq.tData.abAttData[0],buffer,datasize); 

	printf( "\n"\
          "--------------------------------\n"\
          "SetAtt.Req                      \n"\
          "-------------------             \n" );  
	printf( "Source : 0x%08X\n" \
          "Dest   : 0x%08X\n" \
          "Cmd    : 0x%08X\n" \
          "Len    : 0x%08X\n" \
          "State  : 0x%08X\n" \
          "Ext    : 0x%08X\n",       
          tServiceReq.tHead.ulSrc, tServiceReq.tHead.ulDest, 
          tServiceReq.tHead.ulCmd, tServiceReq.tHead.ulLen,
          tServiceReq.tHead.ulSta, tServiceReq.tHead.ulExt );
         
	printf( "DeviceAddr : %u\n" \
          "Class      : %u\n" \
          "Instance   : %u\n" \
          "Attribute  : %u\n" \
          "--------------------------------\n",

          tServiceReq.tData.bDevMacId,
          tServiceReq.tData.usClass,
          tServiceReq.tData.usInstance,
          tServiceReq.tData.usAttribute    );

  
	//send packet to hardware
	lRet = xChannelPutPacket(hChannel, (CIFX_PACKET*)&tServiceReq, 1000);
	if(lRet != CIFX_NO_ERROR)
	{
		ShowError(lRet);
		return false;
	}  
    //Wait packet
	// int nWaitPacket = 100;//1s Trunk Code Version
	int nWaitPacket = 5; //5s PM2 1.8.6 Version
	while(nWaitPacket > 0)
	{
		cout<<"Wait packet back..."<<endl;
		lRet = xChannelGetMBXState(hChannel,&ulReceiveCount,&ulSendCount);
		if(ulReceiveCount > 0)
		{
			cout<<"Get actual packet count is "<<ulReceiveCount<<endl;
			//Read packet
	 		if(CIFX_NO_ERROR != (lRet = xChannelGetPacket(hChannel,sizeof(tRecvPacket),(CIFX_PACKET*)&tRecvPacket,1000)))
	 		{
		 		ShowError(lRet);
		 		return false;
	 		}
			break;
		}
		//usleep(10*1000); //Trunk Code Version
		sleep(1); //PM2 1.8.6 Version
		--nWaitPacket;
	}
	if(nWaitPacket == 0)
	{
    	 SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::FATAL, "CIFXDeviceNet::readExplicit failed for time out(1s)");
		return false;
	}
		cout<<"tRecvPacket.tData.usSrvDatLenn===="<<hex<<tRecvPacket.tData.usSrvDatLen<<endl;
		for(int i=0; i<4;i++)
		{
			cout<<"tRecvPacket.tData.abSrvData[i]===="<<tRecvPacket.tData.abSrvData[i]<<endl;
		}
	//*pDatasizeOut = tRecvPacket.tData.usSrvDatLen;
	for(int i=0; i<tRecvPacket.tData.usSrvDatLen; ++i)
	{
		bufferOut[i] = tRecvPacket.tData.abSrvData[i];
	}		
	return true;
}

