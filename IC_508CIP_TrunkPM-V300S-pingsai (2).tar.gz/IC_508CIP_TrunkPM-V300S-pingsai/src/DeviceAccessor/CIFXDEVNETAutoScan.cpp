#include "CIFXDEVNETAutoScan.h"
#include "ConfigException.h"
#include "Converter.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#include "rcX_Public.h"
#include "rcX_User.h"
#include "DevNetFal_Public.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <string.h>
#include "SysLogger.h"
#include <vector>
#include "DriverHelper.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;
using std::string;
using std::cout;
using std::endl;

#define CIFX_DEV "cifX0"
 DNM_PARAM_T tDnmParam;

using namespace std;
CIFXDEVNETAutoScan::CIFXDEVNETAutoScan(const std::string &devName, int masterMacId, int baudRate):DeviceNet(devName,masterMacId,baudRate)
{
	m_hDriver = NULL;
  	hChannel = NULL;
  	lRet            = 0;                                                  /* Return value for common error codes      */
	ulTimeout = 1000;                                               /* Timeout in milliseconds                  */
	ulState = 0;
	m_Init       = {0};
	m_Init.init_options        = CIFX_DRIVER_INIT_AUTOSCAN;
	m_Init.iCardNumber         = 0;
	m_Init.fEnableCardLocking  = 0;
	m_Init.base_dir            = NULL;
	m_Init.poll_interval       = 0;
	m_Init.poll_StackSize      = 0;   /* set to 0 to use default */
	m_Init.trace_level         = 255;
	m_Init.user_card_cnt       = 0;
 	m_Init.user_cards          = NULL;
  	m_Init.poll_priority       = 0;
  	m_Init.poll_schedpolicy    = 0;
	#ifdef SUSE
	m_Init.logfd = 0;  //add by wzd 1.1.39
  	#endif
  	
	
	for (int i=0;i<64;i++)
	{
		DevicesList[i]=NULL;
	}
}

CIFXDEVNETAutoScan::~CIFXDEVNETAutoScan()
{
	for (int i=0;i<64;i++)
	{
		if(DevicesList[i] != NULL)
		{
			delete DevicesList[i];
			DevicesList[i] = NULL;
		}
	}

	unsigned long ulState1;//modified by zhangyy[1.8.0]
	if(hChannel != NULL)
	{
		if(CIFX_NO_ERROR != xChannelBusState(hChannel, CIFX_BUS_STATE_OFF, (TLR_UINT32*)&ulState1, 10000))
		{
			cout<<"Error setting Bus state lRet"<<endl;
		}
	}
	if(m_hDriver != NULL)
	{
		xDriverClose(m_hDriver);
	}
	if(hChannel != NULL)
	{
		xChannelClose(hChannel);
	}
	cifXDriverDeinit();
}

void CIFXDEVNETAutoScan::ShowError(int32_t lError)
{
	if(lError != CIFX_NO_ERROR)
	{
		char szError[1024] = {0};
		xDriverGetErrorDescription(lError ,szError,sizeof(szError));
		printf("Error : 0x%X,<%s>\n",(unsigned int)lError,szError);
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::FATAL, "CIFXDeviceNet::ShowError() ErrorCode=" + Converter::convertToString((unsigned int)lError)+string(szError));
	}
}

void CIFXDEVNETAutoScan::loadDevice()
{
	/* First of all initialize toolkit */
	lRet = cifXDriverInit(&m_Init);
	if(CIFX_NO_ERROR != lRet)
	{
		ShowError(lRet);
		throw ConfigException("CIFX Error Open Driver,Error is " + Converter::convertToString((unsigned int)lRet));
	}
	lRet    = xDriverOpen(&m_hDriver);
	if(CIFX_NO_ERROR != lRet)
	{
		ShowError(lRet);
		throw ConfigException("CIFX Error Open Driver,Error is " + Converter::convertToString((unsigned int)lRet));
	}
	/* Driver/Toolkit successfully opened */
	lRet = xChannelOpen(NULL, CIFX_DEV, 0, &hChannel);
	if(CIFX_NO_ERROR != lRet)
	{
		ShowError(lRet);
		throw ConfigException("CIFX Error Open Channel,Error is " + Converter::convertToString((unsigned int)lRet));
	}

	lRet = xChannelReset(hChannel, CIFX_CHANNELINIT, 2000);
	if(CIFX_NO_ERROR != lRet)
	{
		ShowError(lRet);
		throw ConfigException("CIFX Error Channel Reset,Error is " + Converter::convertToString((unsigned int)lRet));
	}

	CHANNEL_INFORMATION tChannelInfo = {{0}};

	/* Channel successfully opened, so query basic information */
	if( CIFX_NO_ERROR != (lRet = xChannelInfo(hChannel, sizeof(CHANNEL_INFORMATION), &tChannelInfo)))
	{
		ShowError(lRet);
		throw ConfigException("CIFX Error querying system information block ");
	}
	else
	{
		cout<<"Communication Channel Info"<<endl;
		cout<<"Device Number    : "<<(long unsigned int)tChannelInfo.ulDeviceNumber<<endl;
		cout<<"Serial Number    : "<<(long unsigned int)tChannelInfo.ulSerialNumber<<endl;
		cout<<"Firmware         : "<<tChannelInfo.abFWName<<endl;
		cout<<"FW Version       : "<<tChannelInfo.usFWMajor<<"."<<tChannelInfo.usFWMinor
			  <<"."<<tChannelInfo.usFWRevision<<" build "<<tChannelInfo.usFWBuild<<endl;
		cout<<"FW Date          : "<<tChannelInfo.usFWYear<<tChannelInfo.bFWMonth<<tChannelInfo.bFWDay<<endl;

		cout<<"Mailbox Size     : "<<(long unsigned int)tChannelInfo.ulMailboxSize<<endl;
   }

   //maxmadded
	createDnmParam(&tDnmParam,
						0,//uint32_t				ConfigFlag,
						//uint32_t				#Watchdog,
						0,//uint32_t				NodeAddress,
						m_baudRate, //uint32_t				Baudrate,
						0, //uint32_t				EnableFlag,
						0,//uint32_t				VendorId,
						0,//uint32_t				ProductType,
						0,//uint32_t				ProductCode,
						1, //uint32_t				MajorRevision,
						0,//uint32_t				MinorRevision,
						0,//uint32_t				SerialNumber,
						0,//char				    ProductName[32],
						tDnmParam.slaves//DNS_PARAM_T*			slaves
						//uint32_t				Database = False
					   );

	applyDnmParam(hChannel, &tDnmParam, true);

	sleep(2);

	networkScan(hChannel);

	sleep(2);

	xChannelReset(hChannel, CIFX_CHANNELINIT, 2000);

	sleep(2);

	applyDnmParam(hChannel, &tDnmParam, true);
	sleep(2);

	lRet = xChannelOpen(NULL, CIFX_DEV, 0, &hChannel);
	if(CIFX_NO_ERROR != lRet)
	{
		ShowError(lRet);
		throw ConfigException("CIFX Error Open Channel,Error is " + Converter::convertToString((unsigned int)lRet));
	}

			sleep(2);

   /* Set Host Ready to signal the filed bus an application is ready */
	if(CIFX_NO_ERROR !=(lRet = xChannelHostState(hChannel,CIFX_HOST_STATE_READY,(TLR_UINT32*)&ulState,10000)))
	{
		ShowError(lRet);
	   xChannelClose(hChannel);
	   xDriverClose(m_hDriver);
	   throw ConfigException("CIFX Error read xChannelHostState,Error is " + Converter::convertToString((unsigned int)lRet));
	}
   sleep(2);
	if(CIFX_NO_ERROR != (lRet = xChannelBusState(hChannel, CIFX_BUS_STATE_ON,(TLR_UINT32*) &ulState, 10000)))
	{
		ShowError(lRet);
	   xChannelClose(hChannel);
	   xDriverClose(m_hDriver);
	   throw ConfigException("CIFX Error setting Bus state,Error is " + Converter::convertToString((unsigned int)lRet));
	}

	for (int retry = 0; retry < 2; retry++)
	{
		sleep(5);
		NETX_COMMON_STATUS_BLOCK tCommonStatusBlock = {0};
		if(CIFX_NO_ERROR != (lRet = xChannelCommonStatusBlock(hChannel, CIFX_CMD_READ_DATA,0,sizeof(tCommonStatusBlock),(void*)&tCommonStatusBlock)))
		{
			if (retry == 0)
			{
				continue;
			}
			else
			{
				ShowError(lRet);
				xChannelClose(hChannel);
				xDriverClose(m_hDriver);
				throw ConfigException("CIFX Error read CommonStatusBlock,Error is " + Converter::convertToString((unsigned int)lRet));
			}

		}
		else
		{
			if((tCommonStatusBlock.ulCommunicationCOS & RCX_COMM_COS_BUS_ON) != RCX_COMM_COS_BUS_ON)
			{
				if (retry == 0)
				{
					continue;
				}
				else
				{
					throw ConfigException("CIFX Error Bus state is not on");
				}
			}
			if((tCommonStatusBlock.ulCommunicationState & RCX_COMM_STATE_IDLE) != RCX_COMM_STATE_IDLE)
			{
				cout<<"CIFX Communication State is "<<tCommonStatusBlock.ulCommunicationState<<endl;
				//throw ConfigException("CIFX Error Communication State is not Idle");
			}
			if(tCommonStatusBlock.ulCommunicationError != RCX_S_OK)
			{
				if (retry == 0)
				{
					continue;
				}
				else
				{
					cout<<"CIFX has Communication Error"<<endl;
					//throw ConfigException("CIFX has Communication Error");
				}
			}

			cout<<"Communication Channel Slave Infor"<<endl;
			cout<<"Number of Config Slaves    : "<<(long unsigned int)tCommonStatusBlock.uStackDepended.tMasterStatusBlock.ulNumOfConfigSlaves<<endl;
			cout<<"Number of Active Slaves    : "<<(long unsigned int)tCommonStatusBlock.uStackDepended.tMasterStatusBlock.ulNumOfActiveSlaves<<endl;
			cout<<"Number of Faulted Slaves   : "<<(long unsigned int)tCommonStatusBlock.uStackDepended.tMasterStatusBlock.ulNumOfDiagSlaves<<endl;
		}
	}
}

bool CIFXDEVNETAutoScan::addDevice(int inmac)
{
	if(DevicesList[inmac] == NULL)
	{
		throw ConfigException("CIFX add Mac " + Converter::convertToString(inmac) + " failed,because the DnCifx.conf don't config this MacID");
	}
	cout<<"start scan MacID "<<inmac<<endl;
	if(readStatus(inmac) < 0)
	{
		cout<<"scan failed, rescan..."<<endl;
		sleep(3);
		if(readStatus(inmac) < 0)
		{
			throw ConfigException("CIFX add Mac " + Converter::convertToString(inmac) + " failed,Please check and rescan!");
		}
	}
	cout<<"MacID "<<inmac<<" is online"<<endl;
	return true;	
}

int CIFXDEVNETAutoScan::readStatus(int nMacId)
{
	IMutexLocker locker(&m_lock);
	char buffer[64];
	memset(buffer, 0, sizeof(buffer));
	int lRet = xChannelExtendedStatusBlock(hChannel, CIFX_CMD_READ_DATA, 0, 64, &buffer[0]);
//	//slave io states(mac id:1~64) stored in buffer[40]~buffer[47]
////	for (int i = 0; i < 64; i++)
////	{
////		printf( "%d:%02X ", i + 50, buffer[i]);
////		if ((i + 1) % 8 == 0)
////		{
////			printf("\n");
////		}
////	}
//
	bool let = (0xff & buffer[40 + nMacId / 8]) & (0x01 << (nMacId % 8));
////	printf("%d:state is %d\n", nMacId, let);
	return let;
}

bool CIFXDEVNETAutoScan::readByte(int inmac, char *byte)
{
	IMutexLocker locker(&m_lock);
	if(DevicesList[inmac] == NULL)
	{
		throw IOException("CIFXDEVNET::there is no device for MacID '" +Converter::convertToString(inmac)+ "'");
	}	
	int foo = readDeviceIO(0,inmac,0, byte);
	if(foo < 0)
	{
		throw IOException("CIFXDEVNET::read data from MacID '" +Converter::convertToString(inmac)+"' failed");
	}
	return true;
}

bool CIFXDEVNETAutoScan::writeByte(int inmac, char *byte)
{
	IMutexLocker locker(&m_lock);
	if(DevicesList[inmac] == NULL)
	{
		throw IOException("CIFXDEVNET::there is no device for MacID '" +Converter::convertToString(inmac)+ "'");
	}	
	int foo = writeDeviceIO(0, inmac, 0, byte);
	if(foo < 0)
	{
		throw IOException("CIFXDEVNET::write data to MacID '" +Converter::convertToString(inmac)+"' failed");
	}
	return true;
}

int CIFXDEVNETAutoScan::getIBytesSize(int inmac)
{
	return DevicesList[inmac]->Input1Size;
}

int CIFXDEVNETAutoScan::getOBytesSize(int inmac)
{
	return DevicesList[inmac]->Output1Size;
}

bool CIFXDEVNETAutoScan::readBit(int inmac, int channel, bool *bit)
{
	int inputBytes = (*DevicesList[inmac]).Input1Size;
	if(channel >= inputBytes*8)
	{
		throw IOException("CIFXDEVNET::the channel to read is bigger than allowed channels for MacID '" +Converter::convertToString(inmac)+"'");
	}
	char buffer[inputBytes];
	memset(buffer, 0, inputBytes);
	bool foo = readByte(inmac, buffer);
	if(foo)
	{
		int byteno = channel / 8;
		int bitno = channel % 8;
		unsigned char bitmask = 1;
		bitmask = bitmask << bitno;
		*bit = (bool)(buffer[byteno] & bitmask);
		return true;		
	}
	else
	{
		return false;
	}
}

bool CIFXDEVNETAutoScan::writeBit(int inmac, int channel, bool bit)
{
	int outputBytes = (*DevicesList[inmac]).Output1Size;
	if(channel >= outputBytes*8)
	{
		throw IOException("CIFXDEVNET::the channel to write is bigger than allowed channels for MacID '" +Converter::convertToString(inmac)+"'");
	}	
	char buffer[outputBytes];
	memset(buffer, 0, outputBytes);
	if(bit == 1)
	{
		int byteno = channel / 8;
		int bitno = channel % 8;
		unsigned char bitmask = 1;
		bitmask = bitmask << bitno;	
		buffer[byteno] = 	buffer[byteno] | bitmask;
	}
	return writeByte(inmac, buffer);
}

bool CIFXDEVNETAutoScan::writeExplicit(int macid, char *buffer, int service, int Class, int instance, int datasize)
{
	
	IMutexLocker locker(&m_lock);
	unsigned long lRet = 0;
	uint32_t ulReceiveCount = 0;
	uint32_t ulSendCount = 0;
  	DN_FAL_PACKET_SERVICE_REQ_T  tServiceReq = {{0}};
  	//DN_FAL_PACKET_SERVICE_CNF_T  tRecvPacket  ={{0}};//cnf
	CIFX_PACKET tRecvPacket = {{0}};

	// Prepare packet
	tServiceReq.tHead.ulSrc    = 0;
	tServiceReq.tHead.ulDest   = 0x00000020;    
	tServiceReq.tHead.ulCmd    = DEVNET_FAL_CMD_REMOTE_SERVICE_REQ;
	//tServiceReq.tHead.ulLen    = DN_FAL_SERVICE_REQ_SIZE;
	tServiceReq.tHead.ulLen    = datasize+11;
	tServiceReq.tHead.ulSta    = 0;
	tServiceReq.tHead.ulExt    = 0;
	  
	tServiceReq.tData.bDevMacId  = (unsigned char)macid;
	tServiceReq.tData.usSrvDatLen  = datasize - 1;
	tServiceReq.tData.ubServiceCode  = (unsigned char)service;
	tServiceReq.tData.usClass      = Class; 
	tServiceReq.tData.usInstance   = instance;
	tServiceReq.tData.usAttribute  = buffer[0];
	//tServiceReq.tData.usSrvTimeOut = 100;//ms Trunk Code Version
	tServiceReq.tData.usSrvTimeOut = 50000; //ms PM2 1.8.6 Version
	
	
	for(int i=0; i<datasize-1; ++i)
	{
		tServiceReq.tData.abSrvData[i] = buffer[i+1];
	}	

//	tServiceReq.tHead.ulLen += datasize;
//	memcpy(&tServiceReq.tData.abAttData[0],buffer,datasize); 


	printf( "\n"\
          "--------------------------------\n"\
          "SetAtt.Req                      \n"\
          "-------------------             \n" );  
	printf( "Source : 0x%08X\n" \
          "Dest   : 0x%08X\n" \
          "Cmd    : 0x%08X\n" \
          "Len    : 0x%08X\n" \
          "State  : 0x%08X\n" \
          "Ext    : 0x%08X\n",       
          tServiceReq.tHead.ulSrc, tServiceReq.tHead.ulDest, 
          tServiceReq.tHead.ulCmd, tServiceReq.tHead.ulLen,
          tServiceReq.tHead.ulSta, tServiceReq.tHead.ulExt );
         
	printf( "DeviceAddr : %u\n" \
          "Class      : %u\n" \
          "Instance   : %u\n" \
          "Attribute  : %u\n" \
          "--------------------------------\n",

          tServiceReq.tData.bDevMacId,
          tServiceReq.tData.usClass,
          tServiceReq.tData.usInstance,
          tServiceReq.tData.usAttribute    );

	for(int i=0; i<datasize-1; ++i)  //add by wzd 1.1.54
	{
		printf( "Data : %u\n",tServiceReq.tData.abSrvData[i]);
	}

	//Get actual packe state
	lRet = xChannelGetMBXState(hChannel,&ulReceiveCount,&ulSendCount);
	if(lRet != CIFX_NO_ERROR)
	{
		ShowError(lRet);
		return false;
	}
	int nNum=0;
	while (ulReceiveCount > 0 && nNum < 10)
	{
		//Read packet
		//lRet = xChannelGetPacket(hChannel,sizeof(tRecvPacket),&tRecvPacket,1000); //Trunk Code Version
		lRet = xChannelGetPacket(hChannel, sizeof(tRecvPacket), &tRecvPacket, 100000); //PM2 1.8.6 Version
		if (lRet != CIFX_NO_ERROR)
		{
			ShowError(lRet);
			return false;
		}
		ulReceiveCount--;
		nNum++;
	}
    if(nNum >= 10)
    {
    	 SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::FATAL, "CIFXDeviceNet::writeExplicit failed for ReceiveCount over 10");
        return false;
    }
	//send packet to hardware
	//lRet = xChannelPutPacket(hChannel, (CIFX_PACKET*)&tServiceReq, 1000); //Trunk Code Version
	lRet = xChannelPutPacket(hChannel, (CIFX_PACKET*) &tServiceReq, 100000); //PM2 1.8.6 Version
	if (lRet != CIFX_NO_ERROR)
	{
		ShowError(lRet);
		return false;
	}
	//Read packet
	//if(CIFX_NO_ERROR != (lRet = xChannelGetPacket(hChannel,sizeof(tRecvPacket),(CIFX_PACKET*)&tRecvPacket,1000))) //Trunk Code Version
	if (CIFX_NO_ERROR != (lRet = xChannelGetPacket(hChannel, sizeof(tRecvPacket), (CIFX_PACKET*) &tRecvPacket, 100000))) // PM2 1.8.6 Version
	{
		ShowError(lRet);
		return false;
	}
	return true;
}

bool CIFXDEVNETAutoScan::readExplicit(int macid, char *bufferIn, int service,int Class, int instance, int datasizeIn, char *bufferOut, int *datasizeOut)
{
	IMutexLocker locker(&m_lock);
	unsigned long lRet = 0;
  	uint32_t  ulReceiveCount  = 0;
  	uint32_t  ulSendCount     = 0;
  	int len = 0;
	DN_FAL_PACKET_SERVICE_REQ_T  tServiceReq = {{0}};//req
	DN_FAL_PACKET_SERVICE_CNF_T  tRecvPacket  ={{0}};//cnf

	// Prepare packet
	tServiceReq.tHead.ulSrc    = 0;
	tServiceReq.tHead.ulDest   = 0x20;    
	tServiceReq.tHead.ulCmd    = DEVNET_FAL_CMD_REMOTE_SERVICE_REQ;
	if(m_nHeadLen == -1)
	{
		tServiceReq.tHead.ulLen    = DN_FAL_SERVICE_REQ_SIZE;
	}
	else
	{
		tServiceReq.tHead.ulLen    = m_nHeadLen;   //add by wzd 1.1.54
	}
	tServiceReq.tHead.ulSta    = 0;
	tServiceReq.tHead.ulExt    = 0;
	  
	tServiceReq.tData.bDevMacId  = (unsigned char)macid;
	tServiceReq.tData.usSrvDatLen  = datasizeIn;
	tServiceReq.tData.ubServiceCode  = service;
	tServiceReq.tData.usClass      = Class; 
	tServiceReq.tData.usInstance   = instance;
	tServiceReq.tData.usAttribute  = bufferIn[0];
	tServiceReq.tData.usSrvTimeOut = 100;//ms
	
	for(int i=0; i<datasizeIn; ++i)
	{
		tServiceReq.tData.abSrvData[i] = bufferIn[i+1];
	}	

//	tServiceReq.tHead.ulLen += datasize;
//	memcpy(&tServiceReq.tData.abAttData[0],buffer,datasize); 

	printf( "\n"\
          "--------------------------------\n"\
          "SetAtt.Req                      \n"\
          "-------------------             \n" );  
	printf( "Source : 0x%08X\n" \
          "Dest   : 0x%08X\n" \
          "Cmd    : 0x%08X\n" \
          "Len    : 0x%08X\n" \
          "State  : 0x%08X\n" \
          "Ext    : 0x%08X\n",       
          tServiceReq.tHead.ulSrc, tServiceReq.tHead.ulDest, 
          tServiceReq.tHead.ulCmd, tServiceReq.tHead.ulLen,
          tServiceReq.tHead.ulSta, tServiceReq.tHead.ulExt );
         
	printf( "DeviceAddr : %u\n" \
          "Class      : %u\n" \
          "Instance   : %u\n" \
          "Attribute  : %u\n" \
          "--------------------------------\n",

          tServiceReq.tData.bDevMacId,
          tServiceReq.tData.usClass,
          tServiceReq.tData.usInstance,
          tServiceReq.tData.usAttribute    );

  
	//send packet to hardware
	lRet = xChannelPutPacket(hChannel, (CIFX_PACKET*)&tServiceReq, 1000);
	if(lRet != CIFX_NO_ERROR)
	{
		ShowError(lRet);
		return false;
	}  
    //Wait packet
	// int nWaitPacket = 100;//1s Trunk Code Version
	int nWaitPacket = 5; //5s PM2 1.8.6 Version
	while(nWaitPacket > 0)
	{
		cout<<"Wait packet back..."<<endl;
		lRet = xChannelGetMBXState(hChannel,&ulReceiveCount,&ulSendCount);
		if(ulReceiveCount > 0)
		{
			cout<<"Get actual packet count is "<<ulReceiveCount<<endl;
			//Read packet
	 		if(CIFX_NO_ERROR != (lRet = xChannelGetPacket(hChannel,sizeof(tRecvPacket),(CIFX_PACKET*)&tRecvPacket,1000)))
	 		{
		 		ShowError(lRet);
		 		return false;
	 		}
			break;
		}
		//usleep(10*1000); //Trunk Code Version
		sleep(1); //PM2 1.8.6 Version
		--nWaitPacket;
	}
	if(nWaitPacket == 0)
	{
    	 SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::FATAL, "CIFXDeviceNet::readExplicit failed for time out(1s)");
		return false;
	}
		cout<<"tRecvPacket.tData.usSrvDatLenn===="<<hex<<tRecvPacket.tData.usSrvDatLen<<endl;
		for(int i=0; i<4;i++)
		{
			cout<<"tRecvPacket.tData.abSrvData[i]===="<<tRecvPacket.tData.abSrvData[i]<<endl;
		}
	//*pDatasizeOut = tRecvPacket.tData.usSrvDatLen;
	for(int i=0; i<tRecvPacket.tData.usSrvDatLen; ++i)
	{
		bufferOut[i] = tRecvPacket.tData.abSrvData[i];
	}		
	return true;
}

//added by mujy [20250220] for cifx auto scan
TLR_RESULT App_SendRecvPkt(CIFXHANDLE hChannel, CIFX_PACKET* ptSendPkt, CIFX_PACKET* ptRecvPkt, uint32_t ulTimeout)
{
  TLR_RESULT tResult = TLR_S_OK;

  /* fire the packet */

  tResult = xChannelPutPacket(hChannel, ptSendPkt, ulTimeout);
  if (TLR_S_OK != tResult)
  {
    return tResult;
  }

  /* ok, at this point we have successfully sent a packet */

  /* check for packets to receive */
  /* the ulCnfCmd is always: ulReqCmd | 0x01 */
  TLR_UINT32 ulCnfCmd = ptSendPkt->tHeader.ulCmd | 0x01;

  while(CIFX_NO_ERROR == (tResult = xChannelGetPacket(hChannel, sizeof(*ptRecvPkt), ptRecvPkt, ulTimeout)))
  {
    /* check for our packet */
    if(ptRecvPkt->tHeader.ulCmd == ulCnfCmd)
    {
      /* it is our packet, so return its status as result */
      tResult = ptRecvPkt->tHeader.ulState;

      /* Note: we also return the packet which we have received (by reference, see signature of function) */

      /* we have received our packet, so we can break here */
      break;
    }
    else
    {
      /* it is something else, so place it in the application packet handler */
      //App_HandlePacket(ptApp, ptRecvPkt);
    }
  }

  return tResult;
}

void createDnmParam(DNM_PARAM_T*            self,
					uint32_t				ConfigFlag,
					//uint32_t				#Watchdog,
					uint32_t				NodeAddress,
					uint32_t				Baudrate,
					uint32_t				EnableFlag,
					uint32_t				VendorId,
					uint32_t				ProductType,
					uint32_t				ProductCode,
					uint32_t				MajorRevision,
					uint32_t				MinorRevision,
					uint32_t				SerialNumber,
					char				    ProductName[32],
					DNS_PARAM_T*			slaves
					//uint32_t				Database = False
					)
{
	uint32_t None = 0;


	/*-----------------------PARAMETER OF MASTER ITSELF#----------------------*/
	if (ConfigFlag == None)
		self->ConfigFlags = 0;
	else
		self->ConfigFlags = ConfigFlag;

	if (EnableFlag == None)
		self->EnableFlags = DN_FAL_MSK_DEV_PRM_ENABLE_VENDORID | \
							          DN_FAL_MSK_DEV_PRM_ENABLE_PRODUCTTYPE | \
							          DN_FAL_MSK_DEV_PRM_ENABLE_PRODUCTCODE | \
							          DN_FAL_MSK_DEV_PRM_ENABLE_MAJORMINORREV | \
							          DN_FAL_MSK_DEV_PRM_ENABLE_PRODUCTNAME;
	else
		self->EnableFlags = EnableFlag;

	if (VendorId == None)
		self->VendorId = 283;
	else
		self->VendorId = VendorId;

	if (ProductType == None)
		self->ProductType = 12;                   //#Communication Adapter
	else
		self->ProductType = ProductType;

	if (ProductCode == None)
		self->ProductCode = 40;                   //#PRODUCT_CODE_DNM_NETX_500
	else
		self->ProductCode = ProductCode;

	if (MajorRevision == None)
		self->MajorRevision = 1;
	else
		self->MajorRevision = MajorRevision;

	if (MinorRevision == None)
		self->MinorRevision = 1;
	else
		self->MinorRevision = MinorRevision;

	if (SerialNumber == None)
		self->SerialNumber = 20021;
	else
		self->SerialNumber = SerialNumber;

	if (ProductName == NULL)
	{
		self->ProductNameLen = 11;
    strcpy(self->ProductName, "NETX DN/DNM");
	}
	else
	{
		self->ProductNameLen = strlen(ProductName);
		strcpy(self->ProductName, ProductName);
	}
  /*------------------------------------------------------------------------*/


  /*---------------------BUS PARAMETER OF THE MASTER------------------------*/
	self->SystemFlags = 0x00000001;

	if (NodeAddress == None)
		self->NodeAddress = 0;
	else
		self->NodeAddress = NodeAddress;

	if (Baudrate == 500)
		self->Baudrate = 1;                                 //#500kbaud
	else if (Baudrate == 250)
		self->Baudrate = 2;                                //#250kbaud
	else if (Baudrate == 125)
		self->Baudrate = 3;                                 //#250kbaud
	else
		self->Baudrate = 1;                                 //#default

  /*------------------------------------------------------------------------*/


  /*---------------------------SLAVE CONFIGURATION--------------------------*/

  for (int i = 0; i < 64; i++)
  {
    self->slaves[i].Activated = false;
  }

}

void applyDnmParam(CIFXHANDLE hChannel, DNM_PARAM_T*  self, bool BusOn)
{
	DNS_PARAM_T*                 slv_cfg;
	DN_FAL_PACKET_DOWNLOAD_REQ_T slv_cfg_req;
	DN_FAL_PACKET_DOWNLOAD_CNF_T slv_cfg_cnf;

	DN_DEV_PRM_HEADER_T*         pDevParam;
	DN_PRED_MSTSL_CFG_DATA_T*    pPredefMSCfg;
	DN_PRED_MSTSL_CONNOBJ_T*     pConnObj;
	DN_IO_MODULE_T*              pIOCfg;
	DN_PRED_MSTSL_ADD_TAB_T*     pIOOffset;
	TLR_UINT16*                  offset_pnt;
	int                          output_offset_begin;
	int                          IOOffsetCfgLen;
	DN_EXPL_SET_ATTR_DATA_T*     pSetParamCfg;
	DN_SET_ATTR_DATA_T*          pRemPrm;

	DN_FAL_PACKET_DOWNLOAD_REQ_T dnm_download_req;
	DN_FAL_PACKET_DOWNLOAD_CNF_T dnm_download_cnf;

    RCX_START_STOP_COMM_REQ_T    start_stop_rep  ;
    RCX_START_STOP_COMM_CNF_T    start_stop_cnf  ;

	DN_FAL_PACKET_DOWNLOAD_REQ_T bus_download_req;
	DN_FAL_PACKET_DOWNLOAD_CNF_T bus_download_cnf;

	DN_FAL_PACKET_DOWNLOAD_REQ_T srv_download_req;
	DN_FAL_PACKET_DOWNLOAD_CNF_T srv_download_cnf;

	DN_FAL_BUS_PRM_T*            pBusParam;

	DN_FAL_DEV_PRM_T*            pDnmDevParam;

	DN_FAL_SRV_PRM_T*            pSrvParam;

	NETX_HANDSHAKE_CHANNEL       handshake_flag;

	void* pvUser = NULL;

	uint8_t                      None = 0;

	uint32_t ulState;

	uint32_t ulTimeout = 10000;
	int32_t  lRet  = 0;



  TLR_UINT32                   eR;


  int slv_mac = 0;

  std::vector<int> in_offset_info;//
  std::vector<int> out_offset_info;
	for (slv_mac = 0; slv_mac < 64; slv_mac++)
	{

		slv_cfg = &self->slaves[slv_mac];


        if (slv_cfg->Activated == false)
        {

             continue;
        }

		/*------------------------DOWNLOAD SLAVE PARAMETER------------------------*/
        memset(&slv_cfg_req, 0x00, sizeof(DN_FAL_PACKET_DOWNLOAD_REQ_T));
		slv_cfg_req.tHead.ulCmd  = DEVNET_FAL_CMD_DOWNLOAD_REQ;
		if(DriverHelper::isSystem64bit())//add by mujy [1.5.0] for system is 64bit
		{
			slv_cfg_req.tHead.ulSrc  = (TLR_UINT64)(&slv_cfg_req);//addressof(slv_cfg_req);// #Just something unique
		}
		else
		{
			slv_cfg_req.tHead.ulSrc  = (TLR_UINT32)(&slv_cfg_req);//addressof(slv_cfg_req);// #Just something unique
		}
		
		slv_cfg_req.tHead.ulDest = RCX_PACKET_DEST_DEFAULT_CHANNEL;
		slv_cfg_req.tHead.ulExt  = RCX_PACKET_SEQ_NONE;

		slv_cfg_req.tData.usArea = DN_FAL_DOWNLOAD_AREA_SLAVE_PARAMETER;

        slv_cfg_req.tData.usSubArea = slv_mac;

		pDevParam = (DN_DEV_PRM_HEADER_T*)(slv_cfg_req.tData.abData);

		pDevParam[0].bDvFlag = 129;                                  // #Active ?
		pDevParam[0].bUcmmGroup = 3;                                 // #UCMM Group
		pDevParam[0].usRecFragTimer = 1700;

		if (slv_cfg->VendorId == None)
			pDevParam[0].usVendorID = 0;
		else
			pDevParam[0].usVendorID = slv_cfg->VendorId;

		if (slv_cfg->ProductType == None)
			pDevParam[0].usDeviceType = 0;
		else
			pDevParam[0].usDeviceType = slv_cfg->ProductType;

		if (slv_cfg->ProductCode == None)
			pDevParam[0].usProductCode = 0;
		else
			pDevParam[0].usProductCode = slv_cfg->ProductCode;

		if (slv_cfg->MajorRevision == None)
			pDevParam[0].bMajorRevision = 1;
		else
			pDevParam[0].bMajorRevision = slv_cfg->MajorRevision;

		if (slv_cfg->MinorRevision == None)
			pDevParam[0].bMinorRevision = 1;
		else
			pDevParam[0].bMinorRevision = slv_cfg->MinorRevision;


        pPredefMSCfg = (DN_PRED_MSTSL_CFG_DATA_T*)(slv_cfg_req.tData.abData + sizeof(DN_DEV_PRM_HEADER_T));

		vector<string> cnxn_list;//

		if (slv_cfg->Poll == TRUE)
			cnxn_list.push_back("Poll");

		if (slv_cfg->COSCYC == 1)
			cnxn_list.push_back("COS");
		//else if (slv_cfg->COSCYC == 2) //deleted by zhangyy for bool will never be equal to 2[1.8.0]
			//cnxn_list.push_back("CYC");

		if (slv_cfg->Bitstrobe == TRUE)
			cnxn_list.push_back("Bitstrobe");

		if (slv_cfg->Broadcast == TRUE)
			cnxn_list.push_back("Broadcast");

		int num_of_cnxn = cnxn_list.size();

        /*########################################################################*/

		pPredefMSCfg->usPredMstslCfgDataLen = 2 /*pPredefMSCfg._type_.usPredMstslCfgDataLen.size */ + \
									                        num_of_cnxn*sizeof(DN_PRED_MSTSL_IO_OBJ_HEADER_T) + \
									                        num_of_cnxn * 2 * sizeof(DN_IO_MODULE_T);//#2 = bNumOfIOModules

		pConnObj = (DN_PRED_MSTSL_CONNOBJ_T*)(&(pPredefMSCfg[0].atConnObjInst[0]));

		for (std::vector<string>::iterator cnxn = cnxn_list.begin(); cnxn != cnxn_list.end(); cnxn++)//遍历cnxn.list
		{
                	if (*cnxn == "Poll")//
			{
				pConnObj[0].tPredMstSlObjHeader.bConnectionType = 1;
				pConnObj[0].tPredMstSlObjHeader.bWatchdogTimeoutAction = 0;
				pConnObj[0].tPredMstSlObjHeader.usProdInhibitTime = slv_cfg->PollBanTime;
				pConnObj[0].tPredMstSlObjHeader.usExpPacketRate = 2000;
				pConnObj[0].tPredMstSlObjHeader.bNumOfIOModules = 2;

				pIOCfg = (DN_IO_MODULE_T*)(&(pConnObj[0].atIOModule[0]));

				pIOCfg[0].bDataType = 10;
				pIOCfg[0].bDataSize = slv_cfg->ProducedSize;
				pIOCfg[1].bDataType = 138;
				pIOCfg[1].bDataSize = slv_cfg->ConsumedSize;
			}
			else if (*cnxn == "Bitstrobe")
			{
				pConnObj[0].tPredMstSlObjHeader.bConnectionType = 0x02;
				pConnObj[0].tPredMstSlObjHeader.bWatchdogTimeoutAction = 0;
				pConnObj[0].tPredMstSlObjHeader.usProdInhibitTime = slv_cfg->BitstrobeBanTime;
				pConnObj[0].tPredMstSlObjHeader.usExpPacketRate = slv_cfg->BitstrobeERP;
				pConnObj[0].tPredMstSlObjHeader.bNumOfIOModules = 2;
				pIOCfg = (DN_IO_MODULE_T*)(&(pConnObj[0].atIOModule[0]));

				pIOCfg[0].bDataType = 10;
				pIOCfg[0].bDataSize = slv_cfg->BitStrobeProdSz;
				pIOCfg[1].bDataType = 138;
				pIOCfg[1].bDataSize = slv_cfg->BitStrobeConsSz;
			}
			else if (*cnxn == "CYC")
			{
				pConnObj[0].tPredMstSlObjHeader.bConnectionType = 8;
				pConnObj[0].tPredMstSlObjHeader.bWatchdogTimeoutAction = 0;
				pConnObj[0].tPredMstSlObjHeader.usProdInhibitTime = slv_cfg->COSCYCBanTime;
				pConnObj[0].tPredMstSlObjHeader.usExpPacketRate = slv_cfg->COSCYCERP;
				pConnObj[0].tPredMstSlObjHeader.bNumOfIOModules = 2;
				pIOCfg = (DN_IO_MODULE_T*)(&(pConnObj[0].atIOModule[0]));

				pIOCfg[0].bDataType = 10;
				pIOCfg[0].bDataSize = slv_cfg->COSCYCProdSz;
				pIOCfg[1].bDataType = 138;
				pIOCfg[1].bDataSize = slv_cfg->COSCYCConsSz;
			}
			else if (*cnxn == "COS")
			{
				pConnObj[0].tPredMstSlObjHeader.bConnectionType = 0x04;// #TYPE_CHG_OF_STATE;
				pConnObj[0].tPredMstSlObjHeader.bWatchdogTimeoutAction = 0;
				pConnObj[0].tPredMstSlObjHeader.usProdInhibitTime = slv_cfg->COSCYCBanTime;
				pConnObj[0].tPredMstSlObjHeader.usExpPacketRate = slv_cfg->COSCYCERP;
				pConnObj[0].tPredMstSlObjHeader.bNumOfIOModules = 2;
				pIOCfg = (DN_IO_MODULE_T*)(&(pConnObj[0].atIOModule[0]));

				pIOCfg[0].bDataType = 10;
				pIOCfg[0].bDataSize = slv_cfg->COSCYCProdSz;
				pIOCfg[1].bDataType = 138;
				pIOCfg[1].bDataSize = slv_cfg->COSCYCConsSz;
			}

			in_offset_info.push_back(pIOCfg[0].bDataSize);//
			out_offset_info.push_back(pIOCfg[1].bDataSize);

			/*######################################################################*/
			pConnObj = (DN_PRED_MSTSL_CONNOBJ_T*)(&(pIOCfg[0]) + pConnObj[0].tPredMstSlObjHeader.bNumOfIOModules * sizeof(DN_IO_MODULE_T));
		}

		/*########################################################################*/
		if(DriverHelper::isSystem64bit())//add by mujy [1.5.0] for system is 64bit
		{
			pIOOffset = (DN_PRED_MSTSL_ADD_TAB_T*)((uint64_t)pPredefMSCfg + (uint64_t)(pPredefMSCfg->usPredMstslCfgDataLen));
		}
		else
		{
			pIOOffset = (DN_PRED_MSTSL_ADD_TAB_T*)((uint32_t)pPredefMSCfg + (uint32_t)(pPredefMSCfg->usPredMstslCfgDataLen));
		}
        

		pIOOffset->bInputCount = num_of_cnxn;
		pIOOffset->bOutputCount = num_of_cnxn;

		if(DriverHelper::isSystem64bit())//add by mujy [1.5.0] for system is 64bit
		{
			offset_pnt = (TLR_UINT16*)((uint64_t)pIOOffset + 4);
		}
		else
		{
			offset_pnt = (TLR_UINT16*)((uint32_t)pIOOffset + 4);
		}

		offset_pnt[0] = 0x00;

		for (int i = 0; i < in_offset_info.size()-1; i++)//in_offset_info中元素的个数
		{
			offset_pnt[0] = offset_pnt[0] + in_offset_info[i];//#TODO
		}

		//output_offset_begin = in_offset_info.size();

		offset_pnt[1] = 0x00;

		for (int j = 0; j < out_offset_info.size()-1; j++)
			offset_pnt[1] = offset_pnt[1] + out_offset_info[j];//#TODO

		/*########################################################################*/
		//cout<<"pIOCfg[1].bDataSize==out=="<<hex<<pIOCfg[1].bDataSize<<endl;
		//cout<<"slv_cfg->COSCYCConsSz==out=="<<hex<<slv_cfg->COSCYCConsSz<<endl;
		//cout<<"offset_pnt[1]==out=="<<offset_pnt[1]<<endl;

		IOOffsetCfgLen = 2 /*pIOOffset._type_.usAddTabLen.size*/ + \
						         (pIOOffset[0].bInputCount + pIOOffset[0].bOutputCount) * 2 /*pIOOffset._type_.ausIOOffsets.size*/ + \
						         1/*pIOOffset._type_.bInputCount.size*/ + 1/*pIOOffset._type_.bOutputCount.size:*/;

		if (IOOffsetCfgLen % 4 != 0)
			pIOOffset[0].usAddTabLen = 4 * (IOOffsetCfgLen / 4) + 4;
		else
			pIOOffset[0].usAddTabLen = IOOffsetCfgLen;

		if(DriverHelper::isSystem64bit())//add by mujy [1.5.0] for system is 64bit
		{
			pSetParamCfg = (DN_EXPL_SET_ATTR_DATA_T*)((uint64_t)pIOOffset + pIOOffset[0].usAddTabLen);
		}
		else
		{
			pSetParamCfg = (DN_EXPL_SET_ATTR_DATA_T*)((uint32_t)pIOOffset + pIOOffset[0].usAddTabLen);
		}

		pRemPrm = (DN_SET_ATTR_DATA_T*)(&(pSetParamCfg[0].atSetAttrData[0]));

		pSetParamCfg[0].usAttrDataLen = 2; //# Mininum length = length of itself

		pDevParam[0].usDevParaLen = sizeof(DN_DEV_PRM_HEADER_T) + \
									pPredefMSCfg[0].usPredMstslCfgDataLen + \
									pIOOffset[0].usAddTabLen + \
									2 + //pSetParamCfg.contents.atSetAttrData._type_.usClassID.size +
									2 + //pSetParamCfg.contents.atSetAttrData._type_.usInstanceID.size +
									1 + //pSetParamCfg.contents.atSetAttrData._type_.bAttributeID.size +
									1 + //pSetParamCfg.contents.atSetAttrData._type_.bDataCnt.size +
									pSetParamCfg[0].usAttrDataLen;

		slv_cfg_req.tHead.ulLen =	2 + //len(slv_cfg_req.tData._fields_[0]) +
									2 + //len(slv_cfg_req.tData._fields_[1]) +
									pDevParam[0].usDevParaLen;

        eR = App_SendRecvPkt(hChannel, (CIFX_PACKET*)&slv_cfg_req, (CIFX_PACKET*)&slv_cfg_cnf, 1000);
//        //
        cout << "Downloading Slave Parameter. MACID = " << (slv_mac) << " . Result = " << std::hex  << eR << endl;
//        cout << "Paramter of MACID " <<(slv_mac) << " : ";
//        for (int data_idx = 0; data_idx < pDevParam[0].usDevParaLen; data_idx++)
//        {
//          cout << std::hex << std::setfill('0');
//          cout << std::setw(2) << static_cast<unsigned>(slv_cfg_req.tData.abData[data_idx]);
//          cout << " ";
//        }
//        cout << endl;
	}

	///#-------------------------DOWNLOAD DEVICE PARAMETER------------------------#
	//dnm_download_req = DN_FAL_PACKET_DOWNLOAD_REQ_T()
	dnm_download_req.tHead.ulCmd = DEVNET_FAL_CMD_DOWNLOAD_REQ;
	if(DriverHelper::isSystem64bit())//add by mujy [1.5.0] for system is 64bit
	{
		dnm_download_req.tHead.ulSrc = (TLR_UINT64)(&dnm_download_req);
	}
	else
	{
		dnm_download_req.tHead.ulSrc = (TLR_UINT32)(&dnm_download_req);
	}

	dnm_download_req.tHead.ulDest = RCX_PACKET_DEST_DEFAULT_CHANNEL;
	dnm_download_req.tHead.ulExt = RCX_PACKET_SEQ_NONE;
	dnm_download_req.tHead.ulLen = sizeof(DN_FAL_DEV_PRM_T) + 2 + 2;

	dnm_download_req.tData.usArea = DN_FAL_DOWNLOAD_AREA_DEVICE_PARAMETER;
	dnm_download_req.tData.usSubArea = 0;

	//pDevParam = cast(addressof(dnm_download_req.tData.abData), POINTER(DN_FAL_DEV_PRM_T));
	pDnmDevParam = (DN_FAL_DEV_PRM_T*)(&(dnm_download_req.tData.abData));

	if (self->ConfigFlags == None)
		pDnmDevParam[0].ulConfigFlags = 0;
	else
		pDnmDevParam[0].ulConfigFlags = self->ConfigFlags;

	if (self->EnableFlags == None)
		pDnmDevParam[0].ulEnableFlags = DN_FAL_MSK_DEV_PRM_ENABLE_VENDORID | \
										DN_FAL_MSK_DEV_PRM_ENABLE_PRODUCTTYPE | \
										DN_FAL_MSK_DEV_PRM_ENABLE_PRODUCTCODE | \
										DN_FAL_MSK_DEV_PRM_ENABLE_MAJORMINORREV | \
										DN_FAL_MSK_DEV_PRM_ENABLE_PRODUCTNAME;
	else
		pDnmDevParam[0].ulEnableFlags = self->EnableFlags;

	if (self->VendorId == None)
		pDnmDevParam[0].usVendorId = 283;
	else
		pDnmDevParam[0].usVendorId = self->VendorId;

	if (self->ProductType == None)
		pDnmDevParam[0].usProductType = 12;                   //#Communication Adapter
	else
		pDnmDevParam[0].usProductType = self->ProductType;

	if (self->ProductCode == None)
		pDnmDevParam[0].usProductCode = 41;                   //#   ?
	else
		pDnmDevParam[0].usProductCode = self->ProductCode;

	if (self->MajorRevision == None)
		pDnmDevParam[0].bMajorRev = 1;
	else
		pDnmDevParam[0].bMajorRev = self->MajorRevision;

	if (self->MinorRevision == None)
		pDnmDevParam[0].bMinorRev = 1;
	else
		pDnmDevParam[0].bMinorRev = self->MinorRevision;

	if (self->SerialNumber == None)
		pDnmDevParam[0].ulSerialNumber = 20318;
	else
		pDnmDevParam[0].ulSerialNumber = self->SerialNumber;

	if (self->ProductNameLen == None)
	{
		pDnmDevParam[0].bProductNameLen = 11;
		//assignStringToStructureField(pDnmDevParam[0].abProductName, "NETX DN/DNS") //TODO string copy strcpy
	}
	else
	{
		pDnmDevParam[0].bProductNameLen = 32;
		//pDnmDevParam[0].bProductNameLen = len(self.dnmparam.ProductName);
		//assignStringToStructureField(pDnmDevParam[0].abProductName, self.dnmparam.ProductName);
	}

	App_SendRecvPkt(hChannel, (CIFX_PACKET*)&dnm_download_req, (CIFX_PACKET*)&dnm_download_cnf, 1000);

	//#TODO: Handling error here
	/*#----------------------DOWNLOAD Server PARAMETER---------------------------#*/


	/*#-----------------------DOWNLOAD BUS PARAMETER---------------------------#*/
	bus_download_req.tHead.ulCmd = DEVNET_FAL_CMD_DOWNLOAD_REQ;
	if(DriverHelper::isSystem64bit())//add by mujy [1.5.0] for system is 64bit
	{
		bus_download_req.tHead.ulSrc = (TLR_UINT64)(&(bus_download_req));// #Just something unique
	}
	else
	{
		bus_download_req.tHead.ulSrc = (TLR_UINT32)(&(bus_download_req));// #Just something unique
	}
	
	bus_download_req.tHead.ulDest = RCX_PACKET_DEST_DEFAULT_CHANNEL;
	bus_download_req.tHead.ulExt = RCX_PACKET_SEQ_NONE;
	bus_download_req.tHead.ulLen = sizeof(DN_FAL_BUS_PRM_T) + 2 + 2;

	bus_download_req.tData.usArea = DN_FAL_DOWNLOAD_AREA_BUS_PARAMETER;
	bus_download_req.tData.usSubArea = 0;

	pBusParam = (DN_FAL_BUS_PRM_T*)(&(bus_download_req.tData.abData));


	pBusParam[0].ulSystemFlags = 0x00000001;
	pBusParam[0].ulWdgTime = 0;

       	if (self->NodeAddress == None)
	       	pBusParam[0].ulOwnMacId = 0;
       	else
	        pBusParam[0].ulOwnMacId = self->NodeAddress;

       	pBusParam[0].ulBaudrate = self->Baudrate;

	pBusParam[0].ulConfigFlags = self->ConfigFlags;

	pBusParam[0].ulEnableFlags = 0;

	App_SendRecvPkt(hChannel, (CIFX_PACKET*)&bus_download_req, (CIFX_PACKET*)&bus_download_cnf, 1000);

    /*#-----------------------start communcation---------------------------#*/

    start_stop_rep.tHead.ulCmd = RCX_START_STOP_COMM_REQ ;
	if(DriverHelper::isSystem64bit())//add by mujy [1.5.0] for system is 64bit
	{
		start_stop_rep.tHead.ulSrc = (TLR_UINT64)(&(start_stop_rep));
	}
	else
	{
		start_stop_rep.tHead.ulSrc = (TLR_UINT32)(&(start_stop_rep));
	}
    
    start_stop_rep.tHead.ulDest = RCX_PACKET_DEST_DEFAULT_CHANNEL;
	start_stop_rep.tHead.ulExt = RCX_PACKET_SEQ_NONE;
	start_stop_rep.tHead.ulLen = 4;

	start_stop_rep.tData.ulParam = 0x00000001;
	App_SendRecvPkt(hChannel, (CIFX_PACKET*)&start_stop_rep, (CIFX_PACKET*)&start_stop_cnf, 1000);

	  if (BusOn == TRUE)
    {
      lRet = xChannelBusState(hChannel, CIFX_BUS_STATE_ON, &ulState, ulTimeout);
      //printf("flag=%x\n",ulState);
      //if(CIFX_NO_ERROR != lRet)
      //{
      //	ShowError( lRet);
      //}
      }
}

void CIFXDEVNETAutoScan::networkScan(CIFXHANDLE hDnmChannel)
{
	DN_FAL_PACKET_SERVICE_REQ_T loc_srv_req;
	DN_FAL_PACKET_SERVICE_CNF_T loc_srv_cnf;

	RCX_BUSSCAN_REQ_T           req_busscan_pkt;
	//RCX_BUSSCAN_CNF_T           cnf_busscan_pkt;
  CIFX_PACKET                 cnf_busscan_pkt;

	DN_FAL_PACKET_SERVICE_REQ_T get_prod_name;
	DN_FAL_PACKET_SERVICE_CNF_T get_prod_name_cnf;

	DN_FAL_PACKET_SERVICE_REQ_T get_attr_req;
	DN_FAL_PACKET_SERVICE_CNF_T get_attr_cnf;

	DN_FAL_PACKET_SERVICE_REQ_T open_ucmm_req;
	DN_FAL_PACKET_SERVICE_CNF_T open_ucmm_cnf;

	DN_FAL_PACKET_SERVICE_REQ_T open_mslv_req;
	DN_FAL_PACKET_SERVICE_CNF_T open_mslv_cnf;

	DN_FAL_PACKET_SERVICE_REQ_T get_prodsz_req;
	DN_FAL_PACKET_SERVICE_CNF_T get_prodsz_cnf;

	DN_FAL_PACKET_SERVICE_REQ_T get_cnsmsz_req;
	DN_FAL_PACKET_SERVICE_CNF_T get_cnsmsz_cnf;

	DN_FAL_PACKET_SERVICE_REQ_T rlx_mslv_req;
	DN_FAL_PACKET_SERVICE_CNF_T rlx_mslv_cnf;

	uint8_t                     mac_id;
  int                         master_macid = 0xFF;
  uint8_t                     poll_produce_size;
  uint8_t                     poll_consume_size;

    //本地服务请求，获取单个属�?
	loc_srv_req.tHead.ulCmd = DEVNET_FAL_CMD_LOCAL_SERVICE_REQ;
	if(DriverHelper::isSystem64bit())//add by mujy [1.5.0] for system is 64bit
	{
		loc_srv_req.tHead.ulSrc = (TLR_UINT64)(&(loc_srv_req));// #Just something unique
	}
	else
	{
		loc_srv_req.tHead.ulSrc = (TLR_UINT32)(&(loc_srv_req));// #Just something unique
	}
	
	loc_srv_req.tHead.ulDest = RCX_PACKET_DEST_DEFAULT_CHANNEL;
	loc_srv_req.tHead.ulExt = RCX_PACKET_SEQ_NONE;

	loc_srv_req.tData.ubServiceCode = DEVNET_SRV_CODE_GET_ATTRIBUTE_SINGLE;
	loc_srv_req.tData.usSrvDatLen = 0x00;//                #      Attr ID.8 - bit
	loc_srv_req.tData.bDevMacId = 0x1F;  //                # Address of the dev
	loc_srv_req.tData.usClass = 0x03;    //                #   DeviceNet Object
	loc_srv_req.tData.usInstance = 0x01; //                #  Only one instance
	loc_srv_req.tData.usAttribute = 0x01;//                #             MAC ID

	loc_srv_req.tHead.ulLen =	DN_FAL_SERVICE_REQ_SIZE - \
								DN_FAL_SDU_SERVICE_MAX_DATA + \
								loc_srv_req.tData.usSrvDatLen;


App_SendRecvPkt(hDnmChannel, (CIFX_PACKET*)&loc_srv_req, (CIFX_PACKET*)&loc_srv_cnf, 1000);

    master_macid = loc_srv_cnf.tData.abSrvData[0];


	cout << "Master MAC ID = " << master_macid << endl;
	sleep(2);


	//-----------------------------------------------------------------------------------------------------------------/
	//                                          BUS SCAN REQUEST                                                       /
	//-----------------------------------------------------------------------------------------------------------------/



	req_busscan_pkt.tHead.ulCmd = RCX_BUSSCAN_REQ;
	if(DriverHelper::isSystem64bit())//add by mujy [1.5.0] for system is 64bit
	{
		req_busscan_pkt.tHead.ulSrc = (TLR_UINT64)(&(req_busscan_pkt));//           #Just something unique
	}
	else
	{
		req_busscan_pkt.tHead.ulSrc = (TLR_UINT32)(&(req_busscan_pkt));//           #Just something unique
	}
	
	req_busscan_pkt.tHead.ulDest = RCX_PACKET_DEST_DEFAULT_CHANNEL;
	req_busscan_pkt.tHead.ulExt = RCX_PACKET_SEQ_NONE;
	req_busscan_pkt.tHead.ulLen = sizeof(RCX_BUSSCAN_REQ_T) - sizeof(TLR_PACKET_HEADER_T);

	req_busscan_pkt.tData.ulAction = RCX_BUSSCAN_CMD_START;

	int lerror = App_SendRecvPkt(hDnmChannel, (CIFX_PACKET*)&req_busscan_pkt, (CIFX_PACKET*)&cnf_busscan_pkt, 1000);
	cout << "CMD_START:" << lerror << endl;
	sleep(5);

	req_busscan_pkt.tData.ulAction = RCX_BUSSCAN_CMD_STATUS;
	lerror = App_SendRecvPkt(hDnmChannel, (CIFX_PACKET*)&req_busscan_pkt, (CIFX_PACKET*)&cnf_busscan_pkt,1000);
	if (lerror != CIFX_NO_ERROR)
	{
		cout << "CMD_STATUS:" << lerror << endl;
		cout << "retry after 10s" << endl;
		sleep(10);
		lerror = App_SendRecvPkt(hDnmChannel, (CIFX_PACKET*)&req_busscan_pkt, (CIFX_PACKET*)&cnf_busscan_pkt,1000);
	}
  	sleep(2);

	TLR_UINT8 live_list[8];
    memcpy(live_list, &((RCX_BUSSCAN_CNF_T*)&cnf_busscan_pkt)->tData.abDeviceList, 8);

    string live_list_str = "";
	vector<TLR_UINT8> macid_list;

    cout << "[";
	for (int cnt = 0; cnt <8; cnt++)// in range(8)
	{
        cout << std::hex << std::setfill('0');
        cout << std::setw(2) << static_cast<unsigned>(live_list[cnt]);
        cout << " ";

		if (live_list[cnt] != 0)
		{

                  	//#base_macid = cnt / 8
			for (int i = 0; i < 8; i++)// in range(8) :
			{
				if ((live_list[cnt] >> i) & 0x01)
				{
					mac_id = (cnt % 8) * 8 + i;

					if (mac_id != 0 && mac_id != master_macid)
					{
                                              	//macid_list.append(mac_id);
						macid_list.push_back(mac_id);
					}
				}
			}
		}
	}
    cout << "]" << endl;


	vector<string> prod_name_list;

  //memset(&get_prod_name, 0x00, 1000);
	get_prod_name.tHead.ulCmd = DEVNET_FAL_CMD_REMOTE_SERVICE_REQ;  //
	if(DriverHelper::isSystem64bit())//add by mujy [1.5.0] for system is 64bit
	{
		get_prod_name.tHead.ulSrc = (TLR_UINT64)(&(get_prod_name)); //#Just something unique
	}
	else
	{
		get_prod_name.tHead.ulSrc = (TLR_UINT32)(&(get_prod_name)); //#Just something unique
	}
	
	get_prod_name.tHead.ulDest = RCX_PACKET_DEST_DEFAULT_CHANNEL;
	get_prod_name.tHead.ulExt = RCX_PACKET_SEQ_NONE;
	get_prod_name.tData.ubServiceCode = DEVNET_SRV_CODE_GET_ATTRIBUTE_SINGLE; //
	get_prod_name.tData.usSrvDatLen = 0x00;//         # Attr ID.8 - bit.Value 8 - bit
	get_prod_name.tData.bDevMacId = 0x00;//        # Address of the dev
	get_prod_name.tData.usClass = 0x01;//                   # Dummy Class
	get_prod_name.tData.usInstance = 0x01;//                   # Only one instance ?
	get_prod_name.tData.usSrvTimeOut = 1000;//                 # 200ms time out

	get_prod_name.tData.usAttribute = 0x07;
	get_prod_name.tHead.ulLen = DN_FAL_SERVICE_REQ_SIZE - DN_FAL_SDU_SERVICE_MAX_DATA + get_prod_name.tData.usSrvDatLen;


	vector<TLR_UINT8>::iterator nodeid;

	string product_name = "";

	for (nodeid = macid_list.begin(); nodeid < macid_list.end(); nodeid++)
	{
		sleep(1);

		product_name = "";

		get_prod_name.tData.bDevMacId = *nodeid;        //# Address of the dev
		App_SendRecvPkt(hDnmChannel, (CIFX_PACKET*)&get_prod_name, (CIFX_PACKET*)&get_prod_name_cnf,3000);
		cout<<"["<<endl;
                 for(int j=0; j<get_prod_name_cnf.tData.usSrvDatLen;j++)
		  {
		    cout <<get_prod_name_cnf.tData.abSrvData[j]<<",";
		  }
		 cout<<"]"<<endl;
    get_prod_name_cnf.tData.abSrvData[get_prod_name_cnf.tData.usSrvDatLen] = 0;
    product_name.append((char*)get_prod_name_cnf.tData.abSrvData);

    prod_name_list.push_back(product_name);
	}

  vector<string>::iterator it_prodname;
  cout << "[";
  for (it_prodname = prod_name_list.begin(); it_prodname < prod_name_list.end(); it_prodname++)
  {
    cout << *it_prodname<<" , ";
  }
  cout << "]" << endl;

  uint8_t cnxn_alx[] = {2,      //"POLL":
                        //4,    //"BITSTROBE" :
                        //0x10, //"COS" :
                        //0x20, //"CYC" :
                       };

  //#-------------------SEND DEVNET_FAL_CMD_REMOTE_SERVICE_REQ-----------------#
  open_ucmm_req.tHead.ulCmd = DEVNET_FAL_CMD_REMOTE_SERVICE_REQ;
  if(DriverHelper::isSystem64bit())//add by mujy [1.5.0] for system is 64bit
  {
		open_ucmm_req.tHead.ulSrc = (TLR_UINT64)(&open_ucmm_req);
  }
  else
  {
		open_ucmm_req.tHead.ulSrc = (TLR_UINT32)(&open_ucmm_req);
  }
  open_ucmm_req.tHead.ulDest = RCX_PACKET_DEST_DEFAULT_CHANNEL;
  open_ucmm_req.tHead.ulExt = RCX_PACKET_SEQ_NONE;

  open_ucmm_req.tData.ubServiceCode = DEVNET_SRV_CODE_OPEN_EXZ_CNXN;//
  open_ucmm_req.tData.usSrvDatLen = 0x02;
  open_ucmm_req.tData.bDevMacId = 0xFF;               //# Address of the dev
  open_ucmm_req.tData.usClass = 0x5;                  //# Dummy Class
  open_ucmm_req.tData.usInstance = 0xFFFF;            //# Only one instance ?
  open_ucmm_req.tData.usSrvTimeOut = 100;             //# 200ms time out
  open_ucmm_req.tData.abSrvData[0] = 0x00;            //# Allocation Choice
  open_ucmm_req.tData.abSrvData[1] = 0x30;            //# Allocator MAC ID
  open_ucmm_req.tHead.ulLen = DN_FAL_SERVICE_REQ_SIZE - DN_FAL_SDU_SERVICE_MAX_DATA + open_ucmm_req.tData.usSrvDatLen;

  //##-------------------SEND DEVNET_FAL_CMD_REMOTE_SERVICE_REQ-----------------#
  open_mslv_req.tHead.ulCmd = DEVNET_FAL_CMD_REMOTE_SERVICE_REQ;
  if(DriverHelper::isSystem64bit())//add by mujy [1.5.0] for system is 64bit
  {
		open_mslv_req.tHead.ulSrc = (TLR_UINT64)(&open_mslv_req);   //#Just something unique
  }
  else
  {
		open_mslv_req.tHead.ulSrc = (TLR_UINT32)(&open_mslv_req);   //#Just something unique
  }
  
  open_mslv_req.tHead.ulDest = RCX_PACKET_DEST_DEFAULT_CHANNEL;
  open_mslv_req.tHead.ulExt = RCX_PACKET_SEQ_NONE;

  open_mslv_req.tData.ubServiceCode = DEVNET_SRV_CODE_ALLOC_MST_SLV_CNXN;//Alloc
  open_mslv_req.tData.usSrvDatLen = 0x02;                //#Service Data Length
  open_mslv_req.tData.bDevMacId = 0xFF;                  //#Address of the dev
  open_mslv_req.tData.usClass = 0x03;                    //#DNet Class
  open_mslv_req.tData.usInstance = 0x01;                 //#Only one instance ?
  open_mslv_req.tData.usSrvTimeOut = 200;                //#2000ms time out

  open_mslv_req.tData.abSrvData[0] = 0x01;               //#Allocation Choice
  open_mslv_req.tData.abSrvData[1] = master_macid;       //#Allocator MAC ID

  open_mslv_req.tHead.ulLen = DN_FAL_SERVICE_REQ_SIZE - DN_FAL_SDU_SERVICE_MAX_DATA + open_mslv_req.tData.usSrvDatLen;


  //#-------------------SEND DEVNET_FAL_CMD_REMOTE_SERVICE_REQ-----------------#
  get_prodsz_req.tHead.ulCmd = DEVNET_FAL_CMD_REMOTE_SERVICE_REQ;
  if(DriverHelper::isSystem64bit())//add by mujy [1.5.0] for system is 64bit
  {
		get_prodsz_req.tHead.ulSrc = (TLR_UINT64)(&get_prodsz_req);// #Just something unique
  }
  else
  {
		get_prodsz_req.tHead.ulSrc = (TLR_UINT32)(&get_prodsz_req);// #Just something unique
  }
  
  get_prodsz_req.tHead.ulDest = RCX_PACKET_DEST_DEFAULT_CHANNEL;
  get_prodsz_req.tHead.ulExt = RCX_PACKET_SEQ_NONE;

  get_prodsz_req.tData.ubServiceCode = DEVNET_SRV_CODE_GET_ATTRIBUTE_SINGLE;
  get_prodsz_req.tData.usSrvDatLen = 0x00;         //# Attr ID.8 - bit.Value 8 - bit
  get_prodsz_req.tData.bDevMacId = 0xFF;           //# Address of the dev
  get_prodsz_req.tData.usClass = 0x05;             //# Dummy Class
  get_prodsz_req.tData.usInstance = 0x02;          //# Only one instance ?
  get_prodsz_req.tData.usSrvTimeOut = 200;         //# 200ms time out
  get_prodsz_req.tData.usAttribute = 0x07;         //# Expected Pkt Rate
  get_prodsz_req.tHead.ulLen = DN_FAL_SERVICE_REQ_SIZE - DN_FAL_SDU_SERVICE_MAX_DATA + get_prodsz_req.tData.usSrvDatLen;


  //#-------------------SEND DEVNET_FAL_CMD_REMOTE_SERVICE_REQ-----------------#
  get_cnsmsz_req.tHead.ulCmd = DEVNET_FAL_CMD_REMOTE_SERVICE_REQ;
  if(DriverHelper::isSystem64bit())//add by mujy [1.5.0] for system is 64bit
  {
		get_cnsmsz_req.tHead.ulSrc = (TLR_UINT64)(&get_cnsmsz_req);  //#Just something unique
  }
  else
  {
		get_cnsmsz_req.tHead.ulSrc = (TLR_UINT32)(&get_cnsmsz_req);  //#Just something unique	
  }
  
  get_cnsmsz_req.tHead.ulDest = RCX_PACKET_DEST_DEFAULT_CHANNEL;
  get_cnsmsz_req.tHead.ulExt = RCX_PACKET_SEQ_NONE;

  get_cnsmsz_req.tData.ubServiceCode = DEVNET_SRV_CODE_GET_ATTRIBUTE_SINGLE;
  get_cnsmsz_req.tData.usSrvDatLen = 0x00;      //# Attr ID.8 - bit.Value 8 - bit
  get_cnsmsz_req.tData.bDevMacId = 0xFF;        //# Address of the dev
  get_cnsmsz_req.tData.usClass = 0x05;          //# Dummy Class
  get_cnsmsz_req.tData.usInstance = 0x02;       //# Only one instance ?
  get_cnsmsz_req.tData.usSrvTimeOut = 200;      //# 200ms time out
  get_cnsmsz_req.tData.usAttribute = 0x08;      //# Expected Pkt Rate
  get_cnsmsz_req.tHead.ulLen = DN_FAL_SERVICE_REQ_SIZE - DN_FAL_SDU_SERVICE_MAX_DATA + get_cnsmsz_req.tData.usSrvDatLen;

  //#-------------------SEND DEVNET_FAL_CMD_REMOTE_SERVICE_REQ-----------------#
  rlx_mslv_req.tHead.ulCmd = DEVNET_FAL_CMD_REMOTE_SERVICE_REQ;
  if(DriverHelper::isSystem64bit())//add by mujy [1.5.0] for system is 64bit
  {
		rlx_mslv_req.tHead.ulSrc = (TLR_UINT64)(&rlx_mslv_req);// #Just something unique
  }
  else
  {
		rlx_mslv_req.tHead.ulSrc = (TLR_UINT32)(&rlx_mslv_req);// #Just something unique
  }
  rlx_mslv_req.tHead.ulDest = RCX_PACKET_DEST_DEFAULT_CHANNEL;
  rlx_mslv_req.tHead.ulExt = RCX_PACKET_SEQ_NONE;

  rlx_mslv_req.tData.ubServiceCode = DEVNET_SRV_CODE_RELEASE_MST_SLV_CNXN;
  rlx_mslv_req.tData.usSrvDatLen = 0x01;         //# Attr ID.8 - bit.Value 8 - bit
  rlx_mslv_req.tData.bDevMacId = 0x1F;           //# Address of the dev
  rlx_mslv_req.tData.usClass = 0x03;             //# Dummy Class
  rlx_mslv_req.tData.usInstance = 0x01;          //# Only one instance ?
  rlx_mslv_req.tData.usSrvTimeOut = 200;         //# 200ms time out
  rlx_mslv_req.tData.abSrvData[0] = 0x02;        //#Allocation Choice
  rlx_mslv_req.tHead.ulLen = DN_FAL_SERVICE_REQ_SIZE - DN_FAL_SDU_SERVICE_MAX_DATA + rlx_mslv_req.tData.usSrvDatLen;


  vector<TLR_UINT8>::iterator slave_id;

  int i = 0;
  uint8_t alx = 0x00; //allocation choice
  //maxm added
  	int nMacID = 0;
	int nOutputOffSet = 0;
	int nOutputSize = 0;
	int nInputOffSet = 0;
	int nInputSize = 0;
  	int nSumOutputSize = 0;
    int nSumnInputSize = 0;

  for (slave_id = macid_list.begin(); slave_id < macid_list.end(); slave_id++)
  {
    cout << "===================================================== "<< endl;
    printf("MACID = %d\n",*slave_id);
    cout<<"EDS = "<<prod_name_list[i]<<endl;

    open_ucmm_req.tData.bDevMacId = *slave_id;
    App_SendRecvPkt(hDnmChannel, (CIFX_PACKET*)&open_ucmm_req, (CIFX_PACKET*)&open_ucmm_cnf, 2500);

    //alx = cnxn_alx["POLL"]
    alx = cnxn_alx[0]; //POLL

    open_mslv_req.tData.bDevMacId = *slave_id;
    open_mslv_req.tData.abSrvData[0] = 0x01;          //#Allocation Choice
    App_SendRecvPkt(hDnmChannel, (CIFX_PACKET*)&open_mslv_req, (CIFX_PACKET*)&open_mslv_cnf, 500);


    open_mslv_req.tData.abSrvData[0] = alx;//          #Allocation Choice
    App_SendRecvPkt(hDnmChannel, (CIFX_PACKET*)&open_mslv_req, (CIFX_PACKET*)&open_mslv_cnf, 500);

    get_prodsz_req.tData.bDevMacId = *slave_id;
    get_prodsz_req.tData.usInstance = 2;
    App_SendRecvPkt(hDnmChannel, (CIFX_PACKET*)&get_prodsz_req, (CIFX_PACKET*)&get_prodsz_cnf, 200);
    poll_produce_size = *((TLR_UINT16*)get_prodsz_cnf.tData.abSrvData);

    get_cnsmsz_req.tData.bDevMacId = *slave_id;
    get_cnsmsz_req.tData.usInstance = 2;
    App_SendRecvPkt(hDnmChannel, (CIFX_PACKET*)&get_cnsmsz_req, (CIFX_PACKET*)&get_cnsmsz_cnf, 200);
    poll_consume_size = *((TLR_UINT16*)get_cnsmsz_cnf.tData.abSrvData);

    printf("POLL Input Length = %d, POLL Output Length = %d\n",poll_consume_size,poll_produce_size);

    rlx_mslv_req.tData.abSrvData[0] = alx;//                 #Allocation Choice
    rlx_mslv_req.tData.bDevMacId = *slave_id;
    App_SendRecvPkt(hDnmChannel, (CIFX_PACKET*)&rlx_mslv_req, (CIFX_PACKET*)&rlx_mslv_cnf, 200);
    printf("slave_id=%x\n",*slave_id);
    //Save slave parameter for later downloading.
    tDnmParam.slaves[*slave_id].Activated = true;
    tDnmParam.slaves[*slave_id].Poll = true;
    tDnmParam.slaves[*slave_id].ConsumedSize = poll_consume_size;
    tDnmParam.slaves[*slave_id].ProducedSize = poll_produce_size;
    tDnmParam.slaves[*slave_id].PollERP = 2000;
    //maxm
    DevicesList[*slave_id] = new DNS_DEVICE_CFG;

  	 nSumOutputSize =nSumOutputSize+poll_consume_size;
  	 nSumnInputSize =nSumnInputSize+poll_produce_size;

	nOutputOffSet = nSumOutputSize-poll_consume_size;
    nInputOffSet = nSumnInputSize-poll_produce_size;

	(*DevicesList[*slave_id]).MacId = *slave_id;
	(*DevicesList[*slave_id]).Output1Offset = nOutputOffSet;
	(*DevicesList[*slave_id]).Output1Size = poll_consume_size;
	(*DevicesList[*slave_id]).Input1Offset = nInputOffSet;
	(*DevicesList[*slave_id]).Input1Size = poll_produce_size;

	cout <<"(*DevicesList[*slave_id]).MacId==============" <<dec<<(*DevicesList[*slave_id]).MacId << endl;
	cout <<"(*DevicesList[*slave_id]).Output1Offset=========" <<dec<<(*DevicesList[*slave_id]).Output1Offset << endl;
	cout <<"(*DevicesList[*slave_id]).Output1Size==========="<<dec<<(*DevicesList[*slave_id]).Output1Size << endl;
	cout <<"(*DevicesList[*slave_id]).Input1Offset=========" <<dec<<(*DevicesList[*slave_id]).Input1Offset << endl;
	cout <<"(*DevicesList[*slave_id]).Input1Size===========" <<dec<<(*DevicesList[*slave_id]).Input1Size << endl;
//	cout<<"maxm added "<<tDnmParam.slaves[*slave_id].PollERP<<endl;
    i += 1;
	usleep(200);
  }

  cout << "=====================================================" << endl;

}
