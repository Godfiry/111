/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MKSDualMatch.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-11-17   LiJuanjuan create
**      
*********************************************************************/
#ifndef MKSDUALMATCH_H_
#define MKSDUALMATCH_H_

#include "MKSMatch.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#include "DescriptorList.h"
#include "StringTypeInfo.h"
#include <map>
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class MKSDualMatch:public MKSMatch
{
	DECLARE_DYNAMIC(MKSDualMatch)	
	DECLARE_MSG_MAP	
	private:
		typedef struct
		{
			int m_ps;
			std::string m_s1;
			int m_ps2;
		}Com;
		
		static Com m_commands[];	   
	
	protected:
		void initChs(DeviceNode<MKSDualMatch> *node);
		void initDevice();
	
	public:
		MKSDualMatch();
		virtual ~MKSDualMatch();
		
		bool writeInt(int channelNum, int value, const IntTypeInfo &typeInfo);
		bool writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo);
		bool writeRawCommand(int channelNum, std::string value, const StringTypeInfo &typeInfo);
		bool readInt(int channelNum, int *value, const IntTypeInfo &typeInfo);
		bool readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo);		
		
		void init();		
};

#endif /*MKSDUALMATCH_H_*/
