/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MKSFRC.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-12-02   LiJuanjuan create
**      
*********************************************************************/
#ifndef MKSFRC_H_
#define MKSFRC_H_

#include "IODevice.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#include "DeviceNode.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class MKSFRC:public IODevice
{
	DECLARE_DYNAMIC(MKSFRC)	
	DECLARE_MSG_MAP	
	
	private:
		int m_outputByte;
		int m_inputByte;
		int m_scale;

	protected:
		virtual void initChs(DeviceNode<MKSFRC> *node);
		virtual void initDevice();
						
	public:
		MKSFRC();
		virtual ~MKSFRC();
		
		bool writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo);
		bool readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo);
		bool writeInt(int channelNum, int value, const IntTypeInfo &typeInfo);
		virtual void init();
		void setScale(int scale);
};

#endif /*MKSFRC_H_*/
