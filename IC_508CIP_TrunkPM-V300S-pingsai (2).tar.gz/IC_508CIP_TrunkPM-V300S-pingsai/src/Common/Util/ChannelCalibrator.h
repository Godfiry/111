/********************************************************************
** Copyright (c) 2020, Beijing NAURA Co.,Ltd.  All rights reserved.
** File name: ChannelCalibrator.h
** Description: 
** Release: 1.1
** Modification history: 
** 					2020-2-19   chenmz create
*********************************************************************/
#ifndef CHANNELCALIBRATOR_H_
#define CHANNELCALIBRATOR_H_

#include <iostream>
#include "CmdTarget.h"
#include "UntypedData.h"
#include "ReadOnlyDouble.h"
#include "CalibrateExecuterInterface.h"
#include "Subscriber.h"
#include "ReadWriteInt.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
#endif
using namespace std;

class ChannelCalibrator : public CmdTarget , public Subscriber
{
	DECLARE_DYNAMIC(ChannelCalibrator)
	DECLARE_MSG_MAP

public:
	ChannelCalibrator();
	virtual ~ChannelCalibrator();
	
public://override	
	virtual void startup();
	virtual void update(UntypedData *pData, const ValueInfo &value);
	virtual void verifyInit();

public://xml
	void setCalibrationFlag(const std::string &strPath);
	void setCalibrateChannel(const std::string &strPrePath,const std::string &strAfterPath);
	void setCalibrateExecuter(const std::string &strPath);
	
protected:
	bool checkCalibration();	
	
private:
	ReadOnlyDouble *m_pPreCalibrateCh;
	ReadOnlyDouble *m_pAfterCalibrateCh;
	ReadWriteInt *m_pCalibrationFlag;
	CalibrateExecuterInterface *m_pCalibrateExecuter;	
};

#endif /*CHANNELCALIBRATOR_H_*/
