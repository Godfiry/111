/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					Jan 22, 2008  shenql  create 
**      
***************************************************************************/
#ifndef INTERRUPTRCPSTEPINFO_H_
#define INTERRUPTRCPSTEPINFO_H_

#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class InterruptRcpStepInfo:public IntValueInfo
{
	public:
		static const int Continue = 0;
		static const int Cancel = 1;
		static const int Pause = 2;		
		static const IntTypeInfo typeInfo;
		
		InterruptRcpStepInfo():IntValueInfo(-1, typeInfo)
		{}
		
		InterruptRcpStepInfo(int i):IntValueInfo(i, typeInfo)
		{}
		
		InterruptRcpStepInfo(const std::string &s):IntValueInfo(s, typeInfo)
		{}
};
#endif /*INTERRUPTRCPSTEPINFO_H_*/
