/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					Jan 22, 2008  shenql  create 
**      
***************************************************************************/
#ifndef PMSTATUSINFO_H_
#define PMSTATUSINFO_H_
class PMStatusInfo : public IntValueInfo
{
public:

		static const int UnInit = -1;
		static const int Unknown = 0;
		static const int Preparing = 1;
		static const int Prepared = 2;
		static const int Processing = 3;
		static const int Processed = 4;
		static const int Paused = 5;
		static const int Aborted = 6;
		static const int BadWfr = 7;
		static const IntTypeInfo typeInfo;

	   PMStatusInfo():IntValueInfo(-1, typeInfo)
	   {
	   }
	
	   PMStatusInfo(int i):IntValueInfo(i, typeInfo)
	    {
	    }
	
	   PMStatusInfo(std::string s):IntValueInfo(s, typeInfo)
	    {
	    }
};


#endif/*PMSTATUSINFO_H_*/
