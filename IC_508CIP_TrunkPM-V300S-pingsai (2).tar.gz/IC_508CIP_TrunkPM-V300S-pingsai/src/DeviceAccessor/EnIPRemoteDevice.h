/********************************************************************
** Copyright (c) 2019 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: EnIPRemoteDevice.h
** Description:  connection
** Release: 1.0
** Modification history:           
** 					2019-08-30   Duq create
**                                                 2020-06-03   Duq update 
*********************************************************************/

#ifndef ENIPREMOTEDEVICE_H_
#define ENIPREMOTEDEVICE_H_

#include "Enums.h"
#include "EnIPBase.h"
#include "EnIPTransport.h"
#include "IThread.h"
#include "IMutex.h"
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

class EnIPRemoteDevice: public IThread
{
	public:
		//assembly object classId=4  assembly object data AttributId=3
		uint16_t m_classID;
		uint16_t m_attributID;
		uint16_t m_configInstanceID;
		uint16_t m_inputInstanceID;//T2O
		uint16_t m_outputInstanceID;//O2T
		uint16_t m_inputDataSize;//T2O
		uint16_t m_outputDataSize;//O2T
		uint16_t m_inputPocketSize;//T2O
		uint16_t m_outputPocketSize;//O2T
		unsigned int m_inputConnectionId;//T2O
		unsigned int m_outputConnectionId;//O2T
		char* m_inputBuffer;//T2O
		char* m_outputBuffer;//O2T
		std::string m_inputEPath;//T2O EPath
		std::string m_outputEPath;//O2T EPath
		EnIPNetworkStatus m_status;
		unsigned int m_SequenceNumber;
		
		unsigned short m_EncapsulationVersion;
		unsigned short m_VendorId;
		unsigned short m_DeviceType;
		unsigned short m_ProductCode;
		unsigned int m_SerialNumber;
		std::string m_ProductName;
		unsigned int m_SessionHandle;
		
		EnIPTCPClientTransport* m_Tcpclient;
		EnIPUDPClientTransport* m_Udpclient;
		ForwardClose_Packet* m_closePkt;
		ForwardOpen_Packet* m_openPkt;
		ForwardOpen_Config* m_config;
		std::string m_serverIP;

		bool m_running;
		bool m_runningstatus;
		bool m_result;
		IMutex m_readlock;
		IMutex m_writelock;
		unsigned int m_cycleTime;
		
	public:
		EnIPRemoteDevice(uint16_t configIid, uint16_t inputIid, uint16_t outputIid, std::string &service);
		virtual ~EnIPRemoteDevice();
		
		bool isConnected();//m_Tcpclient connected status
		bool do_RegisterSession();
		void do_UnRegisterSession();
		bool do_ForwardClose();
		bool do_ForwardOpen(unsigned int cycleTime);
		std::string GetForwardOpenPath();
		
		EnIPNetworkStatus SendUCMM_RR_Packet(std::string &DataPath, CIPServiceCodes Service, std::string &data, int &Offset, std::string &Packet);

		virtual bool do_WriteClass1Data(); //Attribut write class1 connection data -- class1 UDP
		virtual bool do_ReadClass1Data(char * data, int len); //Attribut read class1 connection data -- class1 UDP
		bool do_GetDataSize();//get object data byte size
		bool getBytesInputsData(int offset, int len, void *value); // get inputs attribut (offset ~ offset + len -1)th byte data
		bool setBytesOutputsData(int offset, int len, void *value, bool flag); // set value to outputs attribut (offset ~ offset + len -1)th byte data
		virtual void run();
};

#endif  /*ENIPREMOTEDEVICE_H_*/
