/*
 * FOTEKTempCtl.h
 *
 *  Created on: 2024��5��14��
 *      Author: chenshicun
 */

#ifndef SRC_DEVICEACCESSOR_FOTEKTEMPCTL_H_
#define SRC_DEVICEACCESSOR_FOTEKTEMPCTL_H_
#include <string>
#include "SerialDevice.h"
#include "ControlObject.h"
#include "ReadWriteInt.h"
#include "ReadOnlyInt.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#include "DeviceNode.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CONTROL;
using namespace IAP::IO;
#endif

class FOTEKTempCtl : public SerialDevice
{
	DECLARE_DYNAMIC(FOTEKTempCtl)
	DECLARE_MSG_MAP

	public:
		FOTEKTempCtl();
		virtual ~FOTEKTempCtl();

		bool readDouble(int nChannelNum, double *pValue,const DoubleTypeInfo &typeInfo);

		//bool writeInt(int nChannelNum, int Value,const IntTypeInfo &typeInfo);
		void setStartReadTempIndex(int index);


		void init();

		virtual std::string getDeviceName();

	protected:
		std::string readCommand(std::string strCommand, int ntimeOut);
	    void initDevice();
	    void initChs(DeviceNode<FOTEKTempCtl>* pNode);

	private:
	    int m_timeOut;
		int m_resLen;

	    char m_readCmd[9];   //read command array
	    static const int RESP_LEN = 80;//the buff length
	    std::map<int,std::string> m_strCmd;
	    int m_nStartReadTempIndex;

};


#endif /* SRC_DEVICEACCESSOR_FOTEKTEMPCTL_H_ */
