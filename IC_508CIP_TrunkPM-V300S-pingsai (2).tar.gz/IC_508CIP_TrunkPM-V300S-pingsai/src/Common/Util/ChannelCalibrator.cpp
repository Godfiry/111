/********************************************************************
** Copyright (c) 2020, Beijing NAURA Co.,Ltd.  All rights reserved.
** File name: ChannelCalibrator.h
** Description: 
** Release: 1.1
** Modification history: 
** 					2020-2-19   chenmz create
*********************************************************************/
#include "ChannelCalibrator.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "InvalidNameException.h"
#endif
#include "ConfigException.h"
#include "ObjectManager.h"
#include "SysLogger.h"
#include "XmlGetter.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP;
using namespace IAP::CORE;
using namespace IAP::IO;
#endif
using namespace std;

ChannelCalibrator::ChannelCalibrator():Subscriber(IO::UNKNOWN)
{
	m_pPreCalibrateCh = NULL;
	m_pAfterCalibrateCh = NULL;
	m_pCalibrateExecuter = NULL;
	m_pCalibrationFlag = NULL;
}

ChannelCalibrator::~ChannelCalibrator()
{
}

void ChannelCalibrator::startup()
{
	CmdTarget::startup();
	m_pPreCalibrateCh->subscribe(this);
}

void ChannelCalibrator::verifyInit()
{
	CmdTarget::verifyInit();
	if(checkCalibration())
	{
		cout<<"----------------------------------"<<endl;
		cout<<"Software with Calibrator"<<endl;
		bool bFlag = true;
		string strError = "";
		if(m_pPreCalibrateCh==NULL)
		{
			bFlag = false;
			strError = "The PreCalibrate channel is not matched!";
		}
		if(m_pAfterCalibrateCh==NULL)
		{
			bFlag = false;
			strError = "The AfterCalibrate channel is not matched!";
		}
		if(m_pCalibrateExecuter==NULL)
		{
			bFlag = false;
			strError = "The CalibrateExecuter is not matched!";
		}
		if(!bFlag)
		{
			strError += "Please check!!!";
			throw ConfigException(strError);
		}
		cout<<"----------------------------------"<<endl;
	}
}

void ChannelCalibrator::update(UntypedData *pData, const ValueInfo &value)
{
	if(pData == m_pPreCalibrateCh)
	{
		double dTemp = ((DoubleValueInfo&)value).getValue();
		double dResult = dTemp;
		if(checkCalibration())
		{
			dResult = m_pCalibrateExecuter->Calibrate(dTemp);	
		}
		try
		{
			m_pAfterCalibrateCh->setSimulatedValue(dResult);
		}
		catch(exception &ex)
		{
			m_pAfterCalibrateCh->setSimulatedValue(dTemp);
		}
	}
}

bool ChannelCalibrator::checkCalibration()
{
	bool bCalibrationFlag = true;
	if(m_pCalibrationFlag != NULL)
	{
		if(m_pCalibrationFlag->getValue() == 1)//open 
		{
			bCalibrationFlag = true;
		}
		else //close
		{
			bCalibrationFlag = false;
		}
	}
	return bCalibrationFlag;
}

void ChannelCalibrator::setCalibrationFlag(const std::string &strPath)
{
	ReadWriteInt *pObj = XmlGetter::getFromNamespace<ReadWriteInt*>(strPath);
	m_pCalibrationFlag = pObj;	
}

void ChannelCalibrator::setCalibrateChannel(const std::string &strPrePath,const std::string &strAfterPath)
{
	ReadOnlyDouble * pPreCh = XmlGetter::getFromNamespace<ReadOnlyDouble*>(strPrePath);
	m_pPreCalibrateCh = pPreCh;	
	ReadOnlyDouble * pAfterCh = XmlGetter::getFromNamespace<ReadOnlyDouble*>(strAfterPath);
	m_pAfterCalibrateCh = pAfterCh;
}

void ChannelCalibrator::setCalibrateExecuter(const std::string &strPath)
{
	ManagedObject *pObj = NULL;
	try
	{
		pObj = ObjectManager::getInstance()->getObject(this, strPath);
	}
	catch(const InvalidNameException &ex)
	{
		pObj = ObjectManager::getInstance()->getObject(strPath);	
		if(pObj==NULL)
		{
			string strError = getSelfName() + " setCalibrateExecuter path error. [ " + strPath + " ] is not existed. ";
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, strError );	
			throw ConfigException(strError);
		}
	}
	CalibrateExecuterInterface *pObj2 = dynamic_cast<CalibrateExecuterInterface*>(pObj);
	if(NULL == pObj2)
	{
		string strError = getSelfName() + " setCalibrateExecuter data  is not a CalibrateExecuterInterface.[ " + strPath + " ] is not existed. ";
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, strError );	
		throw ConfigException(strError);
	}
	m_pCalibrateExecuter = pObj2;
}

IMPLEMENT_DYNAMIC(ChannelCalibrator,CmdTarget )

BEGIN_MSG_MAP(ChannelCalibrator,CmdTarget)
	SET_S(setCalibrationFlag, ChannelCalibrator)
	SET_SS(setCalibrateChannel,ChannelCalibrator )
	SET_S(setCalibrateExecuter,ChannelCalibrator )
END_MSG_MAP
