/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: ATSChiller.cpp
** Description:
** Release: 1.1
** Modification history:
** 					2021-12-03   wzd create
*********************************************************************/
#ifndef GmpowerLFMN6MatchDriver_H_
#define GmpowerLFMN6MatchDriver_H_

#include <string>
#include "SerialDevice.h"
#include "ControlObject.h"
#include "ReadWriteInt.h"
#include "ReadOnlyInt.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#include "DeviceNode.h"
#ifdef IAP4_0
using namespace IAP::CONTROL;
using namespace IAP::IO;
#endif

using namespace std;



class GmpowerLFMN6MatchDriver : public SerialDevice
{
	DECLARE_DYNAMIC(GmpowerLFMN6MatchDriver)
	DECLARE_MSG_MAP

private:

	char m_writeCmd[8];	//write command array
	char m_readCmd[8];   //read command array
	
	static const int RESP_LEN = 80;//the buff length

protected:

	void initChs(DeviceNode<GmpowerLFMN6MatchDriver> *node);//inint channel
	void initDevice();

public:
	GmpowerLFMN6MatchDriver();
	virtual ~GmpowerLFMN6MatchDriver();
	void init();  //init the device
	bool writeInt(const int nChannelNum, const int nWriteValue, const IntTypeInfo& typeinfo);
	bool readInt(const int nChannelNum, int * pValue ,const IntTypeInfo& typeinfo);
	bool readDouble(const int channnelNum,double * value ,const DoubleTypeInfo& typeinfo);
	virtual std::string getDeviceName();
};

#endif /* GmpowerLFMN6MatchDriver_H_ */
