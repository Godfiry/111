/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MKSSingleMatch.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2017-06-23   XiaSC create
**      
*********************************************************************/
#ifndef MKSPULSESINGLEMATCH_H_
#define MKSPULSESINGLEMATCH_H_

#include "SerialDevice.h"
#include "DeviceNode.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class MKSPulseSingleMatch :public SerialDevice
{

    DECLARE_DYNAMIC(MKSPulseSingleMatch)	
    DECLARE_MSG_MAP
    
    private:
    
    typedef struct
	{
		int m_address;
		int m_p1;
	}Address;
	
	
	static Address m_addInfo[];
	int m_resLen;	
	char m_writeCmd[11];	//writeInt command array	
	char m_readCmd[8];   //read command array
	
	static const int RESP_LEN = 80;//the buff length
	//calculate the CRC and get it
	unsigned short GetCRC16Code(char *cCommand, int nLen);
	

protected:
	bool sendCommand(char *command, int timeOut, int len);
	int readCommand(char *command, int timeOut, int len);
	void initChs(DeviceNode<MKSPulseSingleMatch> *node);//inint channel
	void initDevice();
	
public:
	MKSPulseSingleMatch();
	virtual ~MKSPulseSingleMatch();
	void init();  //init the device 

	bool writeDouble(int channnelNum,double setvalue ,const DoubleTypeInfo& typeinfo);
	bool readDouble(int channnelNum,double * value ,const DoubleTypeInfo& typeinfo);
	bool readInt(int channelNum, int *value, const IntTypeInfo &typeInfo);
	bool writeInt(int channelNum, int value, const IntTypeInfo &typeInfo);
	bool writePosition(int channelNum, int value, const IntTypeInfo &typeInfo);
	bool readPosition(int channelNum, int *value, const IntTypeInfo &typeInfo);

};

#endif /*MKSPULSESINGLEMATCH_H_*/
