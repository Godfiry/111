/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AEDualMatchFastEDriver.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					20220501   SONGPAN create
**      
*********************************************************************/

#include "AEDualMatchFastEDriver.h"
#include <string.h>
#include "DeviceManager.h"
#include <iostream>
#include <sys/time.h>
#include <sstream>
#include "Converter.h"
#include <cmath>
#include "SysLogger.h"
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std;

AEDualMatchFastEDriver::AEDualMatchFastEDriver():SerialDevice(100,"")
{
    ack[0] = (char)0x06;
    addr = 1;
	m_preC1 = 0;
	m_preC2 = 0;
} 

AEDualMatchFastEDriver::~AEDualMatchFastEDriver()
{
}
AEDualMatchFastEDriver::Com AEDualMatchFastEDriver::m_commands[] =   
						{ {0, 0, 0 },   // 0 reserved
						{7, 0x5D, 4},   // 1 set Control Mode (0x5D == 93)
						{7, 0x70, 4},   // 2 set C1 position (112)
						{7, 0x7A, 4},   // 3 set C2 position (122)	
						{12, 0x5C, 4},  // 4 store C1&C2 preset (92)	
						{7, 0x5B, 4},   // 5 recall C1&C2 preset (91)
													
						{5, 0xA3, 7},   // 6 read Control Mode (163)
						{5, 0xB4, 9},	// 7 read C1 (180)	
						{5, 0xB4, 9},	// 8 read C2 (180)	
						{7, 0xF8, 88},	// 9 read VDC (248-206)*

						{7, 0xF8, 88},	// 10 read I-out (248-206)
						{7, 0xF8, 88},	// 11 read V-out (248-206)
						{7, 0xF8, 88},	// 12 read R     (248-206)
						{7, 0xF8, 88},	// 13 read X	 (248-206)
						{7, 0xF8, 88},	// 14 read Phase (248-206)
	
						{3, 0x7D, 4},   // 15 set Reset (125)
						{16, 0x76, 4},  // 16 set Prior Time(118-209)
						{7, 0xF8, 12},   // 17 read Prior Time
						{7, 0x5E, 4},   // 18 enable/disable presets
						{5, 0xA4, 7},   // 19 read enable/disable presets
						{4, 0xDF, 44},
						{3, 0xDB, 92},//21 READ THE MOST VALUE
						{3,0xA2,9},  // 22 read TempStatus(OverHeat)
						{3,0xA2,9},  // 23 read interlock
						{3,0xA2,9}  // 24 read FanError
                        }; 
                                                                                        

bool AEDualMatchFastEDriver::sendCommand(char *msg, char *response, int msg_timeout,int length)
{
     string s1=std::string(msg,20);
     //cout<<"send command: "<<s1<<endl;
     string s2=getCommandResult(s1,m_timeOut);
     
     strcpy(response,s2.c_str());
	if(response[0] != 0x06)
	{
        //cout<<"sendCommand response noAck "<<hex<<(int)response[0]<<" "<<(int)response[1]<<" "<<(int)response[2]<<" "<<(int)response[3]<<" "<<(int)response[4]<<endl;		
	    throw IOException("Send packet's verification is wrong");
	}
	else if(response[3] != 0x00)
	{     
        //cout<<"sendCommand response noCSR0 "<<hex<<(int)response[0]<<" "<<(int)response[1]<<" "<<(int)response[2]<<" "<<(int)response[3]<<" "<<(int)response[4]<<endl;
        throw IOException("Response(CSR) codes was not accepted");  
	}
   return true;
}

bool AEDualMatchFastEDriver::sendCommandAck(char *msg, char *response, int msg_timeout,int resplen, int msglen)
{
	int ret = getCommandResult(msg, msglen, response, resplen, m_timeOut);
    
	if(response[0] != 0x06 || ret <= 0)
	{
       //cout<<"sendCommand response "<<hex<<(int)response[0]<<" "<<(int)response[1]<<" "<<(int)response[2]<<" "<<(int)response[3]<<" "<<(int)response[4]<<endl;		
	    throw IOException("Send packet's verification is wrong");
	}
	else if(response[3] != 0x00)
	{     
        //cout<<"sendCommand response "<<hex<<(int)response[0]<<" "<<(int)response[1]<<" "<<(int)response[2]<<" "<<(int)response[3]<<" "<<(int)response[4]<<endl;
		string serr = "Response(CSR) codes was not accepted, CSR is ";
		serr += Converter::convertToString((int)response[3]);
	 	throw IOException(serr);  
	}
   sendCommandOnly(ack,1); 
   return true;
}
bool AEDualMatchFastEDriver::readCommand(char *msg, char *response, int msg_timeout,int resplen, int msglen)
{	
	getFixCommandResult(msg, msglen, response, resplen, m_timeOut, 2);
   
	if(response[0] != 0x06 )
	{		
		throw IOException("Send packet's verification is wrong");
	}
    sendCommandOnly(ack,1);
    return true;
}

bool AEDualMatchFastEDriver::writeInt(int channelNum, int value, const IntTypeInfo &typeInfo)
{
	if(2 == channelNum || 22 == channelNum)
		m_preC1 = value;
	if(3 == channelNum || 23 == channelNum)
		m_preC2 = value;
	if(4 == channelNum || 24 == channelNum)
		value = (m_preC1*1000 + m_preC2) * 100 + value;   //store c1 and c2 to Position value
	
	
	memset(message, 0, MESS_LEN);
  	memset(resp, 0, RESP_LEN);
	Com com;
	if(channelNum > 20)
	{
		selectNetWork(1);
		com = m_commands[channelNum-20];
	}
	else
	{
		selectNetWork(0);
		com = m_commands[channelNum];
	}
	message[0] = (char)(com.m_type-3+8*addr); // 5 == -3 + 00001000_bin
	message[1] = com.m_cmd;
	int tempint;
	switch(com.m_type)
	{
		case 3: // reset
			message[2] = message[0]^message[1];
			break;
			
       	case 7:   
	  	     if (com.m_cmd == (char)0x5E)// set enable/disable presets
			 {
				//message[2] = 0x01;
				message[3] = 0x00;
				message[4] = (int)value&0xff;  
				message[5] = 0x00;
				message[6] = message[0]^message[1]^message[2]^message[3]^message[4]^message[5];
			 }
			 else
			 {
				 if(com.m_cmd == (char)0x5D)  //set mode
				 {
					// message[2] = 0x01;
					 message[3] = 0x00;
					 message[4] = (int)(value*(-1)+2)&0xff;
					 message[5] = 0x00;
					 message[6] = message[0]^message[1]^message[2]^message[3]^message[4]^message[5];
				 }
				 if (com.m_cmd == (char)0x5B) // recall preset
				 {
					// message[2] = 0x01;
					 message[3] = 0x00;
					 message[4] = (int)value&0xff;  
					 message[5] = 0x00;
					 message[6] = message[0]^message[1]^message[2]^message[3]^message[4]^message[5];
				 }

				 if (com.m_cmd == (char)0x70 || com.m_cmd == (char)0x7A ) // set C1 or C2 position
				 {
					//message[2] = 0x01;
					 message[3] = 0x00;
					 tempint = value*10;
					 message[4] = tempint&0xff;
					 message[5] = (tempint>>8)&0xff;
					 message[6] = message[0]^message[1]^message[2]^message[3]^message[4]^message[5];
				 }     
			 }
		     break;	                   
  	     
         case 12:   // store
	         	//value == ((C1 * 1000) + C2) * 100 + Store-to-position
	         	message[0] = 0x07 + addr*8;
	         	message[2] = 0x08; // optional length byte, 0x08 means there are 8 bytes in data field.
	         	if(channelNum >20)
	         	{	
	         		message[3] = 0x02;
	         	}
	         	else
	         	{
	         	message[3] = 0x01;
	         	}
			   message[4] = 0x00; // [3] and [4] means Match network1  
			   message[5] = value % 100; // the store-to position
			   message[6] = 0x00; // trajectory pair 0
			    
			   tempint = (value/100000) * 10;        // get C1 position to preset
			   message[7] = tempint&0xff;
			   message[8] = (tempint>>8)&0xff;
			    
			   tempint = ((value/100)%1000) * 10;        // get C2 position to preset
			   message[9] = tempint&0xff;
			   message[10] = (tempint>>8)&0xff;
			    
			   message[11] = message[0]^message[1]^message[2]^message[3]^message[4]^message[5]^message[6]^message[7]^message[8]^message[9]^message[10];    
	       	break;
       		
       	case 16:   // set prior time
	         	message[0] = 0x07 + addr*8;
	         	message[2] = 0x0C; // optional length byte, 0x0C means there are 12 bytes in data field.
	         	message[3] = 0xD1; // [3] and [4] means sub-command 209 
				if(channelNum >20)
	         	{	
	         		message[5] = 0x02;
	         	}
	         	else
	         	{
	         		message[5] = 0x01;
	         	} 
			if(channelNum >20)//2M Match
			{
				message[7] = 0x32; 
			   	message[9] = 0x32;	
			}
			else//1356M Match
			{
				//changed by liwh[1.8.0]
			    message[7] = 0x01; // [7] and [8] V Threshold : 1 //change sp 20220501 for dualmatch s
			   	message[9] = 0x01; // [9] and [10] I Threshold : 1 //change sp 20220501 for dualmatch s
		        }   
			   tempint = value;   //prior time
			   message[11] = tempint&0xff;
			   message[12] = (tempint>>8)&0xff;
			   
			   message[13] = 0x05; // [13] and [14] Late pulse blanking(future discard) : 5
			    
			   message[15] = message[0]^message[1]^message[2]^message[3]^message[5]^message[7]^message[9]^message[11]^message[12]^message[13];    
	       	   break;
	}
          
	return(sendCommandAck(message, resp, m_timeOut, com.m_relen+1, com.m_type));
}

bool AEDualMatchFastEDriver::readInt(int channelNum, int *value, const IntTypeInfo &typeInfo)
{
	//Com com = m_commands[channelNum];
	int tempint;

    memset(resp, 0, RESP_LEN); 
	memset(message, 0, MESS_LEN);
	Com com;
	/*if(channelNum > 20)
	{
			selectNetWork(1);
			com = m_commands[channelNum-20];
	}
	else
	{
			selectNetWork(0);
			com = m_commands[channelNum];
	}*/  
    com = m_commands[channelNum];  //modify by zhangpf

	message[0] = (char)(com.m_type-3+8*addr);
	message[1] = com.m_cmd;
	
	if(com.m_type == 5)  // read C1,C2 or mode
	{
		message[2] = 0x01;   //modify by zhangpf
		message[3] = 0x00;
		message[4] = message[0]^message[1]^message[2]^message[3];
	}

	if(com.m_type == 3)  // read OverHeat/Interlock/FanError
	{
		//message[2] = 0x01;   //modify by zhangpf
		//message[3] = 0x00;
		message[2] = message[0]^message[1];
	}
	
	if(com.m_type == 7) //read prior time
	{
		message[2] = 0xD1;    //209
		if(channelNum > 20)
		{
			message[4] = 0x02;
		}
		else
		{
		message[4] = 0x01;
		}
    	message[6] = message[0]^message[1]^message[2]^message[4];	
	}
    
	// test for read enable/disable presets
	if(channelNum == 19) 
	{
		message[2] = 0x01;
    	message[4] = message[0]^message[1]^message[2]^message[3];	
		message[6] = 0x00;
	}
	if(channelNum == 20) 
	{
		message[2] = 0x01;
	    message[3] = message[0]^message[1]^message[2];	
		getCommandResult(message,com.m_type,resp,com.m_relen+1,m_timeOut);
		*value=(int)resp[1] & 0x07;
		if((*value)>1 && (*value)<7)
		{
			for(int i=3;i<(*value)+3;i++)
			{
				//error code
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, Converter::convertToString(i)+":"+Converter::convertToString(((int)resp[i] & 0x00ff)));
			}
		}
		if((*value)==7)
		{
			for(int i=3;i<((int)resp[3] & 0x00ff)+4;i++)
			{
				//error code
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, Converter::convertToString(i)+":"+Converter::convertToString(((int)resp[i] & 0x00ff)));
			}
		}
		return true;
	}
  	if(readCommand(message , resp, m_timeOut, com.m_relen+1, com.m_type))
  	{
		/*if(channelNum > 20)
		{
			channelNum= channelNum-20;
		}*/  
  		switch(channelNum)
  		{
  	     
  	     	case 6:  	
  	     		 // read mode
  	     		
  	     			tempint = (int)resp[5] & 0x00FF;
  	     			*value = int((tempint-2)*(-1));
  	     			break;
  	     		
  	     	case 7:     		
  	     		  //read C1
  	     		  
  	     			tempint = ((((int)resp[6]&0x00ff)<<8)&0xff00) + ((int)resp[5]&0xff);
  	     			*value = (tempint+5)/10;	 
  	    			break;
  	     		
  	     		
  	     	case 8:
  	     		 //read C2
  	     		
  	     			tempint = (((int)(resp[8]&0x00ff)<<8)&0xff00) + ((int)resp[7]&0xff);
  	     			*value = (tempint+5)/10;	 
  	    			break;	
  	    			
  	    	case 17:
  	     		 //read prior time    		
  	     			tempint = (((int)(resp[9]&0x00ff)<<8)&0xff00) + ((int)resp[8]&0xff);
  	     			*value = tempint;	 
  	    			break;	
			// test for read enable/disable presets
  	    	case 19:
  	     			tempint = (((int)(resp[6]&0x00ff)<<8)&0xff00) + ((int)resp[5]&0xff);
  	     			*value = tempint;	 
  	    			break;	
  	     	case 22:
  	     		 // read OverHeat
  	     			tempint = (int)resp[4] & 0x02;
  	     			*value = tempint;
  	     			break;
  	     	case 23:
  	     		 // read Interlock
  	     			tempint = (int)resp[4] & 0x04;
  	     			*value = tempint;
  	     			break;
  	     	case 24:
  	     		 // read FanError
  	     			tempint = (int)resp[4] & 0x08;
  	     			*value = tempint;
  	     			break;
  		}
  		return true;
  	}
    return false;
}

bool AEDualMatchFastEDriver::readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	Com com;
	if(channelNum > 20)
	{
			//selectNetWork(1);
			com = m_commands[channelNum-20];
	}
	else
	{
			//selectNetWork(0);
			com = m_commands[channelNum];
	}
    memset(resp, 0, RESP_LEN);
	int temp = 0;

    if(com.m_type == 3)   // Command 219, no data field.
    {
    	memset(message, 0, 3);
    	message[0] = (char)(com.m_type-3+8*addr);
    	message[1] = com.m_cmd;
    	message[2] = message[0]^message[1];
    	
    }

    if(com.m_type == 7)   // Command 248-201/206, 4-byte data field. //using
    {
    	memset(message, 0, 7);
    	message[0] = (char)(com.m_type-3+8*addr);
    	message[1] = com.m_cmd;
		message[2] = 0xCE;    //206
		message[4] = 0x01;
    	message[6] = message[0]^message[1]^message[2]^message[4];
    	
    }

    if(com.m_type == 5)   // Command 248-29/10, 2-byte data field.
    {
    	memset(message, 0, 5);
    	message[0] = (char)(com.m_type-3+8*addr);
    	message[1] = com.m_cmd;
		message[2] = 0x0A;    //10
    	message[4] = message[0]^message[1]^message[2];
    	
    }
    	
    if(readCommand(message , resp, m_timeOut, com.m_relen+1, com.m_type))
  	{
		if(channelNum > 28 && channelNum<34)
		{
			//cout<<"resp[2]"<<hex<<(int)resp[2]<<endl;
			for(int i =0;i<28;i++)
			{
				resp[8+i]=resp[36+i];
			}
				channelNum = channelNum-20;
		}
  		switch(channelNum)
  		{
  			case 9:
  			{
			// read VDC			
			temp = (((int)(resp[27]&0x00ff)<<8)&0xff00) + ((int)resp[26]&0xff);  //248-201/206	
	
			if(0 == temp)
			{
				*value = 0;
			}
			else
			{	
				int sign = (temp>>15)&0x01;
	
				int index = (temp>>7)&0xFF; 
				index -= 127;
	
				int numaftpt = ((temp&0x7F)<<8) + ((int)resp[25]&0xff);	
				numaftpt = numaftpt|0x8000;
				if(index >=0)
				{
					*value = (numaftpt>>(15-index)) + ((numaftpt>>(14-index))&0x01)*0.5 ;
					
				}	
				else if(-1 == index)
				{
					*value = 0.5 + ((numaftpt>>14)&0x01)*0.25;				
				}
				else
				{
					*value = 0.25;
				}		
	
						*value *= 1.414;
				if(sign == 1){*value = *value * (-1);}
				}
			 	break;	 
	  		}
  			
			case 10: // read I-out (A)	
			{						
				temp = (((int)(resp[31]&0x00ff)<<24)&0xff000000) + (((int)(resp[30]&0x00ff)<<16)&0xff0000) 
					+ (((int)(resp[29]&0x00ff)<<8)&0xff00) + ((int)resp[28]&0xff);  //248-201/206  7th 4-Byte	

				*value = realToDouble((long)temp);				
				break;	
			}
			
			case 11:  //read V-out (V)
			{			
				temp = (((int)(resp[27]&0x00ff)<<24)&0xff000000) + (((int)(resp[26]&0x00ff)<<16)&0xff0000) 
					+ (((int)(resp[25]&0x00ff)<<8)&0xff00) + ((int)resp[24]&0xff);  //248-201/206  6th 4-Byte	

				*value = realToDouble((long)temp);				
				break;	
			}
			
			case 12:  //read R
			{			
				temp = (((int)(resp[19]&0x00ff)<<24)&0xff000000) + (((int)(resp[18]&0x00ff)<<16)&0xff0000) 
					+ (((int)(resp[17]&0x00ff)<<8)&0xff00) + ((int)resp[16]&0xff);  //248-201/206  4th 4-Byte	

				*value = realToDouble((long)temp);				
				break;	
			}
			
			case 13:  //read X
			{			
				temp = (((int)(resp[23]&0x00ff)<<24)&0xff000000) + (((int)(resp[22]&0x00ff)<<16)&0xff0000) 
					+ (((int)(resp[21]&0x00ff)<<8)&0xff00) + ((int)resp[20]&0xff);  //248-201/206  5th 4-Byte	

				*value = realToDouble((long)temp);				
				break;	
			}
			
			case 14:  //read outPhase
			{			
				temp = (((int)(resp[11]&0x00ff)<<24)&0xff000000) + (((int)(resp[10]&0x00ff)<<16)&0xff0000) 
					+ (((int)(resp[9]&0x00ff)<<8)&0xff00) + ((int)resp[8]&0xff);  //248-201/206  2nd 4-Byte	

				*value = realToDouble((long)temp);				
				break;	
			}
			 	
	  	}// switch over
  		
  		return true;
  	     
  	}
    return false;
}
bool AEDualMatchFastEDriver::readDoubleFake(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	int temp = 0;
	switch(channelNum)
	{
		case 9:
  			{
			// read VDC			
			temp = (((int)(respall[55]&0x00ff)<<8)&0xff00) + ((int)respall[54]&0xff);  //248-201/206	
	
			if(0 == temp)
			{
				*value = 0;
			}
			else
			{	
				int sign = (temp>>15)&0x01;
	
				int index = (temp>>7)&0xFF; 
				index -= 127;
	
				int numaftpt = ((temp&0x7F)<<8) + ((int)respall[25]&0xff);	
				numaftpt = numaftpt|0x8000;
				if(index >=0)
				{
					*value = (numaftpt>>(15-index)) + ((numaftpt>>(14-index))&0x01)*0.5 ;
					
				}	
				else if(-1 == index)
				{
					*value = 0.5 + ((numaftpt>>14)&0x01)*0.25;				
				}
				else
				{
					*value = 0.25;
				}		
	
					*value *= 1.414;
				if(sign == 1){*value = *value * (-1);}
			}
			 	break;	 
	  		
			}
			case 10: // read I-out (A)	
			{						
				temp = (((int)(respall[59]&0x00ff)<<24)&0xff000000) + (((int)(respall[58]&0x00ff)<<16)&0xff0000) + (((int)(respall[57]&0x00ff)<<8)&0xff00) + ((int)respall[56]&0xff);
				*value = realToDouble((long)temp);				
				break;	
			}
			
			case 11:  //read V-out (V)
			{			
				temp = (((int)(respall[55]&0x00ff)<<24)&0xff000000) + (((int)(respall[54]&0x00ff)<<16)&0xff0000) + (((int)(respall[53]&0x00ff)<<8)&0xff00) + ((int)respall[52]&0xff);	
				*value = realToDouble((long)temp);				
				break;	
			}
			
			case 12:  //read R
			{			
				temp = (((int)(respall[47]&0x00ff)<<24)&0xff000000) + (((int)(respall[46]&0x00ff)<<16)&0xff0000)+ (((int)(respall[45]&0x00ff)<<8)&0xff00) + ((int)respall[44]&0xff);	
				*value = realToDouble((long)temp);				
				break;	
			}
			
			case 13:  //read X
			{			
				temp = (((int)(respall[51]&0x00ff)<<24)&0xff000000) + (((int)(respall[50]&0x00ff)<<16)&0xff0000) + (((int)(resp[49]&0x00ff)<<8)&0xff00) + ((int)resp[48]&0xff);	
				*value = realToDouble((long)temp);				
				break;	
			}
			
			case 14:  //read outPhase
			{			
				temp = (((int)(respall[63]&0x00ff)<<24)&0xff000000) + (((int)(respall[62]&0x00ff)<<16)&0xff0000) 
					+ (((int)(respall[61]&0x00ff)<<8)&0xff00) + ((int)respall[60]&0xff);			
				*value = realToDouble((long)temp);
				break;	
			}
			
	}
	return true;
	
}

bool AEDualMatchFastEDriver::readIntFake(int channelNum, int *value, const IntTypeInfo &typeInfo)
{
	int temp = 0;
	if(channelNum == 8)
	{
		temp = (((int)(respall[11]&0x00ff)<<8)&0xff00) + ((int)respall[10]&0xff);
	}
	*value = (temp+5)/10;
	return true;
}
bool AEDualMatchFastEDriver::readAll(int channelNum, int *value, const IntTypeInfo &typeInfo)
{
	Com com = m_commands[21];
	memset(message, 0, 3);
   	memset(respall, 0, RESP_ALL_LEN);
	message[0] = (char)(com.m_type-3+8*addr);
    message[1] = com.m_cmd;
    message[2] = message[0]^message[1];
	*value = 0;
	if(readCommand(message , respall, m_timeOut, com.m_relen+1, com.m_type))
	{
		int temp = (((int)(respall[9]&0x00ff)<<8)&0xff00) + ((int)respall[8]&0xff);
		*value = (temp+5)/10;
		return true;
	}
}
double AEDualMatchFastEDriver::realToDouble(long value)
{
	unsigned long m = (value & 0x7fffff) | 0x800000; 
	int e = (value >> 23) & 0xff;
	int s = (value >> 31) & 0x01;
	double res = 0;
	int mi = 0;
	for(int i=0; i<24; ++i)
	{
		mi = (m >> i) & 0x01;
		if(mi == 1)
		{
			res += pow((double)(mi*2), (int)(e-127+i-23));
		}
	}
	return res*pow(-1.0, (int)s);
}

void AEDualMatchFastEDriver::InitChannels(DeviceNode<AEDualMatchFastEDriver> *node)
{   
	//Match Network 1 
	node->registerReadCh(0, &SerialDevice::getStatus);
	for(int i = 1; i <= 5; ++i)
	{
		node->registerWriteCh(i, &AEDualMatchFastEDriver::writeInt);
	}
	node->registerReadCh(6, &AEDualMatchFastEDriver::readInt);
	node->registerReadCh(7, &AEDualMatchFastEDriver::readAll);
	node->registerReadCh(8, &AEDualMatchFastEDriver::readIntFake);
	for(int i = 9; i <= 14; ++i)
	{
		node->registerReadCh(i, &AEDualMatchFastEDriver::readDoubleFake);
	}
	node->registerWriteCh(15, &AEDualMatchFastEDriver::writeInt);
	node->registerWriteCh(16, &AEDualMatchFastEDriver::writeInt);//set prior time
	node->registerReadCh(17, &AEDualMatchFastEDriver::readInt); //read prior time
	node->registerWriteCh(18, &AEDualMatchFastEDriver::writeInt);//set enable/disable presets
	node->registerReadCh(19, &AEDualMatchFastEDriver::readInt); //read enable/disable presets
	node->registerReadCh(20, &AEDualMatchFastEDriver::readInt); //read enable/disable presets

	node->registerWriteCh(21, &AEDualMatchFastEDriver::writeInt); 	// READ THE MOST VALUE
	node->registerReadCh(22, &AEDualMatchFastEDriver::readInt); //read TempStatus(OverHeat)
	node->registerReadCh(23, &AEDualMatchFastEDriver::readInt); //read interlock
	node->registerReadCh(24, &AEDualMatchFastEDriver::readInt); //read FanError
}
  
void AEDualMatchFastEDriver::init()
{
	cout<<"AEDualMatchFastEDriver init start"<<endl;
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "AEDualMatchFastEDriver start");
    DeviceNode<AEDualMatchFastEDriver> *node = new DeviceNode<AEDualMatchFastEDriver>(m_pollPeriod,this);
    InitChannels(node);
    DeviceManager::getInstance()->registerNode(m_nodeNum, node);
    cout<<"AEDualMatchFastEDriver end start"<<endl;
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "AEDualMatchFastEDriver end");
}

void AEDualMatchFastEDriver::setAddress(int ad)
{
   if(ad > 0)
    {
    	addr = ad;
    }
   else
	{
		cout<<"***  AEDualMatchFastEDriver addr config error, Set address to 1."<<endl;
    	addr = 1;
   	}
}

//choose network
  
void AEDualMatchFastEDriver::selectNetWork(int value)
{
   int t_change=value;
   switch (t_change)
   {
   	case 0:
		message[2]=0x01;
		break;
    	case 1:
		message[2]=0x02;
		break;
	default:
		break;
   }
   
}
 
IMPLEMENT_DYNAMIC(AEDualMatchFastEDriver, SerialDevice )
BEGIN_MSG_MAP(AEDualMatchFastEDriver, SerialDevice )
    SET_V( init, AEDualMatchFastEDriver )
    SET_I( setAddress, AEDualMatchFastEDriver )
END_MSG_MAP

