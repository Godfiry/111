/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: IOInterlockException.cpp
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-01-03   LiJuanjuan create
**      
*********************************************************************/
#include "IOInterlockException.h"

IOInterlockException::IOInterlockException(const std::string &s, BlockingAlarm *alarm):AbortException(s)
{
	m_alarm = alarm;
}

BlockingAlarm* IOInterlockException::getAlarm()const
{
	return m_alarm;
}
