#ifndef CPUTESTDRIVER_H_
#define CPUTESTDRIVER_H_

#include "AbstractDevice.h"
#include "DeviceNode.h"
#include "FileLogger.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class CPUTestDriver : public AbstractDevice
{
	DECLARE_DYNAMIC(CPUTestDriver)	
	DECLARE_MSG_MAP
protected:
     int m_pollPeriod;
     int m_nodeNum;
public:
    CPUTestDriver();
    virtual ~CPUTestDriver();
    
protected:    
    void init();
    void initChs(DeviceNode<CPUTestDriver> *node);
    
public:    
    bool ReadCurrentCPU( int channelNum,double *value,const DoubleTypeInfo& typeinfo);
    bool ReadCurrentMem( int channelNum,double *value,const DoubleTypeInfo& typeinfo);
    void setPollInterval(int ms);
    void setNodeNum(int nodeNum);
   


};
#endif /*CPUTESTDRIVER_H_*/
