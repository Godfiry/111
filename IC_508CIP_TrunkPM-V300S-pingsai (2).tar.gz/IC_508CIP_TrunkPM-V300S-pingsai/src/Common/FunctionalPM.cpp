/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: FunctionalPM.cpp
** Description: 
** Release: 
** Modification history: 
**                     2009-12-09   LiJuanjuan create
**                       2025-08-05   taohao[v1.5.0_HotFix] modify for obtain the recipe from the memory
**                                    Use from AppRecipeManager management sessions and recipes instead
***************************************************************************/
#include "FunctionalPM.h"
#include "TransferOperationInfo.h"
#include "SlotSensorInfo.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "RetryException.h"
#include "VetoException.h"
#include "InvalidNameException.h"
#endif
#include "RecipeTimeInfo.h"
#include "SysLogger.h"
#include "Recovery.h"

#include "ExecutionRecipe.h"
#include "RecipeNamespaceManager.h"
#include "ExecutionRecipe.h"
#include "Converter.h"

#include "ConfigException.h" 
#include "ObjectManager.h"
#include "CTCExport.h"
#include "AlarmReNameManager.h"
#include "string.h"
#include "stdlib.h"
#include "XmlGetter.h"

#ifdef IAP4_0
using namespace IAP;
using namespace IAP::CORE;
using namespace IAP::ALARM;
using namespace IAP::RECIPE;
using namespace IAP::CONDITION;
#endif

using namespace std;

FunctionalPM::FunctionalPM()
{
    m_pVerifyRecipeParameterFailed = NULL;
    m_pSlotValveNotCloseAlarm = NULL;
    m_slotValveIsOpen = NULL;
    m_slotValveIsClosed = NULL;
    m_pProcessTheRecipeOffOn = NULL;
    m_pMonitorEPDOffOn  = NULL;//added by guojin[1.1.43]
    m_slotValveStatus = NULL;

    m_sPrepChamb = new PrepChamb();
    m_sPrepChamb->setOwner(this);
    m_sJobStartCondition = new JobStartCondition();//[wangyk 1.1.60]
    m_sJobStartCondition->setOwner(this);
    m_sJobEndCondition = new JobEndCondition();
    m_sJobEndCondition->setOwner(this);

    m_sPrepareForProcessingMaterial = new PrepareForProcessingMaterial;
    m_sPrepareForProcessingMaterial->setOwner(this);
    m_sProcessMaterial = new ProcessMaterial;
    m_sProcessMaterial->setOwner(this);

    m_sCycleProcessMaterial = new CycleProcessMaterial(); //added by chensc [1.1.49]
    m_sCycleProcessMaterial->setOwner(this);
    m_sTotalCycleProcess = new TotalCycleProcess();  //added by chensc [1.1.49]
    m_sTotalCycleProcess->setOwner(this);

    m_pProcessTimer = NULL;//added by 508M new time
    m_pElapsedProcessTime = NULL;

    m_pRcpName = NULL;

    m_pDoubleRunCheckTimer = NULL;
    m_pDoubleRunCheckTimeLeft = NULL;

    m_currentWaferInfor.strLotID = "";
    m_currentWaferInfor.strWaferName = "";
    m_currentWaferInfor.strRecipeName = "";

    m_pDoubleRunAlarm = NULL;

    m_strCTCIPAddress = "192.168.14.200";
}

FunctionalPM::~FunctionalPM()
{
    #ifndef IAP4_0
    delete m_pDoubleRunCheckTimer;
    m_pDoubleRunCheckTimer = NULL;
    #endif

}

void FunctionalPM::PrepChamb::execute()
{
    FunctionalPM *owner = static_cast<FunctionalPM*>(getOwner());
    try
    {
        owner->do_PrepChamb(Params["port"].Int);
    }
    catch(const AbortException &ex)
    {
        Log_Error(getName() + ": PrepChamb service was aborted for:" + string(ex.what()));
        throw;
    }
    catch(const exception &ex)
    {
        Log_Error(getName() + ": PrepChamb service has error for:" + string(ex.what()));
        throw;
    }
}

void FunctionalPM::JobStartCondition::execute() //[wangyk 1.1.60]
{
    FunctionalPM *owner = static_cast<FunctionalPM*>(getOwner());
    try
    {
        owner->do_JobStartCondition(Params["ProcessRecipeName"].Str);
    }
    catch(const AbortException &ex)
    {
        Log_Error(getName() + ": JobStartCondition service was aborted for:" + string(ex.what()));
        throw;
    }
    catch(const exception &ex)
    {
        Log_Error(getName() + ": JobStartCondition service has error for:" + string(ex.what()));
        throw;
    }
}

void FunctionalPM::JobEndCondition::execute()//[wangyk 1.1.60]
{
    FunctionalPM *owner = static_cast<FunctionalPM*>(getOwner());
    try
    {
        owner->do_JobEndCondition(Params["ProcessRecipeName"].Str);
    }
    catch(const AbortException &ex)
    {
        Log_Error(getName() + ": JobEndCondition service was aborted for:" + string(ex.what()));
        throw;
    }
    catch(const exception &ex)
    {
        Log_Error(getName() + ": JobEndCondition service has error for:" + string(ex.what()));
        throw;
    }
}

void FunctionalPM::PrepareForProcessingMaterial::execute()
{
    ControlObject *owner = getOwner();
    if (owner != NULL)
    {
        #ifdef IAP4_0
        Result.Bool = (static_cast<FunctionalPM*>(owner))->do_PrepareForProcessingMaterial();
        #else
        Results["ret_prepared"].Bool = (static_cast<FunctionalPM*>(owner))->do_PrepareForProcessingMaterial();
        #endif
    }
}


void FunctionalPM::ProcessMaterial::execute()
{
    ControlObject *owner = getOwner();
    if (owner != NULL)
    {
        #ifdef IAP4_0
        Result.Bool = (static_cast<FunctionalPM*>(owner))->do_ProcessMaterial();
        #else
        Results["ret_processed"].Bool = (static_cast<FunctionalPM*>(owner))->do_ProcessMaterial();
        #endif
    }
}

void FunctionalPM::TotalCycleProcess::execute()//added by chensc [1.1.49]
{
    FunctionalPM *owner = static_cast<FunctionalPM*>(getOwner());
    try
    {
        owner->do_TotalCycleProcess(Params["recipeid"].Str,Params["cycle"].Int);
    }
    catch(const AbortException &ex)
    {
        Log_Error(getName() + ": TotalCycleProcess service was aborted for: " + string(ex.what()));
        throw;
    }
    catch(const exception &ex)
    {
        Log_Error(getName() + ": TotalCycleProcess service has error for: " + string(ex.what()));
        throw;
    }
}

void FunctionalPM::CycleProcessMaterial::execute()//added by chensc [1.1.49]
{
    FunctionalPM *owner = static_cast<FunctionalPM*>(getOwner());
    try
    {
        owner->do_CycleProcessMaterial(Params["recipeid"].Str,Params["cycle"].Int);
    }
    catch(const AbortException &ex)
    {
        Log_Error(getName() + ": CycleProcessMaterial service was aborted for: " + string(ex.what()));
        throw;
    }
    catch(const exception &ex)
    {
        Log_Error(getName() + ": CycleProcessMaterial service has error for: " + string(ex.what()));
        throw;
    }
}

void FunctionalPM::make()
{
    m_shortName = getSelfName();
    Log_Info(m_shortName + " begin FunctionalPM::make()");
    Chamber::make();
    buildAlarms();
    buildConditions();
    buildDataItems();
    registerObjects();
    Log_Info(m_shortName + " end FunctionalPM::make()");
}

void FunctionalPM::buildAlarms()
{
    string strPreName = AlarmReNameManager::getInstance()->GetShowName(getName());
    m_pVerifyRecipeParameterFailed = new BlockingAlarm(strPreName + "_VerifyRecipeParameterFailed", "Can't execute the recipe.", "recipe parameter value is invalid.", Alarm::FATAL);
    //added by taohao[v1.5.0_HotFix] for obtain the recipe from the memory
    m_pVerifyRecipeParameterFailed->addRecovery(new Recovery("Abort",Recovery::ABORT));
    try
    {
        ReadWriteInt * tmpDeleteRecipeFlag = XmlGetter::getFromNamespace<ReadWriteInt*>("/SETUP/SoftwareFunctionConfig/cfgDeleteRecipeFlag");
    }
    catch(const AbortException &ex)
    {
        m_pVerifyRecipeParameterFailed->addRecovery(new Recovery("Retry (After edit recipe)",Recovery::RETRY));
    }
    m_pSlotValveNotCloseAlarm = new BlockingAlarm(strPreName + "_SlotValveNotClose", "Can't do action "  , "The slot valve is not closed.", Alarm::ERROR);
    m_pSlotValveNotCloseAlarm->addRecovery(new Recovery("Abort",Recovery::ABORT));
    m_pSlotValveNotCloseAlarm->addRecovery(new Recovery("Retry",Recovery::RETRY));

    m_pDoubleRunAlarm = new BlockingAlarm(strPreName + "_DoubleRunCheckAlarm", "Can't execute the recipe, the wafer may be double run, please check.", "Can't execute the recipe.", Alarm::FATAL);
    m_pDoubleRunAlarm->addRecovery(new Recovery("Abort",Recovery::ABORT));
    m_pDoubleRunAlarm->addRecovery(new Recovery("Ignore and Continue (Run process anyway)",Recovery::CONTINUE));
}

void FunctionalPM::buildConditions()
{
}

void FunctionalPM::buildDataItems()
{
    m_slotValveStatus = new ReadWriteInt(getName()+"/SlotValveSts", SlotSensorInfo::typeInfo);
    m_slotValveStatus->setValue(0);//add by AtuoCodeChangeTool for IAP4.0
    CTCExport::exportAsOthers(m_slotValveStatus);

    m_sendReceiveStatus = new ReadWriteInt(TransferOperationInfo::typeInfo);
    m_sendReceiveStatus->setValue(0);//add by AtuoCodeChangeTool for IAP4.0

    int nCapacity = getCapacity();

    m_slotOccupancy.resize(nCapacity + 1);
    m_slotWfr.resize(nCapacity + 1);
    m_slotLotId.resize(nCapacity + 1);
    m_slotWaferName.resize(nCapacity + 1);
    for(int j = 1; j <= nCapacity; j++)
    {
        m_slotWfr[j] = new ReadWriteInt(MaterialIdInfo::typeInfo);
        ObjectManager::getInstance()->registerObject(m_slotWfr[j], getName() + "/S"+Converter::convertToString(j)+ "/WfrId");///PM/S1/WfrId
        m_slotWfr[j]->setValue(0);
        CTCExport::exportAsOthers(m_slotWfr[j], "PM_S"+Converter::convertToString(j)+"_SlotId");

        m_slotLotId[j] = new ReadWriteString(LotIdInfo::typeInfo);
        m_slotLotId[j]->setValue("");//add by AtuoCodeChangeTool for IAP4.0
        ObjectManager::getInstance()->registerObject(m_slotLotId[j], getName() + "/S"+Converter::convertToString(j)+ "/LotId");///PM/S1/LotId
        CTCExport::exportAsOthers(m_slotLotId[j], "PM_S"+Converter::convertToString(j)+"_LotId");

        m_slotWaferName[j]= new ReadWriteString(LotIdInfo::typeInfo);
        m_slotWaferName[j]->setValue("");//add by AtuoCodeChangeTool for IAP4.0
        ObjectManager::getInstance()->registerObject(m_slotWaferName[j], getName() + "/S"+Converter::convertToString(j)+ "/WfrNam");///PM/S1/WfrNam
        CTCExport::exportAsOthers(m_slotWaferName[j], "PM_S"+Converter::convertToString(j)+"_WfrNam");
    }
    try
    {
        m_pProcessTheRecipeOffOn=(ReadWriteInt*)ObjectManager::getInstance()->getObject("/IO/Datas/ProcessTheRecipeFlag");
        m_pProcessTheRecipeOffOn->setValue(0);
    }
    catch(const exception &e)
    {
        m_pProcessTheRecipeOffOn = new ReadWriteInt(getName() + "/ProcessTheRecipeFlag", IntTypeInfo(0,1,DescriptorList("Off,On")));
        CTCExport::exportAsOthers(m_pProcessTheRecipeOffOn);
        m_pProcessTheRecipeOffOn->setValue(0);
    }
    try//added by guojin[1.1.43]
    {
        m_pMonitorEPDOffOn=(ReadWriteInt*)ObjectManager::getInstance()->getObject("/IO/Datas/MonitorEPDFlag");
        m_pMonitorEPDOffOn->setValue(0);
    }
    catch(const exception &e)
    {
        m_pMonitorEPDOffOn = new ReadWriteInt(getName() + "/MonitorEPDFlag", IntTypeInfo(0,1,DescriptorList("Off,On")));
        m_pMonitorEPDOffOn->setValue(0);
    }

    m_pDoubleRunCheckTimeLeft = new ReadWriteDouble(getName() + "/DoubleRunCheckTimeLeft", RecipeTimeInfo::typeInfo);
    m_pDoubleRunCheckTimeLeft->setValue(0.0);//add by AtuoCodeChangeTool for IAP4.0
    CTCExport::exportAsOthers(m_pDoubleRunCheckTimeLeft);
    m_pDoubleRunCheckTimer = new CounterTimer(m_pDoubleRunCheckTimeLeft, 1, 1);
}

void FunctionalPM::registerObjects()
{

}

void FunctionalPM::initialize()
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT,m_shortName + "Begin void FunctionalPM::initialize()");
    Chamber::initialize();
    connectDependentObjects();
    registerDependentObjects();
    initConditionsAndInterlocks();
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT,m_shortName + "End void FunctionalPM::initialize()");
}

void FunctionalPM::connectDependentObjects()
{
    m_pRcpName = static_cast<ReadWriteString*>(ObjectManager::getInstance()->getObject("/Control/PMCExports/Datas/PM_S1_RecipeName"));
    m_pElapsedProcessTime = static_cast<ReadWriteDouble*>(ObjectManager::getInstance()->getObject("/Control/PMCExports/Datas/PM_S1_ElapsedProcessTime"));
    m_pProcessTimer = new CounterTimerMs(m_pElapsedProcessTime, 0, 0.1);
}


void FunctionalPM::registerDependentObjects()
{

}


void FunctionalPM::initConditionsAndInterlocks()
{
    m_slotValveIsOpen = new AppCondition(m_slotValveStatus, "==", 1);
    m_slotValveIsClosed = new AppCondition(m_slotValveStatus, "==", 2);
}

void FunctionalPM::call_PrepChamb(int nPort)
{
    call(m_sPrepChamb);
}

void FunctionalPM::call_JobStartCondition(string strProcessRecipeName)//[wangyk 1.1.60]
{
    m_sJobStartCondition->setParamValue("ProcessRecipeName",strProcessRecipeName); //added by zhangpf[1.8.2]
    call(m_sJobStartCondition);
}

void FunctionalPM::call_JobEndCondition(string strProcessRecipeName)//[wangyk 1.1.60]
{
    m_sJobEndCondition->setParamValue("ProcessRecipeName",strProcessRecipeName); //added by zhangpf[1.8.2]
    call(m_sJobEndCondition);
}

bool FunctionalPM::call_PrepareForProcessingMaterial()//modify by taohao[v1.5.0_HotFix] for obtain the recipe from the memory
{
    call(m_sPrepareForProcessingMaterial);

    #ifdef IAP4_0
    if(m_sPrepareForProcessingMaterial->result().Bool)
    #else
    map<string, CompoundVariable> ret;
    m_sPrepareForProcessingMaterial->getResults(ret);
    if (ret["ret_prepared"].Bool)
    #endif


    {
        return true;
    }
    else
    {
        return false;
    }
}

bool FunctionalPM::call_ProcessMaterial()
{
    call(m_sProcessMaterial);

    #ifdef IAP4_0
    if(m_sProcessMaterial->result().Bool)
    #else
    map<string, CompoundVariable> ret;
    m_sProcessMaterial->getResults(ret);
    if (ret["ret_processed"].Bool)
    #endif


    {
        return true;
    }
    else
    {
        return false;
    }
}

void FunctionalPM::call_TotalCycleProcess(const std::string &strRecipeID,int cycle) //added by chensc [1.1.49]
{
    m_sTotalCycleProcess->setParamValue("recipeid", strRecipeID);
    m_sTotalCycleProcess->setParamValue("cycle", cycle);
    call(m_sTotalCycleProcess);
}

void FunctionalPM::call_CycleProcessMaterial(const std::string &strRecipeID,int cycle) //added by chensc [1.1.49]
{
    m_sCycleProcessMaterial->setParamValue("recipeid", strRecipeID);
    m_sCycleProcessMaterial->setParamValue("cycle", cycle);
    call(m_sCycleProcessMaterial);
}

void FunctionalPM::do_PrepChamb(int nPort)
{
    goToPrepareChamber();
}

void FunctionalPM::do_JobStartCondition(string strProcessRecipeName)//[wangyk 1.1.60]
{

}

void FunctionalPM::do_JobEndCondition(string strProcessRecipeName)//[wangyk 1.1.60]
{

}

void FunctionalPM::do_PrepWfr(int nSlot, int nTransferOperation, int nHandOffMode,int nMatID,string strLotID, string strWaferName)
{
    Log_Info(m_shortName + " about to do FunctionalPM::do_PrepWfr ()");
    try
    {
        if(nSlot >= 0 && nSlot <= getCapacity())
        {
            int nWaferState = getWfrState(nSlot);
            m_nSlotNumber = nSlot;
            m_nTransferOperation = nTransferOperation;
            m_nWaferID = nMatID;
            m_strLotID = strLotID;
            m_strWaferName = strWaferName;
            m_nHandOffMode = nHandOffMode; //added by chensc[1.1.53]
            m_sendReceiveStatus->setValue(nTransferOperation);
            goToTransferPosition();
        }
        else
        {
            throw AbortException("Slot is out of range.");
        }
    }
    catch(const AbortException &ex)
    {
        Log_Error(m_shortName + " in FunctionalPM::do_PrepWfr() caught abort exception:" + string(ex.what()));
        throw;
    }
    catch(const RetryException &retryexception)
    {
        throw;
    }
    catch(const exception &ex)
    {
        Log_Error(m_shortName + " in FunctionalPM::do_PrepWfr() caught exception:" + string(ex.what()));
        throw;
    }
    Log_Info(m_shortName + " done FunctionalPM::do_PrepWfr()");
}

int FunctionalPM::do_CompWfr()
{
    try
    {
        try
        {
            switch(m_nTransferOperation)
            {
                case TransferOperationInfo::Send: // '\001'
                    Log_Info(getSelfName()+" FunctionalPM::do_CompWfr start, TransferOperation is Send.");
                    setWfrState(m_nSlotNumber,1);
                    //m_slotOccupancy[m_nSlotNumber]->setValue(1);
                    m_slotWfr.at(m_nSlotNumber)->setValue(0);
                    m_slotLotId.at(m_nSlotNumber)->setValue("");
                    m_slotWaferName.at(m_nSlotNumber)->setValue("");
                    m_currentWaferInfor.strLotID = "";
                    m_currentWaferInfor.strWaferName = "";
                    m_pDoubleRunCheckTimer->stop();
                    m_pDoubleRunCheckTimeLeft->setValue(0);
                    break;

                case TransferOperationInfo::Receive: // '\0'
                case TransferOperationInfo::Swap: // '\002'
                    Log_Info(getSelfName()+" FunctionalPM::do_CompWfr start, TransferOperation is Receive or Swap.");
                    //m_slotOccupancy[m_nSlotNumber]->setValue(2);
                    setWfrState(m_nSlotNumber,2);
                    m_slotWfr.at(m_nSlotNumber)->setValue(m_nWaferID);
                    m_slotLotId.at(m_nSlotNumber)->setValue(m_strLotID);
                    m_slotWaferName.at(m_nSlotNumber)->setValue(m_strWaferName);
                    m_currentWaferInfor.strLotID = m_strLotID;
                    m_currentWaferInfor.strWaferName = m_strWaferName;
                    break;
            }
        }
        catch(const exception &ex)//setvalue may be occur exception
        {
            Log_Error(getSelfName() + ": FunctionalPM::do_CompWfr  got exception-" +ex.what());
        }
        goToCompleteWaferPosition();
    }
    catch(const RetryException &retryexception)
    {
        throw;
    }
    catch(const exception &ex)
    {
        Log_Error(getSelfName() + ": FunctionalPM::do_CompWfr  got exception-" +ex.what());
        throw;
    }
    Log_Info(getSelfName() + ": FunctionalPM::do_CompWfr  end");
    return 1;
}
bool FunctionalPM::do_PrepareForProcessingMaterial()//modify by taohao[v1.5.0_HotFix] for obtain the recipe from the memory
{
    Log_Info( m_shortName + " about to FunctionalPM::do_PrepareForProcessingMaterial()" );
    
    #ifdef SUSE
        string strCommand="echo '888888' | sudo -S sh -c 'net time set -S "+m_strCTCIPAddress+"'";  //add by wzd 1.1.49
    #else
	    string strCommand="echo '888888' | sudo -S sh -c 'net time set -I "+m_strCTCIPAddress+"'";	
	#endif
    char t_ch[strCommand.length()+1];
    strcpy(t_ch,strCommand.c_str());

    try
    {
        for(unsigned int i = 0; i < m_pDisableCheckItemBeforeSyc.size(); ++i) // add by chensc 1.1.55
        {
            m_pDisableCheckItemBeforeSyc[i]->stop();
        }
        int nResult = system(t_ch);
        if(nResult != 0)
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": FunctionalPM::do_PrepareForProcessingMaterial() SynchronizeClocks error is "+Converter::convertToString(nResult));
        }
        else
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": FunctionalPM::do_PrepareForProcessingMaterial() SynchronizeClocks successfully!");
        }
        for(unsigned int i = 0; i < m_pDisableCheckItemBeforeSyc.size(); ++i) // add by chensc 1.1.55
        {
            m_pDisableCheckItemBeforeSyc[i]->start();
        }
    }
    catch(...)
    {
        for(unsigned int i = 0; i < m_pDisableCheckItemBeforeSyc.size(); ++i) // add by chensc 1.1.55
        {
            m_pDisableCheckItemBeforeSyc[i]->start();
        }
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": FunctionalPM::do_PrepareForProcessingMaterial() SynchronizeClocks failed for some exception.");
    }

    try
    {
        extractRecipeParameters();
        verifyRecipeParameters();
        m_currentWaferInfor.strRecipeName = m_pRcpName->getValue();
        //modify by taohao[v1.5.0_HotFix] for obtain the recipe from the memory
        if((AppRecipeManager::getInstance()->getHandlerClass() != "/DryClean") && (m_currentWaferInfor.strWaferName != "" || m_currentWaferInfor.strLotID != ""))
        {
            if(m_currentWaferInfor.strWaferName == m_lastWaferInfo.strWaferName && m_currentWaferInfor.strLotID == m_lastWaferInfo.strLotID && m_currentWaferInfor.strRecipeName == m_lastWaferInfo.strRecipeName)
            {
                if(m_pDoubleRunCheckTimeLeft->getValue() > 0)
                {
                    //post Alarm
                    m_pDoubleRunAlarm->setDescription("Wafer ["+m_currentWaferInfor.strLotID+", "+m_currentWaferInfor.strWaferName+"] may executed the recipe ["+m_currentWaferInfor.strRecipeName+"] already. Are you sure run again?");
                    m_pDoubleRunAlarm->post(this);
                }
            }
        }
        m_pDoubleRunCheckTimer->stop();
        m_pDoubleRunCheckTimeLeft->setValue(0);
    }
    catch(const RetryException &retryexception)
    {
        throw;
    }
    catch(const exception &ex)
    {
        m_pDoubleRunCheckTimer->stop();
        m_pDoubleRunCheckTimeLeft->setValue(0);
        Log_Error(m_shortName + " do_PrepareForProcessingMaterial caught exception:" + string(ex.what()) );
        if(string(ex.what()).find("executed recovery 'ABORT'") != string::npos)
        {
            throw;
        }
        //added by taohao[v1.5.0_HotFix] for obtain the recipe from the memory
        m_pVerifyRecipeParameterFailed->setMessage("Can't execute the recipe ["+AppRecipeManager::getInstance()->getCurrentRecipeFullName()+"].");
        m_pVerifyRecipeParameterFailed->setDescription(ex.what());
        m_pVerifyRecipeParameterFailed->post(this);
    }
    Log_Info( m_shortName + " done FunctionalPM::do_PrepareForProcessingMaterial()" );
    return true;
}

bool FunctionalPM::do_ProcessMaterial() 
{
    Log_Info( m_shortName + " about to FunctionalPM::do_ProcessMaterial()" );
    try
    {
        m_pElapsedProcessTime->setValue(0);    //added by xiasc for 508M new time
        m_pProcessTimer->start();
        setMessage("do process");
        goToProcessPosition();
        processTheRecipe();
        setMessage("Idle");
        m_pProcessTimer->stop();

        m_lastWaferInfo = m_currentWaferInfor;
        m_pDoubleRunCheckTimeLeft->setValue(60);
        m_pDoubleRunCheckTimer->start();
        //clearProcessParam();
    }
    catch(const RetryException &ex)//zhangyy add const for sonar[1.5.0]
    {
        throw;
    }
    catch(AbortException &ex)
    {
        Log_Error(m_shortName + " Process failed! for abort exception: " + string(ex.what()));
        m_lastWaferInfo.strLotID = "";
        m_lastWaferInfo.strWaferName = "";
        m_lastWaferInfo.strRecipeName = "";
        m_pProcessTimer->stop();
        CheckItemControlBySequence::getInstance()->doAbort();//add by zhangpf[v1.6.6]
        throw;
    }
    catch(exception &ex)
    {
        Log_Error(m_shortName + " Process failed! for exception: " + string(ex.what()));
        m_lastWaferInfo.strLotID = "";
        m_lastWaferInfo.strWaferName = "";
        m_lastWaferInfo.strRecipeName = "";
        m_pProcessTimer->stop();
        CheckItemControlBySequence::getInstance()->doAbort();//add by zhangpf[v1.6.6]
        throw;
    }
    Log_Info( m_shortName + " done FunctionalPM::do_ProcessMaterial()" );
    return true;
}

void FunctionalPM::do_CycleProcessMaterial(const std::string &strRecipeID,int cycle) //added by chensc [1.1.49]
{
    Log_Info( m_shortName + " about to FunctionalPM::do_CycleProcessMaterial()" );
    try
    {
        m_pElapsedProcessTime->setValue(0);    //added by xiasc for 508M new time
        m_pProcessTimer->start();
        setMessage("do process");
        goToProcessPosition();
        do_TotalCycleProcess(strRecipeID,cycle);
        setMessage("Idle");
        m_pProcessTimer->stop();

        m_lastWaferInfo = m_currentWaferInfor;
        m_pDoubleRunCheckTimeLeft->setValue(60);
        m_pDoubleRunCheckTimer->start();
        //clearProcessParam();
    }
    catch(const RetryException &ex)//zhangyy add const for sonar[1.5.0]
    {
        throw;
    }
    catch(AbortException &ex)
    {
        Log_Error(m_shortName + " Process failed! for abort exception: " + string(ex.what()));
        m_lastWaferInfo.strLotID = "";
        m_lastWaferInfo.strWaferName = "";
        m_lastWaferInfo.strRecipeName = "";
        m_pProcessTimer->stop();
        throw;
    }
    catch(exception &ex)
    {
        Log_Error(m_shortName + " Process failed! for exception: " + string(ex.what()));
        m_lastWaferInfo.strLotID = "";
        m_lastWaferInfo.strWaferName = "";
        m_lastWaferInfo.strRecipeName = "";
        m_pProcessTimer->stop();
        throw;
    }
    Log_Info( m_shortName + " done FunctionalPM::do_CycleProcessMaterial()" );

}

void FunctionalPM::do_TotalCycleProcess(const std::string &strRecipeID,int cycle)  //added by chensc [1.1.49]
{
    Log_Info( m_shortName + " about to FunctionalPM::do_TotalCycleProcess()" );
    try
    {
        m_pElapsedProcessTime->setValue(0);    //added by xiasc for 508M new time
        m_pProcessTimer->start();
        setMessage("do process");
        goToProcessPosition();
        processTheRecipe();
        setMessage("Idle");
        m_pProcessTimer->stop();

        m_lastWaferInfo = m_currentWaferInfor;
        m_pDoubleRunCheckTimeLeft->setValue(60);
        m_pDoubleRunCheckTimer->start();
        //clearProcessParam();
    }
    catch(const RetryException &ex)//zhangyy add const for sonar[1.5.0]
    {
        throw;
    }
    catch(AbortException &ex)
    {
        Log_Error(m_shortName + " Process failed! for abort exception: " + string(ex.what()));
        m_lastWaferInfo.strLotID = "";
        m_lastWaferInfo.strWaferName = "";
        m_lastWaferInfo.strRecipeName = "";
        m_pProcessTimer->stop();
        throw;
    }
    catch(exception &ex)
    {
        Log_Error(m_shortName + " Process failed! for exception: " + string(ex.what()));
        m_lastWaferInfo.strLotID = "";
        m_lastWaferInfo.strWaferName = "";
        m_lastWaferInfo.strRecipeName = "";
        m_pProcessTimer->stop();
        throw;
    }
    Log_Info( m_shortName + " done FunctionalPM::do_TotalCycleProcess()" );

}

double FunctionalPM::getTotalProcessTime()
{
    return AppRecipeManager::getInstance()->calculateProcessTotalTime();//taohao[v1.5.0_HotFix] modify for obtain the recipe from the memory
}

void FunctionalPM::processTheRecipe()//taohao[v1.5.0_HotFix] modify for obtain the recipe from the memory
{
    m_pProcessTheRecipeOffOn->setValue("On");
    string t_svalue;
    int t_ivalue;
    for(unsigned int i = 0; i < AppRecipeManager::getInstance()->getNumOfSteps(); i++)
    {
        t_svalue = AppRecipeManager::getInstance()->getStepValueAS(i, "ProcessTime");
        Converter::stringToInt(t_ivalue, t_svalue);
        processTheRecipeStep(t_ivalue * 1000);
    }
    m_pProcessTheRecipeOffOn->setValue("Off");
}

void FunctionalPM::clearProcessParam()
{
    //m_strProcessRecipeName = "";
}

void FunctionalPM::processTheRecipeStep(double d)
{
    do_Wait(d);
}

void FunctionalPM::extractRecipeParameters()
{
    //setProcessRecipeName(m_processRecipe.getName());
}

void FunctionalPM::verifyRecipeParameters()
{
}

void FunctionalPM::do_Wait(double d)
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, m_shortName + " -> Wait time in secs = " + Converter::convertToString(d) + " <- ");
    usleepChange((long)(1000 * 1000 * d));
}


void FunctionalPM::completeReceivingMaterial(int i)
{
    Log_Info( m_shortName + " Updating station map at slot " + Converter::convertToString(i) + " to Present" );
}

void FunctionalPM::completeSendingMaterial(int i)
{
    Log_Info( m_shortName + " Updating station map at slot " + Converter::convertToString(i) + " to Absent" );
}

std::string FunctionalPM::getProcessRecipeName()
{
    return AppRecipeManager::getInstance()->getCurrentRecipeFullName();//taohao[v1.5.0_HotFix] modify for obtain the recipe from the memory
}

void FunctionalPM::goToProcessPosition()
{

}

void FunctionalPM::goToTransferPosition()
{

}

void FunctionalPM::goToPrepareChamber()
{

}


void FunctionalPM::goToCompleteWaferPosition()
{
    if((m_sendReceiveStatus->getValue() == TransferOperationInfo::Receive)  || (m_sendReceiveStatus->getValue() == TransferOperationInfo::Swap))
    {
        completeReceivingMaterial(0);
    }
    if(m_sendReceiveStatus->getValue() == TransferOperationInfo::Send)
    {
        completeSendingMaterial(0);
    }
} 

void FunctionalPM::startup() 
{
    Chamber::startup();

    m_slotValveIsOpen->activate();
    m_slotValveIsClosed->activate();
}

bool FunctionalPM::isAtProcessPosition()
{
    return true;
}

bool FunctionalPM::isAtTransferPosition()
{
    return true;
}
/*
void FunctionalPM::setProcessRecipeName(const std::string &s)
{
    m_strProcessRecipeName = s;
}
*/
void FunctionalPM::setCTCIP(const string &strIPAddress)
{
    m_strCTCIPAddress = strIPAddress;
}

void FunctionalPM::addDisableCheckItemBeforeSyc(const std::string &path)
{
    ManagedObject *t_obj = NULL;
    try
    {
        t_obj = ObjectManager::getInstance()->getObject(this, path);
    }
    catch(const InvalidNameException &ex)
    {
        t_obj = ObjectManager::getInstance()->getObject(path);
    }
    CheckItem *t_obj2 = dynamic_cast<CheckItem*>(t_obj);
    if(NULL == t_obj2)
    {
        throw ConfigException("the object under path '" + path + "' is not a CheckItem");
    }
    m_pDisableCheckItemBeforeSyc.push_back(t_obj2);
}
IMPLEMENT_DYNAMIC_SERVICE(PrepChamb, FunctionalPM)
IMPLEMENT_DYNAMIC_SERVICE(JobStartCondition, FunctionalPM)//[wangyk 1.1.60]
IMPLEMENT_DYNAMIC_SERVICE(JobEndCondition, FunctionalPM)//[wangyk 1.1.60]
IMPLEMENT_DYNAMIC_SERVICE(PrepareForProcessingMaterial, FunctionalPM)
IMPLEMENT_DYNAMIC_SERVICE(ProcessMaterial, FunctionalPM)
IMPLEMENT_DYNAMIC_SERVICE(TotalCycleProcess, FunctionalPM) //added by chensc [1.1.49]
IMPLEMENT_DYNAMIC_SERVICE(CycleProcessMaterial, FunctionalPM) //added by chensc [1.1.49]

BEGIN_SERVICEINFO_LIST(FunctionalPM)
    ADD_SERVICE_INFO(FunctionalPM, PrepChamb, prepare chamber.)
            ADD_PARAM_INFO(FunctionalPM, PrepChamb, port, int, VBE1:1 AFE1:2)
    ADD_SERVICE_INFO(FunctionalPM, JobStartCondition, prepare chamber.)
            ADD_PARAM_INFO(FunctionalPM, JobStartCondition, ProcessRecipeName, string,)
    ADD_SERVICE_INFO(FunctionalPM, JobEndCondition, prepare chamber.)
            ADD_PARAM_INFO(FunctionalPM, JobEndCondition, ProcessRecipeName, string,)
    ADD_SERVICE_INFO(FunctionalPM, PrepareForProcessingMaterial, Prepares the module for Processing Material.)
    ADD_SERVICE_INFO(FunctionalPM, ProcessMaterial, Processes the Material.)
    ADD_SERVICE_INFO(FunctionalPM, TotalCycleProcess, Cycle process) //added by chensc [1.1.49]
            ADD_PARAM_INFO(FunctionalPM, TotalCycleProcess, recipeid, string, the recipe name of cycle process)
            ADD_PARAM_INFO(FunctionalPM, TotalCycleProcess, cycle, int, the cycle number)
    ADD_SERVICE_INFO(FunctionalPM, CycleProcessMaterial, Cycle process) //added by chensc [1.1.49]
            ADD_PARAM_INFO(FunctionalPM, CycleProcessMaterial, recipeid, string, the recipe name of cycle process)
            ADD_PARAM_INFO(FunctionalPM, CycleProcessMaterial, cycle, int, the cycle number)
END_SERVICEINFO_LIST(FunctionalPM)

IMPLEMENT_DYNAMIC(FunctionalPM, Chamber)

BEGIN_MSG_MAP( FunctionalPM, Chamber )
    SET_S(setCTCIP, FunctionalPM)
    SET_S(addDisableCheckItemBeforeSyc, FunctionalPM)
END_MSG_MAP
