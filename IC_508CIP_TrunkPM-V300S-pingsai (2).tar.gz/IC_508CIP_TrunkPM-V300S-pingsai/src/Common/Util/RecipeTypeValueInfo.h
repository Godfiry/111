/*
 * RecipeTypeValueInfo.h
 *
 *  Created on: 2025.5.28
 *      Author: mujingyan
 */

#ifndef SRC_COMMON_RECIPETYPEVALUEINFO_H_
#define SRC_COMMON_RECIPETYPEVALUEINFO_H_

#include "ReadWriteInt.h"
#include "CmdTarget.h"
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
#endif

class RecipeTypeValueInfo:public CmdTarget
{
    public:
        RecipeTypeValueInfo();
        virtual ~RecipeTypeValueInfo();

    public:
        static RecipeTypeValueInfo* getInstance();

        void printValue();
        bool isGroupRecipe();
        bool isFatherChildRecipe();
    private:
        void createValueInfo();

    private:
        static RecipeTypeValueInfo* m_instance;
        ReadWriteInt* m_pRecipeType;
        bool m_bGroupRecipe;
        bool m_bFatherChildRecipe;
};

#endif /* SRC_COMMON_RECIPETYPEVALUEINFO_H_ */
