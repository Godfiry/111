/********************************************************************
** Copyright (c) 2018, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: GeneratorHuttinger3000DNet.cpp
** Description: Product Specification 400KHz
*                Device Net
* 		 BaudRate:125
*       MacID:
** Release: 1.1
** Modification history:
** 					2023-5-16   wzd create
**
*********************************************************************/

#include "GeneratorHuttinger3000DNet.h"
#include "DeviceManager.h"
#include <iostream>
#include <sys/time.h>
#include <sstream>
#include <string.h>
#include "Converter.h"
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
#endif
using namespace std;

GeneratorHuttinger3000DNet::Com GeneratorHuttinger3000DNet::m_Commands[] = {{0, 0}, //0	reserved
											{4,0},//1.Byte4,Bit0 is Turn the RF output On/off
											{0,0},//reserve
											{4,3},//3.Byte4,Bit3,Frequency Offset
											{4,6},//4.Byte4,Bit 6,Level mode: 0 is Forward,1 is Load
											{2,7},//5.Byte2,Bit 7,turn pulsing:0 is Off,1 is on
											{0,0},//6.Byte0 and Byte1,set the power setpoint in watts to x, for
											{0,0},//7.Byte0 and Byte1,set the power setpoint in watts to x
											{3,0},//8,Byte3 ,set Pulse Frequency
											{2,0},//9.Byte2 Bit 0-6,set Pulse Duty
											//-----------------------------------------------------------------------------------
											{0,0},//10.Byte0 and Byte1,get output forward power
											{2,0},//11.Byte2 and Byte3,get output reverse power
											{9,0},//12.Byte7,get Pulse Frequency  //changed by wzd 1.1.42
											{8,0},//13.Byte6 Bit 0-6 ,get Pulse Duty
											{10,2},//14.Byte6,Bit2 Fault Status
											{10,4},//15.Byte8,Bit4,InterLock Status
											{10,0},//16.Byte8,Bit 0,LevelModeStatus: 0 is Forward,1 is Load
											{10,7},//17.Byte8,Bit7 ,Pulse Mode Status
											{4,0}//18.Byte4 and Byte7,get Actual frequency
};
GeneratorHuttinger3000DNet::GeneratorHuttinger3000DNet()
{
	m_pWriteBuffer = NULL;
	m_pReadBuffer = NULL;

	m_nLastLevelMode = 0;
	m_nLastPulseMode = 0;
	m_nLastRFOnOffControl = 0;
}

GeneratorHuttinger3000DNet::~GeneratorHuttinger3000DNet()
{
	if(m_pWriteBuffer != NULL)
	{
		delete m_pWriteBuffer;
		m_pWriteBuffer = NULL;
	}
	if(m_pReadBuffer != NULL)
	{
		delete m_pReadBuffer;
		m_pReadBuffer = NULL;
	}
}

bool GeneratorHuttinger3000DNet::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
	Com com = m_Commands[nChannelNum];

	unsigned char bitmask = 1;
	bitmask = bitmask << com.m_nBit;

	if(nValue == 1)
	{
		m_pWriteBuffer[com.m_nByte] = m_pWriteBuffer[com.m_nByte] | bitmask;
	}
	if(nValue == 0)
	{
		bitmask = ~bitmask;
		m_pWriteBuffer[com.m_nByte] = m_pWriteBuffer[com.m_nByte] & bitmask;
	}
	return m_deviceNet->writeByte(m_macID, m_pWriteBuffer);
}

bool GeneratorHuttinger3000DNet::writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
	Com com = m_Commands[nChannelNum];
	unsigned long temp;
	if(nChannelNum == 6 || nChannelNum == 7)//set power
	{
		temp = (unsigned long) (dValue * 4095.0 / typeInfo.getMax());
		//temp = (unsigned long) (dValue);
	}
	else if(nChannelNum == 8)//set Pulse Frequency
	{
		temp = (unsigned long) (dValue / 50.0);
		m_pWriteBuffer[com.m_nByte] = (unsigned char)(temp & 0xff);
		return m_deviceNet->writeByte(m_macID, m_pWriteBuffer);
	}
	else if (nChannelNum == 9)//set Pulse Duty
	{
		//if(temp >= 128)
		//{
			//temp = (unsigned long) (dValue - 128);//0x0000-0x03E8 ,representing a value from 0-100.0%
		//}
		//else
		//{
		temp = (unsigned long) (dValue);//0x0000-0x03E8 ,representing a value from 0-100.0%
		//}
		//m_pWriteBuffer[com.m_nByte] = (unsigned char)(temp & 0xff);
		m_pWriteBuffer[com.m_nByte] = (m_pWriteBuffer[com.m_nByte] & 0x80) | (unsigned char)(temp & 0xff);
		return m_deviceNet->writeByte(m_macID, m_pWriteBuffer);
	}
	else
	{
		return false;
	}

	m_pWriteBuffer[com.m_nByte] = (unsigned char)(temp & 0xff);
	m_pWriteBuffer[com.m_nByte + 1] = (unsigned char)((temp>>8) & 0xff);
	return m_deviceNet->writeByte(m_macID, m_pWriteBuffer);
}

bool GeneratorHuttinger3000DNet::readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
	Com com = m_Commands[nChannelNum];

	//memset(m_pReadBuffer, 0, m_deviceNet->getIBytesSize(m_macID));
	m_deviceNet->readByte(m_macID, m_pReadBuffer);
	unsigned int movebit = 1 << com.m_nBit;
	unsigned int temp = ((unsigned int)m_pReadBuffer[com.m_nByte]) & movebit;
	int nTempValue = temp >> com.m_nBit;
	if(nTempValue == 0 || nTempValue == 1)
	{
		*pValue = nTempValue;
		return true;
	}
	else
	{
		return false;
	}
}

bool GeneratorHuttinger3000DNet::readDouble(int nChannelNum, double *dValue, const DoubleTypeInfo &typeInfo)
{
	Com com = m_Commands[nChannelNum];
	//memset(m_pReadBuffer, 0, m_deviceNet->getIBytesSize(m_macID));
	m_deviceNet->readByte(m_macID, m_pReadBuffer);
	unsigned long temp=0;
	double dTempValue = 0;
	//temp = (((unsigned long)m_pReadBuffer[com.m_nByte]) & 0xff) + ((((unsigned long)m_pReadBuffer[com.m_nByte+1]) << 8) & 0xff00);
	if(nChannelNum == 10 || nChannelNum == 11)//get power
	{
		temp = (((unsigned long)m_pReadBuffer[com.m_nByte]) & 0xff) + ((((unsigned long)m_pReadBuffer[com.m_nByte+1]) << 8) & 0xff00);
		dTempValue = temp * typeInfo.getMax() / 4095.0;
		//dTempValue = temp;
	}
	else if(nChannelNum == 12)//get Pulse Frequency
	{
		temp = (((unsigned long)m_pReadBuffer[com.m_nByte]) & 0xff);
		dTempValue = temp * 50.0;
	}
	else if(nChannelNum == 13)//get Pulse Duty
	{
		temp = (((unsigned long)m_pReadBuffer[com.m_nByte]) & 0xff);
		if(temp >= 128)
		{
			dTempValue = temp - 128 ;//0x0000-0x03E8 ,representing a value from 0-100.0%
		}
		else
		{
			dTempValue = temp;
		}
	}
	else if(nChannelNum == 18)//get Actual Frequency
	{
		temp = (((unsigned long)m_pReadBuffer[com.m_nByte]) & 0xff) + ((((unsigned long)m_pReadBuffer[com.m_nByte+1]) << 8) & 0xff00) + ((((unsigned long)m_pReadBuffer[com.m_nByte+2]) << 16) & 0xff0000) + ((((unsigned long)m_pReadBuffer[com.m_nByte+3]) << 24) & 0xff000000);
		dTempValue = temp/1000.0;  //changed by wzd 1.1.42
	}
	else
	{
		return false;
	}
	*dValue = MathTool::Round(dTempValue,typeInfo.getAccuracy());
	return true;
}

void GeneratorHuttinger3000DNet::InitChannels(DeviceNode<GeneratorHuttinger3000DNet> *node)
{
	for(int i = 1; i <= 5; ++i)
	{
		node->registerWriteCh(i, &GeneratorHuttinger3000DNet::writeInt);
	}
	for(int i = 6; i <= 9; ++i)
	{
		node->registerWriteCh(i, &GeneratorHuttinger3000DNet::writeDouble);
	}
	for(int i = 10; i <= 13; ++i)
	{
		node->registerReadCh(i, &GeneratorHuttinger3000DNet::readDouble);
	}
	for(int i = 14; i <= 17; ++i)
	{
		node->registerReadCh(i, &GeneratorHuttinger3000DNet::readInt);
	}
	node->registerReadCh(18, &GeneratorHuttinger3000DNet::readDouble);  //add by wzd 1.1.42
	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &GeneratorHuttinger3000DNet::getStatus);
}

void GeneratorHuttinger3000DNet::initDevice()
{
	int nInBytesSize = m_deviceNet->getIBytesSize(m_macID);
	int nOutBytesSize = m_deviceNet->getOBytesSize(m_macID);

	m_pWriteBuffer = new char[nOutBytesSize];
	memset(m_pWriteBuffer, 0, nOutBytesSize);

	m_pReadBuffer = new char[nInBytesSize];
	memset(m_pReadBuffer, 0, nInBytesSize);
}

void GeneratorHuttinger3000DNet::init()
{
	DeviceNode<GeneratorHuttinger3000DNet> *pNode = new DeviceNode<GeneratorHuttinger3000DNet>(m_pollInterval, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
	if(!isSimulated())
	{
		InitChannels(pNode);
		initDeviceNet();
		initDevice();
	}
}
IMPLEMENT_DYNAMIC(GeneratorHuttinger3000DNet, IODevice )
BEGIN_MSG_MAP(GeneratorHuttinger3000DNet, IODevice )
    SET_V( init, GeneratorHuttinger3000DNet )
END_MSG_MAP

