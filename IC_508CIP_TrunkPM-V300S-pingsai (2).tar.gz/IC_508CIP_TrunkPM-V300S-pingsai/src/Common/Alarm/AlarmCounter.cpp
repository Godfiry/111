/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AlarmIDAssigner.h
** Description: 
** Release: 
** Modification history: 
**                   2010-10-19   lijj create
**      
***************************************************************************/
#include "AlarmCounter.h"
#include "AlarmManager.h"
#include "SysLogger.h"
#include "PMStatusInfo.h"
#include "CTCExport.h"

#include<iostream>
#ifdef IAP4_0
using namespace IAP::ALARM;
using namespace IAP::CORE;
using namespace IAP::CONDITION;
#endif
using namespace std;

AlarmCounter* AlarmCounter::m_instance = NULL;

AlarmCounter::AlarmCounter()
{
	m_fatalAlmExist = NULL;
	m_errorAlmExist = NULL;
	m_problemAlmExist = NULL;// [lvjw 1.1.15]

	m_blockAlmExist = NULL;

	m_fatalAlmCount = 0;
	m_errorAlmCount = 0;
	m_problemAlmCount = 0;// [lvjw 1.1.16]

	m_pBlockingAlarm = NULL;//added by mujy [2.0.4.2]
	m_nBlockAlmCount = 0;//added by mujy [2.0.4.2]

	m_pEnergyLeakingBottle = new EnergyLeakingBottle();// [lvjw 1.1.16]
	m_pEnergyLeakingBottle->setCapacity_s(5);
	m_pEnergyLeakingBottle->setEmptyListener(this);

	m_pAlarmStatusForJob = NULL;// [lvjw 1.1.16]
}

AlarmCounter::AlarmCounter(const AlarmCounter& pObj)
{
	m_fatalAlmExist = pObj.m_fatalAlmExist;
	m_errorAlmExist = pObj.m_errorAlmExist;
	m_problemAlmExist = pObj.m_problemAlmExist;

	m_blockAlmExist = pObj.m_blockAlmExist;

	m_fatalAlmCount = pObj.m_fatalAlmCount;
	m_errorAlmCount = pObj.m_errorAlmCount;
	m_problemAlmCount = pObj.m_problemAlmCount;

	m_pBlockingAlarm = pObj.m_pBlockingAlarm;
	m_nBlockAlmCount = pObj.m_nBlockAlmCount;

	m_pEnergyLeakingBottle = new EnergyLeakingBottle();
	m_pEnergyLeakingBottle->setCapacity_s(5);
	m_pEnergyLeakingBottle->setEmptyListener(this);

	m_pAlarmStatusForJob = pObj.m_pAlarmStatusForJob;
}

AlarmCounter& AlarmCounter::operator=(const AlarmCounter& pObj)
{
	if (this != &pObj)
	{
		m_fatalAlmExist = pObj.m_fatalAlmExist;
		m_errorAlmExist = pObj.m_errorAlmExist;
		m_problemAlmExist = pObj.m_problemAlmExist;

		m_blockAlmExist = pObj.m_blockAlmExist;

		m_fatalAlmCount = pObj.m_fatalAlmCount;
		m_errorAlmCount = pObj.m_errorAlmCount;
		m_problemAlmCount = pObj.m_problemAlmCount;

		m_pBlockingAlarm = pObj.m_pBlockingAlarm;
		m_nBlockAlmCount = pObj.m_nBlockAlmCount;

		m_pEnergyLeakingBottle = new EnergyLeakingBottle();
		m_pEnergyLeakingBottle->setCapacity_s(5);
		m_pEnergyLeakingBottle->setEmptyListener(this);

		m_pAlarmStatusForJob = pObj.m_pAlarmStatusForJob;
	}
	return *this;
}

AlarmCounter::~AlarmCounter()
{
	// [lvjw 1.1.16]
	delete m_pEnergyLeakingBottle;
	m_pEnergyLeakingBottle = NULL;
}

AlarmCounter* AlarmCounter::getInstance()
{
	if(m_instance == NULL)
	{
		m_instance = new AlarmCounter();
	}
	return m_instance;
}

void AlarmCounter::make()
{
	if(!isMade())
	{
		#ifdef IAP4_0
		ManagedObject::make();
		#else
		AlarmObserver::make();
		#endif
		m_fatalAlmExist = new ReadWriteInt(getName() + "/FatalAlarmExist", IntTypeInfo(DescriptorList("No,Yes")));
		m_fatalAlmExist->setValue("No");//add by AtuoCodeChangeTool for IAP4.0
		m_errorAlmExist = new ReadWriteInt(getName() + "/ErrorAlarmExist", IntTypeInfo(DescriptorList("No,Yes")));
		m_errorAlmExist->setValue("No");//add by AtuoCodeChangeTool for IAP4.0
		m_problemAlmExist = new ReadWriteInt(getName() + "/ProblemAlmExist", IntTypeInfo(DescriptorList("No,Yes")));// [lvjw 1.1.16]
		m_problemAlmExist->setValue("No");//add by AtuoCodeChangeTool for IAP4.0
		m_blockAlmExist = new ReadWriteInt(getName() + "/BlockAlarmExist", IntTypeInfo(DescriptorList("No,Yes")));//added by mujy [2.0.4.2]
		CTCExport::exportAsOthers(m_blockAlmExist, "PM_BlockAlarmExist");//added by mujy [2.0.4.2]
		m_blockAlmExist->setValue(0);

		m_pAlarmStatusForJob =new ReadWriteInt(getName() + "/AlarmStatusForJob", IntTypeInfo(DescriptorList("NoAlarm, AlarmCanLeave, AlarmCannotLeave")));// [lvjw 1.1.16]
		m_pAlarmStatusForJob->setValue("NoAlarm");//add by AtuoCodeChangeTool for IAP4.0
		CTCExport::exportAsOthers(m_pAlarmStatusForJob, "PM_AlarmStatusForJob");// [lvjw 1.1.16]
	}
}
		
void AlarmCounter::initialize()
{
	if(!isInitialized())
	{
		#ifdef IAP4_0
		ManagedObject::initialize();
		#else
		AlarmObserver::initialize();
		#endif
		AlarmManager::getInstance()->subscribeAlarmEvent(this, Alarm::NOTICE, true);// [lvjw 1.1.16]
		//m_processStatus = m_processModule->getSlotSts();
	}
}
		
void AlarmCounter::updateFromAlarm(Alarm *alarm, bool flag, const std::string &timeStamp)
{
	// [lvjw 1.1.16]
	if(alarm->getSeverity() == Alarm::PROBLEM)
	{
		//cout<<"PROBLEM alarm"<<endl;
		if(flag)
		{
			onProblemAlmIncrease();
		}
		else
		{
			onProblemAlmDecrease();
		}
	}

	if(alarm->getSeverity() == Alarm::ERROR)
	{
		if(flag)
		{
			onErrorAlmIncrease();
		}
		else
		{
			onErrorAlmDecrease();
		}
	}
	
	if(alarm->getSeverity() == Alarm::FATAL)
	{
		if(flag)
		{
			onFatalAlmIncrease();
		}
		else
		{
			onFatalAlmDecrease();
		}
	}

	m_pBlockingAlarm = NULL;//added by mujy [2.0.4.2]
	m_pBlockingAlarm = dynamic_cast<BlockingAlarm*>(alarm);  

	if(NULL != m_pBlockingAlarm)
	{
		if(flag)
		{
			++m_nBlockAlmCount;
		}
		else
		{
			--m_nBlockAlmCount; 
		}
		
	}
	if(m_nBlockAlmCount == 0)
	{
		m_blockAlmExist->setValue(0);
	}
	else if(m_nBlockAlmCount >= 1)
	{
		m_blockAlmExist->setValue(1);
	}
}
		
void AlarmCounter::updateFromRecovery(Alarm *alarm, Recovery *recovery, bool flag, const std::string &timeStamp)
{	
}	

ReadWriteInt* AlarmCounter::getFatalAlmExistData()const
{
	return m_fatalAlmExist;
}
		
ReadWriteInt* AlarmCounter::getErrorAlmExistData()const
{
	return m_errorAlmExist;
}

// [lvjw 1.1.16]
ReadWriteInt* AlarmCounter::getProblemAlmExistData()const
{
	return m_problemAlmExist;
}

AppConditionPtr AlarmCounter::getFatalAlmExistCon()const
{
	return new AppCondition(m_fatalAlmExist, "==", 1);
}

/*void AlarmCounter::setProcessModule(OperationalProcess *processModule)
{
	m_processModule = processModule;
}*/

bool AlarmCounter::hasFatalAlarm()
{
	return m_fatalAlmExist->getValue() == 1;
}
		
bool AlarmCounter::hasErrorAlarm()
{
	return m_errorAlmExist->getValue() == 1;
}

// [lvjw 1.1.16]
bool AlarmCounter::hasProblemAlarm()
{
	return m_problemAlmExist->getValue() == 1;
}

// [lvjw 1.1.16]
void AlarmCounter::onAllErrorFatalAlarmCleared()
{
	m_pEnergyLeakingBottle->fillUp();
}

// [lvjw 1.1.16]
void AlarmCounter::onNewErrorFatalAlarmPost()
{
	m_pEnergyLeakingBottle->flush();
	m_pAlarmStatusForJob->setValue("AlarmCannotLeave");
}

// [lvjw 1.1.16]
void AlarmCounter::onAllProblemAlarmCleared()
{
	//if(!(hasErrorAlarm()||hasFatalAlarm()))//may not pass 5second!!!!!
	if(m_pAlarmStatusForJob->getValueAsDescriptor()=="AlarmCanLeave")
	{
		m_pAlarmStatusForJob->setValue("NoAlarm");
	}
}

// [lvjw 1.1.16]
void AlarmCounter::onNewProblemAlarmPost()
{
	//cout<<"onNewProblemAlarmPost"<<endl;
	if(m_pAlarmStatusForJob->getValueAsDescriptor()=="NoAlarm")
	{
		m_pAlarmStatusForJob->setValue("AlarmCanLeave");
	}
}

// [lvjw 1.1.16]
void AlarmCounter::onAllErrorFatalAlarmCleared5Seconds()
{
	if(hasProblemAlarm())
	{
		m_pAlarmStatusForJob->setValue("AlarmCanLeave");
	}
	else
	{
		m_pAlarmStatusForJob->setValue("NoAlarm");
	}
}

// [lvjw 1.1.16]
void AlarmCounter::onEnergyLeakingBottleEmpty()
{
	onAllErrorFatalAlarmCleared5Seconds();
}

// [lvjw 1.1.16]
void AlarmCounter::onFatalAlmIncrease()
{
	++m_fatalAlmCount;
	m_fatalAlmExist->setValue(1);
	onNewErrorFatalAlarmPost();
}

// [lvjw 1.1.16]
void AlarmCounter::onErrorAlmIncrease()
{
	++m_errorAlmCount;
	m_errorAlmExist->setValue(1);
	onNewErrorFatalAlarmPost();
}

// [lvjw 1.1.16]
void AlarmCounter::onProblemAlmIncrease()
{
	//cout<<"onProblemAlmIncrease"<<endl;
	++m_problemAlmCount;
	m_problemAlmExist->setValue(1);
	onNewProblemAlarmPost();
}

// [lvjw 1.1.16]
void AlarmCounter::onFatalAlmDecrease()
{
	--m_fatalAlmCount;
	if(m_fatalAlmCount == 0)
	{
		m_fatalAlmExist->setValue(0);
		if(m_errorAlmCount == 0)
		{
			onAllErrorFatalAlarmCleared();
		}
	}
}

// [lvjw 1.1.16]
void AlarmCounter::onErrorAlmDecrease()
{
	--m_errorAlmCount;
	if(m_errorAlmCount == 0)
	{
		m_errorAlmExist->setValue(0);
		if(m_fatalAlmCount == 0)
		{
			onAllErrorFatalAlarmCleared();
		}
	}
}

// [lvjw 1.1.16]
void AlarmCounter::onProblemAlmDecrease()
{
	--m_problemAlmCount;
	if(m_problemAlmCount == 0)
	{
		m_problemAlmExist->setValue(0);
		onAllProblemAlarmCleared();
	}
}

