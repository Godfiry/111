/********************************************************************
** Copyright (c) 2018, Beijing NAURA Co.,Ltd.  All rights reserved.
** File name: PulseGeneratorMksEdge.h
** Description: Used by
** 				[
** 					Product Specification 400KHz,1.5KW,Pulsing RF Generator MKS Model Number EDGE 15R40A-D02
** 					Product 2M, 60M MKS Pulsing RF Generator
** 			    ]
*                RS232
* 		 		 BaudRate:19200
*                DataBit:8
*                StopBit:1
*                Parity:No parity
*                FlowControl:no flow control
** Release: 1.1
** Modification history: 
** 					2018-9-6    mujy create
**      			2020-2-24   mujy modified
*********************************************************************/
#ifndef PULSEGENERATORMKSEDGE_H_
#define PULSEGENERATORMKSEDGE_H_

#include "SerialDevice.h"
#include "DeviceNode.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class PulseGeneratorMksEdge : public SerialDevice
{
    DECLARE_DYNAMIC(PulseGeneratorMksEdge)
    DECLARE_MSG_MAP

public:
 	PulseGeneratorMksEdge();
   virtual ~PulseGeneratorMksEdge();
  
public://xml
	void init();

public://read and write function    
	bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
	bool writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo);
	bool writeString(int nChannelNum, std::string strValue, const StringTypeInfo &typeInfo);
	bool writeRawCommand(int nChannelNum, std::string strValue, const StringTypeInfo &typeInfo);
	bool readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);
	bool readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);	
	void addInitCommand(const string& strCommand);
	
protected:
	bool sendCommand(std::string strCommand, int nTimeOut);
	std::string readCommand(std::string strCommand, int nTimeOut);	
	void InitChannels(DeviceNode<PulseGeneratorMksEdge> *pNode);
	void initDevice();
	void setMaxFreq(std::string freq);

private:
	typedef struct
	{
		int m_nCmdType;
		std::string m_strCmd;
		int m_nCmdValueDeal;
	}Com; 

	static Com m_Commands[];

	double m_dPulseFrequency;
	double m_dPulseDuty;
	std::string m_strMaxFreq;
	
	vector<string> m_vecInitCommand;
};
#endif /*PULSEGENERATORMKSEDGE_H_*/
