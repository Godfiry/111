/******************************************************************************
** Copyright (c) 2018, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MFC.h
** Description: RS-485 for GF100 Series Mass Flow Controller(MFC) Controllers and Meters.
*                RS485
* 				   BaudRate:38400
*                DataBit:8
*                StopBit:1
*                Parity:none
*                Byte order:LSB first
*                         
** Release: 1.1
 *   
 *
 * Modified:
 * the channels as below will be delete in release version because those are unuseful:
 * MFC*_alarmAT/MFC*VoltageAT/MFC*_valveSP
 ******************************************************************************/
#ifndef MFC_H_
#define MFC_H_


#include "SerialDevice.h"
#include "DeviceNode.h"
#include "FileLogger.h" //added by mujy 20151027	
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class MFC : public SerialDevice
{
    DECLARE_DYNAMIC(MFC)	
    DECLARE_MSG_MAP

private:
    static const int MAX_MESSAGE_LEN = 200;
    static const int OFFLINE = 0;
    static const int ONLINE = 1;
    static const int READ = 0;
    static const int WRITE = 1;
    int   GetMFCCheckSum(char * buff);
    
    static const int write_message_length = 11;  /* message length for transmiting the message */
    static const int read_message_length = 9;
    static const int receive_message_length = 21;  /* message length for receiving the message */
    static const int receive_alarm_length = 23;  /* message length for receiving the message */
    static const int msg_timeout = 10;/*timeout in deciseconds before deciding that message has failed*/
    
    int status;

    char Message[MAX_MESSAGE_LEN];
    char Response[MAX_MESSAGE_LEN];
		
    FileLogger m_logger;//added by mujy 20151027		
public:
    MFC();
    virtual ~MFC();
    void init();
    bool WriteCt(int channnelNum,double setpt ,const DoubleTypeInfo& typeinfo);
    bool ReadCt(int channnelNum, double *value  ,const DoubleTypeInfo& typeinfo);
    bool ReadVoltageCt( int channnelNum,double *value ,const DoubleTypeInfo& typeinfo);
    bool ReadADt( int channnelNum,int *value ,const IntTypeInfo& typeinfo);
	bool ReadStatusDt( int channnelNum,int *value ,const IntTypeInfo& typeinfo);
    bool WriteVDt( int channnelNum,int setpt  ,const IntTypeInfo& typeinfo);
    void InitMFC();
    void InitChannels(DeviceNode<MFC> *node);
    std::string hexToString(int value);//added by mujy 20151027	
};

#endif /*MFC_H_*/
