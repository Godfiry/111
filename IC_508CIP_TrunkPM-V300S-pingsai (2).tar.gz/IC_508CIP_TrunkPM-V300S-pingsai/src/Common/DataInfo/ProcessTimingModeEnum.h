#ifndef PROCESSTIMINGMODEENUM_H_
#define PROCESSTIMINGMODEENUM_H_

namespace PROCESS_TIMINGMODE
{
	enum ProcessTimingModeEnum
	{
		TimingAfterGas,
		TimingAfterRFStable
	};
}

#endif /*MODULESTATUSENUM_H_*/
