/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: COMETMatchDriver.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					
**                  2014-11-21   lijj	create
*********************************************************************/
#include "COMETMatchDriver.h"
#include "Converter.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std; 

COMETMatchDriver::COMETMatchDriver():SerialDevice(200,"\x0D")
{
	m_timeOut = 50;//5s
	m_nGetComResultTimeOut = 5;//added by xiasc[v1.6.14]
}

COMETMatchDriver::~COMETMatchDriver()
{
}

bool COMETMatchDriver::sendCommand(std::string command, int timeOut)
{
   SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "COMETMatchDriver sendCommand command =" +command);
   string res = getCommandResult(command, m_nGetComResultTimeOut);
   SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "COMETMatchDriver sendCommand res =" +res);
	//add by wzd [1.1.15 Reset]
	if(command == "Rest")
	{
		if(res.find(">\x0A",0) != string::npos)
		{
			return true;
		}
		else if(res.find("NAK\x0A\x0D",0) != string::npos)
		{
			throw IOException(getDeviceName()+" send command ["+command+"] occurred error [" + Hex::GetHexString(res.c_str(),res.size())+"]");
		}
		else if(res.find("NAI\x0A\x0D",0) != string::npos)
		{
			throw IOException(getDeviceName()+" send inactive command ["+command+"], response is "+Hex::GetHexString(res.c_str(),res.size()));
		}
		else
		{
			throw IOException(getDeviceName()+" send command ["+command+"] failed for unknown read back [" + Hex::GetHexString(res.c_str(),res.size())+"]");
		}
	}
	int t_lefttime = timeOut - m_nGetComResultTimeOut;
	while(res.find("\x0D",0) == string::npos)
	{	
		res += getResultOnly(m_nGetComResultTimeOut);
		t_lefttime -= m_nGetComResultTimeOut;
		if(t_lefttime<0)
		{
			throw IOException(getDeviceName()+" send command ["+command+"] failed for response ["+Hex::GetHexString(res.c_str(),res.size())+"] is invalid.");
		}		
	}

	if(res.find(">\x0A\x0D",0) != string::npos)
	{	
		return true;
	}
	else if(res.find("NAK\x0A\x0D",0) != string::npos)
	{
		throw IOException(getDeviceName()+" send command ["+command+"] occurred error [" + Hex::GetHexString(res.c_str(),res.size())+"]");
	}
	else if(res.find("NAI\x0A\x0D",0) != string::npos)
	{
		throw IOException(getDeviceName()+" send inactive command ["+command+"], response is "+Hex::GetHexString(res.c_str(),res.size()));
	}	
	else
	{
		throw IOException(getDeviceName()+" send command ["+command+"] failed for unknown read back [" + Hex::GetHexString(res.c_str(),res.size())+"]");
	}		

}
		
std::string COMETMatchDriver::readCommand(std::string command, int timeOut)
{
	string res = getCommandResult(command, m_nGetComResultTimeOut);
	int t_lefttime = timeOut - m_nGetComResultTimeOut;
	while(res.find("\x0D",0) == string::npos)
	{	
		res += getResultOnly(m_nGetComResultTimeOut);
		t_lefttime -= m_nGetComResultTimeOut;
		if(t_lefttime<0)
		{
			throw IOException(getDeviceName()+" read command ["+command+"] failed for response ["+Hex::GetHexString(res.c_str(),res.size())+"] is invalid");
		}		
	}	
	size_t t_pos  = res.find("\x0A\x0D",0);  //changed by wzd 1.1.39
	if(res.find("NAK\x0A\x0D",0) != string::npos)
	{
		throw IOException(getDeviceName()+" read command ["+command+"] occurred error [" + Hex::GetHexString(res.c_str(),res.size())+"]");
	}
	else if(res.find("NAI\x0A\x0D",0) != string::npos)
	{
		throw IOException(getDeviceName()+" read inactive command ["+command+"], response is ["+Hex::GetHexString(res.c_str(),res.size())+"]");
	}	
	else if(t_pos != string::npos)
	{
		return res.substr(0, t_pos);
	}	
	else
	{
		throw IOException(getDeviceName()+" read command ["+command+"] failed for unknown read back [" + Hex::GetHexString(res.c_str(),res.size())+"]");
	}		
}

void COMETMatchDriver::setGetComResultTimeout(int ms)//added by xiasc[v1.6.14]
{
	m_nGetComResultTimeOut = ms/100;
}

IMPLEMENT_DYNAMIC(COMETMatchDriver, SerialDevice )
BEGIN_MSG_MAP(COMETMatchDriver, SerialDevice )
   SET_I( setGetComResultTimeout, COMETMatchDriver )//added by xiasc[v1.6.14]
END_MSG_MAP

