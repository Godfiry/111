#include "BlockingAlarmEX.h"
using namespace std;

BlockingAlarmEX::BlockingAlarmEX(const string &name, const string &message, const string &description,
								Severity severity):BlockingAlarm(name, message, description, severity)
{
}

BlockingAlarmEX::~BlockingAlarmEX()
{
}

void BlockingAlarmEX::setMessage(const std::string &strMessage)
{
	Alarm::setMessage(strMessage);
}

void BlockingAlarmEX::setDescription(const std::string &strDescription)
{
	Alarm::setDescription(strDescription);
}


void BlockingAlarmEX::setMessage(int nStringID)
{
	setMessage(str(nStringID));
}

void BlockingAlarmEX::setDescription(int nStringID)
{
	setDescription(str(nStringID));
}

