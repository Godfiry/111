/********************************************************************
** Copyright (c) 2019 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: PLCRPDevice.h
** Description:  
** Release: 1.0
** Modification history:           
** 					2020-12-28   Duq create
**                                                 
*********************************************************************/

#ifndef PLCRPDEVICE_H_
#define PLCRPDEVICE_H_

#include "PLCDevice.h"
#include "DeviceNode.h"
#include "MonitorDoubleValue.h" //[zhangcx v1.5.0]

#define MONITORDOUBLEVALUEADDMAP 200  //[zhangcx v1.5.0]

class PLCRPDevice:public PLCDevice,public CMonitorDoubleValue
{
	DECLARE_DYNAMIC(PLCRPDevice)
	DECLARE_MSG_MAP	
	
	public:
		
		PLCRPDevice();
		virtual ~PLCRPDevice();
		
		bool writeDoubleAO(int channelNum, double value, const DoubleTypeInfo &typeInfo);//write double AO
		bool readDoubleAIWithOffSet(int channelNum, double *value, const DoubleTypeInfo &typeInfo);//read double AI with OffSet
		bool readDoubleAI(int channelNum, double *value, const DoubleTypeInfo &typeInfo);
        bool writeRFVoltageAO(int channelNum, double value, const DoubleTypeInfo &typeInfo);//write double AO
		virtual void init();
		virtual void initChs(DeviceNode<PLCRPDevice> *node);

        double RFMaxSetVoltage;
};

#endif  /*PLCRPDEVICE_H_*/
