/*
 * EtherCatBaseDevice.cpp
 *
 *  Created on: 2023��11��2��
 *      Author: liusiyuan
 */

#include "EtherCatBaseDevice.h"
#include "Converter.h"
#include "StrTool.h"
#include <iostream>
#include <unistd.h>
#include <string.h>

#include "DeviceManager.h"
#include "IODevice.h"
#include "Hex.h"
#ifdef CIFXDN
#include "EtherCatCIFX.h"
#warning CIFXDEVNET
#endif
#include <string.h>
#include "ConfigException.h"
#include "MathTool.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
using namespace IAP;
#endif

EtherCat* EtherCatBaseDevice::m_EtherCat = NULL;

EtherCatBaseDevice::EtherCatBaseDevice() {
	// TODO Auto-generated constructor stub
	m_pWriteBuffer = NULL;
	m_pReadBuffer = NULL;
	m_nMacID = -1;
	m_nodeNum = 0;
	m_bDebugEnable = false;
	m_nEtherCatTotalNum = -1;
	m_pollInterval = 200;
	m_TimeOut = -1;
}

EtherCatBaseDevice::~EtherCatBaseDevice() {
	// TODO Auto-generated destructor stub
	if(!isSimulated())
	{
		if(m_EtherCat != NULL)
		{
			delete m_EtherCat;
			m_EtherCat = NULL;
		}
		if(m_pWriteBuffer != NULL)
		{
			delete m_pWriteBuffer;
			m_pWriteBuffer = NULL;
		}
		if(m_pReadBuffer != NULL)
		{
			delete m_pReadBuffer;
			m_pReadBuffer = NULL;
		}

	}
}

bool EtherCatBaseDevice::readBit(int channelNum, int *bit, const IntTypeInfo &typeInfo)
{
	int nIndex = channelNum;

	DigitalParam* dp = &(m_deviceParam.m_Input.m_vDIParam.at(nIndex));
	//only support 2 byte(16bit) or 1 byte(8bit) to read
	if (dp->m_nBitOffset > 16)
	{
		throw IOException(" bit offset need less than 16, support 1 or 2 byte");
	}

	m_EtherCat->readByte(m_nMacID, m_pReadBuffer);

	//1 byte handle
	if (dp->m_nByteSize == 1 && dp->m_nBitOffset < 9)
	{
		int bitTemp = m_pReadBuffer[dp->m_nByteOffset];
		*bit = (bitTemp & (0x01 << (dp->m_nBitOffset - 1))) != 0 ? 1 : 0; 
		return true;
	}

	//2 byte handle
	if (dp->m_nByteSize == 2 && dp->m_nBitOffset < 17)
	{
		int datalow = (m_pReadBuffer[dp->m_nByteOffset] & 0xff); // low 8 byte
		int datahigh = (m_pReadBuffer[dp->m_nByteOffset + 1] & 0xff);// high 8 byte
		int data = ((datahigh << 8) | datalow);
		*bit = (data >> (dp->m_nBitOffset - 1)) & 0x01;

		return true;
	}
	
	return false;
}

bool EtherCatBaseDevice::writeBit(int channelNum, int bit, const IntTypeInfo &typeInfo)
{
	int nIndex = channelNum - 200;

	DigitalParam* dp = &(m_deviceParam.m_Output.m_vDOParam.at(nIndex));

	//only support 2 byte 16bit
	if (dp->m_nBitOffset > 16)
	{
		throw IOException(" bit offset need less than 8, support 2 byte");
	}

	
	if (dp->m_nByteSize == 2 && dp->m_nBitOffset > 8)//high 8 bit
	{
		if (bit == 1)
		{
			m_pWriteBuffer[dp->m_nByteOffset + 1] |= (0x01 << (dp->m_nBitOffset - 9));//set 1
		}
		else
		{
			m_pWriteBuffer[dp->m_nByteOffset + 1] &= (~(0x01 << (dp->m_nBitOffset - 9)));//set 0	
		}

	}
	else if (dp->m_nBitOffset > 0 && dp->m_nBitOffset <= 8)//low 8 bit
	{
		if (bit == 1)
		{
			m_pWriteBuffer[dp->m_nByteOffset] |= (0x01 << (dp->m_nBitOffset - 1));//set 1
		}
		else
		{
			m_pWriteBuffer[dp->m_nByteOffset] &= (~(0x01 << (dp->m_nBitOffset - 1)));//set 0	
		}
	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, " the Byte > 2 !");
		return false;
	}
	
	m_EtherCat->writeByte(m_nMacID, m_pWriteBuffer);
	return true;
}

bool EtherCatBaseDevice::readAnalog(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	int nIndex = channelNum - 400;

	AnalogParam* ap = &(m_deviceParam.m_Input.m_vAIParam.at(nIndex));
	int nType = ap->m_nType;
	bool flag = m_EtherCat->readByte(m_nMacID, m_pReadBuffer);
	
	double pdValue = 0.0;
	
	if(1 == nType || 2 == nType)//sint || usint
	{
		unsigned char cByte[1];
		memcpy(cByte, m_pReadBuffer + ap->m_nByteOffset, 1);
		int data = (cByte[0] & 0xff);
		pdValue = (double)data;
	}
	else if(3 == nType || 4 == nType || 7 == nType)//int || uint || word
	{
		unsigned char cByte[2];
		memcpy(cByte, m_pReadBuffer + ap->m_nByteOffset, 2);
		short sTempValue = (short)(((cByte[1] & 0xff) << 8) | (cByte[0] & 0xff));
		pdValue = (double)sTempValue;
	}
	else if(5 == nType || 6 == nType || 8 == nType)//dint || udint || dword
	{
		unsigned char cByte[4];
		memcpy(cByte, m_pReadBuffer + ap->m_nByteOffset, 4);
		int data1 = (cByte[0] & 0xff);
		int data2 = (cByte[1] & 0xff);
		int data3 = (cByte[2] & 0xff);
		int data4 = (cByte[3] & 0xff);
		
		int data = (data4 << 24) |(data3 << 16) |(data2 << 8) | data1;
		pdValue = (double)data;
	}
	else if(9 == nType)//real
	{
		unsigned char cByte[4];
		memcpy(cByte, m_pReadBuffer + ap->m_nByteOffset, 4);
		pdValue = *(float*)&cByte;
	}

	double dTempValue = pdValue*(ap->m_dMax - ap->m_dMin)/ap->m_dRange +ap->m_dMin;
	*value = MathTool::Round(dTempValue,typeInfo.getAccuracy());//[zhangcx v1.1.52]
	//*value = dTempValue;

	return true;
}

void EtherCatBaseDevice::FloatToByte(float floatNum, unsigned char* byteArry)
{
    char* pchar=(char*)&floatNum;
    for(int i=0;i<sizeof(float);i++) //4
    {
		*byteArry=*pchar;
		pchar++;
		byteArry++;
    }
}

bool EtherCatBaseDevice::writeAnalog(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
	int nIndex = channelNum - 600;

	AnalogParam* ap = &(m_deviceParam.m_Output.m_vAOParam.at(nIndex));
	int nOffset = ap->m_nByteOffset;
	int nType = ap->m_nType;
	
	//double dTempValue = pdValue*(ap->m_dMax - ap->m_dMin)/ap->m_dRange +ap->m_dMin;
	//AnalogParam temp = m_EtherCatDevice[nMacID].m_Output.m_vAOParam.at(nVectorIndex);	
	double dTempValue = (value - ap->m_dMin)*ap->m_dRange/(ap->m_dMax - ap->m_dMin);
	cout<<dTempValue<<endl;
	if(1 == nType || 2 == nType)//sint || usint
	{
		m_pWriteBuffer[nOffset] = ((int)dTempValue & 0xff);
	}
	else if(3 == nType || 4 == nType || 7 == nType)//int || uint || word
	{
		m_pWriteBuffer[nOffset] = ((int)dTempValue & 0xff);	
		m_pWriteBuffer[nOffset+1] = (((int)dTempValue >> 8) & 0xff);
		//cout<<m_pWriteBuffer[nOffset] <<","<<m_pWriteBuffer[nOffset+1]<<endl;
					
	}
	else if(5 == nType || 6 == nType || 8 == nType)//dint || udint || dword
	{
		m_pWriteBuffer[nOffset] = ((int)dTempValue & 0xff);	
		m_pWriteBuffer[nOffset+1] = (((int)dTempValue >> 8) & 0xff);	
		m_pWriteBuffer[nOffset+2] = (((int)dTempValue >> 16) & 0xff);	
		m_pWriteBuffer[nOffset+3] = (((int)dTempValue >> 24) & 0xff);
	}
	else if(9 == nType)//real
	{
		unsigned char msg[4];

		FloatToByte(dTempValue, msg);

		m_pWriteBuffer[nOffset] = msg[0];
		m_pWriteBuffer[nOffset+1] = msg[1];
		m_pWriteBuffer[nOffset+2] = msg[2];
		m_pWriteBuffer[nOffset+3] = msg[3];	
	}

	if (m_bDebugEnable)
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName()+" send: " + Hex::GetHexString(m_pWriteBuffer, m_deviceParam.m_Output.m_nByteSize));
	}

	m_EtherCat->writeByte(m_nMacID, m_pWriteBuffer);

	return true;
}

bool EtherCatBaseDevice::readInt(int channelNum, int *Value, const IntTypeInfo &typeInfo) //add by zhangpf[1.1.57_HotFix2]
{
	*Value = 0;
	return true;
}

bool EtherCatBaseDevice::readEcatStatus(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)  //add by wzd 1.1.65 hotfix4
{
	*pValue = 1;//connect
	return true;
}

bool EtherCatBaseDevice::writeInt(int channelNum, int Value, const IntTypeInfo &typeInfo)  //add by zhangpf[1.1.57_HotFix2]
{
	return true;
}
void EtherCatBaseDevice::initChs(DeviceNode<EtherCatBaseDevice> *node)
{


	for(int i = 0; i < 0+(m_deviceParam.m_Input.m_vDIParam).size(); ++i)
	{
		node->registerReadCh(i, &EtherCatBaseDevice::readBit);
	}
	for(int i = 200; i < 200+(m_deviceParam.m_Output.m_vDOParam).size(); ++i)
	{
		node->registerWriteCh(i, &EtherCatBaseDevice::writeBit);
	}
	for(int i = 400; i < 400+(m_deviceParam.m_Input.m_vAIParam).size(); ++i)
	{
		node->registerReadCh(i, &EtherCatBaseDevice::readAnalog);
	}
	for(int i = 600; i < 600+(m_deviceParam.m_Output.m_vAOParam).size(); ++i)
	{
		node->registerWriteCh(i, &EtherCatBaseDevice::writeAnalog);
	}
	//node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &EtherCatBaseDevice::getStatus);//added by mujy[v1.0.8]

}

void EtherCatBaseDevice::initDevice()
{

}

void EtherCatBaseDevice::initDeviceNet()
{
	if(m_EtherCat == NULL)
	{
		#ifdef CIFXDN
				m_EtherCat = new EtherCatCIFX();
				#warning CIFXDEVNET
		#endif
	}
	if(m_EtherCat != NULL)
	{
	if(m_nEtherCatTotalNum > 0 )
	{
		m_EtherCat->setDeviceNum(m_nEtherCatTotalNum);
	}
	if(m_TimeOut > 0)
	{
		m_EtherCat->setTimeOut(m_TimeOut);
	}

	if (m_bDebugEnable != false)
	{
		m_EtherCat->setDebugMode(m_bDebugEnable);
	}

	m_EtherCat->addDeviceParam(m_nMacID, &m_deviceParam);
	}
}

void EtherCatBaseDevice::init()
{
	DeviceNode<EtherCatBaseDevice> * node = new DeviceNode<EtherCatBaseDevice>(m_pollInterval,this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	initDeviceNet();
	if(!isSimulated())
	{
		cout<<"EtherCatBaseDevice::init() ,macid = "<<m_nMacID<<endl;
		initChs(node);
		string error = "";

		int outBytesSize = m_deviceParam.m_Output.m_nByteSize;
		int inBytesSize = m_deviceParam.m_Input.m_nByteSize;

		m_EtherCat->loadDevice();
		m_pWriteBuffer = new char[outBytesSize];
		m_pReadBuffer = new char[inBytesSize];

		memset(m_pWriteBuffer, 0, outBytesSize);
		memset(m_pReadBuffer, 0, inBytesSize);
		initDevice();
	}
}

void EtherCatBaseDevice::setNodeNum(int nodeNum)
{
	if(nodeNum < 0)
	{
		throw ConfigException("IODevice: illegal NodeNum");
	}
	m_nodeNum = nodeNum;
}

void EtherCatBaseDevice::setEtherCatDeviceTotalNum(int nNum)
{
	m_nEtherCatTotalNum = nNum;
}

bool EtherCatBaseDevice::StringToList(string strSource, vector<int> &vlist)
{
	vector<string> vStrList = StrTool::split(strSource,",");
	if(m_bDebugEnable)
	{
		cout<<"EtherCatBase::StringToList : strSource= " <<strSource<<endl;
	}
	for(int i =0;i<vStrList.size();i++)
	{
		int nTemp = 0;
		if(vStrList[i].find("true") != string::npos)
		{
			vlist.push_back(Simulated);
			//vStrList[i] = "0" + Simulated;
		}
		else if(vStrList[i].find("false") != string::npos)
		{
			vlist.push_back(NotSimulated);
			//vStrList[i] = "0" + NotSimulated;
		}
		else if(Converter::stringToInt(nTemp,vStrList[i]))
		{
			vlist.push_back(nTemp);
		}
		else
		{
			return false;
		}

		if(m_bDebugEnable)
		{
			cout<<"EtherCatBase::StringToList : vList i = " <<i << " ,value = "<<vlist[i]<<endl;
		}
	}
	return true;
}

void EtherCatBaseDevice::setMacMap(string strData)
{
	vector<int> vList;
	if(!StringToList(strData,vList))
	{
		throw IOException("set Mac Map param is wrong");
	}


	if(vList.size() != 6)
	{
		throw IOException("set Mac Map's param size is wrong");
	}


	m_deviceParam.m_nMacID = vList[0];
	m_nMacID = vList[0];
	m_deviceParam.m_nDeviceMapIndex = vList[1];
	m_deviceParam.m_nChannelSize =vList[2];
	m_deviceParam.m_Input.m_nByteSize = vList[3];
	m_deviceParam.m_Output.m_nByteSize =vList[4];
	m_deviceParam.m_nSimulation = vList[5] == Simulated? Simulated : NotSimulated;
}

void EtherCatBaseDevice::addDeviceAO(string strData)
{
	vector<int> vList;
	if(!StringToList(strData,vList))
	{
		throw IOException("set AO param is wrong");
	}


	if(vList.size() != 6)
	{
		throw IOException("set AO param size is wrong");
	}

	AnalogParam aoParam;
	aoParam.m_nByteOffset = vList[0];
	aoParam.m_nByteSize = vList[1];
	aoParam.m_nType = vList[2];
	aoParam.m_dMin = vList[3];
	aoParam.m_dMax = vList[4];
	aoParam.m_dRange = vList[5];


	m_deviceParam.m_Output.m_vAOParam.push_back(aoParam);
	if(m_bDebugEnable)
	{
		cout<<"EtherCatBaseDevice::addDeviceAO : macid= " <<vList[0]<<endl;
	}

}

void EtherCatBaseDevice::addDeviceAI(string strData)
{
	vector<int> vList;
	if(!StringToList(strData,vList))
	{
		throw IOException("set AI param is wrong");
	}


	if(vList.size() != 6)
	{
		throw IOException("set AI param size is wrong");
	}
	//<addDeviceAIAOComment comment="mac,offset(ƫ�Ƶڼ���, byte),byte(�ֽ���),type:bool(1),usint(2),uint(3),udint(4),ulint(5),real(6),min,max,Range"></addDeviceDIDOAIAOComment>

	AnalogParam aiParam;
	aiParam.m_nByteOffset = vList[0];
	aiParam.m_nByteSize = vList[1];
	aiParam.m_nType = vList[2];
	aiParam.m_dMin = vList[3];
	aiParam.m_dMax = vList[4];
	aiParam.m_dRange = vList[5];


	m_deviceParam.m_Input.m_vAIParam.push_back(aiParam);

	if(m_bDebugEnable)
	{
		cout<<"EtherCatBaseDevice::addDeviceAI : macid= " <<vList[0]<<endl;
	}
}

void EtherCatBaseDevice::addDeviceDI(string strData)
{
	vector<int> vList;
	if(!StringToList(strData,vList))
	{
		throw IOException("set DI param is wrong");
	}


	if(vList.size() != 5)
	{
		throw IOException("set DI param size is wrong");
	}

	DigitalParam diParam;
	diParam.m_nByteOffset = vList[0];
	diParam.m_nByteSize = vList[1];
	diParam.m_nType = vList[4];
	diParam.m_nBitOffset = vList[2];
	diParam.m_nBitSize = vList[3];



	m_deviceParam.m_Input.m_vDIParam.push_back(diParam);
	if(m_bDebugEnable)
	{
		cout<<"EtherCatBaseDevice::addDeviceDI : macid= " <<vList[0]<<endl;
	}
}

void EtherCatBaseDevice::addDeviceDO(string strData)
{
	vector<int> vList;
	if(!StringToList(strData,vList))
	{
		throw IOException("set DO param is wrong");
	}


	if(vList.size() != 5)
	{
		throw IOException("set DO param size is wrong");
	}

	DigitalParam doParam;
	doParam.m_nByteOffset = vList[0];
	doParam.m_nByteSize = vList[1];
	doParam.m_nType = vList[4];
	doParam.m_nBitOffset = vList[2];
	doParam.m_nBitSize = vList[3];



	m_deviceParam.m_Output.m_vDOParam.push_back(doParam);

	if(m_bDebugEnable)
	{
		cout<<"EtherCatBaseDevice::addDeviceDO : macid= " <<vList[0]<<endl;
	}
}

void EtherCatBaseDevice::setDebugMode(bool bEnable)
{
	m_bDebugEnable = bEnable;
}

void EtherCatBaseDevice::setTimeOut(int time)
{
	m_TimeOut = time;
}

void EtherCatBaseDevice::setPollIntervalMS(int interval)
{
	m_pollInterval = interval;
}

IMPLEMENT_DYNAMIC(EtherCatBaseDevice, AbstractDevice )
BEGIN_MSG_MAP( EtherCatBaseDevice, AbstractDevice )
	SET_I( setTimeOut, EtherCatBaseDevice )
	SET_I( setNodeNum, EtherCatBaseDevice )
	SET_I( setEtherCatDeviceTotalNum, EtherCatBaseDevice )
	SET_I( setPollIntervalMS, EtherCatBaseDevice )
	SET_S( setMacMap, EtherCatBaseDevice )
	SET_S( addDeviceAO, EtherCatBaseDevice )
	SET_S( addDeviceAI, EtherCatBaseDevice )
	SET_S( addDeviceDI, EtherCatBaseDevice )
	SET_S( addDeviceDO, EtherCatBaseDevice )
	SET_B( setDebugMode, EtherCatBaseDevice)
	SET_V( init, EtherCatBaseDevice )
END_MSG_MAP
