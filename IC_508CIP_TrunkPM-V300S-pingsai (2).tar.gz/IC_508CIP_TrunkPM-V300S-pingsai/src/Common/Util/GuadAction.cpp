/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: GuadAction.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-9-28   LiJuanjuan create
**      
*********************************************************************/

#include "GuadAction.h"
#include "AlarmReNameManager.h"
#include "StrTool.h"
#include <iostream>
using namespace std;
GuadAction::GuadAction()
{
	m_nActionFailedAlarm = NULL;
	m_vIntlkName = "";
}

GuadAction::~GuadAction()
{
}

void GuadAction::make()
{
	ControlObject::make();
	
	string strPreName = getName();
	size_t nPos = strPreName.find(getSelfName());  //changed by wzd 1.1.39
	if(nPos != string::npos)
	{
		strPreName = strPreName.substr(0,nPos);
		vector<string> splitStr = StrTool::split(strPreName,"/");
		if(splitStr.size() >= 1)
		{
			strPreName = splitStr[splitStr.size()-1];
		}
	}
	m_nActionFailedAlarm = new NonBlockingAlarm(strPreName+"_ProtectActionFailedAlm","The safety action of " + m_vIntlkName + " failed", "Action failed", Alarm::ERROR);
	m_nActionFailedAlarm->addRecovery(new Recovery("Clear", Recovery::CLEAR));
}

void GuadAction::setIntlkName(const std::string &name)
{
	m_vIntlkName = name;
}

IMPLEMENT_JOINT(GuadAction, ControlObject)		

BEGIN_MSG_MAP( GuadAction, ControlObject )
END_MSG_MAP