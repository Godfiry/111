/*
 * N2BallastChamber.cpp
 *
 *  Created on: 2022-06-20
 *      Author: liusiyuan
 */

#include "N2BallastChamber.h"
#include "PendulumValve.h"
#include "PendulumGasRecipe.h"
#include "GasRecipe.h"
#include "SysLogger.h"
#include "ObjectManager.h"
#include "ConfigException.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "RetryException.h"
#include "InvalidNameException.h"
#endif

#include "TransferOperationInfo.h"
#include "ValveController.h"
#include "GasSource.h"
#include "Gasses.h"
#include "PendulumController.h"
#include "XmlGetter.h"
#include "ReadWriteInt.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
using namespace IAP::IO;
#endif

using namespace std;

N2BallastChamber::N2BallastChamber() {
    // TODO Auto-generated constructor stub
    m_pInnerDoor = NULL;

    m_pPressureController = NULL;
    m_pProcessGasIDs = NULL;
    m_pInnerDoor = NULL;

    m_pInnerDoorOpenSensor = NULL;
    m_pInnerDoorCloseSensor = NULL;
    m_pInnerDoorOpenWch = NULL;
    m_pInnerDoorCloseWch = NULL;

    m_pN2BallastPumpTimeAfterWAC = NULL;
    m_pN2BallastPumpTimeAfterProcess = NULL;
    m_pN2BallastPumpTimeBeforeWAC = NULL;
    m_pN2BallastPumpTimeBeforeProcess = NULL;
    m_pN2BallastPumpOutBeforePinDown = NULL;

    m_pRecipeBody = NULL;//added by liusy[1.1.43]
    m_nWACTimeMsBeforePinDown = 1000;//ms//added by liusy[1.1.43]

	m_pCfgPostOpenInnerDoorEnabled = NULL;//added by mujy [1.2.3] for PSEV300 WPH

	m_pPendulumValveFullyOpenAfterStopN2Ballast = NULL;//added by liwh[1.8.0]
}

N2BallastChamber::~N2BallastChamber() {
    // TODO Auto-generated destructor stub

}

void N2BallastChamber::make()
{
    try
    {
        m_pN2BallastPumpTimeAfterWAC = XmlGetter::getFromNamespace<ReadWriteDouble*>("/SETUP/Vacuum/N2BallastPumpTimeAfterWAC");
        m_pN2BallastPumpTimeAfterProcess = XmlGetter::getFromNamespace<ReadWriteDouble*>("/SETUP/Vacuum/N2BallastPumpTimeAfterProcess");
        m_pN2BallastPumpTimeBeforeWAC = XmlGetter::getFromNamespace<ReadWriteDouble*>("/SETUP/Vacuum/N2BallastPumpTimeBeforeWAC");
        m_pN2BallastPumpTimeBeforeProcess = XmlGetter::getFromNamespace<ReadWriteDouble*>("/SETUP/Vacuum/N2BallastPumpTimeBeforeProcess");
        m_pN2BallastPumpOutBeforePinDown = XmlGetter::getFromNamespace<ReadWriteDouble*>("/SETUP/Vacuum/N2BallastPumpOutBeforePinDown");
    }
    catch(...)
    {
        if(m_pN2BallastPumpTimeAfterWAC == NULL)
        {
            m_pN2BallastPumpTimeAfterWAC = new ReadWriteDouble();
            m_pN2BallastPumpTimeAfterWAC->setValue(0.5);
        }
        if(m_pN2BallastPumpTimeAfterProcess == NULL)
        {
            m_pN2BallastPumpTimeAfterProcess = new ReadWriteDouble();
            m_pN2BallastPumpTimeAfterProcess->setValue(0.5);
        }

        if(m_pN2BallastPumpTimeBeforeWAC == NULL)
        {
            m_pN2BallastPumpTimeBeforeWAC = new ReadWriteDouble();
            m_pN2BallastPumpTimeBeforeWAC->setValue(0.5);
        }

        if(m_pN2BallastPumpTimeBeforeProcess == NULL)
        {
            m_pN2BallastPumpTimeBeforeProcess = new ReadWriteDouble();
            m_pN2BallastPumpTimeBeforeProcess->setValue(3);
        }

        if(m_pN2BallastPumpOutBeforePinDown == NULL)
        {
            m_pN2BallastPumpOutBeforePinDown = new ReadWriteDouble();
            m_pN2BallastPumpOutBeforePinDown->setValue(3);
        }
    }

    //added by liwh[1.8.0]
    m_pPendulumValveFullyOpenAfterStopN2Ballast = XmlGetter::tryGetFromNamespace<ReadWriteInt>("/SETUP/Switch/cfgIsPendulumValveFullyOpenAfterStopN2Ballast",IntTypeInfo(DescriptorList("No:0,Yes:1")),1);
}

void N2BallastChamber::initialize()
{

    CmdTarget::initialize();
}

void N2BallastChamber::verifyInit()
{

    if(!m_pPressureController->hasSequence("N2Ballast"))
    {
        //throw ConfigException("PressureController no 'N2Ballast' sequence");
    }

    if(!m_pPressureController->hasSequence("StopN2Ballast"))
    {
        throw ConfigException("PressureController no 'StopN2Ballast' sequence");
    }

    if(!m_pPressureController->hasSequence("N2BallastbyPosition"))
    {
        throw ConfigException("PressureController no 'N2BallastbyPosition' sequence");
    }


    CmdTarget::verifyInit();
}

/*
void N2BallastChamber::doPrepChamber()
{
    //???
}
*/

bool N2BallastChamber::isEnabled()
{
    try
    {
        ReadWriteInt* pN2BallastEnabled = XmlGetter::getFromNamespace<ReadWriteInt*>("/SETUP/Vacuum/cfgChamberBallastEnabled");
        if(pN2BallastEnabled != NULL && pN2BallastEnabled->getValue() == 1)
        {
            return true;
        }
    }
    catch(...)
    {

    }
    return false;
}


void N2BallastChamber::setRcpBody(AppRcpBody *body)//added by liusy[1.1.43]
{
    m_pRecipeBody = body;
}

void N2BallastChamber::doPostExecuteRecipe(GassesToFlow *pGassesToFlow)//added by liusy[1.1.43]
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": about to do PostExecuteRecipe");
    try
    {
	    if(m_pInnerDoor != NULL && m_pCfgPostOpenInnerDoorEnabled != NULL && m_pCfgPostOpenInnerDoorEnabled->getValue() == 1)//added by mujy [1.2.3] for PSEV300 WPH
        {
           if(!isInnerDoorOpen())
           {
             m_pInnerDoorCloseWch->setValue(0);
             m_pInnerDoorOpenWch->setValue(1);
           }
           if(isSimulated())
           {
             m_pInnerDoorCloseSensor->setSimulatedValue(0);
             m_pInnerDoorOpenSensor->setSimulatedValue(1);
           }
        }

        for(int i = 0; i < m_pProcessGasIDs->getSize(); ++i)
        {
            if(m_pProcessGasIDs->getGasID(i) == "PendulumValve")
            {
                continue;
            }
            else
            {
                pGassesToFlow->getRecipeForGasAtIndex(i)->setGasFlowRate(0);
            }
        }
        m_pPressureController->beginToFlowGassesWith(pGassesToFlow);
        ((PendulumValve*)(m_pPressureController->getGasSource()->getTheGasses()->getGasValveForGasID("PendulumValve")))->getPendulumController()->do_SetPosition(1000);

        if(m_pPressureController->hasSequence("OpenValvesAfterProcessAndWACBeforeN2Ballast"))
        {
            m_pPressureController->call_RunSequence("OpenValvesAfterProcessAndWACBeforeN2Ballast");
        }


        if(m_pRecipeBody == NULL)//added by liusy[1.1.43]
        {
            usleep((long)(m_pN2BallastPumpTimeAfterProcess->getValue() * 1000000));
        }
        else if(m_pRecipeBody->getRcpClass() == "/DryClean")//added by liusy[1.1.43]
        {
            usleep((long)(m_pN2BallastPumpTimeAfterWAC->getValue() * 1000000));
        }
        else
        {
            usleep((long)(m_pN2BallastPumpTimeAfterProcess->getValue() * 1000000));
        }

        m_pPressureController->call_RunSequence("N2Ballast");
    }
    catch(const RetryException &ex)
    {
        throw;
    }
    catch(const exception &ex)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": PostExecuteRecipe failed for "+ ex.what());
        throw;
    }
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": done PostExecuteRecipe");
}

void N2BallastChamber::doPreExecuteRecipe()//added by liusy[1.1.43]
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": about to do PreExecuteRecipe");
    try
    {

        if(m_pInnerDoor != NULL)
                m_pInnerDoor->call_Close();

        m_pPressureController->call_RunSequence("StopN2Ballast");

        if(m_pPendulumValveFullyOpenAfterStopN2Ballast == NULL || m_pPendulumValveFullyOpenAfterStopN2Ballast->getValue() == 1)//added by liwh[1.8.0]
        {
        	((PendulumValve*)(m_pPressureController->getGasSource()->getTheGasses()->getGasValveForGasID("PendulumValve")))->getPendulumController()->do_SetPosition(1000);
        }

        if(m_pRecipeBody == NULL)//added by liusy[1.1.43]
        {
            usleep((long)(m_pN2BallastPumpTimeBeforeProcess->getValue() * 1000000));
        }
        else if(m_pRecipeBody->getRcpClass() == "/DryClean")//added by liusy[1.1.43]
        {
            usleep((long)(m_pN2BallastPumpTimeBeforeWAC->getValue() * 1000000));
        }
        else
        {
            usleep((long)(m_pN2BallastPumpTimeBeforeProcess->getValue() * 1000000));
        }
    }
    catch(const RetryException &ex)
    {
        throw;
    }
    catch(const exception &ex)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": PreExecuteRecipe failed for "+ ex.what());
        throw;
    }
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": done PreExecuteRecipe");
}

void N2BallastChamber::doGoToTransferPositionNoWait()
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": about to do GoToTransferPositionNoWait");
    try
    {

        m_pPressureController->call_RunSequence("N2BallastbyPosition");

        if(m_pInnerDoor != NULL)
        {
           if(!isInnerDoorOpen())
           {
             m_pInnerDoorCloseWch->setValue(0);
             m_pInnerDoorOpenWch->setValue(1);
           }
           if(isSimulated())
           {
             m_pInnerDoorCloseSensor->setSimulatedValue(0);
             m_pInnerDoorOpenSensor->setSimulatedValue(1);
           }
        }
    }
    catch(const exception &ex)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": GoToTransferPositionNoWait failed for "+ ex.what());
        throw;
    }
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": done GoToTransferPositionNoWait");
}

void N2BallastChamber::doGoToTransferPosition()//added by guojin[1.1.37]
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": about to do GoToTransferPosition");
    try
    {
        m_pPressureController->call_RunSequence("N2BallastbyPosition");

        if(m_pInnerDoor != NULL)
        {
            m_pInnerDoor->call_Open();
        }
    }
    catch(const exception &ex)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": GoToTransferPosition failed for "+ ex.what());
        throw;
    }
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": done GoToTransferPosition");
}

void N2BallastChamber::doCompleteTransferMaterial(int status, int slot)//added by guojin[1.1.37]
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": about to do CompleteTransferMaterial");

    try
    {
        if(m_pInnerDoor != NULL)
        {
            m_pInnerDoor->call_Close();
        }

        if(status==TransferOperationInfo::Receive)
        {
            m_pPressureController->call_RunSequence("StopN2Ballast");
            if(m_pRecipeBody == NULL || m_pRecipeBody->getRcpClass() == "/Process")//added by liusy[1.1.43]
            {
                usleep((long)(m_pN2BallastPumpOutBeforePinDown->getValue() * 1000000));
            }
            else
            {
                usleep(1000*m_nWACTimeMsBeforePinDown);
            }
        }
        else
        {
            ReadWriteDouble* m_cfgChamberBallastPressure = (ReadWriteDouble*)ObjectManager::getInstance()->getObject("/SETUP/Vacuum/cfgChamberBallastPressure");
            if(NULL != m_cfgChamberBallastPressure)
            {
                ((PendulumValve*)(m_pPressureController->getGasSource()->getTheGasses()->getGasValveForGasID("PendulumValve")))->getPendulumController()->do_SetPressure(m_cfgChamberBallastPressure->getValue());
            }
        }

    }
    catch(const exception &ex)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": CompleteTransferMaterial failed for "+ ex.what());
        throw;
    }

    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": done CompleteTransferMaterial");
}

void N2BallastChamber::doCompleteTransferMaterialNoWait(int status, int slot)
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": about to do CompleteTransferMaterialNoWait");

    try
    {
        if(m_pInnerDoor != NULL)
        {
           if(!isInnerDoorClose())
           {
             m_pInnerDoorOpenWch->setValue(0);
             m_pInnerDoorCloseWch->setValue(1);
           }
           if(isSimulated())
           {
             m_pInnerDoorOpenSensor->setSimulatedValue(0);
             m_pInnerDoorCloseSensor->setSimulatedValue(1);
           }
        }


        if(status==TransferOperationInfo::Receive)
        {
            //checkSlotValveClosed();//20180825lijj
            m_pPressureController->call_RunSequence("StopN2Ballast");
            if(m_pRecipeBody == NULL || m_pRecipeBody->getRcpClass() == "/Process")//added by liusy[1.1.43]
            {
                usleep((long)(m_pN2BallastPumpOutBeforePinDown->getValue() * 1000000));
            }
            else
            {
                usleep(1000*m_nWACTimeMsBeforePinDown);
            }

        }
        else
        {
            ReadWriteDouble* m_cfgChamberBallastPressure = (ReadWriteDouble*)ObjectManager::getInstance()->getObject("/SETUP/Vacuum/cfgChamberBallastPressure");
            if(NULL != m_cfgChamberBallastPressure)
            {
                ((PendulumValve*)(m_pPressureController->getGasSource()->getTheGasses()->getGasValveForGasID("PendulumValve")))->getPendulumController()->do_SetPressure(m_cfgChamberBallastPressure->getValue());
            }
        }

    }
    catch(const exception &ex)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": GoToTransferPositionNoWait failed for "+ ex.what());
        throw;
    }

    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": done CompleteTransferMaterialNoWait");
}


double N2BallastChamber::getN2BallastPumpTimeAfterWAC()//added by guojin[1.1.37]
{
    return m_pN2BallastPumpTimeAfterWAC->getValue();
}

double N2BallastChamber::getN2BallastPumpTimeAfterProcess()//added by guojin[1.1.37]
{
    return m_pN2BallastPumpTimeAfterProcess->getValue();
}

double N2BallastChamber::getN2BallastPumpTimeBeforeWAC()//added by guojin[1.1.37]
{
    return m_pN2BallastPumpTimeBeforeWAC->getValue();
}

double N2BallastChamber::getN2BallastPumpTimeBeforeProcess()//added by guojin[1.1.37]
{
    return m_pN2BallastPumpTimeBeforeProcess->getValue();
}

double N2BallastChamber::getN2BallastPumpOutBeforePinDown()//added by guojin[1.1.37]
{
    return m_pN2BallastPumpOutBeforePinDown->getValue();
}

bool N2BallastChamber::isInnerDoorOpen()
{
    if(m_pInnerDoor != NULL)
    {
       if((m_pInnerDoorOpenSensor->getValueAsDescriptor() == "Open")&&(m_pInnerDoorCloseSensor->getValueAsDescriptor() == "NO"))
       {
              SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ": the InnerDoorOpen sensor is open");
          return true;
       }
       else
       {
              SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ": the InnerDoorOpen sensor is NO");
          return false;
       }
    }
    else
    {
        return true;
    }
}

bool N2BallastChamber::isInnerDoorClose()
{
    if(m_pInnerDoor != NULL)
    {
       if((m_pInnerDoorOpenSensor->getValueAsDescriptor() == "NO")&&(m_pInnerDoorCloseSensor->getValueAsDescriptor() == "Close"))
       {
             SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ": the InnerDoorClose sensor is Close");
          return true;
       }
       else
       {
             SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ": the InnerDoorClose sensor is NO");
          return false;
       }
    }
    else
    {
        return true;
    }
}

void N2BallastChamber::setIsOpenInnerDoorWhenPostFlag(ReadWriteInt *pOpenInnerDoorWhenPost)//added by mujy [1.2.3]  for PSEV300 WPH
{
    m_pCfgPostOpenInnerDoorEnabled = pOpenInnerDoorWhenPost;
}

void N2BallastChamber::setProcessGasIDs(const std::string &path)
{
    ManagedObject *t_obj = NULL;
    try
    {
        t_obj = ObjectManager::getInstance()->getObject(this, path);
    }
    catch(const InvalidNameException &ex)
    {
        t_obj = ObjectManager::getInstance()->getObject(path);
    }
    GasIDs *t_obj2 = dynamic_cast<GasIDs*>(t_obj);
    if(NULL == t_obj2)
    {
        string error = "the object under path '" + path + "' is not a GasIDs";
        throw ConfigException(error);
    }
    m_pProcessGasIDs = t_obj2;
}

void N2BallastChamber::setPressureController(const std::string &path)
{
    ManagedObject *t_obj = NULL;
    try
    {
        t_obj = ObjectManager::getInstance()->getObject(this, path);
    }
    catch(const InvalidNameException &ex)
    {
        t_obj = ObjectManager::getInstance()->getObject(path);
    }
    PressureController *t_obj2 = dynamic_cast<PressureController*>(t_obj);
    if(NULL == t_obj2)
    {
        string error = "the object under path '" + path + "' is not a PressureController";
        throw ConfigException(error);
    }
    m_pPressureController = t_obj2;
}


void N2BallastChamber::setInnerDoorOpenSensor(const std::string &path)
{
   ManagedObject *t_obj = NULL;
    try
    {
        t_obj = ObjectManager::getInstance()->getObject(this, path);
    }
    catch(const InvalidNameException &ex)
    {
        t_obj = ObjectManager::getInstance()->getObject(path);
    }
    ReadOnlyInt *t_obj2 = dynamic_cast<ReadOnlyInt*>(t_obj);
    if(NULL == t_obj2)
    {
        string error = "the object under path '" + path + "' is not a ReadOnlyInt";
        throw ConfigException(error);
    }
    m_pInnerDoorOpenSensor = t_obj2;
}

void N2BallastChamber::setInnerDoorCloseSensor(const std::string &path)
{
   ManagedObject *t_obj = NULL;
    try
    {
        t_obj = ObjectManager::getInstance()->getObject(this, path);
    }
    catch(const InvalidNameException &ex)
    {
        t_obj = ObjectManager::getInstance()->getObject(path);
    }
    ReadOnlyInt *t_obj2 = dynamic_cast<ReadOnlyInt*>(t_obj);
    if(NULL == t_obj2)
    {
        string error = "the object under path '" + path + "' is not a ReadOnlyInt";
        throw ConfigException(error);
    }
    m_pInnerDoorCloseSensor = t_obj2;
}

void N2BallastChamber::setInnerDoorOpenWch(const std::string &path)
{
    ManagedObject *t_obj = NULL;
    try
    {
        t_obj = ObjectManager::getInstance()->getObject(this, path);
    }
    catch(const InvalidNameException &ex)
    {
        t_obj = ObjectManager::getInstance()->getObject(path);
    }
    ReadWriteInt *t_obj2 = dynamic_cast<ReadWriteInt*>(t_obj);
    if(NULL == t_obj2)
    {
        string error = "the object under path '" + path + "' is not a ReadWriteInt";
        throw ConfigException(error);
    }
    m_pInnerDoorOpenWch = t_obj2;
}

void N2BallastChamber::setInnerDoorCloseWch(const std::string &path)
{
    ManagedObject *t_obj = NULL;
    try
    {
        t_obj = ObjectManager::getInstance()->getObject(this, path);
    }
    catch(const InvalidNameException &ex)
    {
        t_obj = ObjectManager::getInstance()->getObject(path);
    }
    ReadWriteInt *t_obj2 = dynamic_cast<ReadWriteInt*>(t_obj);
    if(NULL == t_obj2)
    {
        string error = "the object under path '" + path + "' is not a ReadWriteInt";
        throw ConfigException(error);
    }
    m_pInnerDoorCloseWch = t_obj2;
}

void N2BallastChamber::setInnerDoor(const std::string &path)
{
    ManagedObject *t_obj = NULL;
    try
    {
        t_obj = ObjectManager::getInstance()->getObject(this, path);
    }
    catch(const InvalidNameException &ex)
    {
        t_obj = ObjectManager::getInstance()->getObject(path);
    }
    ValveController *t_obj2 = dynamic_cast<ValveController*>(t_obj);
    if(NULL == t_obj2)
    {
        string error = "the object under path '" + path + "' is not a ValveController";
        throw ConfigException(error);
    }
    m_pInnerDoor = t_obj2;
}

void N2BallastChamber::setWACTimeMsBeforePinDown(int nTimeMs)//added by liusy[1.1.43]
{
    m_nWACTimeMsBeforePinDown = nTimeMs;
}

IMPLEMENT_DYNAMIC(N2BallastChamber, CmdTarget)

BEGIN_MSG_MAP( N2BallastChamber, CmdTarget)
    SET_S(setInnerDoorOpenSensor, N2BallastChamber)
    SET_S(setInnerDoorCloseSensor, N2BallastChamber)
    SET_S(setInnerDoorOpenWch, N2BallastChamber)
    SET_S(setInnerDoorCloseWch, N2BallastChamber)
    SET_S(setInnerDoor, N2BallastChamber)
    SET_S(setProcessGasIDs, N2BallastChamber)
    SET_S(setPressureController, N2BallastChamber)
    SET_I(setWACTimeMsBeforePinDown, N2BallastChamber)//added by liusy[1.1.43]
END_MSG_MAP
