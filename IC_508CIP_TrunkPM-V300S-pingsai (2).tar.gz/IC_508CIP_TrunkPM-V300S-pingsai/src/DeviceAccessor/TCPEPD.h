/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TCPEPD.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-7-21   LiJuanjuan create
**      
*********************************************************************/
#ifndef TCPEPD_H_
#define TCPEPD_H_

#include "TCPDevice.h"
#include "DeviceNode.h"
#include "VTYRemoteMessages.h"
#include "IMutex.h"
#include <map>
#include <unistd.h>  //add by wzd 1.1.39
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
#endif

namespace ERROR_MESSAGE_SEVERITY
{
	enum ErrorMessageSeverity
	{
		Normal=0,
		Notification,
		Warning,
		Error,
		Fault
	};
}

class TCPEPD:public TCPDevice
{
	DECLARE_DYNAMIC(TCPEPD)	
	DECLARE_MSG_MAP	
	
	public://xml
		void addErrorMessage(string strKey,int nSeverity, string strMoreInfo);

	private:
	
		typedef struct _TrendData
		{
			_TrendData(double value, int id, int offset)
			{
				m_value = value;
				m_ID = id;
				m_offSet = offset;
			}
			double m_value;
			int m_ID;
			int m_offSet;
		}TrendData;	
		
		typedef struct 
		{
			tVTYDynString m_cmd;
			bool m_successful;
			std::string m_name;
			int m_status;
			std::string m_error;
			
		}Cmd;
		
		typedef struct
		{
			string m_strMessageKey;
			int m_nSeverityLevel;
			string m_strMoreInfo;
		}Error;

		std::map<std::string, TrendData*> m_trendDatas;
		typedef std::pair<std::string, TrendData*> TrendPair;
		
		Cmd m_CONNECT;
		Cmd m_VERSION;
		Cmd m_COMPLETE;
		Cmd m_TEST;
		Cmd m_RESET;
		Cmd m_PRESENT;
		Cmd m_START;
		Cmd m_STOP;
		Cmd m_CFGLIST;
		Cmd m_WAFERINFO;
		Cmd m_DISCONNECT;
		
		tVTYDynString m_DynStringR;		 
		tVTYWaferDesc m_vtyWaferDesc;
		
		std::string m_configList;
		std::string m_configName;
		int m_epdStatus;//0:unknown 1:disconnect 2:ready 3:notready
		int m_endPoint;//1 reach endpoint; 0 not
		double m_endPointTime;
		std::string m_errorStr;		
		std::string m_version;	
		std::string m_nameOfSPCV;
		char m_sndBuffer[BUFFER_SIZE];//BUFFER_SIZE defined in VTYRemoteMessages.h		
		IMutex m_lock;
		IMutex m_lockTrendData;
		IMutex m_lockErrorStr;
		
		void initChannels(DeviceNode<TCPEPD> *node);
		void initEPD();
		void initCmd();
		void sendCmd(Cmd *cmd);
		void replyCmd(); 
		void replyCmd(Cmd *cmd); 
		void replyEvent();	
		void connectEPD();
		void disconnectEPD();
		void readDatas();
		void readMatrix(); //readmatrix
		void readDataBlock(); //readdatablock
		void readEPDTime();//readEPDdata
		void readConfigList();	
		void flush();	
		double getTrendData(const std::string &name);
		void setErrorStr(const std::string &error);
		std::string getErrorStr();
		void sendWfrInfo();

		void initErrorMessage();
	public:
		TCPEPD();
		virtual ~TCPEPD();
		
		virtual void init();
		virtual void acceptData();
		virtual std::string getDeviceName();
		bool writeI(int channelNum, int setpt, const IntTypeInfo &);
		bool readI(int channelNum, int *value, const IntTypeInfo &);
		bool readS(int channelNum, std::string *value, const StringTypeInfo &);
		bool writeS(int channelNum, std::string value, const StringTypeInfo &);
		bool readD(int channelNum, double *value, const DoubleTypeInfo &);
		virtual bool reconnectDevice();
		void setNameOfSPCV(const std::string &name);
		virtual void setDeviceConnected(bool flag);

	protected:
		int dealWithErrorMessage(string strError, string &strMoreInfo);

	private:
		vector <Error> m_vecError;
		int m_nErrorSeverity;
		string m_strErrorMoreInfo;
};

#endif /*TCPEPD_H_*/
