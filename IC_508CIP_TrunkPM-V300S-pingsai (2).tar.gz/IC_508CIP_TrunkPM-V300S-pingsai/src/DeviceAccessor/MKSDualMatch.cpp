/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MKSDualMatch.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-11-17   LiJuanjuan create
**      
*********************************************************************/
#include "MKSDualMatch.h"
#include "DeviceManager.h"

#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP;
#endif

using namespace std; 

MKSDualMatch::Com MKSDualMatch::m_commands[] = {{0, ""}, //0	reserved 						
											{0, "MAN", 0},//1 manual
											{0, "AUT", 0},//2 auto
											{0, "LOC", 0},//3 local
											{0, "REM", 0},//4 remote
											{0, "FRE", 0},//5 fault reset
											{1, "SPR0=", 0},//6 store 
											//{1, "STO", 0},//6 store 
											{1, "RPR0=", 0},//7 recall 		
											//{1, "RCL", 0},//7 recall 									
											{1, "CPO0=", 0},//8 set c1
											//{1, "SCO", 0},//8 set c1
											{1, "CPO1=", 0},//9 set c5	
											{1, "CPT0=", 0},//10 set c2		
											//{1, "SCT", 0},//10 set c2																			
											{1, "SDT", 0},//11 set delay time
											
											
											{3, "HPV", 13},//12 get Manual/Auto
											{3, "HPV", 12},//13 get Local/Remote
											{8, "RCO", 0},//14 get c1
											{9, "RCO1", 0},//15 get c5
											{8, "RCT", 0},//16 get c2											
											{7, "AMP0", 100},//17 current 1
											{7, "AMP1", 100},//18 current 2
											{6, "IRT", 1},//19 current ratio
											{0, "IND", 0},//20 forces re-indexof capacitor positions
											{0, "RGR", 0},  //21 regrease
											{8, "RPP", 0}, //22 HFVpp
											{9, "RPP1", 0}, //23 LFVpp
											{4, "HPV3", 0},
											{9, "HPV3", 0}};
											//{6, "RDC", 0}};//20 get DCBias
MKSDualMatch::MKSDualMatch()
{
}

MKSDualMatch::~MKSDualMatch()
{
}

bool MKSDualMatch::writeInt(int channelNum, int value, const IntTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	int ps = com.m_ps;
	string msg = "";
	switch(ps)
	{
		case 0:
			//msg = com.m_s1;
			msg = m_commands[channelNum + value].m_s1;
			cout << msg << "....................."<<endl;
			break;
		case 1:
			/*if((com.m_s1 == "SPR0=" || com.m_s1 == "RPR0=") && (value > 285))
			{
				msg = com.m_s1 + m_memList.getDescriptor(value-285);//A | B| C| D| E| F
			}
			else
			{
				
			}*/
			msg = com.m_s1 + Converter::convertToString(value);
			break;	
	}
	int t_timeOut = m_timeOut;
	if(com.m_s1 == "IND")
	{
		t_timeOut = 30000;
	}
	return sendCommand(msg, t_timeOut);    //set timeout 30s
}
	
bool MKSDualMatch::writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];	
	string	msg = com.m_s1 + Converter::convertToString((int)(value*10));		
	return sendCommand(msg, m_timeOut);
}	
		
bool MKSDualMatch::writeRawCommand(int channelNum, std::string value, const StringTypeInfo &typeInfo)
{
	return sendCommand(value, m_timeOut);
}
		
bool MKSDualMatch::readInt(int channelNum, int *value, const IntTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	int ps = com.m_ps;
	string res;
	if(channelNum==24||channelNum==25)
	{
		res = getCommandResult(com.m_s1, m_timeOut);
	}
	else
	{
		res = readCommand(com.m_s1, m_timeOut);
	}
	size_t pos = res.find(com.m_s1,0);  //changed by wzd 1.1.39
	if(pos == string::npos)
	{
		throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for response ["+Hex::GetHexString(res.c_str(),res.size())+ "] is invalid.");
	}
	else
	{
		string t_value = (res.substr(pos+ps, 4));
		/*
		if(!Converter::stringToInt(*value, t_value))
		{
			throw IOException("read back value is not an valid int value");
		}
		if(com.m_ps2 != 0)
		{
			*value = (*value >> com.m_ps2) & 0x0001;
		}
		return true;*/
		
		if(com.m_ps2 == 0)
		{
			if(channelNum==24||channelNum==25)
			{
				if(!Converter::stringToInt(*value, t_value, std::hex))
				{
					throw IOException("Match read command ["+com.m_s1+"] failed for can't convert response ["+t_value+"] to integer value");
				}
			}
			else
			{
				if(!Converter::stringToInt(*value, t_value))
				{
				throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for can't convert response ["+t_value+"] to integer value");
				}
			}
		}
		else
		{
			if(!Converter::stringToInt(*value, t_value, std::hex))
			{
				throw IOException(getDeviceName()+" read command-"+com.m_s1+" failed for can't convert response ["+t_value+"] to integer value");
			}
			*value = (*value >> com.m_ps2) & 0x0001;			
		}
		return true;
	}
	
}
		
bool MKSDualMatch::readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	int ps = com.m_ps;
	string res = readCommand(com.m_s1, m_timeOut);
	size_t pos = res.find(com.m_s1,0);  //changed by wzd 1.1.39
	if(pos == string::npos)
	{
		throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for response ["+Hex::GetHexString(res.c_str(),res.size())+ "] is invalid.");
	}
	else
	{
		//cout << "???"<<res<< endl;
		string t_value = (res.substr(pos+ps, 5));
		//cout << "..."<<t_value<< endl;
		int t_intv;
		if(!Converter::stringToInt(t_intv, t_value))
		{
			throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for can't convert response ["+t_value+"] to integer value");
		}
		*value = (double)t_intv / com.m_ps2;
		return true;
	}
	
}

void MKSDualMatch::initChs(DeviceNode<MKSDualMatch> *node)
{
	node->registerWriteCh(0, &MKSDualMatch::writeRawCommand);
	for(int i = 1; i <= 10; ++i)
	{
		node->registerWriteCh(i, &MKSDualMatch::writeInt);
	}
	node->registerWriteCh(11, &MKSDualMatch::writeDouble);
	node->registerWriteCh(20,&MKSDualMatch::writeInt);
	node->registerWriteCh(21,&MKSDualMatch::writeInt);
	for(int i = 12; i <= 16; ++i)
	{
		node->registerReadCh(i, &MKSDualMatch::readInt);
	}
	for(int i = 17; i <= 19; ++i)
	{
		node->registerReadCh(i, &MKSDualMatch::readDouble);
	}
	for(int i = 22; i <= 25; ++i)
	{
		node->registerReadCh(i, &MKSDualMatch::readInt);
	}	
}

void MKSDualMatch::initDevice()
{
	cout<<"Start Scan  MKS Dual Match...."<<endl;
	try
	{
		sendCommand("HPV0=17", m_timeOut);
	}
	catch(...)
	{
		sendCommand("HPV0=17", m_timeOut);
	}
	try
	{
		sendCommand("HPV1=FF", m_timeOut);
	}
	catch(...)
	{
		sendCommand("HPV1=FF", m_timeOut);
	}
	try
	{
		sendCommand("HPV3=9", m_timeOut);
	}
	catch(...)
	{
		sendCommand("HPV3=9", m_timeOut);
	}
	try
	{
		sendCommand("HPV4=12", m_timeOut);
	}
	catch(...)
	{
		sendCommand("HPV4=12", m_timeOut);
	}
	cout<<"Scan MKS Dual Match Successfully...."<<endl;
}
		
void MKSDualMatch::init()
{
	DeviceNode<MKSDualMatch> *node = new DeviceNode<MKSDualMatch>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	if(!isSimulated())
	{
		initChs(node);	
		initDevice();
	}
}

IMPLEMENT_DYNAMIC(MKSDualMatch, MKSMatch )
BEGIN_MSG_MAP(MKSDualMatch, MKSMatch )
    SET_V( init, MKSDualMatch )
END_MSG_MAP
