/********************************************************************
** Copyright (c) 2020, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AEDualMatchICP.h
** Description:  Navigator II 3013-ICP 85A (dual output)
*                RS232
*  				   BaudRate: 19200
* 				   Address: 2
* 				   DataBit:8
*                StopBit:1
*                Parity: ODD
*                Protocol:AE Bus communication protocol
* 				   Communication Type:All commands are hexadecimal (0xFF).
* 
** Data package format:
** Example:  
*
* (1)Host computer send message:
* DataPackage:  0x0A   0x06     0x64	 0x00	      0x68	
* decription: |Header|Command|-------Data-------|-Checksum-| 
* 
* (2)Receive ACK from Match:
* DataPackage:  0x06 
* decription:   |ACK|
* 
* (3)Receive response from Match:
* DataPackage:  0x09   0x06     0x00	    0x0F	
* decription: |Header|Command|--CSR---|-Checksum-| 
* 
* (4)Host computer send ACK:
* DataPackage:  0x06 
* decription:   |ACK|
* 
** Release: 1.1
** Modification history: 
** 					2015-04-24   gaozl create
** 					2020-01-21   zhangyy  modify
**      
*********************************************************************/

#ifndef AEDUALMATCHICP_H_
#define AEDUALMATCHICP_H_
#include "SerialDevice.h"
#include "DeviceNode.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class AEDualMatchICP : public SerialDevice
{
    DECLARE_DYNAMIC(AEDualMatchICP)	
    DECLARE_MSG_MAP
public:
    AEDualMatchICP();
    virtual ~AEDualMatchICP();
    
public:
    void init();//xml
    void InitChannels(DeviceNode<AEDualMatchICP> *pNode);      
    bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
    bool readInt(int nChannelNum,int *pValue,const IntTypeInfo &typeInfo);
    bool readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);
    double realToDouble(long nValue);	
    void setAddress(int nAddr);
    
private:
    typedef struct
	 {
		int nCmdLen;    //Command lenth
		unsigned char cCmdNum;   //Command number  //changed by wzd 1.1.39
		int nResLen;    //Response length
	 }Com;
	 static Com m_commands[];	 
    static const int RESP_LEN = 100;
    static const int MESS_LEN = 20;
    int m_nPreC1;
    int m_nPreC2;

    char message[MESS_LEN];
    char resp[RESP_LEN];
    char ack[1];
    int m_nAddr;
    bool sendCommandAck(char *pMsg, char *pResponse, int nMsg_timeout, int nResplen, int nMsglen);
    bool readCommand(char *pMsg, char *pResponse, int nMsg_timeout, int nResplen, int nMsglen);
};

#endif /*AEDUALMATCHICP_H_*/
