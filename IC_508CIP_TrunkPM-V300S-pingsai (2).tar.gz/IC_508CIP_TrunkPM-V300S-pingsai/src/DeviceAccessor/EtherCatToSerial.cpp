/*
 * EtherCatToSerial.cpp
 *
 *  Created on: 2024年12月27日
 *      Author: wenxiang
 */

#include "EtherCatToSerial.h"
#include "Converter.h"
#include "SysLogger.h"
#include <unistd.h>
#include <sstream>
#include <iomanip>

#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
using namespace IAP;
#endif


std::list<int> EtherCatToSerial::m_availabeSDONum;
IMutex EtherCatToSerial::m_SDONumMutex;
IWaitCondition EtherCatToSerial::m_SDONumCond;

EtherCatToSerial::EtherCatToSerial()
{
	m_fd = -1;
	m_beckHoffFlag = false;
	m_slaveAddress = 0;

	static bool initilized = false;
	if(!initilized)
	{
		initilized = true;
		InitSDONumPOOL();
	}
}

EtherCatToSerial::~EtherCatToSerial()
{
	closePort();
}

bool EtherCatToSerial::Convert(const SerialPortSettings portsettings)
{
	if(!m_beckHoffFlag)
	{
		bool flag1 = ConvertBaudRate(portsettings.BodeRate);
		bool flag2 = ConvertDataBit(portsettings.DataBit);
		bool flag3 = ConvertStopBit(portsettings.StopBit);
		bool flag4 = ConvertParity(portsettings.ParityMode);

		if(flag1 && flag2 && flag3 && flag4)
		{
			return true;
		}
		else
		{
	    	SysLogger::getInstance()->logMsg(LOGBRANCH::IO, LEVEL::ERROR,
	                    "Convert port settings failed ");
			return false;
		}
	}
	else
	{
		bool flag1 = ConvertBeckHoffBaudRate(portsettings.BodeRate);
		bool flag2 = ConvertDataFrame(portsettings.DataFrame);

		if(flag1 && flag2)
		{
			return true;
		}
		else
		{
	    	SysLogger::getInstance()->logMsg(LOGBRANCH::IO, LEVEL::ERROR,
	                    "Convert BeckHoff port settings failed");
			return false;
		}
	}
}
bool EtherCatToSerial::ConvertBaudRate(unsigned int baudrate)
{
	switch(baudrate)
	{
		case 2400:
			m_serialPortMap.BodeRate = 0x00;
			return true;

		case 4800:
			m_serialPortMap.BodeRate = 0x01;
			return true;

		case 9600:
			m_serialPortMap.BodeRate = 0x02;
			return true;

		case 19200:
			m_serialPortMap.BodeRate = 0x03;
			return true;

		case 38400:
			m_serialPortMap.BodeRate = 0x04;
			return true;

		case 57600:
			m_serialPortMap.BodeRate = 0x05;
			return true;

		case 115200:
			m_serialPortMap.BodeRate = 0x06;
			return true;

		default:
	        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
	                        "Convert failed: convert baud rate '"+Converter::convertToString(baudrate)+"' failed.");
			return false;
	}
}

bool EtherCatToSerial::ConvertBeckHoffBaudRate(unsigned int baudrate)
{
	switch(baudrate)
	{
		case 300:
			m_serialPortMap.BodeRate = 0x01;
			return true;

		case 600:
			m_serialPortMap.BodeRate = 0x02;
			return true;

		case 1200:
			m_serialPortMap.BodeRate = 0x03;
			return true;

		case 2400:
			m_serialPortMap.BodeRate = 0x04;
			return true;

		case 4800:
			m_serialPortMap.BodeRate = 0x05;
			return true;

		case 9600:
			m_serialPortMap.BodeRate = 0x06;
			return true;

		case 19200:
			m_serialPortMap.BodeRate = 0x07;
			return true;

		case 38400:
			m_serialPortMap.BodeRate = 0x08;
			return true;

		case 57600:
			m_serialPortMap.BodeRate = 0x09;
			return true;

		case 115200:
			m_serialPortMap.BodeRate = 0x0A;
			return true;

		default:
	        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
	                        "Convert failed: convert BeckHoff baud rate '"+Converter::convertToString(baudrate)+"' failed.");
			return false;
	}
}

bool EtherCatToSerial::ConvertDataBit(unsigned int databit)
{
	if(databit == 8)
	{
		m_serialPortMap.DataBit = 0x00;
		return true;
	}
	else if(databit == 7)
	{
		m_serialPortMap.DataBit = 0x01;
		return true;
	}
	else
	{
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
                        "Convert failed: convert data bit '"+Converter::convertToString(databit)+"' failed.");
		return false;
	}
}

bool EtherCatToSerial::ConvertStopBit(unsigned int stopbit)
{
	if(stopbit == 1)
	{
		m_serialPortMap.StopBit = 0x00;
		return true;
	}
	else if (stopbit == 2)
	{
		m_serialPortMap.StopBit = 0x01;
		return true;
	}
	else
	{
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
                        "Convert failed: convert stop bit '"+Converter::convertToString(stopbit)+"' failed.");
		return false;
	}
}

bool EtherCatToSerial::ConvertParity(unsigned int paritymode)
{
	switch(paritymode)
	{
		case 0:
			m_serialPortMap.ParityMode = 0x00;
			return true;

		case 1:
			m_serialPortMap.ParityMode = 0x02;
			return true;

		case 2:
			m_serialPortMap.ParityMode = 0x01;
			return true;

		default:
	        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
	                        "Convert failed: convert parity mode '"+Converter::convertToString(paritymode)+"' failed.");
			return false;
	}
}

bool EtherCatToSerial::ConvertDataFrame(const std::string &dataframe)
{
	if(dataframe == "7E1" )
	{
		m_serialPortMap.DataFrame = 0x01;
		return true;
	}
	else if(dataframe == "7O1")
	{
		m_serialPortMap.DataFrame = 0x02;
		return true;
	}
	else if(dataframe == "8N1")
	{
		m_serialPortMap.DataFrame = 0x03;
		return true;
	}
	else if(dataframe == "8E1")
	{
		m_serialPortMap.DataFrame = 0x04;
		return true;
	}
	else if(dataframe == "8O1")
	{
		m_serialPortMap.DataFrame = 0x05;
		return true;
	}
	else if(dataframe == "7E2")
	{
		m_serialPortMap.DataFrame = 0x09;
		return true;
	}
	else if(dataframe == "702")
	{
		m_serialPortMap.DataFrame = 0x0A;
		return true;
	}
	else if(dataframe == "8N2")
	{
		m_serialPortMap.DataFrame = 0x0B;
		return true;
	}
	else if(dataframe == "8E2")
	{
		m_serialPortMap.DataFrame = 0x0C;
		return true;
	}
	else if(dataframe == "8O2")
	{
		m_serialPortMap.DataFrame = 0x0D;
		return true;
	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
			                        "Convert failed: convert data frame '"+dataframe+"' failed.");
		return false;
	}
}
void EtherCatToSerial::InitSDONumPOOL()
{
	for(int i = 0; i <= 4; i++)
	{
		m_availabeSDONum.push_back(i);
	}
}

int EtherCatToSerial::AcquireSDONum()
{
	m_SDONumMutex.lock();

	while(m_availabeSDONum.empty())
	{
		m_SDONumCond.wait(&m_SDONumMutex, 5000);
	}

	int num = m_availabeSDONum.front();
	m_availabeSDONum.pop_front();
	m_SDONumMutex.unlock();
	return num;
}

void EtherCatToSerial::ReleaseSDONum(int num)
{
	if(num < 0 || num > 4)
	{
		return;
	}

	m_SDONumMutex.lock();
	m_availabeSDONum.push_back(num);
	m_SDONumCond.wakeAll();
	m_SDONumMutex.unlock();
}

void EtherCatToSerial::setBeckHoffFlag(bool flag)
{
	m_beckHoffFlag = flag;
}

int EtherCatToSerial::SerialSetBySDO(unsigned short slaveaddress, unsigned short index, unsigned char subIndex, unsigned int length, unsigned char* data)
{
	int SDOState = 0;
	unsigned int num = 5; // SDONum is 0-4
	unsigned int rw = SDO_WRITE;
	unsigned int ret = 0;
	std::string subindex = unsignedToHexString(subIndex);

	num = EtherCatToSerial::AcquireSDONum();
	ret = ky_ecat_sdo_req(num, rw, slaveaddress, index, subIndex, length, (unsigned char*)(data));
	if(S_OK != ret)
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
			                        "Request SDO write failed.Slave Address: '"+Converter::convertToString(slaveaddress)+"'; Index: '"+Converter::convertToString(index)+"'; SubIndex: '"+subindex+"' ");
		EtherCatToSerial::ReleaseSDONum(num);
		return S_ERROR;
	}

	do
	{
		int tempRet = 0;
		tempRet = ky_ecat_sdo_get_rsp(num, &SDOState, (unsigned char *)(data));
		if(S_OK != tempRet)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
				                        "Get SDO write response failed.Slave Address: '"+Converter::convertToString(slaveaddress)+"'; Index: '"+Converter::convertToString(index)+"'; SubIndex: '"+subindex+"' ");
			EtherCatToSerial::ReleaseSDONum(num);
			return S_ERROR;
		}
	}
	while(SDO_STATE_WAITING == SDOState || SDO_STATE_GOING_TO_RESPONE == SDOState);

	if(SDO_STATE_SUCCESS == SDOState)
	{
    	if(rw == SDO_READ)
    		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT,
    			                        "SDO read success.Slave Address: '"+Converter::convertToString(slaveaddress)+"'; Index: '"+Converter::convertToString(index)+"'; SubIndex: '"+subindex+"' ");
		else
    		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT,
    			                        "SDO write success.Slave Address: '"+Converter::convertToString(slaveaddress)+"'; Index: '"+Converter::convertToString(index)+"'; SubIndex: '"+subindex+"' ");
	    ret = S_OK;
	}
	else
	{
    	if(rw == SDO_READ)
    		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
    			                        "SDO read failed.Slave Address: '"+Converter::convertToString(slaveaddress)+"'; Index: '"+Converter::convertToString(index)+"'; SubIndex: '"+subindex+"' ");
		else
    		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
    			                        "SDO write failed.Slave Address: '"+Converter::convertToString(slaveaddress)+"'; Index: '"+Converter::convertToString(index)+"'; SubIndex: '"+subindex+"' ");
    	ret = S_ERROR;
	}

	unsigned char r_data[8] = {0};
	rw = SDO_READ;
	if(S_OK != (ret = ky_ecat_sdo_req(num, rw, slaveaddress, index, subIndex, length, (unsigned char*)(r_data))))
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
			                        "Request SDO read failed.Slave Address: '"+Converter::convertToString(slaveaddress)+"'; Index: '"+Converter::convertToString(index)+"'; SubIndex: '"+subindex+"' ");
		return S_ERROR;
	}
	/*等待读SDO完成*/
	do
	{
		int tempRet = 0;
		tempRet = ky_ecat_sdo_get_rsp(num, &SDOState, (unsigned char *)(r_data));
		if(S_OK != tempRet)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
				                        "Get SDO read response failed.Slave Address: '"+Converter::convertToString(slaveaddress)+"'; Index: '"+Converter::convertToString(index)+"'; SubIndex: '"+subindex+"' ");
			EtherCatToSerial::ReleaseSDONum(num);
			return S_ERROR;
		}
	}while(SDO_STATE_WAITING == SDOState || SDO_STATE_GOING_TO_RESPONE == SDOState);

	if(SDO_STATE_SUCCESS == SDOState)
	{
		if(rw == SDO_READ)
    		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT,
    			                        "SDO read success.Slave Address: '"+Converter::convertToString(slaveaddress)+"'; Index: '"+Converter::convertToString(index)+"'; SubIndex: '"+subindex+"'");
		else
    		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT,
    			                        "SDO write success.Slave Address: '"+Converter::convertToString(slaveaddress)+"'; Index: '"+Converter::convertToString(index)+"'; SubIndex: '"+subindex+"'");
		ret = S_OK;
	}
	else
	{
		if(rw == SDO_READ)
    		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
    			                        "SDO read failed.Slave Address: '"+Converter::convertToString(slaveaddress)+"'; Index: '"+Converter::convertToString(index)+"'; SubIndex: '"+subindex+"'");
		else
    		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
    			                        "SDO write failed.Slave Address: '"+Converter::convertToString(slaveaddress)+"'; Index: '"+Converter::convertToString(index)+"'; SubIndex: '"+subindex+"'");
		ret = S_ERROR;
	}
	for(int a = 0; a < length; a++)
	{
		if(r_data[a]!=data[a])
		{
    		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
    			                        "Data compare failed.");
			EtherCatToSerial::ReleaseSDONum(num);
			ret = S_ERROR;
		}
	}
	EtherCatToSerial::ReleaseSDONum(num);
	return ret;
}

void EtherCatToSerial::closePort()
{
	if(m_fd < 0)
	{
		return;
	}
	CloseSHM();
	//close(m_fd);
	ky_shm_serial_st_close(m_fd);
	m_fd = -1;
}

bool EtherCatToSerial::shmSerialOpen(const char *dev, const SerialPortSettings portsettings)
{
	m_slaveAddress = portsettings.SlaveAddress;
	m_index = portsettings.Index;

	short ErrorCode = 0;
	int ecatShmSize = 0;

	if(!Convert(portsettings))
	{
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
                        "EtherCatToSerial::shmSerialOpen() failed: convert serial port settings failed.");
		return false;
	}

	if(!SHMInitInstance::getInstance().InitSHM())
	{
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
                        "EtherCatToSerial::shmSerialOpen() failed: initial shared memory failed.");
        return false;
	}

	if(!SHMInitInstance::getInstance().InitEcatSHM())
	{
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
                        "EtherCatToSerial::shmSerialOpen() failed: initial EtherCat shared memory failed.");
        return false;
	}


	int devState = ky_ecat_dev_state_get(m_slaveAddress);
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT,
                    "Device state is '"+Converter::convertToString(devState)+"' ");

	if((m_fd = ky_shm_serial_st_open(dev, 10)) < 0)
	{
		ky_shm_serial_st_close_by_name(dev);
		if((m_fd = ky_shm_serial_st_open(dev, 10)) < 0)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
                        "EtherCatToSerial::shmSerialOpen() failed: Open serial port failed.");
        return false;
		}
	}

	if(!m_beckHoffFlag)
	{
		SerialPara comiSerialPara[4] = {{m_index, 0x01, 1, m_serialPortMap.BodeRate}, {m_index, 0x02, 1, m_serialPortMap.DataBit}, {m_index, 0x04, 1, m_serialPortMap.StopBit},
				{m_index, 0x03, 1, m_serialPortMap.ParityMode}
		};
		for(int k = 0; k < 4; k++)
		{
			if(0 != SerialSetBySDO(m_slaveAddress, comiSerialPara[k].index, comiSerialPara[k].subIndex, comiSerialPara[k].length, &comiSerialPara[k].data))
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
	                        "EtherCatToSerial::shmSerialOpen() failed: set serial port parameter by SDO failed.");
				return false;
			}
		}
	}
	else
	{
		SerialPara comiSerialPara[2] = {{m_index, 0x11, 1, m_serialPortMap.BodeRate}, {m_index, 0x15, 1, m_serialPortMap.DataFrame}};
		for(int k = 0; k < 2; k++)
		{
			if(0 != SerialSetBySDO(m_slaveAddress, comiSerialPara[k].index, comiSerialPara[k].subIndex, comiSerialPara[k].length, &comiSerialPara[k].data))
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
	                        "EtherCatToSerial::shmSerialOpen() failed: set serial port parameter by SDO failed.");
				return false;
			}
		}
	}

	int res = ky_shm_serial_st_init(m_fd, &ErrorCode);
	if((res == 0) && (ErrorCode == 0))
	{
		return true;
	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
                    "EtherCatToSerial::shmSerialOpen() failed: initial serial port settings failed.");
		return false;
	}
}

int EtherCatToSerial::shmSerialReadStr(char * readBuf, int timeOutMs, int readLength, short* error)
{
	return ky_shm_serial_st_readStr(m_fd, readBuf, timeOutMs, readLength, error);

}

int EtherCatToSerial::shmSerialWriteRaw(const char * writeBuf,int writeLength, short* error)
{
	return ky_shm_serial_st_writeRaw(m_fd, writeBuf, writeLength, error);
}

std::string EtherCatToSerial::unsignedToHexString(unsigned char uc)
{
	std::stringstream ss;
	ss<<"\\x"<<std::hex<<std::setw(2)<<std::setfill('0')<<static_cast<int>(uc);
	return ss.str();
}
