/**************************************************************************
** Copyright (c) 2016, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: DeviceMonitor.cpp
** Description: 
** Release: 
** Modification history: 
** 					2016-10-17  mujy  create [V1.5.16]
**      
***************************************************************************/

#include "DeviceMonitor.h"
#include "SysLogger.h"
#ifdef IAP4_0
#include "ITime.h"
#else
#include "Time.h"
#endif
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "InvalidNameException.h"
#endif
#include "ConfigException.h"
#include "ObjectManager.h"
#include "DataSource.h"
#include "DataTarget.h"
#include "StringValueInfo.h"
#include "DoubleValueInfo.h"
#include "AlarmReNameManager.h"

#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
using namespace IAP::IO;
#endif
using namespace std;

DeviceMonitor::DeviceMonitor():Subscriber(IO::UNKNOWN)
{
	m_IntervalS = 1;
	m_lastIsOffline = false;
    m_nDeviceOfflineAlarm = NULL;
}

DeviceMonitor::~DeviceMonitor()
{
	
}

void DeviceMonitor::make()
{
	string strPreName = AlarmReNameManager::getInstance()->GetShowName(getName());
	m_nDeviceOfflineAlarm = new NonBlockingAlarm(strPreName+"_DeviceOfflineAlarm", strPreName + "  offline alarm.",strPreName +  " offline alarm.", Alarm::ERROR);
	m_nDeviceOfflineAlarm->addRecovery(new Recovery("Clear", Recovery::CLEAR));
}

void DeviceMonitor::startup()
{
	if(!isSimulated())
	{
		startMonitoring();
	}	
}

void DeviceMonitor::shutdown()
{
	if(!isSimulated())
	{
		exitMonitoring();
	}	
}

void DeviceMonitor::internalExecute()
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": start running");
	
	while(getStatus() == RUN)
	{
		bool m_currentIsOffline = true;
		
		//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + ": ABOUT TO CHECK");
		for(unsigned int i=0; i<m_IODatas.size() && getStatus() == RUN; ++i)
		{
			try
			{
				m_currentIsOffline &= (m_IODatas[i]->getValidity() == IO::OFFLINE);
			}
			catch(const exception &ex)
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": got exception:" + string(ex.what()));								
			}
		}
		usleep((long)(m_IntervalS * 1000000));
		try
		{
			if(m_currentIsOffline && m_lastIsOffline)
			{
				if(!m_nDeviceOfflineAlarm->isPosted())
				{
					m_nDeviceOfflineAlarm->post(this);
				}
			}
		}
		catch(const exception &ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": got exception:" + string(ex.what()));								
		}
		
		m_lastIsOffline = m_currentIsOffline;
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": stop running");
}

void DeviceMonitor::update(UntypedData *data, const ValueInfo &value)
{
	
}
void DeviceMonitor::addMonitorIO(const std::string &strPath)
{
	ManagedObject *obj = NULL;
	try
	{
		obj = ObjectManager::getInstance()->getObject(strPath);
	}
	catch(const InvalidNameException &e)
	{
		obj = ObjectManager::getInstance()->getObject(this,strPath);
	}
	UntypedData * pIO = dynamic_cast<UntypedData*>(obj);
	if(NULL == pIO)
	{
		string error = "the object under path '" + strPath + "' is not a ReadWriteInt";
		throw ConfigException(error);
	}
	m_IODatas.push_back(pIO);
	pIO->subscribe(this);
}

void DeviceMonitor::setIntervalS(int nIntervalS)
{
	m_IntervalS = nIntervalS;
}

IMPLEMENT_DYNAMIC(DeviceMonitor, ControlMonitor)
BEGIN_MSG_MAP( DeviceMonitor, ControlMonitor)
SET_S(addMonitorIO, DeviceMonitor)
SET_I(setIntervalS, DeviceMonitor)
END_MSG_MAP
