/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: Util.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-11-30   LiJuanjuan create
**                                                 2018-06-01    Duq update stringToCondition
**                                                 2019-04-17    Duq add isDoubleZero
*********************************************************************/

#include "Util.h"
#include "ObjectManager.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "ConditionSyntaxException.h"
#endif
#include "Converter.h"
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
using namespace IAP::CONDITION;
#endif

using namespace std;

Util::Util()
{
}

Util::~Util()
{
}

bool Util::isDoubleZero(double value)
{
	if(value > -0.0000000000001 && value < 0.0000000000001)
		return true;
	return false;
}

bool Util::stringToHex(int *res, const std::string &s)
{
	if(s.find(".",0) != string::npos)
    {
        return false;
    }
    istringstream iss( s );
    return !(iss>>hex>>*res).fail();	
}

string Util::hexToString(int value)
{
	ostringstream t_o;
	int t_v1 = value;
	int t_v2 = 0;
	string t_res = "";
	while(t_v1 > 0)
	{
		t_v2 = t_v1 % 16;
		t_v1 = (int)(t_v1 / 16);
		t_o.str("");
		t_o <<hex << t_v2;
		t_res = t_o.str() + t_res;		
	}
	return t_res;
}

string Util::toUpper(const std::string &str)
{
	char *t_ch = const_cast<char*>(str.c_str());
	for(size_t i = 0; i< str.length(); ++i)
	{
		t_ch[i] = toupper(t_ch[i]);
	}
	return string(t_ch);	
}

std::string Util::toLower(const std::string &str)
{
	char *t_ch = const_cast<char*>(str.c_str());
	for(size_t i = 0; i< str.length(); ++i)
	{
		t_ch[i] = tolower(t_ch[i]);
	}
	return string(t_ch);	
}	


AppConditionPtr Util::stringToCondition(const std::string &str)
{
	//verify string
	string expression = str;
	size_t t_posl = expression.find_first_of("(", 0);
	size_t t_posr = expression.find_last_of(")", expression.length()-1);
	string t_operator1 = "";
	if(t_posl == string::npos ||  t_posr == string::npos || t_posr != expression.length()-1)
	{
		throw ConditionSyntaxException("Construct condition by incorrect string! 1" + str);
	}
	if(t_posl != 0)
	{
		if((t_operator1 = expression.substr(0,1)) != "!" && (t_operator1 = expression.substr(0,7)) != "changes")
		{
			throw ConditionSyntaxException("Construct condition by incorrect string! 2" + str);
		}		
	}
	//end of recursion
	if(t_posl == expression.find_last_of("(", expression.length()-1) && t_posr == expression.find_first_of(")", 0))
	{
		if(t_operator1 == "changes")
		{
			expression = expression.substr(7, expression.length() - 7);///remove changes
			if(expression.find("=", 0) == string::npos && expression.find(">", 0) == string::npos && expression.find("<", 0) == string::npos)
			{
				expression = expression.substr(1, expression.length()-2);
				return new AppCondition((UntypedData*)ObjectManager::getInstance()->getObject(expression), t_operator1);
			}
			else
			{
				return new AppCondition(stringToCondition(expression),t_operator1);
			}
		}
		else if(t_operator1 == "!")
		{
			expression = expression.substr(1, expression.length() - 1);///remove !
			return new AppCondition(t_operator1, stringToCondition(expression));
		}
		else
		{
			string t_datal = "";
			string t_datar = "";
			if((t_posl = expression.find("==", 0)) != string::npos)
			{
				t_operator1 = "==";
				t_datar = expression.substr(t_posl+2, expression.length()-t_posl-3);
			}
			else if((t_posl = expression.find(">=", 0)) != string::npos)
			{
				t_operator1 = ">=";
				t_datar = expression.substr(t_posl+2, expression.length()-t_posl-3);
			}
			else if((t_posl = expression.find("<=", 0)) != string::npos)
			{
				t_operator1 = "<=";
				t_datar = expression.substr(t_posl+2, expression.length()-t_posl-3);
			}
			else if((t_posl = expression.find(">", 0)) != string::npos)
			{
				t_operator1 = ">";
				t_datar = expression.substr(t_posl+1, expression.length()-t_posl-2);
			}	
			else if((t_posl = expression.find("<", 0)) != string::npos)
			{
				t_operator1 = "<";
				t_datar = expression.substr(t_posl+1, expression.length()-t_posl-2);
			}
			else
			{
				throw ConditionSyntaxException("Construct condition by incorrect string!3 " + str);
			}	
			t_datal = 	expression.substr(1, t_posl-1);	
			double t_ddata = 0.0;	
			int t_idata = 0;
			if(t_datar.find("/", 0) == string::npos)	 
			{				
				if(t_datar.find(".",0) != string::npos)
				{
					if(!Converter::stringToDouble(t_ddata, t_datar))
					{
						throw ConditionSyntaxException("Construct condition by incorrect string! 4" + str);
					}
					else
					{
						return new AppCondition((UntypedData*)ObjectManager::getInstance()->getObject(t_datal), t_operator1, t_ddata);
					}
				}
				else if(Converter::stringToInt(t_idata, t_datar)) //update by Duq 
				{
					string temp = Converter::convertToString(t_idata);
					if(temp == t_datar)
						return new AppCondition((UntypedData*)ObjectManager::getInstance()->getObject(t_datal), t_operator1, t_idata);
					else
						return new AppCondition((UntypedData*)ObjectManager::getInstance()->getObject(t_datal), t_operator1, t_datar);
				}
				else
				{
					return new AppCondition((UntypedData*)ObjectManager::getInstance()->getObject(t_datal), t_operator1, t_datar);
				}
			}	
			else
			{	
				return new AppCondition((UntypedData*)ObjectManager::getInstance()->getObject(t_datal), t_operator1, (UntypedData*)ObjectManager::getInstance()->getObject(t_datar));
			}
		}
	}
	else
	{
		expression = expression.substr(1,expression.length()-2);//remove outside () 
		if((t_operator1=expression.substr(0,1)) != "!" && (t_operator1=expression.substr(0,7)) != "changes")
		{
			t_posl = 0;
			t_posr = 0;
			while(true)
			{
				if(t_posl == string::npos && t_posr == string::npos)
				{
					throw ConditionSyntaxException("Construct condition by incorrect string! 5" + str);
				}
				t_posl = expression.find_first_of("(", t_posl+1);
				t_posr = expression.find_first_of(")", t_posr+1);
				if(t_posl > t_posr)	
				{
					break;
				}		
			}
			if(t_posr == expression.length()-1)//double ()
			{
				return stringToCondition(expression);
			}
			t_operator1 = expression.substr(t_posr+1, 2);
			if(t_operator1 != "&&" && t_operator1 != "||")
			{
				throw ConditionSyntaxException("Construct condition by incorrect string! 6" + str);
			}
			return new AppCondition(stringToCondition(expression.substr(0, t_posr+1)), t_operator1, stringToCondition("("+expression.substr(t_posl, expression.length()-t_posl)+")"));
		}
		else
		{
			if(t_operator1 == "!")
			{
				return new AppCondition(t_operator1, stringToCondition(expression.substr(1, expression.length()-1)));
			}
			else
			{
				return stringToCondition(expression);
			}			
		}
	}
}

