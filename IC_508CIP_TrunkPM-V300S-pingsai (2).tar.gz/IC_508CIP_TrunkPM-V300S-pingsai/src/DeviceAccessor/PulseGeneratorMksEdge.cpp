/********************************************************************
** Copyright (c) 2018, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: PulseGeneratorMksEdge.cpp
** Description: Product Specification 400KHz,1.5KW,Pulsing RF Generator MKS Model Number EDGE 15R40A-D02
*                RS232
*          BaudRate:19200
*                DataBit:8
*                StopBit:1
*                Parity:No parity
*                FlowControl:no flow control               
** Release: 1.1
** Modification history: 
**                 2018-9-6   mujy create
**      
*********************************************************************/

#include "PulseGeneratorMksEdge.h"
#include "DeviceManager.h"
#include <iostream>
#include <sys/time.h>
#include <sstream>
#include "Converter.h"
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std;

PulseGeneratorMksEdge::Com PulseGeneratorMksEdge::m_Commands[] = {{0, ""}, //0    reserved
                                            {0, "OFF", 0},//1.turn the RF output off
                                            {0, "TRG", 0},//2.turn the RF output on
                                            {0, "FRE", 0},//3.Reset generator faults and warning
                                            {1, "LLT", 0},//4.power mode: 0 is Forward,1 is Load
                                            {1, "PSW", 0},//5 turn pulsing:0 is Off,1 is on
                                            {0, "OEM", 0},//6 set the power setpoint in watts to x
                                            {0, "SPUL ", 0},//7 set the SPUL,power
                                            {0, "SPUL ", 0},//8 set the SPUL,set Pulse Frequency
                                            {0, "SPUL ", 0},//9 set the SPUL,set Pulse Duty
                                            {0, "ROF", 0},//10 get output forward power
                                            {0, "ROR", 0},//11 get output reverse power
                                            {0, "PFREQ", 0},//12 get Frequece
                                            {1, "PDUTY", 100},//13 get Duty
                                            {0, "FRQ", 0},//14 get SweepFrequece
                                            {0, "DFT E", 0},//15 Readback DFT rotation value //add by wzd 1.1.21
                                            {0, "FTUE", 0},//16 get current Frequency Tuning  //add by wzd 1.1.21
                                            {0, "DFT ", 0},//17 set rotation value to x//add by wzd 1.1.21
                                            {1, "FTU0=", 0},//18 manual frequency tuningfrequency tuning mode //add by wzd 1.1.21
                                            //{0, "FTU0=1", 0},//19 auto frequency tuning mode //add by wzd 1.1.21
                                            {1, "FTU0-1=", 0},//19 manual Pulse Mode for state 1 //add by wzd 1.1.21
                                            //{0, "FTU0-1=1", 0},// auto Pulse Mode for state 1 //add by wzd 1.1.21
                                            {1, "FTU0-2=", 0},//20 set tune mode //add by wzd 1.1.21
                                            //{0, "FTU0-2=1", 0},// set tune mode //add by wzd 1.1.21
                                            {0, "FTU12-3=", 0}//21 set DFT Gain //add by wzd 1.1.21
};
PulseGeneratorMksEdge::PulseGeneratorMksEdge():SerialDevice(200, "\x0D")
{
    m_timeOut = 50;//5s

    m_dPulseFrequency = 0;
    m_dPulseDuty = 10.0;
    m_strMaxFreq = "400000";

    m_vecInitCommand.clear();
}

PulseGeneratorMksEdge::~PulseGeneratorMksEdge()
{
}

bool PulseGeneratorMksEdge::sendCommand(std::string strCommand, int nTimeOut)
{
    string strReply = getCommandResult(strCommand, nTimeOut);
    if(strReply.find("\x0D\x0A",0) == string::npos)
    {
        strReply += getResultOnly(10);
    }

    if(strReply.find("\x0D\x0A*",0) != string::npos)
    {
        return true;
    }
    else if(strReply.find("\x0D\x0A?",0) != string::npos)
    {
        throw IOException(getDeviceName()+" send command ["+strCommand+"] occurred error [" + strReply+"]");
    }
    else
    {
        throw IOException(getDeviceName()+" send command ["+strCommand+"] failed for unknown response [" +strReply+"]");
    }

}

std::string PulseGeneratorMksEdge::readCommand(std::string strCommand, int nTimeOut)
{
    string strReply = getCommandResult(strCommand, nTimeOut);
    if(strReply.find("\x0D\x0A*",0) != string::npos)
    {
        return strReply;
    }
    else if(strReply.find("\x0D\x0A?",0) != string::npos)
    {
        throw IOException(getDeviceName()+" read command ["+strCommand+"] occurred error [" + strReply+"]");
    }
    else
    {
        throw IOException(getDeviceName()+" read command ["+strCommand+"] failed for unknown response [" +strReply+"]");
    }
}

bool PulseGeneratorMksEdge::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
    Com com = m_Commands[nChannelNum];
    int nCmdType = com.m_nCmdType;
    string strMsg = "";
    switch(nCmdType)
    {
        case 0:
            strMsg = m_Commands[nChannelNum + nValue].m_strCmd;
            break;
        case 1:
            strMsg = com.m_strCmd + Converter::convertToString(nValue);
            break;
    }
    return sendCommand(strMsg, m_timeOut);
}

bool PulseGeneratorMksEdge::writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
    Com com = m_Commands[nChannelNum];
    string    strMsg;
    if(nChannelNum == 6)
    {
        strMsg = "OEM" + Converter::convertToString(dValue);
        return sendCommand(strMsg, m_timeOut);
    }
    else if(nChannelNum == 7 )//set pulse power
    {
        strMsg = "SPUL "+Converter::convertToString(dValue)+",0,"+Converter::convertToString(m_dPulseFrequency)+","+Converter::convertToString(m_dPulseDuty/100);
        return sendCommand(strMsg, m_timeOut);
    }
    else if (nChannelNum == 8)
    {
        m_dPulseFrequency = dValue;
        return true;
    }
    else if (nChannelNum == 9)
    {
        m_dPulseDuty = dValue;
        return true;
    }
    else//change by chensc
    {
        strMsg    = m_Commands[nChannelNum].m_strCmd + Converter::convertToString(dValue);
        return sendCommand(strMsg, m_timeOut);
    }
}

bool PulseGeneratorMksEdge::writeRawCommand(int nChannelNum, std::string strValue, const StringTypeInfo &typeInfo)
{
    return sendCommand(strValue, m_timeOut);
}

bool PulseGeneratorMksEdge::readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
    Com com = m_Commands[nChannelNum];
    int nCmdType = com.m_nCmdType;
    string strReply = readCommand(com.m_strCmd, m_timeOut);
    size_t nPos = strReply.find(com.m_strCmd,0);  //changed by wzd 1.1.39
    if(nPos == string::npos)
    {
        throw IOException(getDeviceName()+" read command ["+com.m_strCmd+"] failed for response ["+strReply+"] is invalid.");

    }
    else
    {
        string strValue = (strReply.substr(nPos+nCmdType, 4));
        if(com.m_nCmdValueDeal == 0)
        {
            if(!Converter::stringToInt(*pValue, strValue))
            {
                throw IOException(getDeviceName()+" read command ["+com.m_strCmd+"] failed for can't convert response "+strValue+" to integer value.");
            }
        }
        else
        {
            if(!Converter::stringToInt(*pValue, strValue, std::hex))
            {
                throw IOException(getDeviceName()+" read command ["+com.m_strCmd+"] failed for can't convert response "+strValue+" to integer value.");
            }
            *pValue = (*pValue >> com.m_nCmdValueDeal) & 0x0001;
        }
        return true;
    }
}

bool PulseGeneratorMksEdge::readDouble(int nChannelNum, double *dValue, const DoubleTypeInfo &typeInfo)
{
    Com com = m_Commands[nChannelNum];
    int nCmdType = com.m_nCmdType;
    string strReply = readCommand(com.m_strCmd, m_timeOut);
    size_t nPos = strReply.find("\x0D\x0A*",0);  //changed by wzd 1.1.39

    if(nPos == string::npos)
    {
        throw IOException(getDeviceName()+" read command ["+com.m_strCmd+"] failed for response "+strReply+" is invalid.");
    }
    else
    {
        string strValue = (strReply.substr(0, nPos));
        double nDoubleValue;
        if(!Converter::stringToDouble(nDoubleValue, strValue))
        {
            throw IOException(getDeviceName()+" read command ["+com.m_strCmd+"] failed for can't convert response ["+strValue+"] is invalid.");
        }

        int nCmdType = com.m_nCmdType;
        switch(nCmdType)
        {
            case 0:
                *dValue = nDoubleValue;
                break;
            case 1:
                *dValue = nDoubleValue * com.m_nCmdValueDeal;
                break;
        }
        return true;
    }
}

void PulseGeneratorMksEdge::InitChannels(DeviceNode<PulseGeneratorMksEdge> *node)
{
    node->registerWriteCh(0, &PulseGeneratorMksEdge::writeRawCommand);
    for(int i = 1; i <= 5; ++i)
    {
        node->registerWriteCh(i, &PulseGeneratorMksEdge::writeInt);
    }

    for(int i = 6; i <= 9; ++i)
    {
        node->registerWriteCh(i, &PulseGeneratorMksEdge::writeDouble);
    }

    for(int i = 10; i <= 16; ++i)
    {
        node->registerReadCh(i, &PulseGeneratorMksEdge::readDouble);
    }
    node->registerWriteCh(17, &PulseGeneratorMksEdge::writeDouble);
    for(int i = 18; i <= 20; ++i)
    {
        node->registerWriteCh(i, &PulseGeneratorMksEdge::writeInt);
    }
    node->registerWriteCh(21, &PulseGeneratorMksEdge::writeDouble);

    node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &PulseGeneratorMksEdge::getStatus);
}

void PulseGeneratorMksEdge::initDevice()
{
    //say hello to generator
    cout<<"Start Scan Generator...."<<endl;

    for(int i =0;i<m_vecInitCommand.size();i++)
    {
        string strCommand=m_vecInitCommand[i];
        sendCommand(strCommand, m_timeOut);
        usleep(500*1000);
    }

    std::string setMaxFreq = std::string("FRQ=") + m_strMaxFreq;
    sendCommand(setMaxFreq, m_timeOut);
    cout<<"Scan Generator Successfully...."<<endl;
}

void PulseGeneratorMksEdge::setMaxFreq(std::string freq)
{
    m_strMaxFreq = freq;
}

void PulseGeneratorMksEdge::init()
{
    DeviceNode<PulseGeneratorMksEdge> *pNode = new DeviceNode<PulseGeneratorMksEdge>(m_pollPeriod, this);
    DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
    if(!isSimulated())
    {
        InitChannels(pNode);
        initDevice();
    }
}

void PulseGeneratorMksEdge::addInitCommand(const string& strCommand)
{
    m_vecInitCommand.push_back(strCommand);
}

IMPLEMENT_DYNAMIC(PulseGeneratorMksEdge, SerialDevice )
BEGIN_MSG_MAP(PulseGeneratorMksEdge, SerialDevice )
    SET_V( init, PulseGeneratorMksEdge )
    SET_S( setMaxFreq, PulseGeneratorMksEdge )
    SET_S(addInitCommand, PulseGeneratorMksEdge)
END_MSG_MAP

