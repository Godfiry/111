/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AdvancedMFC.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-6-18   LiJuanjuan create
**      
*********************************************************************/
#ifndef TCPSOCKET_H_
#define TCPSOCKET_H_

#include <string>
#include <netinet/in.h>
#include "IMutex.h"
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

class TCPSocket
{
	private:
		std::string m_server;
		std::string m_port;
		int m_sockfd;
		struct sockaddr *m_sockaddr;
		int m_revTimeOut;
		int m_sndTimeOut;
	
	public:
		TCPSocket(const std::string &server, std::string port);
		virtual ~TCPSocket();
		
		void connect();
		int shutdown(int rw);//r:0 w:1 rw:2
		int reconnect();
		int close();
		int sendData(const char *data, int size);
		int recvFixLenData(char *buffer, int len);
		int recvData(char *buffer, int len);		
		int select();
		int getErrno()const;
		std::string getErrnoStr()const;
		void setRcvTimeOut(int timeout);
		void setSndTimeOut(int timeout);
		bool isConnected();
};

#endif /*TCPSOCKET_H_*/
