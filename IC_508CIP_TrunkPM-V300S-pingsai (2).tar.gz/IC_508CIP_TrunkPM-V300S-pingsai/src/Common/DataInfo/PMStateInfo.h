/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					Jan 22, 2008  shenql  create 
**      
***************************************************************************/
#ifndef PMSTATEINFO_H_
#define PMSTATEINFO_H_
#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class PMStateInfo : public IntValueInfo
{
public:

		static const int UnInit = -1;
		static const int Init = 0;
		static const int Rd4Next = 1;
		static const int Rd4Clean = 2;
		static const int Rd2ClnEmp = 3;
		static const int NotRd = 4;
		static const IntTypeInfo typeInfo;

	   PMStateInfo():IntValueInfo(-1, typeInfo)
	   {
	   }
	
	   PMStateInfo(int i):IntValueInfo(i, typeInfo)
	    {
	    }
	
	   PMStateInfo(std::string s):IntValueInfo(s, typeInfo)
	    {
	    }
};


#endif/*PMSTATEINFO_H_*/
