/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TCPCheTianEPD.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2021-6-25   Zhongchenyu create
**      
*********************************************************************/
#ifndef TCPCHETIANEPD_H_
#define TCPCHETIANEPD_H_



#include "TCPDevice.h"
#include "DeviceNode.h"
#include "IMutex.h"
#include <map>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
#endif

#define CheTian_TCPIP_PORT "15000"
#define BUFFER_SIZE 300

class TCPCheTianEPD:public TCPDevice
{
	DECLARE_DYNAMIC(TCPCheTianEPD)	
	DECLARE_MSG_MAP	
	
	protected:	//added by liusy 1.1.63
		
		typedef struct _TrendData
		{
			_TrendData(double value, int id, int offset)
			{
				m_value = value;
				m_ID = id;
				m_offSet = offset;
			}
			double m_value;
			int m_ID;
			int m_offSet;
		}TrendData;	
		typedef struct 
		{
			std::string m_name;
			char m_channel;
			char m_cmd;
			char m_status[4];
			std::string m_errormsg;
			int m_datalength;
			int m_reslength;
			std::string m_res;
			
		}Cmd;
		
		Cmd m_RECIPESTART;
		Cmd m_RECIPESTOP;
		Cmd m_COMPLETED;
		Cmd m_START;
		Cmd m_STOP;
		Cmd m_WAFERINFO;
		Cmd m_CFGLIST;
		Cmd m_STATE;
		Cmd m_VERSION;
		Cmd m_EVENT;
		Cmd m_RESPONSE;
		Cmd m_RESET;
		Cmd m_CONNECT;
		Cmd m_DISCONNECT;
		Cmd m_HEATBEAT;
		Cmd m_QUERYDATA;
		
		char m_sndBuffer[BUFFER_SIZE];
		char m_recvBuffer[BUFFER_SIZE];
		char m_head[4];
		IMutex m_lock;
		IMutex m_lockTrendData;
		std::map<std::string, TrendData*> m_trendDatas;
		typedef std::pair<std::string, TrendData*> TrendPair;
		
		void initChannels(DeviceNode<TCPCheTianEPD> *node);
		void initEPD();
		void initCmd();
		void sendCmd(Cmd *cmd);
		void preRead(char *buffer); 
		void replyCmd(); 
		void replyCmd(Cmd *cmd); 
		std::string replyErrorMsg(char *error);
		void readDatas();
		void replyEvent();
		void flush();
		void connectEPD();
		void readEPDTime();
		void readConfigList();	
	
		void sendWfrInfo();

		std::string m_configName;
		std::string m_lot[2];
		std::string m_slot[2];
		std::string m_Waferid[2];
		std::string m_Recipe;
		std::string m_Step;
		std::string m_configlist[2];
		std::string m_version;
		int m_status[2];
		int m_endpoint[2];
		double m_epdtime[2];
		std::string m_error[2];
	
	public:
		TCPCheTianEPD();
		virtual ~TCPCheTianEPD();
		
		virtual void init();
		virtual void acceptData();
		bool writeI(int channelNum, int setpt, const IntTypeInfo &);
		bool writeS(int channelNum, std::string value, const StringTypeInfo &);
		bool readS(int channelNum, std::string *value, const StringTypeInfo &);
		bool readI(int channelNum, int *value, const IntTypeInfo &);
		bool readD(int channelNum, double *value, const DoubleTypeInfo &);
};

#endif /*TCPCHETIANEPD_H_*/
