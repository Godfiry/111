/*
 * EtherCatCIFX.h
 *
 *  Created on: 2024��1��5��
 *      Author: liusiyuan
 */

#ifndef SRC_DEVICEACCESSOR_ETHERCATCIFX_H_
#define SRC_DEVICEACCESSOR_ETHERCATCIFX_H_

#include "cifxlinux.h"
#include "TLR_Results.h"
#include "cifXUser.h"
#include "TLR_Types.h"
#include "EtherCat.h"

typedef struct APPLICATION_COMMON_Ttag
{
	/* handle from driver api */
	TLR_HANDLE hDriver;

	/* channel handle from driver api */
	TLR_HANDLE hChannel;

	/* default timeout */
	TLR_UINT32 ulTimeout;


} APPLICATION_COMMON_T;

typedef struct APPLICATION_Ttag
{
	APPLICATION_COMMON_T tCommon;
} APPLICATION_T;

class EtherCatCIFX : public EtherCat {

public:
	EtherCatCIFX();
	virtual ~EtherCatCIFX();

	void loadDevice();
	void addDeviceParam(int macid, DeviceParam* dp);
	virtual bool readByte(int macid, char* buffer);
	virtual bool writeByte(int inmac, char* byte);

	TLR_RESULT sendRecvPkt(APPLICATION_T* ptApp, CIFX_PACKET* ptSendPkt, CIFX_PACKET* ptRecvPkt);
	void handlePacket(APPLICATION_T* ptApp, CIFX_PACKET* ptPacket);

	bool writeExplicit(int macid, char* buffer, int index, int subIndex, int datasize);
	bool readExplicit(int macid, char* buffer, int index, int subIndex, int& datasize);
	int readStatus(int nMacId);
	void ShowError(int32_t lError);
	void sendEmplyPkt(APPLICATION_T* ptApp);

	int getOutputByteSize(const int& macid);
	int getInputByteSize(const int& macid);
	int getOutputOffset(const int& macid);
	int getInputOffset(const int& macid);


private:

	TLR_RESULT CreateResources(APPLICATION_T** pptApp);
	TLR_RESULT FreeResources(APPLICATION_T* ptApp);
	TLR_RESULT CloseAll(APPLICATION_T* ptApp);
	TLR_RESULT Startup(APPLICATION_T* ptApp);
	TLR_RESULT PromptIntro(APPLICATION_T* ptApp);
	void initDeviceListMapTable();

private:

	APPLICATION_T* m_ptApp;

	CIFXHANDLE m_hDriver;
	CIFXHANDLE m_hChannel;
	CIFX_LINUX_INIT m_Init;
};

#endif /* SRC_DEVICEACCESSOR_ETHERCATCIFX_H_ */
