/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AdvancedMFC.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-6-18   LiJuanjuan create
**      
*********************************************************************/
#include "TCPSocket.h"
#include "ConfigException.h"
#include <iostream>
#include <sys/socket.h>
#include <errno.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/select.h> 
#include <sys/types.h>
#include <netdb.h>
#include <string.h>
#include <netinet/tcp.h>

using namespace std;

TCPSocket::TCPSocket(const std::string &server, std::string port)
{
	m_server = server;
	m_port = port;
	m_sockfd = -1;
	m_revTimeOut = 10;
	m_sndTimeOut = 10;
}

TCPSocket::~TCPSocket()
{	
}

void TCPSocket::connect()
{
	/*
	m_sockaddr.sin_family = AF_INET;
	if(inet_pton(AF_INET, m_server.c_str(), &m_sockaddr.sin_addr) != 1)  
	{
		throw ConfigException("creating socket failed for wrong server host :" + m_server);
	}  

	cout << m_port << endl;
	
	m_sockaddr.sin_port = htons(m_port);
	
	cout << m_sockaddr.sin_port << endl;*/
	addrinfo *t_addr = NULL;
	addrinfo t_hints;
	memset(&t_hints, 0, sizeof(t_hints));
	t_hints.ai_family = AF_INET;
	t_hints.ai_socktype = SOCK_STREAM;
	if(getaddrinfo(m_server.c_str(), m_port.c_str(), &t_hints, &t_addr) != 0)
	{
		throw ConfigException("get address info failed for: " + string(gai_strerror(errno)));
	}
	if(t_addr == NULL)
	{
		throw ConfigException("no address info for specified server " +  m_server + "and port " + m_port);
	}
	memset(&m_sockaddr, 0, sizeof(m_sockaddr));	
	m_sockaddr = t_addr->ai_addr;
	m_sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(m_sockfd < 0)
	{
		throw ConfigException("creating socket  failed");
	}
	if(::connect(m_sockfd, m_sockaddr, sizeof(*m_sockaddr)) != 0)
	{
		::close(m_sockfd);
		throw ConfigException("connect failed for error: " + string(strerror(errno)));
	}
	struct timeval t_timeout;
	t_timeout.tv_sec = m_revTimeOut;
	t_timeout.tv_usec = 0;
	if(setsockopt(m_sockfd, SOL_SOCKET, SO_RCVTIMEO, &t_timeout, sizeof(t_timeout)) != 0)
	{
		throw ConfigException("set socket SO_RCVTIMEO option failed");
	}
	t_timeout.tv_sec = m_sndTimeOut;
	t_timeout.tv_usec = 0;	
	if(setsockopt(m_sockfd, SOL_SOCKET, SO_SNDTIMEO, &t_timeout, sizeof(t_timeout)) != 0)
	{
		throw ConfigException("set socket SO_SNDTIMEO option failed");
	}	
}

int TCPSocket::shutdown(int rw)
{	
	return ::shutdown(m_sockfd, rw);
}

int TCPSocket::close()
{
	return ::close(m_sockfd);
}
	
int TCPSocket::reconnect()
{
	m_sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(::connect(m_sockfd, m_sockaddr, sizeof(*m_sockaddr)) != 0)
	{
		::close(m_sockfd);
		return -1;
	}
	struct timeval t_timeout;
	t_timeout.tv_sec = m_revTimeOut;
	t_timeout.tv_usec = 0;
	if(setsockopt(m_sockfd, SOL_SOCKET, SO_RCVTIMEO, &t_timeout, sizeof(t_timeout)) != 0)
	{
		return -2;
	}
	t_timeout.tv_sec = m_sndTimeOut;
	t_timeout.tv_usec = 0;	
	if(setsockopt(m_sockfd, SOL_SOCKET, SO_SNDTIMEO, &t_timeout, sizeof(t_timeout)) != 0)
	{
		return -3;
	}	
	return 0;
}		


int TCPSocket::sendData(const char *data, int size)
{
	return send(m_sockfd, data, size, 0);
}

int TCPSocket::recvFixLenData(char *buffer, int len)
{
	return recv(m_sockfd, buffer, len, MSG_WAITALL);
}
		
int TCPSocket::recvData(char *buffer, int len)
{
	return recv(m_sockfd, buffer, len, 0);
}

void TCPSocket::setRcvTimeOut(int timeout)
{
	m_revTimeOut = timeout;
}

void TCPSocket::setSndTimeOut(int timeout)
{
	m_sndTimeOut = timeout;
}

int TCPSocket::select()
{
	int t_select;
	while(true)
	{
		fd_set t_rset;
		FD_ZERO(&t_rset);
		FD_SET(m_sockfd, &t_rset);
		t_select = ::select(m_sockfd+1, &t_rset, NULL, NULL, NULL);	 
		if(t_select == -1)
		{
			if(errno == EINTR)
			{
				continue;
			}
		}
		return t_select;
	}
}
		
int TCPSocket::getErrno()const
{
	return errno;
}
		
std::string TCPSocket::getErrnoStr()const
{
	return string(strerror(errno));
}

bool TCPSocket::isConnected()
{
	if(m_sockfd < 0)
		return false;
	struct tcp_info info;
	int len = sizeof(struct tcp_info);
	getsockopt(m_sockfd,IPPROTO_TCP,TCP_INFO,&info, (socklen_t *)&len);
	if(info.tcpi_state == TCP_ESTABLISHED)
	{
		return true;
	}
	return false;
}

