/********************************************************************
** Copyright (c) 2020, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: GeneratorAdtecTx03.cpp
** Description:
** Release: 1.1
** Modification history:
** 					2020-2-5   zhangyy create
**
*********************************************************************/

#include "GeneratorAdtecTx03.h"
#include "DeviceManager.h"
#include "ObjectManager.h"
#include "Converter.h"
#include <iostream>
#include <sys/time.h>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std;

GeneratorAdtecTx03::Cmd GeneratorAdtecTx03::m_commands[] = {
		{0, "S", 0     },   // 0. Stop RF power output
		{0, "G", 0     },   // 1. Start RF power output
		{1, "RESET",  0},   // 2. Reset Generator alarm status
		{1, "W", 0     }    // 3. Set RF power output.For example, 02995 means 299.5W
};

GeneratorAdtecTx03::ReadCmd GeneratorAdtecTx03::m_readCommands[] = {
		{"Q", 14, 5, 33, 14 },//200.Request forward power,  F1F2F3F4F5, substr(14,5)
		{"Q", 20, 5, 33, 14 },//201.Request reflectd power, R1R2R3R4R5, substr(20,5)
		{"Q", 0,  1, 33, 14 },//202.Request control mode, M(0:Manual Mode; 1:Analog Mode; 2:RS232C Mode), substr(0,1)
		{"Q", 2,  1, 33, 14 },//203.Request RF output Status, K(0:RF OFF; 1:RF ON), substr(2,1)
		{"Q", 5,  2, 33, 14 } //204.Request Alarm Status, A1A2(00:No Alarm; 01~99: Different Alarm), substr(5,2)

};

GeneratorAdtecTx03::GeneratorAdtecTx03():SerialDevice(200, "\x0D")
{
	//m_timeOut = 20;//20s, m_timeOut = 10 in SerialDevice
	m_nReadTimeOut = 10;//1s
	m_strErrorCode = "";
	m_strRFStatus = "";
	m_strRFMode = "";
	
}

GeneratorAdtecTx03::~GeneratorAdtecTx03()
{

}

bool GeneratorAdtecTx03::sendCommand(const std::string &strCommand)
{
	string strResult = getCommandResult(strCommand,m_timeOut);
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "AdtecGenerator send "+strCommand+" get Result =" + strResult);
	if(strCommand == "RESET" && strResult.find("Really?") != string::npos)
	{
		sendCommandOnly("Y"); //Ensure Reset command, send Y
		return true;
	}
	else if(strResult.find("\x0D",0) != string::npos)
	{
		if(strResult.find("N",0)!= string::npos)
		{
			throw IOException(getDeviceName() + ": send " +strCommand +" incorrect or command cannot be processed");
		}
	}
	else
	{
		throw IOException(getDeviceName() + ": send " +strCommand +" get unknown readback:" + strResult);
	}
	return true;
}

bool GeneratorAdtecTx03::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
	Cmd cmd = m_commands[nChannelNum];
	string strMsg = cmd.strCmd;
	int nType = cmd.nType;
	int nTemp = 0;
	if(m_strRFMode != "2") //2 means RS232C Mode
	{
		//For Adtec can't be controlled in other mode except RS232C
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "AdtecGenerator change RS232C mode before send command.");
		sendCommand("RS232C"); //Change RS232C mode
	}	
	if(nType == 0)
	{
		strMsg = m_commands[nChannelNum + nValue].strCmd;
		requestInt(203,&nTemp,IntTypeInfo());  //add by th 1.1.54
		if((strMsg == "S" && m_strRFStatus == "0") || (strMsg == "G" && m_strRFStatus == "1"))//0 means RF-OFF, 1 means RF-ON
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "AdtecGenerator don't need start/stop due to already satisfied! ");
			return true;
		}
	}
	return sendCommand(strMsg); //For Reset command
}

bool GeneratorAdtecTx03::writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
	Cmd cmd = m_commands[nChannelNum];
	string strMsg = "";
	if(m_strRFMode != "2")//2 means RS232C Mode
	{
		//For Adtec can't be controlled in other mode except RS232C
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "AdtecGenerator change RS232C mode before send command.");
		sendCommand("RS232C"); //Change RS232C mode
	}
	int nValue = (int)(dValue*10); //For 02995 means 299.5W
	char Format[6]={0};
	sprintf(Format,"%05d",nValue);
	strMsg = " " +cmd.strCmd;
	strMsg = Format + strMsg;
	return sendCommand(strMsg);
}

bool GeneratorAdtecTx03::writeRawCommand(int nChannelNum, std::string strValue, const StringTypeInfo &typeInfo)
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "AdtecGenerator send command = "+strValue);
	return sendCommand(strValue);
}

bool GeneratorAdtecTx03::requestInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
	ReadCmd readCmd = m_readCommands[nChannelNum - 200];
	string strRequestCmd = readCmd.strCmd;
	int nReadBack = 0;
	if(strRequestCmd == "Q")
	{
		std::string strRawResult = getFixCommandResult(strRequestCmd, m_nReadTimeOut, readCmd.nCorrectResponseLen, readCmd.nRetryTime);
		//cout<<"Send Q command get result =  "<<strRawResult<<endl;
		if(strRawResult.find("\x0D\x0D",0) != string::npos)
		{
			std::string strReadBack = strRawResult.substr(readCmd.nSubStartPos,readCmd.nSubLength);
			m_strRFStatus = strRawResult.substr(2,1);// Get current RF ON/OFF Status
			m_strRFMode = strRawResult.substr(0,1);// Get current RF Control Mode
			if(!Converter::stringToInt(nReadBack, strReadBack))//convert string to int using Converter
			{
				throw IOException("read_back value is not a valid int value:" + strReadBack);
			}
			
			if(nChannelNum == 204)
			{
				if(nReadBack == 0)
				{
					*pValue = 0; // No Alarm
				}
				else
				{
					*pValue = 1; //Has Alarm
					m_strErrorCode = strReadBack; // Get Error Code
					//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "AdtecGenerator post Error code =" + m_strErrorCode);
				}
			}
			else
			{
				*pValue = nReadBack;
			}
			return true;
		}
		else
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "AdtecGeneratorTx03 send "+strRequestCmd +" again.");
			std::string strRawResultAgain = getFixCommandResult(strRequestCmd, m_nReadTimeOut, readCmd.nCorrectResponseLen, readCmd.nRetryTime);
			if(strRawResultAgain.find("\x0D\x0D",0) != string::npos)
			{
				std::string strReadBackAgain = strRawResultAgain.substr(readCmd.nSubStartPos,readCmd.nSubLength);
				m_strRFStatus = strRawResultAgain.substr(2,1);// Get current RF ON/OFF Status again
				m_strRFMode = strRawResultAgain.substr(0,1);// Get current RF Control Mode again
				if(!Converter::stringToInt(nReadBack, strReadBackAgain))//convert string to int using Converter
				{
					throw IOException("read_back value is not a valid int value:" + strReadBackAgain);
				}
				if(nChannelNum == 204)
				{
					if(nReadBack == 0)
					{
						*pValue = 0; // No Alarm
					}
					else
					{
						*pValue = 1; //Has Alarm
						m_strErrorCode = strReadBackAgain; // Get Error Code
						//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "AdtecGenerator post Error code =" + m_strErrorCode);
					}
				}
				else
				{
					*pValue = nReadBack;
				}
				return true;
			}
			else
			{
				throw IOException("Send read command = "+strRequestCmd +", Unknown read back : " + strRawResultAgain);
			}
		}
	}
}

bool GeneratorAdtecTx03::requestDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo)
{
	ReadCmd readCmd = m_readCommands[nChannelNum - 200];
	string strRequestCmd = readCmd.strCmd;
	double dReadBack;
	if(strRequestCmd == "Q")
	{
		std::string strReadBack = getFixCommandResult(strRequestCmd, m_nReadTimeOut, readCmd.nCorrectResponseLen, readCmd.nRetryTime);

		if(strReadBack.find("\x0D\x0D",0) != string::npos)
		{
			strReadBack = strReadBack.substr(readCmd.nSubStartPos,readCmd.nSubLength);
			if(!Converter::stringToDouble(dReadBack, strReadBack))//convert string to double using Converter
			{
				throw IOException("read_back value is not a valid double value:" + strReadBack);
			}
			//cout<<"dReadBack = "<<dReadBack<<endl;
			*pValue = dReadBack/10;
			return true;		
		}
		else
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "AdtecGeneratorTx03 send "+strRequestCmd +" again.");
			std::string strReadBackAgain = getFixCommandResult(strRequestCmd, m_nReadTimeOut, readCmd.nCorrectResponseLen, readCmd.nRetryTime);
			if(strReadBackAgain.find("\x0D\x0D",0) != string::npos)
			{
				strReadBackAgain = strReadBackAgain.substr(readCmd.nSubStartPos,readCmd.nSubLength);
				if(!Converter::stringToDouble(dReadBack, strReadBackAgain))//convert string to double using Converter
				{
					throw IOException("read_back value is not a valid double value:" + strReadBackAgain);
				}
				else
				{
					*pValue = dReadBack/10;
					return true;
				}	
			}
			else
			{
				throw IOException("Send read command = "+strRequestCmd +", Unknown read back : " + strReadBackAgain);
			}
		}
	}
}

bool GeneratorAdtecTx03::getErrorCode(int nChannelNum, std::string *pValue, const StringTypeInfo &typeInfo)
{
	*pValue = m_strErrorCode;
	return true;
}

void GeneratorAdtecTx03::InitChannels(DeviceNode<GeneratorAdtecTx03> *pNode)
{
	for(int i=0; i<= 2; ++i)
	{
		pNode->registerWriteCh(i,&GeneratorAdtecTx03::writeInt);
	}
	pNode->registerWriteCh(3,&GeneratorAdtecTx03::writeDouble);

	for(int i=200; i<= 201; ++i)
	{
		pNode->registerReadCh(i,&GeneratorAdtecTx03::requestDouble);
	}
	for(int i=202; i<= 204; ++i)
	{
		pNode->registerReadCh(i,&GeneratorAdtecTx03::requestInt);
	}
	//pNode->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &GeneratorAdtecTx03::getStatus);//added by mujy [v1.0.8]
	pNode->registerWriteCh(1001, &GeneratorAdtecTx03::writeRawCommand);
	pNode->registerReadCh(1002, &GeneratorAdtecTx03::getErrorCode);
}
void GeneratorAdtecTx03::initDevice()
{
	
	cout<<"start scan AdtecGeneratorTx03..."<<endl;
	try
	{
		int nTemp = 0;
		sendCommand("RS232C"); //Change RS232C mode
		requestInt(203,&nTemp,IntTypeInfo());   //add by th 1.1.54
	}
	catch(exception &ex)
	{
		cout<<"Scan AdtecGeneratorTx03 failed. Communication abnormal!"<<endl;
		throw;
	}
	cout<<"scan AdtecGeneratorTx03 successfully."<<endl;	
}

void GeneratorAdtecTx03::init()
{
    DeviceNode<GeneratorAdtecTx03> *pNode = new DeviceNode<GeneratorAdtecTx03>(m_pollPeriod,this);
    DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
    if(!isSimulated())
   	{
   	    InitChannels(pNode);
   	    initDevice();
    }
}

string GeneratorAdtecTx03::getDeviceName()
{
	return __FILE__;
}

IMPLEMENT_DYNAMIC(GeneratorAdtecTx03, SerialDevice )
BEGIN_MSG_MAP(GeneratorAdtecTx03, SerialDevice )
    SET_V( init, GeneratorAdtecTx03 )
END_MSG_MAP
