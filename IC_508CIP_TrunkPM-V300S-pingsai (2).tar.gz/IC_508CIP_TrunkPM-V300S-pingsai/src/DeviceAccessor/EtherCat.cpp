/*
 * EtherCat.cpp
 *
 *  Created on: 2023��11��2��
 *      Author: liusiyuan
 */

#include "EtherCat.h"

EtherCat::EtherCat() {
	// TODO Auto-generated constructor stub
	m_TimeOut = 10;
	m_bDebugEnable = false;
	m_nDeviceNum = 0;
}

EtherCat::~EtherCat() {
	// TODO Auto-generated destructor stub

}

void EtherCat::setDebugMode(bool bDebugEnable)
{
	m_bDebugEnable = bDebugEnable;
}

void EtherCat::setDeviceNum(int nNum)
{
	m_nDeviceNum = nNum;
}

void EtherCat::setTimeOut(int time)
{
	m_TimeOut = time;
}
