/********************************************************************
** Copyright (c) 2019, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AlarmTool.h
** Description:
** Created on: Jan 9, 2019
** Author: mujy
** Modification history:
**						[V1.0.0.2] create
**
*********************************************************************/
#ifndef ALARMTOOL_H_
#define ALARMTOOL_H_

#include "Alarm.h"
#include "ControlObjectEX.h"
#include "Service.h"
#include "Recovery.h"
#include <vector>
#ifdef IAP4_0
using namespace IAP::ALARM;
using namespace IAP::CONTROL;
#endif

class AlarmTool:public ControlObjectEX
{
	
	DECLARE_DYNAMIC(AlarmTool)
	DECLARE_MSG_MAP
	DECLARE_SERVICEINFO_LIST	
	public:
	class Print : public Service
	{
		DECLARE_DYNAMIC_SERVICE(Print)
		public:
			void execute();
	};
	class RenamePrint : public Service
	{
		DECLARE_DYNAMIC_SERVICE(RenamePrint)
		public:
			void execute();
	};

	public:
		AlarmTool();
		virtual ~AlarmTool();
	
	public:
		void call_Print();
		virtual void do_Print();
		void call_RenamePrint();
		virtual void do_RenamePrint();
	
	public://override
		virtual void make();
		virtual void verifyInit();

	protected:
		//FileLogger * m_pAlmLog;
	private:
		ServicePtr<Print> m_sPrint;
		ServicePtr<RenamePrint> m_sRenamePrint;
};

#endif /*AlarmInfo_H_*/
