/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: CheckItem.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-9-28   LiJuanjuan create
**      
*********************************************************************/
#ifndef CHECKITEMCONTROLBYSEQUENCE_H_
#define CHECKITEMCONTROLBYSEQUENCE_H_

#include "ControlObjectEX.h"
#include "Service.h"
#include "ReadWriteInt.h"
#include "AppCondition.h"
#include "NonBlockingAlarm.h"
#include "ReadWriteDouble.h"
#include "IMutex.h"
#include <vector>
#include <SetupTool.h>
#include "StatusMonitor.h"
#include "CheckItem.h"
#include "XmlGetter.h"//add by zhangpf[v1.6.6]

class CheckItemControlBySequence:public ControlObjectEX
{
	DECLARE_DYNAMIC(CheckItemControlBySequence)
	DECLARE_MSG_MAP
	DECLARE_SERVICEINFO_LIST		
	public:
		class Enable : public Service
		{
			DECLARE_DYNAMIC_SERVICE(Enable)

			public:
				void execute();
		};

		class Disable : public Service
		{
			DECLARE_DYNAMIC_SERVICE(Disable)

			public:
				void execute();
		};

		class EnableAll : public Service
		{
			DECLARE_DYNAMIC_SERVICE(EnableAll)

			public:
				void execute();
		};


	public:
	    static CheckItemControlBySequence* getInstance();

	private:
		CheckItemControlBySequence();
		virtual ~CheckItemControlBySequence();
		// no copy
		CheckItemControlBySequence(const CheckItemControlBySequence&);
		CheckItemControlBySequence& operator=(const CheckItemControlBySequence&);

	public://xml
		void addCheckItemControl(const std::string& strControlMethod, const std::string& strCheckItemFullName);

	    //for override
		virtual void do_Enable(const std::string &strControlMethod);
		virtual void do_Disable(const std::string &strControlMethod);
		virtual void do_EnableAll();
		virtual void doAbort();

	public:
		void call_Enable(const std::string &strControlMethod);
		void call_Disable(const std::string &strControlMethod);
		void call_EnableAll();

	protected:

        std::map<std::string, std::vector<CheckItem*> > m_CheckItemIdControlMap;

	private:
		ServicePtr<Enable> m_sEnable;
		ServicePtr<Disable> m_sDisable;
		ServicePtr<EnableAll> m_sEnableAll;
		static CheckItemControlBySequence* m_pInstance;
		static IMutex* m_mutex;//add by zhangpf[v1.11.0]
};

#endif /*CHECKITEMCONTROLBYSEQUENCE_H_*/
