/*************************************************************************************
** Copyright (c) 2007, Beijing NMC Co.Ltd.  All rights reserved.
** File name: 	OperationalPM.cpp
** Description: 
** Release: 		1.0
** Modification history:
** 					
**
*************************************************************************************/

#include "OperationalPM.h"
#include "XferStsInfo.h"
#include "XferAnmInfo.h"
#include "ObjectManager.h"
#include "SysLogger.h"
#include "Converter.h"
#include "RecipeNamespace.h"
#include "RecipeNamespaceManager.h"
#include "ProcessRcpExecutor.h"
#include "RecipeClass.h"
#include "IdleActiveInfo.h"
#include "HandoffModeInfo.h"
#include "HandoffModeInfo.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "AbortException.h"
#include "AlarmPostedException.h"
#include "NoDescriptorException.h"
#include "InvalidParameterException.h"
#include "InvalidNameException.h"
#endif
#include "NoSuchNameException.h"
#include "ConfigException.h"




#include "CTCExport.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::RECIPE;
using namespace IAP;
#endif

using namespace std;

class HandoffModeInfo;

OperationalPM::OperationalPM()
{
	m_pOperationalProcess = NULL;
	m_pXferSts = NULL;
	m_pXferAnm = NULL;
	
	m_sPrepChamb = new PrepChamb();
	m_sPrepChamb->setOwner(this);
	m_sPrepWfr = new PrepWfr();
	m_sPrepWfr->setOwner(this);
	m_sCompWfr = new CompWfr();
	m_sCompWfr->setOwner(this);
	m_sJobStartCondition = new JobStartCondition();//[wangyk 1.1.60]
	m_sJobStartCondition->setOwner(this);
	m_sJobEndCondition = new JobEndCondition();//[wangyk 1.1.60]
	m_sJobEndCondition->setOwner(this);
}

OperationalPM::~OperationalPM()
{

}

void OperationalPM::PrepChamb::execute()
{
	ControlObject *owner = getOwner();
	static_cast<OperationalPM*>(owner)->do_PrepChamb(Params["port"].Int);
}

void OperationalPM::PrepWfr::execute()
{
	ControlObject *owner = getOwner();
	int nSlot = Params["slot"].Int;
	int nTransferOperation = Params["wfrOpr"].Int;
	int nHandOffMode = Params["handoffmode"].Int;
	int nWaferID = Params["waferID"].Int;
	string strLotID = Params["lotID"].Str;
	string strWfrName = Params["wfrName"].Str;		
	static_cast<OperationalPM*>(owner)->do_PrepWfr(nSlot,nTransferOperation,nHandOffMode,nWaferID,strLotID,strWfrName);
}

void OperationalPM::CompWfr::execute()
{
	ControlObject *owner = getOwner();
	static_cast<OperationalPM*>(owner)->do_CompWfr();
}

void OperationalPM::JobStartCondition::execute()//[wangyk 1.1.60]
{
	#ifdef IAP4_0
	Result.Bool = false;
	#else
	Results["result"].Bool = false;
	#endif
	ControlObject *owner = getOwner();
	string strProcessRecipeName = Params["ProcessRecipeName"].Str;
	static_cast<OperationalPM*>(owner)->do_JobStartCondition(strProcessRecipeName);
	#ifdef IAP4_0
	Result.Bool = true;
	#else
	Results["result"].Bool = true;
	#endif
}

void OperationalPM::JobEndCondition::execute()//[wangyk 1.1.60]
{
	#ifdef IAP4_0
	Result.Bool = false;
	#else
	Results["result"].Bool = false;
	#endif
	ControlObject *owner = getOwner();
	string strProcessRecipeName = Params["ProcessRecipeName"].Str;
	static_cast<OperationalPM*>(owner)->do_JobEndCondition(strProcessRecipeName);
	#ifdef IAP4_0
	Result.Bool = true;
	#else
	Results["result"].Bool = true;
	#endif
}

void OperationalPM::make()
{
	Log_Info( getName() + " : start of make");
	OperationalModel::make();
	
	m_pXferSts = new ReadWriteInt(XferStsInfo::typeInfo);
	ObjectManager::getInstance()->registerObject(m_pXferSts, getName() + "/Sts");
	m_pXferSts->setValue(0);	
	CTCExport::exportAsOthers(m_pXferSts, getSelfName() + "_XferSts");
		
		
	m_pXferAnm = new ReadWriteInt(XferAnmInfo::typeInfo);
	ObjectManager::getInstance()->registerObject(m_pXferAnm, getName() + "/Anm");
	m_pXferAnm->setValue(0);	
	CTCExport::exportAsOthers(m_pXferAnm, getSelfName() + "_XferAnm");

	try
	{
		m_pOperationalProcess =  (OperationalProcess *) ObjectManager::getInstance()->getObject(this, "./S1");	
	}
	catch(NoSuchNameException _ex)
	{
		throw NoSuchNameException("PM S1 for " + this->getName() + " not found");
	}
	Log_Info( getName() + " end of make");
}

void OperationalPM::startup()
{
	Log_Info( getName() + " start of startup");
	OperationalModel::startup();
	Log_Info( getName() + " end of startup");
}

void OperationalPM::shutdown()
{
	OperationalModel::shutdown();
}

/*
 * 
 */
void OperationalPM::call_PrepChamb(int nPort)
{	
	call(m_sPrepChamb);
}

/*
 * 
 */
void OperationalPM::call_PrepWfr(int nSlot, int nTransferOperation, int nHandOffMode,int nWaferID,string strLotID, string strWfrName)
{
	m_sPrepWfr->setParamValue("slot",nSlot);
	m_sPrepWfr->setParamValue("wfrOpr",nTransferOperation);
	m_sPrepWfr->setParamValue("handoffmode",nHandOffMode);
	m_sPrepWfr->setParamValue("waferID",nWaferID);
	m_sPrepWfr->setParamValue("lotID",strLotID);
	m_sPrepWfr->setParamValue("wfrName",strWfrName);
	call(m_sPrepWfr);
}
/*
 * 
 */
void OperationalPM::call_CompWfr()
{	
	call(m_sCompWfr);
}
/*
 * 
 */	

void OperationalPM::call_JobStartCondition(string strProcessRecipeName)//[wangyk 1.1.60]
{
	m_sJobStartCondition->setParamValue("ProcessRecipeName",strProcessRecipeName); //added by zhangpf[1.8.2]
	call(m_sJobStartCondition);
}
/*
 *
 */
void OperationalPM::call_JobEndCondition(string strProcessRecipeName)//[wangyk 1.1.60]
{
	m_sJobEndCondition->setParamValue("ProcessRecipeName",strProcessRecipeName); //added by zhangpf[1.8.2]
	call(m_sJobEndCondition);
}
/*
 *
 */
void OperationalPM::do_PrepChamb(int nPort)
{
	Log_Info( getName() + ": do_PrepChamber  start - "+Converter::convertToString(nPort));
	if(checkMode_JobService())
	{
		m_pXferSts->setValue(XferStsInfo::PreChming);
		m_pXferAnm->setValue(XferAnmInfo::PreChming);
		try
		{
			getFuncPMModule()->call_PrepChamb(nPort);
			m_pXferSts->setValue(XferStsInfo::PreChmbed);
			m_pXferAnm->setValue(XferAnmInfo::PreChmbed);
		}
		catch(const RetryException &retryException)
		{
			throw;
		}
		catch(const InterruptException &interruptException)
		{
			Log_Error(getName()+" do Prepare Chamber catch InterruptException - "+string(interruptException.what()));
			m_pXferSts->setValue(XferStsInfo::Aborted);
			m_pServiceName->setValue("Prepare chamber");
			m_pErrorDescription->setValue("Manual Abort");
			m_pServiceFailedAlarm->post(this);
			throw;
		}
		catch(const exception &ex)
		{
			Log_Error(getSelfName() + ": do_PrepChamber  got exception-" +ex.what());
			m_pXferSts->setValue(XferStsInfo::Aborted);
			m_pServiceName->setValue("Prepare chamber");
			m_pErrorDescription->setValue(ex.what());
			if(!m_pServiceFailedAlarm->isPosted() && string(ex.what()).find("executed recovery 'ABORT'") == string::npos)
			{
				m_pServiceFailedAlarm->post(this);
			}
			throw;
		}
	}
	Log_Info( getName() + ": do_PrepChamber  end");
}

/*
 * 
 */
void OperationalPM::do_PrepWfr(int nSlot, int nTransferOperation, int nHandOffMode,int nWaferID,string strLotID, string strWfrName)
{
	Log_Info( getName() + ": do_PrepWfr start, slot=" + Converter::convertToString(nSlot) + ", operation=" + getTransferOperation(nTransferOperation)+", waferID=" + Converter::convertToString(nWaferID) + " LotID="+strLotID+" waferName="+strWfrName);
	if(checkMode_JobService())
	{
		m_pXferSts->setValue(XferStsInfo::PrpWfring);
		m_pXferAnm->setValue(XferAnmInfo::Moving);

		try
		{
			getFuncPMModule()->call_PrepWfr(nSlot, nTransferOperation, nHandOffMode,nWaferID,strLotID,strWfrName);
				
			m_pXferSts->setValue(XferStsInfo::PrpWfred);
			m_pXferAnm->setValue(XferAnmInfo::Moved);
		}
		catch(const RetryException &retryException)
		{
			throw;
		}
		catch(const InterruptException &interruptException)
		{
			Log_Error(getName()+" do Prepare wafer catch InterruptException - "+string(interruptException.what()));
			m_pXferSts->setValue(XferStsInfo::Aborted);
			m_pServiceName->setValue("Prepare wafer");
			m_pErrorDescription->setValue("Manual Abort");
			m_pServiceFailedAlarm->post(this);
			throw;
		}
		catch(const exception &ex)
		{
			Log_Error( getName() + ": do_PrepWfr  got exception-" +ex.what());
			m_pXferSts->setValue(XferStsInfo::Aborted);
			m_pServiceName->setValue("Prepare wafer");
			m_pErrorDescription->setValue(ex.what());
			if(!m_pServiceFailedAlarm->isPosted() && string(ex.what()).find("executed recovery 'ABORT'") == string::npos)
			{
				m_pServiceFailedAlarm->post(this);
			}
			throw;
		}
	}
	Log_Info( getName() + ": do_PrepWfr  end");
}

/*
 * 
 */
void OperationalPM::do_CompWfr()
{
	Log_Info( getName() + ":do_CompWfr  start");
	if(checkMode_JobService())
	{
		m_pXferSts->setValue(XferStsInfo::CmtWfring);

		try
		{
			getFuncPMModule()->call_CompWfr();
		}
		catch(const RetryException &retryException)
		{
			throw;
		}
		catch(const InterruptException &interruptException)
		{
			Log_Error(getName()+" do_CompWfr catch InterruptException - "+string(interruptException.what()));
			m_pXferSts->setValue(XferStsInfo::Aborted);
			m_pServiceName->setValue("Complete wafer transfer");
			m_pErrorDescription->setValue("Manual Abort");
			m_pServiceFailedAlarm->post(this);
			throw;
		}
		catch(const exception &ex)
		{
			Log_Error(getName() + ": do_CompWfr  got exception--" +ex.what());
			m_pXferSts->setValue(XferStsInfo::Aborted);
			m_pServiceName->setValue("Prepare wafer");
			m_pErrorDescription->setValue(ex.what());
			if(!m_pServiceFailedAlarm->isPosted() && string(ex.what()).find("executed recovery 'ABORT'") == string::npos)
			{
				m_pServiceFailedAlarm->post(this);
			}
			throw;
		}
		m_pXferSts->setValue(XferStsInfo::CmtWfred);
	}
	Log_Info( getName() + ":do_CompWfr  end");
}

/*
 *
 */
void OperationalPM::do_JobStartCondition(string strProcessRecipeName)//[wangyk 1.1.60]
{
	Log_Info( getName() + ":do_JobStartCondition  start");
	if(checkMode_JobService())
	{
		try
		{
			getFuncPMModule()->call_JobStartCondition(strProcessRecipeName);
		}
		catch(const RetryException &retryException)
		{
			throw;
		}
		catch(const InterruptException &interruptException)
		{
			Log_Error(getName()+" do_JobStartCondition catch InterruptException - "+string(interruptException.what()));
			m_pXferSts->setValue(XferStsInfo::Aborted);
			m_pServiceName->setValue("JobStartCondition");
			m_pErrorDescription->setValue("Manual Abort");
			m_pServiceFailedAlarm->post(this);
			throw;
		}
		catch(const exception &ex)
		{
			Log_Error(getName() + ": do_JobStartCondition  got exception--" +ex.what());
			m_pXferSts->setValue(XferStsInfo::Aborted);
			m_pServiceName->setValue("JobStartCondition");
			m_pErrorDescription->setValue(ex.what());
			if(!m_pServiceFailedAlarm->isPosted() && string(ex.what()).find("executed recovery 'ABORT'") == string::npos)
			{
				m_pServiceFailedAlarm->post(this);
			}
			throw;
		}
	}
}
/*
 *
 */
void OperationalPM::do_JobEndCondition(string strProcessRecipeName)//[wangyk 1.1.60]
{
	Log_Info( getName() + ":do_JobEndCondition  start");
	if(checkMode_JobService())
	{
		try
		{
			getFuncPMModule()->call_JobEndCondition(strProcessRecipeName);
		}
		catch(const RetryException &retryException)
		{
			throw;
		}
		catch(const InterruptException &interruptException)
		{
			Log_Error(getName()+" do_JobEndCondition catch InterruptException - "+string(interruptException.what()));
			m_pXferSts->setValue(XferStsInfo::Aborted);
			m_pServiceName->setValue("JobEndCondition");
			m_pErrorDescription->setValue("Manual Abort");
			m_pServiceFailedAlarm->post(this);
			throw;
		}
		catch(const exception &ex)
		{
			Log_Error(getName() + ": do_JobEndCondition  got exception--" +ex.what());
			m_pXferSts->setValue(XferStsInfo::Aborted);
			m_pServiceName->setValue("JobEndCondition");
			m_pErrorDescription->setValue(ex.what());
			if(!m_pServiceFailedAlarm->isPosted() && string(ex.what()).find("executed recovery 'ABORT'") == string::npos)
			{
				m_pServiceFailedAlarm->post(this);
			}
			throw;
		}
	}
	Log_Info( getName() + ":do_JobEndCondition  end");
}

void OperationalPM::do_Init()
{
	Log_Info( getName() + ":do_Init  start");
	m_pXferSts->setValue(XferStsInfo::Initting);//added by xiasc[v1.7.03]
	try
	{
		getFuncPMModule()->setMessage("Initialize...");
    	OperationalModel::do_Init();
    	
    	m_pXferSts->setValue(XferStsInfo::Initted);
    	m_pXferAnm->setValue(XferAnmInfo::Init);
    	getFuncPMModule()->setMessage("Idle");
	}
	catch(const AbortException &ex)
	{
		Log_Error( getName() + ": do_Init  got abort exception-" +ex.what());
		m_pXferSts->setValue(XferStsInfo::Aborted);
		throw;
	}
	catch(const RetryException &retryexception)
	{
		throw;
	}
	catch(const exception &ex)
	{
		Log_Error(getName() + ": do_Init  got exception--" +ex.what());
		m_pXferSts->setValue(XferStsInfo::Aborted);
		throw;
	}	
    Log_Info( getName() + ":do_Init  end");
}

void OperationalPM::do_Shutdown()
{
	Log_Info( getName() + ":do_Shutdown  start");
	m_pXferSts->setValue(XferStsInfo::Shutdown);
	m_pXferAnm->setValue(XferAnmInfo::Ending);
	
	OperationalModel::do_Shutdown();
	
	m_pXferSts->setValue(XferStsInfo::Shut);
	m_pXferAnm->setValue(XferAnmInfo::Ended);
	Log_Info( getName() + ":do_Shutdown  end");
}

FunctionalPM* OperationalPM::getFuncPMModule()
{
	return dynamic_cast<FunctionalPM*>(m_pFunctionalModel);
}

string OperationalPM::getTransferOperation(int nTransferOperation)
{
	string strTransferOperation;
	switch(nTransferOperation)
	{
		case TransferOperationInfo::Send: // '\001'
			strTransferOperation = "Send";
			break;

		case TransferOperationInfo::Receive: // '\0'
			strTransferOperation = "Receive";
			break;
		case TransferOperationInfo::Swap: // '\002'
			strTransferOperation = "Swap";
			break;
		default:
			strTransferOperation = "unknown";
	}
	return strTransferOperation;
}
IMPLEMENT_DYNAMIC_SERVICE(PrepChamb, OperationalPM)
IMPLEMENT_DYNAMIC_SERVICE(PrepWfr, OperationalPM)
IMPLEMENT_DYNAMIC_SERVICE(CompWfr, OperationalPM)
IMPLEMENT_DYNAMIC_SERVICE(JobStartCondition, OperationalPM)//[wangyk 1.1.60]
IMPLEMENT_DYNAMIC_SERVICE(JobEndCondition, OperationalPM)//[wangyk 1.1.60]

BEGIN_SERVICEINFO_LIST(OperationalPM)
	ADD_SERVICE_INFO(OperationalPM, PrepChamb, The PrepChamb service)
		ADD_PARAM_INFO(OperationalPM, PrepChamb, port, int, VBE1:1 AFE1:2)
	ADD_SERVICE_INFO(OperationalPM, PrepWfr, The PrepWfr service )
		ADD_PARAM_INFO(OperationalPM, PrepWfr, slot, int, )
		ADD_PARAM_INFO(OperationalPM, PrepWfr, wfrOpr, int, Receive:0 Send:1 Swap:2 Xfer:2)
		ADD_PARAM_INFO(OperationalPM, PrepWfr, handoffmode, int, UnInit:-1 Unknown:0 Passive:1 Active:2)
		ADD_PARAM_INFO(OperationalPM, PrepWfr, waferID, int, )
		ADD_PARAM_INFO(OperationalPM, PrepWfr, lotID, string, )
		ADD_PARAM_INFO(OperationalPM, PrepWfr, wfrName, string, )
	ADD_SERVICE_INFO(OperationalPM, CompWfr, The CompWfr service )
	ADD_SERVICE_INFO(OperationalPM, JobStartCondition, The JobStartCondition service )//[wangyk 1.1.60]
		ADD_PARAM_INFO(OperationalPM, JobStartCondition, ProcessRecipeName, string, )
	ADD_SERVICE_INFO(OperationalPM, JobEndCondition, The JobEndCondition service )//[wangyk 1.1.60]
		ADD_PARAM_INFO(OperationalPM, JobEndCondition, ProcessRecipeName, string, )
END_SERVICEINFO_LIST(OperationalPM)

IMPLEMENT_DYNAMIC(OperationalPM, OperationalModel)

BEGIN_MSG_MAP( OperationalPM, OperationalModel)
END_MSG_MAP
