#ifndef OFFLINEEXCEPTION_H_
#define OFFLINEEXCEPTION_H_
#include <stdexcept>

class OfflineException : public std::runtime_error
{
    public:
		OfflineException(const std::string &err) : runtime_error(err) {}
};
#endif /*OFFLINEEXCEPTION_H_*/
