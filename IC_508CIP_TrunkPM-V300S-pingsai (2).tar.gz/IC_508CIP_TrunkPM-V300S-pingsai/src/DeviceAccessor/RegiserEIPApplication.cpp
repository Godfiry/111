/********************************************************************
** Copyright (c) 2019 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: RegiserEIPApplication.cpp
** Description:  
** Release: 1.0
** Modification history:           
**                     2019-05-29   Duq create
**                                                 2019-08-30   Duq update
**                                                 2020-06-03   Duq update
*********************************************************************/

#include "RegiserEIPApplication.h"
#include "SysLogger.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

using namespace std;

//RegiserEIPApplication class
RegiserEIPApplication* RegiserEIPApplication::m_Instance = NULL;

RegiserEIPApplication::RegiserEIPApplication()
{
}

RegiserEIPApplication* RegiserEIPApplication::getInstance()
{
    if(m_Instance == NULL)
    {
        m_Instance = new RegiserEIPApplication();
    }
    return m_Instance;
}

void RegiserEIPApplication::do_RegiserEIPApplication(string &serverIP, EIPApplication* att)
{
    m_EIPApplications.insert(map<string, EIPApplication*> :: value_type(serverIP, att));
}

void RegiserEIPApplication::do_UnRegiserEIPApplication(string &serverIP)
{
    it= m_EIPApplications.find(serverIP);
    if(it != m_EIPApplications.end())
    {
        m_EIPApplications.erase(serverIP);
    }
}

void RegiserEIPApplication::NoticeRegiseredAttribut(string &serverIP, char *data, int len)
{
//cout << "NoticeRegisteredAttribut: " << "serverIP: " << serverIP<< "data: " << data<< "len: "<<len<<endl;
    it= m_EIPApplications.find(serverIP);

    if(it != m_EIPApplications.end())
    {
        att = it->second;
        att->do_ReadClass1Data(data, len);
    }
    else
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "RegiserEIPApplication::NoticeRegiseredAttribute got not find serverIP: " + serverIP);
}

RegiserEIPApplication::~RegiserEIPApplication()
{
    m_EIPApplications.clear();
}
//RegiserEIPApplication class
