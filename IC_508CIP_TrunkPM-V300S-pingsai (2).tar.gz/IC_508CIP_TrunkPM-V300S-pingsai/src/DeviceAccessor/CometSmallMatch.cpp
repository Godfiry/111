/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: CometSmallMatch.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					
**                  2014-11-21   lijj	create
*********************************************************************/
#include "CometSmallMatch.h"
#include "DeviceManager.h"

#include "IStringList.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std; 

CometSmallMatch::ParamPair CometSmallMatch::m_paramPairs[] = {ParamPair("manaut",DescriptorList("4,3"))};//0="4"="manual" 1="3"="auto"
										 
map<string,DescriptorList> CometSmallMatch::m_params = map<string,DescriptorList>(m_paramPairs, m_paramPairs+1);

CometSmallMatch::Com CometSmallMatch::m_commands[] = {{0, ""}, //0	reserved 						
											{0, "SM", 0},//1 (CH,value)manual
											{0, "SA", 0},//2 auto
											{0, "Rest", 0},//3 fault reset
											{2, "SP",0},  //4 save preset
											{2, "G",0},  //5 goto preset																	
											{1, "Load", 0},//6 set c1
											{1, "Tune", 0},//7 set c2		
											{1, "C3Pos", 0},//8 set c3 										
											
											{1, "QMode", 0},//9 get Manual/Auto
											{3, "QP3C", 1},//10 get c1
											{3, "QP3C", 2},//11 get c2
											{3, "QP3C", 3},//12 get c3
{2,"QP##",1},//13 get c1 another cmd
{2,"QP##",2},//14 get c2  another cmd
{3,"QP3C",3}}; //15 get c3  another cmd

CometSmallMatch::CometSmallMatch()
{
}

CometSmallMatch::~CometSmallMatch()
{
}

bool CometSmallMatch::writeInt(int channelNum, int value, const IntTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	int ps = com.m_ps;
	char format[5]={0};
	double t_c = 0.0;
	string msg = "";
	switch(ps)
	{
		case 0:
			//msg = com.m_s1;
			msg = m_commands[channelNum + value].m_s1;
			break;
		case 1:
			t_c = value / 10.0;		
			sprintf(format,"%04.1f",t_c);
			msg = com.m_s1 + format;
			break;
		case 2:
		   msg = com.m_s1 + Converter::convertToString(value);
		   break;	
	}
	return sendCommand(msg, m_timeOut);
}
		
bool CometSmallMatch::writeRawCommand(int channelNum, std::string value, const StringTypeInfo &typeInfo)
{
	return sendCommand(value, m_timeOut);
}
		
bool CometSmallMatch::readInt(int channelNum, int *value, const IntTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	string res = readCommand(com.m_s1, m_timeOut);
	std::vector<std::string> t_vlist = IStringList::split(res, ",");

	if(t_vlist.size() != com.m_ps && t_vlist.size() > 4)
	{
		throw IOException("read back value is not valid:" + res);
	}
	
	if(t_vlist.size() == 1)
	{
		*value = m_params["manaut"].getDescriptorValue(res);	
	}
	if(t_vlist.size() > 1)
	{
		string t_svalue = t_vlist[com.m_ps2 -1];
		double t_dvalue = 0;
		if(!Converter::stringToDouble(t_dvalue, t_svalue))
		{
			throw IOException("read back value is not an valid double value:" + t_svalue);
		}
		*value = (int)(t_dvalue * 10);
	}
	return true;
}

void CometSmallMatch::initChs(DeviceNode<CometSmallMatch> *node)
{
	node->registerWriteCh(0, &CometSmallMatch::writeRawCommand);
	for(int i = 1; i <= 8; ++i)
	{
		node->registerWriteCh(i, &CometSmallMatch::writeInt);
	}
	for(int i = 9; i <= 15; ++i)
	{
		node->registerReadCh(i, &CometSmallMatch::readInt);
	}
	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &CometSmallMatch::getStatus);	

}

void CometSmallMatch::initDevice()
{
}
		
void CometSmallMatch::init()
{
	DeviceNode<CometSmallMatch> *node = new DeviceNode<CometSmallMatch>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	if(!isSimulated())
	{
		initChs(node);		
		initDevice();
	}
}

IMPLEMENT_DYNAMIC(CometSmallMatch, COMETMatchDriver )
BEGIN_MSG_MAP(CometSmallMatch, COMETMatchDriver )
    SET_V( init, CometSmallMatch )
END_MSG_MAP

