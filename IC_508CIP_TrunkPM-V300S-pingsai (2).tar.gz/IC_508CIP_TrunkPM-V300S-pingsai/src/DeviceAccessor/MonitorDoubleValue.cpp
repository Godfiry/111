/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MonitorDoubleValue.cpp
** Description: Monitor channel double value
** Release: 1.0
** Modification history:
**                    2025-3-25   Dangw create
**
*********************************************************************/
#include <iostream>
#include <cmath>
#include "Converter.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#include "MonitorDoubleValue.h"
#include "SysLogger.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;

CMonitorDoubleValue::CMonitorDoubleValue()
{

}

CMonitorDoubleValue::~CMonitorDoubleValue()
{

}

void CMonitorDoubleValue::initDoubleValue(int nChannelNum, double dValue)
{
    m_mapValue[nChannelNum] = dValue;
    m_mapUnChange[nChannelNum] = VALUE_CHANGED;  // value default: changed
}

void CMonitorDoubleValue::setDoubleValue(int nChannelNum, double dValue, double dAccuracy)
{
    if(isDoubleValueExist(nChannelNum))
    {
        if(isDoubleEqual(m_mapValue[nChannelNum], dValue, dAccuracy))
        {
            m_mapValue[nChannelNum] = dValue;
            m_mapUnChange[nChannelNum] = VALUE_UNCHANGED;
        }
        else
        {
            m_mapValue[nChannelNum] = dValue;
            m_mapUnChange[nChannelNum] = VALUE_CHANGED;
        }
    }
}

bool CMonitorDoubleValue::isDoubleValueExist(int nChannelNum)
{
    if(m_mapValue.find(nChannelNum) != m_mapValue.end()
        && m_mapUnChange.find(nChannelNum) != m_mapUnChange.end())
    {
        return true;
    }
    return false;
}

bool CMonitorDoubleValue::readDoubleChange(int nChannelNum, int* pValue, const IntTypeInfo& typeinfo)
{
    if(isDoubleValueExist(nChannelNum))
    {
        *pValue = m_mapUnChange[nChannelNum];
    }
    else
    {
        *pValue = VALUE_CHANGED;
    }

    return true;
}

void CMonitorDoubleValue::clearDoubleMonitor()
{
    m_mapValue.clear();
    m_mapUnChange.clear();
}

bool CMonitorDoubleValue::isDoubleEqual(double dValueA, double dValueB, double dAccuracy)
{
    if(fabs(dValueA - dValueB) < dAccuracy)
    {
        return true;
    }
    return false;
}
