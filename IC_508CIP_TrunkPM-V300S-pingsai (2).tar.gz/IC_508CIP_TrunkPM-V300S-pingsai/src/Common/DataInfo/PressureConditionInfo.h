/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					Jan 22, 2008  shenql  create 
**      
***************************************************************************/
#ifndef PRESSURECONDITIONINFO_H_
#define PRESSURECONDITIONINFO_H_
#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class PressureConditionInfo : public IntValueInfo
{
public:

		static const int UnInit = -1;
		static const int Unknown = 0;
		static const int AtAtm = 1;
		static const int InBetWeen = 2;
		static const int AtHiVac = 3;
		static const IntTypeInfo typeInfo;

	   PressureConditionInfo():IntValueInfo(-1, typeInfo)
	   {
	   }
	
	   PressureConditionInfo(int i):IntValueInfo(i, typeInfo)
	    {
	    }
	
	   PressureConditionInfo(std::string s):IntValueInfo(s, typeInfo)
	    {
	    }
};


#endif /*PRESSURECONDITIONINFO_H_*/
