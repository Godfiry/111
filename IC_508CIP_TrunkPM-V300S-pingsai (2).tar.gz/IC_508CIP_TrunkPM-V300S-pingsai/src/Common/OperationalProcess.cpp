/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .cpp
** Description: 
** Release: 
** Modification history: 
**                     Feb 22, 2008  shenql  create
**                     2025-08-15 modify by taohao[v1.5.0_HotFix] for obtain the recipe from the memory
***************************************************************************/
#include "OperationalModel.h"
#include "OperationalProcess.h"
#include "NoSuchNameException.h"
#include "SysLogger.h"
#include "Converter.h"
#include "Recovery.h"
#include "Parameter.h"
#include "ObjectManager.h"
#include "PMAnmInfo.h"
#include "PMStateInfo.h"
#include "PMStatusInfo.h"
#include "RecipeTimeInfo.h"
#include "LotIdInfo.h"
#include "RecipeNameInfo.h"
#include "ConfigException.h"
#include "DefaultAction.h"
#include "DefaultValue.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "InvalidNameException.h"
#include "RetryException.h"
#endif

#include "IThread.h"
#include "ModuleStatusEnum.h"
#include "SlotIdInfo.h"
#include "CTCExport.h"
#include "RecipeNameInfo.h"
#include "YesNoInfo.h"
#include "StepNumInfo.h"
#include "AlarmCounter.h"
#include "AlarmReNameManager.h"
#include "StrTool.h"
#include <float.h>
#include <algorithm>
#include "RecipeTypeValueInfo.h"//added by mujy 20250526 for RecipeType Code CIP
#include "XmlGetter.h"
#include "BoshProcessResource.h"
#include "MathTool.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::ALARM;
using namespace IAP::RECIPE;
using namespace IAP::INTERLOCK;
using namespace IAP;
using namespace IAP::IO;
#endif

using namespace std;

OperationalProcess::OperationalProcess()
{
    m_pFuncProcess = NULL;
    m_pRecipeNotExist = NULL;
    m_pVerifyRecipeFailed = NULL;
    m_pProcessRecipeEmpty = NULL;

    m_pSlotSts = NULL;
    m_pSlotState = NULL;
    m_pSlotAnm = NULL;
    m_pRecipeName = NULL;
    m_pRecipeClass = NULL;
    m_pRecipeVersion = NULL;
    m_pRecipeTimeLeft = NULL;
    m_pProcessTime = NULL;
    m_pMaxProcessTime = NULL;
    m_pMaxProcessTimeTolerance = NULL;
    m_pFuncProcess = NULL;//added by liusy[1.1.52]
    m_pFlagstepId = NULL;//added by liusy[1.1.52]
    m_nSlotNumber = -1;

    m_pProcessModule = NULL;
    m_pStepName = NULL;
    m_pProcessCanelled = NULL;
    m_pStepNum = NULL;
    m_pStepID = NULL;
    m_pStepTime = NULL;
    m_pStepWaitTime = NULL;//added by xiasc for 508M time test
    m_pRFStableTime = NULL;
    m_pRealStepTime = NULL;
    m_pElapsedStepTime = NULL;
    m_pElapsedFullStepTime = NULL;
    m_pElapsedProcessTime = NULL;

    m_sPrepare = new Prepare;
    m_sPrepare->setOwner(this);

    m_sProcess = new Process;
    m_sProcess->setOwner(this);

    m_sCalculateLearn = new CalculateLearn;//added by liusy[1.1.52]
    m_sCalculateLearn->setOwner(this);

    //m_pSession = NULL; // <><><>

    m_pWaferThickness=NULL;//added by mujy [v1.5.17]
    m_pIsUseThickness=NULL;//added by mujy [v1.5.17]
    m_pIsUseTime=NULL;//added by mujy [v1.5.17]

    m_strProcessingSpell = "Processing";

    m_pProcessMode = NULL;

    m_sRcpName = "";//added by liusy[1.1.52]

    m_nPVLearnPressureNotStable = NULL;//added by dangw for [ZXGJ 1.4.0_HotFix7 AutoPressureControl]
}

OperationalProcess::~OperationalProcess()
{
}

OperationalProcess::Process::Process()   //add by wzd 1.1.39
{
    #ifdef SUSE //[zhangcx v1.7.0]
        #ifdef IAP4_0
            setThreadPriority(IAP::CORE::IThread::PRIORITY_HIGH);
            setCPU(2, true);
        #else
            setThreadPriority(PRIORITY_HIGH);
            SetCPU(2, true);
        #endif
    #endif
}


void OperationalProcess::Prepare::execute()
{
    ControlObject *owner = getOwner();
    if (owner != NULL)
    {
        #ifdef IAP4_0
        Result.Bool = (static_cast<OperationalProcess*>(owner))->do_Prepare(Params["recipeName"].Str);
        #else
        Results["success"].Bool = (static_cast<OperationalProcess*>(owner))->do_Prepare(Params["recipeName"].Str);
        #endif
    }
}

void OperationalProcess::Process::execute()
{
    ControlObject *owner = getOwner();
    if (owner != NULL)
    {
        #ifdef IAP4_0
        Result.Bool = (static_cast<OperationalProcess*>(owner))->do_Process();
        #else
        Results["success"].Bool = (static_cast<OperationalProcess*>(owner))->do_Process();
        #endif
    }
}
//added by liusy[1.1.52]
void OperationalProcess::CalculateLearn::execute()
{
    ControlObject* owner = getOwner();
    if (owner != NULL)
    {
        #ifdef IAP4_0
        Result.Bool = (static_cast<OperationalProcess*>(owner))->do_CalculateLearn(Params["recipeName"].Str, Params["step"].Int);
        #else
        Results["success"].Bool = (static_cast<OperationalProcess*>(owner))->do_CalculateLearn(Params["recipeName"].Str, Params["step"].Int);
        #endif
    }
}

void OperationalProcess::make()
{
    Log_Info( getName() + " make start" );
    if(isMade())
    {
        return;
    }
    ControlObjectEX::make();
    AlarmCounter::getInstance()->make();
    string strPreName = AlarmReNameManager::getInstance()->GetShowName(getName());
    m_pRecipeNotExist = new BlockingAlarm(strPreName + "_RecipeNotExist", "Failed to retrieve process recipe.",  "Invalid recipe name. Reasons:1. The recipe is corrupted; 2. The recipe does not exist in this PM; 3. Recipe name does not match case of PM recipe ( Recipe and class names are case sensitive.)", Alarm::ERROR);
    m_pRecipeNotExist->addRecovery(new Recovery("Abort",Recovery::ABORT));
    m_pRecipeNotExist->addRecovery(new Recovery("Retry (After create recipe)",Recovery::RETRY));

    m_pVerifyRecipeFailed = new BlockingAlarm(strPreName + "_VerifyRecipeFailed", "Failed to verify current recipe.",  "Recipe exist but verify failed, please check! ", Alarm::ERROR);
    m_pVerifyRecipeFailed->addRecovery(new Recovery("Abort",Recovery::ABORT));
    m_pVerifyRecipeFailed->addRecovery(new Recovery("Retry (After edit recipe)",Recovery::RETRY));
    m_pProcessRecipeEmpty = new BlockingAlarm(strPreName + "_RecipeIsEmpty", "Failed to execute current recipe." , "Recipe is empty, please modify it." , Alarm::FATAL);
    m_pProcessRecipeEmpty->addRecovery(new Recovery("Abort",Recovery::ABORT));
    m_pProcessRecipeEmpty->addRecovery(new Recovery("Retry (After edit recipe)",Recovery::RETRY));

    try  //[zhangcx v1.4.0_hotfix7]
    {
        ReadWriteDouble* t_pPressureStableGapInPVLearn = XmlGetter::getFromNamespace<ReadWriteDouble*>("/SETUP/GasConfig/cfgPressureStableGapInPVLearn");
		m_nPVLearnPressureNotStable = new NonBlockingAlarm(strPreName + "_PVLearnPressureNotStable",
			"During PVLearn the Pressure is Not Stable. ", "During PVLearn the Pressure is Not Stable. The learned Value Will not set to the recipe. ", Alarm::NOTICE);
		m_nPVLearnPressureNotStable->addRecovery(new Recovery("Clear", Recovery::CLEAR));
    }
    catch (...)
    {
        Log_Info(getName() + " not make Learn Pressure Not Stable Interlock.");
    }

    try
    {
        m_pProcessModule = (OperationalModel *) ObjectManager::getInstance()->getObject(this, "../");
    }
    catch(NoSuchNameException _ex)
    {
        throw NoSuchNameException("PM parent for " + this->getName() + " not found");
    }
    if(m_nSlotNumber < 0)
    {
        string s = getSelfName();
        string s1 = s.substr(1);
        Log_Info( "parsing name " + s + " for slot number" );

        if(!Converter::stringToInt(m_nSlotNumber, s1))
        {
            throw ConfigException("Invalid Slot object name " + s);
        }
    }
    string t_prefix = m_pProcessModule->getSelfName();
    if(m_nSlotNumber > 0)
    {
        t_prefix += "_" + getSelfName();
    }
    if(m_strProcessingSpell == "Processing")//add for code merging
    {
        m_pSlotSts = new ReadWriteInt(getName() + "/ProcessStatus", PMStatusInfo::typeInfo);
    }
    else
    {
        m_pSlotSts = new ReadWriteInt(getName() + "/ProcessStatus", IntTypeInfo(DescriptorList("UnInit:-1,Unknown,Preparing,Prepared,Processng,Processed,Paused,Aborted,BadWfr")));
    }

    CTCExport::exportAsOthers(m_pSlotSts, t_prefix + "_ProcessStatus");
    m_pSlotSts->setValue(0);

    if(m_strProcessingSpell == "Processing")//add for code merging
    {
        m_pSlotAnm = new ReadWriteInt(getName() + "/ProcessAnm", PMAnmInfo::typeInfo);
    }
    else
    {
        m_pSlotAnm = new ReadWriteInt(getName() + "/ProcessAnm", IntTypeInfo(DescriptorList("UnInit:-1,Init,Preparing,Prepared,Processng,Processed,Aborted")));
    }
    CTCExport::exportAsOthers(m_pSlotAnm, t_prefix + "_ProcessAnm");
    m_pSlotAnm->setValue(0);

    m_pSlotState = new ReadWriteInt(getName() + "/ProcessStat", PMStateInfo::typeInfo);
    CTCExport::exportAsOthers(m_pSlotState, t_prefix + "_ProcessStat");
    m_pSlotState->setValue(0);

    //m_lotId = new ReadWriteString(getName() + "/LotId", LotIdInfo::typeInfo);
    //CTCExport::exportAsOthers(m_lotId, t_prefix + "_LotId");
    //m_lotId->setValue("");

    //m_slotWaferName = new ReadWriteString(getName() + "/WfrNam", LotIdInfo::typeInfo);
    //CTCExport::exportAsOthers(m_slotWaferName, t_prefix + "_WfrNam");
    //m_slotWaferName->setValue("");

    m_pRecipeName = new ReadWriteString(getName() + "/RecipeName", RecipeNameInfo::typeInfo);
    CTCExport::exportAsOthers(m_pRecipeName, t_prefix + "_RecipeName");
    m_pRecipeName->setValue("");

    m_pRecipeClass = new ReadWriteString(getName() + "/RecipeClass", RecipeNameInfo::typeInfo);
    CTCExport::exportAsOthers(m_pRecipeClass, t_prefix + "_RecipeClass");
    m_pRecipeClass->setValue("");

    m_pRecipeVersion = new ReadWriteString(getName() + "/RecipeVersion", RecipeNameInfo::typeInfo);
    CTCExport::exportAsOthers(m_pRecipeVersion, t_prefix + "_RecipeVersion");
    m_pRecipeVersion->setValue("");

    m_pStepName = new ReadWriteString(getName() + "/StepName", RecipeNameInfo::typeInfo);
    m_pStepName->setValue("");
    CTCExport::exportAsOthers(m_pStepName, t_prefix + "_StepName");

    m_pStepNum = new ReadWriteInt(getName() + "/StepNum", StepNumInfo::typeInfo);
    m_pStepNum->setValue(0);
    CTCExport::exportAsOthers(m_pStepNum, t_prefix + "_StepNum");

    m_pStepID = new ReadWriteInt(getName() + "/StepId", StepNumInfo::typeInfo);
    m_pStepID->setValue(0);
    CTCExport::exportAsOthers(m_pStepID, t_prefix + "_StepId");

    m_pFlagstepId = new ReadWriteInt(getName() + "/FlagStepId", StepNumInfo::typeInfo); //C1 Learn //added by liusy[1.1.52]
    m_pFlagstepId->setValue(0);
    CTCExport::exportAsOthers(m_pFlagstepId, t_prefix + "_FlagStepId");

    m_pRecipeTimeLeft = new ReadWriteDouble(getName() + "/ProcessTimeLeft"/*, RecipeTimeInfo::typeInfo*/);
    CTCExport::exportAsOthers(m_pRecipeTimeLeft, t_prefix + "_ProcessTimeLeft");
    m_pRecipeTimeLeft->setValue(100000);

    m_pProcessTime = new ReadWriteDouble(getName() + "/ProcessTime", RecipeTimeInfo::typeInfo);
    CTCExport::exportAsOthers(m_pProcessTime, t_prefix + "_ProcessTime");
    m_pProcessTime->setValue(0.0);

    try
    {
        m_pMaxProcessTime=(ReadWriteDouble*)ObjectManager::getInstance()->getObject("/IO/Datas/MaxProcessTime");
        CTCExport::exportAsOthers(m_pMaxProcessTime, t_prefix + "_MaxProcessTime");
        m_pMaxProcessTime->setValue(0.0);
    }
    catch(const exception &e)
    {
        m_pMaxProcessTime = new ReadWriteDouble(getName() + "/MaxProcessTime", RecipeTimeInfo::typeInfo);
        CTCExport::exportAsOthers(m_pMaxProcessTime, t_prefix + "_MaxProcessTime");
        m_pMaxProcessTime->setValue(0.0);
    }

    try
    {
        m_pMaxProcessTimeTolerance=(ReadWriteDouble*)ObjectManager::getInstance()->getObject("/SETUP/PreservedValue/MaxProcessTimeTolerance");
    }
    catch(const exception &e)
    {
        m_pMaxProcessTimeTolerance = new ReadWriteDouble(getName() + "/MaxProcessTimeTolerance", RecipeTimeInfo::typeInfo);
        m_pMaxProcessTimeTolerance->setValue(15);
    }

    m_pStepTime = new ReadWriteDouble(getName() + "/StepTime", RecipeTimeInfo::typeInfo);
    CTCExport::exportAsOthers(m_pStepTime, t_prefix + "_StepTime");
    m_pStepTime->setValue(0.0);

    m_pStepWaitTime = new ReadWriteDouble(getName() + "/StepWaitTime", RecipeTimeInfo::typeInfo);
    CTCExport::exportAsOthers(m_pStepWaitTime, t_prefix + "_StepWaitTime");
    m_pStepWaitTime->setValue(0.0);

    m_pRFStableTime = new ReadWriteDouble(getName() + "/RFStableTime", RecipeTimeInfo::typeInfo);
    CTCExport::exportAsOthers(m_pRFStableTime, t_prefix + "_RFStableTime");
    m_pRFStableTime->setValue(0.0);

    m_pRealStepTime = new ReadWriteDouble(getName()+"/RealStepTime", RecipeTimeInfo::typeInfo);
    CTCExport::exportAsOthers(m_pRealStepTime, t_prefix + "_RealStepTime");

        m_pRealStepTime->setValue(0.0);

    if(m_nSlotNumber == 1)
    {
        CTCExport::exportAsOthers(m_pRFStableTime, "RFStableTime");
        CTCExport::exportAsOthers(m_pRealStepTime, "PM_RealStepTime");
    }

    m_pElapsedStepTime = new ReadWriteDouble(getName() + "/ElapsedStepTime", RecipeTimeInfo::typeInfo);
    CTCExport::exportAsOthers(m_pElapsedStepTime, t_prefix + "_ElapsedStepTime");
    m_pElapsedStepTime->setValue(0.0);

    m_pElapsedFullStepTime = new ReadWriteDouble(getName() + "/ElapsedFullStepTime", RecipeTimeInfo::typeInfo);
    CTCExport::exportAsOthers(m_pElapsedFullStepTime, t_prefix + "_ElapsedFullStepTime");
    m_pElapsedFullStepTime->setValue(0.0);

    m_pElapsedProcessTime = new ReadWriteDouble(getName() + "/ElapsedProcessTime", RecipeTimeInfo::typeInfo);
    CTCExport::exportAsOthers(m_pElapsedProcessTime, t_prefix + "_ElapsedProcessTime");
    m_pElapsedProcessTime->setValue(0.0);

    m_pProcessCanelled = new ReadWriteInt(getName() + "/ProcessCancelled", YesNoInfo::typeInfo);
    m_pProcessCanelled->setValue(0);
    CTCExport::exportAsOthers(m_pProcessCanelled, t_prefix + "_ProcessCancelled");

    m_pIsUseThickness = new ReadWriteInt(getName() + "/UseWaferThickness", YesNoInfo::typeInfo);//added by mujy [v1.5.17]
    m_pIsUseThickness->setValue(0);

    m_pIsUseTime = new ReadWriteInt(getName() + "/UseTime", YesNoInfo::typeInfo);
    m_pIsUseTime->setValue(0);

    m_pWaferThickness = new ReadWriteDouble(getName() + "/WaferThickness", DoubleTypeInfo(0,11000));
    m_pWaferThickness->setValue(0);

    if(m_nSlotNumber == 1)
    {
        CTCExport::exportAsOthers(m_pIsUseThickness, "UseWaferThickness");
        CTCExport::exportAsOthers(m_pIsUseTime, "UseTime");
        CTCExport::exportAsOthers(m_pWaferThickness, "WaferThickness");
    }
    m_pProcessMode = new ReadWriteInt(getName()+"/ProcessMode",IntTypeInfo(DescriptorList("Common,BoshProcess")));//add for CTC
    m_pProcessMode->setValue("Common");
    CTCExport::exportAsOthers(m_pProcessMode, t_prefix + "_ProcessMode");

    RecipeTypeValueInfo::getInstance()->printValue();//added by mujy 20250526 for RecipeType Code CIP

    Log_Info( getName() + " make end" );
}

void OperationalProcess::initialize()
{
    Log_Info( getName() + " initialize start" );
    ControlObjectEX::initialize();
    AlarmCounter::getInstance()->initialize();
}

void OperationalProcess::verifyInit()
{
    ControlObjectEX::verifyInit();
    if(m_pFuncProcess == NULL)
    {
        throw "FuncProcess not config.";
    }
}

void OperationalProcess::startup()
{
    ControlObjectEX::startup();
}

void OperationalProcess::shutdown()//modify by taohao[v1.5.0_HotFix] for obtain the recipe from the memory
{
}

void OperationalProcess::call_Prepare(const RecipeNameInfo &recipenameparam)
{
    m_sPrepare->setOwner(this);
    m_sPrepare->setParamValue("recipeName", recipenameparam.getValue());
    call(m_sPrepare);
}

void OperationalProcess::call_Process()
{
    m_sProcess->setOwner(this);
    call(m_sProcess);
}
//added by liusy[1.1.52]
void OperationalProcess::call_CalculateLearn(const RecipeNameInfo& recipenameparam, int step)
{
    m_sCalculateLearn->setOwner(this);
    m_sCalculateLearn->setParamValue("recipeName", recipenameparam.getValue());
    m_sCalculateLearn->setParamValue("step", step);
    call(m_sCalculateLearn);
}
//added by liusy[1.1.52],modify by taohao[v1.5.0_HotFix4] for obtain the recipe from the memory
bool OperationalProcess::do_CalculateLearn(const std::string& recipeID, int step)
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + " OperationalProcess:: start calculate learn: " + recipeID);
    if (AlarmCounter::getInstance()->hasErrorAlarm() || AlarmCounter::getInstance()->hasFatalAlarm())
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + " Calculate learn failed for interrupted by Fatal Alarm " + recipeID);
        return false;
    }

    if(AppRecipeManager::getInstance()->isOpenDeleteFunction())
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + " Calculate learn failed for delete recipe function is open!!!");
        return false;
    }
    int t_num = ((ReadWriteInt*)ObjectManager::getInstance()->getObject("/Control/PMCExports/Datas/dt_num"))->getValue();//jsq 20210901 1----->dt_num
    if (t_num == 0)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + " do_CalculateLearn failed for dt_num is 0");
        return false;
    }
    // not group recipe is return false
    if (!RecipeTypeValueInfo::getInstance()->isGroupRecipe())//added by mujy 20250526 for RecipeType Code CIP
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "recipe is not group Recipe");
        return false;
    }

    AppRecipeManager::getInstance()->retrieveRecipe(recipeID,true,true);
    string t_sRcpClass = AppRecipeManager::getInstance()->getHandlerClass();
    if (t_sRcpClass != "/Process")
    {
        AppRecipeManager::getInstance()->releaseRecipe(recipeID);
        return true;
    }
    //recipe is exist?
    IntValueInfo LearnEnable;
    int nLearnEnable = 0;

    try
    {
        string temp = "SRFAutoLearnEnable";
        AppRecipeManager::getInstance()->getStepValue(1, temp, LearnEnable);
    }
    catch (...)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, " is not SRFAutoLearnEnable Recipe");
        return false;
    }

    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + " do_CalculateLearn start, name is:" + recipeID);


    int nCfgC1Offset =0;
    int nCfgC2Offset =0;
    int nCfgC5Offset =0;

    try
    {
        nCfgC1Offset =  static_cast<ReadWriteInt*>(ObjectManager::getInstance()->getObject("/SETUP/Recipe/SC1_Ignition_Offset"))->getValue();
        nCfgC2Offset= static_cast<ReadWriteInt*>(ObjectManager::getInstance()->getObject("/SETUP/Recipe/SC2_Ignition_Offset"))->getValue();
        nCfgC5Offset= static_cast<ReadWriteInt*>(ObjectManager::getInstance()->getObject("/SETUP/Recipe/SC5_Ignition_Offset"))->getValue();
    }
    catch(...)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + " do_CalculateLearn start, name is:");
    }


    try
    {
        IntValueInfo t_IntV;
        DoubleValueInfo t_DoubleV;
        double t_dParamMax = 0;
        double t_dParamMin = 0;
        int t_iStepNum = AppRecipeManager::getInstance()->getNumOfSteps();
        int t_iParamNum = AppRecipeManager::getInstance()->getNumOfParams();



        int nLearnStep = 0;
        int nPreCycleNum = 1;
        int nCycleNum = 1;

        IntValueInfo t_GroupName;
        int nGroupNameIndex = 0;
        int nPreGroupNameIndex = -1;

        if (step > 0)
        {
            for (unsigned int i = 1; i <= t_iStepNum; ++i)
            {
                AppRecipeManager::getInstance()->getStepValue(i, "SRFAutoLearnEnable", LearnEnable);
                nLearnEnable = LearnEnable.getValue();
                AppRecipeManager::getInstance()->getStepValue(i, "GroupName", t_GroupName);
                nGroupNameIndex = t_GroupName.getValue();
                if(nGroupNameIndex != nPreGroupNameIndex)
                {
                    nLearnStep++;
                }
                else if(nGroupNameIndex == 0)
                {
                    nLearnStep++;
                }
                else
                {

                }
                nPreGroupNameIndex = nGroupNameIndex;


                if (nLearnEnable == 0)
                {
                    continue;  //learn disable, not write to recipe
                }
                for (unsigned int j = 1; j <= t_iParamNum; ++j)
                {
                    string t_paramName = AppRecipeManager::getInstance()->getParamName(j);
                    if (t_paramName.find("LearnValue") == string::npos)
                        continue;

                    if ((ReadWriteString*)ObjectManager::getInstance()->getObject("/Control/PMCExports/Datas/" + t_paramName + "Cal") != NULL)
                    {

                        string t_learnParam = ((ReadWriteString*)ObjectManager::getInstance()->getObject("/Control/PMCExports/Datas/" + t_paramName + "Cal"))->getValue();
                        switch (AppRecipeManager::getInstance()->getParamType(t_paramName))
                        {
                        case IO::INTDATA:
                            AppRecipeManager::getInstance()->getStepValue(i, t_paramName, t_IntV);
                            t_dParamMax = t_IntV.getTypeInfo().getMax();
                            t_dParamMin = t_IntV.getTypeInfo().getMin();
                            break;
                        case IO::DOUBLEDATA:
                            AppRecipeManager::getInstance()->getStepValue(i, t_paramName, t_DoubleV);
                            t_dParamMax = t_DoubleV.getTypeInfo().getMax();
                            t_dParamMin = t_DoubleV.getTypeInfo().getMin();
                            break;
                        default:
                            break;
                        }
                        double sum = 0;
                        int pos1 = 0, pos2 = 0;
                        int pos3 = 0, pos4 = 0;
                        int stp = nLearnStep; //jump bosh, bosh as one step
                        while (stp) {
                            pos3 = t_learnParam.find("/", pos3 + 1);
                            stp--;
                        }
                        stp = nLearnStep - 1; //
                        while (stp) {
                            pos4 = t_learnParam.find("/", pos4 + 1);
                            stp--;
                        }
                        if (pos4 == 0)
                            t_learnParam = t_learnParam.substr(pos4, pos3 - pos4 + 1);
                        else
                            t_learnParam = t_learnParam.substr(pos4 + 1, pos3 - pos4);
                        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + " OperationalProcess:: calculate learn step is: " + Converter::convertToString(i) + "learnvalue is:" + t_learnParam);
                        vector<double> average;//jsq add 20210901
                        for (int k = 0; k < t_num; k++)
                        {
                            pos1 = t_learnParam.find(",", pos2);
                            pos2 = t_learnParam.find(",", pos1 + 1);
                            double t = 0.0;
                            if (pos2 == -1) 
                            {
                                pos2 = t_learnParam.find("/", pos1 + 1);
                            }
                            Converter::stringToDouble(t, t_learnParam.substr(pos1 + 1, pos2 - pos1 - 1));
                            sum = sum + t;
                            average.push_back(t);
                        }
                        if (t_num > 2)
                        {
                            double t_min = *(min_element(average.begin(), average.end()));
                            double t_max = *(max_element(average.begin(), average.end()));
                            sum = (sum - t_min - t_max) / (t_num - 2);
                        }
                        else
                        {
                            sum = sum / (t_num);
                        }
                        if ((sum < t_dParamMin) || (sum > t_dParamMax))
                        {
                            break;
                        }
                        AppRecipeManager::getInstance()->setStepValue(i, j, Converter::convertToString(sum));
                    }
                }
            }

        }

        int presteps = 0;
        string t_param11 = "SRFC1PresetLearnValue";
        string t_param12 = "SRFC1PresetOffset";
        string t_param21 = "SRFC2PresetLearnValue";
        string t_param22 = "SRFC2PresetOffset";
        string t_param31 = "SRFC5PresetLearnValue";
        string t_param32 = "SRFC5PresetOffset";
        string t_powerr = "SRFPower(W)_Init";
        DoubleValueInfo doublev;
        IntValueInfo IntValue;

        for (unsigned int i = 1; i <= AppRecipeManager::getInstance()->getNumOfSteps(); ++i)
        {
            AppRecipeManager::getInstance()->getStepValue(i, "SRFAutoLearnEnable", LearnEnable);
            nLearnEnable = LearnEnable.getValue();

            if (nLearnEnable == 0)
            {
                continue;
            }

            for (unsigned int j = 1; j <= AppRecipeManager::getInstance()->getNumOfParams(); ++j)
            {
                string t_paramName = AppRecipeManager::getInstance()->getParamName(j);
                AppRecipeManager::getInstance()->getStepValue(i, t_powerr, doublev);
                double t_power = doublev.getValue();


                if (t_power < 5)
                {

                    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "OperationalProcess:: skip power mode stable ");
                    continue;
                }

                if (t_paramName.find("SRFC1Calculate") != string::npos && t_power > 5)
                {
                    AppRecipeManager::getInstance()->getStepValue(i, t_param11, IntValue);
                    int t_c = IntValue.getValue();
                    AppRecipeManager::getInstance()->getStepValue(i, t_param12, IntValue);
                    int t_coffset = IntValue.getValue();
                    for (int k = presteps + 1; k <= i; k++)
                    {
                        AppRecipeManager::getInstance()->setStepValue(k, j, Converter::convertToString(t_c + t_coffset + nCfgC1Offset));
                    }
                }

                if (t_paramName.find("SRFC2Calculate") != string::npos && t_power > 5)
                {
                    AppRecipeManager::getInstance()->getStepValue(i, t_param21, IntValue);
                    int t_c = IntValue.getValue();
                    AppRecipeManager::getInstance()->getStepValue(i, t_param22, IntValue);
                    int t_coffset = IntValue.getValue();
                    for (int k = presteps + 1; k <= i; k++)
                    {
                        AppRecipeManager::getInstance()->setStepValue(k, j, Converter::convertToString(t_c + t_coffset + nCfgC2Offset));
                    }
                }

                if (t_paramName.find("SRFC5Calculate") != string::npos && t_power > 5)
                {
                    AppRecipeManager::getInstance()->getStepValue(i, t_param31, IntValue);
                    int t_c = IntValue.getValue();
                    AppRecipeManager::getInstance()->getStepValue(i, t_param32, IntValue);
                    int t_coffset = IntValue.getValue();
                    for (int k = presteps + 1; k <= i; k++)
                    {
                        AppRecipeManager::getInstance()->setStepValue(k, j, Converter::convertToString(t_c + t_coffset + nCfgC5Offset));
                    }
                    presteps = i;
                }
            }
        }

        AppRecipeManager::getInstance()->notifyOtherSession(RecipeMgmtEvent(RecipeMgmtEvent::MODIFIED, AppRecipeManager::getInstance()->getRecipeID()));
        AppRecipeManager::getInstance()->storeRecipe(recipeID);
        AppRecipeManager::getInstance()->releaseRecipe(recipeID);

    }
    catch (const exception& ex)
    {
        AppRecipeManager::getInstance()->releaseRecipe(recipeID);
        m_pSlotSts->setValue(PMStatusInfo::Aborted);
        m_pSlotState->setValue(PMStateInfo::NotRd);
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "OperationalProcess:: failed in CalculateLearn for recipe " + recipeID + " for exception thrown - " + string(ex.what()));
    }
    return true;
}

bool OperationalProcess::needAutoPVLearn()//[zhangcx v1.4.0_hotfix7]
{
	bool bNeedPVLearn = false;
	bool bPVLearnPressureStable = false;
	string strLearnedValue = "";
	BoshProcessResource* pFuncBoshProcess = NULL;

	try
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + " try to get PVLearn data.");
		pFuncBoshProcess = dynamic_cast<BoshProcessResource*>(m_pFuncProcess);
		if (pFuncBoshProcess != NULL)
		{
			bNeedPVLearn = pFuncBoshProcess->getNeedPVLearnStatus();
			bPVLearnPressureStable = pFuncBoshProcess->checkPressureInProcess();

			pFuncBoshProcess->getPVSetDatas(m_mapPVSetDatas);
		}
		else
		{
		    return false;
		}              
	}
	catch (...)
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + " not bosch recipe.");
		bNeedPVLearn = false;
		bPVLearnPressureStable = false;
	}

	if (bNeedPVLearn && !bPVLearnPressureStable)
	{
		if ((m_nPVLearnPressureNotStable != NULL) && (!m_nPVLearnPressureNotStable->isPosted()))
		{
			m_nPVLearnPressureNotStable->setDescription("During PVLearn the Pressure is Not Stable. The learned Value Will not set to the recipe. " + strLearnedValue);
			m_nPVLearnPressureNotStable->post(this);
		}

        if (pFuncBoshProcess != NULL && !bPVLearnPressureStable)
        {
            pFuncBoshProcess->resetPressureStableStatus();
        }

		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + " During PVLearn the Pressure is Not Stable ");

        return false;
	}

	if (bNeedPVLearn && bPVLearnPressureStable)
	{
        return true;
	}

    return false;    
}

bool OperationalProcess::do_AutoPVLearn(const std::string& recipeID)  //[zhangcx v1.4.0_hotfix7]
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + " OperationalProcess:: start Auto learn: " + recipeID);
	if (AlarmCounter::getInstance()->hasErrorAlarm() || AlarmCounter::getInstance()->hasFatalAlarm())
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + " AutoPVLearn failed for interrupted by Fatal Alarm " + recipeID);
		return false;
	}

	// not group recipe is return false
	if (!RecipeTypeValueInfo::getInstance()->isGroupRecipe())//added by mujy 20250526 for RecipeType Code CIP
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "recipe is not group Recipe");
		return false;
	}

	AppRecipeManager::getInstance()->retrieveRecipe(recipeID,true,true);
	string t_sRcpClass = AppRecipeManager::getInstance()->getHandlerClass();
	if (t_sRcpClass != "/Process")
	{
		AppRecipeManager::getInstance()->releaseRecipe(recipeID);
		return true;
	}

	for (std::map<int, PVSetSkipRow>::const_iterator it = m_mapPVSetDatas.begin(); it != m_mapPVSetDatas.end(); ++it)
    {
        AppRecipeManager::getInstance()->setStepValue(it->first, "VATPosPreset_Init", Converter::convertToString(MathTool::Round(it->second.dPVSet, 1)));
		AppRecipeManager::getInstance()->setStepValue(it->first, "VATPosPreset_Final", Converter::convertToString(MathTool::Round(it->second.dPVSet, 1)));
    }

	AppRecipeManager::getInstance()->notifyOtherSession(RecipeMgmtEvent(RecipeMgmtEvent::MODIFIED, AppRecipeManager::getInstance()->getRecipeID()));
	AppRecipeManager::getInstance()->storeRecipe(recipeID);
	AppRecipeManager::getInstance()->releaseRecipe(recipeID);

    return true;
}


bool OperationalProcess::do_Prepare(const std::string &recipeID)
{
    Log_Info( getName()+" OperationalProcess:: start preparing for recipe: " + recipeID );
    bool bResult = true;
    if(m_pProcessModule->checkMode_JobService(this))
    {
        m_pSlotSts->setValue(PMStatusInfo::Preparing);
        m_pSlotAnm->setValue(PMAnmInfo::Preparing);
        try
        {
            clearRecipeInfo();
            do_PrepareRecipe(recipeID);
            bResult = do_PrepareForProcessingMaterial();
            m_pRecipeTimeLeft->setValue(100000);
            m_pSlotSts->setValue(PMStatusInfo::Prepared);
            m_pSlotAnm->setValue(PMAnmInfo::Prepared);
            if(bResult)
            {
                m_pSlotState->setValue(PMStateInfo::Rd4Next);
                m_pProcessCanelled->setValue(0);
                Log_Info( "OperationalProcess:: finish preparing for recipe: " + recipeID );
                return    true;
            }
            else
            {
                m_pSlotState->setValue(PMStateInfo::NotRd);
                Log_Error( "OperationalProcess:: failed in preparing for recipe: " + recipeID );
                return false;
            }
        }
        catch(const RetryException& ex)
        {
            AppRecipeManager::getInstance()->releaseRecipe(recipeID);//modify by taohao[v1.5.0_HotFix] for obtain the recipe from the memory
            throw;
        }
        catch(const exception &ex)
        {
            AppRecipeManager::getInstance()->releaseRecipe(recipeID);//modify by taohao[v1.5.0_HotFix] for obtain the recipe from the memory
            m_pProcessModule->changeModuleStatus(MODULE_STATUS::NotReady);
            m_pSlotSts->setValue(PMStatusInfo::Aborted);
            m_pSlotState->setValue(PMStateInfo::NotRd);
            Log_Error( "OperationalProcess:: failed in preparing for recipe " + recipeID + " for exception thrown - " + string(ex.what()));
            throw AbortException(ex.what());
        }
    }
    else
    {
        return false;
    }
}

void OperationalProcess::do_PrepareRecipe(const string &strRcpID)//modify by taohao[v1.5.0_HotFix] for obtain the recipe from the memory
{
    Log_Info( getName() + " do_PrepareRecipe start" );
    m_sRcpName = strRcpID;//added by liusy[1.1.52]
    string strName = strRcpID;
    try
    {
        strName = strRcpID.substr(strRcpID.find_last_of('/')+1);
        strName = strName.substr(0,strName.find(";"));
    }
    catch (const exception)
    {
        Log_Error(strRcpID+ " substr failed.");
    }
    try
    {
        AppRecipeManager::getInstance()->releaseRecipe(strRcpID); // m_handler is reset to NULL, no exception in here context
        RecipeMgmtSession::CriticalZone cz;
        AppRecipeManager::getInstance()->retrieveRecipe(strRcpID, false, false); // <><><> retrieve recipe as shared
        //AppRecipeManager::getInstance()->selectRecipe(rcpHandler); // do NOT allow to modify this recipe anymore
    }
    catch (const exception &err)
    {
        Log_Error( strRcpID + ": retrieve recipe failed for: " +string(err.what()));
        m_pRecipeNotExist->setMessage("Failed to retrieve the recipe ["+strName+"]");
        m_pRecipeNotExist->post(this);
    }

    if (!AppRecipeManager::getInstance()->verify()) // verify failed
    {
        Log_Error( strRcpID + ": recipe verify failed." );
        AppRecipeManager::getInstance()->releaseRecipe(strRcpID);
        m_pVerifyRecipeFailed->setMessage("Failed to verify the recipe ["+strName+"]");
        m_pVerifyRecipeFailed->post(this);
    }

    if(AppRecipeManager::getInstance()->getNumOfSteps() == 0)
    {
        Log_Error( strRcpID + ": recipe body is empty." );
        AppRecipeManager::getInstance()->releaseRecipe(strRcpID);
        m_pProcessRecipeEmpty->setMessage("Can't execute the recipe ["+strName+"]");
        m_pProcessRecipeEmpty->post(this);
    }
    Log_Info( getName() + ": do_PrepareRecipe end" );
}

bool OperationalProcess::do_PrepareForProcessingMaterial()//modify by taohao[v1.5.0_HotFix] for obtain the recipe from the memory
{
    Log_Info( getName() + ":do_PrepareForProcessingMaterial  start" );
    initRecipeInfo();
    return m_pFuncProcess->call_PrepareForProcessingMaterial();
}

bool OperationalProcess::do_Process()//modify by taohao[v1.5.0_HotFix] for obtain the recipe from the memory
{
    Log_Info( "OperationalProcess:: Start processing recipe" );
    bool bResult = false;
    bool bResult2 = true;//added by liusy[1.1.52]
    bool bResult3 = true;//[zhangcx v1.4.0_hotfix7]
     if(m_pProcessModule->checkMode_JobService(this))
     {
        m_pSlotSts->setValue(3);//change for code merging
        m_pSlotAnm->setValue(3);//change for code merging
        try
        {
            bResult = do_SetupAndProcessMaterial();
            AppRecipeManager::getInstance()->releaseRecipe(m_sRcpName);
            if (m_pProcessModule->ifNeedtomakeLearnRcp())//posted||false  //added by liusy[1.1.52]
            {
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + " Calculate learn start");
                bResult2 = do_CalculateLearn(m_sRcpName);
            }

            if (needAutoPVLearn())//[zhangcx v1.4.0_hotfix7]
            {
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() + " do Auto PV learn start");
                bResult3 = do_AutoPVLearn(m_sRcpName);
            }
            
        }
        catch(const RetryException &ex)
        {
            throw;
        }
        catch(const exception &ex)
        {
            AppRecipeManager::getInstance()->releaseRecipe(m_sRcpName);
            //clearRecipeInfo();
            clearRecipeInfoAbortOrProcessEnd();//add by zhangpf[v1.11.1]
            m_pProcessModule->changeModuleStatus(MODULE_STATUS::NotReady);
            m_pSlotAnm->setValue(PMAnmInfo::Aborted);
            m_pSlotSts->setValue(PMStatusInfo::Aborted);
            m_pSlotState->setValue(PMStateInfo::NotRd);
            Log_Error( "OperationalProcess:: failed in processing recipe for " + string(ex.what()) );
            throw AbortException(ex.what());
        }
        clearRecipeInfoAbortOrProcessEnd();//add by zhangpf[v1.11.1]

        if(bResult && bResult2 && bResult3)//added by liusy[1.1.52]
        {
            m_pSlotSts->setValue(PMStatusInfo::Processed);
            m_pSlotAnm->setValue(PMAnmInfo::Processed);
            m_pSlotState->setValue(PMStateInfo::Rd4Next);
            Log_Info( "OperationalProcess:: finish processing recipe ");
            return true;
        }
        else
        {
            m_pSlotSts->setValue(PMStatusInfo::BadWfr);
            m_pSlotState->setValue(PMStateInfo::NotRd);
            m_pSlotAnm->setValue(PMAnmInfo::Aborted);
            string strErrorInfo = "";

            if (!bResult)
            {
                strErrorInfo = strErrorInfo + "failed in processing recipe for unknown reason";
            }

            if (!bResult2)
            {
                strErrorInfo = strErrorInfo == ""? "failed to learning capacitance in processing recipe":
                    strErrorInfo + "failed to learning capacitance in processing recipe";
            }

			if (!bResult3)//[zhangcx v1.4.0_hotfix7]
			{
				strErrorInfo = strErrorInfo == "" ? "failed to learning PVSet in processing recipe" :
					strErrorInfo + "failed to learning PVSet in processing recipe";
			}

            Log_Error("OperationalProcess::" + strErrorInfo);
            throw AbortException("Process failed in slot " + Converter::convertToString(m_nSlotNumber)+
                ", reason : "+ strErrorInfo);
        }
     }
    else
    {
        AppRecipeManager::getInstance()->releaseRecipe(m_sRcpName);//modify by taohao[v1.5.0_HotFix] for release recipe
        return false;
    }

}

bool OperationalProcess::do_SetupAndProcessMaterial()
{
    Log_Info( getName()+ " OperationalProcess:: Start do_SetupAndProcessMaterial" );
    m_pStepNum->setValue(calculateStepNum());//added by mujy [v1.0.6] for recipe maybe changed after call_Prepare//changed by wzd 1.1.21
    double dTotalProcessTime = calculateProcessTime();//added by mujy [v1.0.6] for recipe maybe changed after call_Prepare
    m_pElapsedProcessTime->setValue(0);
    m_pProcessTime->setValue(dTotalProcessTime);
    m_pMaxProcessTime->setValue(dTotalProcessTime+m_pMaxProcessTimeTolerance->getValue());
    m_pRecipeTimeLeft->setValue(dTotalProcessTime);

    bool bResult = do_ProcessMaterial();
    //clearRecipeInfo();

    Log_Info( getName()+" OperationalProcess:: done do_SetupAndProcessMaterial" );
    return bResult;
}

bool OperationalProcess::do_ProcessMaterial()
{
    Log_Info( getName() + ":do_ProcessMaterial  start" );
    bool bResult = m_pFuncProcess->call_ProcessMaterial();
    return bResult;
}

void OperationalProcess::initRecipeInfo()//modify by taohao[v1.5.0_HotFix] for obtain the recipe from the memory
{
    string recipeName = AppRecipeManager::getInstance()->getRcpHandlerName();
    string recipeClass = AppRecipeManager::getInstance()->getHandlerClass();
    string recipeVersion = AppRecipeManager::getInstance()->getVersion();

    m_pRecipeName->setValue(recipeName);
    m_pRecipeClass->setValue(recipeClass);
    m_pRecipeVersion->setValue(recipeVersion);

    m_pStepNum->setValue(calculateStepNum());//changed by wzd 1.1.21
}

double OperationalProcess::calculateProcessTime()//modify by taohao[v1.5.0_HotFix] for obtain the recipe from the memory
{
    return m_pFuncProcess->getTotalProcessTime();
}

int OperationalProcess::calculateStepNum()  //add by wzd 1.1.21      // mod by xzr 1.1.26
{
    return AppRecipeManager::getInstance()->getNumOfSteps();//modify by taohao[v1.5.0_HotFix] for obtain the recipe from the memory
}

void OperationalProcess::clearRecipeInfo()
{
    m_pRecipeName->setValue("");
    m_pRecipeClass->setValue("");
    m_pRecipeVersion->setValue("");
    m_pStepNum->setValue(0);
    m_pProcessTime->setValue(0);
    m_pMaxProcessTime->setValue(0);
    m_pElapsedProcessTime->setValue(0);
    m_pStepName->setValue("");
    m_pStepID->setValue(0);
    m_pStepTime->setValue(0);
    m_pStepWaitTime->setValue(0);//added by xiasc for 508M time test
    m_pRFStableTime->setValue(0);
    m_pElapsedFullStepTime->setValue(0);
    m_pElapsedStepTime->setValue(0);
}

void OperationalProcess::clearRecipeInfoAbortOrProcessEnd()//add by zhangpf[v1.11.1]
{
    m_pStepNum->setValue(-1);
    m_pStepID->setValue(-1);
}

void OperationalProcess::setSlotNumber(int i)
{
    m_nSlotNumber = i;
}

void OperationalProcess::setTheProcessStr(std::string &strPath)
{
    ManagedObject *p = NULL;

    try
    {
        p = ObjectManager::getInstance()->getObject(strPath);
    }
    catch (const InvalidNameException &e)
    {
        p = ObjectManager::getInstance()->getObject(this, strPath);
    }
    m_pFuncProcess = dynamic_cast<FunctionalProcessInterface*>(p);
    if (m_pFuncProcess == NULL)
    {
        throw ConfigException("The object under path " + strPath + " is not the class expected.");
    }

}

void OperationalProcess::setProcessingSpell(std::string &strSpell)
{
    if(strSpell != "Processing" && strSpell != "Processng")
    {
        throw ConfigException(strSpell+" can't be allowed. The configure must be 'Processing' or 'Processng'.");
    }
    m_strProcessingSpell = strSpell;
}

IMPLEMENT_DYNAMIC_SERVICE(Prepare, OperationalProcess)
IMPLEMENT_DYNAMIC_SERVICE(Process, OperationalProcess)
IMPLEMENT_DYNAMIC_SERVICE(CalculateLearn, OperationalProcess)//added by liusy[1.1.52]

BEGIN_SERVICEINFO_LIST(OperationalProcess)
    ADD_SERVICE_INFO(OperationalProcess, Prepare, Prepare Module for Processing.)
        ADD_PARAM_INFO(OperationalProcess, Prepare, recipeName, string, The ID of recipe that is going to be processing.)
    ADD_SERVICE_INFO(OperationalProcess, Process, Process current recipe.)
    ADD_SERVICE_INFO(OperationalProcess, CalculateLearn, learn current recipe.)//added by liusy[1.1.52]
        ADD_PARAM_INFO(OperationalProcess, CalculateLearn, recipeName, string, The ID of recipe that is going to be processing.)
        ADD_PARAM_INFO(OperationalProcess, CalculateLearn, step, int, The ID of step that is going to be processing.)
END_SERVICEINFO_LIST(OperationalProcess)

// control objects
IMPLEMENT_DYNAMIC(OperationalProcess, ControlObjectEX)

BEGIN_MSG_MAP( OperationalProcess, ControlObjectEX )
    SET_I(setSlotNumber, OperationalProcess)
    SET_S(setTheProcessStr, OperationalProcess)
    SET_S(setProcessingSpell, OperationalProcess)
END_MSG_MAP
