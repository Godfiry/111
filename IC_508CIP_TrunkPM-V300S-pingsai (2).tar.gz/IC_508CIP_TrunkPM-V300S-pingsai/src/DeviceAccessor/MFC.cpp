/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MFC.cpp
** Description: This driver applys to GF100 of Brooks MFC  
** Release: 1.1
** Modification history: 
** 					2015-3-21   Mujy create
**      			2015-06-08  add retry when MFC read failed
**                  2015-10-27 add log for readCT and change timeout parameter 2 to 1
*********************************************************************/
#include "MFC.h"
#include <string.h>
#include "DeviceManager.h"

#include "Converter.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#include <iostream>//added by mujy 20151027
#include <sstream>//added by mujy 20151027
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std;

MFC::MFC():SerialDevice(200, "")
{
	//m_logger.init("/tmp",5000,1024*1024);//added by mujy 20151027
	//m_logger.start(PRIORITY_LOW);//added by mujy 20151027
}

MFC::~MFC()
{
    
}

/*
*	function name:  static int   GetMFCCheckSum(char * buff)   
*	description: MFC checksum calculate function 
*	parameter: char * buff--the string of command 
				
*	thinking:
*	return: int data for MFC checkSum
*/
int  MFC::GetMFCCheckSum(char * buff)
{
    int iLen = 0;
    int iLoop = 0;
    int nData[10] = {0};
    char cTemp[5] = {0};
    int nCheckSum = 0;

    iLen = strlen(buff);
    for (iLoop = 1 ; iLoop < iLen/2; iLoop ++)
    {
	memcpy( cTemp, buff +iLoop*2, 2 );
	sscanf( cTemp, "%x", &nData[iLoop] );
	nCheckSum += nData[iLoop];
    }
    return (nCheckSum &0xff);
}
 
/*		MFC device ID MAC_ID
		MFC1 33 MFC2 34 MFC3 35 MFC4 36 MFC5 37 MFC6 38 
		MFC7 39 MFC8 40 MFC9 41 MFC10 42 MFC11 43  MFC12 44
*/


/*function discripts :
 *	NewSetpoint = (32768 * setpoint  / Fullscale) + 16384 
 */
bool MFC::WriteCt(int channnelNum,double setpt ,const DoubleTypeInfo& typeinfo)
{ 
    if( setpt < (double)(typeinfo.getMin()) || setpt > (double)(typeinfo.getMax()))
    {
		return false;
    }
    int nCheckSum = 0;
    int nLData = 0;
    int nHData = 0;
    int value = 0;
    int nLen = 0;
    memset(Message,0,MAX_MESSAGE_LEN);
    memset(Response,0,MAX_MESSAGE_LEN);
    
    sprintf(Message,"%2x%s",channnelNum+32,"0281056901A4");
    // value = (int)((32768 * setpt / (typeinfo.getMax() - typeinfo.getMin()) ) + 16384);
  	 double tmp = (double)((32768 * setpt / (typeinfo.getMax() - typeinfo.getMin()) ) + 16384);//modified by chenmz [V2.0.4]
 	 double tmp1 = (int)tmp;
  	value = tmp1;
    nLData = value & 0xff;
    nHData = (value >>8) & 0xff;
    nLen = strlen(Message);
    sprintf(Message + nLen,"%2x%2x%s",nLData,nHData,"00");
    nCheckSum = GetMFCCheckSum(Message);   
 
    Message[0] = channnelNum+32;
    sprintf(Message +1,"%s","\x02\x81\x05\x69\x01\xA4");
    Message[7] = nLData;
    Message[8] = nHData;
    Message[9] = 0;
    Message[10] = nCheckSum;
    Message[11] = 0;  
  
    if(m_dev.writeRaw(Message, 11) <= 0)
    {
	return false;
    }
    usleep(30*1000);
  
    if(m_dev.readStr(Response,1,4) < 0)
    {
	return false;
    }
	return true;
}

string MFC::hexToString(int value)//added by mujy 20151027
{
	ostringstream t_o;
	int t_v1 = value;
	int t_v2 = 0;
	string t_res = "";
	if(t_v1 == 0)
	{
	   t_res = "00";	
	}
	
	while(t_v1 > 0) 
	{
		t_v2 = t_v1 % 16;
		t_v1 = (int)(t_v1 / 16);
		t_o.str("");
		t_o <<hex << t_v2;
		t_res = t_o.str() + t_res;		
	}
	
	if(value>0 && value<16)
	{
	   t_res = "0"+t_res;	
	}
	return t_res;
}

bool MFC::ReadCt(int channnelNum, double *value ,const DoubleTypeInfo& typeinfo )
{
    int nCheckSum = 0;
    char cTemp[4] = {0};
    int nLData = 0;
    int nHData = 0;
    int nValue = 0;
    int nLen = 0;
    double fData = 0;
    string str="";//added by mujy 20151027
    
    memset(Message,0,MAX_MESSAGE_LEN);
    memset(Response,0,MAX_MESSAGE_LEN);
    
    sprintf(Message,"%2x%s",channnelNum+20,"0280036A01A900");
    nCheckSum = GetMFCCheckSum(Message);
    
    Message[0] = channnelNum+20;
    sprintf(Message +1,"%s","\x02\x80\x03\x6A\x01\xA9");
    nLen = strlen(Message);
    Message[nLen] = 0;
    Message[nLen + 1] = nCheckSum;
    Message[nLen + 2] = 0;  
    
    while ((nLen = m_dev.readStr(Response,1,MAX_MESSAGE_LEN)) > 0)//modified by mujy 20151103;change timeout parameter 2 to 1
    {
		usleep(30*1000);
    }

    for(int i = 0; i < 10; i++)//added by mujy 20151027
    {
    	str+=hexToString(((int)Message[i])&0x00ff);//added by mujy 20151027
		str+=" ";
    }
    //m_logger.logMsg("ReadMFCFlow: MFC"+Converter::convertToString(channnelNum-12)+
	//	" command  len = "+Converter::convertToString(10)+"  write command = "+str);//added by mujy 20151027
    
    if(m_dev.writeRaw(Message, read_message_length) <= 0)
	return false;
    
    usleep(30*1000);
    
    memset(Response,0,MAX_MESSAGE_LEN);
    nLen = m_dev.readStr(Response, msg_timeout,receive_message_length - read_message_length);
    str="";//added by mujy 20151027
    for(int i = 0; i < nLen; i++)//added by mujy 20151027
    {
    	str+=hexToString(((int)Response[i])&0x00ff);//added by mujy 20151027
		str+=" ";
    }
    
    //m_logger.logMsg("ReadMFCFlow: MFC"+Converter::convertToString(channnelNum-12)+
	//	" response len = "+Converter::convertToString(nLen)+" response      = "+str);//added by mujy 20151027

    if (nLen < (receive_message_length - read_message_length) )
    {
    	SysLogger::getInstance()->logMsg(LOGBRANCH::IO, LEVEL::ERROR, "MFC::ReadCt error at channnelNum = " + Converter::convertToString(channnelNum)+" and retry.");
		while ((nLen = m_dev.readStr(Response,1,MAX_MESSAGE_LEN)) > 0)//modified by mujy 20151103 ;change timeout parameter 2 to 1
	    {
			usleep(30*1000);
	    }
	    
	    if(m_dev.writeRaw(Message, read_message_length) <= 0)
			return false;
	    
	    usleep(30*1000);
	    
	    memset(Response,0,MAX_MESSAGE_LEN);
	    nLen = m_dev.readStr(Response, msg_timeout,receive_message_length - read_message_length);
	    str="";//added by mujy 20151027
    	for(int i = 0; i < nLen; i++)//added by mujy 20151027
    	{
    		str+=hexToString(((int)Response[i])&0x00ff);//added by mujy 20151027
			str+=" ";
    	}
    
	   // m_logger.logMsg("ReadMFCFlow retry: MFC"+Converter::convertToString(channnelNum-12)+" response len = "+Converter::convertToString(nLen)+" response      = "+str);//added by mujy 20151027

	    if (nLen < (receive_message_length - read_message_length) )
	    {
			return false;
	    }
    }
    
    status = ONLINE;
    
    memcpy(cTemp,Response - read_message_length + 17 ,2);
    nLData=cTemp[0];
    nHData = cTemp[1];
    nValue =(( nHData<<8 ) + (nLData &0xff))&0xffff;
    fData =(double)((double) nValue/65535.0*1000)/1000.0;   //return value  fron MFC 
    if (fData < 0.25)
	fData = 0.25 ;
    
    *value = (fData - 0.25) *2 * (typeinfo.getMax() - typeinfo.getMin()) ;
    if((*value)<(double)(typeinfo.getMin()))
     	*value = typeinfo.getMin();
    
    if ((*value)>(double)(typeinfo.getMax()))
     	*value = typeinfo.getMax();
    
    return true;
}
 
/*
bool MFC::ReadVoltageCt( int channnelNum,double *value ,const DoubleTypeInfo& typeinfo)
{
    int nCheckSum = 0;
    char cTemp[4] = {0};
    int nLData = 0;
    int nHData = 0;
    int nValue = 0;
    int nLen = 0;
    double fData = 0;
    
    memset(Message,0,MAX_MESSAGE_LEN);
    memset(Response,0,MAX_MESSAGE_LEN);
    
    sprintf(Message,"%2x%s",channnelNum + 8,"0280036A01B600");
    nCheckSum = GetMFCCheckSum(Message);
    
    Message[0] = channnelNum + 8;
    sprintf(Message +1,"%s","\x02\x80\x03\x6A\x01\xB6");
    nLen = strlen(Message);
    Message[nLen] = 0;
    Message[nLen + 1] = nCheckSum;
    Message[nLen + 2] = 0;
    
    while ((nLen = m_dev.readStr(Response, 2,MAX_MESSAGE_LEN)) > 0)
    {
	usleep(30*1000);
    }
    
    if(m_dev.writeRaw(Message, read_message_length) <= 0)
    {
	return false;
    }
    
    usleep(30*1000);
    
    nLen = m_dev.readStr(Response, msg_timeout,receive_message_length - read_message_length);     
    if (nLen < (receive_message_length - read_message_length) )
    {
	return false;
    }
    
    status = ONLINE;
   
    memcpy(cTemp,Response - read_message_length + 17 ,2);
    nLData=cTemp[0];
    nHData = cTemp[1];
    nValue =(( nHData<<8 ) + (nLData &0xff))&0xffff;
    fData =(double)((double) nValue/65535.0*1000)/1000.0;   //return value  from MFC 
    if (fData < 0)
	*value = 0.0;
    else if(fData >= 0.5)
	*value = 0.5 - 0.0001;//[0,0.5)
    else
	*value = fData;
    
    if((*value) < (double)(typeinfo.getMin()))
	*value = typeinfo.getMin();
    
    if ((*value) > (double)(typeinfo.getMax()))
	*value = typeinfo.getMax();
    
    return true;
}
*/
/*
bool MFC::ReadADt( int channnelNum,int *value ,const IntTypeInfo& typeinfo)
{
    int alarmornot;
    int nCheckSum = 0;
    char cTemp[4] = {0};
    int nData[4] = {0};
    int nLen = 0;

    memset(Message,0,MAX_MESSAGE_LEN);
    memset(Response,0,MAX_MESSAGE_LEN);
    
    sprintf(Message,"%2x%s",channnelNum - 8,"0280036501A000");
    nCheckSum = GetMFCCheckSum(Message);
    
    Message[0] = channnelNum - 8;
    sprintf(Message +1,"%s","\x02\x80\x03\x65\x01\xA0");
    nLen = strlen(Message);
    Message[nLen] = 0;
    Message[nLen + 1] = nCheckSum;
    Message[nLen + 2] = 0;  
  
    while ((nLen = m_dev.readStr(Response, 2,MAX_MESSAGE_LEN)) > 0)
    {
	usleep(30*1000);
    }

    if(m_dev.writeRaw(Message, 9) == -1)
    {
	return false;
    }

    usleep(30*1000);

    nLen = m_dev.readStr(Response, msg_timeout,receive_alarm_length - 9);
    if (nLen < (receive_alarm_length - 9) )
    {
	return false;
    }

    status = ONLINE;
    memcpy(cTemp,Response +8 ,4);
    
    nData[0] = cTemp[0];
    nData[1] = cTemp[1];
    nData[2] = cTemp[2];
    nData[3] = cTemp[3];
    
    if ((nData[0] == 0)&&(nData[1] == 0)&&(nData[2] == 0)&&(nData[3] == 0))
	alarmornot = 0;
    else
	alarmornot = 1;

    *value = alarmornot;
    return true;
}
*/
bool MFC::ReadStatusDt( int channelNum,int *value ,const IntTypeInfo& typeinfo)
{
	if(channelNum == 37)
	{
		*value = status;
		return true;
	}	
	else
		return false;
}
bool MFC::WriteVDt( int channelNum,int setpt  ,const IntTypeInfo& typeinfo)
{
    memset(Message,0,MAX_MESSAGE_LEN);
    memset(Response,0,MAX_MESSAGE_LEN);
    
    if((setpt==0||setpt==1||setpt==2)==false)
    {
	return false;
    }
    int nCheckSum = 0;
    int len = 0;    

    sprintf(Message,"%2x%s%2x",channelNum - 22,"0281046A0101",setpt);
    nCheckSum = GetMFCCheckSum(Message);    

    Message[0] = channelNum - 22;
    sprintf(Message +1,"%s","\x02\x81\x04\x6A\x01\x01");
    len = strlen(Message);
    
    Message[len] = setpt;
    Message[len + 1] = 0;
    Message[len + 2] = nCheckSum;
    Message[len + 3] = 0;  
  
    while ((len = m_dev.readStr(Response,2, MAX_MESSAGE_LEN)) > 0) 
    {
	usleep(30*1000);
    }
    
    if(m_dev.writeRaw(Message, 10) <= 0)
    {
	return false;
    }
    
    usleep(30*1000);
    memset(Response,0,MAX_MESSAGE_LEN);
    if(m_dev.readStr(Response,1,4) < 0)
    {
	return false;
    }
	return true;
 }

void MFC::InitMFC()
{
    status = OFFLINE;
    /*each MFC should be init to FF_W = 1 mode */
    /*m_dev.writeRaw( "\x21\x02\x81\x04\x69\x01\x05\x01\x00\xF7", 10);   
    usleep(30*1000);
    m_dev.writeRaw( "\x22\x02\x81\x04\x69\x01\x05\x01\x00\xF7", 10);
    usleep(30*1000);
    m_dev.writeRaw( "\x23\x02\x81\x04\x69\x01\x05\x01\x00\xF7", 10);
    usleep(30*1000);
    m_dev.writeRaw( "\x24\x02\x81\x04\x69\x01\x05\x01\x00\xF7", 10);
    usleep(30*1000);
    m_dev.writeRaw( "\x25\x02\x81\x04\x69\x01\x05\x01\x00\xF7", 10);
    usleep(30*1000);
    m_dev.writeRaw( "\x26\x02\x81\x04\x69\x01\x05\x01\x00\xF7", 10);
    usleep(30*1000);
    m_dev.writeRaw( "\x27\x02\x81\x04\x69\x01\x05\x01\x00\xF7", 10);
    usleep(30*1000);
    m_dev.writeRaw( "\x28\x02\x81\x04\x69\x01\x05\x01\x00\xF7", 10);
    usleep(30*1000);
    m_dev.writeRaw( "\x29\x02\x81\x04\x69\x01\x05\x01\x00\xF7", 10);
    usleep(30*1000);
    m_dev.writeRaw( "\x2A\x02\x81\x04\x69\x01\x05\x01\x00\xF7", 10);
    usleep(30*1000);
    m_dev.writeRaw( "\x2B\x02\x81\x04\x69\x01\x05\x01\x00\xF7", 10);
    usleep(30*1000);
    m_dev.writeRaw( "\x2C\x02\x81\x04\x69\x01\x05\x01\x00\xF7", 10);
    usleep(30*1000);*/
    
    /*each MFC should be init to flow control mode */
    /*m_dev.writeRaw( "\x21\x02\x81\x04\x69\x01\x03\x01\x00\xF5", 10);
    usleep(30*1000);
    m_dev.writeRaw( "\x22\x02\x81\x04\x69\x01\x03\x01\x00\xF5", 10);
    usleep(30*1000);
    m_dev.writeRaw( "\x23\x02\x81\x04\x69\x01\x03\x01\x00\xF5", 10);
    usleep(30*1000);
    m_dev.writeRaw( "\x24\x02\x81\x04\x69\x01\x03\x01\x00\xF5", 10);
    usleep(30*1000);
    m_dev.writeRaw( "\x25\x02\x81\x04\x69\x01\x03\x01\x00\xF5", 10);
    usleep(30*1000);
    m_dev.writeRaw( "\x26\x02\x81\x04\x69\x01\x03\x01\x00\xF5", 10);
    usleep(30*1000);
    m_dev.writeRaw( "\x27\x02\x81\x04\x69\x01\x03\x01\x00\xF5", 10);
    usleep(30*1000);
    m_dev.writeRaw( "\x28\x02\x81\x04\x69\x01\x03\x01\x00\xF5", 10);
    usleep(30*1000);
    m_dev.writeRaw( "\x29\x02\x81\x04\x69\x01\x03\x01\x00\xF5", 10);
    usleep(30*1000);
    m_dev.writeRaw( "\x2A\x02\x81\x04\x69\x01\x03\x01\x00\xF5", 10);
    usleep(30*1000);
    m_dev.writeRaw( "\x2B\x02\x81\x04\x69\x01\x03\x01\x00\xF5", 10);
    usleep(30*1000);
    m_dev.writeRaw( "\x2C\x02\x81\x04\x69\x01\x03\x01\x00\xF5", 10);
    usleep(30*1000);*/
    status = ONLINE;
 }
 
void MFC::InitChannels(DeviceNode<MFC> *node)
{    
    for(int i=1; i<=12; i++)
    {
	node->registerWriteCh(i,&MFC::WriteCt);
    }
    
    for(int i=13; i<=24; i++)
    {
	node->registerReadCh(i,&MFC::ReadCt);
    }

	node->registerReadCh(37,&MFC::ReadStatusDt);
    /*
    for(int i=41; i<=52; i++)
    {
	node->registerReadCh(i,&MFC::ReadADt);
    }*/
    
    for(int i=55; i<=66; i++)
    {
	node->registerWriteCh(i,&MFC::WriteVDt);
    }
    
    /*for(int i=25; i<=36; i++)
    {
	node->registerReadCh(i,&MFC::ReadVoltageCt);
    }*/
}

void MFC::init()
{
    DeviceNode<MFC> *node = new DeviceNode<MFC>(m_pollPeriod,this);
    InitChannels(node);
    DeviceManager::getInstance()->registerNode(m_nodeNum, node);
    if(!isSimulated())
    {
    	InitMFC();
    }
}

IMPLEMENT_DYNAMIC(MFC, SerialDevice )
BEGIN_MSG_MAP(MFC, SerialDevice )
    SET_V( init, MFC )
END_MSG_MAP
