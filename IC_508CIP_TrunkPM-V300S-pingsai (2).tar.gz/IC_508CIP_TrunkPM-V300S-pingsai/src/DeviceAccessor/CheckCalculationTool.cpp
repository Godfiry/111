#include "CheckCalculationTool.h"
#include "Hex.h"

CheckCalculationTool::CheckCalculationTool()
{
}

CheckCalculationTool::~CheckCalculationTool()
{
}

unsigned short CheckCalculationTool::GetCRCCode(char* nCmd,int nLen)
{
	unsigned short nCRCCode=0xFFFF;
	unsigned short nPolyNomial=0xA001;
	
	unsigned int i,j;
	for(i=0;i<nLen;i++)
	{
		nCRCCode=nCRCCode^(nCmd[i]&0x00FF);
		for(j=0;j<8;j++)
		{
			if(nCRCCode&1)
			{
          		nCRCCode=nCRCCode>>1;
		   		nCRCCode=nCRCCode^nPolyNomial;
			}
			else
			{
				nCRCCode=nCRCCode>>1;
			}
		}
	}
	return nCRCCode;
}


unsigned short CheckCalculationTool::GetCRCCode(char* nCmd, int nPosBegin, int nPosEnd)//[wangyk 1.4.0]
{
	unsigned short nCRCCode=0;

	for(int i = nPosBegin; i<=nPosEnd; i++)
	{
		nCRCCode+=nCmd[i];
	}
	return nCRCCode;
}

std::string CheckCalculationTool::GetLRCCode(const std::string &buffer)
{
	int nSum = 0;
	int nValue = 0;
	unsigned int i = 1; 
	while(i < buffer.length()-1)
	{
		Hex::stringToHex(&nValue, buffer.substr(i, 2));
		nSum += nValue;
		nValue = 0;
		i += 2;
	}
	nSum = - nSum;
	nSum = nSum & 0xFF;

	return Hex::hexToString(nSum,2);
}

int CheckCalculationTool::GetLRCCode( char * pCommand, int nLen )
{
	int nSum;
	nSum = 0;
	for(unsigned int i = 0; i < nLen; ++i)
	{
		nSum += pCommand[i];
    	}
	nSum = -nSum;
	return (nSum & 0xFF);
}

unsigned short CheckCalculationTool::GetXORCode(char* nCmd,int nLen)
{
	//calculate CRC by EXCLUSIVE-OR(XOR) of all the frame bytes
	unsigned short nXORCode=0xFF;
	
	unsigned int i,j;
	for(i=0;i<nLen;i++)
	{
		nXORCode=nXORCode^(nCmd[i]&0xFF);
	}
	return nXORCode;
}

unsigned short CheckCalculationTool::GetCRC16Code(char* nCmd,int nLen)
{
	unsigned short crc=0xFFFF;
	unsigned short polynomial=0xA001;
	
	unsigned int i,j;
	for(i=0;i<nLen;i++)
	{
		crc=crc^(nCmd[i]&0x00FF);
		for(j=0;j<8;j++)
		{
			if(crc&1)
			{
          		crc=crc>>1;
		   		crc=crc^polynomial;
			}
			else
			{
				crc=crc>>1;
			}
		}
	}
	return crc;
}

unsigned short CheckCalculationTool::GetCRC16CodeCCITT(char* nCmd,int nLen)  //add by wzd 1.1.39
{
	unsigned short crc;
	unsigned short polynomial=0x1021;
	unsigned int i,j;
	unsigned short byte;
	crc = 0xFFFF;
	for(i = 0;i < nLen;i++)
	{
		byte = nCmd[i];
		crc = crc ^ (byte << 8);
		for(j = 1;j <= 8;j++)
		{
			if((crc & 0x8000) > 0)
			{
		   		crc = (crc << 1) ^ polynomial;
			}
			else
			{
				crc = (crc << 1);
			}
		}
	}
	return crc;
}

unsigned short CheckCalculationTool::GetModbusCRC16Code(char* nCmd,int nLen)//added by guojin[1.1.42]
{
	unsigned short crc=0xFFFF;
	unsigned short polynomial=0xA001;
	
	unsigned int i,j;
	for(i=0;i<nLen;i++)
	{
		crc=crc^nCmd[i];
		for(j=0;j<8;j++)
		{
			if(crc&1)
			{
          		crc=crc>>1;
		   		crc=crc^polynomial;
			}
			else
			{
				crc=crc>>1;
			}
		}
	}
	return crc;
}

