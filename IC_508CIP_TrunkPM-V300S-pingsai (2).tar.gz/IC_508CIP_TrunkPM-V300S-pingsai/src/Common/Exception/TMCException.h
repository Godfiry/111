/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TMCException.h
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-02-26  LiJuanjuan create
**      
*********************************************************************/
#ifndef TMCEXCEPTION_H_
#define TMCEXCEPTION_H_

#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "AbortException.h"
#endif
#ifdef IAP4_0
using namespace IAP;
#endif

class TMCException:public AbortException
{
	public:
		TMCException(const std::string &s);
};

#endif /*TMCEXCEPTION_H_*/
