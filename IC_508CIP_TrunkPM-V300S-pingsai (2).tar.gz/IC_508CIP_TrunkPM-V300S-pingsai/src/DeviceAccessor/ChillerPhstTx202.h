/********************************************************************
** Copyright (c) 2018, Beijing NAURA Co.,Ltd.  All rights reserved.
** File name: ChillerPhstTx202.h
** Description: This driver is used for PHST Heat Exchanger (instead of chiller)
*                RS485 ATS communication protocol TX-20AGLI
* 				   Communication Type:Modbus protocol,ASCII Mode
* 				   BaudRate:9600
*                  DataBit:7
* 				   StartBit:1
*                  StopBit:1
*                  Parity:Even
*                  FlowControl:no flow control 
*                          
** Release: 1.1
** Modification history: 
** 					2020-5-12   chenmz create
**      
*********************************************************************/
#ifndef CHILLERPHSTTX202_H_
#define CHILLERPHSTTX202_H_

#include "SerialDevice.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#include "ReadWriteDouble.h"
#include <string>
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class ChillerPhstTx202:public SerialDevice
{
	DECLARE_DYNAMIC(ChillerPhstTx202)	
	DECLARE_MSG_MAP
		
	public:
		ChillerPhstTx202();
		virtual ~ChillerPhstTx202();

	public:	
		bool writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo);
		bool readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);
		bool readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);
		bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
		
		void init();
		
	protected:
		void initDevice();
		void initChs(DeviceNode<ChillerPhstTx202> *pNode);
	
	private:
		typedef struct
		{
			std::string m_strAddress;
			int m_nPos;
		}Cmd;
		static Cmd m_cmd[];
	private:		
		std::string m_strFinalCommand;
		int m_nChillerTemp1SetValue;
		int m_nChillerTemp2SetValue;
};
#endif /*CHILLERPHSTTX20_H_*/
