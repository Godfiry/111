/********************************************************************
** Copyright (c) 2006, Beijing COMDEL Co.,Ltd.  All rights reserved.
** File name: COMDELMatchDriver.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2016-06-08   mujy create
**      
*********************************************************************/
#include "COMDELMatchDriver.h"
#include "DeviceManager.h"

#include "SysLogger.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std; 
COMDELMatchDriver::Com COMDELMatchDriver::m_commands[] = {{0, ""}, //0	reserved 						
											{0, "SM1", 0},//1 (CH,value)manual
											{0, "SM0", 0},//2 auto		
											{1, "SA", 0},//3 set c1
											{1, "SB", 0},//4 set c2	
											{1, "PA", 0},//5 set preset c1	
											{1, "PB", 0},//6 set preset c2															
											{4, "RS", 0},//7 get Manual/Auto
											{4, "RA", 10},//8 get c1
											{4, "RB", 10},//9 get c2
											{4, "R1", 10},//10 get preset c1//maybe nouse
											{4, "R2", 10},//11 get preset c2//maybe nouse									
											{4, "RD", 1},//12 get DCBias
											{4, "RV", 2}//13 get Vpp                                                                     
};											 
											
COMDELMatchDriver::COMDELMatchDriver():SerialDevice(100, "\x0D")
{
}

COMDELMatchDriver::~COMDELMatchDriver()
{
}

bool COMDELMatchDriver::sendCommand(std::string command, int timeOut)
{
        cout<<"sendCommand command = "<<command<<endl;
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "COMDELMatchDriver sendCommand command =" +command);

	string res = getCommandResult(command, timeOut);
        cout<<"sendCommand res = "<<res<<endl;
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "COMDELMatchDriver sendCommand res =" +res );
	if(res.find("\x0A\x0D",0) == string::npos)
	{	
		res += getResultOnly(100);
               
	}

	if(res.find("\x0A\x0D\x3E",0) != string::npos)
	{
		return true;
	}
	else if(res.find("\x0A\x0D?",0) != string::npos)
	{
		throw IOException("command error:" + res);
	}
	else
	{
		throw IOException("unknow read_back: " + res);
	}		

}
		
std::string COMDELMatchDriver::readCommand(std::string command, int timeOut)
{
	string res = getCommandResult(command, timeOut);
	
	if(res.find("\x0A\x0D\x3E",0) != string::npos)
	{	
		return res;
	}
	else if(res.find("\x0A\x0D?",0) != string::npos)
	{
		throw IOException("command error:" + res);
	}	
	else
	{
		throw IOException("unknow read_back: " + res);
	}		
}

bool COMDELMatchDriver::writeInt(int channelNum, int value, const IntTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	int ps = com.m_ps;
	string msg = "";
	switch(ps)
	{
		case 0:
			//msg = com.m_s1;
			msg = m_commands[channelNum + value].m_s1;
			break;
		case 1:
			msg = com.m_s1 + Converter::convertToString(value);
			break;	
	}
	return sendCommand(msg, m_timeOut);
}
	
bool COMDELMatchDriver::writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];	
	string	msg = com.m_s1 + Converter::convertToString((int)(value*10));		
	return sendCommand(msg, m_timeOut);
}	
		
bool COMDELMatchDriver::writeRawCommand(int channelNum, std::string value, const StringTypeInfo &typeInfo)
{
	return sendCommand(value, m_timeOut);
}
		
bool COMDELMatchDriver::readInt(int channelNum, int *value, const IntTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	int ps = com.m_ps;
	string res = readCommand(com.m_s1, m_timeOut);
	string t_value = (res.substr(0, ps));
	if(channelNum<=11 && channelNum>=8)
	{
		int t_intv;
		if(!Converter::stringToInt(t_intv, t_value))
		{
		   throw IOException("read back value is not an valid int value");
		}
		*value = t_intv;
	}
	else
	{
		if(!Converter::stringToInt(*value, t_value, std::hex))
		{
		    throw IOException("read back value is not an valid int value");
		}
		int temp;
		temp = (*value >> com.m_ps2) & 0x0001;		
		if(temp)//1 == Manual
		{
			*value = 0;//IO config = Manual
		}
		else//0 == Auto
		{
			*value = 1;//IO config = Auto	
		}
	}	
		
	return true;
}
		
bool COMDELMatchDriver::readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	int ps = com.m_ps;
	string res = readCommand(com.m_s1, m_timeOut);
	string t_value = (res.substr(0, ps));
	int t_intv;
	if(!Converter::stringToInt(t_intv, t_value))
	{
	   throw IOException("read back value is not an valid int value");
	}
	*value = (double)t_intv / com.m_ps2;
	/*if(*value < 0)
	{
		*value = 0;
	}
	else if(*value > 10000)
	{
		*value = 10000;
	}*/
		return true;
	
	
}

void COMDELMatchDriver::initChs(DeviceNode<COMDELMatchDriver> *node)
{
	
	node->registerWriteCh(1, &COMDELMatchDriver::writeInt);
	
	for(int i = 3; i <= 6; ++i)
	{
		node->registerWriteCh(i, &COMDELMatchDriver::writeInt);
	}	
	
	node->registerReadCh(7, &COMDELMatchDriver::readInt);
	for(int i = 8; i <= 11; ++i)
	{		
		node->registerReadCh(i, &COMDELMatchDriver::readInt);
	}	
	node->registerReadCh(12, &COMDELMatchDriver::readDouble);
	node->registerReadCh(13, &COMDELMatchDriver::readDouble);//added by zhangyy[v1.7.08]
        node->registerWriteCh(20, &COMDELMatchDriver::writeRawCommand);
	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &COMDELMatchDriver::getStatus);
}

void COMDELMatchDriver::initDevice()
{
     // string s="!";
     //sendCommandOnly(s);
     sendCommand("!",m_timeOut);
}
		
void COMDELMatchDriver::init()
{
	DeviceNode<COMDELMatchDriver> *node = new DeviceNode<COMDELMatchDriver>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	if(!isSimulated())
	{
		initChs(node);		
		initDevice();
	}
}

IMPLEMENT_DYNAMIC(COMDELMatchDriver, SerialDevice )
BEGIN_MSG_MAP(COMDELMatchDriver, SerialDevice )
    SET_V( init, COMDELMatchDriver )
END_MSG_MAP
