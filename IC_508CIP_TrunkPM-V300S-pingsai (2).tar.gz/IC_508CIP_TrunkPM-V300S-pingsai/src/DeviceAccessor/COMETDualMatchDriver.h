/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: COMETDualMatchDriver.h
** Description:  
** Release: 1.1
** Modification history: 
** 					
**                  2014-11-27   gaozl	create
*********************************************************************/
#ifndef COMETDUALMATCHDRIVER_H_
#define COMETDUALMATCHDRIVER_H_
#include "COMETMatchDriver.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#include "DescriptorList.h"
#include "StringTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class COMETDualMatchDriver:public COMETMatchDriver
{
	DECLARE_DYNAMIC(COMETDualMatchDriver)	
	DECLARE_MSG_MAP	

	private:
		typedef struct
		{
			int m_ps;
			std::string m_s1;
			int m_ps2;
		}Com;

		static Com m_commands[];	  

	protected:
		void initChs(DeviceNode<COMETDualMatchDriver> *node);
		void initDevice();	
		
	public:
		COMETDualMatchDriver();
		virtual ~COMETDualMatchDriver();
		
		bool writeInt(int channelNum, int value, const IntTypeInfo &typeInfo);
		bool writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo);
		bool writeRawCommand(int channelNum, std::string value, const StringTypeInfo &typeInfo);
		bool readInt(int channelNum, int *value, const IntTypeInfo &typeInfo);
		bool readString(int channelNum, std::string *value, const StringTypeInfo &typeInfo);
		bool readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo);
		std::string HexCharToBinStr(char hexch);
		void init();		
};

#endif /*COMETDUALMATCHDRIVER_H_*/
