#include "AEDualMatchICP.h"
#include <string.h>
#include "DeviceManager.h"
#include <iostream>
#include <sys/time.h>
#include <sstream>
#include "Converter.h"
#include <cmath>
#include "SysLogger.h"
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std;

AEDualMatchICP::AEDualMatchICP():SerialDevice(100,"")
{
    ack[0] = (char)0x06;
    m_nAddr = 1;
    m_nPreC1 = 0;
    m_nPreC2 = 0;
} 

AEDualMatchICP::~AEDualMatchICP()
{
}
AEDualMatchICP::Com AEDualMatchICP::m_commands[] =
                        { {0, 0, 0 },     // 0 reserved
                        {7, 0x5D, 4},     // 1 set Control Mode (0x5D == 93), send 4 Byte, Response = 1 CSR only
                        {7, 0x70, 4},     // 2 set C1 position (0x70 == 112), send 4 Byte, Response = 1 CSR only
                        {7, 0x7A, 4},     // 3 set C2 position  (0x7A == 122), send 4 Byte, Response = 1 CSR only
                        {12, 0x5C, 4},    // 4 store C1&C2 preset (0x5C == 92), send 9 Byte, Response = 1 CSR only
                        {7, 0x5B, 4},     // 5 recall C1&C2 preset (0x5B == 91), send 4 Byte, Response = 1 CSR only

                        {5, 0xA3, 7},     // 6 read Control Mode (0xA3 == 163), send 2 Byte, Response = 4 Byte
                        {5, 0xB4, 9},        // 7 read C1 position (0xB4 == 180), send 2 Byte, Response = 6 Byte
                        {5, 0xB4, 9},     // 8 read C2 position (0xB4 == 180), send 2 Byte, Response = 6 Byte
                        {7, 0xF8, 32},    // 9 read VDC (248-206)*
                        {7, 0xF8, 32},    // 10 read I-out (248-206)
                        {7, 0xF8, 32},    // 11 read V-out (248-206)
                        {7, 0xF8, 32},    // 12 read R     (248-206)
                        {7, 0xF8, 32},    // 13 read X     (248-206)
                        {7, 0xF8, 32},    // 14 read Phase (248-206)
                        {3, 0x7D, 4},     // 15 set Reset (0x7D == 125), send 0 Byte, Response = 1 CSR only
                        {16, 0x76, 4},    // 16 set Prior Time (0x76 == 118-209), send 12 Byte, Response = 1 CSR only
                        {7, 0xF8, 12},    // 17 read Prior Time (0xF8 == 248), send 4 Byte, Response = 8 Byte
                        {7, 0x5E, 4},     // 18 enable/disable presets (0x5E == 94), send 4 Byte, Response = 1 CSR only
                        {5, 0xA4, 7},     // 19 read enable/disable presets (0xA4 == 164), send 2 Byte, Response = 4 Byte
                        {4, 0xDF, 44},    // 20 read status or fault(0xDF == 223), send 1 Byte, Response = different Byte
                        {6, 0x5F, 4},     // 21 set C3 position (0x5F == 95), send 3 Byte, Response = 1 CSR only
                        {4, 0xA5, 6},      // 22 read C3 position  (0xA5 == 165), send 1 Byte, Response = 3 Byte
                        {4,0xA5, 10},       //23 read current ratio in thousands,send 1Byte,Response =7 Byte, Byte 1 and 2
                        {4,0xA5, 10},       //24 read current one (in 10 mA),send 1Byte,Response =7 Byte, Byte 3 and 4
                        {4,0xA5, 10},       //25 read current two (in 10 mA),send 1Byte,Response =7 Byte, Byte 5 and 6
                        {4,0xA5, 8},       //26 read voltage one,send 1Byte,Response =5 Byte, Byte 1 and 2
                        {4,0xA5, 8}       //27 read voltage two,send 1Byte,Response =5 Byte, Byte 3 and 4
                        }; 
                                                                                        
bool AEDualMatchICP::sendCommandAck(char *pMsg, char *pResponse, int nMsg_timeout,int nResplen, int nMsglen)
{
    int nRet = getCommandResult(pMsg, nMsglen, pResponse, nResplen, m_timeOut);
    
    if(pResponse[0] != 0x06 || nRet <= 0)
    {
     cout<<"sendCommand response "<<hex<<(int)pResponse[0]<<" "<<(int)pResponse[1]<<" "<<(int)pResponse[2]<<" "<<(int)pResponse[3]<<" "<<(int)pResponse[4]<<endl;
     throw IOException("Send packet's verification is wrong");
    }
    else if(pResponse[3] != 0x00)
    {
       cout<<"sendCommand response "<<hex<<(int)pResponse[0]<<" "<<(int)pResponse[1]<<" "<<(int)pResponse[2]<<" "<<(int)pResponse[3]<<" "<<(int)pResponse[4]<<endl;
        string strErr = "Response(CSR) codes was not accepted, CSR is ";
        strErr += Converter::convertToString((int)pResponse[3]);
         throw IOException(strErr);
    }
   sendCommandOnly(ack,1); 
   return true;
}

bool AEDualMatchICP::readCommand(char *pMsg, char *pResponse, int nMsg_timeout,int nResplen, int nMsglen)
{
    getFixCommandResult(pMsg, nMsglen, pResponse, nResplen, m_timeOut, 2);
   
    if(pResponse[0] != 0x06 )
    {
        throw IOException("Send packet's verification is wrong");
    }
      sendCommandOnly(ack,1);
      return true;
}

bool AEDualMatchICP::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
    if(2 == nChannelNum)
        m_nPreC1 = nValue;
    if(3 == nChannelNum)
        m_nPreC2 = nValue;
    if(4 == nChannelNum)
        nValue = (m_nPreC1*1000 + m_nPreC2) * 100 + nValue; //store c1 and c2 to Position value ( Position value = 1-10)
    Com com = m_commands[nChannelNum];

    memset(message, 0, MESS_LEN);
    memset(resp, 0, RESP_LEN);
    message[0] = (char)(com.nCmdLen-3+8*m_nAddr); // 5 == -3 + 00001000_bin
    message[1] = com.cCmdNum;
    int nTempInt;
    switch(com.nCmdLen)
    {
            case 3:  // Reset (Channel=15)
                message[2] = message[0]^message[1];
                break;

            case 6:   // set C3 position  (Channel=21)
                nTempInt = nValue*10;  //nValue = 0-9999 means 0%-99%
                message[2] = 0x00;  // 0 means set C3 position
                message[3] = nTempInt&0xff; //Low 8 bits
                message[4] = (nTempInt>>8)&0xff;  //High 8 bits
                message[5] = message[0]^message[1]^message[2]^message[3]^message[4];
               break;

            case 7:
               if (com.cCmdNum == (char)0x5E)// set enable/disable presets(Channel=18)
             {
                message[2] = 0x01;
                message[3] = 0x00;  //[2] and [3] means select Match network1
                message[4] = (int)nValue&0xff;   //nValue =0(Disble),1(Enable)
                message[5] = 0x00;
                message[6] = message[0]^message[1]^message[2]^message[3]^message[4]^message[5];
             }
             else
             {
                 if (com.cCmdNum == (char)0x5D || com.cCmdNum == (char)0x5B) // set control mode(Channel=1), recall preset(Channel=5)
                 {
                     message[2] = 0x01;
                     message[3] = 0x00;    //[2] and [3] means select Match network1
                     message[4] = (int)nValue&0xff;  //nValue: 0=User mode,1=Auto mode,2=Host mode;   nValue=1-10(Desired preset)
                     message[5] = 0x00;
                     message[6] = message[0]^message[1]^message[2]^message[3]^message[4]^message[5];
                 }

                 if (com.cCmdNum == (char)0x70 || com.cCmdNum == (char)0x7A ) // set C1 or C2 position(Channel=2,Channel=3)
                 {
                     message[2] = 0x01;
                     message[3] = 0x00;    //[2] and [3] means select Match network1
                     nTempInt = nValue*10; //nValue = 0-9999 means 0%-99%
                     message[4] = nTempInt&0xff;  //Low 8 bits
                     message[5] = (nTempInt>>8)&0xff;  //High 8 bits
                     message[6] = message[0]^message[1]^message[2]^message[3]^message[4]^message[5];
                 }
             }
             break;

           case 12:   // store
                 //value == ((C1 * 1000) + C2) * 100 + Store-to-position
               message[0] = 0x07 + m_nAddr*8;
              message[2] = 0x08;  // optional length byte, 0x08 means there are 8 bytes in data field.
              message[3] = 0x01;
               message[4] = 0x00;  // [3] and [4] means select Match network1
               message[5] = nValue % 100; // the store-to position (1-10)
               message[6] = 0x00; // trajectory pair 0

               nTempInt = (nValue/100000) * 10;        // get C1 position to preset
               message[7] = nTempInt&0xff;
               message[8] = (nTempInt>>8)&0xff;

               nTempInt = ((nValue/100)%1000) * 10;    // get C2 position to preset
               message[9] = nTempInt&0xff;
               message[10] = (nTempInt>>8)&0xff;

               message[11] = message[0]^message[1]^message[2]^message[3]^message[4]^message[5]^message[6]^message[7]^message[8]^message[9]^message[10];
               break;

           case 16:   // set prior time
              message[0] = 0x07 + m_nAddr*8;
              message[2] = 0x0C; // optional length byte, 0x0C means there are 12 bytes in data field.
              message[3] = 0xD1; // [3] and [4] means sub-command 209
               message[5] = 0x01; // [5] and [6] Fundamental freq : 1
               message[7] = 0x01; // [7] and [8] V Threshold : 1
               message[9] = 0x01; // [9] and [10] I Threshold : 1

               nTempInt = nValue;   //prior time
               message[11] = nTempInt&0xff;
               message[12] = (nTempInt>>8)&0xff;

               message[13] = 0x05; // [13] and [14] Late pulse blanking(future discard) : 5

               message[15] = message[0]^message[1]^message[2]^message[3]^message[5]^message[7]^message[9]^message[11]^message[12]^message[13];
               break;
    }
          
    return(sendCommandAck(message, resp, m_timeOut, com.nResLen+1, com.nCmdLen)); // com.nResLen+1 means [ACK + Response]
}

bool AEDualMatchICP::readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
    Com com = m_commands[nChannelNum];
    int nTempInt;

    memset(resp, 0, RESP_LEN);
    memset(message, 0, MESS_LEN);
    message[0] = (char)(com.nCmdLen-3+8*m_nAddr);
    message[1] = com.cCmdNum;
    if(com.nCmdLen == 5)  //read ControlMode (Channel=6), read C1(Channel=7), read C2(Channel=8),read enable/disable presets(Channel=19)
    {
        message[2] = 0x01;
        message[3] = 0x00;
        message[4] = message[0]^message[1]^message[2]^message[3];
    }
    if(com.nCmdLen == 7) //read prior time (Channel=17)
    {
        message[2] = 0xD1;    //209
        message[4] = 0x01;    //Fundamental frequency (rang= 1,2)
        message[6] = message[0]^message[1]^message[2]^message[4];
    }
    if(nChannelNum == 22)  //read C3 (Channel=22)
    {
        message[2] = 0x00;
        message[3] = message[0]^message[1]^message[2];
    }
    if(nChannelNum == 20)
    {
        message[2] = 0x01;  //report active faults
        message[3] = message[0]^message[1]^message[2];
        getCommandResult(message,com.nCmdLen,resp,com.nResLen+1,m_timeOut);
        *pValue=(int)resp[1] & 0x07;
        if((*pValue)>1 && (*pValue)<7)
        {
            for(int i=3;i<(*pValue)+3;i++)
            {
                //error code
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, Converter::convertToString(i)+":"+Converter::convertToString(((int)resp[i] & 0x00ff)));
            }
        }
        if((*pValue)==7)
        {
            for(int i=4;i<((int)resp[3] & 0x00ff)+4;i++) //resp[0]= ACK; resp[1]= Header; resp[2]= Cmd; resp[3]=Optional length
            {
                //error code
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, Converter::convertToString(i)+":"+Converter::convertToString(((int)resp[i] & 0x00ff)));
            }
        }
        return true;
    }

      if(readCommand(message , resp, m_timeOut, com.nResLen+1, com.nCmdLen)) //Response = Ack + Header + Cmd + Data +CheckSum
      {
          switch(nChannelNum)
          {
               case 6:
                    // read mode (response = 4 Byte)

                       nTempInt = (int)resp[5] & 0xff; // resp[0]= ACK; resp[1]= Header; resp[2]= Cmd;
                       *pValue = nTempInt;
                       break;
               case 7:
                     //read C1 (response = 6 Byte)

                       nTempInt = ((((int)resp[6]&0x00ff)<<8)&0xff00) + ((int)resp[5]&0xff);
                       *pValue = nTempInt/10;
                      break;
               case 8:
                    //read C2 (response = 6 Byte)

                       nTempInt = (((int)(resp[8]&0x00ff)<<8)&0xff00) + ((int)resp[7]&0xff);
                       *pValue = nTempInt/10;
                      break;
              case 17:
                    //read prior time   (response = 8 Byte)
                       nTempInt = (((int)(resp[9]&0x00ff)<<8)&0xff00) + ((int)resp[8]&0xff);
                       *pValue = nTempInt;
                      break;
              case 19:
                     //read enable/disable presets (response = 4 Byte)
                      nTempInt = (((int)(resp[6]&0x00ff)<<8)&0xff00) + ((int)resp[5]&0xff);// resp[0]= ACK; resp[1]= Header; resp[2]= Cmd;
                       *pValue = nTempInt;
                      break;
              case 22:
                     //read C3 (response = 3 Byte)
                       nTempInt = (((int)(resp[5]&0x00ff)<<8)&0xff00) + ((int)resp[4]&0xff); // resp[0]= ACK; resp[1]= Header; resp[2]= Cmd; resp[3]= 0x00;
                       *pValue = nTempInt/10;
                      break;
          }
          return true;
      }
    return false;
}
bool AEDualMatchICP::readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo)
{
    Com com = m_commands[nChannelNum];
    memset(resp, 0, RESP_LEN);
    int nTempInt = 0;
    if(com.nCmdLen == 3)   // Command 219, no data field.
    {
        memset(message, 0, 3);
        message[0] = (char)(com.nCmdLen-3+8*m_nAddr);
        message[1] = com.cCmdNum;
        message[2] = message[0]^message[1];
    }
    if((com.nCmdLen == 4)&&(com.nResLen == 10))   // Command 165,1-byte data field
    {
        memset(message, 0, 4);
        message[0] = (char)(com.nCmdLen-3+8*m_nAddr);
        message[1] = com.cCmdNum;
        message[2] = 0x14;
        message[3] = message[0]^message[1]^message[2];
    }
    if((com.nCmdLen == 4)&&(com.nResLen == 8))   // Command 165,1-byte data field
    {
        memset(message, 0, 4);
        message[0] = (char)(com.nCmdLen-3+8*m_nAddr);
        message[1] = com.cCmdNum;
        message[2] = 0x16;
        message[3] = message[0]^message[1]^message[2];
    }

    if(com.nCmdLen == 7)   // Command 248-201/206, 4-byte data field. //using
    {
        memset(message, 0, 7);
        message[0] = (char)(com.nCmdLen-3+8*m_nAddr);
        message[1] = com.cCmdNum;
        message[2] = 0xCE;    //206
        message[4] = 0x01;
        message[6] = message[0]^message[1]^message[2]^message[4];
    }
    if(com.nCmdLen == 5)   // Command 248-29/10, 2-byte data field.
    {
        memset(message, 0, 5);
        message[0] = (char)(com.nCmdLen-3+8*m_nAddr);
        message[1] = com.cCmdNum;
        message[2] = 0x0A;    //10
        message[4] = message[0]^message[1]^message[2];
    }
    if(readCommand(message , resp, m_timeOut, com.nResLen+1, com.nCmdLen))
      {
          switch(nChannelNum)
          {
              case 9:
              {
            // read VDC
            nTempInt = (((int)(resp[27]&0x00ff)<<8)&0xff00) + ((int)resp[26]&0xff);  //248-201/206

            if(0 == nTempInt)
            {
                *pValue = 0;
            }
            else
            {
                int nSign = (nTempInt>>15)&0x01;

                int nIndex = (nTempInt>>7)&0xFF;
                nIndex -= 127;

                int nNumaftpt = ((nTempInt&0x7F)<<8) + ((int)resp[25]&0xff);
                nNumaftpt = nNumaftpt|0x8000;
                if(nIndex >=0)
                {
                    *pValue = (nNumaftpt>>(15-nIndex)) + ((nNumaftpt>>(14-nIndex))&0x01)*0.5 ;

                }
                else if(-1 == nIndex)
                {
                    *pValue = 0.5 + ((nNumaftpt>>14)&0x01)*0.25;
                }
                else
                {
                    *pValue = 0.25;
                }

                    *pValue *= 1.414;
                    if(nSign == 1)
                    {
                        *pValue = *pValue * (-1);
                    }
                }
                 break;
              }

            case 10: // read I-out (A)
            {
                nTempInt = (((int)(resp[31]&0x00ff)<<24)&0xff000000) + (((int)(resp[30]&0x00ff)<<16)&0xff0000)
                    + (((int)(resp[29]&0x00ff)<<8)&0xff00) + ((int)resp[28]&0xff);  //248-201/206  7th 4-Byte

                *pValue = realToDouble((long)nTempInt);
                break;
            }

            case 11:  //read V-out (V)
            {
                nTempInt = (((int)(resp[27]&0x00ff)<<24)&0xff000000) + (((int)(resp[26]&0x00ff)<<16)&0xff0000)
                    + (((int)(resp[25]&0x00ff)<<8)&0xff00) + ((int)resp[24]&0xff);  //248-201/206  6th 4-Byte

                *pValue = realToDouble((long)nTempInt);
                break;
            }

            case 12:  //read R
            {
                nTempInt = (((int)(resp[19]&0x00ff)<<24)&0xff000000) + (((int)(resp[18]&0x00ff)<<16)&0xff0000)
                    + (((int)(resp[17]&0x00ff)<<8)&0xff00) + ((int)resp[16]&0xff);  //248-201/206  4th 4-Byte

                *pValue = realToDouble((long)nTempInt);
                break;
            }

            case 13:  //read X
            {
                nTempInt = (((int)(resp[23]&0x00ff)<<24)&0xff000000) + (((int)(resp[22]&0x00ff)<<16)&0xff0000)
                    + (((int)(resp[21]&0x00ff)<<8)&0xff00) + ((int)resp[20]&0xff);  //248-201/206  5th 4-Byte

                *pValue = realToDouble((long)nTempInt);
                break;
            }

            case 14:  //read outPhase
            {
                nTempInt = (((int)(resp[11]&0x00ff)<<24)&0xff000000) + (((int)(resp[10]&0x00ff)<<16)&0xff0000)
                    + (((int)(resp[9]&0x00ff)<<8)&0xff00) + ((int)resp[8]&0xff);  //248-201/206  2nd 4-Byte

                *pValue = realToDouble((long)nTempInt);
                break;
            }
           case 23:
           {
                   nTempInt = ((((int)resp[5]&0x00ff)<<8)&0xff00) + ((int)resp[4]&0xff);

                   *pValue = nTempInt;
                   break;

           }
           case 24:
           {
                   nTempInt = ((((int)resp[7]&0x00ff)<<8)&0xff00) + ((int)resp[6]&0xff);

                   *pValue = nTempInt/100.0;
                   break;
           }
           case 25:
           {
                   nTempInt = ((((int)resp[9]&0x00ff)<<8)&0xff00) + ((int)resp[8]&0xff);

                   *pValue = nTempInt/100.0;
                   break;
           }
           case 26:
           {
                   nTempInt = ((((int)resp[5]&0x00ff)<<8)&0xff00) + ((int)resp[4]&0xff);

                   *pValue = nTempInt;
                   break;
           }
           case 27:
           {
                   nTempInt = ((((int)resp[7]&0x00ff)<<8)&0xff00) + ((int)resp[6]&0xff);

                   *pValue = nTempInt;
                   break;
           }

          }// switch over

          return true;

      }
    return false;
}

double AEDualMatchICP::realToDouble(long nValue)
{
    unsigned long m = (nValue & 0x7fffff) | 0x800000;
    int e = (nValue >> 23) & 0xff;
    int s = (nValue >> 31) & 0x01;
    double res = 0;
    int mi = 0;
    for(int i=0; i<24; ++i)
    {
        mi = (m >> i) & 0x01;
        if(mi == 1)
        {
            res += pow((double)(mi*2), (int)(e-127+i-23));
        }
    }
    return res*pow(-1.0, (int)s);
}

void AEDualMatchICP::InitChannels(DeviceNode<AEDualMatchICP> *pNode)
{   
    //node->registerReadCh(0, &SerialDevice::connectStatus);
    for(int i = 1; i <= 5; ++i)
    {
        pNode->registerWriteCh(i, &AEDualMatchICP::writeInt);
    }
    for(int i = 6; i <= 8; ++i)
    {
        pNode->registerReadCh(i, &AEDualMatchICP::readInt);
    }
    for(int i = 9; i <= 14; ++i)
    {
        pNode->registerReadCh(i, &AEDualMatchICP::readDouble);
    }
    pNode->registerWriteCh(15, &AEDualMatchICP::writeInt);//set Reset
    pNode->registerWriteCh(16, &AEDualMatchICP::writeInt);//set prior time
    pNode->registerReadCh(17, &AEDualMatchICP::readInt); //read prior time
    pNode->registerWriteCh(18, &AEDualMatchICP::writeInt);//set enable/disable presets
    pNode->registerReadCh(19, &AEDualMatchICP::readInt); //read enable/disable presets
    pNode->registerReadCh(20, &AEDualMatchICP::readInt); //read Match status or fault
    pNode->registerWriteCh(21, &AEDualMatchICP::writeInt);//set C3 position
    pNode->registerReadCh(22, &AEDualMatchICP::readInt); //read C3 position
    for(int i = 23; i <= 27; ++i)
    {
        pNode->registerReadCh(i, &AEDualMatchICP::readDouble);
    }
}
  
void AEDualMatchICP::init()
{
    cout<<"AEDualMatchICP init start"<<endl;
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "AEDualMatchICP start");

    DeviceNode<AEDualMatchICP> *pNode = new DeviceNode<AEDualMatchICP>(200,this);
    InitChannels(pNode);
    DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
    
    cout<<"AEDualMatchICP end start"<<endl;
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "AEDualMatchICP end");
}

void AEDualMatchICP::setAddress(int nAddr)
{
   if(nAddr > 0)
    {
        m_nAddr = nAddr;
    }
   else
    {
        cout<<"***  AEDualMatchICP addr config error, Set address to 1."<<endl;
        m_nAddr = 1;
       }
}

IMPLEMENT_DYNAMIC(AEDualMatchICP, SerialDevice )
BEGIN_MSG_MAP(AEDualMatchICP, SerialDevice )
    SET_V( init, AEDualMatchICP )
    SET_I( setAddress, AEDualMatchICP )
END_MSG_MAP

