/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					Jan 22, 2008  shenql  create 
**      
***************************************************************************/
#ifndef SLOTSENSORINFO_H_
#define SLOTSENSORINFO_H_
#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class SlotSensorInfo : public IntValueInfo
{
public:

		static const int UnInit = -1;
		static const int Unknown = 0;
		static const int Opened = 1;
		static const int Closed = 2;
		static const int Error = 3;
		static const int None = 4;
		
		static const IntTypeInfo typeInfo;

	   SlotSensorInfo():IntValueInfo(-1, typeInfo)
	   {
	   }
	
	   SlotSensorInfo(int i):IntValueInfo(i, typeInfo)
	    {
	    }
	
	   SlotSensorInfo(std::string s):IntValueInfo(s, typeInfo)
	    {
	    }
};



#endif /*SLOTSENSORINFO_H_*/
