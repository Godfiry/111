/*
 * FiberLaserCheyitianA500.h
 *
 *  Created on: 20240514
 *      Author: chenshicun
 *      Also applicable to Changchunxinchanye OEM-I-405-LE-500mW-GC31392
 */

#ifndef SRC_DEVICEACCESSOR_FIBERLASERCHEYITIANA500_H_
#define SRC_DEVICEACCESSOR_FIBERLASERCHEYITIANA500_H_
#include <string>
#include "SerialDevice.h"
#include "ControlObject.h"
#include "ReadWriteInt.h"
#include "ReadOnlyInt.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#include "DeviceNode.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CONTROL;
using namespace IAP::IO;
#endif

class FiberLaserCheyitianA500 : public SerialDevice
{
	DECLARE_DYNAMIC(FiberLaserCheyitianA500)
	DECLARE_MSG_MAP

	public:
		FiberLaserCheyitianA500();
		virtual ~FiberLaserCheyitianA500();

		bool writeDouble(int nChannelNum, double dValue,const DoubleTypeInfo &typeInfo);
		bool writeInt(int nChannelNum, int nValue,const IntTypeInfo &typeInfo);
		bool requestInt(int nChannelNum, int *pValue,const IntTypeInfo &typeInfo);
		bool readDouble(int nChannelNum, double *pValue,const DoubleTypeInfo &typeInfo);

		void init();

	protected:
	    void initDevice();
	    void initChs(DeviceNode<FiberLaserCheyitianA500>* pNode);
	    void refreshCh();

	private:
	    int m_nTimeOut;
		int m_nResLen;

	    char m_writeCmd[10];   //read command array

	    double m_dPower1;
	    double m_dPower2;


};


#endif /* SRC_DEVICEACCESSOR_FIBERLASERCHEYITIANA500_H_ */
