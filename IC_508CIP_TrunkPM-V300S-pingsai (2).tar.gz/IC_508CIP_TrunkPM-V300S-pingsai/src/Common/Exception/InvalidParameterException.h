#ifndef INVALIDPARAMETEREXCEPTION_H_
#define INVALIDPARAMETEREXCEPTION_H_
#include "TMCException.h"

class InvalidParameterException : public TMCException
{
    public:
		InvalidParameterException(const std::string &err) : TMCException(err) {}
};
#endif /*INVALIDPARAMETEREXCEPTION_H_*/
