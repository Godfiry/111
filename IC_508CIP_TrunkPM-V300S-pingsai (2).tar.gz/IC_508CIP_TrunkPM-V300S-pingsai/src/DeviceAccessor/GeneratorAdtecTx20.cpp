/********************************************************************
** Copyright (c) 2020, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: GeneratorAdtecTx20.cpp
** Description:
** Release: 1.1
** Modification history:
**                     2020-2-5   zhangyy create
**
*********************************************************************/

#include "GeneratorAdtecTx20.h"
#include "DeviceManager.h"
#include "ObjectManager.h"
#include "Converter.h"
#include <iostream>
#include <sys/time.h>
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "NoDescriptorException.h"
#endif
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std;

GeneratorAdtecTx20::Cmd GeneratorAdtecTx20::m_commands[] = {
        {0, "S", 0     },   // 0. Stop RF power output    #IO=0
        {0, "G", 0     },   // 1. Start RF power output
        {0, "RESET",  0},   // 2. Reset Generator alarm status #IO=2
        {0, "VFOFF", 0},    //3.Switch VF Function ON    #IO=3
        {0, "VFON", 0},        //4.Switch VF Function OFF
        {0, "VSD-", 0},        //5.Switch the direction of operating start of CHASING STATE to increase [START DIR] #IO=5
        {0, "VSD+", 0},        //6.Switch the direction of operating start of CHASING STATE to decrease [START DIR]
        {2, " W", 0},        //7.Set RF POWER-SETPOINT 0 - 2000W, 1W default:0 #IO=7
        {1, "VIF", 0},        //8.Set Frequency of IGNITE STATE at START [START F] 25620 �C 28120,10, default:27120 #IO=8
        {1, "VCS", 0},        //9.Set start frequency of CHASING STATE [CHASE F S] 25620 - 28120,10, default:27120 #IO=9
};

GeneratorAdtecTx20::ReadCmd GeneratorAdtecTx20::m_readCommands[] = {
        {"Q", 14, 5, 33, 14, DescriptorList("NULL") },//200.Request forward power,  F1F2F3F4F5, substr(14,5)
        {"Q", 20, 5, 33, 14, DescriptorList("NULL")},//201.Request reflectd power, R1R2R3R4R5, substr(20,5)
        {"Q", 0,  1, 33, 14, DescriptorList("NULL") },//202.Request control mode, M(0:Manual Mode; 1:Analog Mode; 2:RS232C Mode), substr(0,1)
        {"Q", 2,  1, 33, 14, DescriptorList("NULL")},//203.Request RF output Status, K(0:RF OFF; 1:RF ON), substr(2,1)
        {"Q", 5,  2, 33, 14, DescriptorList("NULL")}, //204.Request Alarm Status, A1A2(00:No Alarm; 01~99: Different Alarm), substr(5,2)
        {"VF", 11,  -1, -1, -1, DescriptorList("OFF,ON")}, //205.Check VF Function  VF_CONTROL_ON/OFF
        {"VSD", 18,  -1, -1, -1, DescriptorList("-,+")},//206.Check the direction of operation start of CHASING STATE CHASING_START_DIR_+/-
        {"VPR", 12,  5, 64, -1, DescriptorList("NULL")},//207.get Frequency of IGNITE STATE at START
        {"VPR", 39,  5, 64, -1, DescriptorList("NULL")},//208.get Operating Frequency of CHASING STATE
};

GeneratorAdtecTx20::GeneratorAdtecTx20():SerialDevice(200, "\x0D")
{
    //m_timeOut = 20;//20s, m_timeOut = 10 in SerialDevice
    m_nReadTimeOut = 10;//1s
    m_strErrorCode = "";
    m_strRFStatus = "";
    m_strRFMode = "";

}

GeneratorAdtecTx20::~GeneratorAdtecTx20()
{

}

bool GeneratorAdtecTx20::sendCommand(const std::string &strCommand)
{
    //usleep(200000);
    string strResult = getCommandResult(strCommand,m_timeOut);
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "AdtecGenerator send "+strCommand+" get Result =" + strResult);
    if(strCommand == "RESET" && strResult.find("Really?") != string::npos)
    {
        sendCommandOnly("Y"); //Ensure Reset command, send Y
        return true;
    }
    else if(strResult.find("\x0D",0) != string::npos)
    {
        if(strResult.find("N",0)!= string::npos)
        {
            throw IOException(getDeviceName() + ": send " +strCommand +" incorrect or command cannot be processed");
        }
    }
    else
    {
        throw IOException(getDeviceName() + ": send " +strCommand +" get unknown readback:" + strResult);
    }
    return true;
}

bool GeneratorAdtecTx20::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
    Cmd cmd = m_commands[nChannelNum];
    string strMsg = cmd.strCmd;
    int nType = cmd.nType;
    int nTemp = 0;
    if(m_strRFMode != "2") //2 means RS232C Mode
    {
        //For Adtec can't be controlled in other mode except RS232C
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "AdtecGenerator change RS232C mode before send command.");
        sendCommand("RS232C"); //Change RS232C mode
    }
    if(nType == 0)
    {
        strMsg = m_commands[nChannelNum + nValue].strCmd;
        requestInt(203,&nTemp,IntTypeInfo());  //added by taohao[1.8.0] for power on/off failed
        if((strMsg == "S" && m_strRFStatus == "0") || (strMsg == "G" && m_strRFStatus == "1"))//0 means RF-OFF, 1 means RF-ON
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "AdtecGenerator don't need start/stop due to already satisfied! ");
            return true;
        }
    }
    else if(nType == 1)
    {
        strMsg = m_commands[nChannelNum].strCmd + Converter::convertToString(nValue);
    }
    else if(nType == 2)
    {
        strMsg = Converter::convertToString(nValue) + m_commands[nChannelNum].strCmd;
    }

    return sendCommand(strMsg); //For Reset command
}

bool GeneratorAdtecTx20::writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
    Cmd cmd = m_commands[nChannelNum];
    string strMsg = "";
    if(m_strRFMode != "2")//2 means RS232C Mode
    {
        //For Adtec can't be controlled in other mode except RS232C
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "AdtecGenerator change RS232C mode before send command.");
        sendCommand("RS232C"); //Change RS232C mode
    }
    int nValue = (int)(dValue*1); //For 02995 means 299.5W
    char Format[6]={0};
    sprintf(Format,"%d",nValue);
    //strMsg = " " +cmd.strCmd;
    strMsg = Format + cmd.strCmd;
    return sendCommand(strMsg);
}

bool GeneratorAdtecTx20::writeRawCommand(int nChannelNum, std::string strValue, const StringTypeInfo &typeInfo)
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "AdtecGenerator send command = "+strValue);
    return sendCommand(strValue);
}

bool GeneratorAdtecTx20::requestInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
    //usleep(100000);
    ReadCmd readCmd = m_readCommands[nChannelNum - 200];
    string strRequestCmd = readCmd.strCmd;
    int nReadBack = 0;
    if(strRequestCmd == "Q")
    {
        std::string strRawResult = getFixCommandResult(strRequestCmd, m_nReadTimeOut, readCmd.nCorrectResponseLen, readCmd.nRetryTime);
        //cout<<"Send Q command get result =  "<<strRawResult<<endl;
        if(strRawResult.find("\x0D\x0D",0) != string::npos)
        {
            std::string strReadBack = strRawResult.substr(readCmd.nSubStartPos,readCmd.nSubLength);
            m_strRFStatus = strRawResult.substr(2,1);// Get current RF ON/OFF Status
            m_strRFMode = strRawResult.substr(0,1);// Get current RF Control Mode
            if(!Converter::stringToInt(nReadBack, strReadBack))//convert string to int using Converter
            {
                throw IOException("read_back value is not a valid int value:" + strReadBack);
            }

            if(nChannelNum == 204)
            {
                if(nReadBack == 0)
                {
                    *pValue = 0; // No Alarm
                }
                else
                {
                    *pValue = 1; //Has Alarm
                    m_strErrorCode = strReadBack; // Get Error Code
                    //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "AdtecGenerator post Error code =" + m_strErrorCode);
                }
            }
            else
            {
                *pValue = nReadBack;
            }
            return true;
        }
        else
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "GeneratorAdtecTx20 send "+strRequestCmd +" again.");
            std::string strRawResultAgain = getFixCommandResult(strRequestCmd, m_nReadTimeOut, readCmd.nCorrectResponseLen, readCmd.nRetryTime);
            if(strRawResultAgain.find("\x0D\x0D",0) != string::npos)
            {
                std::string strReadBackAgain = strRawResultAgain.substr(readCmd.nSubStartPos,readCmd.nSubLength);
                m_strRFStatus = strRawResultAgain.substr(2,1);// Get current RF ON/OFF Status again
                m_strRFMode = strRawResultAgain.substr(0,1);// Get current RF Control Mode again
                if(!Converter::stringToInt(nReadBack, strReadBackAgain))//convert string to int using Converter
                {
                    throw IOException("read_back value is not a valid int value:" + strReadBackAgain);
                }
                if(nChannelNum == 204)
                {
                    if(nReadBack == 0)
                    {
                        *pValue = 0; // No Alarm
                    }
                    else
                    {
                        *pValue = 1; //Has Alarm
                        m_strErrorCode = strReadBackAgain; // Get Error Code
                        //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "AdtecGenerator post Error code =" + m_strErrorCode);
                    }
                }
                else
                {
                    *pValue = nReadBack;
                }
                return true;
            }
            else
            {
                throw IOException("Send read command = "+strRequestCmd +", Unknown read back : " + strRawResultAgain);
            }
        }
    }
    else if(strRequestCmd == "VF" || strRequestCmd == "VSD")
    {
        std::string strRawResult = getCommandResult(strRequestCmd, m_nReadTimeOut);
        if(strRawResult.find("\x0D",0) != string::npos)
        {
            string strSubResult = strRawResult.substr(readCmd.nSubStartPos,readCmd.nSubLength);
            try
            {
                cout<<readCmd.Descriptor.getDescriptorValue(strSubResult)<<endl;
                *pValue = readCmd.Descriptor.getDescriptorValue(strSubResult);
            }
            catch(NoDescriptorException ex)
            {
                throw IOException("Send read command = "+strRequestCmd +", raw data: "+strRawResult+", parser result: " + strSubResult);
            }
            return true;
        }
        else
        {
            throw IOException("Send read command = "+strRequestCmd +", Unknown read back : " + strRawResult);
        }
    }
    else if(strRequestCmd == "VPR")
    {
        std::string strRawResult = getFixCommandResult(strRequestCmd, m_nReadTimeOut, readCmd.nCorrectResponseLen, readCmd.nRetryTime);
        //cout<<"Send Q command get result =  "<<strRawResult<<endl;
        if(strRawResult.find("\x0D\x0D",0) != string::npos)
        {
            std::string strReadBack = strRawResult.substr(readCmd.nSubStartPos,readCmd.nSubLength);
            if(!Converter::stringToInt(nReadBack, strReadBack))//convert string to int using Converter
            {
                throw IOException("read_back value is not a valid int value:" + strReadBack);
            }
            *pValue = nReadBack;
            return true;
        }
        else
        {
            throw IOException("Send read command = "+strRequestCmd +", Unknown read back : " + strRawResult);
        }
    }
}

bool GeneratorAdtecTx20::requestDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo)
{
    //usleep(100000);
    ReadCmd readCmd = m_readCommands[nChannelNum - 200];
    string strRequestCmd = readCmd.strCmd;
    double dReadBack;
    if(strRequestCmd == "Q")
    {
        std::string strReadBack = getFixCommandResult(strRequestCmd, m_nReadTimeOut, readCmd.nCorrectResponseLen, readCmd.nRetryTime);

        if(strReadBack.find("\x0D\x0D",0) != string::npos)
        {
            strReadBack = strReadBack.substr(readCmd.nSubStartPos,readCmd.nSubLength);
            if(!Converter::stringToDouble(dReadBack, strReadBack))//convert string to double using Converter
            {
                throw IOException("read_back value is not a valid double value:" + strReadBack);
            }
            //cout<<"dReadBack = "<<dReadBack<<endl;
            *pValue = dReadBack;//changed by wzd 20220402
            return true;
        }
        else
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "GeneratorAdtecTx20 send "+strRequestCmd +" again.");
            std::string strReadBackAgain = getFixCommandResult(strRequestCmd, m_nReadTimeOut, readCmd.nCorrectResponseLen, readCmd.nRetryTime);
            if(strReadBackAgain.find("\x0D\x0D",0) != string::npos)
            {
                strReadBackAgain = strReadBackAgain.substr(readCmd.nSubStartPos,readCmd.nSubLength);
                if(!Converter::stringToDouble(dReadBack, strReadBackAgain))//convert string to double using Converter
                {
                    throw IOException("read_back value is not a valid double value:" + strReadBackAgain);
                }
                else
                {
                    *pValue = dReadBack;//changed by wzd 20220402
                    return true;
                }
            }
            else
            {
                throw IOException("Send read command = "+strRequestCmd +", Unknown read back : " + strReadBackAgain);
            }
        }
    }
}

bool GeneratorAdtecTx20::getErrorCode(int nChannelNum, std::string *pValue, const StringTypeInfo &typeInfo)
{
    *pValue = m_strErrorCode;
    return true;
}

void GeneratorAdtecTx20::InitChannels(DeviceNode<GeneratorAdtecTx20> *pNode)
{
    for(int i=0; i<= 6; ++i)
    {
        pNode->registerWriteCh(i,&GeneratorAdtecTx20::writeInt);
    }
    pNode->registerWriteCh(7,&GeneratorAdtecTx20::writeDouble);
    for(int i=8; i<= 15; ++i)
    {
        pNode->registerWriteCh(i,&GeneratorAdtecTx20::writeInt);
    }

    for(int i=200; i<= 201; ++i)
    {
        pNode->registerReadCh(i,&GeneratorAdtecTx20::requestDouble);
    }
    for(int i=202; i<= 210; ++i)
    {
        pNode->registerReadCh(i,&GeneratorAdtecTx20::requestInt);
    }
    //pNode->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &GeneratorAdtecTx20::getStatus);//added by mujy [v1.0.8]
    pNode->registerWriteCh(1001, &GeneratorAdtecTx20::writeRawCommand);
    pNode->registerReadCh(1002, &GeneratorAdtecTx20::getErrorCode);
}
void GeneratorAdtecTx20::initDevice()
{

    cout<<"start scan GeneratorAdtecTx20..."<<endl;
    int *pValue=new int;//added by dingjie[1.1.30]
    try
    {
        const IntTypeInfo typeInfo;
        requestInt(202, pValue,typeInfo);
        if(m_strRFMode != "2")//2 means RS232C Mode
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "AdtecGenerator is not in RS232C mode.");
            sendCommand("RS232C"); //Change RS232C mode
            requestInt(202, pValue,typeInfo);
        }
        else
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "AdtecGenerator is already in RS232C mode.");
        }
        delete pValue;
        pValue=NULL;

    }
    catch(exception &ex)
    {
        if(pValue!=NULL)
        {
            delete pValue;
            pValue=NULL;
        }
        cout<<"Scan GeneratorAdtecTx20 failed. Communication abnormal!"<<endl;
        throw;
    }
    cout<<"scan GeneratorAdtecTx20 successfully."<<endl;
}

void GeneratorAdtecTx20::init()
{
    DeviceNode<GeneratorAdtecTx20> *pNode = new DeviceNode<GeneratorAdtecTx20>(m_pollPeriod,this);
    DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
    if(!isSimulated())
       {
           InitChannels(pNode);
           initDevice();
    }
}

string GeneratorAdtecTx20::getDeviceName()
{
    return __FILE__;
}

IMPLEMENT_DYNAMIC(GeneratorAdtecTx20, SerialDevice )
BEGIN_MSG_MAP(GeneratorAdtecTx20, SerialDevice )
    SET_V( init, GeneratorAdtecTx20 )
END_MSG_MAP
