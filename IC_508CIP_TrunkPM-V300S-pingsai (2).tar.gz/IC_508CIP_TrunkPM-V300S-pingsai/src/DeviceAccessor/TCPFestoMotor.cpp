/********************************************************************
** Copyright (c) 2021, Beijing NAURA Co.,Ltd.  All rights reserved.
** File name: TCPFestoMotor.h
** Description:Festo CMMT Servo Drive communication through Modbus TCP Protocol
** Release: 1.1
** Modification history:
**                  2021-5-14   zhangyy create
**
*********************************************************************/
#include "TCPFestoMotor.h"

#include "DeviceManager.h"
#include "Converter.h"
#ifdef IAP4_0
#include "ITime.h"
#else
#include "Time.h"
#endif
#include "UTime.h"
#include "Hex.h"
#include "ObjectManager.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "InvalidNameException.h"
#endif
#include <sys/time.h>
#include <string.h>
//#include <math.h>
#include <cmath>
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;


TCPFestoMotor::TCPFestoMotor()
{
    m_dPinUpPosition = 17;
    m_dPinDownPosition = 0;
    m_dUpPositionTol = 0.05;
    m_dDownPositionTol = 0.05;
    m_bConfigMotorPositionInSetup = false;
    m_pCfgMotorPinUpPosition = NULL;
    m_pCfgMotorPinDownPosition = NULL;

    m_nPinUpTimeOut = 7000;//ms
    m_nPinDownTimeOut = 3000;//ms

    m_dRecord2Position = 4;
    m_dRecord3Position = 8;
    m_dRecord4Position = 17;
    m_nPrint = 0;

    bzero(m_modbusSend, sizeof(m_modbusSend));//set 0

    m_nPositioningRecord = 0;
    m_nTransactionId = 1;//Original m_nTransactionId = 1, m_nTransactionId++ after each communication

    m_nModbusTimeOut = 1000;
    m_nModbusTimeOutCurrent = 0;
    m_bReadCmd = false;
    m_bExecuteRecordFlag = false;
    m_nFinishPositionRecord = 0;
    m_strResult = "";

    m_dTargetPosition = 0;//0 mm
    m_dTargetVelocity = 0.004;// 0.004 m/s

    m_dAcceleration = 100;//100% of reference value, base value acceleration
    m_dDeceleration = 100;//100% of reference value, base value acceleration
    m_dOverride = 100;//default = 100

    m_dConvertPositionOutput = 1000;//ActualPosition = 9999*10^-6 m = 0.009999m = 9.999mm
    m_ConvertVelocityOutput = 1000;//ActualVelocity = 400*10^-3 m/s = 0.4 m/s

    m_ConvertPositionInput = 1000000; //ActualPosition = 9999*10^-6 m = 0.009999m = 9.999mm
    m_ConvertVelocityInput = 200000000;//Depend on base value velocity = 5 m/s

    //Telegram 111 WriteCommand contain following 11 word
    nSTW1 = 0; // 0
    nPOS_STW1 = 0;
    nPOS_STW2 = 0;
    STW2 = 0;
    nOverride = 16384;
    nMDI_TarPos1 = 0;
    nMDI_TarPos2 = 0;
    nMDI_Velocity1 = 0;
    nMDI_Velocity2 = 0;
    nMDI_ACC = 0;
    nMDI_DEC = 0; //10

    //Telegram 111 ReadCommand contain following 11 word
    nZSW1 = 0; // 0
    nPOS_ZSW1 = 0;
    nPOS_ZSW2 = 0;
    nZSW2 = 0;
    nMELDW = 0;
    nXIST_A1 = 0;
    nXIST_A2 = 0;
    nIST_B1 = 0;
    nIST_B2 = 0;
    nFault_Code = 0;
    nWarn_Code = 0; //10

    m_fTorque = 0;//[zhangcx v1.1.65_HotFix5]
    fPositionControlError = 0;
    m_dPositionControlError = 0;
    //fAccelerate = 0;
    //fCurrent = 0;
    m_fTemperature = 0;//[zhangcx v1.1.65_HotFix5]

    //nSTW1 word contain following 13 Bits
    m_bOutputStageEnable = false;// Bit 0,false = OutputStage disable, true = OutputStage enable
    m_bDriveCoast = true;// Bit 1,false = costing, true = no coast
    m_bFastStop = true;// Bit 2,false = FastStop, true = No FastStop
    m_bEnableOperation = true;// Bit 3,false = block, true = Enable Operation
    m_bRampGenerator = false; // Bit 4
    m_bRejectPositioningTask = false; //Bit 4, use this,false = active, true = inactive
    m_bStartRampGenerator = false;// Bit 5
    m_bIntermediateStop = false;// Bit 5, use this,false = active, true = inactive
    m_bRotationalSpeedSetPoint = false;// Bit 6
    m_bActivatePositioningTask = false;// Bit 6, use this,false = inactive, true = active
    m_bAcknowledgeMalfunction = false;// Bit 7,false = inactive, true = active
    m_bJogging1 = false;// Bit 8,false = inactive, true = active
    m_bJogging2 = false;// Bit 9,false = inactive, true = active
    m_bPLCMasterControl = true;// Bit 10,false = Local, true = Remote
    m_bInvertSetPointValue = false;// Bit 11
    m_bStartHoming = false;// Bit 11, use this,false = inactive, true = active
    m_bReleaseHoldingBrake = false;// Bit 12,false = inactive, true = active
    m_bStartRecordChange = false;// Bit 13,false = inactive, true = active

    //nPOS_STW1 word contain following Bits
    m_bPositioningRecordSelectionBit0  = false;
    m_bPositioningRecordSelectionBit1  = false;
    m_bPositioningRecordSelectionBit2  = false;
    m_bPositioningRecordSelectionBit3  = false;
    m_bPositioningRecordSelectionBit4  = false;
    m_bPositioningRecordSelectionBit5  = false;
    m_bPositioningRecordSelectionBit6  = false;
    m_bRelativePositioning  = false; //Bit8, false = relative, true = absolute
    m_bAbsolutePositioning  = false;
    m_bMDISelection  = false; //false = deactivate MDI, true = activate MDI

    //nPOS_STW2 word contain following Bit
    m_bActivateSoftwareLimitSwitch = true; // bit 14: 1=active, 0=deactive
    m_bActivateHardwareLimitSwitch = true;// bit 15: 1=active, 0=deactive


    //nZSW1 word contain following 16 Bits
    m_bReadytobeSwitchOn = false;//false = inactive, true = active
    m_bReadyforOperation = false;//false = inactive, true = active
    m_bOperationEnabled = false;//false = inactive, true = active
    m_bMalfunctionEffective = false;//false = inactive, true = active
    m_bCoastingActive = false;//false = active, true = inactive
    m_bFastStopActive = false;//false = active, true = inactive
    m_bSwitchOnLockActive = false;//false = inactive, true = active
    m_bWarningEffective = false;//false = inactive, true = active
    m_bVelocityInRange = false;//false = inactive, true = active
    m_bPositionInRange = false;//false = inactive, true = active
    m_bGuideRequired = false; //false = inactive, true = active
    m_bVelocityComparisonValueReached = false;
    m_bTargetPositionReached = false;// m_bTargetPositionReached,false = inactive, true = active
    m_bIMPLimitNotReached = false;
    m_bReferencePointSet = false;
    m_bHoldingBrakeReleased = false;
    m_bPositioningTaskActivated = false;
    m_bNoWarningifMotorOvertemperature = false;
    m_bDriveisStationary = false;
    m_bMotorDirectionofRotation = false;
    m_bAxisAccelerated = false;
    m_bNoPowerUnitOvertemperatureWarning = false;
    m_bDriveDecelerated = false;

    /**********nPOS_ZSW1***From Bit 0 to Bit 15******************/
    m_bActivePositioningRecordBit0 = false;
    m_bActivePositioningRecordBit1 = false;
    m_bActivePositioningRecordBit2 = false;
    m_bActivePositioningRecordBit3 = false;
    m_bActivePositioningRecordBit4 = false;
    m_bActivePositioningRecordBit5 = false;
    m_bActivePositioningRecordBit6 = false;
    m_bActivePositioningRecord = false;
    m_bNegativeLimitSwitchActive = false;
    m_bPositiveLimitSwitchActive = false;
    m_bJoggingActive = false;
    m_bHomingActive = false;
    m_bPositioningRecordActive = false;
    m_bMDIActive = false;

    /**********nPOS_ZSW2***From Bit 0 to Bit 15******************/
    m_bTrackingModeActive = false;
    m_bVelocityLimitingActive = false;
    m_bSetPointValueStopped = false;
    m_bDriveTravelsForward = false;
    m_bDriveTravelsBackward = false;
    m_bNegativeSoftwareLimitSwitchActive = false;
    m_bPositiveSoftwareLimitSwitchActive = false;
    m_bActualPositionLessEqualThanCamSwitch0 = false;
    m_bActualPositionLessEqualThanCamSwitch1 = false;
    m_bDirectOutput1ViaPositioningRecord = false;
    m_bDirectOutput2ViaPositioningRecord = false;
    m_bFixedStopReached = false;
    m_bFixedStopClampingTorqueReached = false;
    m_bTravelToFixedStopActive = false;
    m_bPositionCommandActive = false;
        m_strPinupConfigName = "";
        m_strPindownConfigName = "";//added by liusy[1.1.57]
    
    m_nAdditionalDataMode = 1;//[zhangcx v1.1.65_HotFix5]
}

TCPFestoMotor::~TCPFestoMotor()
{

}
void TCPFestoMotor::queryWriteMultipleRegister()
{
   //1. Send modbus cmd to Servo Motor
   //region Data to send
   //Data to send for write multiple register
   //0  1   2  3   4  5   6   7   8  9   10 11 12 13 14
   //XX 01  00 00  00 1F  FF  10  00 00  XX XX XX XX XX ..
   //Tid    Pid    Len    id  fn  offst  #reg  ln data

   //Tid   --> 00 01 auto increment
   //Pid   --> 00 00
   //Len   --> 00 06
   //id    --> FF
   //fn    --> 10    --> function code 16
   //offst --> 00 00
   //#reg  --> 00 0C (for basic)
   //ln    --> 18 --> (for basic) 24 byte to send
   //data  --> 24 bytes

    m_modbusSend[0] = (unsigned char)((m_nTransactionId & 0xff00) >> 8); //High byte of Tid, m_nTransactionId is variable
    m_modbusSend[1] = (unsigned char)(m_nTransactionId & 0x00ff); //Low byte of Tid, m_nTransactionId is variable

    m_modbusSend[2] = 0x00; //Pid
    m_modbusSend[3] = 0x00; //Pid

    m_modbusSend[4] = 0x00; // 0, if msg length less 256bytes
    m_modbusSend[5] = 0x1F; // 7+12*2 = 31 = 1F

    m_modbusSend[6] = 0xFF; // id
    m_modbusSend[7] = 0x10; //fn = 0x10 means write multiple register

    m_modbusSend[8] = 0x00; //bit, m_cAddrH = 0 in  C# CMMT
    m_modbusSend[9] = 0x00; //bit, m_cAddrL = 0 in  C# CMMT

   int nRegNum = 12; //12 word
   //int nRegNum = 16; //16 word, add torque and acceleration value
   m_modbusSend[10] = (unsigned char)((nRegNum & 0xff00) >> 8);//data word counter high =**** array[10] = this.GetUpperByte(num);
   m_modbusSend[11] = (unsigned char)(nRegNum & 0x00ff); //data word counter low =****array[11] = this.GetLowerByte(num);
   m_modbusSend[12] = (unsigned char)((2*nRegNum) & 0xff);    //data bytes counter =***array[12] = this.GetLowerByte(num * 2);//ProcsssData  length

   int FirstData = 13;
   for (int i = 0; i < 12; i++) //12 word
   //for (int i = 0; i < 16; i++) //16 word
   {
       m_modbusSend[FirstData] = (unsigned char)((m_outW[i] & 0xff00) >> 8); //High byte
       m_modbusSend[FirstData + 1] = (unsigned char)(m_outW[i] & 0x00ff); //Low byte
       FirstData += 2;
   }
    //Send command frame
    int nTotalLen = 13 + nRegNum * 2; //nTotalLen = 37
    if(m_nPrint == 1)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + "*****queryWriteMultipleRegister****** strCommand**" +Hex::GetHexString(m_modbusSend,37));
    }
    sendData(m_modbusSend,nTotalLen);
    answerWriteHoldingRegister();
    m_nTransactionId++;
    if (m_nTransactionId >= 20000)
    {
        m_nTransactionId = 1;
    }
}

void TCPFestoMotor::answerWriteHoldingRegister() //12 bytes
{
    char recvBuffer[65535] = {0};
    memset(recvBuffer, 0, sizeof(recvBuffer));
    if(readData(recvBuffer, sizeof(recvBuffer)))
    {
        string strReply = Hex::GetHexString(recvBuffer,12);
        if(m_nPrint == 1)
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + "*****answerWriteHoldingRegister****** strReply**" +strReply);
        }
    }
}

void TCPFestoMotor::queryReadInputRegister()
{
    //1. Send modbus cmd to Servo Motor
    //Data to send for read input register
    //0  1  2  3  4  5  6  7  8  9  10 11
    //XX XX XX XX XX XX XX XX XX XX XX XX
    //Tid   Pid   Len   id fn offst #reg

    //Tid   --> 00 01 auto increment
    //Pid   --> 00 00
    //Len   --> 00 06
    //id    --> FF
    //fn    --> 04
    //offst --> 00 00
    //#reg  --> 00 0C (for basic)
    char pCommand[100] = {0};
    pCommand[0] = (unsigned char)((m_nTransactionId & 0xff00) >> 8); //High byte of Tid, m_nTransactionId is variable
    pCommand[1] = (unsigned char)(m_nTransactionId & 0x00ff); //Low byte of Tid, m_nTransactionId is variable

    pCommand[2] = 0x00; //Pid
    pCommand[3] = 0x00; //Pid

    pCommand[4] = 0x00;
    pCommand[5] = 0x06;

    pCommand[6] = 0xFF; // id
    pCommand[7] = 0x04; //fn = 0x04 means read input register

    pCommand[8] = 0x00; //bit, m_cAddrH = 0 in  C# CMMT
    pCommand[9] = 0x00; //bit, m_cAddrL = 0 in  C# CMMT

   //int nRegNum = 12; //12 word
    //int nRegNum = 16; //16 word, add torque and acceleration value
    int nRegNum = 20; //20 word, add torque,acceleration,current and I2t
    pCommand[10] = (unsigned char)((nRegNum & 0xff00) >> 8);//data word counter high =**** array[10] = this.GetUpperByte(num);
    pCommand[11] = (unsigned char)(nRegNum & 0x00ff); //data word counter low =****array[11] = this.GetLowerByte(num);

    //Send command frame

    int nTotalLen = 12;
    if(m_nPrint == 1)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + "######queryReadInputRegister****** strCommand**" +Hex::GetHexString(pCommand,12));
    }

    sendData(pCommand,nTotalLen);
    answerReadInputRegister();
    m_nTransactionId++;
    if (m_nTransactionId >= 20000)
    {
        m_nTransactionId = 1;
    }
}

void TCPFestoMotor::answerReadInputRegister()//33 +8 +8 bytes
{
    char recvBuffer[65535] = {0};
    memset(recvBuffer, 0, sizeof(recvBuffer));
    if(readData(recvBuffer, sizeof(recvBuffer)))
    {
        string strReply = Hex::GetHexString(recvBuffer,49);

        if(m_nPrint == 1)
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + "#######answerReadInputRegister****** strReply**" +strReply);
        }

        //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + "*****answerReadInputRegister****** strReply**" +strReply);
        if( (unsigned char)(m_nTransactionId & 0x00ff) == recvBuffer[1]  ) //check lower byte transaction id query and answer match
        {
            int FirstData = 9; //first data
            for (int j = 0; j < recvBuffer[8] / 2; j++)
            {
                m_inW[j] = GetWord(recvBuffer[FirstData], recvBuffer[FirstData + 1]);
                FirstData = FirstData + 2;
            }
            switch(m_nAdditionalDataMode)//[zhangcx v1.1.65_HotFix5]
            {
                case Mode1:
                    FirstData = 33;
                    fPositionControlError = GetFloat(recvBuffer[FirstData], recvBuffer[FirstData+1], recvBuffer[FirstData+2], recvBuffer[FirstData+3]);
                    m_dPositionControlError = (double)(fPositionControlError);
                    break;
                case Mode2:
                    FirstData = 33;
                    m_fTorque = GetFloat(recvBuffer[FirstData], recvBuffer[FirstData+1], recvBuffer[FirstData+2], recvBuffer[FirstData+3]);
                    m_dActualTorque = (double)(m_fTorque);

                    m_fTemperature = GetFloat(recvBuffer[FirstData+4], recvBuffer[FirstData+5], recvBuffer[FirstData+6], recvBuffer[FirstData+7]);
                    m_dTemperature = (double)(m_fTemperature);
                    break;
                default:
                    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + "Additional Data Mode is Error");
            }
            
            /**
            FirstData = 33;
            m_fTorque = GetFloat(recvBuffer[FirstData], recvBuffer[FirstData+1], recvBuffer[FirstData+2], recvBuffer[FirstData+3]);
            m_dActualTorque = (double)(m_fTorque);


            fAccelerate = GetFloat(recvBuffer[FirstData+4], recvBuffer[FirstData+5], recvBuffer[FirstData+6], recvBuffer[FirstData+7]);
            m_dActualAccelerate = (double)(fAccelerate);

            fCurrent = GetFloat(recvBuffer[FirstData+8], recvBuffer[FirstData+9], recvBuffer[FirstData+10], recvBuffer[FirstData+11]);
            m_dActualCurrent = (double)(fCurrent);

            fI2t = GetFloat(recvBuffer[FirstData+12], recvBuffer[FirstData+13], recvBuffer[FirstData+14], recvBuffer[FirstData+15]);
            m_dActualI2t = (double)(fI2t);
            **/
            return;
        }
    }
}

void TCPFestoMotor::queryReadHoldingRegister()
{
    m_modbusSend[0] = (unsigned char)((m_nTransactionId & 0xff00) >> 8); //High byte of Tid, m_nTransactionId is variable
    m_modbusSend[1] = (unsigned char)(m_nTransactionId & 0x00ff); //Low byte of Tid, m_nTransactionId is variable

    m_modbusSend[2] = 0x00; //Pid
    m_modbusSend[3] = 0x00; //Pid

    m_modbusSend[4] = 0x00;
    m_modbusSend[5] = 0x06;

    m_modbusSend[6] = 0xFF; // id
    m_modbusSend[7] = 0x03; //fn = 0x03 means read holding register

    m_modbusSend[8] = (unsigned char)((400 & 0xff00) >> 8); //bit, m_cAddrH = 400 in  C# CMMT
    m_modbusSend[9] = (unsigned char)(400 & 0x00ff); //bit, m_cAddrL = 400 in  C# CMMT

   int nRegNum = 1;
   m_modbusSend[10] = (unsigned char)((nRegNum & 0xff00) >> 8);//data word counter high =**** array[10] = this.GetUpperByte(num);
   m_modbusSend[11] = (unsigned char)(nRegNum & 0x00ff); //data word counter low =****array[11] = this.GetLowerByte(num);

    //Send command frame
    int nTotalLen = 12;
    string strReply = Hex::GetHexString(m_modbusSend,12);
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + "queryReadHoldingRegister = **********************"+strReply);

    sendData(m_modbusSend,nTotalLen);
    answerReadHoldingRegister();
    m_nTransactionId++;
    if (m_nTransactionId >= 20000)
    {
        m_nTransactionId = 1;
    }
}

void TCPFestoMotor::answerReadHoldingRegister()//11 bytes
{
    char recvBuffer[65535] = {0};
    memset(recvBuffer, 0, sizeof(recvBuffer));
    if(readData(recvBuffer, sizeof(recvBuffer)))
    {
        string strReply = Hex::GetHexString(recvBuffer,11);
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + "*****answerReadHoldingRegister****** strReply**" +strReply);
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + "***recvBuffer[1]**" +Converter::convertToString(recvBuffer[1]));
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + "***m_nTransactionId**" +Converter::convertToString(m_nTransactionId));

        m_nModbusTimeOutCurrent = GetWord(recvBuffer[9],recvBuffer[10]);
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + "***answerReadHoldingRegister strReply**" +Converter::convertToString(m_nModbusTimeOutCurrent));
    }
}

bool TCPFestoMotor::queryWriteSingleRegister()
{
    bool bResult = false;
    m_modbusSend[0] = (unsigned char)((m_nTransactionId & 0xff00) >> 8); //High byte of Tid, m_nTransactionId is variable
    m_modbusSend[1] = (unsigned char)(m_nTransactionId & 0x00ff); //Low byte of Tid, m_nTransactionId is variable

    m_modbusSend[2] = 0x00; //Pid
    m_modbusSend[3] = 0x00; //Pid

    m_modbusSend[4] = (unsigned char)((6 & 0xff00) >> 8);
    m_modbusSend[5] = (unsigned char)((6 & 0xff00) >> 8);

    m_modbusSend[6] = 0xFF; // id
    m_modbusSend[7] = 0x06; //fn = 0x06 means write Single register

    m_modbusSend[8] = (unsigned char)((400 & 0xff00) >> 8);
    m_modbusSend[9] = (unsigned char)(400 & 0x00ff);

    m_modbusSend[10] = (unsigned char)((m_nModbusTimeOut & 0xff00) >> 8);
    m_modbusSend[11] = (unsigned char)(m_nModbusTimeOut & 0x00ff);

    //Send command frame
    int nTotalLen = 12;
    string strReply = Hex::GetHexString(m_modbusSend,12);
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + "queryWriteSingleRegister = **********************"+strReply);

    sendData(m_modbusSend,nTotalLen);
    bResult = answerWriteSingleRegister();
    m_nTransactionId++;
    if (m_nTransactionId >= 20000)
    {
        m_nTransactionId = 1;
    }
    return bResult;
}

bool TCPFestoMotor::answerWriteSingleRegister()//12 bytes
{
    char recvBuffer[65535] = {0};
    memset(recvBuffer, 0, sizeof(recvBuffer));
    if(readData(recvBuffer, sizeof(recvBuffer)))
    {
        string strReply = Hex::GetHexString(recvBuffer,12);
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + "*****answerWriteSingleRegister****** strReply**" +strReply);
        return true;
    }
    else
    {
        return false;
    }
}


void TCPFestoMotor::readInput()
{
    if (!isConnected())
    {
        throw IOException("device is not connected! ");
    }
    try//added by liusy[1.1.57]
    {
                if (m_strPinupConfigName != "")
        {
                    m_pCfgMotorPinUpPosition = (ReadWriteDouble*)(ObjectManager::getInstance()->getObject(m_strPinupConfigName));
                }
                else
        {
                    m_pCfgMotorPinUpPosition = (ReadWriteDouble*)(ObjectManager::getInstance()->getObject("/SETUP/EChuck/cfgMotorPinUpPosition"));
                }
                if (m_strPindownConfigName != "")
        {
                     m_pCfgMotorPinDownPosition = (ReadWriteDouble*)(ObjectManager::getInstance()->getObject(m_strPindownConfigName));
                }
                else
                {
            m_pCfgMotorPinDownPosition = (ReadWriteDouble*)(ObjectManager::getInstance()->getObject("/SETUP/EChuck/cfgMotorPinDownPosition"));
                }
        m_bConfigMotorPositionInSetup = true;
    }
    catch(InvalidNameException ex)
    {
        m_bConfigMotorPositionInSetup = false;
        //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ":not need to get MotorPin Position value from setup"+ex.what());
    }
    m_strResult = "";
    queryReadInputRegister();
    parseInWCmd();

    double dMotorPinUpPosition;
    double dMotorPinDownPosition;
    if(m_bConfigMotorPositionInSetup)
    {
        dMotorPinUpPosition = m_pCfgMotorPinUpPosition->getValue();
        dMotorPinDownPosition = m_pCfgMotorPinDownPosition->getValue();
    }
    else
    {
        dMotorPinUpPosition = m_dPinUpPosition;
        dMotorPinDownPosition = m_dPinDownPosition;
    }

    if (abs(m_dActualPosition - dMotorPinUpPosition) <= m_dUpPositionTol)
    {
        m_nPinStatus = 0; //Up
    }
    else if (abs(m_dActualPosition - dMotorPinDownPosition) <= m_dDownPositionTol)
    {
        m_nPinStatus = 1; //Down
    }
    else
    {
        m_nPinStatus = -1; //Unknow
    }
}

bool TCPFestoMotor::readPosition(int nChannelNum, int* pValue, const IntTypeInfo &typeInfo)
{
    *pValue = m_nPinStatus;
    return true;
}

void TCPFestoMotor::writeOutput()//nValue = 1 or 0
{
    for(int i = 0; i < 12; i++)
    {
        constructOutWCmd(i);
    }
    queryWriteMultipleRegister();
}
void TCPFestoMotor::executePositionRecord()
{
    if(m_bExecuteRecordFlag)
    {
        //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " come into m_bPositioningTaskActivated ");
        if( (m_nPositioningRecord== 2) &&(abs(m_dActualPosition  -m_dRecord2Position) <= m_dUpPositionTol))//zhangyy modify[9.13]
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " Select MutiPosition Record reached "+ Converter::convertToString(m_nPositioningRecord) + "!!! Current position" + Converter::convertToString(m_dActualPosition));
            m_bActivatePositioningTask = false;
            m_bExecuteRecordFlag = false;
            m_nFinishPositionRecord = 1;
        }
        else if( (m_nPositioningRecord== 3) &&(abs(m_dActualPosition  -m_dRecord3Position) <= m_dUpPositionTol))//zhangyy modify[9.13]
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " Select MutiPosition Record reached "+ Converter::convertToString(m_nPositioningRecord)+ "!!! Current position" + Converter::convertToString(m_dActualPosition));
            m_bActivatePositioningTask = false;
            m_bExecuteRecordFlag = false;
            m_nFinishPositionRecord = 1;
        }
        else if((m_nPositioningRecord== 4) &&(abs(m_dActualPosition  -m_dRecord4Position) <= m_dUpPositionTol))//zhangyy modify[9.13]
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " Select MutiPosition Record reached "+ Converter::convertToString(m_nPositioningRecord)+ "!!! Current position" + Converter::convertToString(m_dActualPosition));
            m_bActivatePositioningTask = false;
            m_bExecuteRecordFlag = false;
            m_nFinishPositionRecord = 1;
        }
        else if((m_nPositioningRecord== 1) && (m_nPinStatus == 1))
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " Select MutiPosition Record reached "+ Converter::convertToString(m_nPositioningRecord));
            m_bActivatePositioningTask = false;
            m_bExecuteRecordFlag = false;
            m_nFinishPositionRecord = 1;
        }
    }
}

bool TCPFestoMotor::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
    if(nChannelNum == 1) //Home
    {
        m_bMDISelection = true;
        m_bStartHoming = false;
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " start Home");
        if (m_bOperationEnabled) //operation is Enabled
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " Operation is enabled, start homing");
            m_bStartHoming = true;

            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " 111111111");
            int t_leftcount = m_timeOut*1000/m_checkInterval;
            while(t_leftcount >= 0)
            {
                if(m_bReferencePointSet)
                {
                    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " 2222Homing done");
                    usleep(2000*1000);
                    m_bStartHoming = false;
                    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " 333333");
                    return true;
                }
                usleep(m_checkInterval * 1000);
                --t_leftcount;
            }
            throw IOException("Execute Home command timeOut");
        }
        else
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " Operation is not enabled");
            m_bStartHoming = false;
            throw IOException("Can't Home for Operation is disabled");
        }
    }
    if(nChannelNum == 2) //reset & enable, acknowledge
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " start execute enable or disable command");
        //m_nPrint = 1;
        m_bOutputStageEnable = false;
        m_bStartHoming = false;
        m_bAbsolutePositioning = false;
        m_bRelativePositioning = false;
        m_bRejectPositioningTask = false;
        m_bIntermediateStop = false;
        m_bMDISelection = false;
        m_bActivatePositioningTask = false;
        usleep(1000);//sleep 1ms
        if(m_bMalfunctionEffective) //if ServoMotor has fault
        {
            m_bAcknowledgeMalfunction = true; //execute reset
            while(1)
            {
                if(!m_bMalfunctionEffective)
                {
                    m_bOutputStageEnable = nValue;//servo on/off
                    break;
                }
                usleep(1000);
            }
        }
        else
        {
            m_bOutputStageEnable = nValue;//servo on/off
        }
        int t_leftcount = m_timeOut*1000/m_checkInterval;
        while(t_leftcount >= 0)
        {
            if(m_bOperationEnabled)
            {
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " execute enable or disbale operation Successfully");
                m_bAcknowledgeMalfunction = false;
                //m_nPrint = 0;
                return true;
            }
            usleep(m_checkInterval * 1000);
            --t_leftcount;
        }
        //m_nPrint = 0;
        throw IOException("Execute enable or disbale command timeOut");
    }
    if(nChannelNum == 3 ) //m_bIntermediateStop
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "execute Intermediate Stop");
        if(nValue == 1)
        {
            m_bIntermediateStop = false;//execute m_bIntermediateStop
        }
        else if(nValue == 0)
        {
            m_bIntermediateStop = true;//Cancel m_bIntermediateStop
        }
    }
    if(nChannelNum == 4) //m_bRejectPositioningTask
    {
        if(m_bIntermediateStop == false)
        {
            m_bRejectPositioningTask = false;//execute m_bRejectPositioningTask
        }
    }
    return true;
}

bool TCPFestoMotor::writePositionRecord(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{

    if(nChannelNum == 8)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " start select position record");
        if (m_bOperationEnabled) //m_bOperationEnabled
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " operation is enabled");
            m_nPositioningRecord = nValue; //Select position record number
            m_bActivatePositioningTask = false;
            m_bRejectPositioningTask = true;   //NC, 0 = reject
            m_bIntermediateStop = true;        //NC, 0 = stop
            m_bMDISelection = false;
            while(1)
            {
                if(!m_bMDIActive)
                {
                    m_bActivatePositioningTask = true;
                    break;
                }
                usleep(1000);
            }
            int nMaxTime;
            if(nValue == 2)
            {
                nMaxTime = m_nPinUpTimeOut;
            }
            if(nValue == 1)
            {
                nMaxTime = m_nPinDownTimeOut;
            }
            usleep(50*1000);
            while(1)
            {
                if(m_bPositioningTaskActivated)
                {
                    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " comeinto m_bPositioningTaskActivated ");
                    for(int i = 0; i < nMaxTime; i++)
                    {
                        if(m_bTargetPositionReached && (nMaxTime==m_nPinUpTimeOut) && (m_nPinStatus == 0))//zhangyy modify[1.8.11]
                        {
                            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " Select Record Position reached "+ Converter::convertToString(nValue));
                            m_bActivatePositioningTask = false;
                            break;
                        }
                        else if(m_bTargetPositionReached && (nMaxTime==m_nPinDownTimeOut) && (m_nPinStatus == 1))
                        {
                            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " Select Record Position reached "+ Converter::convertToString(nValue));
                            m_bActivatePositioningTask = false;
                            break;
                        }
                        else
                        {
                            usleep(1000);
                        }
                    }
                    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " go out m_bPositioningTaskActivated ");
                    break;
                }
                usleep(1000);
            }

        }
        else
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "Operation is not enabled");
            m_bActivatePositioningTask = false;
            m_bRejectPositioningTask = false;
            m_bIntermediateStop = false;
            m_bMDISelection = false;
            throw IOException("Can't select record position for operation is disabled");
        }
    }
    else if(nChannelNum == 9)
    {
    m_nFinishPositionRecord=0;
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " start select MutiPosition record");
        if (m_bOperationEnabled) //m_bOperationEnabled
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " operation is enabled");
            m_nPositioningRecord = nValue; //Select position record number
            m_bActivatePositioningTask = false;
            m_bRejectPositioningTask = true;   //NC, 0 = reject
            m_bIntermediateStop = true;        //NC, 0 = stop
            m_bMDISelection = false;
            while(1)
            {
                if(!m_bMDIActive)
                {
                    m_bActivatePositioningTask = true;
                    break;
                }
                usleep(1000);
            }
            /**
            int nMaxTime;
            if(nValue == 2 ||nValue == 3 ||nValue == 4 )//For MotorProcess position, timeout = 5s,m_nPinUpTimeOut=5000ms
            {
                nMaxTime = m_nPinUpTimeOut;
            }
            if(nValue == 1)
            {
                nMaxTime = m_nPinDownTimeOut;
            }
            **/
            usleep(50*1000);
            while(1)
            {
                if(m_bPositioningTaskActivated)
                {
                    m_bExecuteRecordFlag = true;
                    break;
                }
                
                usleep(1000);           
            }
        }
        else
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "Operation is not enabled");
            m_bActivatePositioningTask = false;
            m_bRejectPositioningTask = false;
            m_bIntermediateStop = false;
            m_bMDISelection = false;
            throw IOException("Can't select MutiPosition for operation is disabled");
        }
    }
    return true;
}


bool TCPFestoMotor::writeAbsolutePosition(int nChannelNum, double dPosition,const DoubleTypeInfo &typeinfo)
{
    if(nChannelNum == 5)//Make Motor move a distance = dPosition
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " start writeAbsolutePosition");
        if (m_bOperationEnabled) //m_bOperationEnabled
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " operation is enabled");
            m_bAbsolutePositioning = true;  //Move absolute
            m_bRelativePositioning = false;
            m_bActivatePositioningTask = false;
            m_bRejectPositioningTask = true;   //NC, 0 = reject
            m_bIntermediateStop = true;        //NC, 0 = stop
            m_bMDISelection = true;
            //m_bTargetPositionReached = false;
            m_dTargetPosition = dPosition;
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "******** AAAAAAA********* ");
            while(1)
            {
                if(m_bMDIActive)
                {
                    m_bActivatePositioningTask = true;
                    break;
                }
                usleep(1000);
            }
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "******** BBBBBBBB********* ");

                //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "******** CCCCCCCC********* ");

            usleep(50*1000);
            if(m_bPositioningTaskActivated)
            {
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "******** DDDDDDDDD********* ");

                for(int i = 0; i < 200000; i++)
                {
                    if(!m_bIntermediateStop)
                    {
                        m_bIntermediateStop = true;
                        break;
                    }
                    else if(m_bTargetPositionReached)
                    {
                        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " Position reached");
                        m_bActivatePositioningTask = false;
                        break;
                    }
                    else
                    {
                        usleep(1000);
                        //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "******** usleep( 1 ms)********* ");

                    }
                }
            }

        }
        else
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "Operation is not enabled");
            m_bActivatePositioningTask = false;
            m_bAbsolutePositioning = false;
            m_bRelativePositioning = false;
            m_bRejectPositioningTask = false;
            m_bIntermediateStop = false;
            m_bMDISelection = false;
            throw IOException("Can't move absolute position for Operation is disabled");
        }
    }
    return true;
}
//channel = 8 means writeRelativePosition
bool TCPFestoMotor::writeRelativePosition(int nChannelNum, double dPosition,const DoubleTypeInfo &typeinfo)
{
    if(nChannelNum == 6)//Make Motor move a distance = dValue
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "Start writeRelativePosition");
        if (m_bOperationEnabled) //m_bOperationEnabled
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "Operation is enabled");
            m_bAbsolutePositioning = false;
            m_bRelativePositioning = true;  //Move relative

            m_bRejectPositioningTask = true;   //NC, 0 = reject
            m_bIntermediateStop = true;        //NC, 0 = stop
            m_bMDISelection = true;
            //m_bTargetPositionReached = false;
            m_dTargetPosition = dPosition;

            while(1)
            {
                if(m_bMDIActive)
                {
                    m_bActivatePositioningTask = true;
                    break;
                }
                usleep(1000);
            }
            /***
            usleep(2000*1000);
            if(!m_bIntermediateStop)
            {
                m_bIntermediateStop = true;
            }
            else if(m_bTargetPositionReached)
            {
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "Position reached");
                m_bActivatePositioningTask = false;
            }
            m_nPrint = 0;
            **/
            //m_bPositioningTaskActivated
            usleep(50*1000);
            if(m_bPositioningTaskActivated)
            {
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "******** DDDDDDDDD********* ");

                for(int i = 0; i < 200000; i++)
                {
                    if(!m_bIntermediateStop)
                    {
                        m_bIntermediateStop = true;
                        break;
                    }
                    else if(m_bTargetPositionReached)
                    {
                        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " Position reached");
                        m_bActivatePositioningTask = false;
                        break;
                    }
                    else
                    {
                        usleep(1000);
                        //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "******** usleep( 1 ms)********* ");

                    }
                }
            }
        }
        else
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "Operation is not enabled");
            m_bActivatePositioningTask = false;
            m_bAbsolutePositioning = false;
            m_bRelativePositioning = false;
            m_bRejectPositioningTask = false;
            m_bIntermediateStop = false;
            m_bMDISelection = false;
            throw IOException("Can't move relative position for Operation is disabled");
        }
    }
    return true;
}

//channel = 7 means write TargetVelocity
bool TCPFestoMotor::writeTargetVelocity(int nChannelNum, double dVelocity,const DoubleTypeInfo &typeinfo)
{
    m_dTargetVelocity = dVelocity;
    return true;
}

bool TCPFestoMotor::readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
    switch(nChannelNum)//nChannelNum = 200
    {
        case 200: //read fault and Warn
            if(m_bMalfunctionEffective) //if ServoMotor has fault
            {
                m_strResult = " Malfunction, fault = " +  Converter::convertToString(nFault_Code) + " Warn_Code =  "+ Converter::convertToString(nWarn_Code);
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "@@@@@"+getDeviceName() + m_strResult);
                *pValue = 1; //Alarm
                //m_bAcknowledgeMalfunction = true; //execute reset
            }
            else
            {
                *pValue = 0; //No Alarm
            }
            break;
        case 205: //read enable or disable
            *pValue = m_bOperationEnabled;
            break;
        case 207: //read position record reached or not
            *pValue = m_nFinishPositionRecord;
            break;
        default:
            break;
    }
    return true;
}

bool TCPFestoMotor::readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo)
{
    switch(nChannelNum)
    {
        case 201: //read Actual Position
            //m_dActualPosition = MathTool::Round(m_dActualPosition,typeInfo.getAccuracy());
            *pValue = m_dActualPosition;
            break;
        case 202: //read Actual Velocity
            //m_dActualVelocity = MathTool::Round(m_dActualVelocity,typeInfo.getAccuracy());
            //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + "11111111111  m_dActualVelocity " +Converter::convertToString(m_dActualVelocity));
            *pValue = m_dActualVelocity;
            break;
        case 203: //read Actual Torque//[zhangcx v1.1.65_HotFix5]
            //m_dActualTorque = MathTool::Round(m_dActualTorque,typeInfo.getAccuracy());
            *pValue = m_dActualTorque;
            break;
        case 204: //read Actual PositionControlError
            //m_dPositionControlError = MathTool::Round(m_dPositionControlError,typeInfo.getAccuracy());
            *pValue = m_dPositionControlError;
            break;
            
        case 208: //read Actual Temperature//[zhangcx v1.1.65_HotFix5]
            //m_dTemperature = MathTool::Round(m_dTemperature,typeInfo.getAccuracy());
            *pValue = m_dTemperature;
            break;

        default:
            break;
    }
    return true;
}

void TCPFestoMotor::constructOutWCmd(unsigned char Controlword)
{
    switch (Controlword)
    {
        case 0://nSTW1
            nSTW1 = m_bOutputStageEnable + 2 * m_bDriveCoast+ 4 * m_bFastStop+ 8 * m_bEnableOperation
             + 16 * (m_bRampGenerator | m_bRejectPositioningTask) + 32 * (m_bStartRampGenerator | m_bIntermediateStop)
             + 64 * (m_bRotationalSpeedSetPoint | m_bActivatePositioningTask)+ 128 * m_bAcknowledgeMalfunction
             + 256 *m_bJogging1+ 512 *m_bJogging2+ 1024 * m_bPLCMasterControl + 2048 * (m_bInvertSetPointValue | m_bStartHoming)
             + 4096 * m_bReleaseHoldingBrake + 8192 * m_bStartRecordChange;
            m_outW[0] = nSTW1;
            break;
        case 1://nPOS_STW1
            m_bPositioningRecordSelectionBit0 = GetBitfromInt(m_nPositioningRecord, 0);
            m_bPositioningRecordSelectionBit1 = GetBitfromInt(m_nPositioningRecord, 1);
            m_bPositioningRecordSelectionBit2 = GetBitfromInt(m_nPositioningRecord, 2);
            m_bPositioningRecordSelectionBit3 = GetBitfromInt(m_nPositioningRecord, 3);
            m_bPositioningRecordSelectionBit4 = GetBitfromInt(m_nPositioningRecord, 4);
            m_bPositioningRecordSelectionBit5 = GetBitfromInt(m_nPositioningRecord, 5);
            m_bPositioningRecordSelectionBit6 = GetBitfromInt(m_nPositioningRecord, 6);

            nPOS_STW1 = m_bPositioningRecordSelectionBit0 + 2 * m_bPositioningRecordSelectionBit1
             + 4 * m_bPositioningRecordSelectionBit2 + 8 * m_bPositioningRecordSelectionBit3
             + 16 * m_bPositioningRecordSelectionBit4 + 32 * m_bPositioningRecordSelectionBit5
             + 64 * m_bPositioningRecordSelectionBit6 + 256*m_bAbsolutePositioning + 32768*m_bMDISelection;
            m_outW[1] = nPOS_STW1;
            break;
        case 2: //nPOS_STW2  16384 + 32768 = 49152 = C000 = 1100000000000000
            nPOS_STW2 = 16384 * m_bActivateSoftwareLimitSwitch + 32768 *m_bActivateHardwareLimitSwitch;
            m_outW[2] = nPOS_STW2;
            break;
        case 3: //STW2, no use 0000
            STW2 = 0;
            m_outW[3] = STW2;
            break;
        case 4:
            nOverride = (int)(m_dOverride * 16384) / 100;
            m_outW[4] = nOverride;
            break;
        case 5:
            if(m_dTargetPosition >= 0x00)
            {
                nMDI_TarPos1 = (int)(m_dTargetPosition * m_dConvertPositionOutput) % 65536;
            }
            else
            {
                nMDI_TarPos1 = ( (int)(m_dTargetPosition *m_dConvertPositionOutput) - 65536) % 65536;
            }
            m_outW[5] = nMDI_TarPos1;
            break;
        case 6:
            if(m_dTargetPosition >= 0x00)
            {
                nMDI_TarPos2 = (int)(m_dTargetPosition * m_dConvertPositionOutput) / 65536;
            }
            else
            {
                nMDI_TarPos2 = ( (int)(m_dTargetPosition *m_dConvertPositionOutput) - 65536) / 65536;
            }
            m_outW[6] = nMDI_TarPos2;
            break;
        case 7:
            if(m_dTargetVelocity >= 0x00)
            {
                nMDI_Velocity1 = (int)(m_dTargetVelocity * m_ConvertVelocityOutput) % 65536;
            }
            else
            {
                nMDI_Velocity1 = ( (int)(m_dTargetVelocity *m_ConvertVelocityOutput) - 65536) % 65536;
            }
            m_outW[7] = nMDI_Velocity1;
            break;
        case 8:
            if(m_dTargetVelocity >= 0x00)
            {
                nMDI_Velocity2 = (int)(m_dTargetVelocity * m_ConvertVelocityOutput) / 65536;
            }
            else
            {
                nMDI_Velocity2 = ( (int)(m_dTargetVelocity *m_ConvertVelocityOutput) - 65536) / 65536;
            }
            m_outW[8] = nMDI_Velocity2;
            break;
        case 9: //4000
            nMDI_ACC = (int)(m_dAcceleration * 16384) / 100; //16384 = 2^14
            m_outW[9] = nMDI_ACC;
            break;
        case 10: //4000
            nMDI_DEC = (int)(m_dDeceleration * 16384) / 100;
            m_outW[10] = nMDI_DEC;
            break;
        case 11: //0000
            m_outW[11] = 0;
            break;
        default:
            break;
    }
}

void TCPFestoMotor::parseInWCmd()
{
    //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "In parseInWCmd, nZSW1 = " +Converter::convertToString(nZSW1));
    nZSW1 = m_inW[0];
    nPOS_ZSW1 = m_inW[1];
    nPOS_ZSW2 = m_inW[2];
    nZSW2 = m_inW[3];
    nMELDW = m_inW[4];
    nXIST_A1 = m_inW[5];
    nXIST_A2 = m_inW[6];
    m_dActualPosition = (double)(nXIST_A1 + nXIST_A2 * 65536) / m_ConvertPositionInput*1000; //Unit from m to mm
    nIST_B1 = m_inW[7];
    nIST_B2 = m_inW[8];
    m_dActualVelocity = (double)(nIST_B1 + nIST_B2 * 65536) / m_ConvertVelocityInput;//Unit m/s
    //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + "333333  m_dActualVelocity " +Converter::convertToString(m_dActualVelocity));

    nFault_Code = m_inW[9]; //nFault_Code
    nWarn_Code = m_inW[10]; //nWarn_Code

    /**********nZSW1***From Bit 0 to Bit 15******************/
    m_bReadytobeSwitchOn = GetBitfromInt(nZSW1, 0);
    m_bReadyforOperation = GetBitfromInt(nZSW1, 1);
    m_bOperationEnabled = GetBitfromInt(nZSW1, 2);
    m_bMalfunctionEffective = GetBitfromInt(nZSW1, 3);
    m_bCoastingActive = GetBitfromInt(nZSW1, 4);
    m_bFastStopActive = GetBitfromInt(nZSW1, 5);
    m_bSwitchOnLockActive = GetBitfromInt(nZSW1, 6);
    m_bWarningEffective = GetBitfromInt(nZSW1, 7);
    m_bVelocityInRange = GetBitfromInt(nZSW1, 8);
    m_bPositionInRange = GetBitfromInt(nZSW1, 9);//use this

    m_bGuideRequired = m_bPositionInRange;

    m_bVelocityComparisonValueReached = GetBitfromInt(nZSW1, 10);
    m_bTargetPositionReached = m_bVelocityComparisonValueReached;//use this

    m_bIMPLimitNotReached = GetBitfromInt(nZSW1, 11);
    m_bReferencePointSet = m_bIMPLimitNotReached;//use this

    m_bHoldingBrakeReleased = GetBitfromInt(nZSW1, 12);
    m_bPositioningTaskActivated = m_bHoldingBrakeReleased;//use this

    m_bNoWarningifMotorOvertemperature = GetBitfromInt(nZSW1, 13);
    m_bDriveisStationary = m_bNoWarningifMotorOvertemperature;//use this

    m_bMotorDirectionofRotation = GetBitfromInt(nZSW1, 14);
    m_bAxisAccelerated = m_bMotorDirectionofRotation;//use this

    m_bNoPowerUnitOvertemperatureWarning = GetBitfromInt(nZSW1, 15);
    m_bDriveDecelerated = m_bNoPowerUnitOvertemperatureWarning;//use this

    /**********nPOS_ZSW1***From Bit 0 to Bit 15******************/
    m_bActivePositioningRecordBit0 = GetBitfromInt(nPOS_ZSW1, 0);
    m_bActivePositioningRecordBit1 = GetBitfromInt(nPOS_ZSW1, 1);
    m_bActivePositioningRecordBit2 = GetBitfromInt(nPOS_ZSW1, 2);
    m_bActivePositioningRecordBit3 = GetBitfromInt(nPOS_ZSW1, 3);
    m_bActivePositioningRecordBit4 = GetBitfromInt(nPOS_ZSW1, 4);
    m_bActivePositioningRecordBit5 = GetBitfromInt(nPOS_ZSW1, 5);
    m_bActivePositioningRecordBit6 = GetBitfromInt(nPOS_ZSW1, 6);
    m_bActivePositioningRecord = (unsigned char)(nPOS_ZSW1 >> 24);
    m_bNegativeLimitSwitchActive = GetBitfromInt(nPOS_ZSW1, 8);
    m_bPositiveLimitSwitchActive = GetBitfromInt(nPOS_ZSW1, 9);
    m_bJoggingActive = GetBitfromInt(nPOS_ZSW1, 10);
    m_bHomingActive = GetBitfromInt(nPOS_ZSW1, 11);
    m_bPositioningRecordActive = GetBitfromInt(nPOS_ZSW1, 13);
    m_bMDIActive = GetBitfromInt(nPOS_ZSW1, 15);

    /**********nPOS_ZSW2***From Bit 0 to Bit 15******************/
    m_bTrackingModeActive = GetBitfromInt(nPOS_ZSW2, 0);
    m_bVelocityLimitingActive = GetBitfromInt(nPOS_ZSW2, 1);
    m_bSetPointValueStopped = GetBitfromInt(nPOS_ZSW2, 2);
    m_bDriveTravelsForward = GetBitfromInt(nPOS_ZSW2, 4);
    m_bDriveTravelsBackward = GetBitfromInt(nPOS_ZSW2, 5);
    m_bNegativeSoftwareLimitSwitchActive = GetBitfromInt(nPOS_ZSW2, 6);
    m_bPositiveSoftwareLimitSwitchActive = GetBitfromInt(nPOS_ZSW2, 7);
    m_bActualPositionLessEqualThanCamSwitch0 = GetBitfromInt(nPOS_ZSW2, 8);
    m_bActualPositionLessEqualThanCamSwitch1 = GetBitfromInt(nPOS_ZSW2, 9);
    m_bDirectOutput1ViaPositioningRecord = GetBitfromInt(nPOS_ZSW2, 10);
    m_bDirectOutput2ViaPositioningRecord = GetBitfromInt(nPOS_ZSW2, 11);
    m_bFixedStopReached = GetBitfromInt(nPOS_ZSW2, 12);
    m_bFixedStopClampingTorqueReached = GetBitfromInt(nPOS_ZSW2, 13);
    m_bTravelToFixedStopActive = GetBitfromInt(nPOS_ZSW2, 14);
    m_bPositionCommandActive = GetBitfromInt(nPOS_ZSW2, 15);
}

void TCPFestoMotor::updateModbusTimeOut()
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + " Begin to update ModbusTimeOut");
    bool bFlag3 = queryWriteSingleRegister();
    queryReadHoldingRegister();
    cout<<"queryWriteSingleRegister  successfully = "<<bFlag3<<endl;
}


/**
void TCPFestoMotor::updateModbusTimeOut()
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + " updateModbusTimeOut");
    bool bFlag = m_nModbusTimeOutCurrent == 0;
    if(bFlag)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + "queryReadHoldingRegister");
        queryReadHoldingRegister();
    }
    else
    {
        bool bFlag2 = m_nModbusTimeOutCurrent != m_nModbusTimeOut;
        if(bFlag2)
        {
            bool bFlag3 = queryWriteSingleRegister();
            if(bFlag3)
            {
                m_nModbusTimeOutCurrent = m_nModbusTimeOut;
            }
        }
    }

}
**/

bool TCPFestoMotor::GetBitfromInt(int myInt, int bitNumber)
{
    return (myInt & 1 << bitNumber) != 0;
}

int TCPFestoMotor::GetWord(unsigned char Upper, unsigned char Lower)
{
    return Upper * 256 + Lower;
}


float TCPFestoMotor::GetFloat(char char1,char char2,char char3,char char4)
{
    char m[4] = {char2,char1,char4,char3};
    return *(float*)m;
    //return (float&)m;
}

double TCPFestoMotor::GetDouble(char char1,char char2,char char3,char char4,char char5,char char6,char char7,char char8)
{
    char m[8] = {char2,char1,char4,char3,char6,char5,char8,char7};
    return *(double*)m;
    //return (double&)m;
}

string TCPFestoMotor::getDeviceName()
{
    return __FILE__;
}

void TCPFestoMotor::setPinMaxPosition(double dValue)
{
    m_dPinUpPosition = dValue;
}

void TCPFestoMotor::setPinMinPosition(double dValue)
{
    m_dPinDownPosition = dValue;
}

void TCPFestoMotor::setRecord2Position(double dValue)//For X03 Muti Record Position
{
    m_dRecord2Position = dValue;
}

void TCPFestoMotor::setRecord3Position(double dValue)//For X03 Muti Record Position
{
    m_dRecord3Position = dValue;
}
void TCPFestoMotor::setRecord4Position(double dValue)//For X03 Muti Record Position
{
    m_dRecord4Position = dValue;
}
void TCPFestoMotor::setUpPositionTol(double dValue)
{
    m_dUpPositionTol = dValue;
}

void TCPFestoMotor::setDownPositionTol(double dValue)
{
    m_dDownPositionTol = dValue;
}

void TCPFestoMotor::setPinUpTimeOut(int nValue)
{
    m_nPinUpTimeOut = nValue;
}

void TCPFestoMotor::setPinDownTimeOut(int nValue)
{
    m_nPinDownTimeOut = nValue;
}

void TCPFestoMotor::initChannels(DeviceNode<TCPFestoMotor> *pNode)
{
    for(int i=1; i<=4; ++i)
    {
        pNode->registerWriteCh(i,&TCPFestoMotor::writeInt);
    }
    pNode->registerWriteCh(5,&TCPFestoMotor::writeAbsolutePosition);//channel 5 = Move absolute
    pNode->registerWriteCh(6,&TCPFestoMotor::writeRelativePosition);//channel 6 = Move relative
    pNode->registerWriteCh(7,&TCPFestoMotor::writeTargetVelocity);//channel 7 = write TargetVelocity
    pNode->registerWriteCh(8,&TCPFestoMotor::writePositionRecord);//channel 8 = write Position Record
    pNode->registerWriteCh(9,&TCPFestoMotor::writePositionRecord);//channel 9 = write MutiPosition Record

    pNode->registerReadCh(200, &TCPFestoMotor::readInt);//read fault and Warn
    pNode->registerReadCh(201, &TCPFestoMotor::readDouble);//read actual Position
    pNode->registerReadCh(202, &TCPFestoMotor::readDouble);//read actual Velocity
    pNode->registerReadCh(203, &TCPFestoMotor::readDouble);//read actual Torque//[zhangcx v1.1.65_HotFix5]
    pNode->registerReadCh(204, &TCPFestoMotor::readDouble);//read position control error
    pNode->registerReadCh(205, &TCPFestoMotor::readInt);//read enable or disable
    pNode->registerReadCh(206, &TCPFestoMotor::readPosition);//read up,down or unknown MotorPin Position
    pNode->registerReadCh(207, &TCPFestoMotor::readInt);//read position record reached or not
    pNode->registerReadCh(208, &TCPFestoMotor::readDouble);//read actual Temperature//[zhangcx v1.1.65_HotFix5]
}

void TCPFestoMotor::init()
{
    cout<<"TCPFestoMotor start to init"<<endl;
    DeviceNode<TCPFestoMotor> *node = new DeviceNode<TCPFestoMotor>(m_pollInterval,this);
    DeviceManager::getInstance()->registerNode(m_nodeNum,node);

    if(!isSimulated())
    {
        cout<<"TCPFestoMotor start to init channels"<<endl;
        initChannels(node);
        cout<<"TCPFestoMotor init channels ok"<<endl;
        TCPDeviceFesto::init();
        updateModbusTimeOut();
    }
}

void TCPFestoMotor::setPinupConfigName(string strValue)//added by liusy[1.1.57]
{
    m_strPinupConfigName = strValue;
}
void TCPFestoMotor::setPindownConfigName(string strValue)
{
    m_strPindownConfigName = strValue;
}

void TCPFestoMotor::setAdditionalDataMode(int nMode)//[zhangcx v1.1.65_HotFix5]
{
    m_nAdditionalDataMode = nMode;
}

IMPLEMENT_DYNAMIC( TCPFestoMotor, TCPDeviceFesto )

BEGIN_MSG_MAP( TCPFestoMotor, TCPDeviceFesto )
    SET_V( init, TCPFestoMotor )
    SET_D(setPinMaxPosition, TCPFestoMotor)
    SET_D(setPinMinPosition, TCPFestoMotor)
    SET_D(setUpPositionTol, TCPFestoMotor)
    SET_D(setDownPositionTol, TCPFestoMotor)
    SET_I(setPinUpTimeOut,TCPFestoMotor)
    SET_I(setPinDownTimeOut,TCPFestoMotor)
    SET_D(setRecord2Position, TCPFestoMotor)
    SET_D(setRecord3Position, TCPFestoMotor)
    SET_D(setRecord4Position, TCPFestoMotor)
    SET_S(setPinupConfigName, TCPFestoMotor)//added by liusy[1.1.57]
    SET_S(setPindownConfigName, TCPFestoMotor)
    SET_I(setAdditionalDataMode,TCPFestoMotor)//[zhangcx v1.1.65_HotFix5]
END_MSG_MAP
