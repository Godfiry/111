#ifndef MAPTOOL_H_
#define MAPTOOL_H_

#include <map>

using namespace std;

class MapTool
{
public:
	MapTool();
	virtual ~MapTool();
	
public:
	//return true - add success. else return false
	template<class K,class D> static bool addToMap(map<K,D> & DesMap,K Key,D Data);

	template<class K,class D> static bool valueExist(map<K,D> &DesMap,D value);

	template<class K,class D> static typename map<K,D>::iterator findValue(map<K,D> &DesMap,D value);
};

template<class K,class D> bool MapTool::addToMap(map<K,D> & DesMap,K Key,D Data)
{
	if(DesMap.count(Key)!=0)
	{
		return false;
	}
	else
	{
		DesMap[Key]=Data;
		return true;
	}
}

template<class K,class D> bool MapTool::valueExist(map<K,D> &DesMap,D value)
{
	typename map<K,D>::iterator it ;
	for(it=DesMap.begin(); it != DesMap.end();++it)
	{
		if(value == it->second)
		{
			return true;
		}
	}
	return false;
}

template<class K,class D> typename map<K,D>::iterator MapTool::findValue(map<K,D> &DesMap,D value)
{
	typename map<K,D>::iterator it ;
	for(it=DesMap.begin(); it != DesMap.end();++it)
	{
		if(value == it->second)
		{
			break;
		}
	}
	return it;
}

#endif /*MAPTOOL_H_*/
