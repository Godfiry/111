/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: LFDNet.cpp
** Description:CLB200A,350-450KHz,208V,DNet RF Power Supply
* 
** Release: 1.1
** Modification history: 
** 					2013-5-31   mayc create
**      
*********************************************************************/
#include "LFDNet.h"

#include "DeviceManager.h"
#include "ConfigException.h"

#include <cmath>
#include <sys/time.h>
#include <iostream>
#include <string.h>
#ifdef IAP4_0
using namespace IAP::IO;
#endif
using namespace std;

LFDNet::Com LFDNet::m_command[] = {{0, 0, 0, 0, 0}, {0, 0, 0, 0, 0},{0, 0, 0, 0, 0},{0, 0, 0, 0, 0},
										{0x0E, 0xB1, 0x01, 0x12, 0x02},
										{0x10, 0xB1, 0x01, 0x12, 0x02},		
										{0x0E, 0xB1, 0x01, 0x13, 0x01},
										{0x10, 0xB1, 0x01, 0x13, 0x01}};

LFDNet::LFDNet()
{
	memset(buffersave, 0, 5);	//added by xiasc for test
}

LFDNet::~LFDNet()
{
}

bool LFDNet::setLFPower(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
//	if (isSimulated())
//	{
//		return true;
//	}

//	char buffer[5];	
	int outputBytes = m_deviceNet->getOBytesSize(m_macID);
	char buffer[outputBytes];
	memset(buffer, 0, outputBytes);	
	unsigned long  temp =(unsigned long)((value / m_maxLFPower) * 4095);//0xFFF
	buffer[0] = temp & 0xff;
	buffer[1] = (temp >> 8) & 0x0f;
	buffer[2] = 0x00;
	buffer[3] = 0x00;
	buffer[4] = buffersave[4];
	//buffer[8]=buffer[8]&0xFE;
	//PULS 1:Pulse Enabled 0:CW Mode   TM 1:Fixed Frequency 0:Auto-tune        PO 1:ON 0:OFF
	// 1 1 1
	/*if(value < 1.0)
		buffer[4] = 0x00;
	else
		buffer[4] = 0x07;*/

        //cout<< "MaxLFPower:"<< m_maxLFPower <<endl;
         //cout<< "Value:"<< (double)value <<endl;
	 //cout<< "buffer://"<< temp <<endl;
	buffersave[0]=buffer[0];
	buffersave[1]=buffer[1];
	return m_deviceNet->writeByte(m_macID, buffer);
}
bool LFDNet::setLFPowOn(int channelNum, int value, const IntTypeInfo &typeInfo)
{
	
	int outputBytes = m_deviceNet->getOBytesSize(m_macID);
	//cout<<outputBytes<<endl;
	char buffer[outputBytes];
	memset(buffer, 0, outputBytes);
	buffer[0]=buffersave[0];
	buffer[1]=buffersave[1];
	buffer[2] = 0x00;
	buffer[3] = 0x00;
	//m_deviceNet->readByte(m_macID, buffer);
		//cout<<"!!!!!!!"<<buffer[4]<<endl;
   if(0==value)
   {
	   buffer[4]=0x00;
	   //cout<<"!!!!!!!OFF"<<buffer[4]<<endl;
   }
    
	if(1==value)
	{
		buffer[4]=0x07;
		//cout<<"!!!!!!!ON"<<buffer[4]<<endl;
	}
	buffersave[4]=buffer[4];
	
	return m_deviceNet->writeByte(m_macID, buffer);
}

bool LFDNet::getLFPower(int channelNum, double *value,const DoubleTypeInfo &typeInfo )
{
	int inputBytes = m_deviceNet->getIBytesSize(m_macID);
	char buffer[inputBytes];
	//char buffer[9];
	memset(buffer, 0, inputBytes);
	m_deviceNet->readByte(m_macID, buffer);

	unsigned long temp = 0;
	
	if(channelNum == 1)
	{
		temp = (buffer[0] &0xff) + ((buffer[1] << 8) & 0x0f00);	
//		cout<<"Temp:"<<temp<<endl;	
		*value = (((double)temp)/4095) * typeInfo.getMax();//0xFFF = 4095;
	}
	if(channelNum == 3)
	{
		temp = (buffer[2] &0xff) + ((buffer[3] << 8) & 0x0f00);	
//		cout<<"Reflect Temp:"<<temp<<endl;	
		*value = (((double)temp)/4095) * typeInfo.getMax();//0xFFF = 4095;
	}
	if(channelNum == 4)
	{
		temp = (buffer[4] &0xff) + ((buffer[5] << 8) & 0x0f00);	
//		cout<<"Reflect Temp:"<<temp<<endl;	
		*value = temp;//0xFFF = 4095;
	}
	if(channelNum == 6)
	{
		temp = buffer[6]&0xff;	
//		cout<<"Reflect Temp:"<<temp<<endl;	
		*value = temp;//0xFFF = 4095;
	}	
	return true;	
}

bool LFDNet::readECT(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	if((channelNum == 4) || (channelNum == 6))
	{	
	*value = 0;	
	Com t_com = m_command[channelNum];
	char buffer[t_com.m_datasize];
	memset(buffer, 0, t_com.m_datasize);
	char bufferin[1];
	int *dataOut;
	bufferin[0] = t_com.m_attributeID&0x000000ff;
//	cout<<"readECT"<<endl;
	cout<<"channelNumbefore--------------:"<<channelNum<<endl;
	m_deviceNet->readExplicit(m_macID, bufferin, t_com.m_serviceCd, t_com.m_classID, t_com.m_instanceID, 1,buffer,dataOut);//t_com.m_datasize,buffer,dataOut);
//	try
//	{
//		m_deviceNet->readExplicit(m_macID, bufferin, t_com.m_serviceCd, t_com.m_classID, t_com.m_instanceID, 1,buffer,dataOut);//t_com.m_datasize,buffer,dataOut);
//	}
//	catch(const exception &ex)
//	{
//		cout<<"exception &ex:"<<ex.what()<<endl;
		//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, ":in readECT got exception '" + string(ex.what()) + "'");
//		throw;
//	}	
	
//	cout<<"-------------"<<endl;
/*	value1 = buffer[t_com.m_datasize-1];
	for(int i = t_com.m_datasize; i >= 2; i--)
	{
		value1 = (value1<<8) + buffer[i-2];
	}

	cout<<"value:"<<value1<<"buffer:"<<buffer[t_com.m_datasize-1]<<endl;
*/
	unsigned long temp = 0;
	if(t_com.m_datasize == 2)
	{	
		
		temp = ((buffer[1] << 8) & 0xff00)|(buffer[0]&0xff);// + (buffer[1] << 8) & 0x1f00);
//		cout<<"read freq buf 0:"<<hex<<temp<<endl;
//		cout<<"read freq buf 1:"<<hex<<buffer[1]<<endl;
//		cout<<"read freq +256:"<<temp<<endl;
//		cout<<"read freq +:"<<((buffer[1] << 8) & 0xff00)<<endl;
		
	}
	//if(t_com.m_datasize == 1)
//		cout<<"t_com.m_datasize---------:"<<t_com.m_datasize<<endl;
		cout<<"channelNum--------------:"<<channelNum<<endl;
	 
	//pulse freq
	if(channelNum == 4)
	{
			if(temp >= 5000)
				temp = 5000;
			if(temp <= 0)
				temp = 150;
			*value = temp;//4850/4095 + 150;//(value - 150) * 65535 / 4850;
	}	
	else if(channelNum == 6)
	{
		temp = buffer[0]&0xff;
//		cout<<"LF dutycycle---------:"<<temp<<endl;
		if(temp >= 90)
			temp = 90;
		if(temp <= 0)
			temp = 10;
		*value = temp;//80/127 + 10;
	}
	else
	{
		*value = 0;
	}
	return true;
	}
	else
	{
		return true;
	}
/*	for(int i = 0; i < t_com.m_datasize; i++)
	{
		if(t_com.m_datasize == 1)
			*value = buffer[0];
		else
			*value = *value + buffer[i-1];
	}
*/				
}

bool LFDNet::writeECT(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
/*
	if (isSimulated())
	{
		return true;
	}
*/	
	Com t_com = m_command[channelNum];
	char buffer[t_com.m_datasize +1];
	memset(buffer, 0, t_com.m_datasize+1);
	int i = 0;

	if(t_com.m_attributeID != 0)
	{
		buffer[i++] = t_com.m_attributeID;
	}
	
	long temp=0;
	//temp = double((value - 10) * 127) / 80;
	//buffer[1] = (unsigned char)(temp & 0x7f);
	//buffer[0] = t_com.m_attributeID;
	//pulse freq
	
	if(channelNum == 5)
		{
			temp = value;	
			buffer[1] = (unsigned char)(temp & 0xff);
			buffer[2] = (unsigned char)((temp>>8) & 0xff);
		}
	else
		{
			temp = value;
			buffer[1] = (unsigned char)(temp & 0xff);
		}
		
	/*for(int i = 0; i < t_com.m_datasize; i++)
	{
		buffer[i] = (unsigned char)( (int)value & 0xff);
		value = (int)value>>8;
	}*/
	
	//cout<<"temp:"<<temp<<endl;
	//buffer[1] = (unsigned char)(temp & 0xff);
	//buffer[2] = (unsigned char)((temp>>8) & 0xff);
	//cout<<"buffer:"<<hex<<(unsigned int)buffer[1]<<"  "<<(unsigned int)buffer[0]<<endl;
	//cout<<"t_com.m_serviceCd"<<t_com.m_serviceCd<<"t_com.m_classID"<<t_com.m_classID<<"t_com.m_instanceID"<<t_com.m_instanceID<<endl;
	return m_deviceNet->writeExplicit(m_macID, buffer, t_com.m_serviceCd, t_com.m_classID, t_com.m_instanceID, t_com.m_datasize+1);	
}

bool LFDNet::setMaxLFPower(double value)
{
  //cout<<"The MAXGAS value is:"<<value<<endl;
	m_maxLFPower = value;
	//cout<<"the maxGasFlow is:"<<m_maxGasFlow<<endl;
	return true;
}

void LFDNet::init()
{
	if(!isSimulated())
	{
		/*string error = "";
		if(m_deviceNet == NULL)
		{
			if(m_deviceName == "DNSS5136")
			{
				//m_deviceNet = new DNSS5136("/dev/ss5136dn0", 0, 125);
			}
			else if(m_deviceName == "SSTDN3PCU1")
			{
				m_deviceNet = new SSTDN3PCU1("/dev/sstdn3pcu10", 0, 125);
			}	
			m_deviceNet->setFWdir(m_fwdir);
			m_deviceNet->loadDevice();
		}
		if(!(m_deviceNet->addDevice(m_macID)))
		{	
			error = "Add device failed : " + Converter::convertToString(m_macID);
			throw ConfigException(error);
		}
		if(m_nodeNum < 0)
		{
			error = "node number illegal: " + Converter::convertToString(m_macID);
			throw ConfigException(error);
		}*/	
		initDeviceNet();
		DeviceNode<LFDNet> * node = new DeviceNode<LFDNet>(m_pollInterval,this);
		//for(int i=0;i<=4;i++)
		node->registerReadCh(1, &LFDNet::getLFPower);
		//for(int i=10;i<=14;i++)
		node->registerWriteCh(2, &LFDNet::setLFPower);
		
		node->registerReadCh(3, &LFDNet::getLFPower);
		//for(int i=10;i<=14;i++)
		//pulsefreqAI
		node->registerReadCh(4, &LFDNet::getLFPower);
		//pulsefreqAO
		node->registerWriteCh(5, &LFDNet::writeECT);
		//pulseDutyAI
		node->registerReadCh(6, &LFDNet::getLFPower);
		//pulseDutyAO
		node->registerWriteCh(7, &LFDNet::writeECT);
       //powerOn
		node->registerWriteCh(8, &LFDNet::setLFPowOn);

	
		DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	}
	else
	{
		DeviceNode<LFDNet> * node = new DeviceNode<LFDNet>(m_pollInterval,this);
		//for(int i=0;i<=4;i++)
		node->registerReadCh(1, &LFDNet::getLFPower);
		//for(int i=10;i<=14;i++)
		node->registerWriteCh(2, &LFDNet::setLFPower);
		
		node->registerReadCh(3, &LFDNet::getLFPower);
		//for(int i=10;i<=14;i++)
		//pulsefreqAI
		node->registerReadCh(4, &LFDNet::getLFPower);
		//pulsefreqAO
		node->registerWriteCh(5, &LFDNet::writeECT);
		//pulseDutyAI
		node->registerReadCh(6, &LFDNet::getLFPower);
		//pulseDutyAO
		node->registerWriteCh(7, &LFDNet::writeECT);
       //powerOn
		node->registerWriteCh(8, &LFDNet::setLFPowOn);

	
		DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	}
}


IMPLEMENT_DYNAMIC(LFDNet, IODevice )
BEGIN_MSG_MAP( LFDNet, IODevice )
	SET_D(setMaxLFPower, LFDNet)
END_MSG_MAP


