/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: SimulatedDriver.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-10-06   LiJuanjuan create
**      
*********************************************************************/
#include "SimulatedDriver.h"

#include "DoubleTypeInfo.h"
#include "DeviceManager.h"
#include <ctime>
#include <sys/time.h>
#ifdef IAP4_0
using namespace IAP::IO;
#endif

using namespace std;

SimulatedDriver::SimulatedDriver()
{
	m_interval = 200;//ms
	m_doubleChNum = 0;
	m_intChNum = 0;
	m_strChNum = 0;	
	m_nodeNum = -1;
}

SimulatedDriver::~SimulatedDriver()
{
}

bool SimulatedDriver::readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	struct timeval sTime1;
	gettimeofday(&sTime1, NULL);
	double result = sTime1.tv_usec/1000;
	while(result > typeInfo.getMax())
	{
		result = result/2;
	}
	*value = result;
	return true;
}


void SimulatedDriver::init()
{
	DeviceNode<SimulatedDriver> *node = new DeviceNode<SimulatedDriver>(m_interval, this);
	for(int i = 0; i<m_doubleChNum; ++i)
	{
		node->registerReadCh(i, &SimulatedDriver::readDouble);
	}		
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);	
}

void SimulatedDriver::setDoubleChNum(int num)
{
	m_doubleChNum = num;
}

void SimulatedDriver::setIntChNum(int num)
{
	m_intChNum = num;
}
		
void SimulatedDriver::setStrChNum(int num)
{
	m_strChNum = num;
}

void SimulatedDriver::setPollInterval(int interval)
{
	m_interval = interval;
}

void SimulatedDriver::setNodeNum(int num)
{
	m_nodeNum = num;
}

IMPLEMENT_DYNAMIC(SimulatedDriver, AbstractDevice)

BEGIN_MSG_MAP( SimulatedDriver, AbstractDevice)
	SET_I( setDoubleChNum, SimulatedDriver )  
	SET_I( setIntChNum, SimulatedDriver )  
	SET_I( setStrChNum, SimulatedDriver )  
	SET_I( setPollInterval, SimulatedDriver )  
	SET_I( setNodeNum, SimulatedDriver )  
	SET_V( init, SimulatedDriver )  
END_MSG_MAP

