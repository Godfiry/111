#include "EtherCatPLC_V300Gi.h"
#include "Converter.h"
#include "StrTool.h"
#include <iostream>
#include <unistd.h>
#include <string.h>

#include "DeviceManager.h"
#include "IODevice.h"
#include "Hex.h"
#include <string.h>
#include "ConfigException.h"
#include "MathTool.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
using namespace IAP;
#endif

EtherCatPLC_V300Gi::EtherCatPLC_V300Gi() {
	// TODO Auto-generated constructor stub
	//test
	m_channelSize = 200;
}

EtherCatPLC_V300Gi::~EtherCatPLC_V300Gi() {
	// TODO Auto-generated destructor stub

}


bool EtherCatPLC_V300Gi::writeBit(int channelNum, int bit, const IntTypeInfo &typeInfo)
{
	int nIndex = channelNum - m_channelSize;
	DigitalParam* dp = &(m_deviceParam.m_Output.m_vDOParam.at(nIndex));
	int nType = dp->m_nType;

	if(channelNum == 661 || channelNum == 662)
	{
		//DigitalParam* dp = &(m_deviceParam.m_Output.m_vDOParam.at(nIndex));
		int nOffset = dp->m_nByteOffset;
		if(channelNum == 661)  //PV Close/Open
		{
			if(bit == 0)
			{
				m_pWriteBuffer[nOffset] = (unsigned char)(3 & 0xff);
				m_pWriteBuffer[nOffset+1] = (unsigned char)(0 & 0xff);
			}
			if(bit == 1)
			{
				m_pWriteBuffer[nOffset] = (unsigned char)(4 & 0xff);
				m_pWriteBuffer[nOffset+1] = (unsigned char)(0 & 0xff);
			}
		}
		if(channelNum == 662)   //PV Pressure/Position
		{
			if(bit == 0)
			{
				m_pWriteBuffer[nOffset] = (unsigned char)(2 & 0xff);
				m_pWriteBuffer[nOffset+1] = (unsigned char)(0 & 0xff);
			}
			if(bit == 1)
			{
				m_pWriteBuffer[nOffset] = (unsigned char)(5 & 0xff);
				m_pWriteBuffer[nOffset+1] = (unsigned char)(0 & 0xff);
			}
		}
		m_EtherCat->writeByte(m_nMacID, m_pWriteBuffer);
		return true;

	}
	/*if(channelNum == 332 )  // BV LocalRemoteWCh
	{
		DigitalParam* dp = &(m_deviceParam.m_Output.m_vDOParam.at(nIndex));
		int nOffset = dp->m_nByteOffset;

		if(bit == 1)  //REMOTE
		{
			m_pWriteBuffer[nOffset] = (unsigned char)(0x10);
			m_EtherCat->writeByte(m_nMacID, m_pWriteBuffer);
			usleep(1000*1000);
			m_pWriteBuffer[nOffset] = (unsigned char)(0x00);
		}
		if(bit == 2)  //Locked
		{
			m_pWriteBuffer[nOffset] = (unsigned char)(0x01);
		}
		m_EtherCat->writeByte(m_nMacID, m_pWriteBuffer);
		return true;

	}*/

	//only support 2 byte 16bit
	if (dp->m_nBitOffset > 16)
	{
		throw IOException(" bit offset need less than 8, support 2 byte");
	}
	
	if (dp->m_nByteSize == 2 && dp->m_nBitOffset > 8)//high 8 bit
	{
		if (bit == 1)
		{
			m_pWriteBuffer[dp->m_nByteOffset + 1] |= (0x01 << (dp->m_nBitOffset - 9));//set 1
		}
		else
		{
			m_pWriteBuffer[dp->m_nByteOffset + 1] &= (~(0x01 << (dp->m_nBitOffset - 9)));//set 0	
		}

	}
	else if (dp->m_nBitOffset > 0 && dp->m_nBitOffset <= 8)//low 8 bit
	{
		if (bit == 1)
		{
			m_pWriteBuffer[dp->m_nByteOffset] |= (0x01 << (dp->m_nBitOffset - 1));//set 1
		}
		else
		{
			m_pWriteBuffer[dp->m_nByteOffset] &= (~(0x01 << (dp->m_nBitOffset - 1)));//set 0	
		}
	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, " the Byte > 2 !");
		return false;
	}
	
	m_EtherCat->writeByte(m_nMacID, m_pWriteBuffer);
	return true;
}
bool EtherCatPLC_V300Gi::readBit(int channelNum, int *bit, const IntTypeInfo &typeInfo)
{
	int nIndex = channelNum;

	DigitalParam* dp = &(m_deviceParam.m_Input.m_vDIParam.at(nIndex));
	int nType = dp->m_nType;

	//only support 2 byte(16bit) or 1 byte(8bit) to read
	if (dp->m_nBitOffset > 16)
	{
		throw IOException(" bit offset need less than 16, support 1 or 2 byte");
	}

    //m_EtherCat->readByte(m_nMacID, m_pReadBuffer);   //changed by wzd 1.1.65 hotfix4

	/*if(channelNum == 125) // BV ControlMode
	{
		int bitTemp = m_pReadBuffer[dp->m_nByteOffset];
		*bit = bitTemp;
		return true;
	}
	if(channelNum == 126)  //BV local/remote
	{
		int bitTemp = m_pReadBuffer[dp->m_nByteOffset];
		int bit7 = (bitTemp & (0x01 << 6)) != 0 ? 1 : 0;
		int bit8 = (bitTemp & (0x01 << 7)) != 0 ? 1 : 0;
		if(bit7==0 && bit8== 0)
		{
			*bit = 0;
		}
		if(bit7==1 && bit8== 0)
		{
			*bit = 1;
		}
		if(bit7==0 && bit8== 1)
		{
			*bit = 2;
		}
		return true;
	}*/

	//1 byte handle
	if (dp->m_nByteSize == 1 && dp->m_nBitOffset < 9)
	{
		int bitTemp = m_pReadBuffer[dp->m_nByteOffset];
		*bit = (bitTemp & (0x01 << (dp->m_nBitOffset - 1))) != 0 ? 1 : 0;
		return true;
	}

	//2 byte handle
	if (dp->m_nByteSize == 2 && dp->m_nBitOffset < 17)
	{
		int datalow = (m_pReadBuffer[dp->m_nByteOffset] & 0xff); // low 8 byte
		int datahigh = (m_pReadBuffer[dp->m_nByteOffset + 1] & 0xff);// high 8 byte
		int data = ((datahigh << 8) | datalow);
		*bit = (data >> (dp->m_nBitOffset - 1)) & 0x01;

		return true;
	}
	return false;
}

bool EtherCatPLC_V300Gi::readAnalog(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	int nIndex = channelNum - m_channelSize*2;

	AnalogParam* ap = &(m_deviceParam.m_Input.m_vAIParam.at(nIndex));
	int nType = ap->m_nType;
    //bool flag = m_EtherCat->readByte(m_nMacID, m_pReadBuffer);   //changed by wzd 1.1.65 hotfix4
	
	double pdValue = 0.0;
	
	if(1 == nType || 2 == nType)//sint || usint
	{
		unsigned char cByte[1];
		memcpy(cByte, m_pReadBuffer + ap->m_nByteOffset, 1);
		int data = (cByte[0] & 0xff);
		pdValue = (double)data;
	}
	else if(3 == nType || 4 == nType || 7 == nType)//int || uint || word
	{
		unsigned char cByte[2];
		memcpy(cByte, m_pReadBuffer + ap->m_nByteOffset, 2);
		short sTempValue = (short)(((cByte[1] & 0xff) << 8) | (cByte[0] & 0xff));
		pdValue = (double)sTempValue;
	}
	else if(5 == nType || 6 == nType || 8 == nType)//dint || udint || dword
	{
		unsigned char cByte[4];
		memcpy(cByte, m_pReadBuffer + ap->m_nByteOffset, 4);
		int data1 = (cByte[0] & 0xff);
		int data2 = (cByte[1] & 0xff);
		int data3 = (cByte[2] & 0xff);
		int data4 = (cByte[3] & 0xff);
		
		int data = (data4 << 24) |(data3 << 16) |(data2 << 8) | data1;
		pdValue = (double)data;
	}
	else if(9 == nType)//real
	{
		unsigned char cByte[4];
		memcpy(cByte, m_pReadBuffer + ap->m_nByteOffset, 4);
		pdValue = *(float*)&cByte;
		
		/*if(450 == channelNum ||401 == channelNum)
		{
			pdValue = floor(pdValue * 10000.000f + 0.5)/10000.000f;

			int nMaxGasFlow = typeInfo.getMax();
			if(pdValue > nMaxGasFlow)
			{
				pdValue = nMaxGasFlow;				
			}
		}
		if(451 == channelNum)
		{
			int nMaxGasFlow = typeInfo.getMax();
			if(pdValue > nMaxGasFlow)
			{
				pdValue = nMaxGasFlow;				
			}
		}*/
	}	


	double dTempValue = pdValue*(ap->m_dMax - ap->m_dMin)/ap->m_dRange +ap->m_dMin;
	*value = MathTool::Round(dTempValue,typeInfo.getAccuracy());//[zhangcx v1.1.52]
	//*value = dTempValue;

	return true;
}

bool EtherCatPLC_V300Gi::writeAnalog(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
	int nIndex = channelNum - m_channelSize*3;

	AnalogParam* ap = &(m_deviceParam.m_Output.m_vAOParam.at(nIndex));
	int nOffset = ap->m_nByteOffset;
	int nType = ap->m_nType;
	
	if(channelNum == 1569 || channelNum == 1570)//PV need set ControlMode-Pressure/Position
	{
		DigitalParam* dp = &(m_deviceParam.m_Output.m_vDOParam.at(662-m_channelSize));
		int nOffset = dp->m_nByteOffset;
		if(channelNum == 1569)  //presureSP
		{
			m_pWriteBuffer[nOffset] = (unsigned char)(5 & 0xff);
		}
		if(channelNum == 1570)  //positionSP
		{
			m_pWriteBuffer[nOffset] = (unsigned char)(2 & 0xff);
		}
		//m_EtherCat->writeByte(m_nMacID, m_pWriteBuffer);
	}

	//double dTempValue = pdValue*(ap->m_dMax - ap->m_dMin)/ap->m_dRange +ap->m_dMin;
	//AnalogParam temp = m_EtherCatDevice[nMacID].m_Output.m_vAOParam.at(nVectorIndex);	
	double dTempValue = (value - ap->m_dMin)*ap->m_dRange/(ap->m_dMax - ap->m_dMin);
    //cout<<dTempValue<<endl;    //changed by wzd 1.1.65 hotfix4
	if(1 == nType || 2 == nType)//sint || usint
	{
		m_pWriteBuffer[nOffset] = ((int)dTempValue & 0xff);
	}
	else if(3 == nType || 4 == nType || 7 == nType)//int || uint || word
	{
		m_pWriteBuffer[nOffset] = ((int)dTempValue & 0xff);	
		m_pWriteBuffer[nOffset+1] = (((int)dTempValue >> 8) & 0xff);
		//cout<<m_pWriteBuffer[nOffset] <<","<<m_pWriteBuffer[nOffset+1]<<endl;
	}
	else if(5 == nType || 6 == nType || 8 == nType)//dint || udint || dword
	{
		m_pWriteBuffer[nOffset] = ((int)dTempValue & 0xff);	
		m_pWriteBuffer[nOffset+1] = (((int)dTempValue >> 8) & 0xff);	
		m_pWriteBuffer[nOffset+2] = (((int)dTempValue >> 16) & 0xff);	
		m_pWriteBuffer[nOffset+3] = (((int)dTempValue >> 24) & 0xff);
	}
	else if(9 == nType)//real
	{
		unsigned char msg[4];

		FloatToByte(dTempValue, msg);

		m_pWriteBuffer[nOffset] = msg[0];
		m_pWriteBuffer[nOffset+1] = msg[1];
		m_pWriteBuffer[nOffset+2] = msg[2];
		m_pWriteBuffer[nOffset+3] = msg[3];	
	}
	
	m_EtherCat->writeByte(m_nMacID, m_pWriteBuffer);

	return true;
}

bool EtherCatPLC_V300Gi::writeInt(int channelNum, int Value, const IntTypeInfo &typeInfo)
{
	int nIndex = channelNum - m_channelSize*3;
	AnalogParam* ap = &(m_deviceParam.m_Output.m_vAOParam.at(nIndex));
	int nType = ap->m_nType;

	if(2 == nType || 3 == nType)//  2Byte
	{
		int nOffset = ap->m_nByteOffset;
		/*if((channelNum == 202|| channelNum == 203) &&(m_nodeNum == 100 ||m_nodeNum == 101 || m_nodeNum == 102 ))
		{
			Value = Value*10;
		}
		if(channelNum == 336)
		{
			if(Value == 1) //BRF Multi Level Pulse
			{
				m_pWriteBuffer[nOffset] = (unsigned char)(0x09 & 0xff);
			}
			if(Value == 0)
			{
				m_pWriteBuffer[nOffset] = (unsigned char)(0x00);
				m_EtherCat->writeByte(m_nMacID, m_pWriteBuffer);
				usleep(100*1000);
				m_pWriteBuffer[nOffset] = (unsigned char)(0x01 & 0xff);
			}
			m_EtherCat->writeByte(m_nMacID, m_pWriteBuffer);
			return true;
		}*/
		//if(channelNum == 1575 || channelNum == 1576 || channelNum == 1584)
		//{
			//Value = Value * 10;
		//}
		m_pWriteBuffer[nOffset] = (unsigned char)(Value & 0xff);
		m_pWriteBuffer[nOffset+1] = (unsigned char)((Value>>8) & 0xff);
		m_EtherCat->writeByte(m_nMacID, m_pWriteBuffer);
		return true;
	}

	if(6 == nType)//dint || udint || dword
	{
		int nOffset = ap->m_nByteOffset;
		m_pWriteBuffer[nOffset] = ((int)Value & 0xff);	
		m_pWriteBuffer[nOffset+1] = (((int)Value >> 8) & 0xff);	
		m_pWriteBuffer[nOffset+2] = (((int)Value >> 16) & 0xff);	
		m_pWriteBuffer[nOffset+3] = (((int)Value >> 24) & 0xff);
		m_EtherCat->writeByte(m_nMacID, m_pWriteBuffer);
		return true;
	}

	if(9 == nType)
	{
		int nOffset = ap->m_nByteOffset;
		unsigned char msg[4];
		FloatToByte(Value, msg);
		m_pWriteBuffer[nOffset] = msg[0];
		m_pWriteBuffer[nOffset+1] = msg[1];
		m_pWriteBuffer[nOffset+2] = msg[2];
		m_pWriteBuffer[nOffset+3] = msg[3];
		m_EtherCat->writeByte(m_nMacID, m_pWriteBuffer);
		return true;
	}

	return false;

}
bool EtherCatPLC_V300Gi::readInt(int channelNum, int *Value, const IntTypeInfo &typeInfo)
{
	int nIndex = channelNum - m_channelSize*2;

	AnalogParam* ap = &(m_deviceParam.m_Input.m_vAIParam.at(nIndex));
	int nType = ap->m_nType;
	int nOffset = ap->m_nByteOffset;
	//only support 2 byte(16bit) or 1 byte(8bit) to read
	//cout<<"nOffset "<<nOffset<<endl;
	//if (nOffset > 16)
	//{
		//throw IOException(" bit offset need less than 16, support 1 or 2 byte");
	//}

    //m_EtherCat->readByte(m_nMacID, m_pReadBuffer);   //changed by wzd 1.1.65 hotfix4

	if(2 == nType || 3 == nType)//  2Byte
	{

		unsigned char cByte[2];
		memcpy(cByte, m_pReadBuffer + nOffset, 2);
		int TempValue = (int)(((cByte[1] & 0xff) << 8) | (cByte[0] & 0xff));
		/*if((channelNum == 3|| channelNum == 4) &&(m_nodeNum == 100 ||m_nodeNum == 101 || m_nodeNum == 102 ))
		{
			TempValue =TempValue/10;
		}*/
		//if(channelNum == 1101 || channelNum == 1102 || channelNum == 1113)
		//{
			//TempValue = TempValue/10;
		//}
		*Value = TempValue;
		return true;
	}
	return false;
}

bool EtherCatPLC_V300Gi::readEcatStatus(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)    //changed by wzd 1.1.65 hotfix4
{
    try
    {
        bool bFlag = false;
        bFlag = m_EtherCat->readByte(m_nMacID, m_pReadBuffer);
        if(bFlag)
        {
            *pValue = 1;
        }
        else
        {
            *pValue = 0;
        }
    }
    catch(...)
    {
        *pValue = 0;
    }
    return true;
}

void EtherCatPLC_V300Gi::initChs(DeviceNode<EtherCatBaseDevice> *node)
{
	for(int i = 0; i < 0+(m_deviceParam.m_Input.m_vDIParam).size(); ++i)
	{
		//cout<<"m_vDIParam size "<<(m_deviceParam.m_Input.m_vDIParam).size()<<endl;
		DigitalParam* dp = &(m_deviceParam.m_Input.m_vDIParam.at(i));
		int nType = dp->m_nType;
		if(nType == 2)
		{
			node->registerReadCh(i, &EtherCatBaseDevice::readInt);
		}
		else
		{
			node->registerReadCh(i, &EtherCatBaseDevice::readBit);
		}
	}
    node->registerReadCh(10000, &EtherCatBaseDevice::readEcatStatus);      //changed by wzd 1.1.65 hotfix4
	for(int i = m_channelSize; i < m_channelSize+(m_deviceParam.m_Output.m_vDOParam).size(); ++i)
	{
		int nIndex = i - m_channelSize;
		//cout<<"m_vDOParam size "<<(m_deviceParam.m_Output.m_vDOParam).size()<<endl;
		//cout<<"m_channelSize size "<<m_channelSize<<endl;
		DigitalParam* dp = &(m_deviceParam.m_Output.m_vDOParam.at(nIndex));
		int nType = dp->m_nType;
		if(nType == 2)
		{
			node->registerWriteCh(i, &EtherCatBaseDevice::writeInt);
		}
		else
		{
			node->registerWriteCh(i, &EtherCatBaseDevice::writeBit);
		}
	}
	for(int i = m_channelSize*2; i < m_channelSize*2+(m_deviceParam.m_Input.m_vAIParam).size(); ++i)
	{
		if(i == 1101 || i==1102 || i==1113 || i==1091)
		{
			node->registerReadCh(i, &EtherCatBaseDevice::readInt);
		}
		else
		{
			node->registerReadCh(i, &EtherCatBaseDevice::readAnalog);
		}
	}
	for(int i = m_channelSize*3; i < m_channelSize*3+(m_deviceParam.m_Output.m_vAOParam).size(); ++i)
	{
		if((i >=1514 && i <=1521) || (i>=1575 && i<=1586 && i!= 1578) || i == 1694)  // add by zyj for LVC [1.4.0_HotFix2]
		{
			node->registerWriteCh(i, &EtherCatBaseDevice::writeInt);
		}
		else
		{
			node->registerWriteCh(i, &EtherCatBaseDevice::writeAnalog);
		}
	}

	//node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &EtherCatBaseDevice::getStatus);//added by mujy[v1.0.8]

}

void EtherCatPLC_V300Gi::setChannelSize(int channelNum)
{
	if(channelNum < 0)
	{
		throw ConfigException("IODevice: illegal channelNum");
	}
	m_channelSize = channelNum;
}
IMPLEMENT_DYNAMIC(EtherCatPLC_V300Gi, EtherCatPLC_E300Ge )
BEGIN_MSG_MAP( EtherCatPLC_V300Gi, EtherCatPLC_E300Ge )

SET_I( setChannelSize, EtherCatPLC_V300Gi )

END_MSG_MAP
