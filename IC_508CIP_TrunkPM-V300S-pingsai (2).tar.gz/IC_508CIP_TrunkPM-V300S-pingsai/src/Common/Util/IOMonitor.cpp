/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: IOMonitor.cpp
** Description: 
** Release: 
** Modification history: 
** 					2015-07-01  lvjw  create 
**      			2018-10-16  lvjw	cover bug:exit has err.
***************************************************************************/

#include "IOMonitor.h"
#ifdef IAP4_0
#include "ITime.h"
#else
#include "Time.h"
#endif
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "InvalidNameException.h"
#endif
#include "ConfigException.h"
#include "ObjectManager.h"
#include "DataSource.h"
#include "DataTarget.h"
#include "DefaultIOMonitorLogThread.h"
#include "StringValueInfo.h"
#include "DoubleValueInfo.h"
#include "AlarmReNameManager.h"
#include "SysLogger.h"

#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
using namespace IAP::IO;
#endif
using namespace std;

IOMonitor::IOMonitor():Subscriber(IO::UNKNOWN)
{
	m_pThread=NULL;
	
	m_bAutoStart = true;

	m_sMonitorUp = new MonitorUp;
	m_sMonitorUp->setOwner(this);
	
	m_sMonitorDown = new MonitorDown;
	m_sMonitorDown->setOwner(this);
	m_bThreadStarted=false;
	m_strMode=VALUE_CHANGE;
	m_UpdataTimer =NULL;
	m_nUpdataTimeInterval=200;//ms
	
	m_bDefaultThread=false;
}

IOMonitor::~IOMonitor()
{
	if(m_bDefaultThread)
	{
		if(m_UpdataTimer)
		{
			m_UpdataTimer->stop();
			m_UpdataTimer->unsubscribe(this);	
			#ifndef IAP4_0
			delete m_UpdataTimer;
			m_UpdataTimer = NULL;
			#endif

		}
		if(m_pThread)
		{
			m_pThread->toExit();
			//pThread->detach();the process which was created as detach 
			delete m_pThread;
			m_pThread=NULL;
		}
	}
}

void IOMonitor::startup()//added by mujy [1.2]
{
	if(m_bAutoStart)
	{
		cout<<"IOMonitor start......"<<endl;
		do_MonitorUp();
		cout<<"IOMonitor start successfully!"<<endl;
	}
}

void IOMonitor::make()
{
	//string strPreName = AlarmReNameManager::getInstance()->GetShowName(getName());
	//m_QueueTooLongAlarm = new NonBlockingAlarm(strPreName +  "_QueueTooLongAlarm", strPreName + " Queue Too Long", strPreName + " Queue Too Long", Alarm::FATAL);
	//m_QueueTooLongAlarm->addRecovery(new Recovery("Acknowledge Queue Too Long", Recovery::CLEAR));
}

void IOMonitor::addData(MonitorData * pData)
{
	IMutexLocker locker(&m_DataQueueMutex);
	m_Data.push(pData);
	if(m_Data.size()>1000)
	{
		//m_QueueTooLongAlarm->post(this);
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getSelfName() + ": Monitor data queue is too long !");	
		
	}
}

void IOMonitor::getData(MonitorData &data) 
{
	IMutexLocker locker(&m_DataQueueMutex);
	
	MonitorData* pData;
	if(!(m_Data.empty()))
	{
		pData = m_Data.front();
		data = *pData;
		m_Data.pop();
		delete pData;
		pData = NULL;
		
	}
	else
	{
		data.strName = "";
	}
}

void IOMonitor::setLogPath(const std::string &strPath)
{
	m_strLogPath=strPath;
}

void IOMonitor::addMonitorIO(const std::string &strPath)//Node & channel????
{
	ManagedObject *obj = NULL;
	try
	{
		obj = ObjectManager::getInstance()->getObject(strPath);
	}
	catch(const InvalidNameException &e)
	{
		obj = ObjectManager::getInstance()->getObject(this,strPath);
	}
	UntypedData * pIO = dynamic_cast<UntypedData*>(obj);
	if(NULL == pIO)
	{
		string error = "the object under path '" + strPath + "' is not a ReadWriteInt";
		throw ConfigException(error);
	}
	list<UntypedData*>::iterator it;
	for(it = m_IOList.begin() ;it != m_IOList.end() ;it++)
	{
		if(*it == pIO)
		{
			return;
		}
	}
	m_IOList.push_back(pIO);
	/*
	if(it == m_IOList.end())
	{
		m_IOList.push_back(pIO);
	}
	*/
}

void IOMonitor::update(UntypedData *data, const ValueInfo &value)
{
	UntypedData *pData=dynamic_cast<UntypedData*>(data);
	if(pData)
	{
		MonitorData *pMonitorData=new MonitorData();
		pMonitorData->strName  = pData->getName();//added by mujy [1.2]
		if(pData->getAccessMode()==IO::READ_ONLY)
		{
			pMonitorData->nNodeNum		=((ReadOnlyData*)pData)->getDataSource()->getNodeNum();
			pMonitorData->nChannelNum	=((ReadOnlyData*)pData)->getDataSource()->getChannelNum();
		}
		else
		{
			pMonitorData->nNodeNum		=((ReadWriteData*)pData)->getDataTarget()->getNodeNum();
			pMonitorData->nChannelNum	=((ReadWriteData*)pData)->getDataTarget()->getChannelNum();
		}
		switch (value.getDataType())
		{
			case IO::INTDATA:
			{
				IntValueInfo * pIntValueInfo= new IntValueInfo((IntValueInfo &)value);
				pMonitorData->pValueInfo		=pIntValueInfo;
				break;
			}
			case IO::STRINGDATA:
			{
				StringValueInfo * pStringValueInfo= new StringValueInfo((StringValueInfo &)value);
				pMonitorData->pValueInfo		=pStringValueInfo;
				break;
			}
				
			case IO::DOUBLEDATA:
			{
				DoubleValueInfo * pDoubleValueInfo= new DoubleValueInfo((DoubleValueInfo &)value);
				pMonitorData->pValueInfo		=pDoubleValueInfo;
				break;
			}
				
			default: //impossible
				break;
		}
		#ifdef IAP4_0
		pMonitorData->TimeStamp=ITime::getCurrentTimeAsStr();
		#else
		pMonitorData->TimeStamp=Time::getCurrentTimeAsStr();
		#endif
		if(VALUE_CHANGE==m_strMode)
		{
			addData(pMonitorData);
		}
	}	
}

#ifdef IAP4_0
void IOMonitor::updateFromTimer(const Timer * const timer)
#else
void IOMonitor::updateFromTimer()
#endif
{
	//cout<<"updateFromTimer"<<endl;
	list<UntypedData*>::iterator it; 
	
	for(it = m_IOList.begin() ; it != m_IOList.end() ; ++it)
	{
		UntypedData *pData = *it;
		MonitorData *pMonitorData=new MonitorData();
		pMonitorData->strName  = pData->getName();//added by mujy [1.2]
		if(pData->getAccessMode()==IO::READ_ONLY)
		{
			pMonitorData->nNodeNum		=((ReadOnlyData*)pData)->getDataSource()->getNodeNum();
			pMonitorData->nChannelNum	=((ReadOnlyData*)pData)->getDataSource()->getChannelNum();
		}
		else
		{
			pMonitorData->nNodeNum		=((ReadWriteData*)pData)->getDataTarget()->getNodeNum();
			pMonitorData->nChannelNum	=((ReadWriteData*)pData)->getDataTarget()->getChannelNum();
		}
		int nTemp=pData->getDataType();
		switch (nTemp)
		{
			case IO::INTDATA:
				{
					IntValueInfo * pIntValueInfo= new IntValueInfo();
					pData->getValueInfo(*pIntValueInfo);
					pMonitorData->pValueInfo		=pIntValueInfo;
					break;
				}

			case IO::STRINGDATA:
				{
					StringValueInfo * pStringValueInfo= new StringValueInfo();
					pData->getValueInfo(*pStringValueInfo);
					pMonitorData->pValueInfo		=pStringValueInfo;
					break;
				}
				
			case IO::DOUBLEDATA:
				{
					DoubleValueInfo * pDoubleValueInfo= new DoubleValueInfo();
					pData->getValueInfo(*pDoubleValueInfo);
					pMonitorData->pValueInfo		=pDoubleValueInfo;
					break;
				}
				
			default: //impossible
				break;
		}
		
		#ifdef IAP4_0
		pMonitorData->TimeStamp=ITime::getCurrentTimeAsStr();
		#else
		pMonitorData->TimeStamp=Time::getCurrentTimeAsStr();
		#endif
		
		if(TIME_INTERVAL==m_strMode)
		{
			addData(pMonitorData);
		}
	}
}

void IOMonitor::MonitorUp::execute()
{
	IOMonitor *owner = dynamic_cast<IOMonitor*>(getOwner());
	
	if(NULL != owner)
	{
		owner->do_MonitorUp();
	}
}

void IOMonitor::MonitorDown::execute()
{
	IOMonitor *owner = dynamic_cast<IOMonitor*>(getOwner());
	
	if(NULL != owner)
	{
		owner->do_MonitorDown();
	}
}

void IOMonitor::setLogThread(IOMonitorLogThread * pThread)
{
	m_pThread=pThread;
}

void IOMonitor::setLogThreadCh(std::string &strPath)
{
	ManagedObject *obj = NULL;
	try
	{
		obj = ObjectManager::getInstance()->getObject(strPath);
	}
	catch(const InvalidNameException &e)
	{
		obj = ObjectManager::getInstance()->getObject(this,strPath);
	}
	m_pThread = dynamic_cast<IOMonitorLogThread*>(obj);
	string error = getName() + "can't get Thread";
	if(NULL == m_pThread)
	{
		throw ConfigException(error);
	}
}

void IOMonitor::startThread()
{
	m_bThreadStarted=true;
	if(!m_pThread)
	{
		m_pThread= new DefaultIOMonitorLogThread();
		m_bDefaultThread=true;
	}
	m_pThread->setLogPath(m_strLogPath);
	m_pThread->setIOMonitor(this);
	#ifdef IAP4_0
	m_pThread->start(IAP::CORE::IThread::PRIORITY_NORMAL, IAP::CORE::IThread::CREATE_DETACHED); 
	#else
	m_pThread->start(PRIORITY_NORMAL, CREATE_DETACHED); 
	#endif
}

void IOMonitor::do_MonitorUp()
{
	//turn on the thread
	//cout<<m_pThread->getThreadState()<<endl;//judge by this maybe better???if shutdown monitor just suspend the thread.
	if(m_bThreadStarted)
	{
		//pThread->
	}
	else
	{
		startThread();
	}
		
	if(VALUE_CHANGE==m_strMode)
	{
		cout<<VALUE_CHANGE<<endl;
		//subscribe
		list<UntypedData*>::iterator it;
		for (it = m_IOList.begin(); it != m_IOList.end(); ++it)
		{
			UntypedData* pIO=*it;
			if(pIO && !pIO->checkSubscriberExist(this))
			{
				pIO->subscribe(this);
			}
		}
	}
	else
	{
		cout<<TIME_INTERVAL<<endl;
		if(!m_UpdataTimer)
		{
			m_UpdataTimer=new Timer(m_nUpdataTimeInterval);
		}
		m_UpdataTimer->subscribe(this);
		m_UpdataTimer->start();
	}
}

void IOMonitor::do_MonitorDown()
{
	//to do thread deal??
	//subscribe
	if(VALUE_CHANGE==m_strMode)
	{
		list<UntypedData*>::iterator it;
		for (it = m_IOList.begin(); it != m_IOList.end(); ++it)
		{
			UntypedData* pIO=*it;
			if(pIO && pIO->checkSubscriberExist(this))
			{
				pIO->unsubscribe(this);
			}
		}
	}
	else
	{
		if(m_UpdataTimer)
		{
			m_UpdataTimer->stop();
			m_UpdataTimer->unsubscribe(this);	
		}
	}
}

void IOMonitor::setAutoStart(bool bFlag)//added by mujy [1.2]
{
	m_bAutoStart = bFlag;
}

void IOMonitor::setMode(string &strMode)
{
	if(strMode ==TIME_INTERVAL || strMode==VALUE_CHANGE)
	{
		m_strMode=strMode;
	}
}

void IOMonitor::setUpdataTimeInterval(int nInterval)//ms
{
	m_nUpdataTimeInterval=nInterval;
}

IMPLEMENT_DYNAMIC_SERVICE(MonitorUp, IOMonitor)
IMPLEMENT_DYNAMIC_SERVICE(MonitorDown, IOMonitor)

BEGIN_SERVICEINFO_LIST(IOMonitor)
	ADD_SERVICE_INFO(IOMonitor, MonitorUp, Monitor turn Up)
	ADD_SERVICE_INFO(IOMonitor, MonitorDown, Monitor turn Down)
END_SERVICEINFO_LIST(IOMonitor)

IMPLEMENT_DYNAMIC(IOMonitor, ControlObject)
BEGIN_MSG_MAP( IOMonitor, ControlObject)
	SET_S(addMonitorIO, IOMonitor)
	SET_S(setLogPath, IOMonitor)
	SET_S(setLogThreadCh, IOMonitor)
	SET_B(setAutoStart, IOMonitor)//added by mujy [1.2]
	SET_S(setMode, IOMonitor)
	SET_I(setUpdataTimeInterval, IOMonitor)
END_MSG_MAP
