/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
**                     Feb 22, 2008  shenql  create
**                     2025-08-15 modify by taohao[v1.5.0_HotFix] for obtain the recipe from the memory
***************************************************************************/
#ifndef OPERATIONALPROCESS_H_
#define OPERATIONALPROCESS_H_

#include "ControlObjectEX.h"
#include "BlockingAlarm.h"
#include "ReadWriteInt.h"
#include "ReadWriteString.h"
#include "ReadWriteDouble.h"
#include "AppCondition.h"
#include "RecipeNamespaceManager.h"
#include "RecipeNameInfo.h"
#include "FunctionalProcessInterface.h"
#include "OverrunInterlock.h"
#include "Service.h"
#include "RecipeUser.h"
#include "Timer.h"
#include "CounterTimer.h"
#include "ControlObjectEX.h"
#include "OperationalModel.h"
#include "AppRecipeManager.h"
#include "NonBlockingAlarm.h"
#include "PVSetSkipRow.h"//added by dangw[1.4.0_HotFix7]
#ifdef IAP4_0
using namespace IAP::ALARM;
using namespace IAP::IO;
using namespace IAP::CONDITION;
using namespace IAP::RECIPE;
using namespace IAP::INTERLOCK;
using namespace IAP::CONTROL;
using namespace IAP::CORE;
#endif
class OperationalModel;

class OperationalProcess : public ControlObjectEX, public RecipeUser
{
	DECLARE_DYNAMIC( OperationalProcess )
	DECLARE_MSG_MAP

	DECLARE_SERVICEINFO_LIST
	
public:
	class Prepare : public Service
	{
		DECLARE_DYNAMIC_SERVICE(Prepare)
			
		public:
			
			void execute();
	};
	
	class Process : public Service
	{
		DECLARE_DYNAMIC_SERVICE(Process)
			
		public:
			Process();  //add by wzd 1.1.39
			void execute();
	};

	class CalculateLearn : public Service//added by liusy[1.1.52]
	{
		DECLARE_DYNAMIC_SERVICE(CalculateLearn)

		public:
			void execute();
	};

	public://constructor
		OperationalProcess();
		virtual ~OperationalProcess();

	public://service
		void call_Prepare(const RecipeNameInfo &recipenameparam);
		void call_Process();
		void call_CalculateLearn(const RecipeNameInfo& recipenameparam, int step = 1);//added by liusy[1.1.52]

		virtual bool do_Process();
		virtual bool do_Prepare(const std::string &recipeID);
		virtual bool do_CalculateLearn(const std::string& recipeID, int step = 1);//added by liusy[1.1.52]

		virtual bool do_AutoPVLearn(const std::string& recipeID);//[zhangcx v1.4.0_hotfix7]
		bool needAutoPVLearn();

	public://xml
		void setSlotNumber(int i);
		void setTheProcessStr(std::string &strPath);
		void setProcessingSpell(std::string &strSpell);//add for code merging

	public://override
		virtual void make();
		virtual void initialize();
		virtual void verifyInit();
		virtual void startup();
		virtual void shutdown();

	protected://for override
		virtual bool do_PrepareForProcessingMaterial();
		virtual void do_PrepareRecipe(const std::string &s);
		virtual bool do_ProcessMaterial();
		virtual bool do_SetupAndProcessMaterial();
		virtual void clearRecipeInfo();
		virtual void initRecipeInfo();
		virtual double calculateProcessTime();		
		virtual int calculateStepNum(); //add by wzd 1.1.21
		virtual void clearRecipeInfoAbortOrProcessEnd();//add by zhangpf[v1.11.1]

	protected:
		ReadWriteInt *m_pStepNum;
		ReadWriteInt *m_pStepID;
		ReadWriteInt* m_pFlagstepId; //C1 Learn //added by liusy[1.1.52]
		ReadWriteDouble *m_pStepTime;
		ReadWriteDouble *m_pStepWaitTime;//added by xiasc for 508M time test
		ReadWriteDouble *m_pRFStableTime;
		ReadWriteDouble *m_pRealStepTime;

		ReadWriteDouble *m_pElapsedStepTime;
		ReadWriteDouble *m_pElapsedFullStepTime;
		ReadWriteDouble *m_pElapsedProcessTime;
		
		ReadWriteInt *m_pProcessCanelled;
		ReadWriteString *m_pRecipeName;
		ReadWriteString *m_pRecipeClass;
		ReadWriteString *m_pRecipeVersion;
		ReadWriteString *m_pStepName;
		BlockingAlarm *m_pRecipeNotExist;
		BlockingAlarm *m_pVerifyRecipeFailed; //[ chenmz v1.1.1 ]
		BlockingAlarm *m_pProcessRecipeEmpty;

		ReadWriteInt *m_pSlotSts;
		ReadWriteInt *m_pSlotState;
		ReadWriteInt *m_pSlotAnm;

		ReadWriteDouble *m_pRecipeTimeLeft;
		ReadWriteDouble *m_pProcessTime;
		ReadWriteDouble *m_pMaxProcessTime;//added by mujy [V1.0.0.2]
		ReadWriteDouble *m_pMaxProcessTimeTolerance;//added by mujy [V1.0.0.2]
		int m_nSlotNumber;

		FunctionalProcessInterface *m_pFuncProcess;
		OperationalModel *m_pProcessModule;
	
		ReadWriteInt *m_pIsUseThickness;//added by mujy [v1.5.17]
		ReadWriteInt *m_pIsUseTime;//added by mujy [v1.5.17]
		ReadWriteDouble *m_pWaferThickness;//added by mujy [v1.5.17]

		ReadWriteInt * m_pProcessMode;

		std::map<int, PVSetSkipRow> m_mapPVSetDatas;//[zhangcx v1.4.0_hotfix7]

		NonBlockingAlarm* m_nPVLearnPressureNotStable;

	public:
		
		ServicePtr<Prepare> m_sPrepare;
		ServicePtr<Process> m_sProcess;
		ServicePtr<CalculateLearn> m_sCalculateLearn;//added by liusy[1.1.52]

		string m_sRcpName;//added by liusy[1.1.52]

		string m_strProcessingSpell;////add for code merging. PMStatusInfo and PMAnmInfo have spelling mistake [Processing or Processng]
};
#endif /*OPERATIONALPROCESS_H_*/
