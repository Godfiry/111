/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: CTCExport.cpp
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-03-03   LiJuanjuan create
**      
*********************************************************************/
#include "CTCExport.h"
#include "ObjectManager.h"
#include "SysLogger.h"
#include <iostream>
#include <fstream>
#include "ConfigException.h"
#ifdef IAP4_0
using namespace IAP::CORE;
#endif
using namespace std;

string CTCExport::m_exportNode = "/TMCExports/";

string CTCExport::m_objectNode = "/Control/"; //guojin 1.1.48
string CTCExport::m_dataNode = "/IO/";
string CTCExport::m_commonPath = "Exports/";
CTCExport::CTCExport()
{	
	m_sPrint = new Print();
	m_sPrint->setOwner(this);
}

CTCExport::~CTCExport()
{
}

void CTCExport::initialize()
{
	ControlObject::initialize();
	map<std::string, string>::iterator it = m_mapExportData.begin();
	for(;it != m_mapExportData.end(); ++it)
	{
		ManagedObject *obj = ObjectManager::getInstance()->getObject(it->first);
		UntypedData * pIO = dynamic_cast<UntypedData*>(obj);
		if(pIO == NULL)
		{
			throw ConfigException("the object under path '" + it->first + "' is not a UntypedData");
		}
		exportToCTC(pIO,it->second);
	}
}
void CTCExport::Print::execute()
{

	CTCExport *pOwner = dynamic_cast<CTCExport*>(getOwner());
	if(pOwner != NULL)
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT,pOwner->getName()+": do_Print start");
		pOwner->do_Print();
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT,pOwner->getName()+": do_Print end.");
	}
}

void CTCExport::call_Print()
{
	call(m_sPrint);
}

void CTCExport::do_Print()
{
	ofstream in;
	in.open("ExportDatas.txt",ios::trunc);
	vector<string> vectorExports;
	ObjectManager::getInstance()->getNodeNamesUnder(m_exportNode+"Datas",vectorExports);
	string strExportDatas = m_exportNode+"Datas";
	in<<strExportDatas<<" TotalSize="<<vectorExports.size()<<endl;
	for(int i = 0; i < vectorExports.size(); i++)
	{
		in<<vectorExports[i]<<endl;
		//cout<<vectorExports[i]<<endl;
	}
}

std::string CTCExport::getExportNode()
{
	return m_exportNode;
}

void CTCExport::setExportNode(const std::string &name)
{
	m_exportNode = name;
}

void CTCExport::exportToCTC(ManagedObject *obj)
{
	ObjectManager::getInstance()->createAlias(obj->getName(), m_exportNode + "/Controls/" + obj->getSelfName());
}

void CTCExport::exportToCTC(ManagedObject *obj, const std::string &alias)
{
	ObjectManager::getInstance()->createAlias(obj->getName(), m_exportNode  + "/Controls/" + alias);
}

void CTCExport::exportToCTC(ManagedObject *obj, const std::string &modulename, const std::string &alias)
{
	ObjectManager::getInstance()->createAlias(obj->getName(), "/Controls/" + modulename + m_commonPath + alias);
}

void CTCExport::exportToCTC(UntypedData *data)
{
	ObjectManager::getInstance()->createAlias(data->getName(), m_exportNode + "/Datas/" + data->getSelfName());
	ObjectManager::getInstance()->createAlias(data->getName(),   "/IO/Datas/" + data->getSelfName());
}

void CTCExport::exportToCTC(UntypedData *data, const std::string &alias)
{
	if(data->getName() != "")
	{
		ObjectManager::getInstance()->createAlias(data->getName(), m_exportNode + "/Datas/" + alias);
	}
	else
	{
		ObjectManager::getInstance()->registerObject(data, m_exportNode + "/Datas/" + alias);
	}
	ObjectManager::getInstance()->createAlias(data->getName(),   "/IO/Datas/" + alias);
}

void CTCExport::exportToCTC(UntypedData *data, const std::string &modulename, const std::string &alias)
{
	if(data->getName() != "")
	{
		ObjectManager::getInstance()->createAlias(data->getName(), m_dataNode + modulename + m_commonPath + alias);
	}
	else
	{
		ObjectManager::getInstance()->registerObject(data, m_dataNode + modulename + "/Datas/" + alias);
		ObjectManager::getInstance()->createAlias(data->getName(), m_dataNode + modulename + m_commonPath + alias);
	}
	//ObjectManager::getInstance()->createAlias(data->getName(),   "/IO/Datas/" + modulename + m_commonPath + alias);
}

void CTCExport::exportAsOthers(UntypedData *data)
{
	exportToCTC(data);
}

void CTCExport::exportAsOthers(UntypedData *data, const std::string &alias)
{
	exportToCTC(data, alias);
}

void CTCExport::exportAsOthers(UntypedData *data, const std::string &modulename, const std::string &alias)
{
	exportToCTC(data, modulename, alias);
}


void CTCExport::setExportToCTC(string strSourceDataPath,string strAliasName)
{
	m_mapExportData.insert(pair<string, string>(strSourceDataPath, strAliasName));
}

std::string CTCExport::getControlPath()
{
	return m_exportNode + "/Controls/";
}

std::string CTCExport::getOthersPath()
{
	return m_exportNode + "/Datas/";
}

IMPLEMENT_DYNAMIC_SERVICE(Print, CTCExport)

BEGIN_SERVICEINFO_LIST(CTCExport)
	ADD_SERVICE_INFO(CTCExport, Print, Print )
END_SERVICEINFO_LIST(CTCExport)

IMPLEMENT_DYNAMIC(CTCExport, ControlObject)
	
BEGIN_MSG_MAP( CTCExport, ControlObject )
	SET_S(setExportNode, CTCExport)
	SET_SS(setExportToCTC, CTCExport)
END_MSG_MAP
