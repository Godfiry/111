#include "AlarmGetter.h"
#include "AlarmResource.h"
#include "XmlGetter.h"

AlarmGetter::AlarmGetter()
{
}

AlarmGetter::~AlarmGetter()
{
}

Alarm* AlarmGetter::getAlarm(std::string strAlarmResourceName , AlarmPoster* pPoster)
{
	Alarm* pResult=NULL;
	AlarmResource * pAlarmResource=XmlGetter::getFromNamespace<AlarmResource*>(ALARM_PRE_PATH+strAlarmResourceName);
	pResult=pAlarmResource->buildAlarm(pPoster);
	return pResult;
}

BlockingAlarmEX* AlarmGetter::getBlockingAlarmEX(std::string strAlarmResourceName , AlarmPoster* pPoster)
{
	BlockingAlarmEX* pResult=dynamic_cast<BlockingAlarmEX*>(getAlarm(strAlarmResourceName,pPoster));
	if(pResult==NULL)
	{
		throw strAlarmResourceName+" is not BlockingAlarmEX";
	}
	return pResult;
}

NonBlockingAlarmEX* AlarmGetter::getNonBlockingAlarmEX(std::string strAlarmResourceName , AlarmPoster* pPoster)
{
	NonBlockingAlarmEX* pResult=dynamic_cast<NonBlockingAlarmEX*>(getAlarm(strAlarmResourceName,pPoster));
	if(pResult==NULL)
	{
		throw strAlarmResourceName+" is not NonBlockingAlarmEX";
	}
	return pResult;
}
