/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					2011-10-20  lijj  create 
**      
***************************************************************************/

#include "SafetyActionWrapper.h"

SafetyActionWrapper::SafetyActionWrapper(CustomSafetyActionInterface* owner)
{
	m_owner = owner;
}

SafetyActionWrapper::~SafetyActionWrapper()
{
}

void SafetyActionWrapper::execute(OverrunInterlock* valueinterlock)
{
	m_owner->execute(valueinterlock);
}
		
bool SafetyActionWrapper::isTimeConsuming() const
{
	return false;
}
		
std::string SafetyActionWrapper::toString() const
{
	return "SafetyActionWrapper";
}		
