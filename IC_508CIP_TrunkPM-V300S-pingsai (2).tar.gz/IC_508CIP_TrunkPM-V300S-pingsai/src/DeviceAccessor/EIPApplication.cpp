/********************************************************************
** Copyright (c) 2019 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: EIPApplication.cpp
** Description:  
** Release: 1.0
** Modification history:           
** 					2019-06-05   Duq create
**                                                 2020-06-03   Duq update
*********************************************************************/

#include "EIPApplication.h"
#include "RegiserEIPApplication.h"
#include <iostream>
#include <unistd.h>
using namespace std;

static map<string, EIPApplication*> EIPTable;

EIPApplication* EIPApplication::getEIP(string &server, uint16_t configId, uint16_t inputId, uint16_t outputId, unsigned int cycleTime, std::string &error)
{
	map<string, EIPApplication*>::iterator it = EIPTable.find(server);
	EIPApplication* m_eip = NULL;
	if(it == EIPTable.end())
	{
		m_eip = new EIPApplication(server, configId, inputId, outputId);
		bool result = m_eip->initDevice(error, cycleTime);
		if(result)
		{
			EIPTable[server] = m_eip;
		}
		else
			m_eip = NULL;
	}
	else
	{
		m_eip = it->second;
	}
	return m_eip;
}

EIPApplication::EIPApplication(std::string &server, uint16_t configId, uint16_t inputId, uint16_t outputId)
{
	m_inputSize = 0;
	m_outputSize = 0;
	m_server = server;
	m_inputInstanceId = inputId; 
	m_outputInstanceId = outputId;
	m_configInstanceId = configId;
	m_remotedevice = NULL;
	startflag = false;
}

EIPApplication::~EIPApplication()
{

}

void EIPApplication::ApplicationInitialization()
{
    //create EnIPRemoteDevice
	m_remotedevice = new EnIPRemoteDevice(m_configInstanceId, m_inputInstanceId, m_outputInstanceId, m_server);
}

bool EIPApplication::do_RegisterSession()
{
	bool result = m_remotedevice->do_RegisterSession();
	return result;
}

void EIPApplication::do_UnRegisterSession()
{
	m_remotedevice->do_UnRegisterSession();
}

bool EIPApplication::do_ForwardOpen(unsigned int cycleTime)
{
	return m_remotedevice->do_ForwardOpen(cycleTime);
}

bool EIPApplication::do_ForwardClose()
{
	return m_remotedevice->do_ForwardClose();
}

void EIPApplication::do_ReadClass1Data(char * data, int len)
{
	m_remotedevice->do_ReadClass1Data(data, len);
}

bool EIPApplication::getBytesInputsData(int offset, int len, void *value)
{
	if((len == 1) || (len == 2) || (len == 4) || (len == 8))
	{
		return m_remotedevice->getBytesInputsData(offset, len, value);
	}
	else
		return false;
}

bool EIPApplication::setBytesOutputsData(int offset, int len, void *value, bool flag)
{
	if(flag)
	{
		if((len != 1) && (len != 2) && (len != 4) && (len != 8))
			return false;
	}
	return m_remotedevice->setBytesOutputsData(offset, len, value, flag);//flag = true: len --- byte, false : len --- bit
}

bool EIPApplication::getAttributDataSize()
{
	bool result = m_remotedevice->do_GetDataSize();
	if(result)
	{
		m_inputSize = m_remotedevice->m_inputPocketSize;
		m_outputSize = m_remotedevice->m_outputPocketSize;
		//cout<<"m_inputSize: "<<m_inputSize<<endl;
		//cout<<"m_outputSize: "<<m_outputSize<<endl;
	}
	return result;
}

bool EIPApplication::initDevice(string &error, unsigned int cycleTime)
{
	//create objects
	ApplicationInitialization();
	
	//RegisterSession
	if(!do_RegisterSession())
	{
		error = "RegisterSession illegal, m_server is " + m_server;
		return false;
	}
	
	//get Attributs data size
	if(!getAttributDataSize())
	{
		error = "getAttributeDataSize illegal, m_server is " + m_server;//modify by mujy [1.2.0] for word spell
		return false;
	}	
	
	//send packets
	bool result = do_ForwardOpen(cycleTime);
	//cout<<"result: "<<result<<endl;
	if(!result)
	{
		error = "ForwardOpen illegal, m_server is " + m_server;
		return false;
	}
	
	RegiserEIPApplication::getInstance()->do_RegiserEIPApplication(m_server, this);
	startflag = true;
	usleep(10000);
	return true;
}

void EIPApplication::shutdownDevice()
{
	if(startflag)
	{
		RegiserEIPApplication::getInstance()->do_UnRegiserEIPApplication(m_server);
	
		//cout<<"EIPApplication::shutdownDevice() start of closing connection"<<endl;
		//close connection
		do_ForwardClose();
		
		//UnRegisterSession
		do_UnRegisterSession(); 
		startflag = false;
		//cout<<"EIPApplication::shutdownDevice() end of closing connection"<<endl;
	}

	if(m_remotedevice != NULL)
	{
		delete m_remotedevice;
		m_remotedevice = NULL;
	}
}
