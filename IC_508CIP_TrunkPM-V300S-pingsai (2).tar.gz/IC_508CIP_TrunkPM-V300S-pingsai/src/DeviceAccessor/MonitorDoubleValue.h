/********************************************************************
** Copyright (c) 2018, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MonitorDoubleValue.h
** Description: Monitor channel double value
** Release: 1.0
** Modification history:
**                  2025-3-25   Dangw create
*********************************************************************/
#ifndef MONITORDOUBLEVALUE_H_
#define MONITORDOUBLEVALUE_H_

#include "CBase.h"
#include "IntTypeInfo.h"
#include <map>
#ifdef IAP4_0
using namespace IAP::IO;
#endif

enum EValueChange
{
    VALUE_UNCHANGED = 0,
    VALUE_CHANGED = 1
};

class CMonitorDoubleValue
{
    public:
        CMonitorDoubleValue();
        virtual ~CMonitorDoubleValue();

        void initAccuracy(double dAccuracy);
        void initDoubleValue(int nChannelNum, double dValue);
        void setDoubleValue(int nChannelNum, double dValue, double dAccuracy);
        void clearDoubleMonitor();

        virtual bool readDoubleChange(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);
        void setLog(bool bEnable);

    private:
        bool isDoubleValueExist(int nChannelNum);
        bool isDoubleEqual(double dValueA, double dValueB, double dAccuracy);

    private:
        std::map<int, double> m_mapValue;   // channel, double data
        std::map<int, bool> m_mapUnChange;  // channel, bool data
};

#endif /*MONITORDOUBLEVALUE_H_*/
