/*
 * FineTunningItem.cpp
 *
 *  Created on: 2023-08-29
 *      Author: taohao [1.1.43]
 */
#include "FineTunningItem.h"
#include "XmlGetter.h"
#include "MapTool.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "InvalidNameException.h"
#endif
#include "ConfigException.h"
#include "SysLogger.h"
//#include "Converter.h"
#include <string>
#ifdef IAP4_0
using namespace IAP;
using namespace IAP::CORE;
#endif

FineTunningItem::FineTunningItem()
{
    m_cfgFineTunningType = NULL;
    m_RFPowerMode = true;
}

FineTunningItem::~FineTunningItem()
{

}

void FineTunningItem::setRcpIntOffset(string sRcpParamName,int offset)
{
    m_rcpIntOffset[sRcpParamName] = offset;
}

void FineTunningItem::setRcpDoubleOffset(string sRcpParamName,double offset)
{
    m_rcpDoubleOffset[sRcpParamName] = offset;
    /*
    map<string,double>::iterator it;
    for(it = m_rcpDoubleOffset.begin();it != m_rcpDoubleOffset.end();it++)
    {
        cout<< "m_rcpDoubleOffset key is "<< it->first<<"  value is " <<it->second<<endl;
    }
    */
}

void FineTunningItem::setRFRunMode(bool bRFMode)
{
    m_RFPowerMode = bRFMode;
}

double FineTunningItem::getTunningValue(string sStpParamName)
{
    double dFTO_Setup = 0;//FTO=FineTunningOffset
    double dFTO_Recipe = 0;

    //cout<< " sStpParamName.substr(0,sStpParamName.length()-3)  "<< sStpParamName.substr(0,sStpParamName.length()-3) << endl;
    dFTO_Recipe = m_rcpDoubleOffset[sStpParamName.substr(0,sStpParamName.length()-3)+"Rcp"];

    //cout<<"dFTO_Recipe  is  :"<<dFTO_Recipe<<endl;
    try
    {
        m_cfgFineTunningType = static_cast<ReadWriteInt*>(ObjectManager::getInstance()->getObject("/SETUP/FineTunning/FineTunningType"));
    }
    catch(InvalidNameException ex)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ":no config: FineTunningType "+ex.what());
    }

    if(m_cfgFineTunningType != NULL)
    {
        if(m_cfgFineTunningType->getValue() == 2 || m_cfgFineTunningType->getValue() == 3)
        {
            if(sStpParamName == "RFPowerOffSetStp" && m_RFPowerMode)
            {
                return 0;
            }
            dFTO_Setup = m_tunningCh[sStpParamName]->getValue();
        }

        //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "  " + sStpParamName + "  RecipeOffset is " + dFTO_Recipe + " SetupOffset is " + dFTO_Setup);
        return dFTO_Setup + dFTO_Recipe;
    }
	else
	{
		return 0;//zhangyy add for sonar test[1.6.0]
	}
}

void FineTunningItem::setSetupTunningCh(const string StrName,const string &StrPath)
{
    ReadWriteDouble * pRWDouble = XmlGetter::getFromNamespace<ReadWriteDouble*>(StrPath);
    if(!MapTool::addToMap<string,ReadWriteDouble *>(m_tunningCh,StrName,pRWDouble))
    {
        throw "Double Object repeat added:"+StrName;
    }
}

IMPLEMENT_DYNAMIC(FineTunningItem, ControlObject)

BEGIN_MSG_MAP( FineTunningItem, ControlObject)
    SET_SS(setSetupTunningCh, FineTunningItem)
END_MSG_MAP
