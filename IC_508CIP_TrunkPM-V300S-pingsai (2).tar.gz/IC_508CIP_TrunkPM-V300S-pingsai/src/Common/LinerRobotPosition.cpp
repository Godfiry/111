/*
 * LinerRobotPosition.cpp
 *
 *  Created on: 20210712
 *      Author: lvjiawen
 */

#include "LinerRobotPosition.h"

LinerRobotPosition::LinerRobotPosition()
{
}

LinerRobotPosition::~LinerRobotPosition()
{
}

void LinerRobotPosition::setDOState(vector<int> DoList)
{
	m_DoState=DoList;
}

void LinerRobotPosition::setDIState(vector<int> DIList)
{
	m_DIState=DIList;
}

void LinerRobotPosition::setDO(vector<ReadWriteInt*> DoList)
{
	m_DO=DoList;
}

void LinerRobotPosition::setDI(vector<ReadOnlyInt*> DIList)
{
	m_DI=DIList;
}

void LinerRobotPosition::go()
{
	for(int i=0 ; i<m_DoState.size() ; ++i )
	{
		int nData=m_DoState[i];
		if(nData == 0 || nData == 1)
		{
			m_DO[i]->setValue(nData);
		}
	}
}

bool LinerRobotPosition::isAt()
{
	for(int i=0 ; i<m_DIState.size() ; ++i )
	{
		int nData=m_DIState[i];
		if(nData == 0 || nData == 1)
		{
			if(m_DI[i]->getValue() != m_DIState[i])
			{
				return false;
			}
		}
	}
	return true;
}

void LinerRobotPosition::simulateArrive()
{
	for(int i=0 ; i<m_DIState.size() ; ++i )
	{
		int nData=m_DIState[i];
		if(nData == 0 || nData == 1)
		{
			if(m_DI[i]->isSimulated())
			{
				m_DI[i]->setSimulatedValue(m_DIState[i]);
			}
		}
	}
}
