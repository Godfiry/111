/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					2011-10-20  lijj  create 
**      
***************************************************************************/
#ifndef SAFETYACTIONWRAPPER_H_
#define SAFETYACTIONWRAPPER_H_

#include "SafetyAction.h"
#include "CustomSafetyActionInterface.h"
#ifdef IAP4_0
using namespace IAP::INTERLOCK;
#endif

class SafetyActionWrapper:public SafetyAction
{
	private:
		CustomSafetyActionInterface *m_owner;
		
	public:
		SafetyActionWrapper(CustomSafetyActionInterface* owner);
		
		virtual ~SafetyActionWrapper();

		virtual void execute(OverrunInterlock* valueinterlock);
		
		virtual bool isTimeConsuming() const;
		
		virtual std::string toString() const;		
};

#endif /*SAFETYACTIONWRAPPER_H_*/
