#include <iostream>
#include <string.h>
#include <sys/time.h>
#include <sstream>
#include <cmath>
#include "AEDualMatch2M60M.h"
#include "DeviceManager.h"
#include "Converter.h"
#include "SysLogger.h"
#include "Hex.h"
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;


AEDualMatch2M60M::AEDualMatch2M60M():SerialDevice(100,"")
{
    ack[0] = (char)0x06;
    m_nAddr = 1;
	m_nPreC1 = 0;
	m_nPreC2 = 0;
} 

AEDualMatch2M60M::~AEDualMatch2M60M()
{
}
AEDualMatch2M60M::Com AEDualMatch2M60M::m_commands[] =
						{ {0, 0, 0 },     // 0 reserved
						{4, 0x5D, 4},     // 1 set Control Mode (0x5D == 93), send 1 Byte, Response = 1 CSR only
						{5, 0x70, 4},     // 2 set C1 position (0x70 == 112), send 2 Byte, Response = 1 CSR only
						{5, 0x7A, 4},     // 3 set C2 position  (0x7A == 122), send 2 Byte, Response = 1 CSR only	
						{9, 0x5A, 4},    // 4 store C1&C2 preset (0x5A == 90), send 6 Byte, Response = 1 CSR only
						{4, 0x5B, 4},     // 5 recall C1&C2 preset (0x5B == 91), send 1 Byte, Response = 1 CSR only
						{6, 0x64, 4},     // 6 set delay time(0x64 == 100), send 3 Byte, Response = 1 CSR only 													
						{4, 0x5E, 4},     // 7 enable/disable presets (0x5E == 94), send 1 Byte, Response = 1 CSR only
						{3, 0x7D, 4},     // 8 set Reset (0x7D == 125), send 0 Byte, Response = 1 CSR only		
						
						{3, 0xA3, 4},     // 9 read Control Mode (0xA3 == 163), send 0 Byte, Response = 1 Byte
						{3, 0xB4, 7},	    // 10 read C1 position (0xB4 == 180), send 0 Byte, Response = 4 Bytes
						{3, 0xB4, 7},     // 11 read C2 position (0xB4 == 180), send 0 Byte, Response = 4 Bytes
						{4, 0xAA, 6},		// 12 read delay time(0xAA == 170), send 1 Byte, Response = 3 Bytes
						{3, 0xA4, 4},     // 13 read enable/disable presets (0xA4 == 164), send 0 Byte, Response = 1 Bytes
						{3, 0xFE, 11},    // 14 read fault status(0xFE == 254), send 0 Byte, Response = 8 Bytes
						{3, 0xBA, 7},		// 15 read DC Bias(0xBA == 186), send 0 Byte, Response = 4 Bytes
						}; 
                                                                                        
bool AEDualMatch2M60M::sendCommandAck(char *pMsg, char *pResponse, int nMsg_timeout,int nResplen, int nMsglen)
{
	int nRet = getCommandResult(pMsg, nMsglen, pResponse, nResplen, m_timeOut);
    
	if(pResponse[0] != 0x06 || nRet <= 0)
	{
     cout<<"AEDualMatch2M60M::sendCommandAck response "<<hex<<(int)pResponse[0]<<" "<<(int)pResponse[1]<<" "<<(int)pResponse[2]<<" "<<(int)pResponse[3]<<" "<<(int)pResponse[4]<<endl;
	 throw IOException("Send packet's verification is wrong");
	}
	else if(pResponse[3] != 0x00)
	{     
       cout<<"AEDualMatch2M60M::sendCommandAck response "<<hex<<(int)pResponse[0]<<" "<<(int)pResponse[1]<<" "<<(int)pResponse[2]<<" "<<(int)pResponse[3]<<" "<<(int)pResponse[4]<<endl;
		string strErr = "Response(CSR) codes was not accepted, CSR is ";
		strErr += Converter::convertToString((int)pResponse[3]);
	 	throw IOException(strErr);  
	}
   sendCommandOnly(ack,1); 
   return true;
}

bool AEDualMatch2M60M::readCommand(char *pMsg, char *pResponse, int nMsg_timeout,int nResplen, int nMsglen)
{	
	
	getFixCommandResult(pMsg, nMsglen, pResponse, nResplen, m_timeOut, 2);
   
	if(pResponse[0] != 0x06 )
	{		
		throw IOException("Send packet's verification is wrong");
	}
	sendCommandOnly(ack,1);
	return true;
}

bool AEDualMatch2M60M::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
	if(2 == nChannelNum)
		m_nPreC1 = nValue;
	if(3 == nChannelNum)
		m_nPreC2 = nValue;
		
	Com com = m_commands[nChannelNum];
	
	memset(message, 0, MESS_LEN);
	memset(resp, 0, RESP_LEN);
	message[0] = (char)(com.nCmdLen-3+8*m_nAddr); // m_nAddr left shift 3 bits, data length use the 3 bits
	message[1] = com.cCmdNum;
	int nTempInt;
	switch(com.nCmdLen)
	{
			case 3: // Reset (Channel=8)
				message[2] = message[0]^message[1];
				break;
			case 4:
				if (com.cCmdNum == (char)0x5E // set enable/disable presets(Channel=18)
				|| com.cCmdNum == (char)0x5D)  // set control mode(Channel=1)
				{
					message[2] = (int)nValue&0xff;   //nValue =0(Disble),1(Enable)
					message[3] = message[0]^message[1]^message[2];
				}
				else if (com.cCmdNum == (char)0x5B) // recall preset(Channel=5)
				{
					message[2] = ((int)nValue + 1)&0xff;   //0-3->1-4
					message[3] = message[0]^message[1]^message[2];
				}
				break;	
			case 5:
				if (com.cCmdNum == (char)0x70 || com.cCmdNum == (char)0x7A ) // set C1 or C2 position(Channel=2,Channel=3)
				{
					nTempInt = nValue * 10; //nValue = 0-999->(0-9999 means 0%-99%)
					message[2] = nTempInt&0xff;  //Low 8 bits
					message[3] = (nTempInt>>8)&0xff;  //High 8 bits
					message[4] = message[0]^message[1]^message[2]^message[3];
				}     
		     break;
			case 9: // store (Channel=4)
				message[2] = nValue + 1; // the store-to position (0-3)->(1-4)
				message[3] = 0x00; // trajectory pair 0		 
				nTempInt = m_nPreC1 * 10; // get C1 position to preset
				message[4] = nTempInt&0xff;
				message[5] = (nTempInt>>8)&0xff;		
				nTempInt = m_nPreC2 * 10; // get C2 position to preset
				message[6] = nTempInt&0xff;
				message[7] = (nTempInt>>8)&0xff;
				 
				message[8] = message[0]^message[1]^message[2]^message[3]^message[4]^message[5]^message[6]^message[7];    
				break;
	       	
			default:
				break;
	}
          
	return(sendCommandAck(message, resp, m_timeOut, com.nResLen+1, com.nCmdLen)); // com.nResLen+1 means [ACK + Response]
}

bool AEDualMatch2M60M::readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
	Com com = m_commands[nChannelNum];
	int nTempInt;

	memset(resp, 0, RESP_LEN); 
	memset(message, 0, MESS_LEN);
	message[0] = (char)(com.nCmdLen-3+8*m_nAddr);
	message[1] = com.cCmdNum;
	if(com.nCmdLen == 3) // read ControlMode (Channel=9), read C1(Channel=10)
							// read C2(Channel=11),read enable/disable presets(Channel=13)
							// read fault status(Channel=14), read DC Bias(Channel=15)
	{
		message[2] = message[0]^message[1];
 	}	
	if(com.nCmdLen == 4) // read delay time (Channel=12)
	{
		message[2] = 0x01; // delay time of preset 1 position
    	message[3] = message[0]^message[1]^message[2];	
	}	

  	if(readCommand(message , resp, m_timeOut, com.nResLen+1, com.nCmdLen)) //Response = Ack + Header + Cmd + Data +CheckSum
  	{
  		switch(nChannelNum) // resp[0]= ACK; resp[1]= Header; resp[2]= Cmd;
  		{	     
  	     	case 9: // read mode (response = 4 Byte)		
     			nTempInt = (int)resp[3] & 0xff; 
     			*pValue = nTempInt;
     			break;	     		
  	     	case 10: //read C1 (response = 4 Byte)
     			nTempInt = ((((int)resp[4]&0x00ff)<<8)&0xff00) + ((int)resp[3]&0xff);
     			*pValue = nTempInt/10;
    			break; 	     	
  	     	case 11: //read C2 (response = 4 Byte)
     			nTempInt = (((int)(resp[6]&0x00ff)<<8)&0xff00) + ((int)resp[5]&0xff);
     			*pValue = nTempInt/10;
    			break;	 	    			
  	    	case 12: //read delay time of preset 1 positon with 0 pair trajectories  (response = 3 Byte) 		
     			nTempInt = (int)resp[5]&0xff;
     			*pValue = nTempInt;	 
    			break;		
  	    	case 13: //read enable/disable presets (response = 1 Byte)
    			nTempInt = (int)resp[3]&0xff;
     			*pValue = nTempInt;	 
    			break;				
  	    	default:	 
  	    		break;			
  		}
  		return true;
  	}
    return false;
}

bool AEDualMatch2M60M::writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
	Com com = m_commands[nChannelNum];
	
	memset(message, 0, MESS_LEN);
	memset(resp, 0, RESP_LEN);
	message[0] = (char)(com.nCmdLen-3+8*m_nAddr); // m_nAddr left shift 3 bits, data length use the 3 bits
	message[1] = com.cCmdNum;

	switch(com.nCmdLen)
	{
			case 6: // set delay time  (Channel=6) phy layer match has no preset positon, so only use 1
				message[2] = 0x01;  // preset number 1
				message[3] = 0x00;  // initial preset delay only
				message[4] = (int)(dValue * 100)&0xff; //%(s)  250 = 2.5s
				message[5] = message[0]^message[1]^message[2]^message[3]^message[4];
		       break;
		     
			default:
				break;
	}
          
	return(sendCommandAck(message, resp, m_timeOut, com.nResLen+1, com.nCmdLen)); // com.nResLen+1 means [ACK + Response]
}

bool AEDualMatch2M60M::readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo)
{
	Com com = m_commands[nChannelNum];
	int nTempInt;

	memset(resp, 0, RESP_LEN); 
	memset(message, 0, MESS_LEN);
	message[0] = (char)(com.nCmdLen-3+8*m_nAddr);
	message[1] = com.cCmdNum;
	if(com.nCmdLen == 3) //read DC Bias(Channel=15)
	{
		message[2] = message[0]^message[1];
	}
	
	if(readCommand(message , resp, m_timeOut, com.nResLen+1, com.nCmdLen)) //Response = Ack + Header + Cmd + Data +CheckSum
  	{
  		switch(nChannelNum) // resp[0]= ACK; resp[1]= Header; resp[2]= Cmd;
  		{	       		
  	     	case 15: //read DC Bias (response = 4 Byte)
     			nTempInt = ((((int)resp[6]&0x00ff)<<8)&0xff00) + ((int)resp[5]&0xff);
     			*pValue = double(nTempInt)/1.0;
				break;
  	    	default:	 
  	    		break;			
  		}
  		return true;
  	}	
}

bool AEDualMatch2M60M::readString(int nChannelNum, std::string *strValue, const StringTypeInfo &typeInfo)
{
	Com com = m_commands[nChannelNum];

	memset(resp, 0, RESP_LEN); 
	memset(message, 0, MESS_LEN);
	message[0] = (char)(com.nCmdLen-3+8*m_nAddr);
	message[1] = com.cCmdNum;
	message[2] = message[0]^message[1];
 	
	readCommand(message , resp, m_timeOut, com.nResLen+1, com.nCmdLen);
	string strErrorCode;
	for(int i = com.nResLen - 1; i > 2; i--)
	{
		strErrorCode += Hex::hexToStringFixWidth(resp[i]);
	}
	
	*strValue = strErrorCode;
	
	if (strErrorCode != "0000000000000000")
	{	
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "fault status:"+strErrorCode);
	}

	return true;
}

void AEDualMatch2M60M::InitChannels(DeviceNode<AEDualMatch2M60M> *pNode)
{   

	for(int i = 1; i <= 5; ++i)
	{
		pNode->registerWriteCh(i, &AEDualMatch2M60M::writeInt);
	}
	
	pNode->registerWriteCh(6, &AEDualMatch2M60M::writeDouble);
	
	for(int i = 7; i <= 8; ++i)
	{
		pNode->registerWriteCh(i, &AEDualMatch2M60M::writeInt);
	}
	
	for(int i = 9; i <= 13; ++i)
	{
		pNode->registerReadCh(i, &AEDualMatch2M60M::readInt);
	}
	pNode->registerReadCh(14, &AEDualMatch2M60M::readString);
	pNode->registerReadCh(15, &AEDualMatch2M60M::readDouble);

}

void AEDualMatch2M60M::initDevice()
{
	cout<<"Set AEDualMatch2M60M preset enable"<<endl;
	//say hello to generator
	try
	{
		writeInt(7, 1, IntTypeInfo());
	}
	catch(exception &ex)
	{
		cout<<"Set AEDualMatch2M60M preset enable failed!"<<endl;
		throw;
	}
}
  
void AEDualMatch2M60M::init()
{
	cout<<"AEDualMatch2M60M init start"<<endl;
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "AEDualMatch2M60M start");
	
    DeviceNode<AEDualMatch2M60M> *pNode = new DeviceNode<AEDualMatch2M60M>(200,this);
    if(!isSimulated())
    {
    	InitChannels(pNode);
    	initDevice();
    }
    DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
    
    cout<<"AEDualMatch2M60M end start"<<endl;
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "AEDualMatch2M60M end");
}

void AEDualMatch2M60M::setAddress(int nAddr)
{
   if(nAddr > 0)
    {
    	m_nAddr = nAddr;
    }
   else
	{
		cout<<"***  AEDualMatch2M60M addr config error, Set address to 1."<<endl;
    	m_nAddr = 1;
   	}
}

IMPLEMENT_DYNAMIC(AEDualMatch2M60M, SerialDevice )
BEGIN_MSG_MAP(AEDualMatch2M60M, SerialDevice )
    SET_V( init, AEDualMatch2M60M )
    SET_I( setAddress, AEDualMatch2M60M )
END_MSG_MAP

