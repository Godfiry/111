#ifndef ETHERCATPLC_E300GE_H_
#define ETHERCATPLC_E300GE_H_

#include "EtherCatBaseDevice.h"
#include "DeviceNode.h"



class EtherCatPLC_E300Ge :public EtherCatBaseDevice{

	DECLARE_DYNAMIC(EtherCatPLC_E300Ge)
	DECLARE_MSG_MAP

public:
	EtherCatPLC_E300Ge();//
	virtual ~EtherCatPLC_E300Ge();

	virtual bool readAnalog(int channelNum, double *value, const DoubleTypeInfo &typeInfo);
	virtual bool writeAnalog(int channelNum, double value, const DoubleTypeInfo &typeInfo);
	virtual bool readBit(int channelNum, int *bit, const IntTypeInfo &typeInfo);
	virtual bool writeBit(int channelNum, int bit, const IntTypeInfo &typeInfo);
	virtual bool readInt(int channelNum, int *value, const IntTypeInfo &typeInfo);
	virtual bool writeInt(int channelNum, int value, const IntTypeInfo &typeInfo);
	void setChannelSize(int channelNum);

protected:

	virtual void initChs(DeviceNode<EtherCatBaseDevice> *node);
	int m_channelSize;
};

#endif /* ETHERCATPLC_E300GE_H_ */
