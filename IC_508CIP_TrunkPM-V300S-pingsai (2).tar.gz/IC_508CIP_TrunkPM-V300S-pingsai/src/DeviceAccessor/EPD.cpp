#include "EPD.h"

#include "StrTool.h"
#include "DeviceManager.h"

#include "Hex.h"
#include "SysLogger.h"
#include "Converter.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std;

EPD::Cmd EPD::m_WriteIntCommands[]={
    {"Present",6},
    {"Reset",6},
    {"Test",6},
    {"STR ",12},//Start with recipe
    {"SP",6},//Stop
    {"Complete",6}//Wafer Complete
};

EPD::Cmd EPD::m_WriteStrCommands[]={
    {"",-1},//no use
    {"Lot ",6},//set string
    {"ID ",6}//set string
};

EPD::EPD():SerialDevice(200, "\x0D")
{
    m_timeOut = 1;
    m_pollPeriod = 2000; //2000ms
    m_bDebugMode = false;//normal mode
    m_strACK="";
    m_strError="";
    m_nEpdStatus = 0;//
    m_nEndPoint = 0;
    m_mutex=new IMutex(true);
}

EPD::~EPD()
{
    delete m_mutex;
    m_mutex=NULL;
}

void EPD::logSendCommand(const std::string &strCommand)
{
    if(strCommand.length() > 0)
    {
        CBase::Log_Info(getDeviceName() + " PC->EPD: send command->"+strCommand);
    }
}

void EPD::logRecieveCommand(const std::string &strCommand)
{
    if(strCommand.length() > 0)
    {
        CBase::Log_Info(getDeviceName() + " EPD->PC: receive command->"+strCommand);
    }
}

bool EPD::writeI(int nChannelNum, int value, const IntTypeInfo &typeInfo)
{
    if(m_bDebugMode)
    {
        throw IOException("EPD in Debug Mode, Please Change to normal communication mode!!!");
    }
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::VERBOSE,": action --channel Num = "+Converter::convertToString(nChannelNum));
    if(nChannelNum >= 6 && nChannelNum <= 9)
    {
        return true;
    }
    IMutexLocker locker(m_mutex);
    m_strError="";

    string strCommand = m_WriteIntCommands[nChannelNum].strCommand;
    m_strACK = "NAK";
    if(m_WriteIntCommands[nChannelNum].strCommand.find("STR") != string::npos)
    {
        strCommand += m_strConfigName;
        m_nEndPoint = 0;
    }
    logSendCommand(strCommand);
    sendCommandOnly(strCommand);

    if(m_waitAction.wait(m_mutex, m_WriteIntCommands[nChannelNum].nActionTimeOutS * 1000))
    {
        if(m_strACK != "OK")
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::VERBOSE,getName()+": action has error. "+m_strError);
            throw IOException("EPD ["+strCommand+"] action failed for System or other Instrument error.");
        }
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::VERBOSE,getName()+": action finish.");
    }
    else
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::ERROR,getName()+": wait ACK event time out");
        throw IOException("EPD ["+strCommand+"] action failed for waiting ACK event time out("+Converter::convertToString(m_WriteIntCommands[nChannelNum].nActionTimeOutS)+"s)");
    }
    return true;
}

bool EPD::writeS(int nChannelNum, std::string strValue, const StringTypeInfo &)
{
    if(m_bDebugMode)
    {
        throw IOException("EPD in Debug Mode, Please Change to normal communication mode!!!");
    }
    IMutexLocker locker(m_mutex);
    string strCommand = "";
    switch(nChannelNum)
    {
        case 40: // configname
            m_strConfigName = strValue;
            break;


        case 41: //lot
        case 42: //slot
            m_strACK = "NAK";
            strCommand = m_WriteStrCommands[nChannelNum-40].strCommand;
            strCommand += strValue;
            logSendCommand(strCommand);
            sendCommandOnly(strCommand);

            if(m_waitAction.wait(m_mutex, m_WriteStrCommands[nChannelNum-40].nActionTimeOutS * 1000))
            {
                if(m_strACK != "OK")
                {
                    SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::VERBOSE,getName()+": action has error. "+m_strError);
                    throw IOException("Action failed for System or other Instrument error.");
                }
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::VERBOSE,getName()+": action finish.");
            }
            else
            {
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::ERROR,getName()+": wait ACK event time out");
                throw IOException("Action failed for waiting ACK event time out("+Converter::convertToString(m_WriteIntCommands[nChannelNum].nActionTimeOutS)+"s)");
            }
            break;
        case 43://Wafer
        case 44://Recipe
        case 45://Step
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::VERBOSE,getName()+": set Info - "+strValue);
            break;
    }
    return true;
}

bool EPD::readS(int nChannelNum, std::string *pValue, const StringTypeInfo &)
{
    if(m_bDebugMode)
    {
        throw IOException("EPD in Debug Mode, Please Change to normal communication mode!!!");
    }
    IMutexLocker locker(m_mutex);
    string strConfigList = "";
    switch(nChannelNum)
    {
        case 30: // error
            *pValue = m_strError;
            break;

        case 31: //configure list
            logSendCommand("GCL");
            strConfigList = getCommandResult("GCL",60);
            StrTool::string_replace(strConfigList,"\x0A",",");
            logRecieveCommand(strConfigList);
            *pValue = strConfigList;
            break;
        case 32://version
            *pValue = "Unknown";
            break;
    }
    return true;
}

bool EPD::readI(int nChannelNum, int *pValue, const IntTypeInfo &)
{
    if(m_bDebugMode)
    {
        throw IOException("EPD in Debug Mode, Please Change to normal communication mode!!!");
    }
    IMutexLocker locker(m_mutex);
    switch(nChannelNum)
    {
        case 10://epdstatus
            *pValue = m_nEpdStatus;
            break;
        case 11: //EndPoint
            *pValue = m_nEndPoint;
            break;
    }
    return true;
}

bool EPD::readD(int nChannelNum, double *value, const DoubleTypeInfo &typeInfo)
{
    if(m_bDebugMode)
    {
        throw IOException("EPD in Debug Mode, Please Change to normal communication mode!!!");
    }
    IMutexLocker locker(m_mutex);
    double dValue = 0.0;
    switch(nChannelNum)
    {
        case 20://EpdTime
            *value = 0;
            break;
        case 21:
            dValue = m_dTrendData;
            *value = MathTool::Round(dValue,typeInfo.getAccuracy());
            break;
        case 22:
        case 23:
        case 24:
        case 25:
        case 26:
            *value = 0;
            break;
    }
    return true;
}

void EPD::run()
{
    while(true)
    {
        string strData=getResultOnly(m_timeOut);
        if(strData!="")
        {
            Subpackage(strData);
        }
        usleep(100);
    }
}

void EPD::OnReadACK(string &strData)
{
    m_strACK="OK";
    m_waitAction.wakeAll();
}

void EPD::OnReadErr(string &strData)
{
    m_strError=strData;
    m_waitAction.wakeAll();
}

void EPD::OnReadTrendData(string &strData)
{
    vector<string> result=StrTool::split(strData," ");
    if(result.size() > 2)
    {
        Converter::stringToDouble(m_dTrendData,result[1]);
    }
    else
    {
        m_dTrendData = 0;
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::VERBOSE,getName()+": trend data invalid.");
    }
}
void EPD::Subpackage(string &strData)
{
    vector<string> result=StrTool::split(strData,"\x0D");
    for(int i = 0 ; i <result.size() ; ++i)
    {
        dealWithMsg(result[i]);
    }
}

void EPD::dealWithMsg(string &strData)
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::VERBOSE,getName()+": receive"+strData);
    if(m_bDebugMode)
    {
        CBase::Log_Show("EPD Device->PC: " + strData,false);
        return;
    }
    IMutexLocker locker(m_mutex);

    if(strData.find("oes") != string::npos)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":EPD got event Trend Data "+strData);
        OnReadTrendData(strData);
    }
    else if(strData.find("ERROR") != string::npos)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":EPD got event ERROR");
        m_nEpdStatus = 3;//NotReady
        OnReadErr(strData);
    }
    else if(strData.find("NRD") != string::npos)
    {
        m_nEpdStatus = 3;//NotReady
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":EPD got event NOTREADY");
    }
    else if(strData.find("RD") != string::npos)
    {
        m_nEpdStatus = 2;//Ready
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":EPD got event READY");
    }
    else if(strData.find("RUNNING") != string::npos)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":EPD got event RUNNING");
    }
    else if(strData.find("Reset") != string::npos || strData.find("ST") != string::npos || strData.find("SP") != string::npos || strData.find("Test") != string::npos || strData.find("Lot") != string::npos || strData.find("ID") != string::npos || strData.find("PRESENT") != string::npos)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":EPD got event "+strData);
        OnReadACK(strData);
    }
    else if(strData.find("EPT") != string::npos)
    {
        m_nEndPoint = 1;//reach endpoint
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":EPD got event ENDPOINT");
    }
    else
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::ERROR,getName()+": dealWithMsg - unexpected response "+strData);
    }
}

bool EPD::changeDebugMode(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)//0:Normal Mode;1:Debug Mode
{
    if(nValue == 0)
    {
        CBase::Log_Show("EPD change to Normal Communication Mode!!!",false);
    }
    else
    {
        CBase::Log_Show("EPD change to Debug Mode!!!",false);
    }

    m_bDebugMode = nValue;
    return true;
}
bool EPD::writeRawCmd(int nChannelNum, std::string strCommand, const StringTypeInfo &typeInfo)
{
    if(!m_bDebugMode)
    {
        throw IOException("EPD not in Debug Mode, Please Change to debug mode!!!");
    }
    CBase::Log_Show("EPD PC->Device: "+strCommand,false);
    sendCommandOnly(strCommand);
    return true;
}

void EPD::initDevice()
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::VERBOSE,getName()+": send FSR FC=0 !");
    cout<<"start scan EPD..."<<endl;
    string strCfgList;
    try
    {
        readS(31,&strCfgList,StringTypeInfo());
    }
    catch(exception &ex)
    {
        throw IOException("Say hello to EPD failed for "+string(ex.what()));
    }
    cout<<"scan EPD successfully"<<endl;
}
void EPD::init()
{
    DeviceNode<EPD> *node = new DeviceNode<EPD>(m_pollPeriod,this);
     initChs(node);
     DeviceManager::getInstance()->registerNode(m_nodeNum, node);
     if(!isSimulated())
     {
        initDevice();
         start();
     }
}

void EPD::initChs(DeviceNode<EPD> *pNode)
{
    for (int i = 0; i <= 9; i++)
    {
        pNode->registerWriteCh(i,&EPD::writeI);
    }

    for (int i = 10; i <= 11; i++)
    {
        pNode->registerReadCh(i,&EPD::readI);
    }

    for (int i = 20; i <= 26; i++)
    {
        pNode->registerReadCh(i,&EPD::readD);
    }

    for (int i = 30; i <= 32; i++)
    {
        pNode->registerReadCh(i,&EPD::readS);
    }
    for (int i = 40; i <= 45; i++)
    {
        pNode->registerWriteCh(i,&EPD::writeS);
    }
    pNode->registerReadCh(COMMUNICATION_STATUS_CHANNEL,&EPD::getStatus);
}
IMPLEMENT_DYNAMIC(EPD, SerialDevice )
BEGIN_MSG_MAP( EPD, SerialDevice )
    SET_V(init,EPD)
END_MSG_MAP
