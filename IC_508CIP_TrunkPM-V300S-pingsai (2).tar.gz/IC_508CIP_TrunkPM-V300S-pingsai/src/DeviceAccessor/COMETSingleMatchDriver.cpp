/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: COMETSingleMatchDriver.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					
**                  2014-11-21   lijj	create
*********************************************************************/
#include "COMETSingleMatchDriver.h"
#include "DeviceManager.h"

#include "IStringList.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std; 

COMETSingleMatchDriver::ParamPair COMETSingleMatchDriver::m_paramPairs[] = {ParamPair("manaut",DescriptorList("3,1"))};//0="3"="manual" 1="1"="auto"
										 
map<string,DescriptorList> COMETSingleMatchDriver::m_params = map<string,DescriptorList>(m_paramPairs, m_paramPairs+1);

COMETSingleMatchDriver::Com COMETSingleMatchDriver::m_commands[] = {{0, ""}, //0	reserved 						
											{0, "Mode3", 0},//1 (CH,value)manual
											{0, "Mode1", 0},//2 auto
											{0, "Rest", 0},//3 fault reset
											{2, "SP",0},  //4 save preset
											{2, "G",0},  //5 goto preset																	
											{1, "Load", 0},//6 set c1
											{1, "Tune", 0},//7 set c2		
											{1, "C3Pos", 0},//8 set c3   C3Pos##.#								
											
											{1, "QMode", 0},//9 get Manual/Auto
											{3, "QP3C", 1},//10 get c1
											{3, "QP3C", 2},//11 get c2
											{3, "QP3C", 3},//12 get c3
{2,"QP##",1},//13 get c1 another cmd
{2,"QP##",2},//14 get c2  another cmd
{3,"QP3C",3},//15 get c3  another cmd, return##.#
{2, "GP",0},//16 GP## where ## corresponds to 00-15
{2, "C3Mode", 0},//17 set c3 manual commond,such as C3Mode#   (#=1:Auto  #=2:AutoHold  #=3:Manual  #=4:Hold)
{1, "QC3Mode", 0}//18 get c3 manual commond,reply #> (#=1:Auto  #=2:AutoHold  #=3:Manual  #=4:Hold)
}; 

COMETSingleMatchDriver::COMETSingleMatchDriver()
{
}

COMETSingleMatchDriver::~COMETSingleMatchDriver()
{
}

bool COMETSingleMatchDriver::writeInt(int channelNum, int value, const IntTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	int ps = com.m_ps;
	char format[5]={0};
	double t_c = 0.0;
	string msg = "";
	switch(ps)
	{
		case 0:
			//msg = com.m_s1;
			msg = m_commands[channelNum + value].m_s1;
			break;
		case 1:
			t_c = value / 10.0;		
			sprintf(format,"%04.1f",t_c);
			msg = com.m_s1 + format;
			break;
		case 2:
		   if(channelNum == 16)
		   {
		   		string strValue =  Converter::convertToString(value);
		   		if(strValue.size()==1)
		   		{
		   			msg = com.m_s1 +"0"+ Converter::convertToString(value);
		   		}
		   		else
		   		{
		   			msg = com.m_s1 + Converter::convertToString(value);
		   		}
		   }
		   else if(channelNum == 17)
		   {
		   	if(value == 0)
		   	{
		   		value = 3;//#=1:Auto  #=3,Manual
		   	}
		   		msg = com.m_s1 + Converter::convertToString(value);
		   }
		   else
		   {
		   		msg = com.m_s1 + Converter::convertToString(value);
		   }
		   break;	
	}
	return sendCommand(msg, m_timeOut);
}
		
bool COMETSingleMatchDriver::writeRawCommand(int channelNum, std::string value, const StringTypeInfo &typeInfo)
{
	return sendCommand(value, m_timeOut);
}
		
bool COMETSingleMatchDriver::readInt(int channelNum, int *value, const IntTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	string res = readCommand(com.m_s1, m_timeOut);
	
	std::vector<std::string> t_vlist = IStringList::split(res, ",");
	double tmp = 0;
	double tmp1 = 0;

	if(t_vlist.size() != com.m_ps && t_vlist.size() > 4)
	{
		throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for response ["+Hex::GetHexString(res.c_str(),res.size())+"] is invalid.");
	}
	
	if(channelNum == 15)
	{
		//cout<<"send ="<<com.m_s1<<" response = "<<res<<endl;
		double t_dvalue = 0;
		if(!Converter::stringToDouble(t_dvalue, res))
		{
			throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for can't convert response ["+Hex::GetHexString(res.c_str(),res.size())+"] to double value.");
		}
		tmp = (double)(t_dvalue * 10);//modified by chenmz [V2.0.4]
		tmp1 = (int)tmp;
		*value = tmp1;
		return true;
	}

	if(t_vlist.size() == 1)
	{
		if(channelNum == 18)
		{
			res = res.substr(0,1);
		}
		*value = m_params["manaut"].getDescriptorValue(res);	
	}
	if(t_vlist.size() > 1)
	{
		string t_svalue = t_vlist[com.m_ps2 -1];
		double t_dvalue = 0;
		if(!Converter::stringToDouble(t_dvalue, t_svalue))
		{
			throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for can't convert response ["+t_svalue+"] to double value.");
		}
		//*value = (int)(t_dvalue * 10);
		tmp = (double)(t_dvalue * 10);//modified by chenmz [V2.0.4]
		tmp1 = (int)tmp;
		*value = tmp1;
	}
	return true;
}

void COMETSingleMatchDriver::initChs(DeviceNode<COMETSingleMatchDriver> *node)
{
	node->registerWriteCh(0, &COMETSingleMatchDriver::writeRawCommand);
	for(int i = 1; i <= 8; ++i)
	{
		node->registerWriteCh(i, &COMETSingleMatchDriver::writeInt);
	}
	for(int i = 9; i <= 15; ++i)
	{
		node->registerReadCh(i, &COMETSingleMatchDriver::readInt);
	}
	node->registerWriteCh(16, &COMETSingleMatchDriver::writeInt);	
	node->registerWriteCh(17, &COMETSingleMatchDriver::writeInt);
	node->registerReadCh(18, &COMETSingleMatchDriver::readInt);	
	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &COMETSingleMatchDriver::getStatus);//added by mujy [v1.0.8]
}

void COMETSingleMatchDriver::initDevice()
{
	cout<<"Start Scan COMET Single Match...."<<endl;
	//say hello to match
	int nTemp;
	try
	{
		readInt(9,&nTemp,IntTypeInfo());//9 get Manual/Auto
	}
	catch(exception &ex)
	{
		cout<<"Scan COMET Single Match first failed. Try again!"<<endl;
	}
	try
	{
		readInt(9,&nTemp,IntTypeInfo());//9 get Manual/Auto
	}
	catch(exception &ex)
	{
		cout<<"Scan COMET Single Match failed. Communication abnormal!"<<endl;
		throw;
	}
	cout<<"Scan COMET Single Match Successfully...."<<endl;
}
		
void COMETSingleMatchDriver::init()
{
	DeviceNode<COMETSingleMatchDriver> *node = new DeviceNode<COMETSingleMatchDriver>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	if(!isSimulated())
	{
		initChs(node);		
		initDevice();
	}
}

IMPLEMENT_DYNAMIC(COMETSingleMatchDriver, COMETMatchDriver )
BEGIN_MSG_MAP(COMETSingleMatchDriver, COMETMatchDriver )
    SET_V( init, COMETSingleMatchDriver )
END_MSG_MAP

