/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: PCICard.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-12-04   LiJuanjuan create
**      
*********************************************************************/
#ifndef PCICARD_H_
#define PCICARD_H_

#include "AbstractDevice.h"
#include "dask.h"
#include "DeviceNode.h"
#include "ReadWriteDouble.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class PCICard:public AbstractDevice
{
    DECLARE_DYNAMIC(PCICard)	
    DECLARE_MSG_MAP
    
	private:
		unsigned short m_cardNum;
		short m_cardID;
		unsigned short m_cardType;
		int m_nodeNum;
		int m_pollInterval;
		int m_filterInterval;
		double m_dcardVoltage;//added by taohao[1.1.30]
		std::map<int,std::string> m_mapSpecialChlName;//added by xiasc[20180321]

		typedef struct
		{
			std::string name;
			ReadWriteDouble* value;
			double sum;   //channel value sum
			int count;
			double lastValue;
		}FilterInfo;
		std::map<int, FilterInfo> m_filterChannels; //added by mayc[20201018]

		typedef struct
		{
			double dMax;
			double dMin;
		}ScopeInfo;

		std::map<int, ScopeInfo> m_ScopeChannels; //added by liusy[1.1.22]

	protected:
		void initCard();
		void initChannel();
		void init7432(DeviceNode<PCICard> *node);
		void init7433(DeviceNode<PCICard> *node);
		void init7434(DeviceNode<PCICard> *node);
		void init6208(DeviceNode<PCICard> *node);
		void init9116(DeviceNode<PCICard> *node);
        	
	public:
		PCICard();
		virtual ~PCICard();
		
		bool read7432(int channelNum, int *value ,const IntTypeInfo& typeinfo);
		bool write7432(int channelNum, int value ,const IntTypeInfo& typeinfo);
		bool read7433(int channelNum, int *value ,const IntTypeInfo& typeinfo);
		bool write7434(int channelNum, int value ,const IntTypeInfo& typeinfo);
		bool write6208(int channelNum, double value ,const DoubleTypeInfo& typeinfo);
		bool read9116(int channelNum, double *value ,const DoubleTypeInfo& typeinfo);
		void init();
		
		void setCardType(unsigned short cardType);
		void setCardNum(unsigned short cardNum);
		void setNodeNum(int nodeNum);	
		void setPollInterval(int ms);	
		void setSpecialChlName(int channelNum, std::string name);//added by xiasc[20180321]

		void addFilterChl(int channelNum, std::string name);
		void setFilterInterval(int interval);

		void addScopeChl(int channelNum, double dMin, double dMax);//added by liusy[1.1.22]
		void setCardVoltage(double dCardVoltage);//added by taohao[1.1.30]

};

#endif /*PCICARD_H_*/
