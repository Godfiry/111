/*
 * FOTEKTempCtl.cpp
 *
 *  Created on: 2024��5��14��
 *      Author: chenshicun
 */
#include "FOTEKTempCtl.h"
#include <stdlib.h>
#include "ObjectManager.h"
#include "DeviceManager.h"

#include "Hex.h"
#include <iostream>
#include "CheckCalculationTool.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
using namespace IAP;
#endif
using namespace std;


FOTEKTempCtl::FOTEKTempCtl():SerialDevice(200, "")
{
	m_timeOut=20;
	m_resLen = 11;
	m_readCmd[0] = 0x40;//controller address
	m_readCmd[1] = 0x30;//function read
	m_readCmd[2] = 0x30;//read starting at register high byte
	m_readCmd[3] = 0x52;//read starting at register low byte
	m_readCmd[4] = 0x31;//read number of consecutive register high (always 0)
	m_readCmd[5] = 0x39;//read number of consecutive register low
	m_readCmd[6] = 0x31;//Low byte of CRC
	m_readCmd[7] = 0x41;//High byte of CRC
	m_readCmd[8] = 0x0D;//High byte of CRC
	m_nStartReadTempIndex = 6;

}

FOTEKTempCtl::~FOTEKTempCtl()
{
}

bool FOTEKTempCtl::readDouble(int nChannelNum, double *pValue,const DoubleTypeInfo &typeInfo)
{
	/*unsigned short crc = 0x00;
	for(int i = 0;i<6;i++)
	{
		crc = crc ^(m_readCmd[i]&0xFF);
	}*/

	//m_readCmd[6] = crc & 0xFF;

	char response[m_resLen];
	sendCommandOnly(m_readCmd, 9);
	if(getResultOnly(response,m_resLen, m_timeOut) < 0)
	{
		throw IOException(getDeviceName() + " reading back times out");
	}
	/*response[0] = 0x40;
	response[1] = 0x00;
	response[2] = 0x00;
	response[3] = 0x52;
	response[4] = '0';
	response[5] = '0';
	response[6] = '1';
	response[7] = '2';
	response[8] = '1';*/

	char cByte[4]; //save the 32-bite

	cByte[0] = response[m_nStartReadTempIndex];
	cByte[1] = response[m_nStartReadTempIndex+1];
	cByte[2] = response[m_nStartReadTempIndex+2];
	cByte[3] = response[m_nStartReadTempIndex+3];

	//t_strvalue =

	double t_value;
	t_value = atof(cByte);
	*pValue = t_value;
	return true;
}



void FOTEKTempCtl::initChs(DeviceNode<FOTEKTempCtl>* pNode)
{
	pNode->registerReadCh(1, &FOTEKTempCtl::readDouble);
}

void FOTEKTempCtl::initDevice()
{
	cout<<"Start Scan FOTEKTempCtl...."<<endl;
	//say hello to chiller
	double dTemp;
	try
	{
		//readDouble(1,&dTemp,DoubleTypeInfo());
	}
	catch(exception &ex)
	{
		cout<<"Scan FOTEKTempCtl failed. Communication abnormal!"<<endl;
		throw;
	}
	cout<<"Scan FOTEKTempCtl Successfully...."<<endl;
}


void FOTEKTempCtl::init()
{
	DeviceNode<FOTEKTempCtl> *pNode = new DeviceNode<FOTEKTempCtl>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);

	if(!isSimulated())
	{
		initChs(pNode);
		initDevice();
	}
}

void FOTEKTempCtl::setStartReadTempIndex(int index)
{
	m_nStartReadTempIndex = index;
}

string FOTEKTempCtl::getDeviceName()
{
	return __FILE__;
}

IMPLEMENT_DYNAMIC(FOTEKTempCtl, SerialDevice )

BEGIN_MSG_MAP(FOTEKTempCtl, SerialDevice )
	SET_V( init, FOTEKTempCtl )
	SET_I( setStartReadTempIndex, FOTEKTempCtl )
END_MSG_MAP
