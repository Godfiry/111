#include "IR422GasMonitorDriver.h"
#include <stdlib.h>
#include "ObjectManager.h"
#include "DeviceManager.h"

#include "Hex.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
using namespace IAP;
#endif
using namespace std;

IR422GasMonitorDriver::Com IR422GasMonitorDriver::m_Commands[]={{0,""},
															  {4,"RCV1",6},//read partial pressure1 value,ex 5.0000  %FS
															  {4,"RCV2",6},//read partial pressure1 value,ex 10.000  %FS
															  {3,"RTP",6},//read total pressure value,ex 100.00 %FS
															  {4,"RLV1",6},// read light source value1 ,ex 50.000
															  {4,"RLV2",6},// read light source value2 ,ex 49.000
															  {4,"RLV4",6}// read light source reference ,ex 50.000
};

IR422GasMonitorDriver::IR422GasMonitorDriver():SerialDevice(200, "")
{
	m_startCmd = "\0x40";	//"@"
	m_cStartCmd = 0x40;
	m_strAddress = "01";
	m_endCmd = "\0x03\0x40\0x03\0x03\0x03";//"ETX@ETXETXETX"
}

IR422GasMonitorDriver::~IR422GasMonitorDriver()
{
}

std::string IR422GasMonitorDriver::readCommand(std::string strCommand, int ntimeOut)
{
	string strReply=getCommandResult(strCommand,ntimeOut);
	
	if(strReply.find("\0x03\0x40",0)!=string::npos)
	{
		return strReply;	
	}
	else if(strReply.find("NAK",0)!=string::npos)
	{
		throw IOException("read command error,reply is :"+strReply);
	}
	else
	{
		throw IOException("unknow read_back: " + strReply+" when send query command "+strCommand);
	}

}

bool IR422GasMonitorDriver::readDouble(int nChannelNum, double *pValue,const DoubleTypeInfo &typeInfo)
{
	
	Com com = m_Commands[nChannelNum];	
	std::string t_sendComnd = "";
	std::string t_res = "";
	std::string t_svalue = "";
	
	t_sendComnd = m_startCmd+m_strAddress+com.m_strCmd+m_endCmd;
	//t_sendComnd = "@01STXRCV1";
	char command[10];
	command[0]=0x40;
	command[1]='0';
	command[2]='1';
	command[3]=0x02;
	command[4]='R';
	command[5]='C';
	command[6]='V';
	command[7]='1';
	command[8]=0x03;
	command[9]=0x1F;

	t_res = readCommand(command,m_timeOut);	
	t_svalue = t_res.substr(1);
	
	
	//double t_double = 0.0;
	*pValue = atof(t_svalue.c_str());

	
	//if(!Converter::stringToDouble(t_double, t_svalue))
	//{
	//	throw IOException("read back value is not an valid double value:" + t_svalue);
	//}
	
	char ack[1];
	ack[0]=0x06;
	sendCommandOnly(ack,1); 
	
	return true;
}

bool IR422GasMonitorDriver::readInt(int nChannelNum, int *pValue,const IntTypeInfo &typeInfo)
{
	
	std::string t_res = "";
	std::string t_svalue = "";
	//t_sendComnd = "@01STXRCV1";
	char command[10];
	command[0]=0x40;
	command[1]='0';
	command[2]='1';
	command[3]=0x02;
	command[4]='R';
	command[5]='C';
	command[6]='S';
	command[7]=0x03;
	command[8]=0x6B;

	t_res = readCommand(command,m_timeOut);	
	t_svalue = t_res.substr(1);
	
	
	int t_int = 0;
	//*pValue = atof(t_svalue.c_str());

	
	if(!Converter::stringToInt(t_int, t_svalue))
	{
		throw IOException("read back value is not an valid int value:" + t_svalue);
	}
	*pValue = t_int;
	char ack[1];
	ack[0]=0x06;
	sendCommandOnly(ack,1); 
	
	return true;
}

bool IR422GasMonitorDriver::writeInt(int nChannelNum, int Value,const IntTypeInfo &typeInfo)
{
	
	
	//t_sendComnd = "@01STXRCV1";
	char command[10];
	command[0]=0x40;
	command[1]='0';
	command[2]='1';
	command[3]=0x02;
	command[4]='S';
	command[5]='Z';
	command[6]='C';
	command[7]=0x03;
	command[8]=0x73;

	
	sendCommandOnly(command,9); 
	
	return true;
}


void IR422GasMonitorDriver::initChs(DeviceNode<IR422GasMonitorDriver>* pNode)
{
	for(int i=1;i<=5;i++)
	{
		pNode->registerReadCh(i, &IR422GasMonitorDriver::readDouble);
	}
	pNode->registerReadCh(10, &IR422GasMonitorDriver::readInt);
	pNode->registerWriteCh(11, &IR422GasMonitorDriver::writeInt);
   pNode->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &IR422GasMonitorDriver::getStatus);
}

void IR422GasMonitorDriver::initDevice()
{
	cout<<"Start Scan IR422GasMonitor...."<<endl;
	//say hello to chiller
	double dPressure;
	try
	{
		//readDouble(1,&dPressure,DoubleTypeInfo());//3 read temprature
			char command[10];
			command[0]=0x40;
			command[1]='0';
			command[2]='1';
			command[3]=0x02;
			command[4]='R';
			command[5]='C';
			command[6]='V';
			command[7]='1';
			command[8]=0x03;
			command[9]=0x1F;
			string t_res = readCommand(command,m_timeOut);
	}
	catch(exception &ex)
	{
		cout<<"Scan IR422GasMonitor failed. Communication abnormal!"<<endl;
		throw;
	}
	cout<<"Scan IR422GasMonitor Successfully...."<<endl;
}


void IR422GasMonitorDriver::init()
{
	DeviceNode<IR422GasMonitorDriver> *pNode = new DeviceNode<IR422GasMonitorDriver>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
	if(!isSimulated())
	{
		initChs(pNode);
		initDevice();
	}
}
IMPLEMENT_DYNAMIC(IR422GasMonitorDriver, SerialDevice )

BEGIN_MSG_MAP(IR422GasMonitorDriver, SerialDevice )
	SET_V( init, IR422GasMonitorDriver )
END_MSG_MAP
