/*
 * HYCGeneratorDNetDriver.h
 *
 *  Created on: 2023��7��4��
 *      Author: liusiyuan
 */

#ifndef SRC_DEVICEACCESSOR_HYCGENERATORDNETDRIVER_H_
#define SRC_DEVICEACCESSOR_HYCGENERATORDNETDRIVER_H_

#include "IODevice.h"
#include "DeviceNode.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif


class HYCGeneratorDNetDriver : public IODevice{

    DECLARE_DYNAMIC(HYCGeneratorDNetDriver)
    DECLARE_MSG_MAP

public:
	HYCGeneratorDNetDriver();
	virtual ~HYCGeneratorDNetDriver();

public://xml
	void init();

public://read and write function
	bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
	bool writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo);
	bool writeRawCommand(int nChannelNum, std::string strValue, const StringTypeInfo &typeInfo);
	bool readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);
	bool readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);
	void setStartFrequency(int nStartFrequency); //unit Hz

protected:
	bool sendCommand(std::string strCommand, int nTimeOut);
	std::string readCommand(std::string strCommand, int nTimeOut);
	void InitChannels(DeviceNode<HYCGeneratorDNetDriver> *pNode);
	void initDevice();
	int m_nStartFrequency;  //add by zhangpf

private:
	typedef struct
	{
		int m_nByte;
		int m_nBit;
	}Com;
	int m_nLastLevelMode;//0:load leveling, 1:forward leveling;
	int m_nLastPulseMode;//0:off;1:On
	int m_nLastTuningMode;//0: Auto-Tune, 1: fixed
	int m_nLastRFOnOffControl;//0:Off;1:On
	int m_nLastCableLength;

	static Com m_Commands[];
	char *m_pWriteBuffer;
	char *m_pReadBuffer;

};

#endif /* SRC_DEVICEACCESSOR_HYCGENERATORDNETDRIVER_H_ */
