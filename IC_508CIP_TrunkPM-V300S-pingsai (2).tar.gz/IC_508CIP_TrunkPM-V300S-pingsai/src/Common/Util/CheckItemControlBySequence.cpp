#include "CheckItemControlBySequence.h"
#include "StrTool.h"
#include "SysLogger.h"
#include "ConfigException.h"
#include "ObjectManager.h"
#include "Recovery.h"
#include "UTime.h"
#include "Converter.h"
#include "AlarmReNameManager.h"
#include "StrManager.h"
#include <iostream>


#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "AbortException.h"
#include "InvalidNameException.h"
#endif

using namespace std;

CheckItemControlBySequence* CheckItemControlBySequence::m_pInstance = NULL;
IMutex* CheckItemControlBySequence::m_mutex = new IMutex(); //add by zhangpf[v1.11.0]

CheckItemControlBySequence* CheckItemControlBySequence::getInstance() 
{
	m_mutex->lock();//add by zhangpf[v1.11.0]
	if (NULL == m_pInstance)
	{
		m_pInstance = new CheckItemControlBySequence();
		ObjectManager::getInstance()->registerObject(m_pInstance,"/Control/PMCExports/Controls/CheckItemControlBySequence");
		m_pInstance->initialize();
	}
	m_mutex->unlock();//add by zhangpf[v1.11.0]
	return m_pInstance;
}

CheckItemControlBySequence::CheckItemControlBySequence()
{
	m_sEnable = new Enable();
	m_sEnable->setOwner(this);
	m_sDisable = new Disable();
	m_sDisable->setOwner(this);
	m_sEnableAll = new EnableAll();
	m_sEnableAll->setOwner(this);
	m_pInstance = this;
}

CheckItemControlBySequence::~CheckItemControlBySequence()
{

}


void CheckItemControlBySequence::addCheckItemControl(const std::string& strControlMethod,  const std::string& strCheckItemFullName)
{
	CheckItem *pCheckItem = XmlGetter::getFromNamespace<CheckItem*>(strCheckItemFullName);
	m_CheckItemIdControlMap[strControlMethod].push_back(pCheckItem);
}

void CheckItemControlBySequence::Enable::execute()
{
	CheckItemControlBySequence *owner = dynamic_cast<CheckItemControlBySequence*>(getOwner());
	if (owner != NULL)
	{
		try
		{
			owner->do_Enable(Params["strControlMethod"].Str);
		}
		catch(const AbortException &ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": Enable service was aborted for:" + string(ex.what()));				
			throw;
		}
		catch(const exception &ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": Enable service has error for:" + string(ex.what()));							
			throw;
		}				
	}		
}

void CheckItemControlBySequence::Disable::execute()
{
	CheckItemControlBySequence *owner = dynamic_cast<CheckItemControlBySequence*>(getOwner());
	if (owner != NULL)
	{
		try
		{
			owner->do_Disable(Params["strControlMethod"].Str);
		}
		catch(const AbortException &ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": Disable service was aborted for:" + string(ex.what()));				
			throw;
		}
		catch(const exception &ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": Disable service has error for:" + string(ex.what()));							
			throw;
		}				
	}		
}

void CheckItemControlBySequence::EnableAll::execute()
{
	CheckItemControlBySequence *owner = dynamic_cast<CheckItemControlBySequence*>(getOwner());
	if (owner != NULL)
	{
		try
		{
			owner->do_EnableAll();
		}
		catch(const AbortException &ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": EnableAll service was aborted for:" + string(ex.what()));
			throw;
		}
		catch(const exception &ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": EnableAll service has error for:" + string(ex.what()));
			throw;
		}
	}
}

void CheckItemControlBySequence::call_Enable(const std::string &strControlMethod)
{
	m_sEnable->setParamValue("strControlMethod", strControlMethod);
	call(m_sEnable);
}

void CheckItemControlBySequence::call_Disable(const std::string &strControlMethod)
{
	m_sDisable->setParamValue("strControlMethod", strControlMethod);
	call(m_sDisable);
}

void CheckItemControlBySequence::call_EnableAll()
{
	call(m_sEnableAll);
}


void CheckItemControlBySequence::do_Enable(const std::string &strControlMethod)
{
	if(m_CheckItemIdControlMap.find(strControlMethod)!=m_CheckItemIdControlMap.end())
	{
		for(int i=0;i<m_CheckItemIdControlMap[strControlMethod].size();i++)
		{
			m_CheckItemIdControlMap[strControlMethod][i]->call_Enable();
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ": the Control Method of "+strControlMethod+"'s VInterlock["+m_CheckItemIdControlMap[strControlMethod][i]->getSelfName()+"] has been Enabled.");
		}
	}
}

void CheckItemControlBySequence::do_Disable(const std::string &strControlMethod)
{
	if(m_CheckItemIdControlMap.find(strControlMethod)!=m_CheckItemIdControlMap.end())
	{
		for(int i=0;i<m_CheckItemIdControlMap[strControlMethod].size();i++)
		{
			m_CheckItemIdControlMap[strControlMethod][i]->call_Disable();
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ": the Control Method of "+strControlMethod+"'s VInterlock["+m_CheckItemIdControlMap[strControlMethod][i]->getSelfName()+"] has been Disabled.");
		}
	}
}

void CheckItemControlBySequence::do_EnableAll()
{
	map<std::string, std::vector<CheckItem*> >::iterator it;
	for( it = m_CheckItemIdControlMap.begin();it != m_CheckItemIdControlMap.end(); ++it)
	{
		for(int i=0;i<m_CheckItemIdControlMap[it->first].size();i++)
		{
			m_CheckItemIdControlMap[it->first][i]->call_Enable();
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ": the Control Method of "+it->first+"'s VInterlock["+m_CheckItemIdControlMap[it->first][i]->getSelfName()+"] has been Enabled.");
		}
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ": the Control Method of "+it->first+"'s CheckItems has been all Enabled");
	}
}

void CheckItemControlBySequence::doAbort()
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ": about to doAbort");
	map<std::string, std::vector<CheckItem*> >::iterator it;
	for( it = m_CheckItemIdControlMap.begin();it != m_CheckItemIdControlMap.end(); ++it)
	{
		for(int i=0;i<m_CheckItemIdControlMap[it->first].size();i++)
		{
			m_CheckItemIdControlMap[it->first][i]->do_Enable();
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ": the Control Method of "+it->first+"'s VInterlock["+m_CheckItemIdControlMap[it->first][i]->getSelfName()+"] has been Enabled.");
		}
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ": the Control Method of "+it->first+"'s VInterlock has been all Enabled");
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + ": done doAbort");
}

IMPLEMENT_DYNAMIC_SERVICE(Enable, CheckItemControlBySequence)
IMPLEMENT_DYNAMIC_SERVICE(Disable, CheckItemControlBySequence)
IMPLEMENT_DYNAMIC_SERVICE(EnableAll, CheckItemControlBySequence)

BEGIN_SERVICEINFO_LIST(CheckItemControlBySequence)
	ADD_SERVICE_INFO(CheckItemControlBySequence, Enable, enable this check item )
    	ADD_PARAM_INFO(CheckItemControlBySequence, Enable, strControlMethod, string, the Control Method Name )
	ADD_SERVICE_INFO(CheckItemControlBySequence, Disable, disable this check item)
		ADD_PARAM_INFO(CheckItemControlBySequence, Disable, strControlMethod, string, the Control Method Name )
	ADD_SERVICE_INFO(CheckItemControlBySequence, EnableAll, enable this check item )
END_SERVICEINFO_LIST(CheckItemControlBySequence)

IMPLEMENT_DYNAMIC(CheckItemControlBySequence, ControlObjectEX)

BEGIN_MSG_MAP( CheckItemControlBySequence, ControlObjectEX)
	SET_SS(addCheckItemControl, CheckItemControlBySequence)
END_MSG_MAP

