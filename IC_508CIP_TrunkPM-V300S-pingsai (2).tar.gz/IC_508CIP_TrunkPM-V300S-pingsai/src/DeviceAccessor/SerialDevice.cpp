/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: SerialDevice.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2007-9-22   LiJuanjuan create
**      
*********************************************************************/
#include <iostream>
#include <string.h>
#include "SerialDevice.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#include "Converter.h"
#include "ConfigException.h"
#include "SysLogger.h"
#ifdef IAP4_0
using namespace IAP;
using namespace IAP::CORE;
#endif

using namespace std;

SerialDevice::SerialDevice(int nMaxMsgLen, const std::string &strCR)
{
	m_nMaxMsgLen = nMaxMsgLen;
	m_strCR = strCR;
	m_pollPeriod = 100;
	m_timeOut = 20;//2s
	m_bLogEnable =false;
	m_nConnect = COMMUNICATION_STATUS::CONNECT;
	m_type = SERIALPORT;
}

SerialDevice::~SerialDevice()
{
	m_dev.closePort();
}

void SerialDevice::setNodeNum(int nNodeNum)
{
	m_nodeNum = nNodeNum;
}	

void SerialDevice::setDevice(const std::string &strDevName)
{
	if(!isSimulated())
	{
		m_strDevName = strDevName;
		if(m_type != ETHERCAT_TO_SERIAL)//merged from 1.6.3 by zhangyy[1.9.0]
		{
			m_dev.init();
		}
		if(!m_dev.openPort(m_strDevName.c_str()))
		{
			throw ConfigException("SerialDevice: open device '" + strDevName + "' failed");
		}
	}
}

void SerialDevice::setBaudRate(unsigned int nRate)
{
	if(!isSimulated())
	{	
		if(!m_dev.setBaudRate(nRate))
		{
			throw ConfigException("SerialDevice: set baudRate failed for device '" + m_strDevName + "'");
		}
	}
}

void SerialDevice::setCharSize(unsigned int nSize)
{
	if(!isSimulated())
	{		
		if(!m_dev.setCharSize(nSize))
		{
			throw ConfigException("SerialDevice: set CharSize failed for device '" + m_strDevName + "'");
		}
	}
}

void SerialDevice::setStopBit(unsigned int nStopBit)
{
	if(!isSimulated())
	{		
		if(!m_dev.setStopBit(nStopBit))
		{
			throw ConfigException("SerialDevice: set StopBit failed for device '" + m_strDevName + "'");
		}
	}
}

void SerialDevice::setParity(unsigned int nParityMode)
{
	if(!isSimulated())
	{	
		if(!m_dev.setParity(nParityMode))
		{
			throw ConfigException("SerialDevice: set Parity failed for device '" + m_strDevName + "'");			
		}
	}
}

void SerialDevice::setXonoff(bool bEnable)
{
	if(!isSimulated())
	{		
		if(!m_dev.setXonoff(bEnable))
		{
			throw ConfigException("SerialDevice: set Xonoff failed for device '" + m_strDevName + "'");						
		}
	}
}

void SerialDevice::setRtscts(bool bEnable)
{
	if(!isSimulated())
	{		
		if(!m_dev.setRtscts(bEnable))
		{
			throw ConfigException("SerialDevice: set Rtscts failed for device '" + m_strDevName + "'");									
		}
	}
}

std::string SerialDevice::getDeviceName()const
{
	if(getName() != "")
	{
		return getName();
	}
	else
	{
		return m_strDevName;
	}
}

void SerialDevice::logCommunicationInfo(const std::string strInfo)
{
	if(m_bLogEnable)
	{
		Log_Info(getDeviceName()+" "+ strInfo);
	}
}

void SerialDevice::setCommunicationStatus(int nStatus)
{
	m_nConnect = nStatus;
}

void SerialDevice::clearPort()
{
	char pBuf[m_nMaxMsgLen];
	memset(pBuf, 0, m_nMaxMsgLen);
	int nLen = 0;
	while( (nLen = m_dev.readStr(pBuf, 0, m_nMaxMsgLen)) > 0)
	{
		if(m_bLogEnable)
		{
			string strClearMsg = Hex::GetHexString(pBuf,nLen);
			if(strClearMsg.length() > 0)
			{
				Log_Info(getDeviceName()+" clear info(hex): " + strClearMsg);
				Log_Info(getDeviceName()+" clear info(string): " + string(pBuf));
			}
		}
		usleep(1);
	}	
}
		
std::string SerialDevice::getCommandResult(const std::string &strCommand, int nTimeout)
{
	string strTotalCmd = strCommand + m_strCR;
	clearPort();
	if(m_dev.writeRaw(strTotalCmd.c_str(), strTotalCmd.length()) == -1)
	{
		m_nConnect = COMMUNICATION_STATUS::DISCONNECT;
		throw IOException(getDeviceName()+" send command [" + strCommand + "] failed for " + string(strerror(errno)));
	}
	char pBuf[m_nMaxMsgLen];
	memset(pBuf, 0, m_nMaxMsgLen);
	
	if(m_dev.readStr(pBuf, nTimeout, m_nMaxMsgLen) <= 0)
	{
		m_nConnect = COMMUNICATION_STATUS::DISCONNECT;
		throw IOException(getDeviceName()+" read command ["+strCommand+"] failed for no response");
	}
	else
	{
		m_nConnect = COMMUNICATION_STATUS::CONNECT;
		return pBuf;	
	}	
}

std::string SerialDevice::getFixCommandResult(const std::string &strCommand, int nTimeOut, int nMsgLen,  int nTryTimes)
{
	string s = strCommand + m_strCR;
	clearPort();
	if(m_dev.writeRaw(s.c_str(), s.length()) == -1)
	{
		m_nConnect = COMMUNICATION_STATUS::DISCONNECT;
		throw IOException(getDeviceName()+" send command [" + strCommand + "] failed for " + string(strerror(errno)));
	}
	char pBuf[m_nMaxMsgLen];	
	memset(pBuf, 0, m_nMaxMsgLen);
	int nNum = nTryTimes;
	int nLocation = 0;
	int nReadCount = 0;
	while(nNum > 0)
	{
		nReadCount = m_dev.readStr(pBuf+nLocation, nTimeOut, m_nMaxMsgLen-nLocation);
		if(nReadCount >= nMsgLen-nLocation)
		{
			setCommunicationStatus(COMMUNICATION_STATUS::CONNECT);
			//logCommunicationInfo("received command: "+string(pBuf));
			return pBuf;
		}
		else
		{
			if(nReadCount < 0)
			{
				nReadCount = 0;
			}
			nLocation +=nReadCount;
			nNum--;
		}
	}
	if(nLocation >= 0)
	{
		setCommunicationStatus(COMMUNICATION_STATUS::CONNECT);
		throw IOException(getDeviceName()+" read command ["+ strCommand + "] failed for response ["+string(pBuf)+"]'s data length ["+Converter::convertToString(nLocation)+"] less than the target length ["+Converter::convertToString(nMsgLen));
	}
	else
	{
		setCommunicationStatus(COMMUNICATION_STATUS::DISCONNECT);
		throw IOException(getDeviceName()+" read command ["+ strCommand + "] failed for no response.");
	}
}

int SerialDevice::getCommandResult(char *pCommand, int nCommandLen, char *pResponse, int nResponseLen, int nTimeOut)
{
	sendCommandOnly(pCommand, nCommandLen);
	return getResultOnly(pResponse, nResponseLen, nTimeOut);
}

void SerialDevice::getFixCommandResult(const char *pCommand, int nCommandLen, char *pResponse, int nResponseLen, int nTimeOut, int nTryTimes)
{
	sendCommandOnly(pCommand, nCommandLen);
	getFixResultOnly(pResponse, nResponseLen, nTimeOut, nTryTimes);
}
void SerialDevice::sendCommandOnly(const std::string &strCommand)
{
	string strTotalCommand = strCommand + m_strCR;
	sendCommandOnly(strTotalCommand.c_str(), strTotalCommand.length());
}

void SerialDevice::sendCommandOnly(const char *pCommand, int nLen)
{
	clearPort();
	if(m_dev.writeRaw(pCommand, nLen) == -1)
	{	
		setCommunicationStatus(COMMUNICATION_STATUS::DISCONNECT);
		throw IOException(getDeviceName()+" send command [" + Hex::GetHexString(pCommand,nLen) + "] failed for " + string(strerror(errno)));
	}
	//logCommunicationInfo("send command(string): "+string(pCommand));
	//logCommunicationInfo("send command(Hex): "+Hex::GetHexString(pCommand,nLen));
}

int SerialDevice::getResultOnly(char *pBuf, int nCommandLen, int nTimeOut)
{
	int nResponseNum = m_dev.readStr(pBuf, nTimeOut, nCommandLen);
	if(nResponseNum <= 0)
	{
		setCommunicationStatus(COMMUNICATION_STATUS::DISCONNECT);
		throw IOException(getDeviceName()+" read data failed for no response");
	}
	else
	{
		//logCommunicationInfo("received command(string): "+string(pBuf));
		//logCommunicationInfo("received command(Hex): "+Hex::GetHexString(pBuf,nResponseNum));
		setCommunicationStatus(COMMUNICATION_STATUS::CONNECT);
		return nResponseNum;
	}
}

std::string SerialDevice::getResultOnly(int nTimeOut)
{	
	char pBuf[m_nMaxMsgLen];
	memset(pBuf, 0, m_nMaxMsgLen);

	string strResponse = "";

	while(m_dev.readStr(pBuf, nTimeOut, m_nMaxMsgLen) > 0)
	{
		strResponse += string(pBuf);
		//logCommunicationInfo("received command(string): "+strResponse);
		memset(pBuf, 0, m_nMaxMsgLen);
	}	
	return strResponse;
}

void SerialDevice::getFixResultOnly(char *pBuf, int nBufLen, int nTimeOut, int nTryTimes)
{
	memset(pBuf, 0, nBufLen);
	int nTryNum = nTryTimes;
	int nLocation = 0;
	int nResponseCount = 0;
	while(nTryNum > 0)
	{
		nResponseCount = m_dev.readStr(pBuf+nLocation, nTimeOut, nBufLen-nLocation);
		if(nResponseCount >= nBufLen-nLocation)
		{
			setCommunicationStatus(COMMUNICATION_STATUS::CONNECT);
			//logCommunicationInfo("received command(string): "+string(pBuf));
			return;
		}
		else
		{
			if(nResponseCount < 0)
			{
				nResponseCount = 0;
			}
			nLocation +=nResponseCount;
			nTryNum--;
		}
	}

	if(nLocation >= 0)
	{
		setCommunicationStatus(COMMUNICATION_STATUS::CONNECT);
		throw IOException(getDeviceName()+" read data failed for response ["+string(pBuf)+"]'s data length ["+Converter::convertToString(nLocation)+"] less than the target length ["+Converter::convertToString(nBufLen));
	}
	else
	{
		setCommunicationStatus(COMMUNICATION_STATUS::DISCONNECT);
		throw IOException(getDeviceName()+" read data failed for no response.");
	}
}

std::string SerialDevice::getResultOnly(int nTimeOut,int nMaxLen)
{
	char pBuf[m_nMaxMsgLen];
	memset(pBuf, 0, m_nMaxMsgLen);

	string strResponse = "";

	while(m_dev.readStr(pBuf, nTimeOut, m_nMaxMsgLen) > 0)
	{		
		strResponse += string(pBuf);
		memset(pBuf,0,m_nMaxMsgLen);
		if(strResponse.length() >=  nMaxLen)
		{
			//logCommunicationInfo("received command(string): "+strResponse);
			break;
		}
	}
	return strResponse;
}

bool SerialDevice::getStatus(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)//added by mujy [v1.0.8]
{
	*pValue = m_nConnect;
	return true;
}

void SerialDevice::setPollInterval(int nMilliSecond)
{
	m_pollPeriod = nMilliSecond;
}
		
void SerialDevice::setTimeout(int nMilliSecond)
{
	m_timeOut = nMilliSecond/100;
}

void SerialDevice::setDeviceType(const std::string &deviceType)//merged from 1.6.3 by zhangyy[1.9.0]
{
	if(deviceType == "ETHERCAT_TO_SERIAL")
	{
	   m_type = ETHERCAT_TO_SERIAL;
	}
	else
	{
	   m_type = SERIALPORT;
	}	
	m_dev.init(m_type);
}

void SerialDevice::setSlaveAddress(unsigned short slaveAddress)
{
	if(m_type == ETHERCAT_TO_SERIAL)
	{
		if(!m_dev.setSlaveAddress(slaveAddress))
		{
			throw ConfigException("SerialDevice: set slave address failed for device '" + m_strDevName + "'");
		}
	}
}

void SerialDevice::setDataFrame(const std::string &dataFrame)
{
	if(m_type == ETHERCAT_TO_SERIAL)
	{
		if(!m_dev.setDataFrame(dataFrame))
		{
			throw ConfigException("SerialDevice: set data frame failed for device '" + m_strDevName + "'");
		}
	}
}

void SerialDevice::setIndex(unsigned short index)
{
	if(m_type == ETHERCAT_TO_SERIAL)
	{
		if(!m_dev.setIndex(index))
		{
			throw ConfigException("SerialDevice: set index failed for device '" + m_strDevName + "'");
		}
	}
}
void SerialDevice::setLog(bool bLogEnable)
{
	m_bLogEnable = bLogEnable;
}

IMPLEMENT_JOINT(SerialDevice, AbstractDevice)
BEGIN_MSG_MAP( SerialDevice, AbstractDevice)
	SET_I( setNodeNum, SerialDevice )  
	SET_S( setDevice, SerialDevice )
	SET_I( setBaudRate, SerialDevice )
	SET_I( setCharSize,SerialDevice )
	SET_I( setStopBit, SerialDevice )
	SET_I( setParity, SerialDevice )   
	SET_B( setXonoff, SerialDevice)
	SET_B( setRtscts, SerialDevice)
	SET_I( setPollInterval, SerialDevice )
	SET_I( setTimeout, SerialDevice )
	SET_S( setDeviceType, SerialDevice )//merged from 1.6.3 by zhangyy[1.9.0]
	SET_I( setSlaveAddress, SerialDevice )
	SET_I( setIndex, SerialDevice )
	SET_S( setDataFrame, SerialDevice )
	SET_B( setLog, SerialDevice)
END_MSG_MAP

