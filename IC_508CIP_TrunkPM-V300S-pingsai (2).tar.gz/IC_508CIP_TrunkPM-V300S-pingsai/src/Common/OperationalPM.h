/*************************************************************************************
** Copyright (c) 2007, Beijing NMC Co.Ltd.  All rights reserved.
** File name: 	OperationalPM.h
** Description: 
** Release: 		1.0
** Modification history:
** 					2008-2-18   WangYonggui create
* 					2009-10-14   modified by lijj
**
*************************************************************************************/

#ifndef OPERATIONALPM_H_
#define OPERATIONALPM_H_

#include "OperationalModel.h"
#include "OperationalProcess.h"
#include "AppCondition.h"
#include "ServiceResultInfo.h"
#include "FunctionalPM.h"
#include <map>
#include <vector>
#ifdef IAP4_0
using namespace IAP::CONDITION;
#endif
class OperationalProcess;
class OperationalPM : public OperationalModel
{
	DECLARE_DYNAMIC(OperationalPM)
	DECLARE_MSG_MAP
	DECLARE_SERVICEINFO_LIST
		
		class PrepChamb : public Service
		{
			DECLARE_DYNAMIC_SERVICE(PrepChamb)
			
			private:
				ServiceResultInfo theResult;
			public:
				void execute();
		};

		class PrepWfr : public Service
		{
			DECLARE_DYNAMIC_SERVICE(PrepWfr)
			public:
				void execute();
		};
		
		class CompWfr : public Service
		{
			DECLARE_DYNAMIC_SERVICE(CompWfr)
			
			private:
				ServiceResultInfo theResult;
			public:
				void execute();
		};

		class JobStartCondition : public Service//[wangyk 1.1.60]
		{
			DECLARE_DYNAMIC_SERVICE(JobStartCondition)
			public:
				void execute();
		};

		class JobEndCondition : public Service//[wangyk 1.1.60]
		{
			DECLARE_DYNAMIC_SERVICE(JobEndCondition)
			public:
				void execute();
		};

	public://constructor
		OperationalPM();		
		virtual ~OperationalPM();
	
	public://service
		void call_PrepChamb(int port);
		
		void call_PrepWfr(int nSlot, int nTransferOperation, int nHandOffMode,int nWaferID,string strLotID, string strWfrName);
		
		void call_CompWfr();

		void call_JobStartCondition(string strProcessRecipeName);//[wangyk 1.1.60]

		void call_JobEndCondition(string strProcessRecipeName);//[wangyk 1.1.60]
				
		virtual void do_PrepChamb(int nPort);
		
		virtual void do_PrepWfr(int nSlot, int nTransferOperation, int nHandOffMode,int nWaferID,string strLotID, string strWfrName);
		
		virtual void do_CompWfr();
		
		virtual void do_JobStartCondition(string strProcessRecipeName);//[wangyk 1.1.60]

		virtual void do_JobEndCondition(string strProcessRecipeName);//[wangyk 1.1.60]

	public://override
		virtual void make();
		
		virtual void startup();
		
		virtual void shutdown();

		virtual void do_Init();
		
		virtual void do_Shutdown();
		

  	protected:
  		FunctionalPM* getFuncPMModule();
  		string getTransferOperation(int nTransferOperation);

	protected:
		
		FunctionalPM *m_pFuncPMModule;
 				
	private:
		OperationalProcess * m_pOperationalProcess;
		ReadWriteInt *m_pXferSts;
		ReadWriteInt *m_pXferAnm;
	
		ServicePtr<PrepChamb> m_sPrepChamb;
		ServicePtr<PrepWfr> m_sPrepWfr;
		ServicePtr<CompWfr> m_sCompWfr;
		ServicePtr<JobStartCondition> m_sJobStartCondition;//[wangyk 1.1.60]
		ServicePtr<JobEndCondition> m_sJobEndCondition;//[wangyk 1.1.60]
};

#endif /*OperationalPMModule_H_*/
