/********************************************************************
** Copyright (c) 2012, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: EthernetSocket.h
** Description:
** Modification history: 2012-04-16 Liwen created.
**      
*********************************************************************/

#ifndef ETHERNETSOCKET_H_
#define ETHERNETSOCKET_H_

#include <netinet/in.h> // for sockaddr_in
#include <strings.h>
#include <string.h>
#include <netinet/tcp.h>
	
#define BUFFER_SIZE 65535

class EthernetSocket
{
    private:
        std::string m_serverIP;   
        unsigned long m_serverPort; 
        int m_sockfd;
        struct sockaddr_in m_clientAddr;
        struct sockaddr_in m_serverAddr;
        int m_revTimeOut;
        int m_sndTimeOut;
        bool m_connected;
    
    protected:
    
    public:
        EthernetSocket(const std::string serverIP, unsigned long serverPort);
        virtual ~EthernetSocket();
        
        void connect();
        int send(const char *buffer, int len);
        int receive(char *buffer, int len);
        int receiveByLen(char *buffer, int len);
        int select();
	//bool SocketSelect();
        int close();
        void reconnect();
        void setRcvTimeOut(int timeout);
        void setSndTimeOut(int timeout);
        std::string getErrnoDescription()const;
        int getErrno()const;
	bool isConnected();

};

#endif /*ETHERNETSOCKET_H_*/
