/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TMPEdwardsStpiXA4507.cpp
** Description:This driver is used for Edwards TMP 3307
*              RS232
*              Communication Type:Hex Mode
*              DataBit:
*              StopBit:
** Release: 1.1
** Modification history:
**                  2025-08-08   Xieshumin create
*********************************************************************/
#include <sys/time.h>
#include <iostream>
#include <string.h>
#include "TMPEdwardsStpiXA4507.h" 
#include "DeviceManager.h"
#include "ObjectManager.h"
#include "Converter.h"
#include "Util.h"
#include "SysLogger.h"
#include "CheckCalculationTool.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std;

const unsigned char TMPEdwardsStpiXA4507::regReadAddress[10] = {
0x3F,0x44,0x3F,0x5B,0x3F,0x5B,0x3F,0x6D,0x3F,0x6D };
//parameter array
const unsigned char TMPEdwardsStpiXA4507::paraArray[10] = { 0x01,0x02,0x04,0x45,0x46,0x3D
};//the hex of 1/2/4/
enum Status
{
	Stop = 0,
	Start = 1,
	Reset = 2
};

enum TMPControl
{
	RS232 = 0,
	Io = 1
};

enum TMPCommunicationOfflineStop
{
	Enable = 0,
	Disable = 1
};
char TMPEdwardsStpiXA4507::m_ack = 0x06;

//0x3F; function read:?
//0x44; function read:D
//0x5B; function read:[
//0x6D; function read:m
TMPEdwardsStpiXA4507::TMPEdwardsStpiXA4507() :SerialDevice(200, " ")
{
	//cout << "TMP INIT:TMPEdwardsStpiXA4507():SerialDevice(200, " ")" << endl;

	m_timeOut = 200;//2s

	//the form of the writing cmd within para, 10 elements
	//on/off/set
	m_writeParaCmd[0] = 0x02;//ASII:Stx(hex:02) transmission block start character
	m_writeParaCmd[1] = 0x30;//0(hex:30)
	m_writeParaCmd[2] = 0x30;//0(hex:30)
	m_writeParaCmd[3] = 0x31;//1(hex:31)
	m_writeParaCmd[4] = 0x20;//space(hex:20)
	m_writeParaCmd[5] = 0x45;//could be hex of E/F/=, decided by different command,init as ASCII:E(hex:0x45) 
	m_writeParaCmd[6] = 0x30;//paramerter,decided by different command ，init as ASCII:0（hex:0x30）
	m_writeParaCmd[7] = 0x00;//paramerter,decided by different command 
	m_writeParaCmd[8] = 0x03;//Etx(hex:03) transmission frame end character
	m_writeParaCmd[9] = 0x00;//LRC=m_paraCmd[0] XOR m_paraCmd[1] XOR ...m_paraCmd[8]

	//the form of the writing cmd within para, 72 elements
	//Disable the communication disconnect feature.
	m_optionParaCmd[0] = 0x02;//ASII:Stx(hex:02) transmission block start character
	m_optionParaCmd[1] = 0x30;//0(hex:30)
	m_optionParaCmd[2] = 0x30;//0(hex:30)
	m_optionParaCmd[3] = 0x31;//1(hex:31)
	m_optionParaCmd[4] = 0x20;//space(hex:20)
	m_optionParaCmd[5] = 0x3D;//=(hex:3D)
	//para 1~15
	//ASCII_para1:05,means 232
	m_optionParaCmd[6] = 0x30;
	m_optionParaCmd[7] = 0x35;
	//ASCII_para2:FF
	//ASCII_para3:FFFF32003CFF
	for (int i = 8; i < 14; i++)
	{
		m_optionParaCmd[i] = 0x46;//FFFF
	}
	m_optionParaCmd[14] = 0x33;
	m_optionParaCmd[15] = 0x32;
	m_optionParaCmd[16] = 0x30;
	m_optionParaCmd[17] = 0x30;
	m_optionParaCmd[18] = 0x33;
	m_optionParaCmd[19] = 0x43;//C
	m_optionParaCmd[20] = 0x46;
	m_optionParaCmd[21] = 0x46;
	//ASCII_para4:00;ASCII_para5:00
	for (int i = 22; i < 26; i++)
	{
		m_optionParaCmd[i] = 0x30;//0000
	}
	//ASCII_para6:FF
	m_optionParaCmd[26] = 0x46;
	m_optionParaCmd[27] = 0x46;
	//ASCII_para7:000003E8
	for (int i = 28; i < 33; i++)
	{
		m_optionParaCmd[i] = 0x30;//00000
	}
	m_optionParaCmd[33] = 0x33;
	m_optionParaCmd[34] = 0x45;//E
	m_optionParaCmd[35] = 0x38;
	//ASCII_para8:00
	m_optionParaCmd[36] = 0x30;
	m_optionParaCmd[37] = 0x30;
	//ASCII_para9:FF
	m_optionParaCmd[38] = 0x46;
	m_optionParaCmd[39] = 0x46;
	//ASCII_para9:03E8
	m_optionParaCmd[40] = 0x30;
	m_optionParaCmd[41] = 0x33;
	m_optionParaCmd[42] = 0x45;
	m_optionParaCmd[43] = 0x38;
	//ASCII_para11~12:0000003C
	for (int i = 44; i < 50; i++)
	{
		m_optionParaCmd[i] = 0x30;//000000
	}
	//3c->00,60s->0s,to disable
	m_optionParaCmd[50] = 0x30;
	m_optionParaCmd[51] = 0x30;
	//ASCII_para13:05
	m_optionParaCmd[52] = 0x30;
	m_optionParaCmd[53] = 0x35;
	//ASCII_para14:02
	m_optionParaCmd[54] = 0x30;
	m_optionParaCmd[55] = 0x32;
	//ASCII_para15:F*18
	for (int i = 56; i < 74; i++)
	{
		m_optionParaCmd[i] = 0x46;//F*18
	}
	//Etx
	m_optionParaCmd[74] = 0x03;

	//the form of confirmed frame without parameter which response to writing cmd,SIM_>PC
	m_confirmedFrame[0] = 0x02;//Stx 0 0 1 # Etx LRC;LRC=0X13
	m_confirmedFrame[1] = 0x30;
	m_confirmedFrame[2] = 0x30;
	m_confirmedFrame[3] = 0x31;
	m_confirmedFrame[4] = 0x23;
	m_confirmedFrame[5] = 0x03;
	m_confirmedFrame[6] = 0xEC;

	//the form of the reading cmd without para,8 elements
	m_readFixCmd[0] = 0x02;//ASII:Stx(hex:02) transmission block start character
	m_readFixCmd[1] = 0x30;//0(hex:30)
	m_readFixCmd[2] = 0x30;//0(hex:30)
	m_readFixCmd[3] = 0x31;//1(hex:31)
	m_readFixCmd[4] = 0x3F;//?(hex:3F)
	m_readFixCmd[5] = 0x46;//could be hex of F/=, decided by different command ,init as ASCII:F(hex:0x46) 
	m_readFixCmd[6] = 0x03;//Etx(hex:03) transmission frame end character
	m_readFixCmd[7] = 0x00;//LRC=m_paraCmd[0] XOR m_paraCmd[1] XOR ...m_paraCmd[7]


	//the form of the read Meas command，origin IO
	m_readCmd[0] = 0x02;//Stx(hex:02) transmission block start character
	m_readCmd[1] = 0x30;//0(hex:30)
	m_readCmd[2] = 0x30;//0(hex:30)
	m_readCmd[3] = 0x31;//1(hex:31)
	m_readCmd[4] = 0x00;//function read
	m_readCmd[5] = 0x00;//function read
	m_readCmd[6] = 0x03;//Etx(hex:03) transmission frame end character
	m_readCmd[7] = 0x00;//CRC
	//the return of speed and temp is ASCII

	//map contains warning ID and warning message
	m_warningMap.insert(pair<int, string>(2, "TMS Higher Temp\n"));
	m_warningMap.insert(pair<int, string>(5, "Power Failure\n"));
	m_warningMap.insert(pair<int, string>(6, "Power Supply Fail\n"));
	m_warningMap.insert(pair<int, string>(7, "Overspeed 1\n"));
	m_warningMap.insert(pair<int, string>(8, "DRV Overvoltage\n"));
	m_warningMap.insert(pair<int, string>(10, "CNT Overheat 1\n"));
	m_warningMap.insert(pair<int, string>(11, "DRV Overcurrent\n"));
	m_warningMap.insert(pair<int, string>(12, "DRV Overload\n"));
	m_warningMap.insert(pair<int, string>(13, "Disturbance X_H\n"));
	m_warningMap.insert(pair<int, string>(14, "Disturbance YH\n"));
	m_warningMap.insert(pair<int, string>(15, "Disturbance X_B\n"));
	m_warningMap.insert(pair<int, string>(16, "Disturbance X_H\n"));
	m_warningMap.insert(pair<int, string>(17, "Disturbance Z\n"));
	m_warningMap.insert(pair<int, string>(18, "MOTOR Overheat\n"));
	m_warningMap.insert(pair<int, string>(24, "DRV Com Failure\n"));
	m_warningMap.insert(pair<int, string>(25, "1st Damage Limit\n"));
	m_warningMap.insert(pair<int, string>(26, "2nd Damage Limit\n"));
	m_warningMap.insert(pair<int, string>(27, "Star Not Allowed\n"));
	m_warningMap.insert(pair<int, string>(28, "Speed pulse Lost\n"));
	m_warningMap.insert(pair<int, string>(29, "Overspeed 2\n"));
	m_warningMap.insert(pair<int, string>(30, "Overspeed 3\n"));
	m_warningMap.insert(pair<int, string>(31, "M_Temp Lost\n"));
	m_warningMap.insert(pair<int, string>(32, "TMS Lower Temp\n"));
	m_warningMap.insert(pair<int, string>(33, "AMB Com Failure\n"));
	m_warningMap.insert(pair<int, string>(35, "TMS Sensor Lost\n"));
	m_warningMap.insert(pair<int, string>(43, "WARNING: Imbalance X_H\n"));
	m_warningMap.insert(pair<int, string>(44, "WARNING: Imbalance X_B\n"));
	m_warningMap.insert(pair<int, string>(45, "WARNING: Imbalance Z\n"));
	m_warningMap.insert(pair<int, string>(50, "Driver Failure\n"));
	m_warningMap.insert(pair<int, string>(59, "Acc Malfunction\n"));
	m_warningMap.insert(pair<int, string>(61, "Record Failure\n"));
	m_warningMap.insert(pair<int, string>(72, "Aberrant Brake\n"));
	m_warningMap.insert(pair<int, string>(73, "Aberrant Accel\n"));
	m_warningMap.insert(pair<int, string>(76, "Inordinate Current\n"));
	m_warningMap.insert(pair<int, string>(78, "Serial Com Fail\n"));
}

TMPEdwardsStpiXA4507::~TMPEdwardsStpiXA4507()
{
}

/*!
	@brief This method is used to read Double type data from the hardware, and it internally uses the readCommand method.
	@param [in] channelNum The channel number.
	@param [in] typeInfo The Description of some features of the Data.
	@param [out] value The value read from the hardware.
	@exception IOException This exception is used to deal with:
		The channelNum is not registered on readDouble()
		The response back times out;
		Receive NAK;
		Response data incorrect;
	@return true if the readDouble was successful.
*/
bool  TMPEdwardsStpiXA4507::readDouble(int channelNum, double* value, const DoubleTypeInfo& typeinfo) //01, 02, 03, the return values are all double, and the type defined in IO_config is D.
{
	if (isSimulated())
	{
		struct timeval tm;
		struct timezone* tz = NULL;
		gettimeofday(&tm, tz);
		*value = typeinfo.getMax() * ((double)tm.tv_usec / 1000000);
		return true;
	}
	// write command for channel
	if ((channelNum >= 1) && (channelNum <= 3))
	{
		m_readCmd[4] = regReadAddress[(channelNum - 1) * 2];
		m_readCmd[5] = regReadAddress[(channelNum - 1) * 2 + 1];
	}
	else
	{
		//cout << "TMP:channelNum "<<channelNum<<" is not registered on readDouble()"<< endl;
		//return false;
		throw IOException("TMP: IO channel is not registered on readDouble()..");
	}
	m_readCmd[7] = 0xFF;//reset m_readCmd[7]
	//calculate CRC by EXCLUSIVE-OR(XOR) of all the frame bytes
	for (unsigned int i = 0; i < 7; i++)
	{
		m_readCmd[7] = m_readCmd[7] ^ m_readCmd[i];
	}
	m_readCmd[7] = m_readCmd[7] & 0xff;
	//PC->SIM:send command and SIM->PC:return response
	//1. PC->SIM:send command
	//2.SIM->PC: ACK or NAK
	//3.IF ACK,PC->SIM:ACK; and then SIM->PC:response
	//4.IF NAK, PC have to retransmit the command
	char response[RESP_LEN];//save response data
	char ackornak = 0x00;//save ack or nak
	//cout<<"channel num = "<<channelNum<<endl;
	bzero(response, RESP_LEN);
	int nRet = getCommandResult(m_readCmd, 8, &ackornak, 1, m_timeOut);//1/clearport(),sendCommandOnly(m_writeParaCmd, 10),return getResultOnly(&ackornak, 1, m_timeOut),get SIM->PC:ACK or NAK in &ackornak
	//cout<<"readDouble:getCommandResult"<<endl;
	//cout<<"nRet="<<nRet<<endl;

	//cout << "SIM->PC:ackornak=" << Util::hexToString(ackornak) << endl;
	if (nRet < 0)
	{
		//cout << "TMP:readStr back times out..."<< endl;
		//return false;
		throw IOException("TMP:readDouble back times out...");
	}
	// if SIM return is nak(fail to receive the command)
	if (ackornak == NAK)
	{
		//cout << "Speed/Temp TMP:failed to send command because of receiving NAK"<< endl;
		//return false;
		throw IOException("TMP:failed to send command because of receiving NAK");
	}
	//if SIM return is ack(recieve the command completely) ，SIM->PC:ACK
	else if (ackornak == m_ack)
	{
		//PC->SIM:ACK
		//m_dev.writeRaw(&ack, 1);
		//sendCommandOnly(&ack, 1);
		//sendCommandOnly(&m_ack, 1);
		//cout << "m_ack= " << Util::hexToString(m_ack) << endl;
		//read response,5 is the timeout value
		//if (m_dev.readStr(response,5,RESP_LEN) < 0) connectStatus
		int nResponseLength = m_dev.readStr(response, TIME_OUT, RESP_LEN);
		if (nResponseLength < 0)
		{
			// cout << "TMP:readStr back times out.."<< endl;
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "TMP:readStr back times out..");//add by Liuxj [1.1.4]
			//return false;
			throw IOException("TMP:reading response back times out..");
		}
		//read data from response,数据返回帧
		if ((response[0] == 0x02) && (response[1] == 0x30) && (response[2] == 0x30)
			&& (response[3] == 0x31) && (response[4] == 0x20))
		{
			if ((response[5] == 0x44) && (channelNum == 1))//read speed
			{
				char  cByte[5];
				bzero(cByte, 5);//reset the cByte
				for (unsigned int i = 0; i < 4; i++)
				{
					response[i + 20] = response[i + 20] & 0xff;
					cByte[i] = response[i + 20];
				}
				cByte[4] = '\0';
				int ntempResult = 0;
				sscanf(cByte, "%x", &ntempResult);
				//unsigned int ntempResult = *((unsigned int*)(response + 20));//Extract the last 4 characters (unsigned int = 4 chars) from response[20] and assign them to ntempResult.
				float pfValue = (float)ntempResult;
				*value = pfValue * 60.0;//unit:rpm
				sendCommandOnly(&m_ack, 1);//testACK
				return true;
			}
			else if ((response[5] == 0x5B) && (channelNum == 2))//read temperature
			{
				char  cByte[5];
				bzero(cByte, 5);//reset the cByte
				//TMS temprature
				for (unsigned int i = 0; i < 4; i++)
				{
					response[i + 36] = response[i + 36] & 0xff;
					cByte[i] = response[i + 36];
				}
				cByte[4] = '\0';
				int ntempResult = 0;
				sscanf(cByte, "%x", &ntempResult);
				//unsigned int ntempResult = *((unsigned int*)(response + 36));//Extract the last 4 characters (unsigned int = 4 chars) from response[36] and assign them to ntempResult.
				float pfValue = (float)ntempResult;
				*value = pfValue;//unit:centigrade
				sendCommandOnly(&m_ack, 1);//testACK
				return true;
			}
			else if ((response[5] == 0x5B) && (channelNum == 3))//read current
			{
				char  cByte[2];
				bzero(cByte, 2);//reset the cByte
				//Motor current
				response[46] = response[46] & 0xff;
				response[47] = response[47] & 0xff;
				cByte[0] = response[46];
				cByte[1] = response[47];
				int ntempResult = 0;
				sscanf(cByte, "%x", &ntempResult);
				float pfValue = (float)ntempResult;
				*value = pfValue / 10.0;//unit:A
				sendCommandOnly(&m_ack, 1);//testACK
				return true;
			}
			else
			{
				//cout<< "TMP: reading data failed,response[5] is "<<Util::hexToString(response[5])<<endl;
				//return false;
				throw IOException("TMP: reading data failed,response[5] != 0x44");
			}
		}
		else
		{
			//cout<< "TMP:the read data command is invalid, response is "<<Util::hexToString(response[0])<<" "<<Util::hexToString(response[1])<<" "<<Util::hexToString(response[2])<<" "<<Util::hexToString(response[3])<<" "<<Util::hexToString(response[4])<<endl;
			//return false;
			throw IOException("TMP:the read data command is invalid");
		}
	}
}

/*!
	@brief This method is used to read Int type data from the hardware, and it internally uses the readCommand method.
	@param [in] channelNum The channel number.
	@param [in] typeInfo The Description of some features of the Data.
	@param [out] value The value read from the hardware.
	@exception IOException This exception is used to deal with:
		The channelNum is not registered on readDouble()
		The response back times out;
		Receive NAK;
		Response data incorrect;
	@return true if the readIntStatus was successful.
*/
bool TMPEdwardsStpiXA4507::readIntStatus(int channelNum, int* nvalue, const IntTypeInfo& typeinfo)//read start/stop status,channelnum=6
{
	char response[500];//save response status data
	//char option[500];//save option setting data ,para1~15
	char ackornak = 0x00;//save ack or nak
	if (isSimulated())
	{
		*nvalue = 0;//if simulated ,default as 0
		return true;
	}
	//set command according to value
	if (channelNum == 6)//read start/stop:Stx 0 0 1 ? M Etx LRC
	{
		m_readFixCmd[5] = 0x4D;//read start/stop ,set ASCII:M(hex:0x4D) 
	}
	else
	{
		//cout << "TMP:channelNum " << channelNum << " is not registered on readIntStatus()" << endl;
		throw IOException("TMP:channelNum 6 is not registered on readIntStatus()");
		//return false;
	}
	//common process
	//0.get LRC code
	//PC->SIM:wirte command with para and SIM->PC:return response
	//1. PC->SIM:send writing command
	//2.SIM->PC: ACK or NAK?
	//3.IF NAK:count and return false 
	//4.IF ACK
	//5.PC->SIM:ACK
	//6.SIM->PC:Stx 0 0 1 # Etx LR confirmed frame

	//0.get LRC code, caution:LRC=m_paraCmd[0] XOR m_paraCmd[1] XOR ...m_paraCmd[8],only 9 elements
	m_readFixCmd[7] = 0x00;
	m_readFixCmd[7] = CheckCalculationTool::GetXORCode(m_readFixCmd, 7);
	//1. PC->SIM:send writing command with para
	//2.SIM->PC: ACK or NAK in &ackornak
	bzero(response, RESP_LEN);
	try
	{
		//int nRet = getCommandResult(m_readFixCmd, 8, response, RESP_LEN, m_timeOut);//1/clearport(),sendCommandOnly(m_writeParaCmd, 10),return getResultOnly(&ackornak, 1, m_timeOut),get SIM->PC:ACK or NAK in &ackornak
		getFixCommandResult(m_readFixCmd, 8, response, STATUS_LEN, m_timeOut, 5);//STATUS_LEN=1+8+82*2=173
		/*for(int i=0;i<RESP_LEN;i++)
		{
			printf("StatusDI response[%d]:",i);
			printf("0x%02x\n",static_cast<unsigned char>(response[i]));
		}*/
		//3.IF NAK:count and return false 
//cout << "StatuDI SIM->PC:ackornak=" << Util::hexToString(ackornak) << endl;
		if (response[0] == NAK)
		{
			//cout << "StatuDI TMP:failed to send reading command because of receiving NAK" << endl;
			throw IOException("TMP:failed to send command because of receiving NAK");
			//return false;
		}
		//4.IF ACK
		else if (response[0] == m_ack)
		{
			//7.response data processing of different channel num
			//confirmed response start with: Stx 0 0 1 Sp
			if ((response[1] == m_confirmedFrame[0]) && (response[2] == m_confirmedFrame[1]) && (response[3] == m_confirmedFrame[2]) && (response[4] == m_confirmedFrame[3]) && (response[5] == 0x20))
			{
				//7.1 read status:Stx 0 0 1 Sp M para 1~82 Etx  LRC 
				if ((channelNum == 6) && (response[6] == 0x4D))
				{
					if ((response[7] == 0x30) && (response[8] == 0x34))//para1=04(ASCII),means normal=start
					{
						//*nvalue=0;
						*nvalue = Start;
					}
					else
					{
						//*nvalue=1;
						*nvalue = Stop;
					}
					//cout<<"readInt Value for status is:"<<*nvalue<<endl;
					sendCommandOnly(&m_ack, 1);//testACK
					//cout<<"StausDI end"<<endl;
					//cout<<"already send ack for channelNum=6"<<endl;
					return true;
				}
				else
				{
					//cout << "Invalid message in readIntStatus!" << endl;
					throw IOException("Invalid message in readIntStatus!");
					//return false;
				}
			}
			else
			{
				//cout << "The data frame is wrong , it doesn't start with Stx 0 0 1 Sp." << endl;
				throw IOException("The data frame is wrong , it doesn't start with Stx 0 0 1 Sp.");
				//return false;
			}
		}
		else
		{
			//cout << "SIM->PC:response is not ACK:0x06 or NAK:0x15, the value is" << Util::hexToString(response[0]) << endl;
			throw IOException("SIM->PC:response is not ACK:0x06 or NAK:0x15");
			//return false;
		}
	}
	catch (exception& ex)
	{
		throw IOException("readIntStatus failed");
		//cout << "readIntStatus failed" << endl;
	}
}

/*!
	@brief This method is used to read Int type data from the hardware, and it internally uses the readCommand method.
	@param [in] channelNum The channel number.
	@param [in] typeInfo The Description of some features of the Data.
	@param [out] value The value read from the hardware.
	@exception IOException This exception is used to deal with:
		The channelNum is not registered on readDouble()
		The response back times out;
		Receive NAK;
		Response data incorrect;
	@return true if the readIntStatus was successful.
*/
bool TMPEdwardsStpiXA4507::readIntOperationMode(int channelNum, int* nvalue, const IntTypeInfo& typeinfo)//read TMP mode,disabale,contains channelnum=9/10
{
	//cout<<"OfflineDI begin"<<endl;
	char response[500];//save response status data
	//char option[500];//save option setting data ,para1~15
	char ackornak = 0x00;//save ack or nak
	if (isSimulated())
	{
		*nvalue = 0;//if simulated ,default as 0
		return true;
	}
	//set command according to value
	if (channelNum == 9 || channelNum == 10)//read option frame(contains 232mode and disable):Stx 0 0 1 ? = Etx LRC
	{
		m_readFixCmd[5] = 0x3D;//set ASCII:=(hex:0x3D)
	}
	else
	{
		//cout << "TMP:channelNum " << channelNum << " is not registered on readIntOperationMode()" << endl;
		throw IOException("TMP:channelNum 9 or 10 is not registered on readIntOperationMode()");
		//return false;
	}

	//common process
	//0.get LRC code
	//PC->SIM:wirte command with para and SIM->PC:return response
	//1. PC->SIM:send writing command
	//2.SIM->PC: ACK or NAK?
	//3.IF NAK:count and return false 
	//4.IF ACK
	//5.PC->SIM:ACK
	//6.SIM->PC:Stx 0 0 1 # Etx LR confirmed frame

	//0.get LRC code, caution:LRC=m_paraCmd[0] XOR m_paraCmd[1] XOR ...m_paraCmd[8],only 9 elements
	m_readFixCmd[7] = CheckCalculationTool::GetXORCode(m_readFixCmd, 7);
	bzero(response, RESP_LEN);
	try
	{
		//1. PC->SIM:send writing command with para
		//2.SIM->PC: ACK or NAK in &ackornak
		getFixCommandResult(m_readFixCmd, 8, response, OPTION_LEN, m_timeOut, 5);//OPTION_LEN=1(ACK)+8+68=77
		//3.IF NAK:count and return false 
		if (response[0] == NAK)
		{

			//cout << "ControlDI/OfflineDI TMP:failed to send reading warning command because of receiving NAK" << endl;
			//throw IOException("TMP:failed to send reading warning command because of receiving NAK");
			//return false;
			throw IOException("TMP:failed to send command because of receiving NAK");
		}
		//4.IF ACK
		else if (response[0] == m_ack)
		{
			//7.response data processing of different channel num
			//confirmed response start with: Stx 0 0 1 Sp
			if ((response[1] == m_confirmedFrame[0]) && (response[2] == m_confirmedFrame[1]) && (response[3] == m_confirmedFrame[2]) && (response[4] == m_confirmedFrame[3]) && (response[5] == 0x20))
			{
				//7.1 read if TMP in 232 mode:Stx 0 0 1 Sp = para 1~15 Etx  LRC
				//if para1=05.232
				if ((channelNum == 9) && (response[6] == 0x3D))
				{
					//cout << "response[7] is " << Util::hexToString(response[7]) << endl;
					if (response[8] == 0x35)//para1==05(hex:0x30 0x35)
					{
						*nvalue = RS232;
					}
					else
					{
						*nvalue = Io;
						//cout << "TMP RS232 control failed, please check TMP control mode" << endl;
					}
					sendCommandOnly(&m_ack, 1);//testACK
					return true;
				}
				//7.3 read if disable TMPCommunicationOfflineStop:Stx 0 0 1 Sp = para 1~15 Etx  LRC
				//Enable:0,Disable:1
				else if ((channelNum == 10) && (response[6] == 0x3D))
				{
					//if para12=0000,disable
					if ((response[48] == 0x30) && (response[49] == 0x30) && (response[51] == 0x30) && (response[52] == 0x30))
					{
						//*nvalue = 1;
						*nvalue = Disable;
					}
					else
					{
						//*nvalue = 0;
						*nvalue = Enable;
					}
					sendCommandOnly(&m_ack, 1);//testACK
					//cout<<"OfflineDI end"<<endl;
					return true;
				}
				else
				{
					//cout << "Invalid message in readIntOperationMode!" << endl;
					throw IOException("Invalid message in readIntOperationMode!");
					//return false;
				}
			}
			else
			{
				//cout << "The data frame is wrong , it doesn't start with Stx 0 0 1 Sp." << endl;
				throw IOException("The data frame is wrong , it doesn't start with Stx 0 0 1 Sp.");
				//return false;
			}
		}
		else
		{
			//cout << "SIM->PC:response is not ACK:0x06 or NAK:0x15, the value is" << Util::hexToString(ackornak) << endl;
			throw IOException("SIM->PC:response is not ACK:0x06 or NAK:0x15");
			//return false;
		}
	}
	catch (exception& ex)
	{
		throw IOException("readIntOperationMode failed");
		//cout << "readIntOperationMode failed" << endl;
	}
}

/*!
	@brief This method is used to read Int type data from the hardware, and it internally uses the readCommand method.
	@param [in] channelNum The channel number.
	@param [in] typeInfo The Description of some features of the Data.
	@param [out] value The value read from the hardware.
	@exception IOException This exception is used to deal with:
		The channelNum is not registered on readIntWarningDI()
		The response back times out;
		Receive NAK;
		Response data incorrect;
	@return true if the readIntStatus was successful.
*/
bool TMPEdwardsStpiXA4507::readIntWarningDI(int channelNum, int* nvalue, const IntTypeInfo& typeinfo)//read if have warnings,channelnum=12
{
	//cout<<"WarningDI begin"<<endl;
	char response[500];//save warning data 8+81*
	char ackornak = 0x00;//save ack or nak
	//char ack = 0x06;
	//char res_lrc=0x00;//save the lrc of response with para
	if (isSimulated())
	{
		*nvalue = 0;
		return true;
	}
	//set command according to value
	if (channelNum == 12)//read warning:Stx 0 0 1 ? F Etx LRC
	{
		m_readFixCmd[5] = 0x46;//could be hex of F/=, read warning ,set ASCII:F(hex:0x46) 
	}
	else

	{
		//cout << "TMP:channelNum " << channelNum << " is not registered on readStrCommand()" << endl;
		throw IOException("TMP:channelNum 12 is not registered on readStrCommand()");
		//return false;
	}

	//common process
	//0.get LRC code
	//PC->SIM:wirte command with para and SIM->PC:return response
	//1. PC->SIM:send writing command
	//2.SIM->PC: ACK or NAK?
	//3.IF NAK:count and return false 
	//4.IF ACK
	//5.PC->SIM:ACK
	//6.SIM->PC:Stx 0 0 1 # Etx LR confirmed frame

	//0.get LRC code, caution:LRC=m_paraCmd[0] XOR m_paraCmd[1] XOR ...m_paraCmd[8],only 9 elements
	m_readFixCmd[7] = CheckCalculationTool::GetXORCode(m_readFixCmd, 7);
	bzero(response, RESP_LEN);
	try
	{
		//1. PC->SIM:send writing command with para
		//2.SIM->PC: ACK or NAK in &ackornak
		getFixCommandResult(m_readFixCmd, 8, response, WARN_LEN, m_timeOut, 5);
		/*for(int i=0;i<RESP_LEN;i++)
			{
			printf("WarningDI response[%d]:",i);
			printf("0x%02x\n",static_cast<unsigned char>(response[i]));
			}*/
			//3.IF NAK:count and return false 
		if (response[0] == NAK)
		{
			//cout << "WarningDI TMP:failed to send reading warning command because of receiving NAK" << endl;
			//return false;
			throw IOException("TMP:failed to send command because of receiving NAK");
		}
		//4.IF ACK
		else if (response[0] == m_ack)
		{
			//cout << "SIM->PC:ACK:" << Util::hexToString(ackornak) << endl;
			//5.PC->SIM:ACK
			//sendCommandOnly(&m_ack, 1);
			//6.SIM->PC
			//if ch=8,response is warning info,contains 8+81*2=170=WARN_LEN
			//7.response data processing of different channel num
			//confirmed response start with: Stx 0 0 1 Sp
			if ((response[1] == m_confirmedFrame[0]) && (response[2] == m_confirmedFrame[1]) && (response[3] == m_confirmedFrame[2]) && (response[4] == m_confirmedFrame[3]) && (response[5] == 0x20))
			{
				//7.1 warning message:Stx 0 0 1 Sp F para 1~81 Etx  LRC 
				if ((channelNum == 12) && (response[6] == 0x46))
				{
					//para 1=num of warning,hex->ASCII->int
					string str_num = "";
					str_num.push_back(response[7]);
					str_num.push_back(response[8]);
					int nwar_num = Hex::hexToInt(str_num);
					//cout << "Total " << nwar_num << " warnngs!" << endl;
					if (0 == nwar_num)
					{
						//*nvalue = 1;
						*nvalue = 0;
					}
					else
					{
						*nvalue = 1;
					}
					sendCommandOnly(&m_ack, 1);//testACK
					//cout<<"WarningDI end"<<endl;
					return true;
				}
				else
				{
					//cout << "Invalid message in readStrCommand!" << endl;
					throw IOException("Invalid message in readIntWarningDI!");
					//return false;
				}
			}
			else
			{
				//cout << "The data frame is wrong , it doesn't start with Stx 0 0 1 Sp." << endl;
				throw IOException("The data frame is wrong , it doesn't start with Stx 0 0 1 Sp.");
				//return false;
			}
		}
		else
		{
			//cout << "SIM->PC:response is not ACK:0x06 or NAK:0x15, the value is" << Util::hexToString(ackornak) << endl;
			throw IOException("SIM->PC:response is not ACK:0x06 or NAK:0x15");
			//return false;
		}
	}
	catch (exception& ex)
	{
		throw IOException("readIntWarningDI failed");
		//cout << "readIntWarningDI failed" << endl;
	}


}

/*!
	@brief This method is used to read String type data from the hardware.
	@param [in] channelNum The channel number.
	@param [in] typeInfo The Description of some features of the Data.
	@param [out] value The value read from the hardware.
	@exception IOException This exception is used to deal with:
		The channelNum is not registered on readStrCommand()
		The response back times out;
		Receive NAK;
		Response data incorrect;
	@return true if the readIntStatus was successful.
*/
bool TMPEdwardsStpiXA4507::readStrCommand(int channelNum, string* strvalue, const StringTypeInfo& typeinfo)//232 read warning
{
	char response[500];//save warning data 8+81*
	char ackornak = 0x00;//save ack or nak
	//char ack = 0x06;
	//char res_lrc=0x00;//save the lrc of response with para
	if (isSimulated())
	{
		*strvalue = "Simulated";
		return true;
	}
	//set command according to value
	if (channelNum == 8)//read warning:Stx 0 0 1 ? F Etx LRC
	{
		m_readFixCmd[5] = 0x46;//could be hex of F/=, read warning ,set ASCII:F(hex:0x46) 
	}
	else
	{
		//cout << "TMP:channelNum " << channelNum << " is not registered on readStrCommand()" << endl;
		throw IOException("TMP:channelNum 8 is not registered on readStrCommand()");
		//return false;
	}

	//common process
	//0.get LRC code
	//PC->SIM:wirte command with para and SIM->PC:return response
	//1. PC->SIM:send writing command
	//2.SIM->PC: ACK or NAK?
	//3.IF NAK:count and return false 
	//4.IF ACK
	//5.PC->SIM:ACK
	//6.SIM->PC:Stx 0 0 1 # Etx LR confirmed frame
	//0.get LRC code, caution:LRC=m_paraCmd[0] XOR m_paraCmd[1] XOR ...m_paraCmd[8],only 9 elements
	m_readFixCmd[7] = CheckCalculationTool::GetXORCode(m_readFixCmd, 7);
	bzero(response, RESP_LEN);
	try
	{
		//1. PC->SIM:send writing command with para
		//2.SIM->PC: ACK or NAK in &ackornak
//cout << "Warning232 init ackornak=" << Util::hexToString(ackornak) << endl;
		getFixCommandResult(m_readFixCmd, 8, response, WARN_LEN, m_timeOut, 5);
		//cout << "Warning232 receive ackornak=" << Util::hexToString(ackornak) << endl;
				//3.IF NAK:count and return false 
		if (response[0] == NAK)
		{
			//cout << "Warning232 TMP:failed to send reading warning command because of receiving NAK" << endl;
			//return false;
			throw IOException("TMP:failed to send command because of receiving NAK");
		}
		//4.IF ACK
		else if (response[0] == m_ack)
		{
			//cout << "SIM->PC:ACK:" << Util::hexToString(ackornak) << endl;
			//5.PC->SIM:ACK
			//sendCommandOnly(&m_ack, 1);
			//6.SIM->PC
			//if ch=8,response is warning info,contains 8+81*2=170=WARN_LEN
			//7.response data processing of different channel num
			//confirmed response start with: Stx 0 0 1 Sp
			if ((response[1] == m_confirmedFrame[0]) && (response[2] == m_confirmedFrame[1]) && (response[3] == m_confirmedFrame[2]) && (response[4] == m_confirmedFrame[3]) && (response[5] == 0x20))
			{
				//7.1 warning message:Stx 0 0 1 Sp F para 1~81 Etx  LRC 
				if ((channelNum == 8) && (response[6] == 0x46))
				{
					//para 1=num of warning,hex->ASCII->int
					//int nwar_num=hexToDecimal(response[6], response[7]);
					string str_warning = "";
					string str_num = "";
					str_num.push_back(response[7]);
					str_num.push_back(response[8]);
					int nwar_num = Hex::hexToInt(str_num);
					//cout<< "Total "<<nwar_num<<" warnngs!"<<endl;
					for (int i = 1; i <= nwar_num; i++)
					{
						if (i > 245)
						{
							break;//avoid 8+2*246=500=response[500],array overflow
						}
						str_num = "";
						str_num.push_back(response[7 + 2 * i]);
						str_num.push_back(response[7 + 2 * i + 1]);
						int nwar_value = Hex::hexToInt(str_num);
						//int nwar_value=hexToDecimal(response[6 + 2 * i], response[6 + 2 * i + 1]);
						//cout<< "The NO."<<i<<" warning_value is "<< static_cast<char>(response[7+2*i])<< static_cast<char>(response[7 + 2 * i + 1])<< endl;//print ASCII of warning
						//cout << "warning value is:" << nwar_value << endl;//print decimal of warning
						//auto it = m_warningMap.find(nwar_value);
						if (m_warningMap.find(nwar_value) != m_warningMap.end())
						{
							str_warning += m_warningMap[nwar_value];
						}
						else
						{
							str_warning += "Unknown warning value\n";
						}
					}
					*strvalue = str_warning;
					if ("" != str_warning)
					{
						SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "warning is " + str_warning);
						//cout << "warning is " << str_warning << endl;
					}
					sendCommandOnly(&m_ack, 1);//testACK
					return true;
				}
				else
				{
					//cout << "Invalid message in readStrCommand!" << endl;
					throw IOException("Invalid message in readStrCommand!");
					//return false;
				}
			}
			else
			{
				//cout << "The data frame is wrong , it doesn't start with Stx 0 0 1 Sp." << endl;
				throw IOException("The data frame is wrong , it doesn't start with Stx 0 0 1 Sp.");
				//return false;
			}
		}
		else
		{
			//cout << "SIM->PC:response is not ACK:0x06 or NAK:0x15, the value is" << Util::hexToString(ackornak) << endl;
			throw IOException("SIM->PC:response is not ACK:0x06 or NAK:0x15");
			//return false;
		}
	}
	catch (exception& ex)
	{
		throw IOException("readStrCommand failed");
		//cout << "readStrCommand failed" << endl;
	}
}

/*!
	@brief This method is used to write Int type data to the hardware.
	@param [in] channelNum The channel number.
	@param [in] value The value to be written.
	@param [in] typeInfo The Description of some features of the Data.
		The channelNum is not registered in writeIntStatus()
		The response back times out;
		Receive NAK;
		Response data incorrect;
	@return true if the readIntStatus was successful.
*/
bool TMPEdwardsStpiXA4507::writeIntStatus(int channelNum, int nvalue, const IntTypeInfo& typeinfo)//set start/stop/reset.channelnum=7
{
	char response[200];//save response data
	char ackornak = 0x00;//save ack or nak
	//char ack = 0x06;
	int nRet = -1;
	if (isSimulated())
	{
		return true;
	}
	//set command according to value
	//set start/stop/reset command
	if (channelNum == 7)
	{

		//if (nvalue == 1)
		if (nvalue == Start)
		{
			m_writeParaCmd[7] = 0x31;//start,value:01(hex:0x30 0x31)
		}
		//else if (nvalue == 0)
		else if (nvalue == Stop)
		{
			m_writeParaCmd[7] = 0x32;//stop,value:02(hex:0x30 0x32)
		}
		//else if (nvalue == 2)
		else if (nvalue == Reset)
		{
			m_writeParaCmd[7] = 0x34;//reset,value:04(hex:0x30 0x34)
		}
		else
		{
			//cout << "TMP:Power value is 0/1/2,0 means on.1 means off,2 means reset,but curren value is " << nvalue << "." << endl;
			throw IOException("TMP:Power value is 0/1/2,please check current value!");
			//return false;
		}
	}
	else
	{
		//cout << "TMP:channelNum " << channelNum << " is not registered on writeIntStatus()" << endl;
		throw IOException("TMP:channelNum 8 is not registered on writeIntStatus()");
		//return false;
	}

	//common process
	//0.get LRC code
	//PC->SIM:wirte command with para and SIM->PC:return response
	//1. PC->SIM:send writing command
	//2.SIM->PC: ACK or NAK?
	//3.IF NAK:count and return false 
	//4.IF ACK
	//5.PC->SIM:ACK
	//6.SIM->PC:Stx 0 0 1 # Etx LR confirmed frame

	//0.get LRC code, caution:LRC=m_paraCmd[0] XOR m_paraCmd[1] XOR ...m_paraCmd[8],only 9 elements
	m_writeParaCmd[9] = CheckCalculationTool::GetXORCode(m_writeParaCmd, 9);
	//printf("0x%02x\n",static_cast<unsigned char>(m_writeParaCmd[9]));
	try
	{
		//1. PC->SIM:send writing command with para
		//2.SIM->PC: ACK or NAK in &ackornak
		if (channelNum == 7)
		{
			nRet = getCommandResult(m_writeParaCmd, 10, &ackornak, 1, m_timeOut);//1/clearport(),sendCommandOnly(m_writeParaCmd, 10),return getResultOnly(&ackornak, 1, m_timeOut),get SIM->PC:ACK or NAK in &ackornak
		}
		else
		{
			//cout << "TMP:channelNum " << channelNum << " is not registered on writeIntStatus()" << endl;
			throw IOException("TMP:channelNum 8 is not registered on writeIntStatus()");
			//return false;
		}

		if (nRet < 0)
		{
			//cout << "TMP:writeIntStatus back times out..." << endl;
			throw IOException("TMP:writeIntStatus back times out...");
			//return false;
		}
		//3.IF NAK:count and return false 
		if (ackornak == NAK)
		{
			//cout << "StatuDO TMP:failed to send on/off/reset command because of receiving NAK" << endl;
			//return false;
			throw IOException("TMP:failed to send command because of receiving NAK");
		}
		//4.IF ACK
		else if (ackornak == m_ack)
		{
			//cout << "SIM->PC:ACK:" << Util::hexToString(ackornak) << endl;
			//5.PC->SIM:ACK
			//m_dev.writeRaw(&ack, 1);
			//sendCommandOnly(&ack, 1);
			//sendCommandOnly(&m_ack, 1);
			//sendOnlyNoClearPort(&ack, 1);
			//6.SIM->PC:Stx 0 0 1 # Etx LRC confirmed frame,7 means confirmed frame contains 7 bytes
			//getFixResultOnly(response, CONFIRM_LEN, TIME_OUT, 3);//Write the response frame to the response[RESP_LEN] array, where each element of the array represents one byte.
			int nResponseLength = m_dev.readStr(response, TIME_OUT, CONFIRM_LEN);
			if (nResponseLength < 0)
			{
				// cout << "TMP:readStr back times out.."<< endl;
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "TMP:readStr back times out..");//add by Liuxj [1.1.4]
				//return false;
				throw IOException("TMP:reading response back times out..");
			}

			for (unsigned int i = 0; i < 7; i++)
			{
				//cout << "response is " << Util::hexToString(response[i]) << endl;
				if (response[i] == m_confirmedFrame[i])
				{
					continue;
				}
				else
				{
					//cout << "TMP:the writing command is wrong, incorrect response [" << i << "] is " << Util::hexToString(response[i]) << endl;
					throw IOException("TMP:the confirmed frame is wrong.");
					//return false;
				}
			}
			//*value=1;//refer to on/off/reset successfully
			//cout << "writeInt successfully in writeIntStatus" << endl;
			sendCommandOnly(&m_ack, 1);//testACK
			return true;
		}
		else
		{
			//cout << "SIM->PC:response is not ACK:0x06 or NAK:0x15, the value is" << Util::hexToString(ackornak) << endl;
			throw IOException("SIM->PC:response is not ACK:0x06 or NAK:0x15");
			//return false;
		}
	}
	catch (exception& ex)
	{
		throw IOException("writeIntStatus failed");
		//cout << "writeIntStatus failed" << endl;
	}
}

/*!
	@brief This method is used to write Int type data to the hardware.
	@param [in] channelNum The channel number.
	@param [in] value The value to be written.
	@param [in] typeInfo The Description of some features of the Data.
		The channelNum is not registered in writeIntOperationMode()
		The response back times out;
		Receive NAK;
		Response data incorrect;
	@return true if the readIntStatus was successful.
*/
bool TMPEdwardsStpiXA4507::writeIntOperationMode(int channelNum, int nvalue, const IntTypeInfo& typeinfo)//set disable,channelnum=11
{
	char response[200];//save response data
	char ackornak = 0x00;//save ack or nak
	//char ack = 0x06;
	int nRet = -1;
	if (isSimulated())
	{
		return true;
	}

	//set Enable/Disable,default as Disable
	if (channelNum == 11)
	{
		if (nvalue == Enable)
		{
			//cout << "set Enable" << endl;
			m_optionParaCmd[50] = 0x33;
			m_optionParaCmd[51] = 0x43;
		}
		else if (nvalue == Disable)
		{
			//cout << "set Disable" << endl;
			m_optionParaCmd[50] = 0x30;
			m_optionParaCmd[51] = 0x30;
		}
		else
		{
			//cout<<"Wrong setting value for TMPCommunicationOfflineStopDO"<<endl;
			throw IOException("Wrong setting value for TMPCommunicationOfflineStopDO");
		}
	}
	else
	{
		//cout << "TMP:channelNum " << channelNum << " is not registered on writeIntOperationMode()" << endl;
		throw IOException("TMP:channelNum 11 is not registered on writeIntOperationMode()");
		//return false;
	}

	//common process
	//0.get LRC code
	//PC->SIM:wirte command with para and SIM->PC:return response
	//1. PC->SIM:send writing command
	//2.SIM->PC: ACK or NAK?
	//3.IF NAK:count and return false 
	//4.IF ACK
	//5.PC->SIM:ACK
	//6.SIM->PC:Stx 0 0 1 # Etx LR confirmed frame

	//0.get LRC code, caution:LRC=m_paraCmd[0] XOR m_paraCmd[1] XOR ...m_paraCmd[8],only 9 elements
	m_optionParaCmd[75] = CheckCalculationTool::GetXORCode(m_optionParaCmd, 75);
	//printf("m_optionParaCmd[75]: 0x%02x\n",static_cast<unsigned char>(m_optionParaCmd[75]));
	try
	{
		//1. PC->SIM:send writing command with para
		//2.SIM->PC: ACK or NAK in &ackornak
		if (channelNum == 11)
		{
			nRet = getCommandResult(m_optionParaCmd, 76, &ackornak, 1, m_timeOut);//1/clearport(),sendCommandOnly(m_writeParaCmd, 10),return getResultOnly(&ackornak, 1, m_timeOut),get SIM->PC:ACK or NAK in &ackornak
			//printf("m_optionParaCmd[50]: 0x%02x\n",static_cast<unsigned char>(m_optionParaCmd[50]));
			//printf("m_optionParaCmd[51]: 0x%02x\n",static_cast<unsigned char>(m_optionParaCmd[51]));
		}
		else
		{
			//cout << "TMP:channelNum " << channelNum << " is not registered on writeIntOperationMode()" << endl;
			throw IOException("TMP:channelNum 11 is not registered on writeIntOperationMode()");
			//return false;
		}

		if (nRet < 0)
		{
			//cout << "TMP:writeIntOperationMode back times out..." << endl;
			throw IOException("TMP:writeIntOperationMode back times out...");
			//return false;
		}
		//3.IF NAK:count and return false 
		if (ackornak == NAK)
		{
			//cout << "ControlDO/offlinDO TMP:failed to set OptionMode command because of receiving NAK" << endl;
			//return false;
			throw IOException("TMP:failed to send command because of receiving NAK");
		}
		//4.IF ACK
		else if (ackornak == m_ack)
		{
			//cout << "SIM->PC:ACK:" << Util::hexToString(ackornak) << endl;
			//5.PC->SIM:ACK
			//m_dev.writeRaw(&ack, 1);
			//sendCommandOnly(&ack, 1);
			//sendCommandOnly(&m_ack, 1);
			//sendOnlyNoClearPort(&ack, 1);
			//6.SIM->PC:Stx 0 0 1 # Etx LRC confirmed frame,7 means confirmed frame contains 7 bytes
			//getFixResultOnly(response, CONFIRM_LEN, TIME_OUT, 3);//Write the response frame to the response[RESP_LEN] array, with each element representing one byte.
			int nResponseLength = m_dev.readStr(response, TIME_OUT, CONFIRM_LEN);
			if (nResponseLength < 0)
			{
				// cout << "TMP:readStr back times out.."<< endl;
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "TMP:readStr back times out..");//add by Liuxj [1.1.4]
				//return false;
				throw IOException("TMP:reading response back times out..");
			}

			for (unsigned int i = 0; i < 7; i++)
			{
				//cout << "response is " << Util::hexToString(response[i]) << endl;
				if (response[i] == m_confirmedFrame[i])
				{
					continue;
				}
				else
				{
					//cout << "TMP:the writing command is wrong, incorrect response [" << i << "] is " << Util::hexToString(response[i]) << endl;
					throw IOException("TMP:the confirmed frame is wrong.");
					//return false;
				}
			}
			//*value=1;//refer to on/off/reset successfully
			//cout << "writeInt successfully in writeIntOperationMode" << endl;
			sendCommandOnly(&m_ack, 1);//testACK
			return true;
		}
		else
		{
			//cout << "SIM->PC:response is not ACK:0x06 or NAK:0x15, the value is" << Util::hexToString(ackornak) << endl;
			throw IOException("SIM->PC:response is not ACK:0x06 or NAK:0x15");
			//return false;
		}
	}
	catch (exception& ex)
	{
		throw IOException("writeIntOperationMode failed");
		//cout << "writeIntOperationMode failed" << endl;
	}
}



//register channel
void TMPEdwardsStpiXA4507::initChs(DeviceNode<TMPEdwardsStpiXA4507>* node)
{
	//cout << "TMPEdwardsStpiXA4507::initChs()" << endl;
	node->registerReadCh(0, &TMPEdwardsStpiXA4507::getStatus);

	for (unsigned int i = 1; i <= 3; i++)
	{
		node->registerReadCh(i, &TMPEdwardsStpiXA4507::readDouble);
	}

	/*for(unsigned int i = 4; i <= 5; i++)
	{
		node->registerReadCh(i, &TMPEdwardsStpiXA4507::readString);//read error and warning.
	}*/
	//cout << "TMPEdwardsStpiXA4507::initChs(6~12)" << endl;

	//node->registerReadCh(i, &TMPEdwardsStpiXA4507::writeCommand);//read error and warning.//The binding is for the read channel, which should correspond to the "R" in the IO_config. If it is an RW channel, remember to use WriteCh.
	node->registerReadCh(6, &TMPEdwardsStpiXA4507::readIntStatus);//read start/stop/reset    
	node->registerWriteCh(7, &TMPEdwardsStpiXA4507::writeIntStatus);//set start/stop/reset
	node->registerReadCh(8, &TMPEdwardsStpiXA4507::readStrCommand);//read warning
	node->registerReadCh(9, &TMPEdwardsStpiXA4507::readIntOperationMode);//read TMPControlDI:232 mod
	node->registerReadCh(10, &TMPEdwardsStpiXA4507::readIntOperationMode);//read TMPCommunicationOfflineStopDI:option disable
	node->registerWriteCh(11, &TMPEdwardsStpiXA4507::writeIntOperationMode);//set TMPCommunicationOfflineStopDO:option disable
	node->registerReadCh(12, &TMPEdwardsStpiXA4507::readIntWarningDI);
	//node->registerWriteCh(9, &TMPEdwardsStpiXA4507::writeStrCommand);
}

void TMPEdwardsStpiXA4507::initDevice()
{
	//say hello 
	double dTemp;
	try
	{
		readDouble(2, &dTemp, DoubleTypeInfo());
	}
	catch (exception& ex)
	{
		cout << "Scan TurboMolecularPump failed. Communication abnormal!" << endl;
		throw;
	}
	cout << "Scan TurboMolecularPump Successfully...." << endl;
}

//init device		
void TMPEdwardsStpiXA4507::init()
{
	//cout << getName() + "TMPEdwardsStpiXA4507 init start" << endl;
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "TMPEdwardsStpiXA4507 start");
	DeviceNode<TMPEdwardsStpiXA4507>* node = new DeviceNode<TMPEdwardsStpiXA4507>(m_pollPeriod, this);
	if (!isSimulated())
	{
		initChs(node);
		initDevice();
	}
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	//cout << getName() + "TMPEdwardsStpiXA4507 end start" << endl;
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "TMPEdwardsStpiXA4507 end");
}

IMPLEMENT_DYNAMIC(TMPEdwardsStpiXA4507, SerialDevice)

BEGIN_MSG_MAP(TMPEdwardsStpiXA4507, SerialDevice)
	SET_V(init, TMPEdwardsStpiXA4507)
END_MSG_MAP



