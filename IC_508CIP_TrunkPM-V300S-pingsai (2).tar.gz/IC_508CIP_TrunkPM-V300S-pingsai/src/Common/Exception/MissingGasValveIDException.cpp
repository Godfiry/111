/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MissingGasValveIDException.cpp
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-03-20   LiJuanjuan create
**      
*********************************************************************/
#include "MissingGasValveIDException.h"

MissingGasValveIDException::MissingGasValveIDException(const std::string &s):TMCException(s)
{
}
