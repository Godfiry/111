/*
 * RecipeTypeValueInfo.cpp
 *
 *  Created on: 2025.5.28
 *      Author: mujingyan
 */

#include "RecipeTypeValueInfo.h"
#include "CTCExport.h"
#include "RecipeNamespaceManager.h"
#include <vector>
#include <iostream>
#include <algorithm>//include std::find
#ifdef IAP4_0
using namespace IAP::RECIPE;
#endif

using namespace std;

RecipeTypeValueInfo* RecipeTypeValueInfo::m_instance = NULL;

RecipeTypeValueInfo::RecipeTypeValueInfo() 
{
    m_bGroupRecipe = false;
    m_bFatherChildRecipe = false;
    createValueInfo();
}

RecipeTypeValueInfo::~RecipeTypeValueInfo() 
{
    
}

RecipeTypeValueInfo* RecipeTypeValueInfo::getInstance()
{
	if (NULL == m_instance)
	{
		m_instance = new RecipeTypeValueInfo();
	}

	return m_instance;
}

void RecipeTypeValueInfo::createValueInfo()
{
    m_pRecipeType = new ReadWriteInt(getName() + "/RecipeType", IntTypeInfo(DescriptorList("Default,FatherChildRecipe,GroupRecipe")));
    m_pRecipeType->setValue("Default");
    CTCExport::exportAsOthers(m_pRecipeType, "PM_RecipeType");

    vector<string> rcpClassVector = RecipeNamespaceManager::getInstance()->getAllRcpClasses();
    if (std::find(rcpClassVector.begin(), rcpClassVector.end(), "/ChildProcess") != rcpClassVector.end())
    {
        m_pRecipeType->setValue("FatherChildRecipe");
        m_bFatherChildRecipe = true;
    }
    else if (std::find(rcpClassVector.begin(), rcpClassVector.end(), "/Process") != rcpClassVector.end())
    {
        vector<const Parameter*> parameter = RecipeNamespaceManager::getInstance()->getRcpClassTemplate("/Process");
        bool bFindGroupName = false;
        bool bFindCycleNum = false;
        for (unsigned int i = 0; i < parameter.size(); i++)
        {
            string strParameterName = parameter[i]->getName();

            if (strParameterName == "GroupName")
            {
                bFindGroupName = true;
            }
            if (strParameterName == "CycleNum")
            {
                bFindCycleNum = true;
            }
            if (bFindCycleNum && bFindGroupName)
            {
                m_pRecipeType->setValue("GroupRecipe");
                m_bGroupRecipe = true;
                break;
            }
        }
    }
}

void RecipeTypeValueInfo::printValue()
{
    cout << "Recipe Type is " << m_pRecipeType->getValueAsDescriptor() << endl;
    cout<<(m_bGroupRecipe ? "GroupRecipe" : "RecipeType is not GroupRecipe")<<endl;
    cout<<(m_bFatherChildRecipe ? "FatherChildRecipe":"RecipeType is not FatherChildRecipe")<<endl;
}
bool RecipeTypeValueInfo::isGroupRecipe()
{
	return m_bGroupRecipe;
}

bool RecipeTypeValueInfo::isFatherChildRecipe()
{
	return m_bFatherChildRecipe;
}

