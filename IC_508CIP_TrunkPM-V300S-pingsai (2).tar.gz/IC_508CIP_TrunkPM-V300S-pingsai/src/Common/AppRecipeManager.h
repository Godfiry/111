/*
 * AppRecipeManager.h
 *
 *  Created on: 2025-8-5
 *      Author: taohao
 */

#ifndef SRC_COMMON_APPRECIPEMANAGER_H_
#define SRC_COMMON_APPRECIPEMANAGER_H_

#include "ControlObject.h"
#include "BlockingAlarm.h"
#include "NonBlockingAlarm.h"
#include "ReadWriteInt.h"
#include "AppCondition.h"
#include "RecipeNamespaceManager.h"
#include "Service.h"
#include "RecipeUser.h"
#include "ExecRcpHandler.h"
#include "Timer.h"
#include <map>
#include <vector>
#include <string>
#include "AppRcpBody.h"
#include "ReadWriteInt.h"
#include "ReadWriteString.h"
#include "DataType.h"
#include "RecipeMgmtEvent.h"
#include "CBase.h"
#include "IMutex.h"
#include "Setup.h"
#ifdef IAP4_0
using namespace IAP;
using namespace IAP::RECIPE;
using namespace IAP::CONTROL;
using namespace IAP::CORE;
using namespace IAP::SETUP;
using namespace IAP::ALARM;
using namespace IAP::IO;
#endif

#define MAX_RECIPE_NUM 50
#define MAX_BUFFER_SIZE 6

const std::string m_strTrue = "true";
const std::string m_strFalse = "false";
const std::string m_strAll = "all";
const std::string m_strBuffer = "buffer";

typedef struct
{
    std::string rcpVersion;
    unsigned int rcpNumOfSteps;
    unsigned int rcpNumOfParams;
    double rcpBodyTotalProcessTime;
}RcpInfo;

typedef enum
{
    OneRecipe,
    AllRecipes,
    Buffer,
    Error
} OperationType;

class AppRecipeManager : public ControlObject, public RecipeUser, public CBase
{
    DECLARE_DYNAMIC( AppRecipeManager )
    DECLARE_MSG_MAP

    DECLARE_SERVICEINFO_LIST

    public:
        class StoreRecipeToMemory : public Service
        {
            DECLARE_DYNAMIC_SERVICE(StoreRecipeToMemory)

            public:
                void execute();
        };
        class DeleteRecipeBodyFiles : public Service
        {
            DECLARE_DYNAMIC_SERVICE(DeleteRecipeBodyFiles)

            public:
                void execute();
        };
        class DeleteRecipeFromMemory : public Service
        {
            DECLARE_DYNAMIC_SERVICE(DeleteRecipeFromMemory)

            public:
                void execute();
        };

    public:
        AppRecipeManager();
        virtual ~AppRecipeManager();

    public:
        ServicePtr<StoreRecipeToMemory> m_sStoreRecipeToMemory;
        ServicePtr<DeleteRecipeBodyFiles> m_sDeleteRecipeBodyFiles;
        ServicePtr<DeleteRecipeFromMemory> m_sDeleteRecipeFromMemory;

        virtual void make();
        virtual void initialize();
        virtual void shutdown();

    public:
        virtual std::string call_StoreRecipeToMemory(const std::string &strRecipeID);
        virtual std::string call_DeleteRecipeBodyFiles(const std::string &strRecipeID);
        virtual std::string call_DeleteRecipeFromMemory(const std::string &strRecipeID);

        virtual std::string do_StoreRecipeToMemory(const std::string &strRecipeID);
        virtual std::string do_DeleteRecipeBodyFiles(const std::string &stRecipeID);
        virtual std::string do_DeleteRecipeFromMemory(const std::string &strRecipeID);

    public:
        static AppRecipeManager* getInstance();
        std::string getCurrentRecipeFullName() const;
        AppRcpBody* makeCurrentRecipeBody(bool bLiveEdit = false);
        bool isOpenDeleteFunction(const std::string &strRecipeID = "") const;
        bool isDryCleanProcessType(const std::string &strRecipeID = "") const;
        bool isSpecialRecipe(const std::string &strRecipeID = "",bool bSpecialRecipe = false) const;
        //bool isSpecialComments(const std::string& strRecipeID) const;
        bool isSpecialComments(const ExecRcpHandler &handler) const;//added by taohao[1.5.0_HotFix9] for special recipe with Comments
        bool isExistInMemory(const std::string &strRecipeID) const;//added by taohao[1.5.0_HotFix9] for special recipe with Comments

    public:
        //ExecRcpHandler
        std::string getHandlerClass() const;
        unsigned int getNumOfSteps() const;
        std::string getStepValueAS(unsigned int , const std::string &strParamName) const;
        std::string getRcpHandlerName();
        std::string getVersion() const;
        unsigned int getNumOfParams() const;
        void getStepValue(unsigned int nStepIndex, const std::string &strParamName, ValueInfo &vInfo) const;
        std::string getParamName(unsigned int index) const;
        bool setStepValue(unsigned int nStepIndex, unsigned int nParamIndex, const std::string &strValue, bool bNeedNotify = true);
        bool setStepValue(unsigned int nStepIndex, string strParamName, const std::string &strValue, bool bNeedNotify = true);
        std::string getRecipeID() const;
        bool verify() const;
        IO::DataType getParamType(const std::string &strName) const;
        double calculateProcessTotalTime(AppRcpBody *rcpBody) const;
        double calculateProcessTotalTime() const;

    public:
        //RecipeMgmtSession
        void releaseRecipe(const std::string &strRecipeID);
        void retrieveRecipe(const std::string &strRecipeID,bool bSpecialRecipe = false, bool bExclusive = false);
        void storeRecipe(const std::string &strRecipeID,bool bOverwrite = true);
        void clear(const std::string &strRecipeID);
        void notifyOtherSession(const RecipeMgmtEvent &event);
        vector<string> getRcpIDsUnder(const string& clsName) const;//add by ps 1.11.0
		std::string getRecipeName(const std::string& strRecipeID) const;
		ExecRcpHandler getRecipeHandler(const std::string& strRecipeID, bool bExclusive = false);

    protected:
        int checkRecipeName(const std::string &strRecipeID) const;
        std::string extractRcpFullName(const std::string &strFileName) const;
        bool isGetRcpInfoFromIAP(const std::string &strRecipeID = "",bool bSpecialRecipe = false) const;//added by taohao[1.10.0]

    private:
        AppRcpBody* getRcpBodyFromMemory(const std::string &strRecipeID) const;
        RcpInfo getRcpBodyInfoFromMemory(const std::string &strRecipeID) const;
        std::string refreshRecipeBodyMap(const std::string &strRecipeID,AppRcpBody *rcpBody,const ExecRcpHandler &handler);
        void deleteSameElementInMemory(const std::string &strRecipeID);
        std::string executeDeleteFile(const std::string &strNeedDeleteRecipeName);
        void setCurrentRecipeFullName(const std::string &strRecipeID);
        void clearCurrentRecipeFullName();

    protected:
        ReadWriteInt *m_cfgDeleteRecipeFlag;
        NonBlockingAlarm *m_pExecuteRecipeFailed;
        NonBlockingAlarm *m_pServiceFailedAlarm;
        ReadWriteString *m_pErrorDescription;
        ReadWriteString *m_pServiceName;
        mutable std::string m_strCurrentRecipeFullName;
        mutable IMutex m_lock;

    private:
        mutable std::map<std::string,AppRcpBody*> m_allRecipeBody;
        std::map<std::string,RcpInfo> m_rcpBodyParam;
        //different jobs use the same recipe, modification takes effect when next process
        mutable std::map<std::string,AppRcpBody*> m_rcpBodyBuffer;
        std::map<std::string,RcpInfo> m_rcpBodyParamBuffer;

        ExecRcpHandler m_CurrentRcpHandler;
        AppRcpBody *m_pRecipeBodyFromMemory;
        AppRcpBody *m_pRecipeBodyFromIAP;
        RcpInfo m_rcpInfo;

        RecipeMgmtSession *m_pSession;
        static AppRecipeManager* m_pInstance;
};
#endif /* SRC_COMMON_APPRECIPEMANAGER_H_ */
