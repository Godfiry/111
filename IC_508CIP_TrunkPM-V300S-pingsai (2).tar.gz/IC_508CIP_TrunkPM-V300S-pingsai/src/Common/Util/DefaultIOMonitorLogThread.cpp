/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: DefaultIOMonitorLogThread.cpp
** Description: 
** Release: 
** Modification history: 
** 					2015-07-09  lvjw  create 
**      			2018-12-27  mujy modify the function of dealWithTheData
***************************************************************************/


#include "DefaultIOMonitorLogThread.h"
#include "Converter.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
#endif
using namespace std;


DefaultIOMonitorLogThread::DefaultIOMonitorLogThread()
{
}

DefaultIOMonitorLogThread::~DefaultIOMonitorLogThread()
{
}

void DefaultIOMonitorLogThread::dealWithTheData(MonitorData &pData)//modified by mujy [1.2]
{
	m_plogger->logMsg(
			  pData.strName
			+ " Value="+     pData.pValueInfo->getValueAsString()
			);
	delete pData.pValueInfo;//added by dingjie[1.1.47]
	pData.pValueInfo = NULL;
}

IMPLEMENT_DYNAMIC(DefaultIOMonitorLogThread, IOMonitorLogThread)

