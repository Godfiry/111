/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: RcpStepCancelException.h
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-09-2  LiJuanjuan create
**      
*********************************************************************/
#ifndef RCPSTEPCANCELEXCEPTION_H_
#define RCPSTEPCANCELEXCEPTION_H_

#include "TMCException.h"

class RcpStepCancelException:public TMCException
{
	public:
		RcpStepCancelException(const std::string &s);
};

#endif /*RCPSTEPCANCELEXCEPTION_H_*/
