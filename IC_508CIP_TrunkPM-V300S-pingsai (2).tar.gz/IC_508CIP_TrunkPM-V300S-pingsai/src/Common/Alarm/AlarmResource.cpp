#include "AlarmResource.h"
#include "BlockingAlarmEX.h"
#include "NonBlockingAlarmEX.h"
#include "ConfigException.h"
#include "StrManager.h"
#include "AlarmReNameManager.h"
#include <iostream>

using namespace std;

AlarmResource::AlarmResource()
{
	m_strName="";
	m_strBlockingType="";
	m_nMsgStringID=-1;
	m_nDesStringID=-1;
	m_nSeverity=0;//UNKNOWN
	m_bHasAbort=false;
	m_bHasRetry=false;
	m_bHasContinue=false;
	m_strAbort="Abort";
	m_strRetry="Retry";
	m_strContinue="Ignore and Continue";
}

AlarmResource::~AlarmResource()
{
}

void AlarmResource::make()
{
}

void AlarmResource::setName(const std::string &strName)
{
	m_strName=strName;
}

void AlarmResource::setBlockingType(const std::string &strType)
{
	//todo : change to lowercase;
	m_strBlockingType=strType;
}

void AlarmResource::setMessage(int nStringID)
{
	m_nMsgStringID=nStringID;
}

void AlarmResource::setDescription(int nStringID)
{
	m_nDesStringID=nStringID;
}

void AlarmResource::setSeverity(int nSeverity)
{
	if(nSeverity<0 || nSeverity>5)
	{
		throw ConfigException("alarm resource build err:error Severity type.");
	}
	m_nSeverity=nSeverity;
}

void AlarmResource::addRecovery(const std::string &strType)
{
	//todo : change to lowercase;
	if(strType==RECOVERY_TYPE_ABORT)
	{
		m_bHasAbort=true;
	}
	else if(strType==RECOVERY_TYPE_RETRY)
	{
		m_bHasRetry=true;
	}
	else if(strType==RECOVERY_TYPE_CONTINUE)
	{
		m_bHasContinue=true;
	}
	else
	{
		throw ConfigException("alarm resource build err:error recovery type.");
	}
}

void AlarmResource::addRecoveryWithName(const std::string &strName,const std::string &strType)
{
	//todo : change to lowercase;
	if(strType==RECOVERY_TYPE_ABORT)
	{
		m_strAbort=strName;
		m_bHasAbort=true;
	}
	else if(strType==RECOVERY_TYPE_RETRY)
	{
		m_strRetry=strName;
		m_bHasRetry=true;
	}
	else if(strType==RECOVERY_TYPE_CONTINUE)
	{
		m_strContinue=strName;
		m_bHasContinue=true;
	}
	else
	{
		throw ConfigException("alarm resource build err:error recovery type.");
	}
}

Alarm* AlarmResource::buildAlarm(AlarmPoster* pPoster)
{
	Alarm* pResult=NULL;
	
	if(pPoster==NULL)
	{
		throw ConfigException(getSelfName()+":alarm resource build err:No alarm Poster");
	}
	if(pPoster->getID()=="")
	{
		throw ConfigException(getSelfName()+":alarm resource build err:No alarm PosterID");
	}
	if(m_strName=="")
	{
		throw ConfigException(getSelfName()+":alarm resource build err:err name");
	}
	if(StrManager::getInstance()->GetString(m_nMsgStringID)=="")
	{
		Log_Error(getSelfName()+":message string ID is not exist or hadn't config.");
	}
	if(StrManager::getInstance()->GetString(m_nDesStringID)=="")
	{
		Log_Error(getSelfName()+":description string ID is not exist or hadn't config.");
	}
	
	string strPreName=AlarmReNameManager::getInstance()->GetShowName(pPoster->getID());
	if(m_strBlockingType==BLOCKING)
	{
		if(m_bHasAbort||m_bHasRetry||m_bHasContinue)
		{
			BlockingAlarmEX *pBlockingAlarm=new BlockingAlarmEX(strPreName+"_"+m_strName,"","",(Alarm::Severity)m_nSeverity);
			pBlockingAlarm->setMessage(m_nMsgStringID);
			pBlockingAlarm->setDescription(m_nDesStringID);
			if(m_bHasAbort)
			{
				pBlockingAlarm->addRecovery(new Recovery(m_strAbort,  Recovery::ABORT));
			}
			if(m_bHasRetry)
			{
				pBlockingAlarm->addRecovery(new Recovery(m_strRetry,  Recovery::RETRY));
			}
			if(m_bHasContinue)
			{
				pBlockingAlarm->addRecovery(new Recovery(m_strContinue,  Recovery::CONTINUE));
			}
			
			pResult=pBlockingAlarm;
		}
		else
		{
			throw ConfigException(m_strName+" alarm resource build err:blocking alarm without recovery.");
		}
	}
	else if(m_strBlockingType==NONBLOCKING)
	{
		if(m_bHasAbort||m_bHasRetry||m_bHasContinue)
		{
			throw ConfigException(m_strName+" alarm resource build err:nonblocking alarm recovery bad parameter.");
		}
		else
		{
			NonBlockingAlarmEX *pNonBlockingAlarm=new NonBlockingAlarmEX(strPreName+"/"+m_strName,"","",(Alarm::Severity)m_nSeverity);
			pNonBlockingAlarm->setMessage(m_nMsgStringID);
			pNonBlockingAlarm->setDescription(m_nDesStringID);
			pNonBlockingAlarm->addRecovery(new Recovery("Clear",  Recovery::CLEAR));
			pResult=pNonBlockingAlarm;
		}
	}
	else
	{
		throw ConfigException(m_strName+" alarm resource build err:error blocking type.");
	}
	cout<<"alarm has maked:"<<m_strName<<endl;
	return pResult;
}

IMPLEMENT_DYNAMIC( AlarmResource, CmdTarget)

BEGIN_MSG_MAP( AlarmResource, CmdTarget)
	SET_S(setName, AlarmResource)
	SET_S(setBlockingType, AlarmResource)
	SET_I(setMessage, AlarmResource)
	SET_I(setDescription, AlarmResource)
	SET_I(setSeverity, AlarmResource)
	SET_S(addRecovery, AlarmResource)
	SET_SS(addRecoveryWithName, AlarmResource)
END_MSG_MAP
