/********************************************************************
** Copyright (c) 2019 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: RecipeControlInfo.h
** Description:  
** Release: 1.0
** Modification history:           
** 					2019-04-24   Duq create
** 
*********************************************************************/

#ifndef RECIPECONTROLINFO_H_
#define RECIPECONTROLINFO_H_

#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class RecipeControlInfo : public IntValueInfo
{
	public:
		//None:0,Run:1,Hold:2,Resume:3,EndCurrentStep:4,RestartCurrentStep:5,EndRecipe:6,Abort:7
		static const int None = 0;
		static const int Run = 1;
		static const int Hold = 2;
		static const int Resume = 3;
		static const int EndCurrentStep = 4;
		static const int RestartCurrentStep = 5;
		static const int EndRecipe = 6;
		static const int Abort = 7;
		
		static const IntTypeInfo typeInfo;
		
		RecipeControlInfo():IntValueInfo(0, typeInfo)
	    {
	    }
	
	    RecipeControlInfo(int i):IntValueInfo(i, typeInfo)
	    {
	    }
	
	    RecipeControlInfo(std::string s):IntValueInfo(s, typeInfo)
	    {
	    }
};

#endif  /*RECIPECONTROLINFO_H_*/
