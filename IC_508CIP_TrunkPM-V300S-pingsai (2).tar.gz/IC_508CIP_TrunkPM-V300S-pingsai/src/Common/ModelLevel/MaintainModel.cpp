#include "MaintainModel.h"
#include "ModuleStatusEnum.h"
#include "AlarmReNameManager.h"

#include <string.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <sstream>

#ifdef IAP4_0
#include "ITime.h"
#else
#include "Time.h"
#endif

#ifdef IAP4_0
using namespace IAP;
using namespace IAP::CORE;
#endif

MaintainModel::MaintainModel()
{
	m_sSynchronizeClocks = new SynchronizeClocks();		//add by ps 1.10.0
	m_sSynchronizeClocks->setOwner(this);

	m_pServiceFailedAlarm = NULL;
	m_pErrorDescription = NULL;
	m_pServiceName = NULL;

	m_Init=new Init();
	m_Init->setOwner(this);
		
	m_SetOpMode=new SetOpMode();
	m_SetOpMode->setOwner(this);
	
	m_Shutdown=new Shutdown();
	m_Shutdown->setOwner(this);
	m_bOverrideActionRecovery = false;

	m_pFuncModelBusyAlarm = NULL;
	m_pCurrentEpochTime = NULL;  	//add by ps 1.10.0

}

MaintainModel::~MaintainModel()
{
}


//add by ps 1.10.0
void MaintainModel::setCurrentEpochTime()
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + " about to do setCurrentEpochTime .");

#ifdef IAP4_0
	long lTime = ITime::getCurrentTimeAsSeconds();
#else
	long lTime = Time::getCurrentTimeAsSeconds();
#endif

	if (m_pCurrentEpochTime != NULL)
	{
		m_pCurrentEpochTime->setValue(lTime);
	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + " m_pCurrentEpochTime is NULL .");
	}

	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + " done setCurrentEpochTime.  m_pCurrentEpochTime:  " + Converter::convertToString(lTime));

}

bool MaintainModel::OverrideAction::execute(const Alarm *pAlarm, Recovery *pRecovery)
{
	if(NULL != m_pOwner)
	{
		m_pOwner->m_bOverrideActionRecovery = true;
	}
   	return true;
}

void MaintainModel::OverrideAction::setOwner(MaintainModel *pModel)
{
	m_pOwner = pModel;
}

void MaintainModel::initialize()
{
	ControlObjectEX::initialize();	
	string strPreName = AlarmReNameManager::getInstance()->GetShowName(getName());
	m_pNotInMaintModeAlarm = new BlockingAlarm(strPreName + "_NotInMaintMode",
												strPreName + " is not in maintenance mode for this operation.",
												"A client has attempted to run a service when it's status is not in the maintenance state.",
												Alarm::EVENT);

	OverrideAction *pAction = new OverrideAction();
	pAction->setOwner(this);
	m_pNotInMaintModeAlarm->addRecovery(new Recovery("Cancel request",Recovery::CONTINUE));
	m_pNotInMaintModeAlarm->addRecovery(new Recovery("Override mode to MaintMode and Continue",Recovery::CONTINUE,pAction));

	m_pErrorDescription = new ReadWriteString(getName() + "/ErrorMsg");
	m_pServiceName = new ReadWriteString(getName() + "/ServiceName");

	m_pServiceFailedAlarm = new NonBlockingAlarm(strPreName + "_RunServiceFailed", "Run service [ <"+ m_pServiceName->getName() +"> ] failed.", "Run service failed: <" + m_pErrorDescription->getName() + ">", Alarm::ERROR);
	m_pServiceFailedAlarm->addRecovery(new Recovery("Clear", Recovery::CLEAR));

	m_pFuncModelBusyAlarm = new NonBlockingAlarm(strPreName + "_ChamberBusy", "Cannot do maintain service.", "Chamber is busy, please check whether the chamber is performing service at Chamber page UI.", Alarm::ERROR);
	m_pFuncModelBusyAlarm->addRecovery(new Recovery("Clear", Recovery::CLEAR));
}

bool MaintainModel::checkModeAndPostAlarm()
{
	if(m_pFunctionalModel->getState() == 1/*ControlState::RUNNING*/ || m_pFunctionalModel->getState() == 2/*ControlState::ALMPAUSE*/ || m_pFunctionalModel->getState() == 4/*ControlState::ABORTING*/)
	{
		Log_Error("checkModeAndPostAlarm functional model control state is " + m_pFunctionalModel->getStateAsString());
		m_pFuncModelBusyAlarm->post(this);
		return false;
	}
	int nMode=m_pFunctionalModel->getStatusValue();
	if(MODULE_STATUS::MaintMode == nMode)
	{
		return true;
	}
	else
	{
		m_pNotInMaintModeAlarm->post(this);
		if(m_bOverrideActionRecovery)
		{
			m_bOverrideActionRecovery = false;
			m_pFunctionalModel->setStatusValue(MODULE_STATUS::MaintMode);
			return true;
		}
		return false;
	}
}

bool MaintainModel::checkModeByBlackListAndPostAlm(std::list<int> blackList)
{
	if(m_pFunctionalModel->getState() == 1/*ControlState::RUNNING*/ || m_pFunctionalModel->getState() == 2/*ControlState::ALMPAUSE*/ || m_pFunctionalModel->getState() == 4/*ControlState::ABORTING*/)
	{
		Log_Error("checkModeByBlackListAndPostAlm() functional model control state is " + m_pFunctionalModel->getStateAsString());
		m_pFuncModelBusyAlarm->post(this);
		return false;
	}
	int nMode=m_pFunctionalModel->getStatusValue();
	std::list<int>::iterator it;
	for(it=blackList.begin();it!=blackList.end();++it)
	{
		if(nMode==(*it))
		{
			Log_Error("checkModeByBlackListAndPostAlm---invalid Mode");
			m_pNotInMaintModeAlarm->post(this);
			if(m_bOverrideActionRecovery)
			{
				m_bOverrideActionRecovery = false;
				m_pFunctionalModel->setStatusValue(MODULE_STATUS::MaintMode);
				return false;
			}
			return true;
		}
	}
	return false;
}

void MaintainModel::call_Init()
{
	call(m_Init);
}

void MaintainModel::call_SetOpMode(int nMode, bool override)
{
	m_SetOpMode->setParamValue("mode",nMode);
	m_SetOpMode->setParamValue("override",override);
	call(m_SetOpMode);
}

void MaintainModel::call_Shutdown()
{
	call(m_Shutdown);
}

//add by ps 1.10.0
void MaintainModel::call_SynchronizeClocks()
{
	call(m_sSynchronizeClocks);
}

void MaintainModel::Init::execute()
{
	MaintainModel *pOwner = dynamic_cast<MaintainModel*>(getOwner());
	if(pOwner != NULL)
	{
		Log_Info(pOwner->getName()+": do_Init start");
	
		pOwner->do_Init();
		
		Log_Info(pOwner->getName()+": do_Init end");
	}
}

void MaintainModel::SetOpMode::execute()
{
	MaintainModel *pOwner = dynamic_cast<MaintainModel*>(getOwner());
	if(pOwner != NULL)
	{
		int nMode = Params["mode"].Int;
		bool override = Params["override"].Bool;
		
		Log_Info(pOwner->getName()+": do_SetOpMode start - nMode = "+Converter::convertToString(nMode));
		
		pOwner->do_SetOpMode(nMode, override);
		
		Log_Info(pOwner->getName()+": do_SetOpMode end");
	}
}

void MaintainModel::Shutdown::execute()
{
	MaintainModel *pOwner = dynamic_cast<MaintainModel*>(getOwner());
	if(pOwner != NULL)
	{
		Log_Info(pOwner->getName()+": do_Shutdown start");
	
		pOwner->do_Shutdown();
		
		Log_Info(pOwner->getName()+": do_Shutdown end");
	}
}

//add by ps 1.10.0
void MaintainModel::SynchronizeClocks::execute()
{
	MaintainModel* owner = dynamic_cast<MaintainModel*>(getOwner());
	if (owner != NULL)
	{
		try
		{
			owner->do_SynchronizeClocks(Params["strIP"].Str);
		}
		catch (const AbortException& ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": SynchronizeClocks service was aborted for:" + string(ex.what()));
			throw;
		}
		catch (const exception& ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": SynchronizeClocks service has error for:" + string(ex.what()));
			throw;
		}
	}
}

void MaintainModel::do_Init()
{
	std::list<int> blackList;
	blackList.push_back(MODULE_STATUS::CTCInUse);
	if(!checkModeByBlackListAndPostAlm(blackList))
	{
		try
		{
			m_pFunctionalModel->call_Init();
		}
		catch(const RetryException &retryException)
		{
			throw;
		}
		catch(const InterruptException &interruptException)
		{
			Log_Error(getName()+" do init catch InterruptException - "+string(interruptException.what()));
			m_pServiceName->setValue("Initialize");
			m_pErrorDescription->setValue("Manual Abort");
			m_pServiceFailedAlarm->post(this);
			throw;
		}
		catch(const exception &ex)
		{
			Log_Error(getName() + " do init caught exception - " + string(ex.what()));
			m_pServiceName->setValue("Initialize");
			m_pErrorDescription->setValue(ex.what());
			if(!m_pServiceFailedAlarm->isPosted() && string(ex.what()).find("executed recovery 'ABORT'") == string::npos)
			{
				m_pServiceFailedAlarm->post(this);
			}
			throw;
		}
	}
}

void MaintainModel::do_SetOpMode(int nMode, bool override)
{
	if(MODULE_STATUS::MaintMode == nMode && MODULE_STATUS::CTCInUse == m_pFunctionalModel->getStatusValue())
	{
		Log_Error(getName()+" Set OpMode to MaintMode when Mode is CTCInUse");
		m_pNotInMaintModeAlarm->post(this);
		if(m_bOverrideActionRecovery)
		{
			m_bOverrideActionRecovery = false;
			m_pFunctionalModel->setStatusValue(MODULE_STATUS::MaintMode);
		}
	}
	else
	{
		m_pFunctionalModel->setStatusValue( nMode);
	}

}

void MaintainModel::do_Shutdown()
{
	std::list<int> blackList;
	blackList.push_back(MODULE_STATUS::CTCInUse);
	if(!checkModeByBlackListAndPostAlm(blackList))
	{
		try
		{
			m_pFunctionalModel->setStatusValue(MODULE_STATUS::NotReady);
			m_pFunctionalModel->call_Shutdown();
		}
		catch(const RetryException &retryException)
		{
			throw;
		}
		catch(const InterruptException &interruptException)
		{
			Log_Error(getName()+" do Shutdown catch InterruptException - "+string(interruptException.what()));
			m_pServiceName->setValue("Shutdown");
			m_pErrorDescription->setValue("Manual Abort");
			m_pServiceFailedAlarm->post(this);
			throw;
		}
		catch(const exception &ex)
		{
			Log_Error(getName() + " do Shutdown caught exception - " + string(ex.what()));
			m_pServiceName->setValue("Shutdown");
			m_pErrorDescription->setValue(ex.what());
			if(!m_pServiceFailedAlarm->isPosted() && string(ex.what()).find("executed recovery 'ABORT'") == string::npos)
			{
				m_pServiceFailedAlarm->post(this);
			}
			throw;
		}
	}
}

// CTC IP 192.168.14.200
void MaintainModel::do_SynchronizeClocks(const string& strIP) 	//changed by mujy [v1.0.6]
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": do_SynchronizeClocks start.  CTC IPAddr is " + strIP);

	if (checkModeAndPostAlarm())
	{
		// //add by pingsai 1.10.0
		#ifdef SUSE
				string cmd2 = "echo '888888' | sudo -S sh -c 'net time set -S " + strIP + "'";
		#else
				string cmd2 = "echo '888888' | sudo -S sh -c 'net time set -I " + strIP + "'";
		#endif

		char t_ch[cmd2.length() + 1];
		strcpy(t_ch, cmd2.c_str());

		cout << "Start to SynchronizeClocks with server " << strIP << endl;
		try
		{
			int nResult = system(t_ch);
			if (nResult != 0)
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": do_SynchronizeClocks error is " + Converter::convertToString(nResult));
				m_pServiceName->setValue("SynchronizeClocks");
				m_pErrorDescription->setValue("some reason,such as 1:Can't contact server;2.user is not in the sudoers file;3.Session request failed");
				m_pServiceFailedAlarm->post(this);
			}
			else
			{
				cout << endl;
				cout << "SynchronizeClocks with server " << strIP << " successfully! Please check!" << endl;
			}

			setCurrentEpochTime(); //add by ps 1.10.0
		}
		catch (...)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": do_SynchronizeClocks catch exception.");
			m_pServiceName->setValue("SynchronizeClocks");
			m_pErrorDescription->setValue("exception.");
			m_pServiceFailedAlarm->post(this);
			throw;
		}
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": do_SynchronizeClocks end.");
}

void MaintainModel::setFunctionalModel(std::string &strPath)
{
	ManagedObject *p = NULL;

	try
	{
		p = ObjectManager::getInstance()->getObject(strPath);
	}
	catch (const InvalidNameException &e)
	{
		p = ObjectManager::getInstance()->getObject(this, strPath);
	}
	m_pFunctionalModel = dynamic_cast<FunctionalModel*>(p);
	if (m_pFunctionalModel == NULL)
	{
		throw ConfigException("The object under path " + strPath + " is not the class expected.");
	}
}

//add by ps 1.10.0
void MaintainModel::make()
{
	m_pCurrentEpochTime = new ReadWriteDouble(getName() + "/CurrentEpochTime");
	setCurrentEpochTime();
	CTCExport::exportAsOthers(m_pCurrentEpochTime);
}

IMPLEMENT_DYNAMIC_SERVICE(Init, MaintainModel)
IMPLEMENT_DYNAMIC_SERVICE(SetOpMode, MaintainModel)
IMPLEMENT_DYNAMIC_SERVICE(Shutdown, MaintainModel)
IMPLEMENT_DYNAMIC_SERVICE(SynchronizeClocks, MaintainModel)			//add by ps 1.10.0


BEGIN_SERVICEINFO_LIST(MaintainModel)
	ADD_SERVICE_INFO(MaintainModel, Init, The Init service )	
	
	ADD_SERVICE_INFO(MaintainModel, SetOpMode, The SetOpMode service )
		ADD_PARAM_INFO(MaintainModel, SetOpMode, mode, int, InfoIsNew:-1 Offline UnInit NotReady Standby CTCInUse MaintPend MaintMode)	
		ADD_PARAM_INFO(MaintainModel, SetOpMode, override, bool, If override the mode of MaintainModel)
	ADD_SERVICE_INFO(MaintainModel, Shutdown, The Shutdown service )
	ADD_SERVICE_INFO(MaintainModel, SynchronizeClocks, SynchronizeClocks With CTC)		//add by ps 1.10.0
		ADD_PARAM_INFO(MaintainModel, SynchronizeClocks, strIP, string, time of CTC)
		
END_SERVICEINFO_LIST(MaintainModel)

IMPLEMENT_DYNAMIC(MaintainModel, ControlObjectEX)

BEGIN_MSG_MAP( MaintainModel, ControlObjectEX )
	SET_S( setFunctionalModel, MaintainModel )
END_MSG_MAP
