/********************************************************************
** Copyright (c) 2010, Beijing NMC Co.,Ltd. product division.
** All rights reserved.
**
** File name: AlarmResource.h
**
** Description:
**
** Modification history:
* 							2016.10.31		lvjw	created.
*********************************************************************/

#ifndef ALARMRESOURCE_H_
#define ALARMRESOURCE_H_

#include "CmdTarget.h"
#include "CBase.h"
#include "AlarmPoster.h"
#include "Alarm.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::ALARM;
#endif

//blocking type
#define BLOCKING "blocking"
#define NONBLOCKING "nonblocking"
//recovery type
#define RECOVERY_TYPE_ABORT "abort"
#define RECOVERY_TYPE_RETRY "retry"
#define RECOVERY_TYPE_CONTINUE "continue"

class AlarmResource : public CmdTarget,virtual public CBase
{
	DECLARE_DYNAMIC( AlarmResource ) 
	DECLARE_MSG_MAP
	
public:
	AlarmResource();
	virtual ~AlarmResource();
	
public:
	virtual void make();
	void setName(const std::string &strName);
	void setBlockingType(const std::string &strBlockingType);
	void setMessage(int nStringID);
	void setDescription(int nStringID);
	void setSeverity(int nSeverity);
	void addRecovery(const std::string &strRecovery);
	void addRecoveryWithName(const std::string &strName,const std::string &strType);
	
public:
	Alarm* buildAlarm(AlarmPoster* pPoster);
	
public:
	std::string m_strName;
	std::string m_strBlockingType;
	int m_nMsgStringID;
	int m_nDesStringID;
	int m_nSeverity;
	bool m_bHasAbort;
	bool m_bHasRetry;
	bool m_bHasContinue;
	std::string m_strAbort;//recovery show string
	std::string m_strRetry;//recovery show string
	std::string m_strContinue;//recovery show string
};

#endif /*ALARMRESOURCE_H_*/
