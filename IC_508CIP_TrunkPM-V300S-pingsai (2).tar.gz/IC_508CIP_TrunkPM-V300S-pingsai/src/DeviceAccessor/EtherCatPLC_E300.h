#ifndef ETHERCATPLC_E300_H_
#define ETHERCATPLC_E300_H_

#include "EtherCatBaseDevice.h"



class EtherCatPLC_E300 :public EtherCatBaseDevice{

	DECLARE_DYNAMIC(EtherCatPLC_E300)
	DECLARE_MSG_MAP

public:
	EtherCatPLC_E300();//
	virtual ~EtherCatPLC_E300();

	virtual bool readAnalog(int channelNum, double *value, const DoubleTypeInfo &typeInfo);
	virtual bool writeAnalog(int channelNum, double value, const DoubleTypeInfo &typeInfo);
	//virtual bool readBit(int channelNum, int *bit, const IntTypeInfo &typeInfo);
	virtual bool writeBit(int channelNum, int bit, const IntTypeInfo &typeInfo);
};

#endif /* ETHERCATPLC_E300_H_ */
