/********************************************************************
** Copyright (c) 2019 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: EnIPBase.cpp
** Description:  
** Release: 1.0
** Modification history:           
** 					2019-05-30   Duq create
**                                                 2019-08-30   Duq update
**                                                 2020-06-04   Duq update
*********************************************************************/

#include "EnIPBase.h"
#include <string.h>

#include <iostream>

using namespace std;

//EnIPPath class
//path:2bytes or 4bytes
void EnIPPath::Fit(char* path, int &offset, uint16_t value, char code)
{
	if (value > 255)
    {
        path[offset] = (char)(code|0x1);
		path[offset + 1] = 0x00;//pad
        path[offset + 2] = (char)(value & 0xFF);//lower
        path[offset + 3] = (char)((value & 0xFF00) >> 8);//high
        offset += 4;
    }
    else//2bytes:value,code
    {
        path[offset] = (char)code;
        path[offset + 1] = (char)(value & 0xFF);
        offset += 2;
    }
}

//classid(2bytes or 4bytes)--instanceid(2bytes or 4bytes)--attributid(2bytes or 4bytes)
string EnIPPath::GetPath(uint16_t* Class, uint16_t Instance, uint16_t* Attribut, bool IsConnectionPoint)
{
	char path[12] = {0};
	int size=0;
	if (Class != NULL)
        Fit(path, size, *Class, 0x20);
	
	if (IsConnectionPoint)
        Fit(path, size, Instance, 0x2C); // connection point
    else
        Fit(path, size, Instance, 0x24); // instance id

	if (Attribut != NULL)
        Fit(path, size, *Attribut, 0x30);
	string result = "";
	result.assign(path, size);
	return result;
}
//EnIPPath class

//Encapsulation_Packet class
Encapsulation_Packet::Encapsulation_Packet(EncapsulationCommands Command, unsigned int Sessionhandle, string &Encapsulateddata) 
{ 
	m_Command = Command;
	m_Sessionhandle = Sessionhandle;
	m_Encapsulateddata = Encapsulateddata;
    m_Length = Encapsulateddata.length();
	m_Status = EncapsulationStatus_Success; 
	m_Options = 0;
	memset(m_SenderContext,0,sizeof(m_SenderContext));
}

//get CIP packet: CIP Head(24bytes) + CIP Data
string Encapsulation_Packet::toByteArray()
{
	char head[24] = {0};
	memcpy(head, &m_Command, 2);
	//head[0] = (unsigned char)(m_Command & 0xFF);
	//head[1] = (unsigned char)((m_Command>>8) & 0xFF);
	memcpy(head+2, &m_Length, 2);
	//head[2] = (unsigned char)(m_Length & 0xFF);
	//head[3] = (unsigned char)((m_Length>>8) & 0xFF);
	memcpy(head+4, &m_Sessionhandle, 4);
	//head[4] = (unsigned char)(m_Sessionhandle & 0xFF);
	//head[5] = (unsigned char)((m_Sessionhandle>>8) & 0xFF);
	//head[6] = (unsigned char)((m_Sessionhandle>>16) & 0xFF);
	//head[7] = (unsigned char)((m_Sessionhandle>>24) & 0xFF);
	memcpy(head+8, &m_Status, 4);
	//head[8] = (unsigned char)(m_Status & 0xFF);
	//head[9] = (unsigned char)((m_Status>>8) & 0xFF);
	//head[10] = (unsigned char)((m_Status>>16) & 0xFF);
	//head[11] = (unsigned char)((m_Status>>24) & 0xFF);
	memcpy(head+12, m_SenderContext, 8);
	//for(int i = 0; i < 8; i++)
	//	head[12 + i] = m_SenderContext[i];
	memcpy(head+20, &m_Options, 4);
	//head[20] = (unsigned char)(m_Options & 0xFF);
	//head[21] = (unsigned char)((m_Options>>8) & 0xFF);
	//head[22] = (unsigned char)((m_Options>>16) & 0xFF);
	//head[23] = (unsigned char)((m_Options>>24) & 0xFF);
	string cipHead = "";
	cipHead.assign(head, 24);
	string fullPacket = cipHead + m_Encapsulateddata;
	return fullPacket;
}

//get CIP head; 
bool Encapsulation_Packet::analysisEncapsulationPacket(string &Packet, int &Offset, int Length)
{
	if(Length < 24)
	{
		m_Status = Invalid_Length;
		//cout<<"Encapsulation_Packet::analysisEncapsulationPacket Length: "<<Length<<endl;
		return false;
	}
	const char* temp = Packet.data();
	uint16_t cmd;
	memcpy(&cmd, temp, 2);
	//cmd = temp[Offset] + (temp[Offset + 1]<<8);
	//judge cmd
	if(m_Command != (EncapsulationCommands)cmd)
	{
		//cout<<"Encapsulation_Packet::analysisEncapsulationPacket m_Command: "<<m_Command<<endl;
		//cout<<"Encapsulation_Packet::analysisEncapsulationPacket cmd: "<<cmd<<endl;
		return false;
	}
    Offset += 2;
	memcpy(&m_Length, temp + Offset, 2);
	//m_Length = temp[Offset] + (temp[Offset + 1]<<8);
	if (Length < 24 + m_Length)//Length is the Length of packet
    {
        m_Status = Invalid_Length;
		//cout<<"Encapsulation_Packet::analysisEncapsulationPacket m_Length: "<<m_Length<<endl;
        return false;
    }
	Offset += 2;
	memcpy(&m_Sessionhandle, temp + Offset, 4);
    //m_Sessionhandle = (unsigned char)(temp[Offset]) + (unsigned int)(temp[Offset + 1]<<8) + (unsigned int)(temp[Offset + 2]<<16) + (unsigned int)(temp[Offset + 3]<<24);
	//cout<<"m_Sessionhandle: "<<m_Sessionhandle<<endl;
    Offset += 4;
	memcpy(&m_Status, temp + Offset, 4);
    //m_Status = (EncapsulationStatus)((unsigned int)temp[Offset] + (unsigned int)(temp[Offset + 1]<<8) + (unsigned int)(temp[Offset + 2]<<16) + (unsigned int)(temp[Offset + 3]<<24));//32bits
	if(m_Status != EncapsulationStatus_Success)
	{
		//cout<<"Encapsulation_Packet::analysisEncapsulationPacket m_Status: "<<m_Status<<endl;
		return false;
	}
    Offset += 4;
	memcpy(m_SenderContext, temp + Offset, 8);
	//for(int i = 0; i < 8; i++)
	//	m_SenderContext[i] = temp[Offset + i];
	Offset += 8;
	memcpy(&m_Options, temp + Offset, 4);
    //m_Options = (unsigned int)temp[Offset] + (unsigned int)(temp[Offset + 1]<<8) + (unsigned int)(temp[Offset + 2]<<16) + (unsigned int)(temp[Offset + 3]<<24);
    Offset += 4;  // Offset = 24
	return true;
}
//Encapsulation_Packet class

//UCMM_RR_Packet class
UCMM_RR_Packet::UCMM_RR_Packet(CIPServiceCodes Service, bool IsRequest, string &Path, string &Data)
{
	m_Service = (uint8_t)Service;
	if (!IsRequest)
        m_Service = (uint8_t)(m_Service | 0x80);
	m_Path = Path;
	m_Data = Data;
	m_IdemId = UnConnectedDataItem;//0x00B2
	m_ItemCount = 2;
	m_AdditionalStatus = NULL;
}

string UCMM_RR_Packet::toByteArray()
{
	if ((m_Path == "") || ((m_Path.length() % 2) != 0))
    {
        return "";
    }
	//  Table 3-2.1 UCMM Request
    m_DataLength = (uint16_t)(2 + m_Path.length() + (m_Data == "" ? 0 : m_Data.length()));
	char retVal[18] = {0};//time out = 0x00
	memcpy(retVal+6, &m_ItemCount, 2);
	//retVal[6] = m_ItemCount&0xFF;
	//retVal[7] = (m_ItemCount>>8)&0xFF;
	memcpy(retVal+12, &m_IdemId, 2);
	//retVal[12] = m_IdemId&0xFF;
	//retVal[13] = (m_IdemId>>8)&0xFF;
	memcpy(retVal+14, &m_DataLength, 2);
	//retVal[14] = m_DataLength&0xFF;
	//retVal[15] = (m_DataLength>>8)&0xFF;
	retVal[16] = m_Service;
	retVal[17] = (uint8_t)(m_Path.length() >> 1);//16bits word num of m_Path 
	string head = "";
	head.assign(retVal, 18);
	string fullPacket = head + m_Path;
	if(m_Data != "")
	{
		fullPacket = fullPacket + m_Data;
	}
    return fullPacket;
}

//get UCMM response
bool UCMM_RR_Packet::analysisUCMMRRPacket(string &DataArray, int &Offset, int Lenght)
{
	if ((Offset + 20) > Lenght)//length is the length of packet
	{
		m_GeneralStatus = Not_enough_data;
		return false;
	}
	
	const char* packet = DataArray.data();
	// Skip 16 bytes of the Command specific data
    Offset += 16;

    m_Service = (uint8_t)packet[Offset];
    Offset += 1;

    //Skip reserved byte
    Offset += 1;

    m_GeneralStatus = (CIPGeneralSatusCode)packet[Offset]; // only 0 is OK
	if(m_GeneralStatus != CIPGeneralSatusCode_Success)
		return false;
    Offset += 1;

    m_AdditionalStatus_Size = (uint8_t)packet[Offset];//16bits word num of AdditionalStatus
    Offset += 1;

    if ((Offset + m_AdditionalStatus_Size *2) > Lenght)
	{
		m_GeneralStatus = Not_enough_data;
		return false;
	}

    if (m_AdditionalStatus_Size > 0)
    {
        m_AdditionalStatus = new uint16_t[m_AdditionalStatus_Size];
        for (int i = 0; i < m_AdditionalStatus_Size; i++)
        {
			memcpy(m_AdditionalStatus + i, packet + Offset, 2);
            //m_AdditionalStatus[i] = (uint16_t)(packet[Offset] + (packet[Offset + 1]<<8));
			//cout<<"m_AdditionalStatus i"<<(uint16_t)m_AdditionalStatus[i]<<endl;
			Offset += 2;
        }
    }
	return true;
}

UCMM_RR_Packet::~UCMM_RR_Packet()
{
	if(m_AdditionalStatus != NULL)
	{
		delete m_AdditionalStatus;
		m_AdditionalStatus = NULL;
	}
}

bool UCMM_RR_Packet::IsService(CIPServiceCodes Service)
{
	uint8_t s = (uint8_t)(m_Service & 0x7F);
	if (s == (uint8_t)Service) 
		return true;

    if ((m_Service > 0x80 )&& (s == (uint8_t)UnconnectedSend))
        return true;
            
    return false;
}
//UCMM_RR_Packet class

//ForwardOpen_Config class
ForwardOpen_Config::ForwardOpen_Config(uint16_t InputDataSize, uint16_t OutputDataSize, bool InputP2P, unsigned int cycleTime)
{
	//O --->  T : output
	IsO2T = false;
	O2T_Exculsive = false;
	O2T_P2P = true;
	O2T_Priority = 0;
	O2T_datasize = 0;
	O2T_RPI = 200*1000;
	
	//T --->  O : input
	IsT2O = false;
	T2O_Exculsive = false;
	T2O_P2P = true;
	T2O_Priority = 0; 
	T2O_datasize = 0;
	T2O_RPI = 200*1000;
	
	//O --->  T : output
//	if (Output != NULL)
    {
        IsO2T = true;
        O2T_datasize = OutputDataSize;
        O2T_RPI = cycleTime; // in microsecond,  here same for the two direction
        O2T_P2P = true; // by default in this direction
    }
	
	//T --->  O : input
//	if (Input != NULL)
    {
        IsT2O = true;
        T2O_datasize = InputDataSize;
        T2O_RPI = cycleTime; // in microsecond, here same for the two direction
        T2O_P2P = InputP2P;
    }
}
//ForwardOpen_Config class

//ForwardOpen_Packet class
unsigned int ForwardOpen_Packet::m_ConnectionId = 0;
uint16_t ForwardOpen_Packet::m_ConnectionSerialNumber = (uint16_t)random();
uint16_t ForwardOpen_Packet::m_OriginatorVendorId = 0xFADA;
unsigned int ForwardOpen_Packet::m_OriginatorSerialNumber = 0x8BADF00D;

/*
            // Volume 1:  chapter 3-5.5.1.1
            T->O Network Connection Parameters: 0x463b
            0... .... .... .... = Owner: Exclusive (0)
            .10. .... .... .... = Connection Type: Point to Point (2)
            .... 01.. .... .... = Priority: High Priority (1)
            .... ..1. .... .... = Connection Size Type: Variable (1)
            .... ...0 0011 1011 = Connection Size: 59
 */
 
ForwardOpen_Packet::ForwardOpen_Packet(string &Connection_Path, ForwardOpen_Config* conf, unsigned int* ConnectionId)
{
	m_IsLargeForwardOpen = false;
	m_Priority_TimeTick = 10;
	m_Timeout_Ticks = 10;
	m_O2T_RPI = 0;
	m_T2O_RPI = 0;
	m_TransportTrigger = 0x81;//Server, Cyclic, Class1
	m_Reserved[0] = m_Reserved[1] = m_Reserved[2] = 0;
	m_ConnectionTimeoutMultiplier = 4;//for revice time out
	
	//cout<<"conf->O2T_datasize"<<conf->O2T_datasize<<endl;
	//cout<<"conf->T2O_datasize"<<conf->T2O_datasize<<endl;
	if ((conf->O2T_datasize > (511-6)) || (conf->T2O_datasize > (511-2)))
	{
        m_IsLargeForwardOpen = true;
		//cout<<"IsLargeForwardOpen"<<endl;
	}
	
	m_Connection_Path = Connection_Path;
	
	if (ConnectionId == NULL)
    {
        // 3-3.7.1.3 Pseudo-Random Connection ID Per Connection
        m_ConnectionId += 2;
        m_ConnectionId = m_ConnectionId | (uint16_t)(random() << 16);
    }
    else
        m_ConnectionId = *ConnectionId;
	
	if (conf->IsO2T)
	{
		m_O2T_ConnectionId = m_ConnectionId;
        if (conf->O2T_P2P)
			m_O2T_ConnectionParameters = 0x4400;//0: exclusive-owner, input only or listen-only connection, 10 = P2P, 0 = fixed connection size, 01 = High Priority
		else 
			m_O2T_ConnectionParameters = 0x2400;//0: exclusive-owner, input only or listen-only connection, 01 = multicast, 0 = fixed connection size, 01 = High Priority

        if (true == m_IsLargeForwardOpen)
        {
            if (conf->O2T_datasize > 0)
                m_O2T_ConnectionParameters = (m_O2T_ConnectionParameters << 16) + conf->O2T_datasize + 2 + 4;
            else
                m_O2T_ConnectionParameters = (m_O2T_ConnectionParameters << 16) + 2;
        }
        else
        {
            if (conf->O2T_datasize > 0)
                m_O2T_ConnectionParameters += (uint16_t)(conf->O2T_datasize + 2 + 4);
            else
                m_O2T_ConnectionParameters += (uint16_t)(2);
        }

        m_O2T_RPI = conf->O2T_RPI;
	}
        
    if (conf->IsT2O)
	{
		m_T2O_ConnectionId = m_ConnectionId + 1;
		m_T2O_ConnectionParameters = 0x0000; // Fixed Datasize, Variable data size is 0x0200
        m_T2O_ConnectionParameters = (unsigned int)(m_T2O_ConnectionParameters + ((conf->T2O_Priority & 0x03)<<10));//bits: 10th ~ 11th 00 = Low Priority
        if (conf->T2O_P2P)//connect type: 13th ~ 14th 0x10 --- P2P    0x01 --- multicast
            m_T2O_ConnectionParameters = m_T2O_ConnectionParameters | 0x4000;//P2P
        else
            m_T2O_ConnectionParameters = m_T2O_ConnectionParameters | 0x2000;//multicast

        if (conf->O2T_Exculsive)//false
            m_T2O_ConnectionParameters = m_T2O_ConnectionParameters | 0x8000;//redundant owner :15th --- 1:simultaneously.  0: exclusive-owner, input only or listen-only connection.

        if (true == m_IsLargeForwardOpen)
        {
            m_T2O_ConnectionParameters = (m_T2O_ConnectionParameters << 16) + conf->T2O_datasize + 2;
        }
        else
            m_T2O_ConnectionParameters += (uint16_t)(conf->T2O_datasize + 2);//data size

        m_T2O_RPI = conf->T2O_RPI;
	}
}

//table 3-5.9 request  
string ForwardOpen_Packet::toByteArray()
{
	m_Connection_Path_Size = m_Connection_Path.length();
	if(1 == m_Connection_Path_Size % 2)
	{
		m_Connection_Path = m_Connection_Path + '\0';
	}
	int PathSize = m_Connection_Path.length() / 2 + (m_Connection_Path.length() % 2);
    m_Connection_Path_Size = (uint8_t)PathSize;
	int shift = 0; // ForwardOpen or LargeForwardOpen
	char fwopen[40] = {0};
	fwopen[0] = m_Priority_TimeTick;//10
    fwopen[1] = m_Timeout_Ticks;//10
	//originator's CIP Producted CID
	memcpy(fwopen + 2, &m_O2T_ConnectionId, 4);
	//fwopen[2] = m_O2T_ConnectionId&0xFF;
	//fwopen[3] = (m_O2T_ConnectionId>>8)&0xFF;
	//fwopen[4] = (m_O2T_ConnectionId>>16)&0xFF;
	//fwopen[5] = (m_O2T_ConnectionId>>24)&0xFF;
	//originator's CIP Consumed CID
	memcpy(fwopen + 6, &m_T2O_ConnectionId, 4);
	//fwopen[6] = m_T2O_ConnectionId&0xFF;
	//fwopen[7] = (m_T2O_ConnectionId>>8)&0xFF;
	//fwopen[8] = (m_T2O_ConnectionId>>16)&0xFF;
	//fwopen[9] = (m_T2O_ConnectionId>>24)&0xFF;
	//originator's ConnectionSerialNumber
	memcpy(fwopen + 10, &m_ConnectionSerialNumber, 2);
	//fwopen[10] = m_ConnectionSerialNumber&0xFF;
	//fwopen[11] = (m_ConnectionSerialNumber>>8)&0xFF;
	//originator's VendorId
	memcpy(fwopen + 12, &m_OriginatorVendorId, 2);
	//fwopen[12] = m_OriginatorVendorId&0xFF;
	//fwopen[13] = (m_OriginatorVendorId>>8)&0xFF;
	//originator's SerialNumber
	memcpy(fwopen + 14, &m_OriginatorSerialNumber, 4);
	//fwopen[14] = m_OriginatorSerialNumber&0xFF;
	//fwopen[15] = (m_OriginatorSerialNumber>>8)&0xFF;
	//fwopen[16] = (m_OriginatorSerialNumber>>16)&0xFF;
	//fwopen[17] = (m_OriginatorSerialNumber>>24)&0xFF;
	fwopen[18] = m_ConnectionTimeoutMultiplier;//originator's
	fwopen[19] = m_Reserved[0];
	fwopen[20] = m_Reserved[1];
	fwopen[21] = m_Reserved[2];
	//O2T requested packet rate, ms
	memcpy(fwopen + 22, &m_O2T_RPI, 4);
	//fwopen[22] = m_O2T_RPI&0xFF;
	//fwopen[23] = (m_O2T_RPI>>8)&0xFF;
	//fwopen[24] = (m_O2T_RPI>>16)&0xFF;
	//fwopen[25] = (m_O2T_RPI>>24)&0xFF;
	//O2T ConnectionParameters
	if (true == m_IsLargeForwardOpen)
    {
		memcpy(fwopen + 26, &m_O2T_ConnectionParameters, 4);
		//fwopen[26] = m_O2T_ConnectionParameters&0xFF;
		//fwopen[27] = (m_O2T_ConnectionParameters>>8)&0xFF;
		//fwopen[28] = (m_O2T_ConnectionParameters>>16)&0xFF;
		//fwopen[29] = (m_O2T_ConnectionParameters>>24)&0xFF;
		shift = 2;
	}
	else
	{
		memcpy(fwopen + 26, &m_O2T_ConnectionParameters, 2);
		//fwopen[26] = m_O2T_ConnectionParameters&0xFF;
		//fwopen[27] = (m_O2T_ConnectionParameters>>8)&0xFF;
	}
	//T2O requested packet rate, ms
	memcpy(fwopen + 28 + shift, &m_T2O_RPI, 4);
	//fwopen[28+shift] = m_T2O_RPI&0xFF;
	//fwopen[29+shift] = (m_T2O_RPI>>8)&0xFF;
	//fwopen[30+shift] = (m_T2O_RPI>>16)&0xFF;
	//fwopen[31+shift] = (m_T2O_RPI>>24)&0xFF;
	//T2O ConnectionParameters
	if (true == m_IsLargeForwardOpen)
    {
		memcpy(fwopen + 32 + shift, &m_T2O_ConnectionParameters, 4);
		//fwopen[32+shift] = m_T2O_ConnectionParameters&0xFF;
		//fwopen[33+shift] = (m_T2O_ConnectionParameters>>8)&0xFF;
		//fwopen[34+shift] = (m_T2O_ConnectionParameters>>16)&0xFF;
		//fwopen[35+shift] = (m_T2O_ConnectionParameters>>24)&0xFF;
		shift = 4;
	}
	else
	{
		memcpy(fwopen + 32 + shift, &m_T2O_ConnectionParameters, 2);
		//fwopen[32+shift] = m_T2O_ConnectionParameters&0xFF;
		//fwopen[33+shift] = (m_T2O_ConnectionParameters>>8)&0xFF;
	}
	fwopen[34 + shift] = m_TransportTrigger&0xFF;
    fwopen[35 + shift] = m_Connection_Path_Size;
	string head = "";
	head.assign(fwopen, 36 + shift);
	string fullPacket = head + m_Connection_Path;
	return fullPacket;
}
//ForwardOpen_Packet class

//ForwardClose_Packet class
string ForwardClose_Packet::toByteArray()
{
	char fwclose[12] = {0};
	fwclose[0] = m_OrignalPkt->m_Priority_TimeTick;
    fwclose[1] = m_OrignalPkt->m_Timeout_Ticks;
	memcpy(fwclose + 2, &(m_OrignalPkt->m_ConnectionSerialNumber), 2);
	//fwclose[2] = (m_OrignalPkt->m_ConnectionSerialNumber)&0xFF;
	//fwclose[3] = (m_OrignalPkt->m_ConnectionSerialNumber>>8)&0xFF;
	memcpy(fwclose + 4, &(m_OrignalPkt->m_OriginatorVendorId), 2);
	//fwclose[4] = (m_OrignalPkt->m_OriginatorVendorId)&0xFF;
	//fwclose[5] = (m_OrignalPkt->m_OriginatorVendorId>>8)&0xFF;
	memcpy(fwclose + 6, &(m_OrignalPkt->m_OriginatorSerialNumber), 4);
	//fwclose[6] = (m_OrignalPkt->m_OriginatorSerialNumber)&0xFF;
	//fwclose[7] = (m_OrignalPkt->m_OriginatorSerialNumber>>8)&0xFF;
	//fwclose[8] = (m_OrignalPkt->m_OriginatorSerialNumber>>16)&0xFF;
	//fwclose[9] = (m_OrignalPkt->m_OriginatorSerialNumber>>24)&0xFF;
	
	fwclose[10] = m_OrignalPkt->m_Connection_Path_Size;
    fwclose[11] = 0;
	string head = "";
	head.assign(fwclose, 12);
	string fullPacket = head + m_OrignalPkt->m_Connection_Path;
	return fullPacket;
}
//ForwardClose_Packet class

//SequencedAddressItem_Packet class
void SequencedAddressItem_Packet::updateSequenceNumber(char *data, unsigned int &sequenceNumber)
{
	memcpy(data + 10, &sequenceNumber, 4);
	memcpy(data + 18, &sequenceNumber, 2);
	sequenceNumber++;
}

//Table 3-5.1 UDP data format for class 0 and class 1
bool SequencedAddressItem_Packet::fillSendItemPacketHead(char *data, int datelen, unsigned int connectionId, unsigned int sequenceNumber)
{
	uint16_t m_Lenght = 8;
	uint16_t m_Lenght2 = 0;
	if (datelen > 0)
	{
		m_Lenght2 = (uint16_t)(datelen + 2 + 4); // +2 sequenceNumber bis (2 bytes !) +4 : 32 bits header
	}
	else
	{
		return false;
	}
	// Itemcount=2
    data[0] = 2;
	data[2] = (SequencedAddressItem)&0xFF;
	data[3] = (SequencedAddressItem>>8)&0xFF;//0x8002
	memcpy(data + 4, &m_Lenght, 2);
	memcpy(data + 6, &connectionId, 4);
	memcpy(data + 10, &sequenceNumber, 4);
	data[14] = (ConnectedDataItem)&0xFF;
	data[15] = (ConnectedDataItem>>8)&0xFF;//0x00B1
	memcpy(data + 16, &m_Lenght2, 2);
	memcpy(data + 18, &sequenceNumber, 2);
	data[20] = 0x01;
	data[21] = 0x00;
	data[22] = 0x00;
	data[23] = 0x00;
	return true;//24bytes
}

//get packet data: SequencedAddressItem + ConnectedDataItem
bool SequencedAddressItem_Packet::analysisGetItem(char *data, int packetlen, int &offset, unsigned int &connectionId)
{
	if(packetlen < 18)
		return false;
	
	uint16_t m_Lenght2 = 0;
	uint16_t m_TypeId = 0;
	uint16_t m_TypeId2 = 0;
	
	offset += 2;
	memcpy(&m_TypeId, data + offset, 2);
	if (m_TypeId != (uint16_t)SequencedAddressItem)//0x8002
		return false;
	offset += 4;
	memcpy(&connectionId, data + offset, 4);
	offset += 8;
	memcpy(&m_TypeId2, data + offset, 2);
	if (m_TypeId2 != (uint16_t)ConnectedDataItem) //0x00B1
		return false;	
	offset += 2;
	memcpy(&m_Lenght2, data + offset, 2);
    offset += 2;
	if ((m_Lenght2 + offset) != packetlen)
    {
        m_TypeId = 0; // invalidate the frame
        return false;
    }
    if (m_Lenght2 != 0)
    {
        offset += 2;
    }
	return true;
}
//SequencedAddressItem_Packet class
