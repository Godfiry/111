/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: DNetFFD1000II.h
** Description:  
** Release: 1.1
** Modification history: 
**                     2024-9-26   taohao create
**      
*********************************************************************/
#ifndef DNetFFD1000II_H_
#define DNetFFD1000II_H_

#include "IODevice.h"
#include "DoubleTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class DNetFFD1000II:public IODevice
{
    DECLARE_DYNAMIC(DNetFFD1000II)
    DECLARE_MSG_MAP
    private:
        double m_dTemp1;
        double m_dTemp2;
        double m_dTemp3;
        char m_cBuffer[6];
        int m_cTemp1;
        int m_cTemp2;
        int m_cTemp3;
        int m_nSum;

    public:
        DNetFFD1000II();
        virtual ~DNetFFD1000II();

        bool setGasRatio(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo);
        bool getGasRatio(int mChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);
        bool getGasFlow(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);
        bool setZeroAdjust(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
        bool getZeroStatus(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);

        virtual void init();
};

#endif /*DNetFFD1000II_H_*/
