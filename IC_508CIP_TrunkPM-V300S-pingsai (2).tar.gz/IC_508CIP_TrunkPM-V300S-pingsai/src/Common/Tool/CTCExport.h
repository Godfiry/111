/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: CTCExport.h
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-03-03   LiJuanjuan create
**      
*********************************************************************/
#ifndef CTCEXPORT_H_
#define CTCEXPORT_H_

#include "ControlObjectEX.h"
#include "UntypedData.h"
#include "Service.h"
#include <map>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CONTROL;
#endif

class CTCExport:public ControlObjectEX
{
	DECLARE_DYNAMIC( CTCExport )
	DECLARE_MSG_MAP
	DECLARE_SERVICEINFO_LIST

	public:
		class Print : public Service
		{
			DECLARE_DYNAMIC_SERVICE(Print)
			public:
				void execute();
		};

	public:
		CTCExport();
		virtual ~CTCExport();

	public:
		void call_Print();
		virtual void do_Print();

	public:
		virtual void initialize();

	public://xml
		void setExportToCTC(std::string strSourceDataPath,std::string strAliasName);

	public:
		static std::string getExportNode();
		void setExportNode(const std::string &name);
		static void exportToCTC(ManagedObject *obj);
		static void exportToCTC(ManagedObject *obj, const std::string &alias);
		static void exportToCTC(ManagedObject *obj, const std::string &modulename, const std::string &alias);
		static void exportToCTC(UntypedData *data);
		static void exportToCTC(UntypedData *data, const std::string &alias);
		static void exportToCTC(UntypedData *data, const std::string &modulename, const std::string &alias);

		static void exportAsOthers(UntypedData *data, const std::string &modulename, const std::string &alias);
		static void exportAsOthers(UntypedData *data, const std::string &alias);

		static void exportAsOthers(UntypedData *data);	
		static std::string getControlPath();
		static std::string getOthersPath();

	private:
		ServicePtr<Print> m_sPrint;
		static std::string m_exportNode;
		std::map<std::string,std::string> m_mapExportData;

		static std::string m_objectNode;
		static std::string m_dataNode;
		static std::string m_commonPath;
};


#endif /*CTCEXPORT_H_*/
