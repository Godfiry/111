/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: SMCChiller.cpp
** Description:  
** Release: 1.1
** Modification history: 
**                 2016-10-18   mujy modify [V1.5.16]
**
*********************************************************************/
#include "SMCChiller.h"
#include "ObjectManager.h"
#include "DeviceManager.h"

#include "StrTool.h"
#include "Hex.h"
#include "CheckCalculationTool.h"
#include <stdio.h>
#include <cctype>
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
using namespace IAP;
#endif
using namespace std;

SMCChiller::Cmd SMCChiller::m_cmd[]={{""},
                                     {":011700000000000C000102",0},//1 0000:stop/0001:start
                                     {":011700000000000B000102",0},//2 set temperature  
                                     {":011700000001000B000000",0},//3 read temprature
                                     {":011700020001000B000000",0},//4 read pump Pressure
                                     {":011700010001000B000000",0},//5 read water flow
                                     {":011700040001000B000000",0x0002},//6 read fault summary
                                     {":011700040001000B000000",0x0004},//7 read warn summary
                                     {":011700040001000B000000",0x0020},//8 read local remote
                                     {":011700050002000B000000",0x0FFFFFFF},//9 read alarm
                                     {":011700040001000B000000",0x0001},//10 read run flag //added by mujy [V1.5.16]
                                     {":021700000000000C000102",0},//11 0000:stop/0001:start
                                     {":021700000000000B000102",0},//12 set temprature
                                     {":021700000001000B000000",0},//13 read temprature
                                     {":021700020001000B000000",0},//14 read pump Pressure
                                     {":021700010001000B000000",0},//15 read water flow
                                     {":021700040001000B000000",0x0002},//16 read fault summary
                                     {":021700040001000B000000",0x0004},//17 read warn summary
                                     {":021700040001000B000000",0x0020},//18 read local remote
                                     {":021700050002000B000000",0x0FFFFFFF},//19 read alarm
                                     {":021700040001000B000000",0x0001}//20 read run flag
                                          };
SMCChiller::SMCChiller():SerialDevice(200, "\x0D\x0A")
{
    m_timeOut=50;//5s
    m_pollPeriod=1000;
}

SMCChiller::~SMCChiller()
{
}

bool SMCChiller::writeDouble(int nChannelNum, double dValue,const DoubleTypeInfo &typeInfo)
{
    string strCommand=m_cmd[nChannelNum].m_strAddress;
    //int t_temp=(int)value*10;
    double dTmp = (double)dValue*10;//modified by chenmz [V1.6.5]
    double dTmp1 = (int)dTmp;
    int nTemp = dTmp1;
    if(nTemp < 0)
    {
        nTemp += 65536;
    }
    std::string strTemp=Hex::hexToString(nTemp,4);//modified by mujy [V1.5.16]
    strCommand += strTemp;
    strCommand += CheckCalculationTool::GetLRCCode(strCommand);
    strCommand = StrTool::toUpper(strCommand);
    string strResponse = getCommandResult(strCommand, m_timeOut);
    size_t nPos = strResponse.find(":", 0);  //changed by wzd 1.1.39
    if(nPos == string::npos)
    {
        if(strCommand.find(":02") != string::npos)
        {
            throw IOException("Chiller channel2 write temperature ["+Converter::convertToString(dValue)+"] failed for unknown response [" + strResponse+"]");
        }
        else
        {
            throw IOException("Chiller write temperature ["+Converter::convertToString(dValue)+"] failed for unknown response [" + strResponse+"]");
        }
    }
    return true;
}
bool SMCChiller::readDouble(int nChannelNum, double *pValue,const DoubleTypeInfo &typeInfo)
{
    Cmd cmd=m_cmd[nChannelNum];
    string strCommand=cmd.m_strAddress+CheckCalculationTool::GetLRCCode(cmd.m_strAddress);
    strCommand=StrTool::toUpper(strCommand);
    //std::string strResponse = getCommandResult(t_command, m_timeOut);
    std::string strResponse = getFixCommandResult(strCommand, m_timeOut,13,4);
    size_t nPos=strResponse.find(":",0);  //changed by wzd 1.1.39
    if(nPos==string::npos)
    {
        if(strCommand.find(":02") != string::npos)
        {
            throw IOException("Chiller channel2 read temperature failed for unknown response [" + strResponse+"]");
        }
        else
        {
            throw IOException("Chiller read temperature failed for unknown response [" + strResponse+"]");
        }
    }
    else
    {
        string strSplitValue = strResponse.substr(nPos+7, 4);
        int nValue = 0;
        if(!Hex::stringToHex(&nValue, strSplitValue))
        {
            throw IOException("Chiller read temperature failed for can't convert response ["+strSplitValue+"] to double value.");
        }
        if(nValue & 0x8000)
        {
            nValue -= 65536;
        }
        switch(nChannelNum)
        {
            case 3:
            case 13:
                *pValue=(double)nValue/10;
                break;
            case 4:
            case 14:
                *pValue=(double)nValue/100;
                break;
            case 5:
            case 15:
                 *pValue=(double)nValue/10;
                 break;
            default:
                break;
        }
    }
    return true;
}

bool SMCChiller::writeInt(int nChannelNum, int nValue,const IntTypeInfo &typeInfo)
{
    string strCmd = m_cmd[nChannelNum].m_strAddress;
    string strAction;
    if(nValue == 1)
    {
        strCmd += "0001";
        strAction = "start";
    }
    else
    {
        strCmd += "0000";
        strAction = "stop";
    }
    strCmd += CheckCalculationTool::GetLRCCode(strCmd);
    strCmd = StrTool::toUpper(strCmd);//need test to decide if keep it
    string strResponse = getCommandResult(strCmd, m_timeOut);
    int nPos = strResponse.find(":", 0);
    if(nPos == string::npos)
    {
        if(strCmd.find(":02") != string::npos)
        {
            throw IOException("Chiller channel2 "+strAction+" failed for unknown response [" + strResponse+"]");
        }
        else
        {
            throw IOException("Chiller "+strAction+" failed for unknown response [" + strResponse+"]");
        }
    }
    return true;

}
bool SMCChiller::readInt(int nChannelNum, int *pValue,const IntTypeInfo &typeInfo)
{
       Cmd cmd = m_cmd[nChannelNum];
    string strCommand = cmd.m_strAddress + CheckCalculationTool::GetLRCCode(cmd.m_strAddress);
    strCommand = StrTool::toUpper(strCommand);
    //string strResponse = getCommandResult(t_command, m_timeOut);
    std::string strResponse = getFixCommandResult(strCommand, m_timeOut,13,4);
    size_t nPos = strResponse.find(":", 0);  //changed by wzd 1.1.39
    if(nPos == string::npos)
    {
        if(strCommand.find(":02") != string::npos)
        {
            throw IOException("Chiller channel2 read status failed for unknown response [" + strResponse+"]");
        }
        else
        {
            throw IOException("Chiller read status failed for unknown response [" + strResponse+"]");
        }
    }
    else
    {
        string strSplitValue = strResponse.substr(nPos+7, 4);
        int nValue = 0;
        if(!Hex::stringToHex(&nValue, strSplitValue))
        {
            throw IOException("Chiller read status failed for can't convert response ["+strSplitValue+"] to integer value.");
        }
        else
        {
            *pValue = (nValue & cmd.m_nDeal) != 0;
            switch(nChannelNum)
            {
                case 6:
                case 7:
                case 9:
                case 16:
                case 17:
                case 19:
                    if(*pValue == 1)
                    {
                        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "SMCChiller: channel ["+Converter::convertToString(nChannelNum)+"] read back = "+strResponse +" ;split value = "+strSplitValue);
                    }
                    break;
                case 8:
                case 10:
                case 18:
                case 20:
                    if(*pValue == 0)
                    {
                        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "SMCChiller: channel ["+Converter::convertToString(nChannelNum)+"] read back = "+strResponse+" ;split value = "+strSplitValue);
                    }
                    break;
                default:
                    break;
            }
            return true;
        }
    }
}

void SMCChiller::initDevice()
{
    cout<<"Start Scan Chiller...."<<endl;
    //say hello to chiller
    double dTemp;
    try
    {
        readDouble(3,&dTemp,DoubleTypeInfo());//3 read temprature
    }
    catch(exception &ex)
    {
        cout<<"Scan chiller failed. Communication abnormal!"<<endl;
        throw;
    }
    cout<<"Scan Chiller Successfully...."<<endl;
}
void SMCChiller::initChs(DeviceNode<SMCChiller>* pNode)
{
    pNode->registerWriteCh(1, &SMCChiller::writeInt);
    pNode->registerWriteCh(2, &SMCChiller::writeDouble);
    for(int i=3;i<=5;i++)
    {
        pNode->registerReadCh(i, &SMCChiller::readDouble);
    }
    for(int i=6;i<=10;i++)//modified by mujy [V1.5.16]
     {
        pNode->registerReadCh(i, &SMCChiller::readInt);
    }

    pNode->registerWriteCh(11, &SMCChiller::writeInt);
       pNode->registerWriteCh(12, &SMCChiller::writeDouble);
       for(int i=13;i<=15;i++)
       {
           pNode->registerReadCh(i, &SMCChiller::readDouble);
       }
    for(int i=16;i<=20;i++)
    {
        pNode->registerReadCh(i, &SMCChiller::readInt);
    }
    pNode->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &SMCChiller::getStatus);
}


void SMCChiller::init()
{
    DeviceNode<SMCChiller> *pNode = new DeviceNode<SMCChiller>(m_pollPeriod, this);
    DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
    if(!isSimulated())
    {
        initChs(pNode);
        initDevice();
    }
}
IMPLEMENT_DYNAMIC(SMCChiller, SerialDevice )

BEGIN_MSG_MAP(SMCChiller, SerialDevice )
    SET_V( init, SMCChiller )
END_MSG_MAP
