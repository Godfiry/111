/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					Jan 22, 2008  shenql  create 
**      
***************************************************************************/
#ifndef SERVICERESULTINFO_H_
#define SERVICERESULTINFO_H_
#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class ServiceResultInfo : public IntValueInfo
{
public:

		static const int UnInit = -1;
		static const int Success = 0;
		static const int Failure = 1;
		static const int BROKEN_SUBSTRATE = 2;
		static const IntTypeInfo typeInfo;

	   ServiceResultInfo():IntValueInfo(-1, typeInfo)
	   {
	   }
	
	   ServiceResultInfo(int i):IntValueInfo(i, typeInfo)
	    {
	    }
	
	   ServiceResultInfo(std::string s):IntValueInfo(s, typeInfo)
	    {
	    }
};


#endif /*SERVICERESULTINFO_H_*/
