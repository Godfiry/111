/********************************************************************
** Copyright (c) 2018, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: GeneratorHuttinger3000DNet.h
** Description:SuperNova Flexible DeviceNet Profile
*             Use Polled I/O
* 				Default instance is
** Release: 1.1
** Modification history:
** 					2023-5-19   wzd create
**
*********************************************************************/
#ifndef GENERATORHUTTINGER3000DNET_H_
#define GENERATORHUTTINGER3000DNET_H_

#include "IODevice.h"
#include "DeviceNode.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class GeneratorHuttinger3000DNet : public IODevice
{
    DECLARE_DYNAMIC(GeneratorHuttinger3000DNet)
    DECLARE_MSG_MAP

public:
	GeneratorHuttinger3000DNet();
    virtual ~GeneratorHuttinger3000DNet();

public://xml
	void init();

public://read and write function
	bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
	bool writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo);
	bool writeRawCommand(int nChannelNum, std::string strValue, const StringTypeInfo &typeInfo);
	bool readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);
	bool readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);

protected:
	bool sendCommand(std::string strCommand, int nTimeOut);
	std::string readCommand(std::string strCommand, int nTimeOut);
	void InitChannels(DeviceNode<GeneratorHuttinger3000DNet> *pNode);
	void initDevice();

private:
	typedef struct
	{
		int m_nByte;
		int m_nBit;
	}Com;
	int m_nLastLevelMode;//0:forward leveling;1:load leveling
	int m_nLastPulseMode;//0:CW Mode;1:Pulse Mode
	int m_nLastRFOnOffControl;//0:Off;1:On
	static Com m_Commands[];
	char *m_pWriteBuffer;
	char *m_pReadBuffer;
};
#endif /*GENERATORHUTTINGER3000DNET_H_*/
