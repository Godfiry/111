/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: FFMSDriver.h
** Description:  
** Release: 1.1
** Modification history: 
**                          2009-11-25   LiJuanjuan create
**      
*********************************************************************/
#ifndef FFMSDRIVER_H_
#define FFMSDRIVER_H_

#include "SerialDevice.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class FFMSDriver:public SerialDevice
{
     DECLARE_DYNAMIC(FFMSDriver)     
     DECLARE_MSG_MAP     
     
     private:
          typedef struct
          {
               std::string m_command;
               //std::string m_response;
               int type;
               std::string m_error;
          }Cmd;
          
          static Cmd m_cmd[];
     
     protected:
          void initDevice();
          void initChs(DeviceNode<FFMSDriver> *node);     
          //std::string calculateLRC(const std::string &buffer);
                    
     public:
          FFMSDriver();
          virtual ~FFMSDriver();
          
          bool writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo);
          bool readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo);
          bool readInt(int channelNum, int *value, const IntTypeInfo &typeInfo);
          bool writeInt(int channelNum, int value, const IntTypeInfo &typeInfo);
          void init();     
          
};

#endif /*FFMSDRIVER_H_*/
