#include "ControlObjectEX.h"
#include "AlarmGetter.h"
#include "XmlGetter.h"

#include "MapTool.h"

ControlObjectEX::ControlObjectEX()
{
	m_isStartuped = false;
}

ControlObjectEX::~ControlObjectEX()
{
}

bool ControlObjectEX::isStartuped() const
{
	return m_isStartuped;
}

void ControlObjectEX::startup()
{
	ControlObject::startup();
	m_isStartuped = true;
}

void ControlObjectEX::addAlarm(string strName)
{
	Alarm* pAlarm = AlarmGetter::getAlarm(strName, this);

	if (!MapTool::addToMap<string, Alarm*>(m_Alarms, strName, pAlarm))
	{
		throw "alarm repeat added";
	}
	//m_Alarms[strName]=pAlarm;
}

void ControlObjectEX::addRecovery(string strName, Recovery* pRecoveryAction)
{
	if (m_Alarms.count(strName) == 0)
	{
		throw strName + " alarm not exist";
	}
	else
	{
		m_Alarms[strName]->addRecovery(pRecoveryAction);
	}
}

void ControlObjectEX::postAlarm(Alarm* pAlarm)
{
	Log_Error(getName() + ": postAlarm()- Message:" + pAlarm->getMessage());
	Log_Error(getName() + ": postAlarm()- Description:" + pAlarm->getDescription());
	if (!pAlarm->isPosted())
	{
		pAlarm->post(this);
	}
}

void ControlObjectEX::postAlarm(const string& strName)
{
	if (m_Alarms.count(strName) == 0)
	{
		Log_Debug(getName() + ": postAlarm()- alarm not exist!");
		throw "alarm not exist";
	}
	Log_Error(getName() + ": postAlarm()- Message:" + m_Alarms[strName]->getMessage());
	Log_Error(getName() + ": postAlarm()- Description:" + m_Alarms[strName]->getDescription());
	if (!m_Alarms[strName]->isPosted())//add by mujy [v1.0.9]
	{
		m_Alarms[strName]->post(this);
	}
}

void ControlObjectEX::postAlarm(const string& strName, string strDescription)
{
	if (m_Alarms.count(strName) == 0)
	{
		Log_Debug(getName() + ": postAlarm()- alarm not exist!");
		throw "alarm not exist";
	}
	m_Alarms[strName]->setDescription(strDescription);

	Log_Error(getName() + ": postAlarm()- Message:" + m_Alarms[strName]->getMessage());
	Log_Error(getName() + ": postAlarm()- Description:" + m_Alarms[strName]->getDescription());
	if (!m_Alarms[strName]->isPosted())
	{
		m_Alarms[strName]->post(this);
	}
}

void ControlObjectEX::addIntSensors(const string& strChName, const string& strPath)
{
	ReadOnlyInt* pRInt = XmlGetter::getFromNamespace<ReadOnlyInt*>(strPath);
	if (!MapTool::addToMap<string, ReadOnlyInt*>(m_IntSensorChs, strChName, pRInt))
	{
		throw "Int Sensor repeat added:" + strChName;
	}
	//m_IntSensorChs.insert(pair<std::string,ReadOnlyInt*>(strChName, pRInt));
}

void ControlObjectEX::addDoubleSensors(const string& strChName, const string& strPath)
{
	ReadOnlyDouble* pRDouble = XmlGetter::getFromNamespace<ReadOnlyDouble*>(strPath);
	if (!MapTool::addToMap<string, ReadOnlyDouble*>(m_DoubleSensorChs, strChName, pRDouble))
	{
		throw "Double Sensor repeat added:" + strChName;
	}
	//m_DoubleSensorChs.insert(pair<std::string,ReadOnlyDouble*>(strChName, pRDouble));
}

void ControlObjectEX::addStringSensors(const string& strChName, const string& strPath)
{
	ReadOnlyString* pRString = XmlGetter::getFromNamespace<ReadOnlyString*>(strPath);
	if (!MapTool::addToMap<string, ReadOnlyString*>(m_StringSensorChs, strChName, pRString))
	{
		throw "string Sensor repeat added:" + strChName;
	}
	//m_StringSensorChs.insert(pair<std::string,ReadOnlyString*>(strChName, pRString));
}

void ControlObjectEX::addIntCfgParams(const string& strChName, const string& strPath)
{
	ReadWriteInt* pRWInt = XmlGetter::getFromNamespace<ReadWriteInt*>(strPath);
	if (!MapTool::addToMap<string, ReadWriteInt*>(m_IntCfgParams, strChName, pRWInt))
	{
		throw "IntCfgParams repeat added:" + strChName;
	}
	//m_IntCfgParams.insert(pair<std::string,ReadWriteInt*>(strChName, pRWInt));
}

void ControlObjectEX::addDoubleCfgParams(const string& strChName, const string& strPath)
{
	ReadWriteDouble* pRWDouble = XmlGetter::getFromNamespace<ReadWriteDouble*>(strPath);
	if (!MapTool::addToMap<string, ReadWriteDouble*>(m_DoubleCfgParams, strChName, pRWDouble))
	{
		throw "DoubleCfgParams repeat added:" + strChName;
	}
	//m_DoubleCfgParams.insert(pair<std::string,ReadWriteDouble*>(strChName, pRWDouble));
}

void ControlObjectEX::addStringCfgParams(const string& strChName, const string& strPath)
{
	ReadWriteString* pRWString = XmlGetter::getFromNamespace<ReadWriteString*>(strPath);
	if (!MapTool::addToMap<string, ReadWriteString*>(m_StringCfgParams, strChName, pRWString))
	{
		throw "StringCfgParams repeat added:" + strChName;
	}
	//m_StringCfgParams.insert(pair<std::string,ReadWriteString*>(strChName, pRWString));
}

//[chensc v1.1.19]
void ControlObjectEX::addIntActuators(const string& strChName, const string& strPath)
{
	ReadWriteInt* pRWInt = XmlGetter::getFromNamespace<ReadWriteInt*>(strPath);
	if (!MapTool::addToMap<string, ReadWriteInt*>(m_IntActuatorChs, strChName, pRWInt))
	{
		throw "Int Actuators repeat added:" + strChName;
	}
}
//[chensc v1.1.19]
void ControlObjectEX::addDoubleActuators(const string& strChName, const string& strPath)
{
	ReadWriteDouble* pRWDouble = XmlGetter::getFromNamespace<ReadWriteDouble*>(strPath);
	if (!MapTool::addToMap<string, ReadWriteDouble*>(m_DoubleActuatorChs, strChName, pRWDouble))
	{
		throw "Double Actuators repeat added:" + strChName;
	}
}
//[chensc v1.1.19]
void ControlObjectEX::addStringActuators(const string& strChName, const string& strPath)
{
	ReadWriteString* pRWString = XmlGetter::getFromNamespace<ReadWriteString*>(strPath);
	if (!MapTool::addToMap<string, ReadWriteString*>(m_StringActuatorChs, strChName, pRWString))
	{
		throw "String Actuators repeat added:" + strChName;
	}
}

bool ControlObjectEX::checkIntSensorList(string* pSensorNameList, int nLength)
{
	for (int i = 0; i < nLength; ++i)
	{
		if (m_IntSensorChs.find(pSensorNameList[i]) == m_IntSensorChs.end())
		{
			return false;
		}
	}
	return true;
}

bool ControlObjectEX::checkDoubleSensorList(string* pSensorNameList, int nLength)
{
	for (int i = 0; i < nLength; ++i)
	{
		if (m_DoubleSensorChs.find(pSensorNameList[i]) == m_DoubleSensorChs.end())
		{
			return false;
		}
	}
	return true;
}

bool ControlObjectEX::checkStringSensorList(string* pSensorNameList, int nLength)
{
	for (int i = 0; i < nLength; ++i)
	{
		if (m_StringSensorChs.find(pSensorNameList[i]) == m_StringSensorChs.end())
		{
			return false;
		}
	}
	return true;
}

bool ControlObjectEX::checkIntCfgParamList(string* pCfgParamList, int nLength)
{
	for (int i = 0; i < nLength; ++i)
	{
		if (m_IntCfgParams.find(pCfgParamList[i]) == m_IntCfgParams.end())
		{
			return false;
		}
	}
	return true;
}

bool ControlObjectEX::checkDoubleCfgParamList(string* pCfgParamList, int nLength)
{
	for (int i = 0; i < nLength; ++i)
	{
		if (m_DoubleCfgParams.find(pCfgParamList[i]) == m_DoubleCfgParams.end())
		{
			return false;
		}
	}
	return true;
}

bool ControlObjectEX::checkStringCfgParamList(string* pCfgParamList, int nLength)
{
	for (int i = 0; i < nLength; ++i)
	{
		if (m_StringCfgParams.find(pCfgParamList[i]) == m_StringCfgParams.end())
		{
			return false;
		}
	}
	return true;
}

//[chensc v1.1.19]
bool ControlObjectEX::checkIntActuatorList(string* pActuatorNameList, int nLength)
{
	for (int i = 0; i < nLength; ++i)
	{
		if (m_IntActuatorChs.find(pActuatorNameList[i]) == m_IntActuatorChs.end())
		{
			return false;
		}
	}
	return true;
}
//[chensc v1.1.19]
bool ControlObjectEX::checkDoubleActuatorList(string* pActuatorNameList, int nLength)
{
	for (int i = 0; i < nLength; ++i)
	{
		if (m_DoubleActuatorChs.find(pActuatorNameList[i]) == m_DoubleActuatorChs.end())
		{
			return false;
		}
	}
	return true;
}
//[chensc v1.1.19]
bool ControlObjectEX::checkStringActuatorList(string* pActuatorNameList, int nLength)
{
	for (int i = 0; i < nLength; ++i)
	{
		if (m_StringActuatorChs.find(pActuatorNameList[i]) == m_StringActuatorChs.end())
		{
			return false;
		}
	}
	return true;
}

void ControlObjectEX::usleepChange(unsigned long usec)
{
#ifdef IAP4_0
	unsigned int msec = usec / 1000;
	msleep(msec);
#else
	usleep(usec); //[zhangcx v1.7.0]
#endif
}

//add by pingsai 1.10.0
void ControlObjectEX::sleepChange(unsigned long sec)
{
#ifdef IAP4_0
	unsigned int msec = sec * 1000;
	msleep(msec);
#else
	sleep(sec);
#endif
}

IMPLEMENT_DYNAMIC(ControlObjectEX, ControlObject)

BEGIN_MSG_MAP(ControlObjectEX, ControlObject)
	SET_SS(addIntSensors, ControlObjectEX)
	SET_SS(addDoubleSensors, ControlObjectEX)
	SET_SS(addStringSensors, ControlObjectEX)
	SET_SS(addIntCfgParams, ControlObjectEX)
	SET_SS(addDoubleCfgParams, ControlObjectEX)
	SET_SS(addStringCfgParams, ControlObjectEX)
	SET_SS(addIntActuators, ControlObjectEX)    //[chensc v1.1.19]
	SET_SS(addDoubleActuators, ControlObjectEX) //[chensc v1.1.19]
	SET_SS(addStringActuators, ControlObjectEX) //[chensc v1.1.19]
END_MSG_MAP
