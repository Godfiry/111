/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: FinsPLCDevice.cpp
** Description: This driver is used for AI,AO,DO,DO through Fins protocol
*
** Release: 1.0
** Modification history:
**                  2021-6-26   Mayc create
*********************************************************************/

#include "FinsPLCDevice.h"
#include "DeviceManager.h"

#ifdef IAP4_0
#include "ITime.h"
#else
#include "Time.h"
#endif
#include "Hex.h"
#include <iostream>
#include <string.h>
#include <string.h>
#include <sys/time.h>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;

char FinsPLCDevice::Hello[20]=
{
    0x46,0x49,0x4E,0x53,//Fixed header FINS
    0x00,0x00,0x00,0x0C,//Length after this to frame-end
    0x00,0x00,0x00,0x00,//Command(0x00000000): FINS FRAME SEND Command
    0x00,0x00,0x00,0x00,// error code
    0x00,0x00,0x00,0x65// client node llcs ip 192.168.14.101
};


FinsPLCDevice::Cmd::Cmd()
{
    char m_tmpFinsHeader[4] = {0x46, 0x49, 0x4E, 0x53};
    memcpy(m_finsHeader, m_tmpFinsHeader, 4);

    char m_tmpdataLength[4] =  {0x00, 0x00, 0x00, 0x00};
    memcpy(m_dataLength, m_tmpdataLength, 4);

    char m_tmpCommandCode[4] = {0x00, 0x00, 0x00, 0x02};
    memcpy(m_commandCode, m_tmpCommandCode, 4);

    char m_tmpErrorCode[4] =  {0x00, 0x00, 0x00, 0x00};
    memcpy(m_errorCode, m_tmpErrorCode, 4);

    unsigned char m_tmpFixArea[10] = {0x80, 0x00, 0x02, 0x00, 0x03, 0x00, 0x00, 0x65, 0x00, 0xFF};  //changed by wzd 1.1.39
    memcpy(m_fixArea, m_tmpFixArea, 10);

    char m_tmpactionType[2] = {0x01, 0x01};
    memcpy(m_actionType, m_tmpactionType, 2);

    char m_tmpDataType[1] = {0x31};
    memcpy(m_dataType, m_tmpDataType, 1);

    char m_tmpAddress[3] = {0x00, 0x00, 0x00};
    memcpy(m_address, m_tmpAddress, 3);

    char m_tmpDataCount[2] = {0x00, 0x01};
    memcpy(m_dataCount, m_tmpDataCount, 2);


}

FinsPLCDevice::FinsPLCDevice()
{
    m_waiting = false;
    m_error = "";
    m_result = "";
    m_readCmd = false;
    m_ClientIP = "";
    int_clientIP = 0x01;
    int_serverIP = 0x01;
    nRecvBufferLength = 64;
    memset(m_recvBuffer, 0, sizeof(m_recvBuffer));

    m_readDICmds.m_dataLength[3] = 0x1A;
    m_writeDOCmds.m_dataLength[3] = 0x1B;
    m_readAICmds.m_dataLength[3] = 0x1A;
    m_writeAOCmds.m_dataLength[3] = 0x1C;

    m_writeDOCmds.m_actionType[1] = 0x02;
    m_writeAOCmds.m_actionType[1] = 0x02;

    m_readAICmds.m_dataType[0] = 0x82;
    m_writeAOCmds.m_dataType[0] = 0x82;

    m_writeDOCmds.m_address[1] = 0x0A;
    m_writeAOCmds.m_address[1] = 0x64;

}

FinsPLCDevice::~FinsPLCDevice()
{

}

std::string FinsPLCDevice::sendCommand(char* command,int cmdLength)
{
    if(!m_readCmd)
    {
//      log(LEVEL::FATAL,getName()+": ---FinsPLCDevice  send:----"+Hex::GetHexString(command,CmdLength));
    }
    m_waiting = true;
    m_error = "";
    memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
    const char* sendCmd = command;
    sendData(sendCmd, cmdLength);//sendData has IMutexLocker  to make sure send completed
    nRecvBufferLength = (sendCmd[33]& 0xFF);
//  cout<<"sendCommand ::after sendData=========="<<endl;

    //wait for replay
    int t_leftcount = m_timeOut*100000 / m_checkInterval;
    while(t_leftcount >= 0)
    {
        if(!m_waiting)
        {
            if(m_error != "")
            {
                cout << "sendCommand m_error==========" << m_error << endl;
                return m_error;
            }
            else
            {
                return "";
            }
        }

        //usleep(m_checkInterval * 1000);
        usleep(m_checkInterval * 20);
        --t_leftcount;
    }
    return "command read_back timeOut";
}

bool FinsPLCDevice::WriteInt(int channelNum, int value, const IntTypeInfo &typeInfo)
{
    string strResult ="";
    m_strErr = "";
    channelNum -= 100;
    
    m_writeDOCmds.m_address[1] = 0x0A;
    m_writeDOCmds.m_address[2] = 0x00;
    m_writeDOCmds.m_address[1] += (channelNum / 16) & 0xFF;
    m_writeDOCmds.m_address[2] += (channelNum % 16) & 0xFF;

    // send cmd DO
    char tmpCmd[35];
    memcpy(tmpCmd, (void*)&m_writeDOCmds, sizeof(m_writeDOCmds));

    tmpCmd[34] = value & 0xFF;
    strResult = sendCommand(tmpCmd,sizeof(m_writeDOCmds) + 1);
    //cout << "channel num " << channelNum << endl;
    //cout << ": ---FinsPLCDevice  WriteInt address1:----:" << Hex::GetHexString(&m_writeDOCmds.m_address[1],1) << endl;
    //cout << ": ---FinsPLCDevice  WriteInt address2:----:" << Hex::GetHexString(&m_writeDOCmds.m_address[2],1) << endl;
    //cout << ": ---FinsPLCDevice  WriteInt send:----:" << Hex::GetHexString(tmpCmd,sizeof(tmpCmd)) << endl;

    //sendcmd return "" means ok
    if(strResult != "")
    {
        m_strErr = strResult;
        return true;
    }
    else
    {
        return true;
    }
}

bool FinsPLCDevice::WriteDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
    string strResult ="";
    m_strErr="";
    channelNum -= 300;
    m_writeAOCmds.m_address[1] = 0x64;
    m_writeAOCmds.m_address[1] += channelNum & 0xFF;

    char tmpCmd[36];
    memcpy(tmpCmd, (void*)&m_writeAOCmds, sizeof(m_writeAOCmds));

    //double to char[]
    int tmpValue = 0; // change by chensc 1.1.21
    if(m_mapSpecialChlName[channelNum] == "VDMFlowAO" )
    {
        tmpValue = (int)(((value - typeInfo.getMin()) / (typeInfo.getMax() - typeInfo.getMin())) * 2000);
    }
    else if (m_mapSpecialChlName[channelNum] == "RFTimeLimit") //[1.5.0] add by chenwei for protect Etch base on step
    {
        tmpValue = (int)value;
    }
    else if(m_ScopeChannels.find(channelNum) != m_ScopeChannels.end())
    {
        tmpValue = (int)(((value - typeInfo.getMin()) / (m_ScopeChannels[channelNum].dMax - typeInfo.getMin())) * 4000);
    }
    else
    {
        tmpValue = (int)(((value - typeInfo.getMin()) / (typeInfo.getMax() - typeInfo.getMin())) * 4000);
    }
    
    tmpCmd[34] = (tmpValue >> 8) & 0xFF;
    tmpCmd[35] = tmpValue & 0xFF;
    //cout << ": ---FinsPLCDevice  writeDoubleCommand send:----:" << Hex::GetHexString(tmpCmd,sizeof(tmpCmd)) << endl;
    strResult = sendCommand(tmpCmd,sizeof(m_writeAOCmds) + 2);

    //sendcmd return "" means ok
    if(strResult != "")
    {
        //cout << ": ---FinsPLCDevice  writeDouble receive buffer:----:" << Hex::GetHexString(strResult) << endl;
        m_strErr = strResult;
        return true;
    }
    else
    {
        return true;
    }
}

bool FinsPLCDevice::getActionErr(int channelNum, std::string *value, const StringTypeInfo &typeInfo)
{
    *value=m_strErr;
    return true;
}

bool FinsPLCDevice::ReadInt(int channelNum, int *pValue, const IntTypeInfo &typeInfo)
{
    if(!isSimulated())
    {
        m_strErr="";
        string strResult ="";

        m_readDICmds.m_address[1] = (channelNum / 16) & 0xFF;
        m_readDICmds.m_address[2] = (channelNum % 16) & 0xFF;

        char tmpCmd[34];
        memcpy(tmpCmd, (void*)&m_readDICmds, sizeof(m_readDICmds));
        m_readCmd = true;
        
        string strError = sendCommand(tmpCmd,sizeof(m_readDICmds));
        //cout << ": ---FinsPLCDevice  readCommand send:----:" << Hex::GetHexString(tmpCmd,sizeof(m_readDICmds)) << endl;
        if(strError != "")
        {
            throw IOException(m_error);
        }
        m_readCmd = false;
        int tmp_ret = (int)((m_recvBuffer[6] << 8) + m_recvBuffer[7]) ;
        if(tmp_ret > 22)
        {
            //cout << ": ---FinsPLCDevice  receive buffer:----:" << Hex::GetHexString(m_recvBuffer,tmp_ret + 8) << endl;
            *pValue = m_recvBuffer[30] & 0xFF;
            return true;    //added by liuxj v1.1.54
        }
        else
        {
            *pValue = 3;
            m_strErr = m_error;
            throw IOException(m_error);
            cout<<"IOException==========="<<m_error<<endl;
            return true;
        }
    }
    else
    {
        return true;
    }
}

bool FinsPLCDevice::ReadMultiInt(int count)
{
    if(!isSimulated())
    {
        if (count > 16 || count < 1)
        {
            return true;
        }
        m_strErr="";
        string strResult ="";

        m_readDICmds.m_address[1] = 0x00;
        m_readDICmds.m_address[2] = 0x00;
        m_readDICmds.m_dataType[0] = 0xB1;
        m_readDICmds.m_dataCount[0] = 0x00;
        m_readDICmds.m_dataCount[0] = 0xFF & count;
        char tmpCmd[34];
        memcpy(tmpCmd, (void*)&m_readDICmds, sizeof(m_readDICmds));
        m_readCmd = true;
        //  log(LEVEL::FATAL,getName()+": ---FinsPLCDevice  readCommand send:----"+Hex::GetHexString(command,CmdLength));

        string strError = sendCommand(tmpCmd,sizeof(m_readDICmds));
        if(strError != "")
        {
            throw IOException(m_error);
        }
        m_readCmd = false;
        int tmp_ret = (int)((m_recvBuffer[6] << 8) + m_recvBuffer[7]) ;
        if(tmp_ret == 22 + count)
        {
            //*pValue = m_recvBuffer[30] & 0xFF;
            for (int i = 0; i < count; i++)
            {
                //cout << "m_recvData[" << i << "]: " << hex << m_recvBuffer[30 + i] & 0xFF << endl;
            }
        }
        else
        {

            m_strErr = m_error;
            throw IOException(m_error);
        }
        return true;    //added by liuxj v1.1.54
    }
    else
    {
        return true;
    }

}

bool FinsPLCDevice::ReadMultiDouble()
{
    if(!isSimulated())
    {
    }
    else
    {
        return true;
    }

}

bool FinsPLCDevice::ReadDouble(int channelNum, double *pValue, const DoubleTypeInfo &typeInfo)
{
    m_strErr="";
    string strResult ="";
    channelNum -= 200;
    m_readAICmds.m_address[1] = channelNum & 0xFF;
    double dTempValue =0.0;     //added by liuxj v1.1.54

    char tmpCmd[34];
    memcpy(tmpCmd, (void*)&m_readAICmds, sizeof(m_readAICmds));
    m_readCmd = true;
    //  log(LEVEL::FATAL,getName()+": ---FinsPLCDevice  readCommand send:----"+Hex::GetHexString(command,CmdLength));
    //cout << "channel num " << channelNum << endl;
    //cout << ": ---FinsPLCDevice  readDoubleCommand send:----:" << Hex::GetHexString(tmpCmd,sizeof(m_readAICmds)) << endl;
    long t_startTime = getCurrentTimeAsMSeconds();
    //if(channelNum == 1)
    //{
    //  cout<<"the processpr"<<endl;
    //}
    string strError = sendCommand(tmpCmd,sizeof(m_readAICmds));
    if(strError != "")
    {
        throw IOException(m_error);
    }
    m_readCmd = false;
    int tmp_ret = (int)((m_recvBuffer[6] << 8) + m_recvBuffer[7]) ;
    //cout<<"the data size is:"<<tmp_ret<<endl;

    if(tmp_ret > 22)
    {
        //cout << ": ---FinsPLCDevice  readDoubleCommand receive:----:" << Hex::GetHexString(m_recvBuffer,tmp_ret+8) << endl;
        //*pValue = (((double)(((int)(m_recvBuffer[30]) << 8) & 0xFF00) + ((int)(m_recvBuffer[31]) & 0xFF)) / 4000) *
        //      (typeInfo.getMax() - typeInfo.getMin()) + typeInfo.getMin();
        if(m_mapSpecialChlName[channelNum].find("PT") != string::npos)
        {
            *pValue = (((double)(((int)(m_recvBuffer[30]) << 8) & 0xFF00) + ((int)(m_recvBuffer[31]) & 0xFF) - 400) / 1600) *
                            (typeInfo.getMax() - typeInfo.getMin()) + typeInfo.getMin();

        }
        else if (m_mapSpecialChlName[channelNum] == "PCFlowOutAI" || m_mapSpecialChlName[channelNum] == "PCFlowOut2AI" || m_mapSpecialChlName[channelNum] == "CenterTapMonAI")
        {
            *pValue = (((double)(((int)(m_recvBuffer[30]) << 8) & 0xFF00) + ((int)(m_recvBuffer[31]) & 0xFF)) / 2000) *
                                        (typeInfo.getMax() - typeInfo.getMin()) + typeInfo.getMin();
        }
        else if(m_mapSpecialChlName[channelNum] == "VDMFlowAI" ) //change by chensc 1.1.21
        {
            *pValue = (((double)(((int)(m_recvBuffer[30]) << 8) & 0xFF00) + ((int)(m_recvBuffer[31]) & 0xFF)) / 2000) *
                                        (typeInfo.getMax() - typeInfo.getMin()) + typeInfo.getMin();
        }
        else if(m_mapSpecialChlName[channelNum] == "SRFReflectPWRAI" || m_mapSpecialChlName[channelNum] == "SRFFWDLPWRAI")//added by guojin[1.1.47]
        {
            *pValue = (((double)(((int)(m_recvBuffer[30]) << 8) & 0xFF00) + ((int)(m_recvBuffer[31]) & 0xFF)) / 4000) *
                            (typeInfo.getMax() - typeInfo.getMin()) + typeInfo.getMin();
            if(*pValue < 10)//filter noise
            {
                 *pValue = 0;
            }
        }
        else if(m_mapSpecialChlName[channelNum] == "PMHighVacuumGaugeAI" ) //change by liuxj 1.1.54
        {
            dTempValue = 1.667*(((double)(((int)(m_recvBuffer[30]) << 8) & 0xFF00) + ((int)(m_recvBuffer[31]) & 0xFF)) / 4000*10) - 11.46;
            dTempValue = pow(10,dTempValue);
            if(dTempValue >= 750)
            {
                dTempValue=750*1000;//Torr -> mTorr
            }
            else if(dTempValue <= 3.8e-09)
            {
                dTempValue=3.8e-09*1000;//Torr -> mTorr
            }
            else
            {
                dTempValue=dTempValue*1000;//Torr -> mTorr
            }
            *pValue = dTempValue; 
        }
        else
        {
            *pValue = (((double)(((int)(m_recvBuffer[30]) << 8) & 0xFF00) + ((int)(m_recvBuffer[31]) & 0xFF)) / 4000) *
                            (typeInfo.getMax() - typeInfo.getMin()) + typeInfo.getMin();
        }
        
        if(*pValue>typeInfo.getMax())
        {
            //cout<<"the value is over the max,the true value is:"<<*pValue<<endl;
            *pValue = typeInfo.getMax();
        }
        if(*pValue<typeInfo.getMin())
        {
            //cout<<"the value is over the max,the true value is:"<<*pValue<<endl;
            *pValue = typeInfo.getMin();
        }
        return true;
    }
    else
    {
        m_strErr = m_error;
        throw IOException(m_error);
        cout<<"IOException==========="<<m_error<<endl;
        return true;
    }

}

void FinsPLCDevice::parseReply()//mainly used to check recvBuffer has Error
{
    string t_reply(m_recvBuffer,m_recvBuffer +strlen(m_recvBuffer));

    int recvFrameLen = (m_recvBuffer[6] << 8) + m_recvBuffer[7];
    long t_leftTime = m_timeOut*1000;//ms
    long t_startTime = getCurrentTimeAsMSeconds();


    while(t_leftTime > 0)
    {
        if(recvFrameLen == 16)//reply to hello
        {
            cout<<"parseReply hello***************************************** "<<endl;
            return;
        }

        if ((recvFrameLen >= 22))
        {
//          cout<<"parseReply  ******************************************* "<<endl;
            if ((m_recvBuffer[8] != 0x00) || (m_recvBuffer[9] != 0x00) || (m_recvBuffer[10] != 0x00) || (m_recvBuffer[11] != 0x02))
            {
                string err =": Receive FINS frame failed! Invalid error code is "+t_reply.substr(9,4);
                cout  << err << endl;
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, err);
                m_error = err;
                return;
            }

            // check error code, should be 0x00000000
            if ((m_recvBuffer[12] != 0x00) || (m_recvBuffer[13] != 0x00)|| (m_recvBuffer[14] != 0x00) || (m_recvBuffer[15] != 0x00))
            {
                string err = ":receive error,Error code is "+t_reply.substr(9,4);
                 cout  << err << endl;
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, err);
                m_error = err;
                return; // need reconn
            }

            if ((m_recvBuffer[12] == 0x00) || (m_recvBuffer[13] == 0x00)|| (m_recvBuffer[14] == 0x00) || (m_recvBuffer[15] == 0x00))
            {
                return;
            }

        }
        usleep(m_checkInterval*1000);
        flush();
        t_reply += string(m_recvBuffer);
        t_leftTime -= getCurrentTimeAsMSeconds() - t_startTime;
        if(t_leftTime< 0)
        {
            m_error = "waiting execution done timeout "+t_reply;
            cout<<"waiting execution done timeout::: "<<endl;
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, ": ---RobotXinsongDock ::"+m_error);
            return;
        }

    }


}

void FinsPLCDevice::flush()
{
    memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
    if(!readData(m_recvBuffer, sizeof(m_recvBuffer)))
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName()+":reading failed in flush()");
    }
}

void FinsPLCDevice::acceptData()
{
    memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
    if(readData(m_recvBuffer, sizeof(m_recvBuffer)))
    {
        if(m_waiting)
        {
            parseReply();     //verify if there is some Error ,parse data is in  func readInt()\ ReadStr() which use recvBuffer
            m_waiting = false;
        }
        else
        {
            string strRawResult = string(m_recvBuffer);
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName()+": in acceptData() is not waiting");
        }
    }
    else
    {

        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": reading failed in acceptData()");
        if(m_waiting)
        {
            m_error = "read_back from device failed";
            m_waiting = false;
        }
    }
//  cout<<"########after  recive############"<<endl;
}

long FinsPLCDevice::getCurrentTimeAsMSeconds()
{
    struct timeval t_time;

    gettimeofday(&t_time, NULL);

    return (t_time.tv_sec*1000 + t_time.tv_usec/1000) ;
}

bool FinsPLCDevice::reconnectDevice()
{
    if(!m_running)
    {
        return false;
    }
    try
    {

    }
    catch(const exception &ex)
    {
        return false;
    }
    return TCPDevice::reconnectDevice();
}

void FinsPLCDevice::initChs(DeviceNode<FinsPLCDevice> *node)
{

    for(unsigned int i = 0; i <= 99; i++)
    {
        node->registerReadCh(i, &FinsPLCDevice::ReadInt);
    }

    for(unsigned int i = 100; i <= 199; i++)
    {
        node->registerWriteCh(i, &FinsPLCDevice::WriteInt);
    }

    for(unsigned int i = 200; i <= 299; i++)
    {
        node->registerReadCh(i, &FinsPLCDevice::ReadDouble);
    }

    for(unsigned int i = 300; i <= 399; i++)
    {
        node->registerWriteCh(i, &FinsPLCDevice::WriteDouble);
    }

}
//xml
void FinsPLCDevice::setClientIP(const std::string &ClientIP)
{
    m_ClientIP = ClientIP;
}

void FinsPLCDevice::setSpecialChlName(int channelNum, std::string name)
{
    m_mapSpecialChlName.insert(pair<int,std::string>(channelNum,name));
    if(m_mapSpecialChlName.find(channelNum) != m_mapSpecialChlName.end())
    {
        cout<<"channelNum1:"<<channelNum<<endl;
        cout<<"name1:"<<name<<endl;
    }
    else
    {
        cout<<"channelNum2:"<<channelNum<<endl;
        cout<<"name2:"<<name<<endl;
    }
}

void FinsPLCDevice::addScopeChl(int nChannelNum, double dMin, double dMax)//added by guojin[1.1.32]
{
    if(m_ScopeChannels.find(nChannelNum) != m_ScopeChannels.end())
    {
        cout<<"addScopeChannel already has:"<<nChannelNum<<endl;
    }
    else
    {
        ScopeInfo info;
        info.dMin=dMin;
        info.dMax=dMax;
        m_ScopeChannels.insert(pair<int,ScopeInfo>(nChannelNum,info));
    }
}

void FinsPLCDevice::init()
{
    DeviceNode<FinsPLCDevice> *node = new DeviceNode<FinsPLCDevice>(m_pollInterval,this);
    initChs(node);
    DeviceManager::getInstance()->registerNode(m_nodeNum, node);
    if(!isSimulated())
    {
        TCPDevice::init();
        Converter::stringToInt(int_clientIP, m_ClientIP.substr(m_server.find_last_of('.')+1));
        Converter::stringToInt(int_serverIP, m_server.substr(m_server.find_last_of('.')+1));
        Hello[19] = int_clientIP & 0xFF;
        //say hello!
        sendCommand(Hello,20);
        cout << ": ---FinsPLCDevice  hello:----:" << Hex::GetHexString(Hello,20) << endl;
        //get serverIP  clientIP
        m_readDICmds.m_fixArea[4] = int_serverIP & 0xFF;
        m_readDICmds.m_fixArea[7] = int_clientIP & 0xFF;
        m_writeDOCmds.m_fixArea[4] = int_serverIP & 0xFF;
        m_writeDOCmds.m_fixArea[7] = int_clientIP & 0xFF;
        m_readAICmds.m_fixArea[4] = int_serverIP & 0xFF;
        m_readAICmds.m_fixArea[7] = int_clientIP & 0xFF;
        m_writeAOCmds.m_fixArea[4] = int_serverIP & 0xFF;
        m_writeAOCmds.m_fixArea[7] = int_clientIP & 0xFF;

    }
}


IMPLEMENT_DYNAMIC(FinsPLCDevice, TCPDevice )
BEGIN_MSG_MAP( FinsPLCDevice, TCPDevice )
    SET_V(init,FinsPLCDevice)
    SET_S( setClientIP, FinsPLCDevice )
    SET_IS(setSpecialChlName, FinsPLCDevice)
    SET_IDD(addScopeChl,FinsPLCDevice)//added by guojin[1.1.32]
END_MSG_MAP
