/*
 * TCPDeviceFesto.h
 *
 *  Created on: Jun 4, 2021
 *      Author: zhangyy
 */

#ifndef TCPDEVICEFESTO_H_
#define TCPDEVICEFESTO_H_


#include "AbstractDevice.h"
#include <string.h>
#include <unistd.h>  //add by wzd 1.1.39
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class TCPConnectionFesto;

class TCPDeviceFesto:public AbstractDevice
{
	DECLARE_JOINT(TCPDeviceFesto)
	DECLARE_MSG_MAP

	private:
	TCPConnectionFesto *m_connection;
		bool m_connected;

	protected:
		std::string m_server;
		std::string m_port;
		int m_nodeNum;
		int m_pollInterval;//ms
		static const int s_INBUFFERSIZE = 65535;
		char m_recvBuffer[s_INBUFFERSIZE];
		int m_timeOut;//s
		int m_checkInterval;//ms
		bool m_running;

		bool isConnected()const;

		int m_nPrint;

	public:
		TCPDeviceFesto();
		virtual ~TCPDeviceFesto();

		void setServer(const std::string &server);
		void setPort(const std::string &port);
		virtual void init();
		virtual void readInput();
		virtual void writeOutput();
		virtual void executePositionRecord();
		virtual void updateModbusTimeOut();
		void sendData(const char *data, int size);
		void setNodeNum(int nodeNum);
		void setPollIntervalMS(int interval);
		void setTimeOutS(int timeOut);
		bool readData(char *buffer, int len);
		bool readFixLenData(char *buffer, int len);
		virtual bool reconnectDevice();
		virtual void setDeviceConnected(bool flag);
		virtual std::string getDeviceName();


};


#endif /* TCPDEVICEFESTO_H_ */
