/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: LFDNet.h
** Description:  CLB200A,350-450KHz,208V,DNet RF Power Supply
* 				Polled I/O connection.
***********************************************************************************
* 				Poll command message
* --------------------------------------------------------------------------------------------------
* Byte   |  7    |   6    |    5  |    4   |  3    |   2   |    1   |   0
* ------------- -----------------------------------------------------------------------------------
* 	0     |                Power Output Setpoing AO(LSB)
* -------------------------------------------------------------------------------------------------
*   1    |0      |   0    |    0  |   0     | Power Output Setpoing AO(MSB)  
* -------------------------------------------------------------------------------------------------
*   2     |0      |   0    |    0  |   0     | NotUsed
* -------------------------------------------------------------------------------------------------
*   3    |                   NotUsed
* -------------------------------------------------------------------------------------------------
*   4    |                                          | PULS  |  TM   |  PO
* -------------------------------------------------------------------------------------------------
* [Power Output Setpoint] 0-10V,10V =full output power of the generator 
* [PO] = power on command,1 = ON , 0 = OFF
* [TM] =Truning Mode,1 = Fixed  Frequency, 0 = Auto-tune
* [PULS] = Pulse Mode,1 = Pulse Mode Enabled, 0 = CW mode
* ***********************************************************************************
* Poll Response Message
* --------------------------------------------------------------------------------------------------
* Byte   |   7    |   6    |    5  |    4    |  3    |   2   |    1   |   0
* ------------- -----------------------------------------------------------------------------------
* 	0     |                Forward Power Sense AI (LSB)
* -------------------------------------------------------------------------------------------------
*   1    |   0    |   0    |    0  |    0    |  Forward Power Sense AI (MSB)  
* -------------------------------------------------------------------------------------------------
*   2     |				  Reflected Power Sense AI(LSB)
* -------------------------------------------------------------------------------------------------
*   3    |   0    |   0    |    0  |    0    |  Reflected Power Sense AI (MSB) 
* -------------------------------------------------------------------------------------------------
*   4    |                     Pulse Rep Rate (LSB)                  
* -------------------------------------------------------------------------------------------------
*   5    |                     Pulse Rep Rate (MSB)                  
* -------------------------------------------------------------------------------------------------
*   6    |                     Pulse Rep Rate (LSB)                  
* -------------------------------------------------------------------------------------------------
*   7      |   0      |     0    |    0  |   0     | 0      |   0    |    0  |   0     |              
* -------------------------------------------------------------------------------------------------
*   8      |   0   |   0   |  SPE | INTS  |  0   |   TS  | FF  | POS   | 
* -------------------------------------------------------------------------------------------------
* 
* [Forward Power Sense] 0-10V,10V = maximum rated power
* [Reflected Power Sense] 0-10V,10V = maximum reflected power
* [Pulse Rep Rate].Range is 150-5000Hz
* [Pulse Duty Cycle],range is 10 -90%
* [Pos] = Power On Status,1 = Frequency Fixed,0 = auto-tune
* [FF] = Fixed Frequency Status,1 = Frequency Fixed,0 = auto-tune
* [TS] = Temperature Status,1 = Normal range,0 = OVERTEMP
* [INTS] = Interlock Status,1 = satisfied,0 = open
* [SPE] = Serial Port Error,1 = Serial Link not responding,0 = Normal
** Release: 1.1
** Modification history: 
** 					2007-9-22   LiJuanjuan create
**      
*********************************************************************/

#ifndef LFDNET_H_
#define LFDNET_H_

#include "IODevice.h"
#include "DeviceNode.h"
#include "DeviceManager.h"
#include "ConfigException.h"
#include "ReadWriteInt.h"

#include "DoubleTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif
//using namespace std;
class LFDNet:public IODevice
{
	DECLARE_DYNAMIC(LFDNet)	
	DECLARE_MSG_MAP		
	public:
		LFDNet();
		virtual ~LFDNet();
		
		bool setLFPower(int channelNum, double value, const DoubleTypeInfo &typeInfo);
		bool getLFPower(int channelNum, double *value, const DoubleTypeInfo &typeInfo);
		bool readECT(int channelNum, double *value, const DoubleTypeInfo &typeInfo);
		bool writeECT(int channelNum, double value, const DoubleTypeInfo &typeInfo);
		bool setLFPowOn(int channelNum, int value, const IntTypeInfo &typeInfo);
						
		virtual void init();
		bool setMaxLFPower(double value);
//		bool setMFCMaxBinaryValue(int value);
		
	private:
		double m_maxLFPower;
        char buffersave[5];
		typedef struct
		{
			int m_serviceCd;
			int m_classID;
			int m_instanceID;
			int m_attributeID;
			int m_datasize;			
		}Com;
		static Com m_command[];		
//		double m_maxMFCBinaryValue;
};
#endif /*LFDNET_H_*/
