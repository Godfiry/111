/******************************************************************************
 ** Date: 2018-10-23 
 ** File name: ChillerJulaboFP50.h 
 ** Author: Zhang Yuanyuan
 ** product module: Julabo FP50-ME Refrigerated/Heating Circulator  
 ** Device communication setting:
     		BaudRate:  4800
     		CharSize:   7
			StopBit:    1
			Parity:     1 (Even check)
 ** Modification history:  
 ** 			2018-10-23   Zhangyy create
 ******************************************************************************/

#ifndef CHILLERJULABOFP50_H_
#define CHILLERJULABOFP50_H_
#ifdef IAP4_0
#include "ITime.h" 
#else
#include "Time.h" 
#endif
#include "SerialDevice.h"
#include "DeviceNode.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
#endif


class ChillerJulaboFP50:public SerialDevice
{
	DECLARE_DYNAMIC(ChillerJulaboFP50)	
	DECLARE_MSG_MAP	
	
private:
    static std::string m_commands[];
   // static std::string m_endLetter;
		
public:
    ChillerJulaboFP50();
    virtual ~ChillerJulaboFP50();
    void init();
    void initDevice();
    bool writeInt(int channelNum, int setpt, const IntTypeInfo &typeinfo);
    bool readInt(int channelNum, int *value, const IntTypeInfo &typeinfo);
    bool writeDouble(int channelNum, double setpt, const DoubleTypeInfo &typeinfo);
    bool readDouble(int channelNum, double * value, const DoubleTypeInfo &typeinfo);
    bool readAlarm(int channelNum, int * value ,const IntTypeInfo& typeinfo);
    void initChannels(DeviceNode<ChillerJulaboFP50> *node);
		
};
#endif /*CHILLERJULABOFP50_H_*/
