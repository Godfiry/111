#include "StrTool.h"
#include "NumberArrayTool.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "ConditionSyntaxException.h"
#endif
#include "Converter.h"
#include "ObjectManager.h"
#include <string.h>
#include <iostream>
#include <stdio.h>
#include "ConfigException.h"
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP;
using namespace IAP::CORE;
using namespace IAP::CONDITION;
#endif

vector<string> StrTool::split(const string &strData,char * pSeparator,int nSeparatorNum)
{
	vector<string> result;
	int nSepStart=0;
	int* pSeparatorPoint=new int[nSeparatorNum];
	for(int i =0 ; i < nSeparatorNum ; ++i)
	{
		pSeparatorPoint[i]=-1;
		pSeparatorPoint[i]=strData.find(pSeparator[i]);
	}
	while(true)
	{
		int nFirstSepPointIndex=NumberArrayTool::getMinNumExcept(pSeparatorPoint,nSeparatorNum,-1);
		
		if(nFirstSepPointIndex==-1)
		{
			string strTemp=strData.substr(nSepStart);
			result.push_back(strTemp);
			break;
		}
		else
		{
			int nFirstSep=pSeparatorPoint[nFirstSepPointIndex];
			
			if(nFirstSep>nSepStart)
			{
				string strTemp=strData.substr(nSepStart,nFirstSep-nSepStart);
				result.push_back(strTemp);
			}
			
			nSepStart=nFirstSep+1;
			if(nSepStart>=strData.length())
			{
				break;
			}
			pSeparatorPoint[nFirstSepPointIndex]=strData.find(pSeparator[nFirstSepPointIndex],nSepStart);
		}
	}
	
	delete [] pSeparatorPoint;//change by mujy for [1.6.0] bug
	pSeparatorPoint = NULL;
	return result;
}


vector<string> StrTool::split(const string &strData,const string &strSeparator)
{
	vector<string> result;
	size_t nSepStart=0;  //changed by wzd 1.1.39
	string::size_type pos=0;
	while(true)
	{
		pos=strData.find(strSeparator,nSepStart);
		if(pos==string::npos)
		{
			string strTemp=strData.substr(nSepStart);
			result.push_back(strTemp);
			break;
		}
		else
		{
			if(pos>nSepStart)
			{
				string strTemp=strData.substr(nSepStart,pos-nSepStart);
				result.push_back(strTemp);
			}
			nSepStart=pos+strSeparator.length();
			if(nSepStart>=strData.length())
			{
				break;
			}
		}
	}
	return result;
}

string StrTool::join(vector<string> &strs)
{
	return join(strs,"");
}

string StrTool::join(vector<string> &strs,const string strSeparator)
{
	ostringstream oss;

	for(int i = 0 ; i <strs.size()-1; ++i)
	{
		oss<<strs[i]<<strSeparator;
	}
	oss<<strs[strs.size()-1];
	return oss.str();
}

void StrTool::string_replace(string &strData, const string &str_oldvalue,const string &str_newvalue)
{
	while(true)
	{
		string::size_type pos=0;
		
		if((pos = strData.find(str_oldvalue)) != std::string::npos)
		{
			strData.replace(pos,str_oldvalue.length(),str_newvalue);
		}
		else
		{
			break;
		}
	}
}



string StrTool::toUpper(const std::string &str)
{
	//char *t_ch = const_cast<char*>(str.c_str());//delete by mujy [v1.6.1]
	char t_ch[str.length()+1];//added by mujy [v1.6.1]
	strcpy(t_ch,str.c_str());
	for(unsigned int i = 0; i< str.length(); ++i)
	{
		t_ch[i] = toupper(t_ch[i]);
	}
	return string(t_ch);	
}

std::string StrTool::toLower(const std::string &str)
{
	//char *t_ch = const_cast<char*>(str.c_str());//delete by mujy [v1.6.1]
	char t_ch[str.length()+1];//added by mujy [v1.6.1]
	strcpy(t_ch,str.c_str());
	for(unsigned int i = 0; i< str.length(); ++i)
	{
		t_ch[i] = tolower(t_ch[i]);
	}
	return string(t_ch);	
}	


AppConditionPtr StrTool::stringToCondition(const std::string &str)
{
	//verify string
	string expression = str;
	size_t t_posl = expression.find_first_of("(", 0);  //changed by wzd 1.1.39
	size_t t_posr = expression.find_last_of(")", expression.length()-1);  //changed by wzd 1.1.39
	string t_operator1 = "";
	if(t_posl == string::npos ||  t_posr == string::npos || t_posr != expression.length()-1)
	{
		throw ConditionSyntaxException("Construct condition by incorrect string! 1" + str);
	}
	if(t_posl != 0)
	{
		if((t_operator1 = expression.substr(0,1)) != "!" && (t_operator1 = expression.substr(0,7)) != "changes")
		{
			throw ConditionSyntaxException("Construct condition by incorrect string! 2" + str);
		}		
	}
	//end of recursion
	if(t_posl == expression.find_last_of("(", expression.length()-1) && t_posr == expression.find_first_of(")", 0))
	{
		if(t_operator1 == "changes")
		{
			expression = expression.substr(7, expression.length() - 7);///remove changes
			if(expression.find("=", 0) == string::npos && expression.find(">", 0) == string::npos && expression.find("<", 0) == string::npos)
			{
				expression = expression.substr(1, expression.length()-2);
				return new AppCondition((UntypedData*)ObjectManager::getInstance()->getObject(expression), t_operator1);
			}
			else
			{
				return new AppCondition(stringToCondition(expression),t_operator1);
			}
		}
		else if(t_operator1 == "!")
		{
			expression = expression.substr(1, expression.length() - 1);///remove !
			return new AppCondition(t_operator1, stringToCondition(expression));
		}
		else
		{
			string t_datal = "";
			string t_datar = "";
			if((t_posl = expression.find("==", 0)) != string::npos)
			{
				t_operator1 = "==";
				t_datar = expression.substr(t_posl+2, expression.length()-t_posl-3);
			}
			else if((t_posl = expression.find(">=", 0)) != string::npos)
			{
				t_operator1 = ">=";
				t_datar = expression.substr(t_posl+2, expression.length()-t_posl-3);
			}
			else if((t_posl = expression.find("<=", 0)) != string::npos)
			{
				t_operator1 = "<=";
				t_datar = expression.substr(t_posl+2, expression.length()-t_posl-3);
			}
			else if((t_posl = expression.find(">", 0)) != string::npos)
			{
				t_operator1 = ">";
				t_datar = expression.substr(t_posl+1, expression.length()-t_posl-2);
			}	
			else if((t_posl = expression.find("<", 0)) != string::npos)
			{
				t_operator1 = "<";
				t_datar = expression.substr(t_posl+1, expression.length()-t_posl-2);
			}
			else if((t_posl = expression.find("!=", 0)) != string::npos)
			{
				t_operator1 = "!=";
				t_datar = expression.substr(t_posl+2, expression.length()-t_posl-3);
			}
			else
			{
				throw ConditionSyntaxException("Construct condition by incorrect string!3 " + str);
			}	
			t_datal = 	expression.substr(1, t_posl-1);	
			double t_ddata = 0.0;	
			int t_idata = 0;
			if(t_datar.find("/", 0) == string::npos)	 
			{				
				if(t_datar.find(".",0) != string::npos)
				{
					
					if(!Converter::stringToDouble(t_ddata, t_datar))
					{
						throw ConditionSyntaxException("Construct condition by incorrect string! 4" + str);
					}
					else
					{
						return new AppCondition((UntypedData*)ObjectManager::getInstance()->getObject(t_datal), t_operator1, t_ddata);
					}
				}
				else if(Converter::stringToInt(t_idata, t_datar))
				{
					return new AppCondition((UntypedData*)ObjectManager::getInstance()->getObject(t_datal), t_operator1, t_idata);
				}
				else
				{
					return new AppCondition((UntypedData*)ObjectManager::getInstance()->getObject(t_datal), t_operator1, t_datar);
				}
			}	
			else
			{	
				return new AppCondition((UntypedData*)ObjectManager::getInstance()->getObject(t_datal), t_operator1, (UntypedData*)ObjectManager::getInstance()->getObject(t_datar));
			}
		}
	}
	else
	{
		expression = expression.substr(1,expression.length()-2);//remove outside () 
		if((t_operator1=expression.substr(0,1)) != "!" && (t_operator1=expression.substr(0,7)) != "changes")
		{
			t_posl = 0;
			t_posr = 0;
			while(true)
			{
				if(t_posl == string::npos && t_posr == string::npos)
				{
					throw ConditionSyntaxException("Construct condition by incorrect string! 5" + str);
				}
				t_posl = expression.find_first_of("(", t_posl+1);
				t_posr = expression.find_first_of(")", t_posr+1);
				if(t_posl > t_posr)	
				{
					break;
				}		
			}
			if(t_posr == expression.length()-1)//double ()
			{
				return stringToCondition(expression);
			}
			t_operator1 = expression.substr(t_posr+1, 2);
			if(t_operator1 != "&&" && t_operator1 != "||")
			{
				throw ConditionSyntaxException("Construct condition by incorrect string! 6" + str);
			}
			return new AppCondition(stringToCondition(expression.substr(0, t_posr+1)), t_operator1, stringToCondition("("+expression.substr(t_posl, expression.length()-t_posl)+")"));
		}
		else
		{
			if(t_operator1 == "!")
			{
				return new AppCondition(t_operator1, stringToCondition(expression.substr(1, expression.length()-1)));
			}
			else
			{
				return stringToCondition(expression);
			}			
		}
	}
}

string StrTool::getIOStringFromCondition(const std::string &str)
{
	//verify string
	string expression = str;
	size_t t_posl = expression.find_first_of("(", 0);  //changed by wzd 1.1.39
	size_t t_posr = expression.find_last_of(")", expression.length()-1);  //changed by wzd 1.1.39
	string t_operator1 = "";
	if(t_posl == string::npos ||  t_posr == string::npos || t_posr != expression.length()-1)
	{
		throw ConditionSyntaxException("failed to config IO monitor 1");
	}
	if(t_posl != 0)
	{
		if((t_operator1 = expression.substr(0,1)) != "!" && (t_operator1 = expression.substr(0,7)) != "changes")
		{
			throw ConditionSyntaxException("failed to config IO monitor 2");
		}
	}
	//end of recursion
	if(t_posl == expression.find_last_of("(", expression.length()-1) && t_posr == expression.find_first_of(")", 0))
	{
		if(t_operator1 == "changes")
		{
			expression = expression.substr(7, expression.length() - 7);///remove changes
			if(expression.find("=", 0) == string::npos && expression.find(">", 0) == string::npos && expression.find("<", 0) == string::npos)
			{
				expression = expression.substr(1, expression.length()-2);
				return expression;
			}
			else
			{
				return getIOStringFromCondition(expression);
			}
		}
		else if(t_operator1 == "!")
		{
			expression = expression.substr(1, expression.length() - 1);///remove !
			return getIOStringFromCondition(expression);
		}
		else
		{
			string t_datal = "";
			string t_datar = "";
			if((t_posl = expression.find("==", 0)) != string::npos)
			{
				t_operator1 = "==";
				t_datar = expression.substr(t_posl+2, expression.length()-t_posl-3);
			}
			else if((t_posl = expression.find(">=", 0)) != string::npos)
			{
				t_operator1 = ">=";
				t_datar = expression.substr(t_posl+2, expression.length()-t_posl-3);
			}
			else if((t_posl = expression.find("<=", 0)) != string::npos)
			{
				t_operator1 = "<=";
				t_datar = expression.substr(t_posl+2, expression.length()-t_posl-3);
			}
			else if((t_posl = expression.find(">", 0)) != string::npos)
			{
				t_operator1 = ">";
				t_datar = expression.substr(t_posl+1, expression.length()-t_posl-2);
			}
			else if((t_posl = expression.find("<", 0)) != string::npos)
			{
				t_operator1 = "<";
				t_datar = expression.substr(t_posl+1, expression.length()-t_posl-2);
			}
			else if((t_posl = expression.find("!=", 0)) != string::npos)
			{
				t_operator1 = "!=";
				t_datar = expression.substr(t_posl+2, expression.length()-t_posl-3);
			}
			else
			{
				throw ConditionSyntaxException("failed to config IO monitor 3");
			}
			t_datal = 	expression.substr(1, t_posl-1);
			if(t_datar.find("/", 0) == string::npos)
			{
				return t_datal;
			}
			else
			{
				return t_datal+"+"+t_datar;
			}
		}
	}
	else
	{
		expression = expression.substr(1,expression.length()-2);//remove outside ()
		if((t_operator1=expression.substr(0,1)) != "!" && (t_operator1=expression.substr(0,7)) != "changes")
		{
			t_posl = 0;
			t_posr = 0;
			while(true)
			{
				if(t_posl == string::npos && t_posr == string::npos)
				{
					throw ConditionSyntaxException("failed to config IO monitor 4");
				}
				t_posl = expression.find_first_of("(", t_posl+1);
				t_posr = expression.find_first_of(")", t_posr+1);
				if(t_posl > t_posr)
				{
					break;
				}
			}
			if(t_posr == expression.length()-1)//double ()
			{
				return getIOStringFromCondition(expression);
			}
			t_operator1 = expression.substr(t_posr+1, 2);
			if(t_operator1 != "&&" && t_operator1 != "||")
			{
				throw ConditionSyntaxException("failed to config IO monitor 5");
			}
			return getIOStringFromCondition(expression.substr(0, t_posr+1))+"+"+ getIOStringFromCondition("("+expression.substr(t_posl, expression.length()-t_posl)+")");
		}
		else
		{
			if(t_operator1 == "!")
			{
				return getIOStringFromCondition(expression.substr(1, expression.length()-1));
			}
			else
			{
				return getIOStringFromCondition(expression);
			}
		}
	}
}

//[lvjw]
string StrTool::Double2String(const double dData, const string strLength)
{
	char Code[20];
	string strFormat="%."+strLength+"lf";
	sprintf(Code,strFormat.c_str(),dData);
	string strResult(Code);
	return strResult;
}

//[lvjw]
string StrTool::Int2String(const int nData, const string strLength)
{
	char Code[20];
	string strFormat="%."+strLength+"d";
	sprintf(Code,strFormat.c_str(),nData);
	string strResult(Code);
	return strResult;
}

string StrTool::Int2HexString(int value)
{
	ostringstream t_o;
	int t_v1 = value;
	int t_v2 = 0;
	string t_res = "";
	while(t_v1 > 0)
	{
		t_v2 = t_v1 % 16;
		t_v1 = (int)(t_v1 / 16);
		t_o.str("");
		t_o <<hex << t_v2;
		t_res = t_o.str() + t_res;
	}
	return t_res;
}

string StrTool::Int2HexString(int value,int nlength)
{
	ostringstream t_o;
	int t_v1 = value;
	int t_v2 = 0;
	string t_res = "";
	while(t_v1 > 0)
	{
		t_v2 = t_v1 % 16;
		t_v1 = (int)(t_v1 / 16);
		t_o.str("");
		t_o <<hex << t_v2;
		t_res = t_o.str() + t_res;
	}
	while(t_res.length() < nlength)
	{
		t_res = "0"+t_res;
	}
	return t_res;
}

string StrTool::trim(string strData)
{
	string strResult;
	strResult=trim_start(strData);
	strResult=trim_end(strResult);
	return strResult;
}

string StrTool::trim_start(string strData)
{
	return trim_start(strData," ");
}

string StrTool::trim_end(string strData)
{
	return trim_end(strData," \n\r");
}

string StrTool::trim(string strData,const string strTrimChars)
{
	string strResult;
	strResult=trim_start(strData,strTrimChars);
	strResult=trim_end(strResult,strTrimChars);
	return strResult;
}

string StrTool::trim_start(string strData,const string strTrimChars)
{
	return strData.substr(strData.find_first_not_of(strTrimChars));
}

string StrTool::trim_end(string strData,const string strTrimChars)
{
	return strData.substr(0,strData.find_last_not_of(strTrimChars)+1);
}

bool StrTool::contains(string strData,string strContainStr)
{
	bool bResult = strData.find(strContainStr) != string::npos;
	return bResult;
}

bool StrTool::startWith(const string strData,const string strStart)
{
	return strData.substr(0,strStart.length())==strStart;
}

bool StrTool::endWith(const string strData,const string strEnd)
{
	return strData.substr(strData.length()-strEnd.length())==strEnd;
}

bool StrTool::stringToBool(const std::string& strData)//[zhangcx v1.2.0]
{
	if("true" == strData)
	{
		return true;
	}
	else if("false" == strData)
	{
		return false;
	}
	else
	{
		throw ConfigException("stringToBool failed for incorrect string " + strData);
	}
}
