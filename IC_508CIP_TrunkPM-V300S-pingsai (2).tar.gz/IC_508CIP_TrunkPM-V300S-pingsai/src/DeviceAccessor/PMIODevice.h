/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: PMIODevice.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2007-9-22   LiJuanjuan create
**      
*********************************************************************/
#ifndef PMIODEVICE_H_
#define PMIODEVICE_H_
 
#include "AbstractDevice.h"
#include "DeviceNode.h"
#include "DeviceNet.h"
#include "IntTypeInfo.h"
#include "DoubleTypeInfo.h"
#include "IODevice.h"
#include "ReadWriteInt.h"
#include "ReadWriteDouble.h"
#include <map>
#include <string.h>
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class PMIODevice:public IODevice
{
	DECLARE_DYNAMIC(PMIODevice)	
	DECLARE_MSG_MAP	

private:
	
	std::map<int,std::string> m_mapSpecialChlName;
protected:
//	int m_AIChlNum;
//	int m_AOChlNum;
	int m_DIStartPos;
	int m_DIChsSize;
	int m_AIStartPos;
	int m_AIChsSize;
	int m_AOStartPos;
	int m_AOChsSize;
	int m_DOStartPos;
	int m_DOChsSize;
	void initChs(DeviceNode<PMIODevice> *node);
	//added by liusy[1.1.57]
	int m_DIStartAddr;
	int m_AIStartAddr;
public:
		
	PMIODevice();
	virtual ~PMIODevice();
	void setDIInfo(int tDIStartPos, int tDIChsSize);
	void setDOInfo(int tDOStartPos, int tDOChsSize);
	void setAIInfo(int tAIStartPos, int tAIChsSize);
	void setAOInfo(int tAOStartPos, int tAOChsSize);
	void setDIStartAddr(int nStartAddr);//added by liusy[1.1.57]
	void setAIStartAddr(int nStartAddr);
	
	virtual void init();	
	bool readBit(int channelNum, int *bit, const IntTypeInfo &typeInfo);
	bool writeBit(int channelNum, int bit, const IntTypeInfo &typeInfo);
	bool readAnalog(int channelNum, double *value, const DoubleTypeInfo &typeInfo);
	bool writeAnalog(int channelNum, double value, const DoubleTypeInfo &typeInfo);
	void setSpecialChlName(int channelNum, std::string name);

};

#endif /*PMIODEVICE_H_*/
