/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TCPConnection.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-7-30   LiJuanjuan create
**      
*********************************************************************/
#include "TCPConnection.h"
#include "TCPDevice.h"
#include "SysLogger.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#include "ConfigException.h"
#include "TCPSocket.h"
#include <errno.h>
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;

TCPConnection::TCPConnection(const std::string &server, std::string port)
{
	m_socket = new TCPSocket(server, port);
	m_device = NULL;	
	m_state = s_CLOSED;
	m_running = false;
	m_timeout = 10;
	m_reconnectMonitor = new ReconnectMonitor(this);
}

TCPConnection::~TCPConnection()
{
	delete m_reconnectMonitor;
	delete m_socket;	
}


TCPConnection::ReconnectMonitor::ReconnectMonitor(TCPConnection *owner)
{
	m_connection = owner;
}

void TCPConnection::ReconnectMonitor::run()
{
	string deviceName = m_connection->m_device->getDeviceName();
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, deviceName + ":ReconnectMonitor start running");			
	try
	{
		m_connection->reconnectDevice();
	}
	catch(const exception &ex)
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, deviceName + ":ReconnectMonitor got exception - "+ex.what());			
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, deviceName + ":ReconnectMonitor exit");			
}


void TCPConnection::run()
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnection started run()");	
	int t_select;
	while(m_running)
	{
		try
		{
			if(!isConnected())
			{
				reconnect();
			}
			if(!m_running)
			{
				return;
			}		
			//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnection selecting");
			t_select = m_socket->select();			
			if(!m_running)
			{
				return;
			}
			if(0 == t_select)
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, m_device->getDeviceName() + ":TCPConnection select timeout.");
			}
			else if(-1 == t_select)
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, m_device->getDeviceName() + ":TCPConnection select error for " + m_socket->getErrnoStr());
				if(m_socket->getErrno() == EAGAIN || m_socket->getErrno() == EINTR)
				{
					SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, m_device->getDeviceName() + ":TCPConnection error is EAGAIN or EINTR and continue selecting");
					continue;
				}
				else
				{
					changeState(s_ERROR);
				}
			}
			else
			{
				m_device->acceptData();
			}
		}
		catch(const exception &ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, m_device->getDeviceName() + ":TCPConnection in run() got exception: " + string(ex.what()));
		}
	}
}

void TCPConnection::connect()
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnection connecting");
	changeState(s_CLOSED);
	m_socket->connect();
	changeState(s_CONNECTED);
	m_running = true;
	start();
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnection connected");
}

void TCPConnection::changeState(int newstat)
{
	m_state = newstat;
}

void TCPConnection::disconnect()
{	
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnection disconnecting");
	m_running = false;
	//m_reconnectMonitor->interupt();
	m_socket->shutdown(2);//close rw
	wait();	
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnection disconnected");
}

void TCPConnection::close()
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnection closing");				
	changeState(s_CLOSING);
	m_socket->shutdown(2);//close rw
	changeState(s_CLOSED);
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnection closed");	
}

void TCPConnection::reconnect()
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnection reconnecting");
	reconnectSocket();
	if(!m_running)
	{
		return;
	}

	sleep(1);//wait for device get ready
	m_reconnectMonitor->start();
	//reconnectDevice();
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnection reconnected");		
	
}
	
void TCPConnection::reconnectSocket()
{
	close();
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnection reconnecting socket");
	changeState(s_CONNECTING);
	while(!isConnected())
	{		
		if(!m_running)
		{
			return;			
		}	
		sleep(1);//1s	
		if(m_socket->reconnect() != 0)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnection reconnect socket failed for "+ m_socket->getErrnoStr());		
			continue;
		}
		changeState(s_CONNECTED);	
	}	
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, m_device->getDeviceName() + ":TCPConnection reconnected socket");				
}		
	
void TCPConnection::reconnectDevice()
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, m_device->getDeviceName() + ":TCPConnection reconnecting device");	
	while(isConnected() && !m_device->reconnectDevice())
	{		
		if(!m_running)
		{
			return;			
		}
		sleep(1);//1s		
	}	
	if(isConnected())
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, m_device->getDeviceName() + ":TCPConnection reconnected device");				
	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, m_device->getDeviceName() + ":TCPConnection reconnect device failed for socket disconnected");
	}
}
		
void TCPConnection::setDevice(TCPDevice *device)
{
	m_device = device;
}

void TCPConnection::sendData(const char *data, int size)
{
	IMutexLocker locker(&m_lock);
	//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, m_device->getDeviceName() + ":TCPConnection sending data :" + string(data));
	if(!isConnected())
	{
		throw IOException(m_device->getDeviceName()+ " send data failed for socked is not connected");
	}
	while(true)
	{
		if(m_socket->sendData(data, size) == -1)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, m_device->getDeviceName() + ":TCPConnection send error for " + m_socket->getErrnoStr());		
/*			if(m_socket->getErrno() == EINTR )//EAGAIN  errno means the sended data is bigger than socket send buffer 
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, m_device->getDeviceName() + ":TCPConnection error is EAGAIN or EINTR and continue send");
				continue;
			}
			else*/
			{			
				changeState(s_ERROR);				
				throw IOException(m_device->getDeviceName()+ " send data failed for " + m_socket->getErrnoStr());
			}		
		} 
		else
		{
			break;
		}
	}
	//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, m_device->getDeviceName() + ":TCPConnection sended data :" + string(data));	
}


bool TCPConnection::recvFixLenData(char *buffer, int len)
{
	IMutexLocker locker(&m_lock);
	while(true)
	{
		int t_recvCount = m_socket->recvFixLenData(buffer, len);
		if(0 == t_recvCount)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, m_device->getDeviceName() + ":TCPConnection recv FIN and server close connection");				
			changeState(s_CLOSED);
			return false;
		}
		else if (-1 == t_recvCount)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, m_device->getDeviceName() + ":TCPConnection recv error for " + m_socket->getErrnoStr());		
/*			if(m_socket->getErrno() == EAGAIN || m_socket->getErrno() == EINTR)
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, m_device->getDeviceName() + ":TCPConnection error is EAGAIN or EINTR and continue recv");
				continue;
			}
			else*/
			{			
				changeState(s_ERROR);				
				return false;
			}
		}		
		return true;
	}
}
		
bool TCPConnection::recvData(char *buffer, int len)
{
	IMutexLocker locker(&m_lock);
	while(true)
	{
		int t_recvCount = m_socket->recvData(buffer, len);
		if(0 == t_recvCount)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, m_device->getDeviceName() + ":TCPConnection recv FIN and server close connection");				
			changeState(s_CLOSED);
			return false;
		}
		else if (-1 == t_recvCount)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, m_device->getDeviceName() + ":TCPConnection recv error for " + m_socket->getErrnoStr());
/*			if(m_socket->getErrno() == EAGAIN || m_socket->getErrno() == EINTR)//by lijj 20110519 EAGAIN means there is no data to read
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, m_device->getDeviceName() + ":TCPConnection error is EAGAIN or EINTR and continue recv");
				continue;
			}
			else*/
			{			
				changeState(s_ERROR);				
				return false;
			}
		}	
		return true;
	}
}

bool TCPConnection::isConnected()const
{
	return (m_state == s_CONNECTED);
}

void TCPConnection::setTimeOut(int timeout)
{
	m_timeout = timeout;
}
