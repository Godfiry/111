#ifndef CIFXDEVNETAUTO_H_
#define CIFXDEVNETAUTO_H_

#include "DeviceNet.h"
#include "cifxdevnet_lib.h"
#include <unistd.h>  //add by wzd 1.1.39
//maxm adeded ....
#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include <termios.h>
#include <fcntl.h>
#include "cifXUser.h"                                                                 /* Include cifX driver API definition       */
#include "cifXErrors.h"                                                               /* Include cifX driver API error definition */
#include "rcX_User.h"                                                                 /* Include rcX definition file        */
#include "TLR_Types.h"                                                                /* Include TLR type definitions */
#include "TLR_Packet.h"  
#include "TLR_Results.h"                                                             /* Include TLR legacy header    */
#include "GetConfigFiles.h"                                                           /* Include Host PC example specifics header */
#include "Application.h"
#include "string.h"
//....maxm

extern CIFXHANDLE hChannel;
extern DNS_DEVICE_CFG * DevicesList[64];

class CIFXDEVNETAutoScan:public DeviceNet
{
public:
	CIFXDEVNETAutoScan(const std::string &devName, int masterMacId, int baudRate);
	virtual ~CIFXDEVNETAutoScan();

public:
		virtual void loadDevice(); 
		virtual bool addDevice(int inmac); 
		virtual int getIBytesSize(int inmac);
		virtual int getOBytesSize(int inmac);
		virtual bool readByte(int macid, char *buffer);
		virtual bool writeByte(int inmac, char *byte);
		virtual bool readBit(int inmac, int channel, bool *bit);
		virtual bool writeBit(int inmac, int channel, bool bit);
		virtual bool writeExplicit(int macid, char *buffer, int service, int Class, int instance, int datasize);
		virtual bool readExplicit(int macid, char *bufferIn, int service,int Class, int instance, int datasizeIn, char *bufferOut, int *datasizeOut);
		virtual int readStatus(int nMacId);
		
protected:
		void ShowError(int32_t lError);
		void networkScan(CIFXHANDLE hDnmChannel);
private:
	CIFX_LINUX_INIT m_Init;	
	CIFXHANDLE m_hDriver;
	int32_t       lRet;
	uint32_t      ulTimeout;
	uint32_t      ulState;
};

#endif /*CIFXDEVNETAUTO_H_*/
