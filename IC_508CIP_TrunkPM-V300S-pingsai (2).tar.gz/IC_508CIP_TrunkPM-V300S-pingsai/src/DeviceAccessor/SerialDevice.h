/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: SerialDevice.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2007-9-22   LiJuanjuan create
**      
*********************************************************************/
#ifndef SERIALDEVICE_H_
#define SERIALDEVICE_H_

#include "AbstractDevice.h"
#include "ISerialPort.h"
#include "CBase.h"
#include "Hex.h"
#include "MathTool.h"
#include "IntTypeInfo.h"
#include "CommunicationStatusEnum.h"
#include "DefineValue.h"
#include "DevicePara.h"
#include "SerialAdapter.h"
#include "DriverHelper.h"//added by mujy [1.5.0] for SerialDeviceBaseClass
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class SerialDevice : public AbstractDevice, public CBase
{
DECLARE_JOINT(SerialDevice)	
DECLARE_MSG_MAP

				
	public:
		SerialDevice(int maxMsgLen, const std::string &strCR);
		virtual ~SerialDevice();		
	
	public://xml	
		void setNodeNum(int nNodeNum);		
		void setDevice(const std::string &strDevName);
		void setBaudRate(unsigned int nRate);
		void setCharSize(unsigned int nSize);
		void setStopBit(unsigned int nStopBit);
		void setParity(unsigned int nParityMode);
		void setXonoff(bool bEnable);
		void setRtscts(bool bEnable);				
		void setPollInterval(int nMilliSecond);
		void setTimeout(int nMilliSecond);
		void setDeviceType(const std::string &deviceType);//merged from 1.6.3 by zhangyy[1.9.0]
		void setSlaveAddress(unsigned short slaveAddress);//merged from 1.6.3 by zhangyy[1.9.0]
		void setDataFrame(const std::string &dataFrame);//merged from 1.6.3 by zhangyy[1.9.0]
		void setIndex(unsigned short index);//merged from 1.6.3 by zhangyy[1.9.0]
		
		void setLog(bool bEnable);

	public:
		virtual bool getStatus(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);

	public:
		std::string getDeviceName()const;
	
	protected:
		//-------------
		virtual std::string getCommandResult(const std::string &strCommand, int nTimeOut);//fixed by liusy for UnitTest
		std::string getFixCommandResult(const std::string &strCommand, int nTimeOut, int nMsgLen, int nTryTimes);
		void sendCommandOnly(const std::string &strCommand);
		virtual std::string getResultOnly(int nTimeOut);//fixed by liusy for UnitTest
		std::string getResultOnly(int nTimeOut,int nMaxLen);
		
		//--------------
		int getCommandResult(char *pCommand, int nCommandLen, char *pResponse, int nResultLen, int nTimeOut);
		void getFixCommandResult(const char *pCommand, int nCommandLen, char *pResponse, int nResultLen, int nTimeOut, int nTryTimes);
		virtual void sendCommandOnly(const char *pCommand, int nLen);//fixed by liusy for UnitTest
		virtual int getResultOnly(char *pBuf, int nBufLen, int nTimeOut);//fixed by liusy for UnitTest
		void getFixResultOnly(char *pBuf, int nBufLen, int nTimeOut, int nTryTimes);

		void logCommunicationInfo(const std::string strInfo);
		void setCommunicationStatus(int nStatus);

	protected:	
		virtual void clearPort();
		
	protected:
		int m_nodeNum;
		int m_timeOut;// unit is 1/10s
		int m_pollPeriod;
		SerialAdapter m_dev;
		//ISerialPort m_dev;
		std::string m_strDevName;
		DeviceType m_type;

	private:
		int m_nMaxMsgLen;
		std::string m_strCR;
		
		bool m_bLogEnable;
		int m_nConnect;
};

#endif /*SERIALDEVICE_H_*/
