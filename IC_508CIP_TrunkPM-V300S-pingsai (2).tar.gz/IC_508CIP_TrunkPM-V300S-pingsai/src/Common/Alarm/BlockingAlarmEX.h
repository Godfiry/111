/********************************************************************
** Copyright (c) 2010, Beijing NMC Co.,Ltd.  product division.
** All rights reserved.
**
** File name: BlockingAlarmEX.h
**
** Description:
**
** Modification history:
* 							2016.11.10		lvjw	created.
*********************************************************************/
#ifndef BLOCKINGALARMEX_H_
#define BLOCKINGALARMEX_H_

#include "BlockingAlarm.h"
#include "CBase.h"
#ifdef IAP4_0
using namespace IAP::ALARM;
#endif

class BlockingAlarmEX:public BlockingAlarm,virtual public CBase
{
public:
	BlockingAlarmEX(const std::string &name, const std::string &message, 
									const std::string &description, Severity severity);
	virtual ~BlockingAlarmEX();
	
public:
	void setMessage(const std::string &s);
	void setDescription(const std::string &s);
	
	void setMessage(int nStringID);
	void setDescription(int nStringID);
	
};

#endif /*BLOCKINGALARMEX_H_*/
