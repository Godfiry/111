/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: COMETSingleMatchDriver.h
** Description:  
** Release: 1.1
** Modification history: 
** 					
**                  2014-11-21   lijj	create
*********************************************************************/
#ifndef COMETSMALLMATCH_H_
#define COMETSMALLMATCH_H_
#include "COMETMatchDriver.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#include "DescriptorList.h"
#include "StringTypeInfo.h"

#include <map>
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class CometSmallMatch:public COMETMatchDriver
{
	DECLARE_DYNAMIC(CometSmallMatch)	
	DECLARE_MSG_MAP	

	private:
		typedef struct
		{
			int m_ps;
			std::string m_s1;
			int m_ps2;
		}Com;
		
		typedef std::pair<std::string,DescriptorList> ParamPair;
		
		static std::map<std::string,DescriptorList> m_params;
		static ParamPair m_paramPairs[];
		static Com m_commands[];	  

	protected:
		void initChs(DeviceNode<CometSmallMatch> *node);
		void initDevice();	
		
	public:
		CometSmallMatch();
		virtual ~CometSmallMatch();
		
		bool writeInt(int channelNum, int value, const IntTypeInfo &typeInfo);
		bool writeRawCommand(int channelNum, std::string value, const StringTypeInfo &typeInfo);
		bool readInt(int channelNum, int *value, const IntTypeInfo &typeInfo);
		
		void init();		
};

#endif /*COMETSMALLMATCH_H_*/
