/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: FinsPLCDevice.h
** Description: This driver is used for AI,AO,DO,DO through Fins protocol
*
** Release: 1.0
** Modification history:
** 					2021-6-26   Mayc create
**
**	发送Fins/TCP命46494E53（FINS）0000001A（数据长度26）00000002（命令代码）00000000（错误代码）80000200(01)PLC地址0000（03）本机地址0000 0101（读取） B1（W区） 0064（字） 00（位） 0001（读取数据数量）（FINS命令帧）
**	反馈是46494E53（FINS）00000018（数据长度24）00000002（命令代码）0000 0000（错误代码）C0 00 02 00 03 00 00 01 00 00 01 01 00 00 12 34 （FINS反馈帧1234是反馈数据）
**	发送Fins/TCP命令46494E53（FINS）0000001C（数据长度28）00000002（命令代码）00000000（错误代码）80000200010000030000 0102（写入） 82（D区） 0000（字） 00（位） 0001（数量） 1234（写入数据数量）（FINS命令帧）
**	反馈如下46494E53（FINS）00000016（数据长度22）00000002（命令代码）00 000000（错误代码）C0 00 02 00 03 00 00 01 00 00 01 02 00 00（FINS反馈帧0000是反馈代码表示通讯正常）
**
**
*********************************************************************/

#ifndef FINSPLCDEVICE_H_
#define FINSPLCDEVICE_H_

#include "TCPDevice.h"
#include "DeviceNode.h"
#include "IntTypeInfo.h"
#include "DoubleTypeInfo.h"
#include "StringTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

using namespace std;



class FinsPLCDevice : public TCPDevice
{
	DECLARE_DYNAMIC(FinsPLCDevice)
		DECLARE_MSG_MAP
	public:
		FinsPLCDevice();
		virtual ~FinsPLCDevice();

	public://override
		virtual void init();

	public://interface
		bool WriteInt(int channelNum, int value, const IntTypeInfo &typeInfo);
		bool WriteDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo);
		bool ReadInt(int channelNum, int *pValue, const IntTypeInfo &typeInfo);
		bool ReadMultiInt(int count);
		bool ReadDouble(int channelNum, double *pValue, const DoubleTypeInfo &typeInfo);
		bool ReadMultiDouble();
	//	bool getMapResult(int channelNum, std::string *value, const StringTypeInfo &typeInfo);
		bool getActionErr(int channelNum, std::string *value, const StringTypeInfo &typeInfo);

	public://xml
		void setClientIP(const std::string &ClientIP);
		void setSpecialChlName(int channelNum, std::string name);
		void addScopeChl(int nChannelNum, double dMin, double dMax);//added by guojin[1.1.32]

	protected:
		void parseReply();
		void flush();

		virtual void acceptData();
		virtual bool reconnectDevice();
		std::string sendCommand(char* command,int CmdLength);

		long getCurrentTimeAsMSeconds();

	private:
		void initChs(DeviceNode<FinsPLCDevice> *node);

	private:
		std::string m_strErr;
		std::string m_recivedDataStr;
		bool m_readCmd;
		bool m_waiting;
		int int_clientIP;
		std::string m_ClientIP;
		int int_serverIP;
		//long m_startTime;		

		std::string m_error;
		std::string m_result;
		static std::string m_strCmds[13];
		static  char Hello[20];

		char m_sendCmds[35];
		char m_recvBuffer[64];
		int nRecvBufferLength;
		std::map<int,std::string> m_mapSpecialChlName;
		
		typedef struct
		{
			double dMax;
			double dMin;
		}ScopeInfo;
		std::map<int, ScopeInfo> m_ScopeChannels; //added by guojin[1.1.32]
		
		struct Cmd{
			char m_finsHeader[4];
			char m_dataLength[4];
			char m_commandCode[4];
			char m_errorCode[4];
			char m_fixArea[10];  //m_fixArea[4] PLC地址，m_fixArea[7]本机地址
			char m_actionType[2];
			char m_dataType[1];
			char m_address[3];
			char m_dataCount[2];
			Cmd();
		};
		Cmd m_readDICmds;
		Cmd m_writeDOCmds;
		Cmd m_readAICmds;
		Cmd m_writeAOCmds;
};

#endif /* FINSPLCDEVICE_H_ */
