/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: UTime.cpp
** Description: This class offers functions to get the system time
** Release: 1.1
** Modification history: 
** 					2009-09-2   LiJuanjuan create
**      
*********************************************************************/
#include "UTime.h"
#ifdef IAP4_0
#include "ITime.h"
#else
#include "Time.h"
#endif
//#include <string>
#include <sys/time.h>
#ifdef IAP4_0
using namespace IAP::CORE;
#endif
//#include <strings.h>
//#include <iostream>

using namespace std;
/*
UTime::UTime()
{
}

UTime::~UTime()
{
}*/

long UTime::getCurrentTimeAsMSeconds()
{
	struct timeval t_time;

	gettimeofday(&t_time, NULL);

	return (t_time.tv_sec*1000 + t_time.tv_usec/1000) ;
}


