/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					Jan 22, 2008  shenql  create 
**      
***************************************************************************/
#ifndef SLOTMAPINFO_H_
#define SLOTMAPINFO_H_
#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class SlotMapInfo : public IntValueInfo
{
public:

		static const int UnInit = -1;
		static const int Unknown = 0;
		static const int Absent = 1;
		static const int Present= 2;
		static const int XSlotted = 3;
		static const int Doubled = 4;
		static const int Present200 = 5;
		static const int Present300 = 6;
		static const IntTypeInfo typeInfo;

	   SlotMapInfo():IntValueInfo(-1, typeInfo)
	   {
	   }
	
	   SlotMapInfo(int i):IntValueInfo(i, typeInfo)
	    {
	    }
	
	   SlotMapInfo(std::string s):IntValueInfo(s, typeInfo)
	    {
	    }
};


#endif /*SLOTMAPINFO_H_*/
