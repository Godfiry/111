/********************************************************************
** Copyright (c) 2019, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: DefineValue.h
** Description:
** Release: 1.1
** Modification history:
**					2019-6-12   mujy modify [V1.0.8]
*********************************************************************/

#ifndef DEFINEVALUE_H_
#define DEFINEVALUE_H_

#define COMMUNICATION_STATUS_CHANNEL 1000

#endif
