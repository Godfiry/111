/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TMCException.cpp
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-02-26  LiJuanjuan create
**      
*********************************************************************/
#include "TMCException.h"

TMCException::TMCException(const std::string &s):AbortException(s)
{
}
