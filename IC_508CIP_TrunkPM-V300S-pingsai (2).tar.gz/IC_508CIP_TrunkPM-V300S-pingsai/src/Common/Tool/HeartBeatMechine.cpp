
#include "HeartBeatMechine.h"
#include "XmlGetter.h"
#include <iostream>
#include "SysLogger.h"
#include "ConfigException.h"
#include "Converter.h"
#include "UTime.h"
#include "AlarmManager.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::ALARM;
using namespace IAP::CONDITION;
#endif
#include "unistd.h"

HeartBeatMechine::HeartBeatMechine()
{
	m_nBeatInterval=1000;
	//m_pMyTimer = NULL;
	m_bKeepRun = false;//zhangyy add[1.8.0]
	m_pBeatChannel = NULL;
	m_nBeatLeave = 0;
	m_pProcessTheRecipeFlag = NULL;//added by zhangyy [1.6.0]
	m_pMaxProcessTime = NULL;//added by zhangyy [1.6.0]
	m_longProcessOnBeginTime = 0;//added by zhangyy [1.6.0]
	m_ProcessOnCondition = NULL;//added by zhangyy [1.6.0]
	m_pProcessOnTimeOutAlarm = NULL;//added by zhangyy [1.6.0]
}

HeartBeatMechine::~HeartBeatMechine()
{
	/**
	if(m_pMyTimer != NULL)//modified by mujy 20250312 [V1.2.0] for core dump
	{
		m_pMyTimer->stop();
		#ifndef IAP4_0
		delete m_pMyTimer;
		m_pMyTimer = NULL;
		#endif

	}
	**/
	m_bKeepRun = false;//zhangyy add[1.8.0]
}

void HeartBeatMechine::make()//added by zhangyy [1.6.0]
{
	try
	{
		m_pProcessTheRecipeFlag = XmlGetter::getFromNamespace<ReadWriteInt*>("IO/Datas/ProcessTheRecipeFlag");
	}
	catch(const exception &e)
    {
       m_pProcessTheRecipeFlag = XmlGetter::getFromNamespace<ReadWriteInt*>("Control/PMCExports/Datas/ProcessTheRecipeFlag");
    }
    try
	{
		m_pMaxProcessTime = XmlGetter::getFromNamespace<ReadWriteDouble*>("IO/Datas/MaxProcessTime");
	}
	catch(const exception &e)
    {
       m_pMaxProcessTime = XmlGetter::getFromNamespace<ReadWriteDouble*>("Control/PMCExports/Datas/PM_S1_MaxProcessTime");
    }
	m_ProcessOnCondition = new AppCondition(m_pProcessTheRecipeFlag,"==", 1);
}

void HeartBeatMechine::startup()
{
	
	CmdTarget::startup();
	/**
	m_pMyTimer = new Timer();
	m_pMyTimer->subscribe(this);
	m_pMyTimer->setDuration((long)(m_nBeatInterval));
	m_pMyTimer->start();
	**/
	m_bKeepRun = true;
	bool bFlag = IThread::start();//added by zhangyy using Thread[1.8.0]
	if(!bFlag)
	{
		throw ConfigException("HeartBeat thread start failed!");
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT,getName()+": HeartBeat startup !");
	if(m_pBeatChannel != NULL )
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT,getName()+": m_pBeatChannel's value is: "+Converter::convertToString(m_pBeatChannel->getValue()));
	}
	else
	{
		throw ConfigException("m_pBeatChannel is null!");
	}
	m_ProcessOnCondition->activate();//added by zhangyy [1.6.0]
	m_pProcessOnTimeOutAlarm = AlarmManager::getInstance()->getAlarm("StatusMonitor_ProcessOnTimeOut");
}


bool HeartBeatMechine::checkProcessOverEtch()//added by zhangyy [1.6.0]
{
	if(NULL == m_pProcessTheRecipeFlag || NULL == m_pMaxProcessTime )
	{
		return false;
	}
	else
	{
		if( NULL != m_pProcessOnTimeOutAlarm && m_pProcessOnTimeOutAlarm->isPosted())//ProcessOnTimeout alarm is posted.
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT,getName()+": ProcessOnTimeout alarm is posted!");
			return true;//Process is over etch
		}
		else if(m_ProcessOnCondition->judge() == 1 )//ProcessOnTimeout alarm is not posted. Begin process
		{
			if(m_longProcessOnBeginTime == 0)
			{
				m_longProcessOnBeginTime = UTime::getCurrentTimeAsMSeconds();
				return false;
			}
			else
			{
				long longMaxProcessTimeMS = (long)(m_pMaxProcessTime->getValue()*1000);
				if((UTime::getCurrentTimeAsMSeconds() - m_longProcessOnBeginTime) < longMaxProcessTimeMS )
				{
					return false;
				}
				else
				{
					SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT,getName()+": ProcessOnTimeout alarm is not posted but process over etch!");
					return true;//Process is over etch
				}
			
			}
		}
		else
		{
			m_longProcessOnBeginTime = 0;
			return false;//Not in process status
		}
	}
}
/**  deleted by zhangyy[1.8.0]
#ifdef IAP4_0
void HeartBeatMechine::updateFromTimer(const Timer * const timer)
#else
void HeartBeatMechine::updateFromTimer()
#endif
{
	m_nBeatLeave = m_nBeatLeave ^ 0x01;
	try
	{
		if(m_pBeatChannel != NULL)
		{
			if(checkProcessOverEtch())//Process over etch. added by zhangyy [1.6.0]
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT,getName()+": HeartBeat stopped for process on time out!");
			}
			else
			{
				m_pBeatChannel->setValue(m_nBeatLeave);
			}
			
		}
		else
		{
		      throw ConfigException("updateFromTimer : m_pBeatChannel is null!");
		}
	}
	catch(...)
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
											"HeartBeat write channel failed!");
	}
}
**/
void HeartBeatMechine::run()//Added by zhangyy using Thread[1.8.0]
{
	while(m_bKeepRun)
	{
		try
		{
			if(m_pBeatChannel != NULL)
			{
				if(checkProcessOverEtch())//Process over etch. added by zhangyy [1.6.0]
				{
					SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT,getName()+": HeartBeat stopped for process on time out!");
				}
				else
				{
					m_pBeatChannel->setValue(m_nBeatLeave);
				}
				
			}
			else
			{
			      throw ConfigException("HeartBeatMechine run : m_pBeatChannel is null!");
			}
		}
		catch(...)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "HeartBeat write channel failed!");
		}
		m_nBeatLeave = m_nBeatLeave ^ 0x01;
		usleep(m_nBeatInterval*1000);
	}
}


void HeartBeatMechine::setBeatInterval(int nMS)
{
	m_nBeatInterval = nMS;
}

void HeartBeatMechine::setBeatChannel(string strPath)
{
	m_pBeatChannel=XmlGetter::getFromNamespace<ReadWriteInt *>(strPath);
	if(m_pBeatChannel == NULL )
	{
		throw ConfigException("m_pBeatChannel is null!");
	}
	m_pBeatChannel->setValue(0);
}

IMPLEMENT_DYNAMIC(HeartBeatMechine, CmdTarget)

BEGIN_MSG_MAP( HeartBeatMechine, CmdTarget )
	SET_I(setBeatInterval, HeartBeatMechine)
	SET_S(setBeatChannel, HeartBeatMechine)
END_MSG_MAP
