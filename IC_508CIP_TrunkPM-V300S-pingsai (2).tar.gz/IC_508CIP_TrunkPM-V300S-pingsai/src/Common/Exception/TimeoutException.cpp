/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TimeoutException.cpp
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-02-26  LiJuanjuan create
**      
*********************************************************************/
#include "TimeoutException.h"

TimeoutException::TimeoutException(const std::string &s):TMCException(s)
{
}


