/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: KYKYTurboMolecularPump.cpp
** Description:for Shimadzu TMP 
** Release: 1.1
** Modification history: 
**                     chensc create 20230411
*********************************************************************/
#include "KYKYTurboMolecularPump.h"
#include "DeviceManager.h"
#include "ObjectManager.h"
#include "Converter.h"

#include "StrTool.h"
#include "Hex.h"
#include "CheckCalculationTool.h"
#include <sys/time.h>
#include <iostream> 
#include <string.h>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std;

KYKYTurboMolecularPump::KYKYTurboMolecularPump():SerialDevice(8000, "")
{	
	m_timeOut = 200;//2s
	
	//the form of the read Meas command
	m_pReadCmd[0] = 0x10;//controller address
	m_pReadCmd[1] = 0x03;//function read
	m_pReadCmd[2] = 0x00;//read starting at register high byte
	m_pReadCmd[3] = 0x00;//read starting at register low byte
	m_pReadCmd[4] = 0x00;//read number of consecutive register high
	m_pReadCmd[5] = 0x00;//read number of consecutive register low
	m_pReadCmd[6] = 0x00;//Low byte of CRC
	m_pReadCmd[7] = 0x00;//High byte of CRC
	
}

KYKYTurboMolecularPump::~KYKYTurboMolecularPump()
{
}

bool KYKYTurboMolecularPump::readDouble(int channelNum,double * dValue , const DoubleTypeInfo& typeinfo)
{
	if (isSimulated())
	{
		struct timeval tm;
		struct timezone *tz = NULL;
		
		gettimeofday(&tm,tz);
		*dValue = typeinfo.getMax() * ((double)tm.tv_usec / 1000000);
		return true;
	}
	   	
   	if (channelNum ==1) 
   	{
		m_pReadCmd[2] = 0x10;
		m_pReadCmd[3] = 0x00;
		m_pReadCmd[4] = 0x00;
		m_pReadCmd[5] = 0x04;
		m_pReadCmd[6] = 0x43;
		m_pReadCmd[7] = 0x88;
   	}
   	else if (channelNum ==2) 
   	{
		m_pReadCmd[2] = 0x10;
		m_pReadCmd[3] = 0x08;
		m_pReadCmd[4] = 0x00;
		m_pReadCmd[5] = 0x04;
		m_pReadCmd[6] = 0xC2;
		m_pReadCmd[7] = 0x4A;
   	}
   	else if (channelNum ==3) 
   	{
    		m_pReadCmd[2] = 0x10;
		m_pReadCmd[3] = 0x00;
		m_pReadCmd[4] = 0x00;
		m_pReadCmd[5] = 0x04;
		m_pReadCmd[6] = 0x43;
		m_pReadCmd[7] = 0x88;
   	}
   	else
   	{
		cout << "TMP:channelNum "<<channelNum<<" is not registered on readDouble()"<< endl;
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() 
		+ string(" TMP:channelNum")+Converter::convertToString(channelNum)+string(" is not registered on readDouble()"));
		return false;
		//throw IOException("TMP: IO channel is not registered on readDouble()..");
   	}
	   	
   	//unsigned short crc = CheckCalculationTool::GetCRCCode( m_pReadCmd, 6 );
   	//m_pReadCmd[6] = (crc & 0xFF) & 0xFF;    // low byte of CRC
   	//m_pReadCmd[7] = (crc >> 8) & 0xFF;  //  high byte of CRC

   	char response[RESP_LEN];
	memset(response, 0, RESP_LEN);
	sendCommandOnly(m_pReadCmd, 8);

	if(getResultOnly(response,RESP_LEN, m_timeOut) < 0)
	{
		throw IOException(getDeviceName() + ": reading back times out");
	}
	if(response[0] == m_pReadCmd[0] && response[1] == 0x03)
	{
		if(channelNum == 1)  //speed
		{
			unsigned char  cByte[4];//save the 32-bite
			int val;
			response[3] = response[3]&0x00ff;
			response[4] = response[4]&0x00ff;
			cByte[0] = response[3];
			cByte[1] = response[4];
			int t_val = (cByte[0] << 8) | cByte[1];
			*dValue = (double)t_val * 6;
			return true;
		}
		if(channelNum == 2) //tempt
		{
			unsigned char  cByte[4];//save the 32-bite
			int val;
			response[5] = response[5]&0x00ff;
			response[6] = response[6]&0x00ff;
			cByte[0] = response[5];
			cByte[1] = response[6];
			int t_val = (cByte[0] << 8) | cByte[1];
			*dValue = (double)t_val;
			return true;
		}
		if(channelNum == 3)  //current
		{
			unsigned char  cByte[4];//save the 32-bite
			int val;
			response[7] = response[7]&0x00ff;
			response[8] = response[8]&0x00ff;
			cByte[0] = response[7];
			cByte[1] = response[8];
			int t_val = (cByte[0] << 8) | cByte[1];
			*dValue = (double) t_val / 100 ;
			return true;
		}
	}
	else
	{
		cout<< "TMP:the read data command is invalid, response is "<<hex<<(int)response[0]<<" "<<(int)response[1]<<" "<<(int)response[2]<<" "<<(int)response[3]<<" "<<(int)response[4]<<" "<<(int)response[5]<<" "<<(int)response[6]<<endl;
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + string(" TMP:the read data command is invalid."));
		return false;
		//throw IOException("TMP:the read data command is invalid");
	}
			
}

bool KYKYTurboMolecularPump::readInt(int channelNum,int * value ,const IntTypeInfo& typeinfo)
{
	m_pReadCmd[2] = 0x10;
	m_pReadCmd[3] = 0x04;
	m_pReadCmd[4] = 0x00;
	m_pReadCmd[5] = 0x04;
	m_pReadCmd[6] = 0x02;
	m_pReadCmd[7] = 0x49;

 	char response[RESP_LEN];
	memset(response, 0, RESP_LEN);
	sendCommandOnly(m_pReadCmd, 8);
	if(getResultOnly(response,RESP_LEN, m_timeOut) < 0)
	{
		throw IOException(getDeviceName() + ": reading back times out");
	}


	if(response[0] == m_pReadCmd[0] && response[1] == 0x03)
	{
		if(channelNum == 11)  //errorcode1
		{
			unsigned char  cByte[4];//save the 32-bite
			int val;
			response[3] = response[3]&0x00ff;
			response[4] = response[4]&0x00ff;
			cByte[0] = response[3];
			cByte[1] = response[4];
			int t_val = (cByte[0] << 8) | cByte[1];
			*value = t_val;
			return true;
		}
		else if(channelNum == 12) //errorcode2
		{
			unsigned char  cByte[4];//save the 32-bite
			int val;
			response[5] = response[5]&0x00ff;
			response[6] = response[6]&0x00ff;
			cByte[0] = response[5];
			cByte[1] = response[6];
			int t_val = (cByte[0] << 8) | cByte[1];
			*value = t_val;
			return true;
		}
		else if(channelNum == 13) //errorcode3
		{
			unsigned char  cByte[4];//save the 32-bite
			int val;
			response[7] = response[7]&0x00ff;
			response[8] = response[8]&0x00ff;
			cByte[0] = response[7];
			cByte[1] = response[8];
			int t_val = (cByte[0] << 8) | cByte[1];
			*value = t_val;
			return true;
		}
		else if(channelNum == 14) //errorcode4
		{
			unsigned char  cByte[4];//save the 32-bite
			int val;
			response[9] = response[9]&0x00ff;
			response[10] = response[10]&0x00ff;
			cByte[0] = response[9];
			cByte[1] = response[10];
			int t_val = (cByte[0] << 8) | cByte[1];
			*value = t_val;
			return true;
		}
	}
	else
	{
		cout<< "TMP:the read data command is invalid, response is "<<hex<<(int)response[0]<<" "<<(int)response[1]<<" "<<(int)response[2]<<" "<<(int)response[3]<<" "<<(int)response[4]<<" "<<(int)response[5]<<" "<<(int)response[6]<<endl;
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + string(" TMP:the read data command is invalid."));
		return false;
		//throw IOException("TMP:the read data command is invalid");
	}
}

void KYKYTurboMolecularPump::initChs(DeviceNode<KYKYTurboMolecularPump> *node)
{
	for(unsigned int i = 1; i <= 10; i++)
	{
		node->registerReadCh(i, &KYKYTurboMolecularPump::readDouble);
	}
	for(unsigned int i = 11; i<=15;i++)
	{
		node->registerReadCh(i, &KYKYTurboMolecularPump::readInt);
	}
}

	
void KYKYTurboMolecularPump::init()
{
	DeviceNode<KYKYTurboMolecularPump> *node = new DeviceNode<KYKYTurboMolecularPump>(m_pollPeriod, this);
	initChs(node);		
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
}

string KYKYTurboMolecularPump::getDeviceName()
{
	return __FILE__;
}

IMPLEMENT_DYNAMIC(KYKYTurboMolecularPump, SerialDevice)

BEGIN_MSG_MAP(KYKYTurboMolecularPump, SerialDevice)
	SET_V( init, KYKYTurboMolecularPump)
END_MSG_MAP



