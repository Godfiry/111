#include "FunctionalModel.h"
#include "ModuleStatusEnum.h"

FunctionalModel::FunctionalModel()
{
	m_pModuleStatus=NULL;
	
	m_pModuleMessage=NULL;
	
	m_Init=new Init();
	m_Init->setOwner(this);
	
	m_InitMaintain=new InitMaintain();
	m_InitMaintain->setOwner(this);
	
	m_SetOpMode=new SetOpMode();
	m_SetOpMode->setOwner(this);
	
	m_Shutdown=new Shutdown();
	m_Shutdown->setOwner(this);
}

FunctionalModel::~FunctionalModel()
{
}

bool FunctionalModel::checkStatusEqual(int nMode)
{
	if(m_pModuleStatus->getValue() == nMode)
	{
		return true;
	}
	else
	{
		return false;
	}
}

int FunctionalModel::getStatusValue()
{
	return m_pModuleStatus->getValue();
}

string FunctionalModel::getStatusValueAsString(int nMode)//added by mujy [V1.0.0.3]
{
	string strStatusValue;
	switch(nMode)
	{
		case MODULE_STATUS::NotReady:
			strStatusValue = "NotReady";
			break;
		case MODULE_STATUS::Standby:
			strStatusValue = "Standby";
			break;
		case MODULE_STATUS::CTCInUse:
			strStatusValue = "CTCInUse";
			break;
		case MODULE_STATUS::MaintMode:
			strStatusValue = "MaintMode";
			break;
		case MODULE_STATUS::InfoIsNew:
			strStatusValue = "InfoIsNew";
			break;
		case MODULE_STATUS::Offline:
			strStatusValue = "Offline";
			break;
		case MODULE_STATUS::UnInit:
			strStatusValue = "UnInit";
			break;
		case MODULE_STATUS::MaintReq:
			strStatusValue = "MaintReq";
			break;
		case MODULE_STATUS::MaintPend:
			strStatusValue = "MaintPend";
			break;
		default:
			strStatusValue = "unknown";
	}
	return strStatusValue;
}

void FunctionalModel::setStatusValue(int nMode)
{
	Log_Info(getName()+" old module status to "+getStatusValueAsString(getStatusValue()));
	Log_Info(getName()+" set module status to "+getStatusValueAsString(nMode));
	m_pModuleStatus->setValue(nMode);
	Log_Info(getName()+" set module status end ");
}

void FunctionalModel::setMessage(string strMessage)
{
	m_pModuleMessage->setValue(strMessage);
}

void FunctionalModel::make()
{
	m_pModuleStatus=new ReadWriteInt(getName() + "/Status",IntTypeInfo(DescriptorList("InfoIsNew:-1,Offline,UnInit,NotReady,Standby,CTCInUse,MaintReq,MaintPend,MaintMode")));
	CTCExport::exportAsOthers(m_pModuleStatus,getSelfName()+"_Status");
	m_pModuleStatus->setValue(MODULE_STATUS::UnInit);
	
	m_pModuleMessage=new ReadWriteString(StringTypeInfo(200));
	CTCExport::exportAsOthers(m_pModuleMessage,getSelfName()+"_Message");
	m_pModuleMessage->setValue("UnInit");
}

void FunctionalModel::defaultAbort()
{
	Log_Info(getName()+": defaultAbort() start");
	ControlObject::defaultAbort();
	if(getStatusValue() != MODULE_STATUS::MaintMode)//mujy add
	{
		setStatusValue(MODULE_STATUS::NotReady);
	}
	m_pModuleMessage->setValue("Aborted");
	Log_Info(getName()+": defaultAbort() end");
}

void FunctionalModel::call_Init()
{
	call(m_Init);
}
void FunctionalModel::call_InitMaintain()
{
	call(m_InitMaintain);
}
void FunctionalModel::call_SetOpMode(int nMode)
{
	m_SetOpMode->setParamValue("mode",nMode);
	call(m_SetOpMode);
}

void FunctionalModel::call_Shutdown()
{
	call(m_Shutdown);
}

void FunctionalModel::do_Init()
{
	setStatusValue(MODULE_STATUS::Standby);
	m_pModuleMessage->setValue("Idle");
}
void FunctionalModel::do_InitMaintain()
{
	setStatusValue(MODULE_STATUS::MaintMode);
	m_pModuleMessage->setValue("Idle");
}

void FunctionalModel::do_SetOpMode(int nMode)
{
	if(getStatusValue()==nMode)
	{
		return;
	}
	setStatusValue(nMode);
}

void FunctionalModel::do_Shutdown()
{
	setStatusValue(MODULE_STATUS::UnInit);
	m_pModuleMessage->setValue("UnInit");
}

void FunctionalModel::Init::execute()
{
	FunctionalModel *pOwner = dynamic_cast<FunctionalModel*>(getOwner());
	if(pOwner != NULL)
	{
		Log_Info(pOwner->getName()+": do_Init start");
		pOwner->do_Init();
		Log_Info(pOwner->getName()+": do_Init end");
	}
}
void FunctionalModel::InitMaintain::execute()
{
	FunctionalModel *pOwner = dynamic_cast<FunctionalModel*>(getOwner());
	if(pOwner != NULL)
	{
		Log_Info(pOwner->getName()+": do_InitMaintain start");
		pOwner->do_InitMaintain();
		Log_Info(pOwner->getName()+": do_InitMaintain end");
	}
}
void FunctionalModel::SetOpMode::execute()
{
	FunctionalModel *pOwner = dynamic_cast<FunctionalModel*>(getOwner());
	if(pOwner != NULL)
	{
		int nMode = Params["mode"].Int;
		Log_Info(pOwner->getName()+": do_SetOpMode start - nMode = "+pOwner->getStatusValueAsString(nMode));	
		pOwner->do_SetOpMode(nMode);	
		Log_Info(pOwner->getName()+": do_SetOpMode end");
	}
}

void FunctionalModel::Shutdown::execute()
{
	FunctionalModel *pOwner = dynamic_cast<FunctionalModel*>(getOwner());
	if(pOwner != NULL)
	{
		Log_Info(pOwner->getName()+": do_Shutdown start");
	
		pOwner->do_Shutdown();
		
		Log_Info(pOwner->getName()+": do_Shutdown end");
	}
}

IMPLEMENT_DYNAMIC_SERVICE(Init, FunctionalModel)
IMPLEMENT_DYNAMIC_SERVICE(InitMaintain, FunctionalModel)
IMPLEMENT_DYNAMIC_SERVICE(SetOpMode, FunctionalModel)
IMPLEMENT_DYNAMIC_SERVICE(Shutdown, FunctionalModel)

BEGIN_SERVICEINFO_LIST(FunctionalModel)

	ADD_SERVICE_INFO(FunctionalModel, Init, The Init service )
	ADD_SERVICE_INFO(FunctionalModel, InitMaintain, The InitMaintain service )
		
	ADD_SERVICE_INFO(FunctionalModel, SetOpMode, The SetOpMode service )
		ADD_PARAM_INFO(FunctionalModel, SetOpMode, mode, int, InfoIsNew:-1 Offline UnInit NotReady Standby CTCInUse MaintPend MaintMode)
		
	ADD_SERVICE_INFO(FunctionalModel, Shutdown, The Shutdown service )
		
END_SERVICEINFO_LIST(FunctionalModel)

IMPLEMENT_DYNAMIC(FunctionalModel, ControlObjectEX)

BEGIN_MSG_MAP( FunctionalModel, ControlObjectEX )
END_MSG_MAP
