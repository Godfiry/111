/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: COMETPulseMatchDriver.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					
**                   2015-03-31   bihuijie	create
*********************************************************************/
#include "COMETPulseMatchDriver.h"
#include "DeviceManager.h"

#include "IStringList.h"
#include <iostream>
#include <string.h>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std; 

COMETPulseMatchDriver::ParamPair COMETPulseMatchDriver::m_paramPairs[] = {ParamPair("manaut",DescriptorList("3,1"))};//0="3"="manual" 1="1"="auto"										 
map<string,DescriptorList> COMETPulseMatchDriver::m_params = map<string,DescriptorList>(m_paramPairs, m_paramPairs+1);

COMETPulseMatchDriver::Com COMETPulseMatchDriver::m_commands[] = {{0, ""}, //0	reserved 						
											{0, "SM", 0},//1 (CH,value)manual
											{0, "SA", 0},//2 auto
											{0, "Rest", 0},//3 fault reset		
											{2, "SP",0},  //4 save preset
											{2, "G",0},  //5 goto preset															
											{1, "Load", 0},//6 set c1
											{1, "Tune", 0},//7 set c2			
											{1, "QMode", 1},//8 get Manual/Auto
											{1, "QA", 1},//9 get c1
											{1, "QB", 1},//10 get c2
											{4, "QP001", 1},//11 get preset c1
											{4, "QP001", 2},//12 get preset c2
											{1, "QV", 0},//13 get vpp
											{0, "Zload",0},//14 get zload
											{4, "QAux",0}}; //15 get vpp new command for match update

COMETPulseMatchDriver::COMETPulseMatchDriver()
{
}

COMETPulseMatchDriver::~COMETPulseMatchDriver()
{
}

bool COMETPulseMatchDriver::writeInt(int channelNum, int value, const IntTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	int ps = com.m_ps;
	string msg = "";
	char format[5]={0};	
	double t_c = 0.0;
	switch(ps)
	{
		case 0:
			//msg = com.m_s1;
			msg = m_commands[channelNum + value].m_s1;
			break;
			
		case 1:
			t_c = value / 10.0;		
			sprintf(format,"%04.1f",t_c);
			msg = com.m_s1 + format;
			break;
			
	    case 2:
		   msg = com.m_s1 + "00" + Converter::convertToString(value);
		   break;
	  
	}
	return sendCommand(msg, m_timeOut);
}
		
bool COMETPulseMatchDriver::writeRawCommand(int channelNum, std::string value, const StringTypeInfo &typeInfo)
{
	return sendCommand(value, m_timeOut);
}
		
bool COMETPulseMatchDriver::readInt(int channelNum, int *value, const IntTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	string res = readCommand(com.m_s1, m_timeOut);
      //  cout<<"command "<<com.m_s1<<endl;
      //  cout<<"res "<<res<<endl;
	std::vector<std::string> t_vlist = IStringList::split(res, ",");
       // cout<<"listsize "<<t_vlist.size()<<endl;
	if(t_vlist.size() != com.m_ps)
	{
		throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for response ["+Hex::GetHexString(res.c_str(),res.size())+"] is invalid.");
	}
	
	if(t_vlist.size() == 20)
	{
		string t_svalue = t_vlist[com.m_ps2 -1];
		*value = m_params["manaut"].getDescriptorValue(t_svalue);	
	}
	if(t_vlist.size() == 4)
	{
		string t_svalue = t_vlist[com.m_ps2 -1];
		double t_dvalue = 0;
		if(!Converter::stringToDouble(t_dvalue, t_svalue))
		{
			throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for can't convert response ["+t_svalue+"] to double value.");
		}
		*value = (int)(t_dvalue * 10);
	}
	if(t_vlist.size() == 2)
	{
		string t_svalue = t_vlist[com.m_ps2 -1];
		double t_dvalue = 0;
		if(!Converter::stringToDouble(t_dvalue, t_svalue))
		{
			throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for can't convert response ["+t_svalue+"] to double value.");
		}
		*value = (int)(t_dvalue * 10);
	}
	if(t_vlist.size() == 1)
	{
		string t_svalue = t_vlist[0];		
                if(channelNum == 8)
                { 
                     int t_dvalue = 0;
                     if(!Converter::stringToInt(t_dvalue, t_svalue))
		     {
			throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for can't convert response ["+t_svalue+"] to integer value.");
		     }
		     if(t_dvalue ==3)
                     {
                        *value = 1;
                     } 
                     if(t_dvalue ==4)
                     {
                        *value = 0;
                     } 
                }
                if(channelNum == 9 || channelNum == 10)
                {
                    double t_dvalue = 0;
                    if(!Converter::stringToDouble(t_dvalue, t_svalue))
		    {
			throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for can't convert response ["+t_svalue+"] to double value.");
		    }
		   *value =(int)(t_dvalue *10);
                }
	}
	
	return true;
}

bool COMETPulseMatchDriver::readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	string res = readCommand(com.m_s1, m_timeOut);
        //cout<<"command "<<com.m_s1<<endl;
       // cout<<"res "<<res<<endl;
	std::vector<std::string> t_vlist = IStringList::split(res, ",");
       // cout<<"listsize "<<t_vlist.size()<<endl;
	if(t_vlist.size() != com.m_ps)
	{
		throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for response ["+Hex::GetHexString(res.c_str(),res.size())+"] is invalid.");
	}
	double t_dvalue = 0;
	if(t_vlist.size() == 1 || t_vlist.size() == 4)
	{
		string t_svalue = t_vlist[0];		
            
        if(!Converter::stringToDouble(t_dvalue, t_svalue))
	    {
				throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for can't convert response ["+t_svalue+"] to double value.");
	    }
	    *value =t_dvalue/2;
               
	}
	
	return true;
}

bool COMETPulseMatchDriver::readString(int channelNum, std::string *value, const StringTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	string res = readCommand(com.m_s1, m_timeOut);
	*value = res;
	return true;
}

void COMETPulseMatchDriver::initChs(DeviceNode<COMETPulseMatchDriver> *node)
{
	node->registerWriteCh(0, &COMETPulseMatchDriver::writeRawCommand);

   for(int i = 1; i <= 7; ++i)
	{
		node->registerWriteCh(i, &COMETPulseMatchDriver::writeInt);
	}
	for(int i = 8; i <= 12; ++i)
	{
		node->registerReadCh(i, &COMETPulseMatchDriver::readInt);
	}	
	
	node->registerReadCh(13, &COMETPulseMatchDriver::readDouble);
	node->registerReadCh(14, &COMETPulseMatchDriver::readString);
	node->registerReadCh(15, &COMETPulseMatchDriver::readDouble);
	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &COMETPulseMatchDriver::getStatus);//added by mujy [v1.0.8]
}



void COMETPulseMatchDriver::initDevice()
{
	cout<<"Start Scan COMET Pulse Match...."<<endl;
	//say hello to match
	int nTemp;
	try
	{
		readInt(9,&nTemp,IntTypeInfo()); //read C1
	}
	catch(exception &ex)
	{
		cout<<"Scan COMET Pulse Match first failed. Try again!"<<endl;
	}
	try
	{
		readInt(9,&nTemp,IntTypeInfo()); //read C1
	}
	catch(exception &ex)
	{
		cout<<"Scan COMET Pulse Match failed. Communication abnormal!"<<endl;
		throw;
	}
	
	cout<<"Scan COMET Pulse Match Successfully...."<<endl;
}
		
void COMETPulseMatchDriver::init()
{
	DeviceNode<COMETPulseMatchDriver> *node = new DeviceNode<COMETPulseMatchDriver>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	if(!isSimulated())
	{
		initChs(node);		
		initDevice();
	}
}

IMPLEMENT_DYNAMIC(COMETPulseMatchDriver, COMETMatchDriver )
BEGIN_MSG_MAP(COMETPulseMatchDriver, COMETMatchDriver )
    SET_V( init, COMETPulseMatchDriver )
END_MSG_MAP

