/******************************************************************************
 * Copyrigh (C) 2010 by NMC
 *
 * File: DMC10D.h
 *
 * Date: 2008-05-14
 *
 * Author: GaoJianQiang <gaojq@bj-nmc.local>
 *
 * Version: 0.1
 *
 * Descriptor:
 *   RS-485 Driver for the DMC10D  Temperature Controller
 *
 * Modified:
 *
 ******************************************************************************/

#ifndef _DMC10D_H
#define _DMC10D_H

#include "SerialDevice.h"
#include "DeviceNode.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class DMC10D : public SerialDevice
{
    DECLARE_DYNAMIC(DMC10D)	
    DECLARE_MSG_MAP

private:
    static const int MAX_MESSAGE_LEN = 80;
    static const int OFFLINE = 0;
    static const int ONLINE = 1;
    static const int READ = 0;
    static const int WRITE = 1;
    static const int write_message_length = 23;  /* message length for transmiting the message */
    static const int read_message_length = 21;
    static const int receive_message_length = 16;  /* message length for receiving the message */

    int status_channel;
    int alarm_channel;
    bool isSet;
    
    int	DMC10checkSum( char * cCommand, int nLen );
    void SetCommand( char * cCommand, int  nCmdLen );
    void ComposeMessage(int flag, int index, double value, char *buff);
    void ComposeInputTypeMessage(int flag,int nChanNum, int nType, char *buff);
    void ComposePointMessage(int flag,int nChanNum, int decPoint, char *buff);
    void ComposeTurnMessage(int flag,int nChanNum, int mode,char *buff);
    void ComposeModeMessage(int flag,int nChanNum, int mode,char *buff);
    bool SendMsg(char * Message, char * Response, int msg_type);
    
		
public:
    DMC10D();
    virtual ~DMC10D();
    void init();
    void initDMC10Config();
    void InitDMC10D();
    void InitChannels(DeviceNode<DMC10D> *node);
    void setParam(bool IsSet);
    
    bool WriteCt(int channnelNum, double setpt ,const DoubleTypeInfo& typeinfo);
    bool ReadCt(int channelNum, double *value ,const DoubleTypeInfo& typeinfo);
    bool ReadADt(int channelNum, int *value ,const IntTypeInfo& typeinfo);
	bool ReadStatus(int channelNum, int *value ,const IntTypeInfo& typeinfo);
};


#endif /* _DMC10D_H */

