/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AEGeneratorDriver.h
** Description: AE Paramount Generator:13.56MHz
*                RS232
* 				   BaudRate:19200
*                DataBit:8
*                StopBit:1
*                Parity:Odd  
** Release: 1.1
** Modification history: 
** 					2014-12-10   bihuijie create
**      
*********************************************************************/
#ifndef AEGENERATORDRIVER_H_
#define AEGENERATORDRIVER_H_
#include "SerialDevice.h"
#include "DeviceNode.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class AEGeneratorDriver : public SerialDevice
{
    DECLARE_DYNAMIC(AEGeneratorDriver)	
    DECLARE_MSG_MAP

private:
    typedef struct
	 {
		int m_type;
		unsigned char m_cmd;   //changed by wzd 1.1.39
		int m_relen;
	 }Com;
	 static Com m_commands[];	 
    static const int RESP_LEN = 8;
    static const int MESS_LEN = 10;

    char message[MESS_LEN];
    char resp[RESP_LEN];
    char ack[1];
    bool sendCommand(char *msg,char *response, int l_msg_timeout,int length);
    bool sendCommandAck(char *msg,char *response, int msg_timeout,int resplen,int msglen);
    bool readCommand(char *msg,char *response, int msg_timeout,int resplen,int msglen);
		 
public:
    AEGeneratorDriver();
    virtual ~AEGeneratorDriver();
    void init();
    void InitChannels(DeviceNode<AEGeneratorDriver> *node);   
    bool writeInt(int channel,int value,const IntTypeInfo& typeinfo);
    bool writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo);
    bool readInt(int channel,int *value,const IntTypeInfo& typeinfo);
    bool readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo);		
    bool writePosition(int channelNum, double value, const DoubleTypeInfo &typeInfo);
    bool readPosition(int channelNum, double *value, const DoubleTypeInfo &typeInfo);	
    bool writeForwardLoad(int channel,int value,const IntTypeInfo& typeinfo);
};
#endif /*AEGENERATORDRIVER_H_*/
