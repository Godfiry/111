/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .cpp
** Description: 
** Release: 
** Modification history: 
** 					Feb 22, 2008  shenql  create 
**      
***************************************************************************/

#include "OperationalPecvdProcess.h"

#include "SysLogger.h"
#include "Converter.h"
#include "Recovery.h"
#include "Parameter.h"
#include "ObjectManager.h"
#include "PMAnmInfo.h"
#include "PMStateInfo.h"
#include "PMStatusInfo.h"
#include "RecipeTimeInfo.h"
#include "LotIdInfo.h"
#include "RecipeNameInfo.h"
#include "ConfigException.h"
#include "DefaultAction.h"
#include "DefaultValue.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "InvalidNameException.h"
#include "RetryException.h"
#endif

#include "IThread.h"
#include "ModuleStatusEnum.h"
#include "SlotIdInfo.h"
#include "CTCExport.h"
#include "RecipeNameInfo.h"
#include "YesNoInfo.h"
#include "StepNumInfo.h"
#include "AlarmCounter.h"
#include "AlarmReNameManager.h"
#include "StrTool.h"
#include <float.h>
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::ALARM;
using namespace IAP::RECIPE;
using namespace IAP::INTERLOCK;
using namespace IAP;
#endif
using namespace std;

OperationalPecvdProcess::OperationalPecvdProcess()
{
    m_pFuncTotalCycleProcess = NULL;

    m_sTotalCycleProcess = new TotalCycleProcess;
    m_sTotalCycleProcess->setOwner(this);
}

OperationalPecvdProcess::~OperationalPecvdProcess()
{
}


void OperationalPecvdProcess::TotalCycleProcess::execute()
{
    ControlObject *owner = getOwner();
    if (owner != NULL)
    {
        (static_cast<OperationalPecvdProcess*>(owner))->do_TotalCycleProcess(Params["RecipeName"].Str,Params["nCycle"].Int);
    }
}



bool OperationalPecvdProcess::do_TotalCycleProcess(const std::string &RecipeName,int nCycle)
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName()+" OperationalPecvdProcess:: start do_TotalCycleProcess: " + RecipeName+", cycle is "+Converter::convertToString(nCycle));

    //do_PrepChamb(1);


    if(RecipeName != "")
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName()+" OperationalPecvdProcess:: start do_Process: " + RecipeName);
        string t_rcpName = RecipeName;
        AppRecipeManager::getInstance()->releaseRecipe(RecipeName);//modify by taohao[v1.5.0_HotFix2] for obtain the recipe from the memory

        try
        {
            do_Prepare(RecipeName);
            double dTotalProcessTime = calculateProcessTime() * nCycle;
            m_pElapsedProcessTime->setValue(0);
            m_pProcessTime->setValue(dTotalProcessTime);
            m_pMaxProcessTime->setValue(dTotalProcessTime+m_pMaxProcessTimeTolerance->getValue());
            m_pRecipeTimeLeft->setValue(dTotalProcessTime);
            AppRecipeManager::getInstance()->releaseRecipe(RecipeName);//modify by taohao[v1.5.0_HotFix2] for obtain the recipe from the memory
            m_pSlotSts->setValue(3);//change for code merging
            m_pSlotAnm->setValue(3);//change for code merging
            m_pFuncTotalCycleProcess->call_CycleProcessMaterial(RecipeName,nCycle);
        }
        catch(const RetryException &ex)
        {
            throw;
        }
        catch(const exception &ex)
        {
            AppRecipeManager::getInstance()->releaseRecipe(RecipeName);//modify by taohao[v1.5.0_HotFix2] for obtain the recipe from the memory
            //clearRecipeInfo();
            m_pProcessModule->changeModuleStatus(MODULE_STATUS::NotReady);
            m_pSlotAnm->setValue(PMAnmInfo::Aborted);
            m_pSlotSts->setValue(PMStatusInfo::Aborted);
            m_pSlotState->setValue(PMStateInfo::NotRd);
            Log_Error( "OperationalPecvdProcess:: failed in processing recipe for " + string(ex.what()) );
            throw AbortException(ex.what());
        }
        m_pSlotSts->setValue(PMStatusInfo::Processed);
        m_pSlotAnm->setValue(PMAnmInfo::Processed);
        m_pSlotState->setValue(PMStateInfo::Rd4Next);
        Log_Info( "OperationalPecvdProcess:: finish processing recipe ");
        return true;

        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName()+" OperationalPecvdProcess:: end do_Process: " + RecipeName);
    }

    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName()+" OperationalPecvdProcess:: end do_TotalCycleProcess: " + RecipeName+", cycle is "+Converter::convertToString(nCycle));
    return true;
}



void OperationalPecvdProcess::setTheProcessStr(std::string &strPath)
{
    ManagedObject *p = NULL;

    try
    {
        p = ObjectManager::getInstance()->getObject(strPath);    
    }
    catch (const InvalidNameException &e)
    {
        p = ObjectManager::getInstance()->getObject(this, strPath);
    }
    m_pFuncProcess = dynamic_cast<FunctionalProcessInterface*>(p);
    m_pFuncTotalCycleProcess = dynamic_cast<FunctionalPM*>(p);
    if (m_pFuncProcess == NULL)
    {
        throw ConfigException("The object under path " + strPath + " is not the class expected.");
    }
    
    if (m_pFuncTotalCycleProcess == NULL)
    {
        throw ConfigException("The object under path " + strPath + " is not the class expected FunctionalPM.");
    }

}


IMPLEMENT_DYNAMIC_SERVICE(TotalCycleProcess, OperationalPecvdProcess)
BEGIN_SERVICEINFO_LIST(OperationalPecvdProcess)
    ADD_SERVICE_INFO(OperationalPecvdProcess, TotalCycleProcess, Cycle Recipe process )
            ADD_PARAM_INFO(OperationalPecvdProcess, TotalCycleProcess, RecipeName, string, the recipe to cycle process)
            ADD_PARAM_INFO(OperationalPecvdProcess, TotalCycleProcess, nCycle, int, the cycle num to cycle process )
END_SERVICEINFO_LIST(OperationalPecvdProcess)

// control objects
IMPLEMENT_DYNAMIC(OperationalPecvdProcess, OperationalProcess)

BEGIN_MSG_MAP( OperationalPecvdProcess, OperationalProcess )
    SET_S(setTheProcessStr, OperationalPecvdProcess)
END_MSG_MAP
