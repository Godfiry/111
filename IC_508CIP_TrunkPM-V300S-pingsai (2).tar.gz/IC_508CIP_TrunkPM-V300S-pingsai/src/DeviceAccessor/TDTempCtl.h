/*
 * TDTempCtl.h
 *
 *  Created on: 2023-9-25
 *      Author: taohao
 */

/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TDTempCtl.h
** Description:
** Release: 1.1
** Modification history:
**                     2023-02-05  SYD create
**
*********************************************************************/
#ifndef TDTEMPCTL_H_
#define TDTEMPCTL_H_

#include "DeviceNode.h"
#include "SerialDevice.h"
#include "string.h"
#include <map>
#include "MonitorDoubleValue.h" //added by mujy 20250602 for TempCtl Protect CIP
#ifdef IAP4_0
using namespace IAP::IO;
#endif

#define MONITORDOUBLEVALUEADDMAP 200//added by mujy 20250602 for TempCtl Protect CIP

class TDTempCtl : public SerialDevice,public CMonitorDoubleValue
{
    DECLARE_DYNAMIC(TDTempCtl)
    DECLARE_MSG_MAP

private:
    struct CalibrationPar
    {
        //int m_nChannelNum;
        string m_tempCalibrationA;//offsetA
        string m_tempCalibrationB;//offsetB
    };

    map<int, CalibrationPar*> m_pCalibrationPar;

    static const int MAX_MESSAGE_LEN = 20;
    static const int MIN_RECEIVEMSG_LEN = 20;
    static const unsigned char wrAddr [10];

    char writeArray[8];
    char readArray[8];

    static const int RESP_LEN = 80;//the buff length

    map<int, double> m_pHeatPowerPar;//added by guojin[20250515][1.4.0]for current operation

protected:

    void initChs(DeviceNode<TDTempCtl> *node);//inint channel
    void initDevice();

    double calculateReadCarTemp(int nChannelNum, double value);
    double calculateWriteCarTemp(int nChannelNum, double value);
    void setCalibrationInitChannel(int nChannelNum );//[1.1.65 taohao]

public:
    TDTempCtl();
    virtual ~TDTempCtl();
    void init();
    bool writeDouble(int channnelNum,double setpt ,const DoubleTypeInfo& typeinfo);
    bool readDouble(int channnelNum,double * value ,const DoubleTypeInfo& typeinfo);
    bool writeInt(int channelNum, int mode, const IntTypeInfo& typeinfo);
    unsigned short calculateCRC(char* buffer,int len);
    void differTDTempDifferMachineCh(int channelNum);
    static void convertDecToHex(int d,char *result);
    void addCalibrationPar(int nChannelNum,std::string cfgtempCalibrationA, std::string cfgtempCalibrationB);

    int m_nCalibrationInitChannel;//[1.1.65 taohao]

    void addHeatPowerPar(int nChannelNum,double dPower);//added by guojin[20250515][1.4.0]for current operation

};

#endif /*TDTempCtl_H_*/
