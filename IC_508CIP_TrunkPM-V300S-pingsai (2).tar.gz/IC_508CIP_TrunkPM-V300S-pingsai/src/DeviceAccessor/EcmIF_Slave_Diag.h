/**************************************************************************************
 Copyright (c) Hilscher Gesellschaft fuer Systemautomation mbH. All Rights Reserved.
***************************************************************************************
$Id: EcmIF_Slave_Diag.h 58639 2016-01-15 11:41:24Z Sven $:


Changes:
 Date          Description
 -----------------------------------------------------------------------------------
 yyyy-mm-dd    created
**************************************************************************************/

#ifndef __STRUCT_ETHERCAT_MASTER_DIAG_GET_SLAVE_DIAG_T__
#define __STRUCT_ETHERCAT_MASTER_DIAG_GET_SLAVE_DIAG_T__

typedef __PACKED_PRE struct ETHERCAT_MASTER_DIAG_GET_SLAVE_DIAG_Ttag
{
  uint32_t ulStationAddress;
  uint32_t ulAutoIncAddress;
  uint32_t ulCurrentState;
  uint32_t ulLastError;
  TLR_STR  szSlaveName[80];
  uint32_t fEmergencyReported;
} __PACKED_POST ETHERCAT_MASTER_DIAG_GET_SLAVE_DIAG_T;

#endif
