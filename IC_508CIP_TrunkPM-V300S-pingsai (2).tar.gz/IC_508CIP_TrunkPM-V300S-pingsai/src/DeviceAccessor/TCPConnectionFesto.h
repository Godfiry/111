/*
 * TCPConnectionFesto.h
 *
 *  Created on: Jun 4, 2021
 *      Author: zhangyy
 */

#ifndef TCPCONNECTIONFESTO_H_
#define TCPCONNECTIONFESTO_H_

#include <string>
#include "IThread.h"
#include "IMutex.h"
#include <unistd.h>  //add by wzd 1.1.39
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

class TCPDeviceFesto;
class TCPSocket;

class TCPConnectionFesto:public IThread
{
	private:
		class ReconnectMonitor:public IThread
		{
			private:
				TCPConnectionFesto *m_connection;

			public:
				ReconnectMonitor(TCPConnectionFesto *owner);

				virtual void run();
		};


	private:
		static const int s_CLOSED = 0;
		static const int s_CONNECTED = 1;
		static const int s_CONNECTING = 2;
		static const int s_CLOSING = 3;
		static const int s_ERROR = 4;
		TCPSocket *m_socket;
		TCPDeviceFesto *m_device;
		int m_state;
		bool m_running;
		int m_timeout;
		IMutex m_lock;
		ReconnectMonitor *m_reconnectMonitor;

		void changeState(int newstat);
		void reconnect();
		void reconnectSocket();
		void reconnectDevice();
		void close();


	public:
		TCPConnectionFesto(const std::string &server, std::string port);
		virtual ~TCPConnectionFesto();

		void connect();
		void disconnect();
		void setDevice(TCPDeviceFesto *device);
		void sendData(const char *data, int size);
		bool isConnected()const;
		virtual void run();
		bool recvFixLenData(char *buffer, int len);
		bool recvData(char *buffer, int len);
		void setTimeOut(int timeout);
};



#endif /* TCPCONNECTIONFESTO_H_ */
