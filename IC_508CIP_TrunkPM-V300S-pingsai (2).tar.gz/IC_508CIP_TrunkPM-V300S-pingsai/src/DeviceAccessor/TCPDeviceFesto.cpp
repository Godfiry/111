/*
 * TCPDeviceFesto.cpp
 *
 *  Created on: Jun 4, 2021
 *      Author: zhangyy
 */

#include "TCPDeviceFesto.h"
#include "TCPConnectionFesto.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#include <string.h>
#ifdef IAP4_0
using namespace IAP;
#endif
using namespace std;

TCPDeviceFesto::TCPDeviceFesto()
{
	m_connection = NULL;
	m_server = "";
	m_port = "";
	m_nodeNum = -1;
	m_pollInterval = 200;//ms
	m_timeOut = 10;//s
	m_checkInterval = 100;//ms
	m_connected = false;
	m_running = true;
	memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
}

TCPDeviceFesto::~TCPDeviceFesto()
{
	m_running = false;
	if(m_connection != NULL)
	{
		m_connection->disconnect();
		delete m_connection;
		m_connection = NULL;//mujy added 20160616[v1.0.16]

	}
}

void TCPDeviceFesto::setServer(const std::string &server)
{
	m_server = server;
}

void TCPDeviceFesto::setPort(const string &port)
{
	m_port = port;
}

void TCPDeviceFesto::sendData(const char *data, int size)
{
	try
	{
		m_connection->sendData(data, size);
	}
	catch(const exception &ex)
	{
		setDeviceConnected(false);
		throw;
	}
}

void TCPDeviceFesto::setNodeNum(int nodeNum)
{
	m_nodeNum = nodeNum;
}

void TCPDeviceFesto::setPollIntervalMS(int interval)
{
	m_pollInterval = interval;
}

void TCPDeviceFesto::setTimeOutS(int timeOut)
{
	m_timeOut = timeOut;
}

void TCPDeviceFesto::init()
{
	m_connection = new TCPConnectionFesto(m_server, m_port);
	m_connection->setDevice(this);
	m_connection->connect();
	setDeviceConnected(true);
}

bool TCPDeviceFesto::isConnected()const
{
	return m_connection->isConnected() && m_connected;
}

void TCPDeviceFesto::setDeviceConnected(bool flag)
{
	m_connected = flag;
}

bool TCPDeviceFesto::reconnectDevice()
{
	setDeviceConnected(true);
	return true;
}

void TCPDeviceFesto::readInput()
{

}

void TCPDeviceFesto::writeOutput()
{

}

void TCPDeviceFesto::executePositionRecord()
{

}
void TCPDeviceFesto::updateModbusTimeOut()
{

}

bool TCPDeviceFesto::readData(char *buffer, int len)
{
	if(!m_connection->recvData(buffer, len))
	{
		setDeviceConnected(false);
		return false;
	}
	else
	{
		return true;
	}
}

bool TCPDeviceFesto::readFixLenData(char *buffer, int len)
{
	if(!m_connection->recvFixLenData(buffer, len))
	{
		setDeviceConnected(false);
		return false;
	}
	else
	{
		return true;
	}
}

std::string TCPDeviceFesto::getDeviceName()
{
	return "Unknown";
}

IMPLEMENT_JOINT(TCPDeviceFesto, AbstractDevice)
BEGIN_MSG_MAP( TCPDeviceFesto, AbstractDevice)
	SET_S( setServer, TCPDeviceFesto )
	SET_S( setPort, TCPDeviceFesto )
	SET_I( setNodeNum, TCPDeviceFesto )
	SET_I( setPollIntervalMS, TCPDeviceFesto )
	SET_I( setTimeOutS, TCPDeviceFesto )
	SET_V( init, TCPDeviceFesto )
END_MSG_MAP
