/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: ConfigException.h
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-03-04  LiJuanjuan create
**      
*********************************************************************/
#ifndef CONFIGEXCEPTION_H_
#define CONFIGEXCEPTION_H_

#include "TMCException.h"

class ConfigException:public TMCException
{
	public:
		ConfigException(const std::string &s);
};

#endif /*CONFIGEXCEPTION_H_*/
