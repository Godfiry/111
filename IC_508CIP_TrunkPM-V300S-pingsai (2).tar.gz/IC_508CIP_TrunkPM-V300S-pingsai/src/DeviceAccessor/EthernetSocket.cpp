/********************************************************************
** Copyright (c) 2012, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: EthernetSocket.cpp
** Description:
** Modification history: 2012-04-16 Liwen created.
**      
*********************************************************************/

#include <iostream>
#include <string.h>

#include <sys/socket.h>      //for socket
#include <sys/select.h>     //for select
#include <sys/types.h>     //for socket
#include <errno.h>        //for error
#include <arpa/inet.h>   //for inet_addr
#include "ConfigException.h"
#include <netdb.h> 
#include <netinet/tcp.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "EthernetSocket.h"

using namespace std;
//using namespace MEC;


EthernetSocket::EthernetSocket(const string serverIP, unsigned long serverPort)
{
    m_serverIP = serverIP;
    m_serverPort = serverPort;
    m_sockfd = -1;
    m_connected = false;
    m_revTimeOut= 30;
	m_sndTimeOut = 30;
}

EthernetSocket::~EthernetSocket()
{
	#ifdef SUSE
    ::pclose(m_sockfd);
	#else
	::close(m_sockfd);	
	#endif
    m_connected = false;
}

void EthernetSocket::connect()
{
    if ((m_sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        throw string("EthernetSocket::connect(): Create TCP Socket failed!");
    }
    
    bzero(&m_clientAddr, sizeof(m_clientAddr));
    m_clientAddr.sin_family = AF_INET;
    m_clientAddr.sin_addr.s_addr = htons(INADDR_ANY);
    m_clientAddr.sin_port = htons(0);
    
    struct timeval t_timeout;
    //t_timeout.tv_sec = m_revTimeOut;
    t_timeout.tv_sec = 30;
    t_timeout.tv_usec = 0;
    if(setsockopt(m_sockfd, SOL_SOCKET, SO_RCVTIMEO, &t_timeout, sizeof(t_timeout)) != 0)
    {
       throw string("EthernetSocket::connect(): set socket SO_RCVTIMEO option failed!");
    }
    
    t_timeout.tv_sec = 30;
    t_timeout.tv_usec = 0;  
    if(setsockopt(m_sockfd, SOL_SOCKET, SO_SNDTIMEO, &t_timeout, sizeof(t_timeout)) != 0)
    {
        throw string("EthernetSocket::connect(): set socket SO_SNDTIMEO option failed!");
    }
    
    if (::bind(m_sockfd, (struct sockaddr*)&m_clientAddr, sizeof(m_clientAddr)) < 0)
    {
        throw string("EthernetSocket::connect(): Bind local address failed!");
    }
    
    bzero(&m_serverAddr, sizeof(m_serverAddr));
    m_serverAddr.sin_family = AF_INET;
    m_serverAddr.sin_addr.s_addr = inet_addr(m_serverIP.c_str());
    m_serverAddr.sin_port = htons(m_serverPort);
    
    if (::connect(m_sockfd, (struct sockaddr*)&m_serverAddr, sizeof(m_serverAddr)) != 0)
    {//cout<<"errno:"<<errno<<endl;
        throw string("EthernetSocket::connect(): Connect with TCP server '"+m_serverIP+"' failed! ");
    }
    
    struct timeval t_timeoutForSendOrRev;
    t_timeoutForSendOrRev.tv_sec = m_revTimeOut;
    //t_timeoutForSendOrRev.tv_sec = 60;
    t_timeoutForSendOrRev.tv_usec = 0;
    if(setsockopt(m_sockfd, SOL_SOCKET, SO_RCVTIMEO, &t_timeoutForSendOrRev, sizeof(t_timeoutForSendOrRev)) != 0)
    {
       throw string("EthernetSocket::connect(): set socket SO_RCVTIMEO option failed!");
    }
    
//    t_timeoutForSendOrRev.tv_sec = m_sndTimeOut;
    t_timeoutForSendOrRev.tv_sec = 60;
    t_timeoutForSendOrRev.tv_usec = 0;  
    if(setsockopt(m_sockfd, SOL_SOCKET, SO_SNDTIMEO, &t_timeoutForSendOrRev, sizeof(t_timeoutForSendOrRev)) != 0)
    {
        throw string("EthernetSocket::connect(): set socket SO_SNDTIMEO option failed!");
    }
// heart check
	int keepalive=1;
	int keepidle=60;
	int keepinterval=5;
	int keepcount=3;
    	if(setsockopt(m_sockfd,SOL_SOCKET,SO_KEEPALIVE,(void *)&keepalive,sizeof(keepalive))==-1)
	{
		::close(m_sockfd);
		throw ConfigException("EthernetSocket::set socket KEEPALIVE option failed");
	}
	if(setsockopt(m_sockfd,SOL_TCP,TCP_KEEPIDLE,(void *)&keepidle,sizeof(keepidle))==-1)
	{
		::close(m_sockfd);
		throw ConfigException("EthernetSocket::set socket KEEPIDLE option failed");
	}
	if(setsockopt(m_sockfd,SOL_TCP,TCP_KEEPINTVL,(void *)&keepinterval,sizeof(keepinterval))==-1)
	{
		::close(m_sockfd);
		throw ConfigException("EthernetSocket::set socket KEEPINTVL option failed");
	}
	if(setsockopt(m_sockfd,SOL_TCP,TCP_KEEPCNT,(void *)&keepcount,sizeof(keepcount))<0)
	{
		::close(m_sockfd);
		throw ConfigException("EthernetSocket::set socket KEEPCNT option failed");
	}	
}

int EthernetSocket::send(const char *buffer, int len)
{
    return ::send(m_sockfd, buffer, len, 0);
}

int EthernetSocket::receive(char *buffer, int len)
{
    return ::recv(m_sockfd, buffer, len, 0);
}

int EthernetSocket::receiveByLen(char *buffer, int len)
{
	return ::recv(m_sockfd, buffer, len, MSG_WAITALL);
}

int EthernetSocket::select()
{
    int t_select;
    while(true)
    {
        fd_set t_rdset;
        FD_ZERO(&t_rdset);
        FD_SET(m_sockfd, &t_rdset);
        struct timeval tv;
        tv.tv_sec = 60;
        //tv.tv_usec = 500;
        t_select = ::select(m_sockfd+1, &t_rdset, NULL, NULL, &tv);     
        if(t_select == -1)
        {
            if(errno == EINTR)
            {
                continue;
            }
        }
        return t_select;
    }
}
/*bool EthernetSocket::SocketSelect()
{
    int t_select;
    while(true)
    {
        fd_set t_rdset;
        FD_ZERO(&t_rdset);
        FD_SET(t_select, &t_rdset);
        struct timeval tv;
        tv.tv_sec = 60;
        //tv.tv_usec = 500;
      //  t_select = ::select(m_sockfd+1, &t_rdset, NULL, NULL, &tv);     
        switch(select(t_select+1, &t_rdset, NULL, NULL, &tv))
			{
				case -1:
						return false;
				case  0:
						break;
				default:
						if(FD_ISSET(t_select,&t_rdset))//测试sock是否可读，即网络上是否有数据
						{
							return true;
						}
						continue;
						
			}
    }
}
*/
int EthernetSocket::close()
{
    return ::close(m_sockfd);
}

void EthernetSocket::reconnect()
{
	::close(m_sockfd);
	sleep(2);
    connect();
}

void EthernetSocket::setRcvTimeOut(int timeout)
{
    m_revTimeOut = timeout;
}

void EthernetSocket::setSndTimeOut(int timeout)
{
    m_sndTimeOut = timeout;
}

std::string EthernetSocket::getErrnoDescription()const
{
	return string(strerror(errno));
}

int EthernetSocket::getErrno()const
{
	return errno;
}

bool EthernetSocket::isConnected()
{
	if(m_sockfd < 0)
	{
		return false;
	}
	struct tcp_info info;
	int len = sizeof(struct tcp_info);
	getsockopt(m_sockfd,IPPROTO_TCP,TCP_INFO,&info, (socklen_t *)&len);
	if(info.tcpi_state == TCP_ESTABLISHED)	
	{
		return true;	
	}
	::close(m_sockfd);
	return false;
}
