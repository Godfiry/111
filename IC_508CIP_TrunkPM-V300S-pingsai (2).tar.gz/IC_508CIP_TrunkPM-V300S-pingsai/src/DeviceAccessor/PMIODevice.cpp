/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: PMIODevice.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2007-9-22   LiJuanjuan create
**      
*********************************************************************/
#include "PMIODevice.h"
#include <string.h>

#include "DeviceManager.h"
#include "ConfigException.h"
//#include "ConstantDefine.h"

#include "ObjectManager.h"
#include<iostream>
#include <cmath>
#include <sys/time.h>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
#endif

using namespace std;

PMIODevice::PMIODevice()
{
	m_DIStartAddr = -1;//added by liusy[1.1.57]
	m_AIStartAddr = -1;
}

PMIODevice::~PMIODevice()
{
}

bool PMIODevice::readBit(int channelNum, int *bit, const IntTypeInfo &typeInfo)
{
	if (isSimulated())
	{
		struct timeval tm;
		struct timezone *tz = NULL;
		
		gettimeofday(&tm,tz);
		*bit = tm.tv_usec % 2;
		return true;
	}
	
	int byteno = (channelNum - m_DIStartPos) / 8;
	int bitno = (channelNum - m_DIStartPos) % 8;
	unsigned int movebit = 1 << bitno;
	
	char buffer[200];
	memset(buffer, 0, 200);
	m_deviceNet->readByte(m_macID, buffer);
	int nStartAddr = 0;//added by liusy[1.1.57]
	if(m_DIStartAddr != -1)
	{
		nStartAddr = m_DIStartAddr;
	}
	else
	{
		nStartAddr = m_AIChsSize *2;
	}
	unsigned int temp = ((unsigned int)buffer[byteno + nStartAddr]) & movebit;
	int value = temp >> bitno;
	if(value==0||value==1)
	{
		//cout<<"channelnum:"<<channelNum<<endl;
		//cout<<"read bit value:"<<value<<endl;
		*bit = value;
		return true;
	}
	else
		return false;
}

bool PMIODevice::writeBit(int channelNum, int bit, const IntTypeInfo &typeInfo)
{
	if (isSimulated())
	{
		return true;
	}
	
	if(bit < 0 || bit > 1)
	{
		return false;
	}
	int byteno = channelNum / 8;
	int bitno = channelNum % 8;
	unsigned char bitmask = 1;
	bitmask = bitmask << bitno;	
	//16 AO //8
	if(bit == 1)
	{
//		m_buffer[byteno] = m_buffer[byteno] | bitmask;
		m_buffer[byteno + m_AOChsSize * 2] = m_buffer[byteno + m_AOChsSize * 2] | bitmask;//16 16
	}
	if(bit == 0)
	{
		bitmask = ~bitmask;
//		m_buffer[byteno] = m_buffer[byteno] & bitmask;
		m_buffer[byteno + m_AOChsSize * 2] = m_buffer[byteno + m_AOChsSize * 2] & bitmask;//16 16
	}
	return m_deviceNet->writeByte(m_macID, m_buffer);
}

bool PMIODevice::writeAnalog(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
	if (isSimulated())
	{
		return true;
	}

	unsigned long temp;
	
	if(channelNum < m_AOStartPos || channelNum >= (m_AOStartPos + m_AOChsSize))
	{
		return false;
	}
	else
	{	
		if(m_mapSpecialChlName.find(channelNum) != m_mapSpecialChlName.end())	
		{
			if(m_mapSpecialChlName[channelNum] == "TcontrolAO")
			{
				temp =  (unsigned long) ((value - 1.5) / 10 * 32768.0);			
			}	
			//PulseFreqAO (maxFreq - x) / (maxFreq - minFreq) * (max - min) + min						
			if(m_mapSpecialChlName[channelNum] == "PulseFreqAO")
			{
				temp =  (unsigned long) (typeInfo.getMax() / value);//125000
			}

		}
		else
		{
			temp = (unsigned long) (value / typeInfo.getMax() * 32768.0);
		}
		m_buffer[(channelNum - m_AOStartPos) * 2] = (unsigned char)(temp & 0xff);
		m_buffer[(channelNum - m_AOStartPos) * 2 + 1] = (unsigned char)((temp>>8) & 0xff);
		return m_deviceNet->writeByte(m_macID, m_buffer);
	}
	
//HePressureSPAO case Pa:(value / 6666.1 * 32768.0);case mTorrOrTorr:  (value / 6666.1 * 32768.0 * 133.3);
}

bool PMIODevice::readAnalog(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	if (isSimulated())
	{
		struct timeval tm;
		struct timezone *tz = NULL;
		
		gettimeofday(&tm,tz);
		*value = typeInfo.getMax() * ((double)tm.tv_usec / 1000000);
		return true;
	}
	
	char buffer[100];
	memset(buffer, 0, 100);
	m_deviceNet->readByte(m_macID, buffer);
	unsigned long temp=0;
	
	int nStartAddr = 0;//added by liusy[1.1.57]
	if(m_AIStartAddr != -1)
	{
		nStartAddr = m_AIStartAddr;
	}

	if(channelNum < m_AIStartPos || channelNum >= (m_AIStartPos + m_AIChsSize))
	{
		return false;
	}
	else
	{
		
		temp = (((unsigned long)buffer[(channelNum - m_AIStartPos) * 2 + nStartAddr]) & 0xff) + ((((unsigned long)buffer[(channelNum - m_AIStartPos) * 2 + 1 + nStartAddr]) << 8) & 0xff00);
		if ((double (temp) <= 32768 * 1.05) && (temp >= 32768))
			temp = 32768;
		if(m_mapSpecialChlName.find(channelNum) != m_mapSpecialChlName.end())
		{
			std::string t_strName = m_mapSpecialChlName[channelNum];  //[chensc v1.1.19]
			if(m_mapSpecialChlName[channelNum] == "TMPAnalogoutAI")
			{
				if(temp*typeInfo.getMax()/32768.0<800.0)
				{
					*value = 0;
				}
				else
				{
					*value = (int)(temp*typeInfo.getMax()/32768.0);
				}
				return true;
			}							
			if(m_mapSpecialChlName[channelNum] == "PulseFreqAI")
			{
				if(0 != temp)
					*value = typeInfo.getMax() / temp;   // 125000
				else
					*value = 0.0;
				return true;
			}
			if(t_strName.find("Heater") != string::npos)   //[chensc v1.1.19]
			{
				*value = temp/10;
				return true;
			}
		}
		else
		{
			double dTemp = temp*typeInfo.getMax()/32768.0;//changed by heyj[1.10.0]
            if(m_aiFilter.find(channelNum) == m_aiFilter.end() || (dTemp > m_aiFilter[channelNum]))//[added by wangyk 1.2.4]
            {
				*value = dTemp;
			}
            else//filter noise
            {
                *value = 0;
			}	
            return true;
        }
    }    
}

void PMIODevice::initChs(DeviceNode<PMIODevice> *node)
{
	
//			cout<<"ininitchs"<<endl;
	for(int i = 0; i < m_DIChsSize; ++i)
	{
		node->registerReadCh(i + m_DIStartPos, &PMIODevice::readBit);
	}
	//cout<<"1"<<endl;
	for(int i = 0; i < m_DOChsSize; ++i)
	{
		node->registerWriteCh(i + m_DOStartPos, &PMIODevice::writeBit);
	}
	//cout<<"2"<<endl;
	for(int i = 0; i < m_AIChsSize; ++i)
	{
		node->registerReadCh(i + m_AIStartPos, &PMIODevice::readAnalog);
	}
	//cout<<"3"<<endl;
	for(int i = 0; i < m_AOChsSize; ++i)
	{
		node->registerWriteCh(i + m_AOStartPos, &PMIODevice::writeAnalog);
	}
	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &PMIODevice::getStatus);
	//cout<<"outinitchs"<<endl;
}

void PMIODevice::setSpecialChlName(int channelNum, std::string name)
{
	m_mapSpecialChlName.insert(pair<int,std::string>(channelNum,name));
}

void PMIODevice::init()
{
	DeviceNode<PMIODevice> * node = new DeviceNode<PMIODevice>(m_pollInterval,this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	
	if(!isSimulated())
	{
		initChs(node);
		initDeviceNet();	
		
		string error = "";
		int inBytesSize = m_deviceNet->getIBytesSize(m_macID);
		int outBytesSize = m_deviceNet->getOBytesSize(m_macID);
		if((m_DIChsSize + m_AIChsSize*16)  > inBytesSize*8)
		{
			error = "Input channel number is bigger than allowed input number: " + Converter::convertToString(m_DIChsSize + m_AIChsSize*16) + ">"+Converter::convertToString(inBytesSize*8);
			throw ConfigException(error);
		}
		if((m_DOChsSize + m_AOChsSize*16) > outBytesSize*8)
		{
			error = "Output channel number is bigger than allowed output number: " + Converter::convertToString(m_DOChsSize + m_AOChsSize*16) + ">"+Converter::convertToString(outBytesSize*8);
			throw ConfigException(error);
		}
		m_buffer = new char[outBytesSize];
		memset(m_buffer, 0, outBytesSize);
		
		initDevice();
	}
	else
	{
		string error;
		
		if(m_nodeNum < 0)
		{
			error = "node number illegal: " + Converter::convertToString(m_macID);
			throw ConfigException(error);
		}
		initChs(node);
	}
}
void PMIODevice::setDIInfo(int tDIStartPos, int tDIChsSize)
{
	m_DIStartPos = tDIStartPos;
	m_DIChsSize = tDIChsSize;
}
void PMIODevice::setDOInfo(int tDOStartPos, int tDOChsSize)
{
	//cout<<"start set DOInfo:"<<endl;
	m_DOStartPos = tDOStartPos;
	m_DOChsSize = tDOChsSize;
	//cout<<"finish set DOInfo:"<<endl;
}
void PMIODevice::setAIInfo(int tAIStartPos, int tAIChsSize)
{
	//cout<<"start set AIInfo:"<<endl;
	m_AIStartPos = tAIStartPos;
	m_AIChsSize = tAIChsSize;
	//cout<<"finish set AIInfo:"<<endl;
}
//added by liusy[1.1.57]
void PMIODevice::setDIStartAddr(int nStartAddr)
{
	m_DIStartAddr = nStartAddr;
}

void PMIODevice::setAIStartAddr(int nStartAddr)
{
	m_AIStartAddr = nStartAddr;
}

void PMIODevice::setAOInfo(int tAOStartPos, int tAOChsSize)
{
	//cout<<"start set AOInfo:"<<endl;
	m_AOStartPos = tAOStartPos;
	m_AOChsSize = tAOChsSize;
	//cout<<"finish set AOInfo:"<<endl;
}
IMPLEMENT_DYNAMIC(PMIODevice, IODevice )
BEGIN_MSG_MAP( PMIODevice, IODevice )
	SET_II(setDIInfo, PMIODevice)
	SET_II(setDOInfo, PMIODevice)
	SET_II(setAIInfo, PMIODevice)
	SET_II(setAOInfo, PMIODevice)
	SET_I(setDIStartAddr, PMIODevice)//added by liusy[1.1.57]
	SET_I(setAIStartAddr, PMIODevice)//added by liusy[1.1.57]
	SET_IS(setSpecialChlName, PMIODevice)
END_MSG_MAP


