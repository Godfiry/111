/********************************************************************
** Copyright (c) 2021, Beijing NAURA Co.,Ltd.  All rights reserved.
** File name: PLCRecipeAssistant.h
** Description:
** Release: 1.1
** Modification history:
** 					2021-6-12   mujy create
**
*********************************************************************/
//#include "PLCRecipeAssistant.h"
//#include "AbortException.h"
//#include "Converter.h"
//#include "SysLogger.h"
//#include <iostream>

//#define MAXRECIPESTEP 10
//
//using namespace std;
//
//PLCRecipeAssistant::PLCRecipeAssistant()
//{
//	m_mapRecipeContent.clear();
//	//m_nTotalChildRecipeNum = 1;
//	m_nChildRecipeTotalCycleNum = 0;
//	m_nChildRecipeTotalStepNum = 0;
//}
//
//PLCRecipeAssistant::~PLCRecipeAssistant()
//{
//
//}
//
//bool PLCRecipeAssistant::isAddRecipeParamFromDriver()
//{
//	if(m_mapRecipeContent.size() <= 0)
//	{
//		return false;
//	}
//	else
//	{
//		return true;
//	}
//}
////for Upper
//void PLCRecipeAssistant::setRcpItemValue(string strParamName,int nStepIndex,double dValue)
//{
//	if (m_mapRecipeContent.count(strParamName) && nStepIndex < MAXRECIPESTEP)
//	{
//		m_mapRecipeContent[strParamName].at(nStepIndex) = dValue;
//		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": ToPLC set Param["+strParamName+"], step["+Converter::convertToString(nStepIndex)+"], value ["+Converter::convertToString(dValue)+"]");
//	}
//}
//
//void PLCRecipeAssistant::setRcpItemValue(string strParamName,int nStepIndex,int nValue)
//{
//	if (m_mapRecipeContent.count(strParamName)  && nStepIndex < MAXRECIPESTEP)
//	{
//		m_mapRecipeContent[strParamName].at(nStepIndex) = nValue;
//		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": ToPLC set Param["+strParamName+"], step["+Converter::convertToString(nStepIndex)+"], value ["+Converter::convertToString(nValue)+"]");
//	}
//}
//
///*void PLCRecipeAssistant::setChildRecipeTotalNum(int nNum)
//{
//	m_nTotalChildRecipeNum = nNum;
//}*/
//
//void PLCRecipeAssistant::setEveryChildRecipeTotalCycleNum(int nCycleNum)
//{
//	m_nChildRecipeTotalCycleNum = nCycleNum;
//}
//
//void PLCRecipeAssistant::setChildRecipeTotalStepNum(int nStepNum)
//{
//	m_nChildRecipeTotalStepNum = nStepNum;
//}
//
////for driver
//std::vector<double> PLCRecipeAssistant::getItemArray(string strParamName)
//{
//	if (m_mapRecipeContent.count(strParamName))
//	{
//		return m_mapRecipeContent[strParamName];
//	}
//	else
//	{
//		throw AbortException("driver try to get a unexist Rcp param value. "+strParamName);
//	}
//}
//
///*int PLCRecipeAssistant::getChildRecipeTotalNum()
//{
//	return m_nTotalChildRecipeNum;
//}*/
//
//int PLCRecipeAssistant::getEveryChildRecipeTotalCycleNum()
//{
//	return m_nChildRecipeTotalCycleNum;
//}
//
//int PLCRecipeAssistant::getChildRecipeTotalStepNum()
//{
//	return m_nChildRecipeTotalStepNum;
//}
////
//void PLCRecipeAssistant::addRecipeParam(string strParamName)
//{
//	cout<<"PLCRecipeAssistant::addRecipeParam "<<strParamName<<endl;
//	if (m_mapRecipeContent.count(strParamName))
//	{
//		throw AbortException("repeat param name ,please check. "+strParamName);
//	}
//
//	std::vector<double> data(MAXRECIPESTEP,0.0);
//	m_mapRecipeContent.insert(pair<std::string, std::vector<double> >(strParamName, data));
//	cout<<"PLCRecipeAssistant::addRecipeParam end"<<endl;
//}
//
//void PLCRecipeAssistant::clear()
//{
//	map<std::string, std::vector<double> >::iterator it = m_mapRecipeContent.begin();
//	for(;it != m_mapRecipeContent.end(); ++it)
//	{
//		std::vector<double> data(MAXRECIPESTEP,0.0);
//		m_mapRecipeContent[it->first] = data;
//	}
//	m_nChildRecipeTotalCycleNum = 0;
//	m_nChildRecipeTotalStepNum = 0;
//}
//
//IMPLEMENT_DYNAMIC(PLCRecipeAssistant, CmdTarget)
//
//BEGIN_MSG_MAP( PLCRecipeAssistant, CmdTarget )
//    SET_S( addRecipeParam, PLCRecipeAssistant )
//END_MSG_MAP
