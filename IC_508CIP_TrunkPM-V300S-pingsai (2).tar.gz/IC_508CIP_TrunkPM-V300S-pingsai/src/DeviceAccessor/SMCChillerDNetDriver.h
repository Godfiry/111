#ifndef SMCCHILLERDNETDRIVER_H_
#define SMCCHILLERDNETDRIVER_H_

#include "IODevice.h"
#include "DeviceNode.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class SMCChillerDNetDriver: public IODevice
{
    DECLARE_DYNAMIC(SMCChillerDNetDriver)	
    DECLARE_MSG_MAP
    
public:
	SMCChillerDNetDriver();
	virtual ~SMCChillerDNetDriver();
	
public://xml
	void init();
	
public://read and write function    
	bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
	bool writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo);
	bool readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);
	bool readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);
	bool readAlarm(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);

protected:	
	void InitChannels(DeviceNode<SMCChillerDNetDriver> *pNode);   
	void initDevice();
	
private:	
	typedef struct
	{
		int m_nByte;
		int m_nBit;
	}Com; 	
	char *m_pWriteBuffer;
	static Com m_Commands[];
};

#endif /*SMCCHILLERDNETDRIVER_H_*/
