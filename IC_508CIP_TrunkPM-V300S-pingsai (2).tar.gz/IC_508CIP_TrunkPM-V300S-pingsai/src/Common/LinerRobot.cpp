/*
 * LinerRobot.cpp
 *
 *  Created on: 20210712
 *      Author: lvjiawen
 */

#include "LinerRobot.h"
#include "XmlGetter.h"
#include "MapTool.h"
//#include "StrTool.h"
#include "ConfigException.h"
#include "AlarmReNameManager.h"
#include "Converter.h"
#include "CTCExport.h"
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

const string LinerRobot::UNKNOWN = "Unknown";

LinerRobot::LinerRobot()
{
	MOVING_TIME = 1;

	m_nTimeOutSec= 10;
	m_bUseStatusMonitor = true;

	m_strDestinationPos = "";

	m_pCurrentPosition = NULL;
	m_pState = NULL;

/*	m_pGoTo=new GoTo();
	m_pGoTo->setOwner(this);

	m_pGoNotWait=new GoNotWait();
	m_pGoNotWait->setOwner(this);*/

	m_pTimeOutAlarm = NULL;
	m_pUnexpectedMoveAlarm = NULL;

	m_pTimeScale = NULL;

	m_pDestinationPosMutex=new IMutex(true);

	m_pTimerMoveMonitor = NULL;
	m_pTimerSimulateMove = NULL;

	m_pMoveTime = NULL;//[zhangcx v1.1.27]
}

LinerRobot::LinerRobot(const LinerRobot& pObj)
{
	MOVING_TIME = pObj.MOVING_TIME;

	m_nTimeOutSec = pObj.m_nTimeOutSec;
	m_bUseStatusMonitor = pObj.m_bUseStatusMonitor;

	m_strDestinationPos = pObj.m_strDestinationPos;

	m_pCurrentPosition = pObj.m_pCurrentPosition;
	m_pState = pObj.m_pState;

	m_pTimeOutAlarm = pObj.m_pTimeOutAlarm;
	m_pUnexpectedMoveAlarm = pObj.m_pUnexpectedMoveAlarm;

	m_pTimeScale = pObj.m_pTimeScale;

	m_pDestinationPosMutex = new IMutex(true);

	m_pTimerMoveMonitor = pObj.m_pTimerMoveMonitor;
	m_pTimerSimulateMove = pObj.m_pTimerSimulateMove;

	m_pMoveTime = pObj.m_pMoveTime;
}

LinerRobot& LinerRobot::operator=(const LinerRobot& pObj)
{
	if (this != &pObj)
	{
		MOVING_TIME = pObj.MOVING_TIME;

		m_nTimeOutSec = pObj.m_nTimeOutSec;
		m_bUseStatusMonitor = pObj.m_bUseStatusMonitor;

		m_strDestinationPos = pObj.m_strDestinationPos;

		m_pCurrentPosition = pObj.m_pCurrentPosition;
		m_pState = pObj.m_pState;

		m_pTimeOutAlarm = pObj.m_pTimeOutAlarm;
		m_pUnexpectedMoveAlarm = pObj.m_pUnexpectedMoveAlarm;

		m_pTimeScale = pObj.m_pTimeScale;

		m_pDestinationPosMutex = new IMutex(true);

		m_pTimerMoveMonitor = pObj.m_pTimerMoveMonitor;
		m_pTimerSimulateMove = pObj.m_pTimerSimulateMove;

		m_pMoveTime = pObj.m_pMoveTime;
	}
	return *this;
}

LinerRobot::~LinerRobot()
{
	map<string, LinerRobotPosition*>::iterator it ;
	for(it=m_Position.begin(); it != m_Position.end();++it)
	{
		LinerRobotPosition* pData=it->second;
		delete pData;
		pData = NULL;
	}
	m_Position.clear();

	delete m_pTimeScale;
	m_pTimeScale = NULL;

	delete m_pTimerMoveMonitor;
	m_pTimerMoveMonitor = NULL;

	delete m_pTimerSimulateMove;
	m_pTimerSimulateMove = NULL;

	delete m_pDestinationPosMutex;
	m_pDestinationPosMutex=NULL;
}

void LinerRobot::make()
{
	Log_Info(getName()+" make.");
	m_pTimerMoveMonitor = new TimerEx();
	m_pTimerMoveMonitor->setTicker(this);
	m_pTimerMoveMonitor->setDuration(m_nTimeOutSec * 1000);

	m_pTimerSimulateMove = new TimerEx();
	m_pTimerSimulateMove->setTicker(this);
	m_pTimerSimulateMove->setDuration(MOVING_TIME * 1000);

	string strPreName = AlarmReNameManager::getInstance()->GetShowName(getName());
	m_pTimeOutAlarm = new NonBlockingAlarmEX(strPreName+"_TimeOut","move time out","move time out",Alarm::FATAL);//[wangyk v1.4.0] change alarmlevel 
	m_pTimeOutAlarm->addRecovery(new Recovery("Clear",  Recovery::CLEAR));

	m_pUnexpectedMoveAlarm = new NonBlockingAlarmEX(strPreName+"_UnexpectedMove",getName()+" Unexpected move.","Position changed without send action!",Alarm::ERROR);//wangyk change Name 1.2.9
	m_pUnexpectedMoveAlarm->addRecovery(new Recovery("Clear",  Recovery::CLEAR));

	if(m_pCurrentPosition == NULL)
	{
		m_pCurrentPosition = new ReadWriteInt(IntTypeInfo(DescriptorList(makeDescriptorListStr())));
	}
	if(m_pState == NULL)
	{
		m_pState= new ReadWriteInt(IntTypeInfo(DescriptorList("Abnormal,OK")));
		m_pState->setValue("Abnormal");//add by AtuoCodeChangeTool for IAP4.0
	}
	m_pTimeScale = new TimeScale(getSelfName());

	m_pMoveTime = new ReadWriteDouble();//[zhangcx v1.1.27]
	m_pMoveTime->setValue(0.0);//add by AtuoCodeChangeTool for IAP4.0
	CTCExport::exportAsOthers(m_pMoveTime, getSelfName() + "_MoveTime");

	ControlObjectEX::make();
}

void LinerRobot::initialize()
{
	Log_Info(getName()+" initialize.");
	m_pCurrentPosition->setValue(UNKNOWN);
	m_pState->setValue("Abnormal");
	ControlObjectEX::initialize();

	m_pMoveTime->setValue(0);//[zhangcx v1.1.27]
}

void LinerRobot::verifyInit()
{
	Log_Info(getName()+" verifyInit.");
	//DO
	int nDOSize=m_DO.size();
	vector<ReadWriteInt*> DO(nDOSize);
	map<int,ReadWriteInt*>::iterator it_DO ;
	for(it_DO=m_DO.begin(); it_DO != m_DO.end();++it_DO)
	{
		int nID=it_DO->first;
		ReadWriteInt* pData=it_DO->second;
		if(nID >= nDOSize)
		{
			Log_Error(getName()+" Config Err:DO ID must be serial num,and start with 0!eg.0 1 2 3");
			throw ConfigException("Err:DO ID must be serial num,and start with 0!eg.0 1 2 3");
		}
		DO[nID]=pData;
	}

	//DI
	int nDISize=m_DI.size();
	vector<ReadOnlyInt*> DI(nDISize);
	map<int,ReadOnlyInt*>::iterator it_DI ;
	for(it_DI=m_DI.begin(); it_DI != m_DI.end();++it_DI)
	{
		int nID=it_DI->first;
		ReadOnlyInt* pData=it_DI->second;
		if(nID >= nDISize)
		{
			Log_Error(getName()+" Config Err:DI ID must be serial num,and start with 0!eg.0 1 2 3");
			throw ConfigException("Err:DI ID must be serial num,and start with 0!eg.0 1 2 3");
		}
		DI[nID]=pData;
	}

	map<string, vector<int> >::iterator it_PositionDO ;
	for(it_PositionDO=m_PositionDO.begin(); it_PositionDO != m_PositionDO.end();++it_PositionDO)
	{
		vector<int> Data=it_PositionDO->second;
		int nLength = Data.size();
		if(nLength > nDOSize)
		{
			Log_Error(getName()+" Config Err:PositionDO size is longer than DOSize!");
			throw ConfigException("Err:PositionDO size is longer than DOSize!");
		}
	}

	map<string, vector<int> >::iterator it_PositionDI ;
	for(it_PositionDI=m_PositionDI.begin(); it_PositionDI != m_PositionDI.end();++it_PositionDI)
	{
		vector<int> Data=it_PositionDI->second;
		int nLength = Data.size();
		if(nLength > nDISize)
		{
			Log_Error(getName()+" Config Err:PositionDI size is longer than DISize!");
			throw ConfigException("Err:PositionDI size is longer than DISize!");
		}
	}

	//add to position
	map<string, LinerRobotPosition*>::iterator it ;
	for(it=m_Position.begin(); it != m_Position.end();++it)
	{
		LinerRobotPosition* pData=it->second;
		pData->setDO(DO);
		pData->setDI(DI);
	}

	ControlObjectEX::verifyInit();
}

void LinerRobot::startup()
{
	//subscribe
	map<int,ReadOnlyInt*>::iterator it_DI ;
	for(it_DI=m_DI.begin(); it_DI != m_DI.end();++it_DI)
	{
		ReadOnlyInt* pData=it_DI->second;
		pData->subscribe(this);
	}

	goCurrentPosition();

	ControlObjectEX::startup();
}

void LinerRobot::update(UntypedData *pData, const ValueInfo &value)
{
	try
	{
		if(MapTool::valueExist<int, ReadOnlyInt*>(m_DI,dynamic_cast<ReadOnlyInt*>(pData)))
		{
			Log_Info(getName()+": sensor changed.");
			map<string, LinerRobotPosition*>::iterator it ;
			for(it=m_Position.begin(); it != m_Position.end();++it)
			{
				string strPosName=it->first;
				LinerRobotPosition* pData=it->second;
				if(pData->isAt())
				{
					if(strPosName != getCurrentPosition())//not check sensor changed,do nothing.
					{
						onStatusChange(strPosName);
					}
					return;
				}
			}
			onStatusChange(UNKNOWN);
		}
	}
	catch(exception &ex)
	{
		Log_Error(getName()+" Exception in update thread! err is:" + ex.what());
	}
	catch(...)
	{
		Log_Error(getName()+" Exception in update thread!");
	}
}

void LinerRobot::updateFromTimer(TimerEx * pSender)
{
	string strPosName = getDestinationPos();

	if(pSender == m_pTimerMoveMonitor)
	{
		if(isMoving())
		{
			onGoTimeOut(strPosName);
		}
	}
	if(pSender == m_pTimerSimulateMove)
	{
		if(strPosName != "")
		{
			m_Position[strPosName]->simulateArrive();
		}
	}
}

void LinerRobot::do_Up()
{
	cout<<"Please use Goto/GoNotWait!"<<endl;
}

void LinerRobot::do_Down()
{
	cout<<"Please use Goto/GoNotWait!"<<endl;
}

void LinerRobot::do_GoTo(string strPosName)
{
	if(strPosName!="up" && strPosName!="down" && strPosName!="process" )
	{
		cout<<"Please use string parameter in recipe!"<<endl;
		Log_Info(getName()+"Please use string parameter in recipe!");
	}
	else
	{
		Log_Info(getName()+": do_GoTo start");
		Log_Info(getName()+": do_GoTo strPosName = " + strPosName);

		goAndWait(strPosName);

		Log_Info(getName()+": do_GoTo end");
	}
}

void LinerRobot::do_GoNotWait(string strPosName)
{
	if(strPosName!="up" && strPosName!="down" && strPosName!="process" )
	{

		cout<<"Please use string parameter in recipe!"<<endl;
		Log_Info(getName()+"Please use string parameter in recipe!");
	}
	else
	{
		Log_Info(getName()+": do_GoNotWait start");
		Log_Info(getName()+": do_GoNotWait strPosName = " + strPosName);

		go(strPosName);

		Log_Info(getName()+": do_GoNotWait end");
	}
}

void LinerRobot::setPosition(string strPosName)
{
	LinerRobotPosition * pPos =new LinerRobotPosition();
	if(!MapTool::addToMap<string, LinerRobotPosition*>(m_Position, strPosName, pPos))
	{
		Log_Error(getName()+" Config Err:Position ID repeat added!");
		throw ConfigException(getName()+" Err:Position ID repeat added!");
	}
}

void LinerRobot::setDO(int nDOID,string strPath)
{
	if(nDOID < 0)
	{
		Log_Error(getName()+" Config Err:Do ID < 0!");
		throw ConfigException(getName()+" Err:Do ID < 0!");
	}
	ReadWriteInt *pDO=XmlGetter::getFromNamespace<ReadWriteInt*>(strPath);
	if(!MapTool::addToMap<int, ReadWriteInt*>(m_DO, nDOID, pDO))
	{
		Log_Error(getName()+" Config Err:Do ID repeat added!");
		throw ConfigException(getName()+" Err:Do ID repeat added!");
	}
}

void LinerRobot::setDI(int nDIID,string strPath)
{
	if(nDIID < 0)
	{
		Log_Error(getName()+" Config Err:DI ID < 0!");
		throw ConfigException(getName()+" Err:DI ID < 0!");
	}
	ReadOnlyInt *pDI=XmlGetter::getFromNamespace<ReadOnlyInt*>(strPath);
	if(!MapTool::addToMap<int, ReadOnlyInt*>(m_DI, nDIID, pDI))
	{
		Log_Error(getName()+" Config Err:DI ID repeat added!");
		throw ConfigException(getName()+" Err:DI ID repeat added!");
	}
}

void LinerRobot::setPositionDO(string strPosName,string strDoList)
{
	vector<int> DoList;
	const char *pData=strDoList.c_str();
	for(unsigned int i=0 ; i < strDoList.length() ; ++i)
	{
		if(pData[i]=='0')
		{
			DoList.push_back(0);
		}
		else if(pData[i]=='1')
		{
			DoList.push_back(1);
		}
		else
		{
			//not set actuator
			DoList.push_back(2);
		}
	}

	if(!MapTool::addToMap<string, vector<int> >(m_PositionDO, strPosName, DoList))
	{
		Log_Error(getName()+" Config Err:[setPositionDO]Position ID repeat added!");
		throw ConfigException(getName()+" Err:[setPositionDO]Position ID repeat added!");
	}

	//add position

	m_Position[strPosName]->setDOState(DoList);
}

void LinerRobot::setPositionDI(string strPosName,string strDIList)
{
	vector<int> DIList;
	const char *pData=strDIList.c_str();
	for(unsigned int i=0 ; i < strDIList.length() ; ++i)
	{
		if(pData[i]=='0')
		{
			DIList.push_back(0);
		}
		else if(pData[i]=='1')
		{
			DIList.push_back(1);
		}
		else
		{
			//not check sensor
			DIList.push_back(2);
		}
	}

	if(!MapTool::addToMap<string, vector<int> >(m_PositionDI, strPosName, DIList))
	{
		Log_Error(getName()+" Config Err:[setPositionDI]Position ID repeat added!");
		throw ConfigException(getName()+" Err:[setPositionDI]Position ID repeat added!");
	}

	//add position

	m_Position[strPosName]->setDIState(DIList);
}

void LinerRobot::setInterlock(string strPosName,string strPath)
{
	IOInterlocks *pInterlock=XmlGetter::getFromNamespace<IOInterlocks*>(strPath);
	if(!MapTool::addToMap<string, IOInterlocks*>(m_Interlock, strPosName, pInterlock))
	{
		Log_Error(getName()+"setInterlock Config Err:Position ID repeat added!");
		throw ConfigException(getName()+" Err:Position ID repeat added!");
	}
}

void LinerRobot::useStatusMonitor(bool bUseStatusMonitor)
{
	m_bUseStatusMonitor = bUseStatusMonitor;
}

void LinerRobot::setPositionExportPath(string strPath)
{
	m_pCurrentPosition = new ReadWriteInt(IntTypeInfo(DescriptorList(makeDescriptorListStr())));
	CTCExport::exportToCTC(m_pCurrentPosition,strPath);
}

void LinerRobot::setStatusExportPath(string strPath)
{
	m_pState = new ReadWriteInt(strPath,IntTypeInfo(DescriptorList(makeDescriptorListStr())));
}

void LinerRobot::setTimeOut(int nTimeOutSecond)
{
	m_nTimeOutSec = nTimeOutSecond;
}

void LinerRobot::go(string strPosName)
{
	// position exist
	if(!isPositionExist(strPosName))
	{
		onPositionNotExist(strPosName);
	}
	// onMoving
	if(isMoving())
	{
		//  [lvjw 1.2.10]
		if(strPosName == getDestinationPos())
		{
			Log_Error(getName() + ": Other action not Finish! Go to the same position,cancel the last one.");
			return;
		}
		onOtherActionNotFinish(false,strPosName);
	}
	// (Already at destination) || (No sensor)
	if(isSensorAt(strPosName))
	{
		Log_Info(getName()+": go " + strPosName + " send DO only.");
		m_Position[strPosName]->go();
		if(strPosName != getCurrentPosition())//only no sensor may come in  [lvjw 1.2.10]
		{
			m_pCurrentPosition->setValue(strPosName);
		}
		return ;
	}
	// normal
	m_Position[strPosName]->go();
	m_pTimerMoveMonitor->startOnce();
	onMoving(strPosName);
	if(isSimulated())
	{
		m_pTimerSimulateMove->startOnce();
	}
}

bool LinerRobot::waitArrive()
{
	string strPosName = getDestinationPos();

	while(true)
	{
		if(!isMoving())//  [lvjw 1.2.10]
		{
			return true;
		}
		if(m_pTimeScale->isReach(m_nTimeOutSec*1000))
		{
			return false;
		}
		usleepChange(50*1000);
	}
	return false;//will not reach here
}

void LinerRobot::goAndWait(string strPosName)
{
	// position exist
	if(!isPositionExist(strPosName))
	{
		onPositionNotExist(strPosName);
	}
	// onMoving
	if(isMoving())
	{
		onOtherActionNotFinish(true,strPosName);
	}
	// (Already at destination) || (No sensor)
	if(isSensorAt(strPosName))
	{
		Log_Info(getName()+": go " + strPosName + " send DO only.");
		m_Position[strPosName]->go();
		if(strPosName != getCurrentPosition())//only no sensor may come in  [lvjw 1.2.10]
		{
			m_pCurrentPosition->setValue(strPosName);
		}
		return ;
	}
	// normal
	m_Position[strPosName]->go();
	onMoving(strPosName);
	if(isSimulated())
	{
		Log_Info(getName()+" Simulate Moving.");
		m_pTimerSimulateMove->startOnce();
	}
	if(!waitArrive())
	{
		onGoAndWaitTimeOut(strPosName);
	}
}

void LinerRobot::goCurrentPosition()
{
	string strCurrentPos=getCurrentPosition();
	if(strCurrentPos != UNKNOWN)
	{
		Log_Info(getName()+": goCurrentPosition - " + strCurrentPos);
		go(strCurrentPos);
	}
	else
	{
		Log_Info(getName()+": goCurrentPosition do nothing at UNKNOWN position.");
	}
}

bool LinerRobot::isSensorAt(string strPosName)
{
	return m_Position[strPosName]->isAt();
}

bool LinerRobot::isAt(string strPosName)
{
	bool bResult = (strPosName == getCurrentPosition());
	return bResult;
}

bool LinerRobot::isMoving()
{
	bool bResult = (getDestinationPos() != "");
	return bResult;
}

string LinerRobot::getCurrentPosition()
{
	return m_pCurrentPosition->getValueAsDescriptor();
}

void LinerRobot::onMoving(string strPosName)
{
	m_pTimeScale->setStartPoint();
	setDestinationPos(strPosName);
}

void LinerRobot::onStatusChange(string strPosName)
{
	Log_Info(getName()+": Status change to "+strPosName);

	m_pCurrentPosition->setValue(strPosName);

	if(!isMoving() && m_bUseStatusMonitor && isStartuped())
	{
		onUnexpectedMove(strPosName);
	}

	if(strPosName == getDestinationPos())
	{
		onArriveDestination();
	}
}

void LinerRobot::onArriveDestination()
{
	Log_Info(getName()+": ArriveDestination.");
	m_pTimeScale->setFinishPoint();
	m_pState->setValue("OK");
	m_pTimerMoveMonitor->stop();
	setDestinationPos("");

	string strMoveTime = m_pTimeScale->getTimeScale();//[zhangcx v1.1.27]
	double dMoveTime = 0;
	strMoveTime.erase(strMoveTime.length() - 1);
	Converter::stringToDouble(dMoveTime, strMoveTime);
	m_pMoveTime->setValue(dMoveTime);
}

void LinerRobot::onGoFailed(string strPosName,string strFailReason)
{
	string strErrMsg="go to [" + strPosName + "] fail.Reason :" + strFailReason;
	Log_Error(getName() + ": " + strErrMsg);
	m_pState->setValue("Abnormal");
	m_pTimerMoveMonitor->stop();//  [lvjw 1.2.10]
	setDestinationPos("");
}

void LinerRobot::onUnexpectedMove(string strPosName)
{
	//in update thread. throw exception is forbiden!!!!
	Log_Error(getName()+": move to " + strPosName + " with out action!");
	postAlarm(m_pUnexpectedMoveAlarm);
}

void LinerRobot::onGoAndWaitTimeOut(string strPosName)
{
	onGoFailed(strPosName,"time out");
	throw AbortException(getSelfName()+" move time out!");
}

void LinerRobot::onGoTimeOut(string strPosName)
{
	string strMsg = getSelfName()+" move to " + strPosName + " failed!";
	string strDes = "Move to " + strPosName + " time out! Time out is [" +Converter::convertToString(m_nTimeOutSec) + "] second." ;
	m_pTimeOutAlarm ->setMessage(strMsg);
	m_pTimeOutAlarm ->setDescription(strDes);
	onGoFailed(strPosName,"time out");
	postAlarm(m_pTimeOutAlarm);
}

void LinerRobot::onOtherActionNotFinish(bool bWait,string strCurrentDestination)
{
	Log_Error(getName() + ": Other action not Finish!");
	//  [lvjw 1.2.10]
	if(bWait)
	{
		while(isMoving())
		{
			usleepChange(50*1000);
		}
	}
	else
	{
		onGoFailed(getDestinationPos(),"new action coming");
	}
}

void LinerRobot::onPositionNotExist(string strErrPosName)
{
	string strMsg = getName() + ": Position not exist!";
	Log_Error(strMsg);
	throw AbortException(strMsg);
}

bool LinerRobot::isPositionExist(string strPosName)
{
	return (m_Position.count(strPosName) != 0);
}

string LinerRobot::makeDescriptorListStr()
{
	string strResult=UNKNOWN;

	map<string, LinerRobotPosition*>::iterator it ;
	for(it=m_Position.begin(); it != m_Position.end();++it)
	{
		string strPosName=it->first;
		strResult = strResult + "," + strPosName;
	}

	return strResult;
}

string LinerRobot::getDestinationPos()
{
	IMutexLocker locker(m_pDestinationPosMutex);
	return m_strDestinationPos;
}

void LinerRobot::setDestinationPos(string strPosName)
{
	IMutexLocker locker(m_pDestinationPosMutex);
	m_strDestinationPos = strPosName;
}
//class
IMPLEMENT_DYNAMIC(LinerRobot, Pin)

BEGIN_SERVICEINFO_LIST(LinerRobot)

END_SERVICEINFO_LIST(LinerRobot)

//config
BEGIN_MSG_MAP( LinerRobot, Pin)
	SET_S(setPosition, LinerRobot)
	SET_IS(setDO, LinerRobot)
	SET_IS(setDI, LinerRobot)
	SET_SS(setPositionDO, LinerRobot)
	SET_SS(setPositionDI, LinerRobot)
	SET_SS(setInterlock, LinerRobot)
	SET_B(useStatusMonitor, LinerRobot)
	SET_S(setPositionExportPath, LinerRobot)
	SET_S(setStatusExportPath, LinerRobot)
	SET_I(setTimeOut, LinerRobot)
END_MSG_MAP
