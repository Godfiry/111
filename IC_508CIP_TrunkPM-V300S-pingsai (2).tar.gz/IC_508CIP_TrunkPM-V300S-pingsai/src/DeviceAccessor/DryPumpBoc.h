/********************************************************************
** Copyright (c) 2019, Beijing Naura Co.,Ltd.  All rights reserved.
** File name: DryPumpBoc.h
** Description: For BOC dry pump device for RS232 communicational model.
* 		1. Manual name: << SIM P41100200 -issue F Instructions>>;
* 		2. Baud Rate:9600; CharSize: 8;StopBite:1 ; Parity:0;	[Reference manual P8 --2.1 Serial interface];
* 		3. RS232 command syntax:[first charactor][function][CR]
* 			(1)sendCommand can reference mnual P24 4.5 Command messages;
* 				Notice: when the sendCommand is sent, the Device-DryPump will return a response to reply whether the sendCommand was sent successfully.
* 			(2)readCommand can reference mnual P18 & P21 4.4 Query message details;
** Release: 1.0 
** Modification history: 
** 					2019-08-29   liuxj create
**      
*********************************************************************/
#ifndef DRYPUMPBOC_H_
#define DRYPUMPBOC_H_
#include "SerialDevice.h"
#include "DeviceNode.h"
#include "ReadWriteDouble.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class DryPumpBoc : public SerialDevice
{
    	DECLARE_DYNAMIC(DryPumpBoc)	
	DECLARE_MSG_MAP
	
	public:
		DryPumpBoc();
		virtual ~DryPumpBoc();
		
	public://xml
		 void init();
	
	public://interface
		bool readInt(int nChannelNum,int *pValue,const IntTypeInfo& typeinfo);
		bool writeInt(int nChannelNum,int nValue ,const IntTypeInfo& typeinfo);
		bool readStringError(int nChannelNum,std::string * strValue , const StringTypeInfo& typeinfo);
		void checkActionCommandReply(std::string strCmd, std::string strResp);	//for analysis the send eeror reason;
		void logIOException(std::string strCommand, std::string strFailedReason);	//to print the logSystem.
		
	protected://override
		void initChs(DeviceNode<DryPumpBoc> *pNode);	//inint channel
		void initDevice();
		
	private:
		typedef struct
		{
			std::string m_strMsg;
			int m_nTimeOut;
		}Com;
		static Com m_commands[8];	
};
#endif /*DRYPUMPBOC_H_*/
