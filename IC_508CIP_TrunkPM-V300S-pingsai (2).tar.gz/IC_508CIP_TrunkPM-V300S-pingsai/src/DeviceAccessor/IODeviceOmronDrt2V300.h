/*
 * IODeviceOmronDrt2V300.h
 *
 *  Created on: Sep 19, 2021
 *      Author: weizd
 */

#ifndef IODEVICEOMRONDRT2V300_H_
#define IODEVICEOMRONDRT2V300_H_

#include "IODevice.h"

class IODeviceOmronDrt2V300:public IODevice
{
	DECLARE_DYNAMIC(IODeviceOmronDrt2V300)
	DECLARE_MSG_MAP

	public:
		IODeviceOmronDrt2V300();
		virtual ~IODeviceOmronDrt2V300();

	public://override
		virtual void init();
		virtual void initDevice();
		virtual std::string getDeviceName();

	public:
		bool setFire(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
		bool readWarning(int nChannelNum, int * nValue, const IntTypeInfo &typeInfo);

	private:
		int m_nInBytesSize;
		int m_nOutBytesSize;


};

#endif /* SCRUBBEROMRONDRT2V300_H_ */
