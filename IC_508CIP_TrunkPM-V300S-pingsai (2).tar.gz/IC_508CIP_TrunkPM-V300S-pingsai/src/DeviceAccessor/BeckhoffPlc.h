/********************************************************************
** Copyright (c) 2021, Beijing NAURA Co.,Ltd.  All rights reserved.
** File name: BeckhoffPlc.h
** Description:Beckhoff module communication through TCP/IP Protocol
*
*  Modbus TCP frame format:
* --------------------------------------------------------------------------------------------------------------------------
*  transaction identifier  |  protocol identifier    | length field     | unit identifier | function code | data bytes
* --------------------------------------------------------------------------------------------------------------------------
*    byte 0 | byte 1       |    byte 2 | byte 3      | byte 4 | byte 5  |      byte 6     |     byte 7    | byte 8 ~ byte n
* --------------------------------------------------------------------------------------------------------------------------
*  Modbus func code
*  FUNC CODE:: WR_BIT 0x05
*  FUNC CODE:: MWR_BIT 0x15
*  FUNC CODE:: WR_WORD 0x06
*  FUNC CODE:: MWR_WORD 0x16
*
** Release: 1.1
** Modification history:
** 					2021-1-20   chenmz create
** 					2021-2-1    mayc modified
**
*********************************************************************/
#ifndef BECKHOFFPLC_H_
#define BECKHOFFPLC_H_

#include "TCPDevice.h"
#include "DeviceNode.h"
#include "IMutex.h"
#include "ReadWriteDouble.h"
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
#endif


class BeckhoffPlc :public TCPDevice
{
	DECLARE_DYNAMIC(BeckhoffPlc)	
	DECLARE_MSG_MAP	

private:

	class Param
	{
	public:

		int m_nAreaCode; // contains: m_lenH + m_lenL + m_uid + m_funcCode

		unsigned char m_cUid; //unit identifier('slave address', 255 if not used)
		unsigned char m_cFuncCode;
		unsigned char m_cLenH; // Variable Length high byte.
		unsigned char m_cLenL; // Variable Length low byte.

		int m_nAreaAddr;
		unsigned char m_cAddrH;    // Variable ADDRESS high byte.
		unsigned char m_cAddrL;    // Variable ADDRESS low byte.
		int m_nByteLen;   // Variable length in BYTE

		Param();
		Param(int nAreaCode, int nAreaAddr, int nByteLen);

		bool operator==(const Param &right) const;

	};

	bool m_bWaiting;
	bool m_bReadCmd;
	std::string m_strError;
	std::string m_strRawResult;
	std::string m_strResult;

	static const unsigned char R_COILBITS = 0x01; //read digital outputs,but only use one bit
	static const unsigned char R_INPUTBITS = 0x02; //read digital inputs,but only use one bit
	static const unsigned char R_HREGWORD = 0x03; //read holding register,but only use one or two words.
	static const unsigned char R_IREGWORD = 0x04; //read the inputs basis word,but only use one or two words.

	static const unsigned char WR_BIT = 0x05; //write single coil
	static const unsigned char MWR_BIT = 0x0f; //write multiple coils
	static const unsigned char WR_WORD = 0x06; //write single holding register
	static const unsigned char MWR_WORD = 0x10; //write single holding registers

	std::vector<Param> m_diParam; // DI channel cmd Param list
	std::vector<Param> m_doParam; // DO channel cmd Param list

	char m_modbusSend[64];

	protected:
	void parseReply();
	void flush();

	void modbusSendCommand(const Param &param, void *val, int nValByteLen, const std::string &strErrTitle);
	void initChannels(DeviceNode<BeckhoffPlc> *node);

public:
	BeckhoffPlc();
	virtual ~BeckhoffPlc();
	virtual void init();
	virtual std::string getDeviceName();
	virtual void acceptData();
	bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
	bool readInt(int nChannelNum, int *nValue, const IntTypeInfo &typeInfo);

	void addParamDI(int nAreaCode, int nAreaAddr, int nByteLen);
	void addParamDO(int nAreaCode, int nAreaAddr, int nByteLen);
};
#endif /*BECKHOFFPLC_H_*/
