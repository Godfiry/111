/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: DNetDNetFFD1000II1000-II.cpp
** Description:  
**     master -> follow : all use 16 bytes,default use 6 bytes
**     follow -> master : all use 16 bytes,default use 10 bytes
** Release: 1.1
** Modification history: 
**                     2024-9-26   taohao create
**      
*********************************************************************/
#include "DNetFFD1000II.h"

#include "DeviceManager.h"
#include <cmath>
#include <string.h>
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
#endif

using namespace std;

DNetFFD1000II::DNetFFD1000II()
{
    m_dFullScale = 100;
    m_dTemp1 = 0;
    m_dTemp2 = 0;
    m_dTemp3 = 0;
    memset(m_cBuffer, 0, 6);
    m_cTemp1 = 0;
    m_cTemp2 = 0;
    m_cTemp3 = 0;
    m_nSum = 0;
}

DNetFFD1000II::~DNetFFD1000II()
{
}

bool DNetFFD1000II::setGasRatio(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
    int temp =(int)(dValue);
    if(nChannelNum == 1)
    {
        m_cTemp1 = temp;
        m_cBuffer[2] = temp & 0xff;
    }
    else if(nChannelNum == 2)
    {
        m_cTemp2 = temp;
        m_cBuffer[3] = temp & 0xff;
    }
    else if(nChannelNum == 3)
    {
        m_cTemp3 = temp;
        m_cBuffer[4] = temp & 0xff;
    }
    m_nSum = m_cTemp2 + m_cTemp3;
    //if(abs(m_nSum - m_dFullScale) < 4)
    if(abs(m_nSum - 100) < 4)
    {
        m_cTemp3 = m_cTemp3 + 100 - m_nSum;
        m_cBuffer[4] = m_cTemp3 & 0xff;

        return m_deviceNet->writeByte(m_macID, m_cBuffer);
    }
    return true;
}

bool DNetFFD1000II::getGasRatio(int nChannelNum, double *pValue,const DoubleTypeInfo &typeInfo )
{
    int t_maxGasFlow = typeInfo.getMax();
    int inputBytes = m_deviceNet->getIBytesSize(m_macID);
    char buffer[inputBytes];
    memset(buffer, 0, inputBytes);
    m_deviceNet->readByte(m_macID, buffer);

    int temp = 0;

    if(nChannelNum ==4)
    {
        temp = buffer[0] &0xff;
    }
    else if(nChannelNum ==5)
    {
        temp = buffer[1] &0xff;
    }
    else if(nChannelNum ==6)
    {
        temp = buffer[2] &0xff;
    }

    if(temp < 0)
    {
        *pValue = 0;
    }
    else
    {
        *pValue =(double)(temp);
    }
    return true;
}

bool DNetFFD1000II::getGasFlow(int nChannelNum, double *pValue,const DoubleTypeInfo &typeInfo )
{
    int t_maxGasFlow = typeInfo.getMax();
    int inputBytes = m_deviceNet->getIBytesSize(m_macID);
    char buffer[inputBytes];
    memset(buffer, 0, inputBytes);
    m_deviceNet->readByte(m_macID, buffer);

    int temp = 0;
    if(nChannelNum ==7)
    {
        temp = (buffer[4] &0xff) + ((buffer[5] << 8) & 0xff00);
        m_dTemp1 = (double)temp;
    }
    else if(nChannelNum ==8)
    {
        temp = (buffer[6] &0xff) + ((buffer[7] << 8) & 0xff00);

        m_dTemp2 = (double)temp;
    }
    else if(nChannelNum ==9)
    {
        temp = (buffer[8] &0xff) + ((buffer[9] << 8) & 0xff00);

        m_dTemp3 = (double)temp;
    }
    if(temp < 0)
    {
        *pValue = 0;
    }
    else
    {
        *pValue =(double)(temp);
    }
    return true;
}

bool DNetFFD1000II::setZeroAdjust(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
    if(nChannelNum == 12)
    {
        m_cTemp1 = nValue;
        m_cBuffer[1] = m_cTemp1 & 0xff;
    }
    return m_deviceNet->writeByte(m_macID, m_cBuffer);
}

bool DNetFFD1000II::getZeroStatus(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
    int t_service = 28;
    int t_class = 49;
    int t_instance = 1;
    int t_datasizein = 1;
    char t_bufferin[512];
    memset(t_bufferin, 0, 512);
    t_bufferin[0] = 0x1C;
    int t_datasizeout = 1;
    char t_bufferout[512];
    memset(t_bufferout, 0, 512);
    m_deviceNet->readExplicit(m_macID, t_bufferin, t_service,t_class, t_instance ,t_datasizein, t_bufferout, &t_datasizeout);
    *pValue = (int)t_bufferout[0];
    if(*pValue < 2)
    {
        return true;
    }
    else
    {
        return false;
    }
}

void DNetFFD1000II::init()
{
    DeviceNode<DNetFFD1000II> *node = new DeviceNode<DNetFFD1000II>(m_pollInterval,this);
    DeviceManager::getInstance()->registerNode(m_nodeNum, node);
    if(!isSimulated())
    {
        node->registerWriteCh(1, &DNetFFD1000II::setGasRatio);//centerW
        node->registerWriteCh(2, &DNetFFD1000II::setGasRatio);//middleW
        node->registerWriteCh(3, &DNetFFD1000II::setGasRatio);//edgeW
        node->registerReadCh(4, &DNetFFD1000II::getGasRatio);//centerR
        node->registerReadCh(5, &DNetFFD1000II::getGasRatio);//middleR
        node->registerReadCh(6, &DNetFFD1000II::getGasRatio);//edgeR
        node->registerReadCh(7, &DNetFFD1000II::getGasFlow);//centerflow
        node->registerReadCh(8, &DNetFFD1000II::getGasFlow);//middleflow
        node->registerReadCh(9, &DNetFFD1000II::getGasFlow);//edgeflow
        node->registerReadCh(10, &DNetFFD1000II::getStatus);//status
        node->registerReadCh(11, &DNetFFD1000II::getZeroStatus);//Zero status
        node->registerWriteCh(12, &DNetFFD1000II::setZeroAdjust);//ZeroAdjust
        initDeviceNet();
    }
}

IMPLEMENT_DYNAMIC(DNetFFD1000II, IODevice )
BEGIN_MSG_MAP( DNetFFD1000II, IODevice )
    SET_I(setFullScale, DNetFFD1000II)
END_MSG_MAP


