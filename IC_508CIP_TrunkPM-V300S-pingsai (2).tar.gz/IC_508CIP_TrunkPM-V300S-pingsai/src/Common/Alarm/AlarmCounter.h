/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AlarmIDAssigner.h
** Description: 
** Release: 
** Modification history: 
**                   2010-10-19   lijj create
**      
***************************************************************************/
#ifndef ALARMCOUNTER_H_
#define ALARMCOUNTER_H_

#include "ReadWriteInt.h"
#include "AlarmObserver.h"
#include "AppCondition.h"
#include "BlockingAlarm.h"
#include "EnergyLeakingBottle.h"// [lvjw 1.1.16]
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::ALARM;
using namespace IAP::CORE;
using namespace IAP::CONDITION;
#endif

#ifdef IAP4_0
class AlarmCounter:public AlarmObserver,public ManagedObject,public IEnergyLeakingBottleEmptyListener
#else
class AlarmCounter:public AlarmObserver,public IEnergyLeakingBottleEmptyListener
#endif
{
	private:
		static AlarmCounter *m_instance;
		ReadWriteInt *m_fatalAlmExist;
		ReadWriteInt *m_errorAlmExist;
		ReadWriteInt *m_problemAlmExist;// [lvjw 1.1.16]
		ReadWriteInt *m_blockAlmExist;//added by mujy [2.0.4.2]

		BlockingAlarm *m_pBlockingAlarm;

		ReadWriteInt *m_pAlarmStatusForJob;// [lvjw 1.1.16]

		int m_fatalAlmCount;
		int m_errorAlmCount;
		int m_problemAlmCount;// [lvjw 1.1.16]
		int m_nBlockAlmCount;
		//OperationalProcess *m_processModule;
		//ReadWriteInt *m_processStatus;
	
	private:

		AlarmCounter(const AlarmCounter& pObj); //modified by chenw [1.6.0_RC02]

		AlarmCounter& operator=(const AlarmCounter& pObj);

	protected:
		AlarmCounter();

		//bool isProcessing();
		
	public:		
		virtual ~AlarmCounter();
		
		static AlarmCounter* getInstance();
		
		virtual void make();
		
		virtual void initialize();
		
		virtual void updateFromAlarm(Alarm *alarm, bool flag, const std::string &timeStamp);
		
		virtual void updateFromRecovery(Alarm *alarm, Recovery *recovery, bool flag, const std::string &timeStamp);	
		
		ReadWriteInt* getFatalAlmExistData()const;
		
		ReadWriteInt* getErrorAlmExistData()const;
		
		ReadWriteInt* getProblemAlmExistData()const;// [lvjw 1.1.16]

		AppConditionPtr getFatalAlmExistCon()const;
		
		//void setProcessModule(OperationalProcess *processModule);
		
		bool hasFatalAlarm();
		
		bool hasErrorAlarm();

		bool hasProblemAlarm();// [lvjw 1.1.16]

		void onAllErrorFatalAlarmCleared();// [lvjw 1.1.16]
		void onNewErrorFatalAlarmPost();// [lvjw 1.1.16]

		void onAllProblemAlarmCleared();// [lvjw 1.1.16]
		void onNewProblemAlarmPost();// [lvjw 1.1.16]

		void onAllErrorFatalAlarmCleared5Seconds();// [lvjw 1.1.16]

	public:
		virtual void onEnergyLeakingBottleEmpty() ;// [lvjw 1.1.16]

	protected:// [lvjw 1.1.16]
		virtual void onFatalAlmIncrease();
		virtual void onErrorAlmIncrease();
		virtual void onProblemAlmIncrease();

		virtual void onFatalAlmDecrease();
		virtual void onErrorAlmDecrease();
		virtual void onProblemAlmDecrease();

	private:
		EnergyLeakingBottle * m_pEnergyLeakingBottle;

};

#endif /*ALARMCOUNTER_H_*/
