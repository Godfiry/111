/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: CheckItem.h
** Description: 
** Release: 1.1
** Modification history: 
**						2016-11-2		lvjw		Created
**      
*********************************************************************/


#ifndef LOGGER_H_
#define LOGGER_H_

#include "SysLogger.h"
#include <list>
#include <map>
#ifdef IAP4_0
#include "ITime.h"
#else
#include "Time.h"
#endif
#include <unistd.h>  //add by wzd 1.1.39
#ifdef IAP4_0
using namespace IAP::CORE;
#endif
using namespace std;

#ifdef Debug
#define DisplayLog true
#else
#define DisplayLog false
#endif

class CBase
{
public:
	CBase();
	virtual ~CBase();

public:

	static void Log_Info(const std::string &strMsg);
	static void Log_Error(const std::string &strMsg);
	static void Log_Debug(const std::string &strMsg);
	static void Log_Show(const std::string &strMsg,bool bPrintTime = true);
	
	static void Log_Info(const char * pMsg , ...);
	static void Log_Error(const char * pMsg , ...);
	static void Log_Debug(const char * pMsg , ...);
	
	//static void Log(LEVEL::Level l, const std::string &msg);
	//static void Log(LEVEL::Level l, const char * pMsg , ...);
	static std::string str(int nID);
};

#endif /*LOGGER_H_*/
