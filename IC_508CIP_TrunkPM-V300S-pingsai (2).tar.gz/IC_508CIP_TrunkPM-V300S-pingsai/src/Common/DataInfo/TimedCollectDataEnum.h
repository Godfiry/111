#ifndef TIMEDCOLLECTDATAENUM_H_
#define TIMEDCOLLECTDATAENUM_H_
       
namespace TIMEDCOLLECTDATA
{
	enum TimedCollectDataEnum
	{
		UnInit=-1,
		Stop=0,
		Collect=1
	};
}

#endif /*TIMEDCOLLECTDATAENUM_H_*/
