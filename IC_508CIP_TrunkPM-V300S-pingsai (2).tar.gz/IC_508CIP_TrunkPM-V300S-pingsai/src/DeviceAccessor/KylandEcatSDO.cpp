/*
 * KylandEcatSDO.cpp
 *
 *  Created on: 2024��4��9��
 *      Author: zhangcx
 */


#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif


#include "KylandEcatSDO.h"
#include "ConfigException.h"

#include "SHMInitInstance.h"
#include "DeviceNode.h"
#include "DeviceManager.h"
#include "SysLogger.h"
#include "Converter.h"
#include "Hex.h"
#include "EtherCatToSerial.h"

#include <iostream>
#include <unistd.h>
#include <string.h>
#include "shmlib.h"

#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
using namespace IAP;
#endif

KylandEcatSDO::KylandEcatSDO()
{
	m_nNodeNum = 0;
	m_nPollInterval = 200;
	m_nTimeOut = -1;
}

KylandEcatSDO::~KylandEcatSDO()
{


}

void KylandEcatSDO::loadDevice()
{
	if (!SHMInitInstance::getInstance().InitEcatSHM())
	{
		printf("Init fail, reason : %s", GetErrorStr());
	}
}

void KylandEcatSDO::init()
{
	DeviceNode<KylandEcatSDO>* node = new DeviceNode<KylandEcatSDO>(m_nPollInterval, this);
	DeviceManager::getInstance()->registerNode(m_nNodeNum, node);


	if (!isSimulated())
	{

		initChs(node);

		loadDevice();
	}
}


void KylandEcatSDO::initChs(DeviceNode< KylandEcatSDO>* node)
{
	for (int i = 0; i < m_vSDOParam.size(); ++i)
	{
		if (m_vSDOParam[i].m_nRW == 0)
		{
			if (m_vSDOParam[i].m_nLength == 14)
			{
				node->registerReadCh(m_vSDOParam[i].m_nChannel, &KylandEcatSDO::readDouble);
				m_vSDOParam[i].m_nLength = 4;
			}
			else
			{
				node->registerReadCh(m_vSDOParam[i].m_nChannel, &KylandEcatSDO::readInt);
			}
		}
		if (m_vSDOParam[i].m_nRW == 1)
		{
			if (m_vSDOParam[i].m_nLength == 14)
			{
				node->registerWriteCh(m_vSDOParam[i].m_nChannel, &KylandEcatSDO::writeDouble);
				m_vSDOParam[i].m_nLength = 4;
			}
			else
			{
				node->registerWriteCh(m_vSDOParam[i].m_nChannel, &KylandEcatSDO::writeInt);
			}
		}
	}
}

bool KylandEcatSDO::sendSDOToDevice(int nChannel, unsigned char* pdata)
{
	SDOParam SDOParamTemp = findSDOParam(nChannel);

	int SDOState = 0;
	unsigned int num = 5;
	num = EtherCatToSerial::AcquireSDONum();


	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "The nChannel is : " + Converter::convertToString(nChannel));
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "The num is : " + Converter::convertToString(num));
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "The m_nRW is : " + Converter::convertToString(SDOParamTemp.m_nRW));
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "The m_nSlaveAddress is : " + Converter::convertToString(SDOParamTemp.m_nSlaveAddress));
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "The m_nIndex is : " + Converter::convertToString(SDOParamTemp.m_nIndex));
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "The m_charSubindex is : " + Converter::convertToString(SDOParamTemp.m_charSubindex));
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "The m_nLength is : " + Converter::convertToString(SDOParamTemp.m_nLength));


	unsigned int ret = 0;

	int cRet = 100;
	cRet = ky_ecat_dev_state_get(SDOParamTemp.m_nSlaveAddress);
	
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "sendSDOToDevice : The ky_ecat_dev_state_get is : " + Converter::convertToString(cRet));

	ret = ky_ecat_sdo_req(num, SDOParamTemp.m_nRW, SDOParamTemp.m_nSlaveAddress, SDOParamTemp.m_nIndex, SDOParamTemp.m_charSubindex, SDOParamTemp.m_nLength, pdata);

	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "sendSDOToDevice start : The ky_ecat_sdo_req is : ");

	if (S_OK != ret)
	{
		std::string str(1, SDOParamTemp.m_charSubindex);
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
			"Request SDO write failed.Slave Address: '" + Converter::convertToString(SDOParamTemp.m_nSlaveAddress) + "'; Index: '" + Converter::convertToString(SDOParamTemp.m_nIndex) + "'; SubIndex: '" + str + "' ");
		EtherCatToSerial::ReleaseSDONum(num);
		return S_ERROR;
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "sendSDOToDevice end : The ky_ecat_sdo_req is : ");
	
	do
	{
		usleep(10);
		int tempRet = 0;
		tempRet = ky_ecat_sdo_get_rsp(num, &SDOState, pdata);
		if (S_OK != tempRet)
		{
			printf("ky_ecat_sdo_get_rsp fail, return %d\n", tempRet);
			EtherCatToSerial::ReleaseSDONum(num);
			return S_ERROR;
		}
	} while (SDO_STATE_WAITING == SDOState || SDO_STATE_GOING_TO_RESPONE == SDOState);

	if (SDO_STATE_SUCCESS == SDOState)
	{
		if (SDOParamTemp.m_nRW == SDO_READ)
		{
			printf("SDO read success. %x : %d = %ld.\n", SDOParamTemp.m_nIndex, SDOParamTemp.m_charSubindex, pdata);
		}

		else
		{
			printf("SDO write success\n");
		}

		ret = S_OK;
	}
	else
	{
		if (SDOParamTemp.m_nRW == SDO_READ)
		{
			printf("SDO read fail, state = %d\n", SDOState);
		}
		else
		{
			printf("SDO write fail, state = %d\n", SDOState);
		}

		ret = S_ERROR;
	}

	EtherCatToSerial::ReleaseSDONum(num);
	return ret;
}

SDOParam KylandEcatSDO::findSDOParam(int nChannel)
{
	SDOParam SDOParamTemp;
	for (int i = 0; i < m_vSDOParam.size(); ++i)
	{
		if (m_vSDOParam[i].m_nChannel == nChannel)
		{
			return m_vSDOParam[i];
		}
	}

	return SDOParamTemp;
}

bool KylandEcatSDO::writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo& typeInfo)
{
	SDOParam SDOParamTemp = findSDOParam(nChannelNum);
	char* w_data = new char[SDOParamTemp.m_nLength];
	memset(w_data, 0, SDOParamTemp.m_nLength);
	
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "writeDouble : The dValue is : " + Converter::convertToString(dValue));


	float fValue = (float)dValue;
	w_data = (unsigned char*)(&fValue);

	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "writeDouble : The w_data is : " + Converter::convertToString(w_data));


	sendSDOToDevice(nChannelNum, w_data);
	return true;
}

bool KylandEcatSDO::writeInt(int nChannelNum, int nValue, const IntTypeInfo& typeInfo)
{
	SDOParam SDOParamTemp = findSDOParam(nChannelNum);
	char* w_data = new char[SDOParamTemp.m_nLength];
	memset(w_data, 0, SDOParamTemp.m_nLength);

	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "writeInt : The nValue is : " + Converter::convertToString(nValue));

	if (nChannelNum >= 9 && nChannelNum <= 12)
	{
		float fValue = (float)(nValue * 1.0);
		w_data = (unsigned char*)(&fValue);

	}
	else
	{
		w_data = (unsigned char*)(&nValue);
	}

	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "writeInt : The w_data is : " + Converter::convertToString(w_data));

	sendSDOToDevice(nChannelNum, w_data);
	return true;
}

bool KylandEcatSDO::readDouble(int nChannelNum, double* dValue, const DoubleTypeInfo& typeInfo)
{
	SDOParam SDOParamTemp = findSDOParam(nChannelNum);
	char* r_data;
	r_data = new char[SDOParamTemp.m_nLength];
	memset(r_data, 0, SDOParamTemp.m_nLength);
	sendSDOToDevice(nChannelNum, r_data);


	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "readDouble : The r_data is : " + Hex::GetHexString(r_data, 4));

	*dValue = *(float*)r_data;

	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "readDouble : The dValue is : " + Converter::convertToString(dValue));

	//*dValue = atof(r_data);

	return true;
}

bool KylandEcatSDO::readInt(int nChannelNum, int* nValue, const IntTypeInfo& typeInfo)
{
	SDOParam SDOParamTemp = findSDOParam(nChannelNum);
	char* r_data;
	r_data = new char[SDOParamTemp.m_nLength];
	memset(r_data, 0, SDOParamTemp.m_nLength);
	sendSDOToDevice(nChannelNum, r_data);

	if (SDOParamTemp.m_nLength == 1)
	{
		*nValue = (r_data[0] & 0xff);
	}
	if (SDOParamTemp.m_nLength == 2)
	{
		short sTempValue = (short)(((r_data[1] & 0xff) << 8) | (r_data[0] & 0xff));
		*nValue = (int)sTempValue;
	}
	if (SDOParamTemp.m_nLength == 4)
	{
		int data1 = (r_data[0] & 0xff);
		int data2 = (r_data[1] & 0xff);
		int data3 = (r_data[2] & 0xff);
		int data4 = (r_data[3] & 0xff);

		*nValue = (data4 << 24) | (data3 << 16) | (data2 << 8) | data1;
	}

	return true;
}

void KylandEcatSDO::setAddressMap(string strAddress)
{
	vector<string> vList;
	SDOParam SDOParamTemp;
	vList = StrTool::split(strAddress, ",");

	if (vList.size() != 6)
	{
		throw IOException("set SDO param size is wrong");
	}

	int nChannel = 0;
	Converter::stringToInt(nChannel, vList[0]);
	SDOParamTemp.m_nChannel = nChannel;

	int nRW = ("R" == vList[1]) ? 0 : 1;
	SDOParamTemp.m_nRW = nRW;

	int nSlaveAddress = 0;
	Converter::stringToInt(nSlaveAddress, vList[2]);
	SDOParamTemp.m_nSlaveAddress = nSlaveAddress;

	int nIndex = 0;
	sscanf(vList[3].c_str(), "%i", &nIndex);
	SDOParamTemp.m_nIndex = nIndex;

	int nSubindex = 0;

	sscanf(vList[4].c_str(), "0x%x", &nSubindex);
	SDOParamTemp.m_charSubindex = nSubindex;

	int nLength = 0;
	if (vList[5] == "UDINT")
	{
		nLength = 4;
	}
	else if (vList[5] == "USINT")
	{
		nLength = 1;
	}
	else if (vList[5] == "UINT")
	{
		nLength = 2;
	}
	else if (vList[5] == "REAL")
	{
		nLength = 14;
	}
	SDOParamTemp.m_nLength = nLength;

	m_vSDOParam.push_back(SDOParamTemp);


	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "setAddressMap : The m_vSDOParam num is : " + Converter::convertToString(m_vSDOParam.size()));

}

void KylandEcatSDO::setNodeNum(int nNodeNum)
{
	if (nNodeNum < 0)
	{
		throw ConfigException("IODevice: illegal nNodeNum");
	}
	m_nNodeNum = nNodeNum;
}

void KylandEcatSDO::setTimeOut(int nTime)
{
	m_nTimeOut = nTime;
}

void KylandEcatSDO::setPollIntervalMS(int nInterval)
{
	m_nPollInterval = nInterval;
}

IMPLEMENT_DYNAMIC(KylandEcatSDO, AbstractDevice)
BEGIN_MSG_MAP(KylandEcatSDO, AbstractDevice)
	SET_I(setTimeOut, KylandEcatSDO)
	SET_I(setNodeNum, KylandEcatSDO)
	SET_I(setPollIntervalMS, KylandEcatSDO)
	SET_V(init, KylandEcatSDO)
	SET_S(setAddressMap, KylandEcatSDO)
END_MSG_MAP
