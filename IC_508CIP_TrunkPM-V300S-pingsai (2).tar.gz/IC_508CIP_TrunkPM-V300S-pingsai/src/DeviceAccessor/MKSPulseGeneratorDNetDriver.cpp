/********************************************************************
** Copyright (c) 2018, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MKSPulseGeneratorDNetDriver.cpp
** Description: Product Specification 400KHz,1.5KW,Pulsing RF Generator MKS Model Number EDGE 15R40A-D02
*                Device Net
* 		 BaudRate:125
*       MacID:                      
** Release: 1.1
** Modification history: 
** 					2018-9-6   mujy create
**      
*********************************************************************/

#include "MKSPulseGeneratorDNetDriver.h"
#include "DeviceManager.h"
#include <iostream>
#include <sys/time.h>
#include <sstream>
#include <string.h>
#include "Converter.h"
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
#endif
using namespace std;

MKSPulseGeneratorDNetDriver::Com MKSPulseGeneratorDNetDriver::m_Commands[] = {{0, 0}, //0	reserved 	
											{12,0},//1.Byte12,Bit0 is Turn the RF output On/off
											{0,0},//reserve
											{12,7},//3.Byte12,Bit7,Reset generator faults and warning					
											{12,1},//4.Byte12,Bit 1,Level mode: 0 is Forward,1 is Load
											{13,0},//5.Byte13,Bit 0,turn pulsing:0 is Off,1 is on
											{0,0},//6.Byte0 and Byte1,set the power setpoint in watts to x, for 
											{0,0},//7.Byte0 and Byte1,set the power setpoint in watts to x
											{4,0},//8,Byte4 and Byte5,set Pulse Frequency
											{6,0},//9.Byte6 and Byte7,set Pulse Duty
											//-----------------------------------------------------------------------------------
											{0,0},//10.Byte0 and Byte1,get output forward power
											{2,0},//11.Byte2 and Byte3,get output reverse power
											{32,0},//12.Byte32 and Byte33,get Frequece
											{34,0},//13.Byte34 and Byte35,get Duty	
											{42,6},//14.Byte42,Bit6 and Bit 7,Warn/Fault Status
											{42,0},//15.Byte42,Bit0,Power On Status
											{43,0},//16.Byte43,Bit 0,LevelModeStatus: 0 is Forward,1 is Load
											{44,0}//17.Byte44,Bit1 and Bit 0,Pulse Mode Status
};
MKSPulseGeneratorDNetDriver::MKSPulseGeneratorDNetDriver()
{
	m_pWriteBuffer = NULL;
	m_pReadBuffer = NULL;
	
	m_nLastLevelMode = 0;
	m_nLastPulseMode = 0;
	m_nLastRFOnOffControl = 0;
}

MKSPulseGeneratorDNetDriver::~MKSPulseGeneratorDNetDriver()
{
	if(m_pWriteBuffer != NULL)
	{
		delete m_pWriteBuffer;
		m_pWriteBuffer = NULL;
	}
	if(m_pReadBuffer != NULL)
	{
		delete m_pReadBuffer;
		m_pReadBuffer = NULL;
	}
}
				
bool MKSPulseGeneratorDNetDriver::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
	Com com = m_Commands[nChannelNum];

	unsigned char bitmask = 1;
	bitmask = bitmask << com.m_nBit;
	
	if(nValue == 1)
	{
		m_pWriteBuffer[com.m_nByte] = m_pWriteBuffer[com.m_nByte] | bitmask;
	}
	if(nValue == 0)
	{
		bitmask = ~bitmask;
		m_pWriteBuffer[com.m_nByte] = m_pWriteBuffer[com.m_nByte] & bitmask;
	}
	return m_deviceNet->writeByte(m_macID, m_pWriteBuffer);	
}
	
bool MKSPulseGeneratorDNetDriver::writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
	Com com = m_Commands[nChannelNum];	
	unsigned long temp;
	if(nChannelNum == 6 || nChannelNum == 7)//set power
	{
		//temp = (unsigned long) (dValue * 4095.0 / typeInfo.getMax());
		temp = (unsigned long) (dValue);
	}
	else if(nChannelNum == 8)//set Pulse Frequency
	{
		temp = (unsigned long) (dValue);
	}
	else if (nChannelNum == 9)//set Pulse Duty
	{
		temp = (unsigned long) (dValue * 10.0);//0x0000-0x03E8 ,representing a value from 0-100.0%
	}
	else
	{
		return false;
	}
	
	m_pWriteBuffer[com.m_nByte] = (unsigned char)(temp & 0xff);
	m_pWriteBuffer[com.m_nByte + 1] = (unsigned char)((temp>>8) & 0xff);
	return m_deviceNet->writeByte(m_macID, m_pWriteBuffer);
}	
	
bool MKSPulseGeneratorDNetDriver::readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
	Com com = m_Commands[nChannelNum];

	//memset(m_pReadBuffer, 0, m_deviceNet->getIBytesSize(m_macID));
	m_deviceNet->readByte(m_macID, m_pReadBuffer);
	unsigned int movebit = 1 << com.m_nBit;
	unsigned int temp = ((unsigned int)m_pReadBuffer[com.m_nByte]) & movebit;
	int nTempValue = temp >> com.m_nBit;
	if(nTempValue == 0 || nTempValue == 1)
	{
		*pValue = nTempValue;
		return true;
	}
	else
	{
		return false;
	}
}
		
bool MKSPulseGeneratorDNetDriver::readDouble(int nChannelNum, double *dValue, const DoubleTypeInfo &typeInfo)
{
	Com com = m_Commands[nChannelNum];
	//memset(m_pReadBuffer, 0, m_deviceNet->getIBytesSize(m_macID));
	m_deviceNet->readByte(m_macID, m_pReadBuffer);
	unsigned long temp=0;
	double dTempValue = 0;
	temp = (((unsigned long)m_pReadBuffer[com.m_nByte]) & 0xff) + ((((unsigned long)m_pReadBuffer[com.m_nByte+1]) << 8) & 0xff00);
	if(nChannelNum == 10 || nChannelNum == 11)//get power
	{
		//*dValue = temp * typeInfo.getMax() / 4095.0;
		dTempValue = temp;
	}
	else if(nChannelNum == 12)//get Pulse Frequency
	{
		dTempValue = temp;
	}
	else if (nChannelNum == 13)//get Pulse Duty
	{
		dTempValue = temp / 10.0;//0x0000-0x03E8 ,representing a value from 0-100.0%
		
	}
	else
	{
		return false;
	}
	*dValue = MathTool::Round(dTempValue,typeInfo.getAccuracy());
	return true;
}

void MKSPulseGeneratorDNetDriver::InitChannels(DeviceNode<MKSPulseGeneratorDNetDriver> *node)
{
	for(int i = 1; i <= 5; ++i)
	{
		node->registerWriteCh(i, &MKSPulseGeneratorDNetDriver::writeInt);
	}
	for(int i = 6; i <= 9; ++i)
	{
		node->registerWriteCh(i, &MKSPulseGeneratorDNetDriver::writeDouble);
	}
	for(int i = 10; i <= 13; ++i)
	{
		node->registerReadCh(i, &MKSPulseGeneratorDNetDriver::readDouble);
	}
	for(int i = 14; i <= 17; ++i)
	{
		node->registerReadCh(i, &MKSPulseGeneratorDNetDriver::readInt);
	}
	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &MKSPulseGeneratorDNetDriver::getStatus);
}

void MKSPulseGeneratorDNetDriver::initDevice()
{	
	int nInBytesSize = m_deviceNet->getIBytesSize(m_macID);
	int nOutBytesSize = m_deviceNet->getOBytesSize(m_macID);
	
	m_pWriteBuffer = new char[nOutBytesSize];
	memset(m_pWriteBuffer, 0, nOutBytesSize);
	
	m_pReadBuffer = new char[nInBytesSize];
	memset(m_pReadBuffer, 0, nInBytesSize);
}
		
void MKSPulseGeneratorDNetDriver::init()
{
	DeviceNode<MKSPulseGeneratorDNetDriver> *pNode = new DeviceNode<MKSPulseGeneratorDNetDriver>(m_pollInterval, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
	if(!isSimulated())
	{
		InitChannels(pNode);
		initDeviceNet();
		initDevice();
	}
}
IMPLEMENT_DYNAMIC(MKSPulseGeneratorDNetDriver, IODevice )
BEGIN_MSG_MAP(MKSPulseGeneratorDNetDriver, IODevice )
    SET_V( init, MKSPulseGeneratorDNetDriver )
END_MSG_MAP

