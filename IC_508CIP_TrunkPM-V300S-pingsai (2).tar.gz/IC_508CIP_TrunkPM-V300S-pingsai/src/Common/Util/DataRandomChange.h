/************************************************************************************
** Copyright (c) 2026, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: DataRandomChange.h
** Description: This file includes declaration of class DataRandomChange.          
** Release: 1.2
** Modification history: 
* 					2026-4-16
*************************************************************************************/



#ifndef SRC_COMMON_UTIL_DATARANDOMCHANGE_H_
#define SRC_COMMON_UTIL_DATARANDOMCHANGE_H_

#include "ControlObjectEX.h"
#include "Subscriber.h"
#include "Service.h"
#include "ReadOnlyData.h"
#include "AppCondition.h"
#include "Timer.h"
#include "IThread.h"
#include <vector>
#include <string>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CONTROL;
using namespace IAP::ALARM;
using namespace IAP::CORE;
using namespace IAP::CONDITION;
#endif

struct RandomDataStruct
{
	UntypedData * pRandomDataSP;
	UntypedData * pRandomDataSensor;
	double dRandomRange;
};

namespace DATACHANGERAMDOMMODE
{
    enum RandomMode
    {
	Process,
	Idle
    };
}	
class DataRandomChange : public ControlObjectEX,public IThread
{
	DECLARE_DYNAMIC( DataRandomChange )
	DECLARE_MSG_MAP
	DECLARE_SERVICEINFO_LIST
	
	class  RandomUp: public Service
	{
		DECLARE_DYNAMIC_SERVICE(RandomUp)
			
			public:
				void execute();	
	};
	class  RandomDown: public Service
	{
		DECLARE_DYNAMIC_SERVICE(RandomDown)
			
			public:
				void execute();	
	};
	
	public:
		DataRandomChange();
		virtual ~DataRandomChange();
		
	public://xml
		void setIntervalMS(int nMillSecond);
		void addRandomDataCh(const std::string &strRandomSPPath, const std::string &strRandomSensorPath,double dRange);
		void setRandomMode(string strMode);

	protected:
		virtual void do_RandomUp(int nIntervalMs);
		virtual void do_RandomDown();
		virtual void make();
		virtual void startup();
		virtual void shutdown();
        virtual void run();

	private:
		void startThread();
		void doRandomChange();
	private:
		std::map<int, RandomDataStruct*> m_mapRandomDatas;
		int m_nRandomDataIndex;
		ServicePtr<RandomUp> m_sRandomUp;
		ServicePtr<RandomDown> m_sRandomDown;
		ReadWriteInt *m_pProcessTheRecipeOffOn;
                ReadWriteInt *m_pRandomUp;
		int m_nRandomMode;
		bool m_bThreadStarted;
                
		int m_nIntervalMS;
                bool m_bKeepRun;
};
#endif /*SRC_COMMON_UTIL_DATARANDOMCHANGE_H_*/
