/********************************************************************
** Copyright (c) 2021, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TCPFuXiangEPD.h
** Description:
** Release: 1.0
** Modification history:
** 					2021-11-23   zhangcx create
**
*********************************************************************/
#ifndef TCPFUXIANGEPD_H_
#define TCPFUXIANGEPD_H_

#include "IWaitCondition.h"//[added by wangyk 1.2.4]
#include "TCPDevice.h"
#include "DeviceNode.h"
#include "IntTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
#endif

class TCPFuXiangEPD: public TCPDevice
{
	DECLARE_DYNAMIC(TCPFuXiangEPD)
	DECLARE_MSG_MAP

public:
	TCPFuXiangEPD();
	virtual ~TCPFuXiangEPD();

public://xml config
	void init();
	void setPMName(const std::string &strPMName);

public:
	virtual void acceptData();
	void onReceiveMsg(string strData);
	virtual std::string getDeviceName();

public://interface
	bool writeI(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
	bool readI(int nChannelNum, int *nValue, const IntTypeInfo &typeInfo);
	bool readD(int nChannelNum, double *dValue, const DoubleTypeInfo &typeInfo);
	bool readStr(int nChannelNum, std::string *strCommand, const StringTypeInfo &typeInfo);
	bool writeStr(int nChannelNum, std::string strCommand, const StringTypeInfo &typeInfo);

	bool writeRawCmd(int nChannelNum, std::string strCommand, const StringTypeInfo &typeInfo);
private:
	void InitDevice();
	void InitChannels(DeviceNode<TCPFuXiangEPD> *pNode);

private:
	void Subpackage(string strMassage);
	void dispatchMsg(string strMassage);
	void dealWithMsg(string strMsgCmd, string strMsgData);

private:
	mutable IMutex *m_mutex;//lock data maybe changed by receiving data.
	IWaitCondition m_waitAction;//[added by wangyk 1.2.4]
	string m_strSendCommandReply;//[added by wangyk 1.2.4]

	static string m_Commands[];
	string m_strHead;

	int m_nEndPoint;
	int m_nEndPoint1;//[added by wangyk 1.9.1]
	int m_nEndPoint2;
	double m_dTime;
	double m_dTime1;//[added by wangyk 1.9.1]
	double m_dTime2;
	string m_strCfgList;
	string m_strError;

	string m_strCfg;
	string m_strCfgName;
	string m_strRecipe;
	string m_strStep;
	string m_strLot1;
	string m_strWafer1;
	string m_strPiece1;
	string m_strLot2;
	string m_strWafer2;
	string m_strPiece2;

	double m_dTrendData[6];//[zhangcx v1.1.23]
};

#endif /*TCPFUXIANGEPD_H_*/
