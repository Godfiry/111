/*
 * KylandShmDevice.cpp
 *
 *  Created on: Feb 12, 2025
 *      Author: zhangyy
 */

#include "KylandShmDevice.h"
#include "ConfigException.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#include "DeviceManager.h"
#include "SysLogger.h"
#include "Hex.h"
#include "Converter.h"
#ifdef KYLAND //added by zhangyy [1.6.3]
#include "SHMInitInstance.h"
#endif
#include <iostream>
#include <unistd.h>
#include <string.h>
#include "shmlib.h"
#include <string.h>
KylandShmDevice::KylandShmDevice()
{
	m_nNodeNum = 0;
	m_nPollInterval = 200;
	m_nTimeOut = -1;
	m_dFullScale = 32767;

	m_NoChangeChannel.clear();
}

KylandShmDevice::~KylandShmDevice()
{
	
}

void KylandShmDevice::loadDevice()
{
#ifdef KYLAND //added by zhangyy [1.6.3]
	if(!SHMInitInstance::getInstance().InitSHM())
	{
		printf("Init fail, reason : %s", GetErrorStr());
	}
#else
	// do nothing
#endif
}

void KylandShmDevice::init()
{

	DeviceNode<KylandShmDevice> * node = new DeviceNode<KylandShmDevice>(m_nPollInterval,this);
	DeviceManager::getInstance()->registerNode(m_nNodeNum, node);

	if(!isSimulated())
	{
		memset(SHM_WBool,0,sizeof(SHM_WBool));
		memset(SHM_WDint,0,sizeof(SHM_WDint));
		memset(SHM_WReal,0,sizeof(SHM_WReal));
		memset(SHM_RBool,0,sizeof(SHM_RBool));
		memset(SHM_RDint,0,sizeof(SHM_RDint));
		memset(SHM_RReal,0,sizeof(SHM_RReal));
		initChs(node);
		loadDevice();
		//loadRecipeParam();
	}
}

//void KylandShmDevice::loadRecipeParam()
//{
//	if(m_strPLCRecipeAssistantPath == "")
//	{
//		throw AbortException("not config PLCRecipeAssistant");
//	}
//
//	if(!m_mapRecipeData.count("EveryChildRecipeTotalCycleNum"))
//	{
//		throw AbortException("not config 'EveryChildRecipeTotalCycleNum' in xml addRecipeParam method.");
//	}
//
//	if(!m_mapRecipeData.count("EveryChildRecipeTotalStepNum"))
//	{
//		throw AbortException("not config 'EveryChildRecipeTotalStepNum' in xml addRecipeParam method.");
//	}
//}

void KylandShmDevice::initChs(DeviceNode< KylandShmDevice> *pNode)
{
	for(int i = 15001; i <= 20000; i++)
	{
		pNode->registerWriteCh(i, & KylandShmDevice::writeInt);//channel 15001~20000
	}

	for(int i = 20001; i <= 25000; i++)
	{
		pNode->registerWriteCh(i, & KylandShmDevice::writeInt);//channel 20001~25000
	}
	for(int i = 25001; i <= 30000; i++)
	{
		pNode->registerWriteCh(i, & KylandShmDevice::writeDouble);//channel 25001~30000
	}


	for(int i = 1; i <= 5000; i++)
	{
		pNode->registerReadCh(i, & KylandShmDevice::readInt);//channel 1~5000
	}
	for(int i = 5001; i <= 10000; i++)
	{
		pNode->registerReadCh(i, & KylandShmDevice::readInt);//channel 5001~10000
	}
	for(int i = 10001; i <= 15000; i++)
	{
		pNode->registerReadCh(i, & KylandShmDevice::readDouble);//channel 10001~15000
	}
}

bool KylandShmDevice::writeShm(char *pBlockName, unsigned int pBlockSize, void * pData)
{
#ifdef KYLAND //added by zhangyy [1.6.3]
	IMutexLocker locker(&m_lock);
	if(KY_SHM_OK != WriteFromMemory(pBlockName, pBlockSize, pData))
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + " writeShm WriteFromMemory failed, error is " + GetErrorStr());
		return KY_SHM_ERROR;
	}
	usleep(2000);
	if(KY_SHM_OK != SetDataToMemory())
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + " writeShm SetDataToMemory failed, error is " + GetErrorStr());
		return KY_SHM_ERROR;
	}
	usleep(2000);
#endif
	return true;

}

bool KylandShmDevice::readShm(char * pBlockName, unsigned int pBlockSize, void * pData)
{
#ifdef KYLAND //added by zhangyy [1.6.3]
	IMutexLocker locker(&m_lock);

	if(KY_SHM_OK != GetDataFromMemory())
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + " readShm GetDataFromMemory failed, error is " + GetErrorStr());
		return KY_SHM_ERROR;
	}
	if(KY_SHM_OK != ReadFromMemory(pBlockName, pBlockSize, pData))
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + " readShm ReadFromMemory failed, error is " + GetErrorStr());
		return KY_SHM_ERROR;
	}
#endif
	return true;
}

bool KylandShmDevice::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
#ifdef KYLAND //added by zhangyy [1.6.3]
	int nNum = 0;
	if(nChannelNum >= 15001 && nChannelNum <= 20000)//Bool
	{
		nNum = nChannelNum-15001;
		SHM_WBool[nNum] = nValue;
		writeShm("SHM_WBool", sizeof(SHM_WBool), &SHM_WBool);
	}
	else if(nChannelNum >= 20001 && nChannelNum <= 25000)
	{
		nNum = nChannelNum-20001;
		SHM_WDint[nNum] = nValue;
		writeShm("SHM_WDint", sizeof(SHM_WDint), &SHM_WDint);
	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + " in writeInt function, nChannelNum = " + Converter::convertToString(nChannelNum) + ", is wrong! ");
	}
#endif
	return true;
}

bool KylandShmDevice::writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
#ifdef KYLAND //added by zhangyy [1.6.3]

	double dTempValue = 0;
	if (std::find(m_NoChangeChannel.begin(), m_NoChangeChannel.end(), nChannelNum) != m_NoChangeChannel.end())
	{
		dTempValue = dValue;
	}
	else
	{
		dTempValue = ((dValue / (typeInfo.getMax() - typeInfo.getMin())) + typeInfo.getMin()) * m_dFullScale;
	}

	//cout<<"write AO channelNum ="<<nChannelNum<<endl;
	//cout<<"AO after change = "<<dTempValue<<endl;
	int nNum = 0;
	if(nChannelNum >= 25001 && nChannelNum <= 30000  )//Real
	{
		nNum = nChannelNum-25001;

		SHM_WReal[nNum] = dTempValue;
		writeShm("SHM_WReal", sizeof(SHM_WReal), &SHM_WReal);
	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + " in writeDouble function, nChannelNum = " + Converter::convertToString(nChannelNum) + ", is wrong! ");
	}
#endif
	return true;
}

bool KylandShmDevice::readInt(int nChannelNum, int* nValue, const IntTypeInfo& typeInfo)
{


#ifdef KYLAND //added by zhangyy [1.6.3]

	int nNum = 0;
	int nTempValue;
	if (nChannelNum >= 1 && nChannelNum <= 5000)//Read Bool
	{
		readShm("SHM_RBool", sizeof(SHM_RBool), &SHM_RBool);
		nNum = nChannelNum - 1;
		*nValue = SHM_RBool[nNum];
	}
	else if (nChannelNum >= 5001 && nChannelNum <= 10000)
	{
		readShm("SHM_RDint", sizeof(SHM_RDint), &SHM_RDint);
		nNum = nChannelNum - 5001;
		nTempValue = SHM_RDint[nNum];
		if (nChannelNum >= 5401 && nChannelNum <= 5417)//need convert ECAT Mc State
		{
			if (nTempValue & 0x0001)
			{
				nTempValue = 0;//INIT
			}
			else if (nTempValue & 0x0002)
			{
				nTempValue = 1;//PREOP
			}
			else if (nTempValue & 0x0003)
			{
				nTempValue = 2;//BOOT
			}
			else if (nTempValue & 0x0004)
			{
				nTempValue = 3;//SAFEOP
			}
			else if (nTempValue & 0x0008)
			{
				nTempValue = 4;//OP
			}
			else if (nTempValue & 0x0010)
			{
				nTempValue = 5;//SlaveSignalError
			}
			else if (nTempValue & 0x0020)
			{
				nTempValue = 6;//InvalidVendorId
			}
			else if (nTempValue & 0x0040)
			{
				nTempValue = 7;//InitError
			}
			else if (nTempValue & 0x0080)
			{
				nTempValue = 8;//SlaveDisabled
			}
			else if (nTempValue & 0x0100)
			{
				nTempValue = 9;//SlaveNotPresent
			}
			else if (nTempValue & 0x0200)
			{
				nTempValue = 10;//SignalLinkError
			}
			else if (nTempValue & 0x0400)
			{
				nTempValue = 11;//SignalMissingLink
			}
			else if (nTempValue & 0x0800)
			{
				nTempValue = 12;//UnexpectedLink
			}
			else if (nTempValue & 0x1000)
			{
				nTempValue = 13;//CommPortA
			}
			else if (nTempValue & 0x2000)
			{
				nTempValue = 14;//CommPortB
			}
			else if (nTempValue & 0x4000)
			{
				nTempValue = 15;//CommPortC
			}
			else if (nTempValue & 0x8000)
			{
				nTempValue = 16;//CommPortD
			}

		}
		else
		{
			*nValue = nTempValue;
		}

	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + " in readInt function, nChannelNum = " + Converter::convertToString(nChannelNum) + ", is wrong! ");
	}
#endif
	return true;
}

bool KylandShmDevice::readDouble(int nChannelNum, double *dValue, const DoubleTypeInfo &typeInfo)
{
#ifdef KYLAND //added by zhangyy [1.6.3]
	int nNum = 0;
	double dTempValue =0;
	if(nChannelNum >= 10001 && nChannelNum <= 15000 )
	{
		//cout<<"nChannelNum = "<<(int)nChannelNum<<endl;
		readShm("SHM_RReal", sizeof(SHM_RReal), &SHM_RReal);
		nNum = nChannelNum-10001;
		//cout<<"nNum = "<<nNum<<endl;
		//cout<<"read AI channelNum ="<<nChannelNum<<endl;
		//cout<<" AI Value = "<<SHM_RReal[nNum]<<endl;

		if (std::find(m_NoChangeChannel.begin(), m_NoChangeChannel.end(), nChannelNum) != m_NoChangeChannel.end())
		{
			dTempValue = SHM_RReal[nNum];
		}
		else
		{
			dTempValue = SHM_RReal[nNum] * (typeInfo.getMax() - typeInfo.getMin()) / m_dFullScale + typeInfo.getMin();
		}


		*dValue = dTempValue;
	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + " in readDouble function, nChannelNum = " + Converter::convertToString(nChannelNum) + ", is wrong! ");
	}
#endif
	return true;
}

//bool KylandShmDevice::writeRecipe(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
//{
//	if (!isConnected())
//	{
//		throw IOException("device is not connected! ");
//	}
//	IMutexLocker locker(m_mutex);
//
//	int nDataNum = 0;
//	int nDataByteNum = 0;
//	unsigned long nData = 0;
//	map<std::string, Param>::iterator it = m_mapRecipeData.begin();
//	if(m_pPLCRecipeAssistant == NULL)
//	{
//		throw IOException("PLCRecipeAssistant is NULL");
//	}
//
//	//-------------------------------------------
//	/*composeWriteCommandHead(m_mapRecipeData["TotalChildRecipeNum"].m_nAddr, 2);
//	int nChildRecipeTotalNum = m_pPLCRecipeAssistant->getChildRecipeTotalNum();
//	SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::EVENT,getName()+": set TotalChildRecipeNum start..."+Converter::convertToString(nChildRecipeTotalNum));
//	m_pModbusSend[13] = (nChildRecipeTotalNum & 0xFF00) >> 8;
//	m_pModbusSend[14] = (nChildRecipeTotalNum & 0x00FF);
//
//	sendCommand(m_pModbusSend,15);
//	if(m_waitAction.wait(m_mutex, 5000))
//	{
//		bool bResult = parseWriteResponse();
//		if(!bResult)
//		{
//			throw IOException("[!Communication Error]-[PC->PLC]-[writeRecipe] send TotalChildRecipeNum to PLC failed for unknown response.");
//		}
//	}
//	else
//	{
//		Log_Error("PC->PLC  send TotalChildRecipeNum to PLC failed for wait response time out");
//		throw IOException("[!Communication Error]-[PC->PLC]-[writeRecipe] send TotalChildRecipeNum to PLC failed for wait response time out.");
//	}
//	SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::EVENT,getName()+": set TotalChildRecipeNum end.");*/
//	//------------------------------------------------
//
//	SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::EVENT,getName()+": set EveryChildRecipeTotalCycleNum start...");
//
//	int nChildRecipeTotalCycleNum = m_pPLCRecipeAssistant->getEveryChildRecipeTotalCycleNum();
//	
//	composeWriteCommandHead(m_mapRecipeData["EveryChildRecipeTotalCycleNum"].m_nAddr, 2);
//	//for(int i = 0 ; i < nDataNum; i++)
//	//{
//		m_pModbusSend[13] = (nChildRecipeTotalCycleNum & 0xFF00) >> 8;
//		m_pModbusSend[14] = nChildRecipeTotalCycleNum & 0x00FF;
//	//}
//	sendCommand(m_pModbusSend,15);
//	if(m_waitAction.wait(m_mutex, 5000))
//	{
//		bool bResult = parseWriteResponse();
//		if(!bResult)
//		{
//			throw IOException("[!Communication Error]-[PC->PLC]-[writeRecipe] send EveryChildRecipeTotalCycleNum to PLC failed for unknown response.");
//		}
//	}
//	else
//	{
//		Log_Error("PC->PLC  send EveryChildRecipeTotalCycleNum to PLC failed for wait response time out");
//		throw IOException("[!Communication Error]-[PC->PLC]-[writeRecipe] send EveryChildRecipeTotalCycleNum to PLC failed for wait response time out.");
//	}
//	SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::EVENT,getName()+": set EveryChildRecipeTotalCycleNum end.");
//
//	//--------------------------------------------------
//	SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::EVENT,getName()+": set EveryChildRecipeTotalStepNum start...");
//	int nChildRecipeTotalStepNum = m_pPLCRecipeAssistant->getChildRecipeTotalStepNum();
//	
//	composeWriteCommandHead(m_mapRecipeData["EveryChildRecipeTotalStepNum"].m_nAddr, 2);
//	//for(int i = 0 ; i < nDataNum; i++)
//	//{
//		m_pModbusSend[13] = (nChildRecipeTotalStepNum & 0xFF00) >> 8;
//		m_pModbusSend[14] = nChildRecipeTotalStepNum & 0x00FF;
//	//}
//	sendCommand(m_pModbusSend,15);
//	if(m_waitAction.wait(m_mutex, 5000))
//	{
//		bool bResult = parseWriteResponse();
//		if(!bResult)
//		{
//			throw IOException("[!Communication Error]-[PC->PLC]-[writeRecipe] send EveryChildRecipeTotalStepNum to PLC failed for unknown response.");
//		}
//	}
//	else
//	{
//		Log_Error("PC->PLC  send EveryChildRecipeTotalStepNum to PLC failed for wait response time out");
//		throw IOException("[!Communication Error]-[PC->PLC]-[writeRecipe] send EveryChildRecipeTotalStepNum to PLC failed for wait response time out.");
//	}
//	SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::EVENT,getName()+": set EveryChildRecipeTotalStepNum end.");
//	//----------------------------------------------------------
//
//	SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::EVENT,getName()+": set every recipe param value start...");
//	for(;it != m_mapRecipeData.end(); ++it)
//	{
//		if(it->first.find("EveryChildRecipeTotalCycleNum") != string::npos)
//		{
//			continue;
//		}
//		if(it->first.find("EveryChildRecipeTotalStepNum") != string::npos)
//		{
//			continue;
//		}
//		std::vector<double> data = m_pPLCRecipeAssistant->getItemArray(it->first);
//		nDataNum = data.size();
//		if(it->second.m_nType == 1)//Int
//		{
//			nDataByteNum = nDataNum * 2;
//			for(int i = 0; i < nDataNum; i++)
//			{
//				nData = (int)data.at(i);
//				m_pModbusSend[13+i*2] = (unsigned char)((nData & 0xFF00 ) >> 8);
//				m_pModbusSend[13+i*2+1] = (unsigned char)(nData & 0x00FF);
//			}
//		}
//		else if(it->second.m_nType == 2)//Double
//		{
//			nDataByteNum = nDataNum * 4;
//			for(int i = 0; i < nDataNum; i++)
//			{
//				double dData = data.at(i);
//
//				unsigned char floatToHex[4];
//				float changesettemp = (float)dData;
//				char* pchar=(char*)&changesettemp;
//				for(int i=0;i<sizeof(float);i++) //4
//				{
//					floatToHex[i]=*pchar;
//					pchar++;
//				}
//
//				m_pModbusSend[13+i*4] = floatToHex[1];
//				m_pModbusSend[13+i*4+1] = floatToHex[0];
//				m_pModbusSend[13+i*4+2] = floatToHex[3];
//				m_pModbusSend[13+i*4+3] = floatToHex[2];
//			}
//		}
//		else
//		{
//			throw IOException("data type is invalid");
//		}
//		SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::EVENT,getName()+": set recipe param "+it->first);
//		composeWriteCommandHead(it->second.m_nAddr, nDataByteNum);
//
//		sendCommand(m_pModbusSend,13+nDataByteNum);
//		
//		SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::EVENT,getName()+": set every parma value "+it->first+" "
//+Hex::GetHexString(m_pModbusSend,13+nDataByteNum));
//
//		if(m_waitAction.wait(m_mutex, 5000))
//		{
//			bool bResult = parseWriteResponse();
//			if(!bResult)
//			{
//				throw IOException("[!Communication Error]-[PC->PLC]-[writeRecipe] send "+it->first+" value to PLC failed for unknown response.");
//			}
//		}
//		else
//		{
//			Log_Error("PC->PLC  send "+it->first+" value to PLC failed for wait response time out.");
//			throw IOException("[!Communication Error]-[PC->PLC]-[writeRecipe] send "+it->first+" value to PLC failed for wait response time out.");
//		}
//		SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::EVENT,getName()+": set every recipe param value end.");
//	}
//
//	return true;
//}

void KylandShmDevice::setNodeNum(int nNodeNum)
{
	if(nNodeNum < 0)
	{
		throw ConfigException("IODevice: illegal nNodeNum");
	}
	m_nNodeNum = nNodeNum;
}

void KylandShmDevice::setTimeOut(int nTime)
{
	m_nTimeOut = nTime;
}

void KylandShmDevice::setPollIntervalMS(int nInterval)
{
	m_nPollInterval = nInterval;
}

void KylandShmDevice::setFullScale(double dFullScale)
{
	m_dFullScale = dFullScale;
}

void KylandShmDevice::setNoChangeChannel(int nNoChangeChannel)
{
	m_NoChangeChannel.push_back(nNoChangeChannel);
}



//void KylandShmDevice::setPLCRecipeAssistant(string strPath)
//{
//	m_strPLCRecipeAssistantPath = strPath;
//}

//void KylandShmDevice::addRecipeParam(string strParamName,int nRegisteAddress,int nParamType)
//{
//	if (m_mapRecipeData.count(strParamName))
//	{
//		throw AbortException("repeat param name ,please check. "+strParamName);
//	}
//	if(nParamType != 1 && nParamType != 2)
//	{
//		throw AbortException("invalid parmp type ,please check. "+strParamName);
//	}
//
//	if(nRegisteAddress > REGISTE_AREA)
//	{
//		nRegisteAddress = nRegisteAddress - REGISTE_AREA;
//	}
//	Param value;
//	value.m_nAddr = nRegisteAddress;
//	value.m_nType = nParamType;
//	m_mapRecipeData.insert(pair<std::string, Param>(strParamName, value));
//}

IMPLEMENT_DYNAMIC(KylandShmDevice, AbstractDevice )
BEGIN_MSG_MAP( KylandShmDevice, AbstractDevice )
	SET_I( setTimeOut, KylandShmDevice )
	SET_I( setNodeNum, KylandShmDevice )
	SET_I( setPollIntervalMS, KylandShmDevice )
	SET_V( init, KylandShmDevice )
	SET_D( setFullScale, KylandShmDevice )
	SET_I(setNoChangeChannel, KylandShmDevice)
	/*SET_S(setPLCRecipeAssistant, KylandShmDevice)
	SET_SII(addRecipeParam,KylandShmDevice)*/
END_MSG_MAP
