/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					Jan 22, 2008  shenql  create 
**      
***************************************************************************/
#ifndef TRANSFEROPERATIONINFO_H_
#define TRANSFEROPERATIONINFO_H_
#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class TransferOperationInfo : public IntValueInfo
{
public:

		static const int UnInit = -1;
		static const int Receive = 0;
		static const int Send = 1;
		static const int Swap = 2;
		static const int Xfer = 3;
		static const IntTypeInfo typeInfo;

	   TransferOperationInfo():IntValueInfo(-1, typeInfo)
	   {
	   }
	
	   TransferOperationInfo(int i):IntValueInfo(i, typeInfo)
	    {
	    }
	
	   TransferOperationInfo(std::string s):IntValueInfo(s, typeInfo)
	    {
	    }
};


#endif /*TRANSFEROPERATIONINFO_H_*/
