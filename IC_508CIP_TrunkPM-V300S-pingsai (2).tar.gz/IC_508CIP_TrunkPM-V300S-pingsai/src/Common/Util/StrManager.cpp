/********************************************************************
** Copyright (c) 2016, Beijing NMC Co.,Ltd. All rights reserved.
** All rights reserved.
**
** File name: StrManager.cpp
**
** Description:
**
** Modification history:
* 							2016.10.31		lvjw	created.
*********************************************************************/

#include "StrManager.h"
#include "SysLogger.h"
#include "Converter.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

using namespace std;



StrManager* StrManager::m_pInstance=NULL;
StrManager::StrManager()
{
}

StrManager::~StrManager()
{
}

bool StrManager::AddString(int nID,const string& strData)
{
	bool bResult=true;
	if(nID<0)
	{
		//throw exception
	}
	if(IsStrExist(nID))
	{
		AddStrErrAction(nID);
		bResult=false;
	}
	m_data[nID]=strData;
	return bResult;
}

bool StrManager::GetString(int nID , string &strData)
{
	if(m_data.count(nID)>0)//nID exist
	{
		strData=m_data[nID];
		return true;
	}
	else
	{
		GetStrErrAction(nID);
		strData="";
		return false;
	}
	
}

string StrManager::GetString(int nID)
{
	if(m_data.count(nID)>0)//nID exist
	{
		return m_data[nID];
	}
	else
	{
		GetStrErrAction(nID);
		return "";
	}
	
}

bool StrManager::IsStrExist(int nID)
{
	if(m_data.count(nID)>0)//nID exist
	{
		return true;
	}
	else
	{
		return false;
	}
}

void StrManager::GetStrErrAction(int nID)
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,"string ID Not Exist when get."+Converter::convertToString(nID));
}

void StrManager::AddStrErrAction(int nID)
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,"string ID already Exist when add."+Converter::convertToString(nID));
}

StrManager* StrManager::getInstance()
{
	if(m_pInstance == NULL)
	{
		m_pInstance= new StrManager();
	}
	return m_pInstance;
}




