#ifndef ALARMRENAMEMANAGER_H_
#define ALARMRENAMEMANAGER_H_

#include <map>
#include <string>
using namespace std;


class AlarmReNameManager 
{
	
//constructer and Destructer
private:
	AlarmReNameManager();
public:
	virtual ~AlarmReNameManager();
	static AlarmReNameManager *getInstance();
private:
	static AlarmReNameManager * m_pInstance;
	
//xml function
public:
	bool AddAlarmNames(const string& strOriginalName , const string& strShowName);
	
public:
	string GetShowName(const string& strOriginalName);
	
	bool IsAlarmNameExist(const string& strOriginalName);

private:
	map<string,string> m_names;
};

#endif /*ALARMRENAMEMANAGER_H_*/
