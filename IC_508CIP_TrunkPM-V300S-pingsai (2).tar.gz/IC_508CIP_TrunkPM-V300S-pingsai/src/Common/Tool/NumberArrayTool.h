#ifndef NUMBERARRAYTOOL_H_
#define NUMBERARRAYTOOL_H_

class NumberArrayTool
{
public:
	static int getMinNum(int * pData , int nLength);
	//if all datas is the except,return -1
	//return min Num Index
	static int getMinNumExcept(int * pData , int nLength,int nExcept);
};

#endif /*NUMBERARRAYTOOL_H_*/
