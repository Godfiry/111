/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: StripBv.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2008-5-18   LiJuanjuan create
**      
*********************************************************************/
#include "StripBv.h"

#include "DeviceManager.h"
#include "ConfigException.h"
//#include "DNSS5136.h"

#include <cmath>
#include<iostream>
#include <string.h>
#ifdef IAP4_0
using namespace IAP::IO;
#endif
using namespace std;


StripBv::StripBv()
{
}

StripBv::~StripBv()
{
}

bool StripBv::readCT(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	char buffer[6];
	int temp;//[wangyk 1.2.0]
	//unsigned long temp;
	memset(buffer, 0, 6);
	if(!isSimulated())
	{
		m_deviceNet->readByte(m_macID, buffer);
		if(channelNum==3)//positionAT
		{
			temp = (((unsigned long)buffer[3]) & 0xff) + ((((unsigned long)buffer[4]) << 8) & 0xff00);
			if(temp<1)
			{
				*value=0;
			}
			else
			{
				*value = temp * typeInfo.getMax() / 10000;
			}
		}
		else if(channelNum==4)//pressureAT
		{
			//cout<<"ff "<<channelNum<<endl;
			temp = (((unsigned long)buffer[1]) & 0xff) + ((((unsigned long)buffer[2]) << 8) & 0xff00);	
			//cout<<"aa  "<<temp<<endl;
			if(buffer[2] & 0x80) //[wangyk 1.2.0]
			{
			    temp -= 65536;
			    *value = temp / (10000/typeInfo.getMax());//added by wangyk 1.2.6
			    if( *value < typeInfo.getMin())
				{
					*value = typeInfo.getMin();
				}
			}
			else
			{
				double dValue = temp / (10000/typeInfo.getMax());//added by wangyk 1.2.6
				//cout<<"value "<<dValue<<endl;
				if(dValue > typeInfo.getMax())
				{
					*value = typeInfo.getMax();
				}
				else
				{
					*value = dValue;
				}
				//*value = temp * typeInfo.getMax() / 1000;
			}
		}
		else if(channelNum==8)//vlvstatus
		{
			temp = ((unsigned long)buffer[5]) & 0xff;
			cout<<"temp:"<<temp<<endl;
			*value = temp;
		}
		else
			return false;
		return true;
	}
	else
	{
		*value=typeInfo.getMin();
		return true;
	}
}

bool StripBv::writeCT(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
	char buffer[4];
	memset(buffer, 0, 4);
	long temp;
	if(channelNum==1)//presureSP
	{

		temp = value*(10000/typeInfo.getMax());//added by wangyk 1.2.6
		buffer[0] = (unsigned char)(0 & 0xff);
		buffer[1] = (unsigned char)(temp & 0xff);
		buffer[2] = (unsigned char)((temp>>8) & 0xff);
		buffer[3] = (unsigned char)(0 & 0xff);
	 }
	if(channelNum==2)//positionSP
	{
		temp = value*10000/typeInfo.getMax();
		buffer[0] = (unsigned char)(0 & 0xff);
		buffer[1] = (unsigned char)(temp & 0xff);
		buffer[2] = (unsigned char)((temp>>8) & 0xff);
		buffer[3] = (unsigned char)(1 & 0xff);		
	}
	cout<<"temp: "<<temp<<endl;
	cout<<"channelNum13:1 "<<hex<<(int)buffer[0]<<endl;//<<" "<<buffer[1]<<" "<<buffer[2]<<" "<<buffer[3]<<endl;
	cout<<"channelNum13:2 "<<hex<<(unsigned int)buffer[1]<<endl;
	cout<<"channelNum13:3 "<<hex<<(unsigned int)buffer[2]<<endl;
	cout<<"channelNum13:4 "<<hex<<(unsigned int)buffer[3]<<endl;
	if(!isSimulated())
		return m_deviceNet->writeByte(m_macID, buffer);
	else
	{
		cout<<"StripBv writeCT temp:"<<temp<<endl;
		return true;
	}

}

bool StripBv::readECT(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	if(!isSimulated())
	{
		char bufferout[4];
		memset(bufferout, 0, 4);
		char bufferin[1];
		memset(bufferin, 0, 1);
		int *b;
		bufferin[0] = 0x6C;
		m_deviceNet->readExplicit(m_macID, bufferin, 0x0E, 0x64, 1, 4,bufferout,b);
		unsigned long temp;
		temp = (((unsigned long)bufferout[0]) & 0xff) + ((((unsigned long)bufferout[1]) << 8) & 0xff00) + ((((unsigned long)bufferout[2])  << 16) & 0xff0000) + ((((unsigned long)bufferout[3]) << 24) & 0xff000000);
		//*value = pow(double(10.0),double(realToDouble(temp)*1.667/1000-9.333));
		*value = temp;
		return true;
	}
	else
		return true;
}

bool StripBv::readECTInt(int channelNum, int *value, const IntTypeInfo &typeInfo)
{	
	char buffer[6];
	unsigned long temp;
	memset(buffer, 0, 6);
	if(!isSimulated())
	{
		m_deviceNet->readByte(m_macID, buffer);

		if(channelNum==8)//vlvstatus
		{
			temp = (unsigned long)buffer[5];//((unsigned long)buffer[5]) & 0xff;
			cout<<"temp:"<<temp<<endl;
			*value = temp;
		}
		else
			return false;
		return true;
	}
	else
	{
		*value=typeInfo.getMin();
		return true;
	}
}
bool StripBv::writeDT(int channelNum, int value, const IntTypeInfo &typeInfo)
{
	if(!isSimulated())
	{
		char buffer[4];
		memset(buffer, 0, 4);
		if(value == 0)
		{
			buffer[0] = (unsigned char)(1 & 0xff);
			buffer[1] = (unsigned char)(0 & 0xff);
			buffer[2] = (unsigned char)(0 & 0xff);
			buffer[3] = (unsigned char)(0 & 0xff);
		}
		if(value == 1)
		{
			buffer[0] = (unsigned char)(2 & 0xff);
			buffer[1] = (unsigned char)(0 & 0xff);
			buffer[2] = (unsigned char)(0 & 0xff);
			buffer[3] = (unsigned char)(0 & 0xff);
		}
		return m_deviceNet->writeByte(m_macID, buffer);
	}
	else
		return true;
}

void StripBv::init()
{
	if(!isSimulated())
	{	
		string error = "";
       initDeviceNet();	
		if(m_nodeNum < 0)
		{
			error = "node number illegal: " + Converter::convertToString(m_macID);
			throw ConfigException(error);
		}	
		DeviceNode<StripBv> * node = new DeviceNode<StripBv>(m_pollInterval,this);
		//init channels
		node->registerWriteCh(0, &StripBv::writeDT);
		node->registerWriteCh(1, &StripBv::writeCT);
		node->registerWriteCh(2, &StripBv::writeCT);
		for(int i=3; i<=4; ++i)
		{
			node->registerReadCh(i, &StripBv::readCT);
		}
		node->registerReadCh(5, &StripBv::readECT);
		node->registerReadCh(6, &StripBv::readECTInt);
		node->registerReadCh(7, &StripBv::readECTInt);
		node->registerReadCh(8, &StripBv::readECTInt);
		node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &StripBv::getStatus);
		DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	}
	else
	{
		DeviceNode<StripBv> * node = new DeviceNode<StripBv>(m_pollInterval,this);
		//init channels
		node->registerWriteCh(0, &StripBv::writeDT);
		node->registerWriteCh(1, &StripBv::writeCT);
		node->registerWriteCh(2, &StripBv::writeCT);
		for(int i=3; i<=4; ++i)
		{
			node->registerReadCh(i, &StripBv::readCT);
		}
		node->registerReadCh(5, &StripBv::readECT);
		node->registerReadCh(6, &StripBv::readECTInt);
		node->registerReadCh(7, &StripBv::readECTInt);
		DeviceManager::getInstance()->registerNode(m_nodeNum, node);		
	}
}

IMPLEMENT_DYNAMIC(StripBv, IODevice )
BEGIN_MSG_MAP( StripBv, IODevice )

END_MSG_MAP
