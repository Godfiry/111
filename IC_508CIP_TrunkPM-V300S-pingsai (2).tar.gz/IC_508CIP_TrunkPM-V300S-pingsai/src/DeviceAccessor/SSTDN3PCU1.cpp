/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: SSTDN3PCU1.cpp
** Description:  
** Release: 1.1
** Modification history: 
**                     2008-5-17   LiJuanjuan create
**      
*********************************************************************/
#include "ConfigException.h"
#include "Converter.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#include <stdio.h>
#include <fcntl.h>
#include <sys/termios.h>
#include <signal.h>
#include <setjmp.h>
#include <errno.h>
#include <ctype.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include "SSTDN3PCU1.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;

SSTDN3PCU1::SSTDN3PCU1(const std::string &devName, int masterMacId, int baudRate):DeviceNet(devName,masterMacId,baudRate)
{
}

SSTDN3PCU1::~SSTDN3PCU1()
{
    StopScan();
    GoOffline();
    CleanupCardMemList();
}

void SSTDN3PCU1::loadDevice()
{
    string error = "";

    if((dni = open(m_devName.c_str(), O_RDWR)) < 0)
    {
        cout << m_devName.c_str() << endl;
        error = "Open device '" + m_devName +"' failed value returned was '"+ Converter::convertToString(dni) + "'";
        throw ConfigException(error);
    }
    /*
    if ((ioctl(dni,SS5136DN_REPORT_APERATURE)) != PAGESIZEINBYTES)
    {
        error = "There is a memory aperture mismatch between the driver and this program!";
        throw IOException(error);
    }
    */
    for (int i=0;i<64;i++)
    {
        DevicesList[i]=NULL;
    }
    /*
    int cardtype = ioctl(dni,SS5136DN_REPORT_CARDTYPE);
    if (cardtype == PRO)
    {
        if (PAGESIZEINBYTES == 0x8000)
        {
            if ((ldappmod32p("dnscan.ss2")) == -1)
            {
                error = "32 Module 'dnscan.ss2' load failed!";
                throw IOException(error);
              }
        }
        else
        {
            if ((ldappmod16p("dnscan.ss2")) == -1)
             {
                error = "16 Module 'dnscan.ss2' load failed!";
                throw IOException(error);
            }
        }
    }
    else
    {
        if (PAGESIZEINBYTES == 0x8000)
        {
            if ((ldappmod32p("dnscan.ss1")) == -1)
              {
                error = "32 Module 'dnscan.ss1' load failed!";
                throw IOException(error);
            }
        }
        else
        {
            if ((ldappmod16p("dnscan.ss1")) == -1)
            {
                error = "16 Module 'dnscan.ss2' load failed!";
                throw IOException(error);
            }
        }
    }
    */
    ldfw(const_cast<char*>((m_fwdir + "/DnScan.ss3").c_str()));
    initCardMemList();

    if ((m_masterMacID < 0) || (m_masterMacID > 63))
    {
        m_scannermak = 0;
    }
    else
    {
        m_scannermak = (unsigned char)m_masterMacID;
    }
    unsigned short scannerspeed;
    switch(m_baudRate)
    {
        case 500:
            scannerspeed = BAUD500K;
            break;
        case 250:
            scannerspeed = BAUD250K;
            break;
        case 125:
            scannerspeed = BAUD125K;
            break;
        default:
            throw ConfigException("Invalid baud rate for scan");
    }
    int foo=GoOnline(m_scannermak,scannerspeed);
    cout << "GoOnline returned "<< foo <<endl;
    foo=StartScan();
    cout << "StartScan returned "<< foo <<endl;
}

bool SSTDN3PCU1::addDevice(int inmac)
{
    if(inmac == m_scannermak)
    {
        return true;
    }
    string error;
    //(void *)DevicesList[inmac]=malloc(sizeof(DNS_DEVICE_CFG));
    DevicesList[inmac] = new DNS_DEVICE_CFG;
    (*DevicesList[inmac]).MacId = (unsigned short)inmac;
    (*DevicesList[inmac]).VendorId = 0;
    (*DevicesList[inmac]).DeviceType = 0;
    (*DevicesList[inmac]).ProductCode = 0;
    (*DevicesList[inmac]).Reserved1 = 0;
    (*DevicesList[inmac]).Reserved2 = 0;
    (*DevicesList[inmac]).Reserved3 = 0;
      /* enable explicit message connections */
    (*DevicesList[inmac]).Flags = DNS_EXP;
    (*DevicesList[inmac]).ExplicitSize = 16;
    (*DevicesList[inmac]).ExplicitOffset = allocCardMem(16);
    (*DevicesList[inmac]).Io1Interval = 0;
      /* poll request size  */
    (*DevicesList[inmac]).Output1Size = 0;
      /* poll request Offset */
    (*DevicesList[inmac]).Output1Offset = 0;
    (*DevicesList[inmac]).Output1LocalPathOffset = 0;
    (*DevicesList[inmac]).Output1RemotePathOffset = 0;
      /* poll response size */
    (*DevicesList[inmac]).Input1Size = 0;
      /* poll response offset */
    (*DevicesList[inmac]).Input1Offset = 0;
    (*DevicesList[inmac]).Input1LocalPathOffset = 0;
    (*DevicesList[inmac]).Input1RemotePathOffset = 0;
    (*DevicesList[inmac]).Io2Interval = 0;
      /* strobe request size */
    (*DevicesList[inmac]).Output2Size = 0;
      /* strobe request offset */
    (*DevicesList[inmac]).Output2Offset = 0;
    (*DevicesList[inmac]).Output2LocalPathOffset = 0;
    (*DevicesList[inmac]).Output2RemotePathOffset = 0;
      /* strobe response size */
    (*DevicesList[inmac]).Input2Size = 0;
      /* strobe response Offset */
    (*DevicesList[inmac]).Input2Offset = 0;
    (*DevicesList[inmac]).Input2LocalPathOffset = 0;
    (*DevicesList[inmac]).Input2RemotePathOffset = 0;

    int foo=AddDevice(DevicesList[inmac],0);
    if (foo != 0)
    {
        error = "Unable to scan device '" + Converter::convertToString(inmac);
        (*DevicesList[inmac]).ExplicitSize = 0;
        foo = deallocCardMem((*DevicesList[inmac]).ExplicitOffset);
        delete DevicesList[inmac];
        (DevicesList[inmac]) = NULL;
        return false;
    }
    else
    {
        foo=GetDevice(DevicesList[inmac]);
        foo=ioctl(dni,SSTDN3PCU1_SETCARDMEMPTR,DATA_BASE+(CONTROLTOP+(inmac*DCONSIZE)));
        char inflags;
        char outflags;
        foo=read(dni,&inflags,1);
        outflags = inflags | DCTL_EXPITRLCK;
        foo=ioctl(dni,SSTDN3PCU1_SETCARDMEMPTR,DATA_BASE+(CONTROLTOP+(inmac*DCONSIZE)));
        foo=write(dni,&outflags,1);

          /*  Begin block to query for polled input  */
        explicit_request ereq;
        explicit_response eresp;
        ereq.ExplicitSize=0x2;
        ereq.ExplicitService=0x4b;
        ereq.ExplicitClass=0x3;
        ereq.ExplicitInstance=1;
        ereq.ServiceData[0]=2;
        ereq.ServiceData[1]=m_scannermak;

          /*  printf("Sending master/slave connection request.\n");  */
        foo = sendDeviceExplicit(0,inmac,&ereq,&eresp);
        if (eresp.ExplicitService != 0xcb)
        {
            cout << "This device does not support polled I/O.\n";
            (*DevicesList[inmac]).Output1Size = 0;
            (*DevicesList[inmac]).Input1Size = 0;
        }
        else
        {
            ereq.ExplicitSize=1;
            ereq.ExplicitService=0x0e;
            ereq.ExplicitClass=0x5;
            ereq.ExplicitInstance=2;
            ereq.ServiceData[0]=7;

            foo = sendDeviceExplicit(0,inmac,&ereq,&eresp);

            if (eresp.ExplicitService != 0x8e)
            {
                   cout << "This device does not support polled input.\n";
                (*DevicesList[inmac]).Input1Size = 0;
            }
            else
            {
                cout << "This device reports that it has " << (int)eresp.ServiceData[0] <<" bytes of polled input.\n";
              (*DevicesList[inmac]).Input1Size = (unsigned short)eresp.ServiceData[0];
            }
            ereq.ExplicitSize=1;
            ereq.ExplicitService=0x0e;
            ereq.ExplicitClass=0x5;
            ereq.ExplicitInstance=2;
            ereq.ServiceData[0]=8;

            foo = sendDeviceExplicit(0,inmac,&ereq,&eresp);

            if (eresp.ExplicitService != 0x8e)
            {
              cout << "This device does not support polled output.\n";
                (*DevicesList[inmac]).Output1Size = 0;
            }
            else
            {
                cout << "This device reports that it has " << (int)eresp.ServiceData[0] << " bytes of polled output.\n";
                (*DevicesList[inmac]).Output1Size = (unsigned short)eresp.ServiceData[0];
            }
        }
            ereq.ExplicitSize=1;
            ereq.ExplicitService=0x4c;
            ereq.ExplicitClass=0x3;
            ereq.ExplicitInstance=1;
            ereq.ServiceData[0]=2;
              foo = sendDeviceExplicit(0,inmac,&ereq,&eresp);
    }
    if(DevicesList[inmac] != NULL)
    {
        short tmpsht = (unsigned short)inmac;
        foo = RemoveDevice(&tmpsht);
        usleep(500000);
        (*DevicesList[inmac]).Flags = DNS_P | DNS_EXP;
        //(*DevicesList[inmac]).ExplicitSize = 0;
        //foo = deallocCardMem((*DevicesList[inmac]).ExplicitOffset);
        if ((*DevicesList[inmac]).Output1Size > 0)
        {
            (*DevicesList[inmac]).Output1Offset = allocCardMem((*DevicesList[inmac]).Output1Size);
            foo=ioctl(dni,SSTDN3PCU1_SETCARDMEMPTR,DATA_BASE+((*DevicesList[inmac]).Output1Offset));
            unsigned char outbyte = 0;
            for (int i=0;i<(*DevicesList[inmac]).Output1Size;i++)
            {
                foo=write(dni,&outbyte,1);
            }
        }
        if ((*DevicesList[inmac]).Input1Size > 0)
        {
           (*DevicesList[inmac]).Input1Offset = allocCardMem((*DevicesList[inmac]).Input1Size);
        }
        foo = AddDevice(DevicesList[inmac],0);
        if(foo != 0)
        {
            error = "Unable to scan device '" + Converter::convertToString(inmac);
            (*DevicesList[inmac]).ExplicitSize = 0;
            foo = deallocCardMem((*DevicesList[inmac]).ExplicitOffset);
            delete DevicesList[inmac];
            (DevicesList[inmac]) = NULL;
            return false;
        }
    }
    return true;
}

int SSTDN3PCU1::readStatus(int nMacId)
{
    IMutexLocker locker(&m_lock);
    int nResult;
    unsigned char nStatus;
    nResult=ioctl(dni,SSTDN3PCU1_SETCARDMEMPTR,DATA_BASE+(STATUSTOP+nMacId*16));
    nResult=read(dni,&nStatus,1);
    if(nResult < 0)
    {
        return -1;
    }
    return nStatus;
}

bool SSTDN3PCU1::readByte(int inmac, char *byte)
{
    IMutexLocker locker(&m_lock);
    if(DevicesList[inmac] == NULL)
    {
        throw IOException("SSTDN3PCU1::there is no device for macid '" +Converter::convertToString(inmac)+ "'");
    }
    int foo = readDeviceIO(0,inmac,IN1, byte);
    if(foo < 0)
    {
        throw IOException("SSTDN3PCU1::sending explicit data to macid '" +Converter::convertToString(inmac)+"' failed");
    }
    return true;
}

bool SSTDN3PCU1::writeByte(int inmac, char *byte)
{
    IMutexLocker locker(&m_lock);
    if(DevicesList[inmac] == NULL)
    {
        throw IOException("SSTDN3PCU1::there is no device for macid '" +Converter::convertToString(inmac)+ "'");
    }
    int foo = writeDeviceIO(0, inmac, OUT1, byte);
    if(foo < 0)
    {
        throw IOException("SSTDN3PCU1::sending explicit data to macid '" +Converter::convertToString(inmac)+"' failed");
    }
    return true;
}

int SSTDN3PCU1::getIBytesSize(int inmac)
{
    return DevicesList[inmac]->Input1Size;
}

int SSTDN3PCU1::getOBytesSize(int inmac)
{
    return DevicesList[inmac]->Output1Size;
}

bool SSTDN3PCU1::readBit(int inmac, int channel, bool *bit)
{
    int inputBytes = (*DevicesList[inmac]).Input1Size;
    if(channel >= inputBytes*8)
    {
        throw IOException("SSTDN3PCU1::the channel to read is bigger than allowed channels for macid '" +Converter::convertToString(inmac)+"'");
    }
    char buffer[inputBytes];
    memset(buffer, 0, inputBytes);
    bool foo = readByte(inmac, buffer);
    if(foo)
    {
        int byteno = channel / 8;
        int bitno = channel % 8;
        unsigned char bitmask = 1;
        bitmask = bitmask << bitno;
        *bit = (bool)(buffer[byteno] & bitmask);
        return true;
    }
    else
    {
        return false;
    }
}

bool SSTDN3PCU1::writeBit(int inmac, int channel, bool bit)
{
    int outputBytes = (*DevicesList[inmac]).Output1Size;
    if(channel >= outputBytes*8)
    {
        throw IOException("SSTDN3PCU1::the channel to write is bigger than allowed channels for macid '" +Converter::convertToString(inmac)+"'");
    }
    char buffer[outputBytes];
    memset(buffer, 0, outputBytes);
    if(bit == 1)
    {
        int byteno = channel / 8;
        int bitno = channel % 8;
        unsigned char bitmask = 1;
        bitmask = bitmask << bitno;
        buffer[byteno] =     buffer[byteno] | bitmask;
    }
    return writeByte(inmac, buffer);
}

bool SSTDN3PCU1::writeExplicit(int macid, char *buffer, int service, int Class, int instance, int datasize)
{
    IMutexLocker locker(&m_lock);
    explicit_request ereq;
    explicit_response eresp;
    ereq.ExplicitSize = datasize;
    ereq.ExplicitService = service;
    ereq.ExplicitClass = Class;
    ereq.ExplicitInstance = instance;
    for(int i=0; i<datasize; ++i)
    {
        ereq.ServiceData[i] = buffer[i];
    }
    int foo = sendDeviceExplicit(0,macid,&ereq,&eresp);
    if(foo < 0)
    {
        throw IOException("SSTDN3PCU1::sending explicit data to macid '" +Converter::convertToString(macid)+"' failed");
    }
    if((eresp.ExplicitService & 0x80) > 0)
    {
        cout << "explicit response service_status:"<< (int) (eresp.ExplicitService)<< endl;
        //throw IOException("SSTDN3PCU1::sending explicit data to macid '" +Converter::convertToString(macid)+"' failed for response has error ");
    }
    return true;
}

bool SSTDN3PCU1::readExplicit(int macid, char *bufferIn, int service,int Class, int instance, int datasizeIn, char *bufferOut, int *datasizeOut)
{
    IMutexLocker locker(&m_lock);
    explicit_request ereq;
    explicit_response eresp;
    ereq.ExplicitSize = datasizeIn;
    ereq.ExplicitService = service;
    ereq.ExplicitClass = Class;
    ereq.ExplicitInstance = instance;
    for(int i=0; i<datasizeIn; ++i)
    {
        ereq.ServiceData[i] = bufferIn[i];
    }
    int foo = sendDeviceExplicit(0,macid,&ereq,&eresp);
    if(foo < 0)
    {
        throw IOException("SSTDN3PCU1::sending explicit data to macid '" +Converter::convertToString(macid)+"' failed");
    }
    if((eresp.ExplicitService & 0x80) > 0)
    {
        cout << "explicit response service_status:"<< (int) (eresp.ExplicitService)<< endl;
        //throw IOException("SSTDN3PCU1::sending explicit data to macid '" +Converter::convertToString(macid)+"' failed for response has error ");
    }
    *datasizeOut = eresp.ExplicitSize;
    for(int i=0; i<eresp.ExplicitSize; ++i)
    {
        bufferOut[i] = eresp.ServiceData[i];
    }
    return true;
}

