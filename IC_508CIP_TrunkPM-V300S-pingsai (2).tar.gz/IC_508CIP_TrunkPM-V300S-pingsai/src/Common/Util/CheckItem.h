/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: CheckItem.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-9-28   LiJuanjuan create
**      
*********************************************************************/
#ifndef CHECKITEM_H_
#define CHECKITEM_H_

#include "ControlObjectEX.h"
#include "Service.h"
#include "ReadWriteInt.h"
#include "AppCondition.h"
#include "NonBlockingAlarm.h"
#include "ReadWriteDouble.h"
#include "IMutex.h"
#include <vector>
#include <SetupTool.h>
#ifdef IAP4_0
using namespace IAP::CONTROL;
using namespace IAP::IO;
using namespace IAP::CONDITION;
using namespace IAP::ALARM;
using namespace IAP::CORE;
#endif
class GuadAction;

class CheckItem:public ControlObjectEX
{
	DECLARE_DYNAMIC(CheckItem)
	DECLARE_MSG_MAP
	DECLARE_SERVICEINFO_LIST		
	
	public:
		class Enable : public Service
		{
			DECLARE_DYNAMIC_SERVICE(Enable)
			
			public:
				void execute();
		};
		
		class Disable : public Service
		{
			DECLARE_DYNAMIC_SERVICE(Disable)
			
			public:
				void execute();
		};

	public:
		CheckItem();
		virtual ~CheckItem();

	public://xml
		void setTriggerCondition(const std::string &strConditionPath);
		void addAction(const std::string &path);
		void setDurativeTimeS(double time);
		void setDurativeTimeSCh(const std::string &path);
		void setAlarmMessage(const std::string &message);
		void setAlarmMessageID(int nMessageID);//add for code merging
		void setCheckDelaySCh(const std::string &path);
		void setCheckDelayS(double time);
		void setEnableAtStart(bool bFlag);
		void setEnableIOValidity(bool bFlag);
		void setAlarmSeverity(int severity);

	public://override
		virtual void make();

	public://for override
		virtual void start();
		virtual void stop();
		virtual void do_Enable();
		virtual void do_Disable();
		virtual bool check();
		virtual void bulidAlarm();

	public:
		void call_Enable();
		void call_Disable();

		long getCheckDelayMS()const;
		long getDurativeTimeMS()const;
		bool isEnabled()const;
		void activateTrigger();
		void deactivateTrigger();
		void setAlarmDescription(std::string strDescription);
		void setPostAlarm(bool post);//added by guojin[1.1.53] for noalarm
		void setTempCheckDelaytimeS(double time);

	protected:
		virtual void recordAbnormalData();
		virtual void clearAbnormalData();
		virtual std::string updateAlarmMessageWithRecordData();

	protected:
		long m_triggeredTimeMS;//ms
		NonBlockingAlarm *m_pTriggerAlarm;
		bool m_postAlarm;//added by guojin[1.1.53] for noalarm

		virtual bool doCheck();
		virtual bool isTriggered();
		bool isIOValidity();
		virtual void configTrigger();
		bool checkDuration();
		bool checkTriggered();
		bool checkDelay();
		void executeSafeAction();
		void setTrigger(AppConditionPtr trigger);
		AppConditionPtr getTrigger()const;
		std::string getAlarmDescription()const;//mujy add [v1.0.0.3]
		void setTriggerIO(const std::string &strPath); //added by liusy[20191104]
		void setAllTriggerIO(const std::string &strConditionPath);//added by liusy[20191104]
		std::vector<UntypedData*> m_vTriggerIO;    //added by liusy[20191104]
		std::string getTimeoutInfo()const;
		std::string getAlarmMessage()const;
	private:
		ReadWriteInt *m_enable;
		std::vector<GuadAction*> m_actions;

		
		std::string m_alarmMessage;
		ReadWriteDouble *m_durativeTimeS;//s		
		ReadWriteDouble *m_checkDelayS;//s
		long m_startTimeMS;		
		IMutex m_lock;
		bool m_bEnableAtStart;
		bool m_bEnableIOValidity;
		Alarm::Severity m_alarmSeverity;		
		AppConditionPtr m_trigger;	
				
		ServicePtr<Enable> m_sEnable;
		ServicePtr<Disable> m_sDisable;

		std::string m_strAlarmDescription;
		std::string m_strTriggerIODescription;
		std::string m_strTimeoutInfo;
		double m_dTempCheckDelayTimeS;
};

#endif /*CHECKITEM_H_*/
