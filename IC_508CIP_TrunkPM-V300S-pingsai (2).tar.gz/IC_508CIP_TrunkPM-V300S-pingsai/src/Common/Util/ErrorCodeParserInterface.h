/********************************************************************
** Copyright (c) 2019, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: ErrorCodeParserInterface.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2019-5-8   mujy create
**      
*********************************************************************/
#ifndef ERRORCODEPARSERINTERFACE_H_
#define ERRORCODEPARSERINTERFACE_H_

#include <string>
using namespace std;

class ErrorCodeParserInterface
{
public:
	virtual string parseErrorCode(const string strCode) = 0;
};

#endif /*TRANSLATORINTERFACE_H_*/
