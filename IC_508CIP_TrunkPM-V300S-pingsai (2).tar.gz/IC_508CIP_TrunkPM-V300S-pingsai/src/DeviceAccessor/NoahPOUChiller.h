/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: POUChiller.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2016-2-23   mujy create for Lauda-Noah 3300&3500 POU Chiller
**      
*********************************************************************/
#ifndef NOAHPOUCHILLER_H_
#define NOAHPOUCHILLER_H_

#include "DeviceNode.h"
#include "SerialDevice.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class NoahPOUChiller : public SerialDevice
{
	DECLARE_DYNAMIC(NoahPOUChiller)	
	DECLARE_MSG_MAP
	
private:

	typedef struct
	{
		int m_address;
		int m_p1;
	}Address;
		
	static Address m_addInfo[];
	int m_resLen;	
	char m_writeCmd[8];	//write command array	
	char m_readCmd[8];   //read command array
	
	static const int RESP_LEN = 80;//the buff length
	//calculate the CRC and get it
	unsigned short GetCRC16Code(char *cCommand, int nLen);
	

protected:
	bool sendCommand(char *command, int timeOut, int len);
	int readCommand(char *command, int timeOut, int len);
	void initChs(DeviceNode<NoahPOUChiller> *node);//inint channel
	void initDevice();
	
public:
	NoahPOUChiller();
	virtual ~NoahPOUChiller();
	void init();  //init the device 

	bool writeDouble(int channnelNum,double setpt ,const DoubleTypeInfo& typeinfo);
	bool readDouble(int channnelNum,double * value ,const DoubleTypeInfo& typeinfo);
	bool readInt(int channelNum, int *value, const IntTypeInfo &typeInfo);
	bool writeInt(int channelNum, int value, const IntTypeInfo &typeInfo);
};

#endif /*NOAHPOUChiller_H_*/
