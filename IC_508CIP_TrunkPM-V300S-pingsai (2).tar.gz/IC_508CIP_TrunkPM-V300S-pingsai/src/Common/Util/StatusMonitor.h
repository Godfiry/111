/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: StatusMonitor.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-9-28   LiJuanjuan create
**      			2016-10-18   mujy added [V1.5.16]
*********************************************************************/
#ifndef STATUSMONITOR_H_
#define STATUSMONITOR_H_

#include "ControlMonitor.h"
#include "NonBlockingAlarm.h"
#include "ReadWriteDouble.h"
#include <unistd.h>  //add by wzd 1.1.39
#ifdef IAP4_0
using namespace IAP::CONTROL;
using namespace IAP::ALARM;
using namespace IAP::IO;
using namespace IAP::CORE;
#endif

class CheckItem;

class StatusMonitor:public ControlMonitor
{
	DECLARE_DYNAMIC(StatusMonitor)
	DECLARE_MSG_MAP
		
	protected:
		ReadWriteDouble *m_intervalS;//s
		ReadWriteDouble *m_startDelayS;//s
		bool m_autoStart;
		std::vector<CheckItem*> m_checkItems;
		
		volatile bool m_monitorEnable;//added by mujy [V1.5.16]
		bool m_waitstableFlag;
	public:
		StatusMonitor();
		virtual ~StatusMonitor();
		
	public://xml config
		void setIntervalS(double timeS);
		void setIntervalSCh(const std::string &path);

		void setStartDelayS(double timeS);
		void setStartDelaySCh(const std::string &path);

		virtual void addCheckItem(const std::string &path);
		void setAutoStart(bool flag);

	public://override
		virtual void internalExecute();
		virtual void startup();
		virtual void shutdown();
		//void setStartTimeToItems();


		/* instructions
		 * BeginMonitor->(start->stop->start->stop...start->stop)->EndMonitor
		 */
		void start();
		void stop();
		void BeginMonitor();//added by mujy [V1.5.16]
		void EndMonitor();//added by mujy [V1.5.16]
		int getCheckItemSize()const;
		CheckItem* getCheckItem(int index)const;
				
		void addToCheckItems(CheckItem *item);

		void enableAllCheckItem();//added by heyj[1.2.7HotFix]

	private:
		IMutex m_mutex;
};

#endif /*STATUSMONITOR_H_*/
