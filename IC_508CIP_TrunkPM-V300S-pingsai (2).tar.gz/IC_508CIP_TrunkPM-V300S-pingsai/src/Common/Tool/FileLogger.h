/****************************************************************
** Copyright(c) 2007, Beijing NMC Co.,Ltd. All rights reserved.
** File name: FileLogger.h
** Description: This file includes declaration of class FileLogger.
**
** Release: 1.0
** Modification history: 
** 
** example:
**		FileLogger logger;
**		logger.init("/home/nmc/logerDir",5000,1024*1024);
**		logger.start();
**		logger.logMsg("hello world");
****************************************************************/



#ifndef FILELOGGER_H_
#define FILELOGGER_H_


#include <fstream>
#include <queue>
#include <map>

#include "IThread.h"
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

class FileLogger : public IThread
{
	public:
		FileLogger();
		virtual ~FileLogger();
		
	public:
		inline std::string dir() const
		{
			return m_dir;
		}
		void init(	const std::string &dir, unsigned int threshold, long fileSizeLimit);
		
		void logMsg(const std::string &msg);
		
		void saveMsg(const std::string &msg);// log msg later.lvjw 2018.01.03
		void logSaveMsg();// log msg later.lvjw 2018.01.03
	protected:
		virtual void run();
		
	private:
		std::string m_dir; // the dir of all syslog files
		unsigned int m_threshold; // threshold number of syslog files to keep
		long m_sizeLimit;
		std::queue<std::string> m_fileQueue; // syslog files list
		
		std::queue<std::string> m_logMessage; // log msg queue
		std::queue<std::string> m_saveMessage; // save msg queue.lvjw 2018.01.03
		mutable IMutex m_queueLock;
		
		volatile bool m_exit;
		IMutex m_waitLock;
		IWaitCondition m_waitCond;
		
		std::string m_fileName; // the FULL name of current syslog file
		std::fstream m_file; 	// current file instance
		std::string m_lastFileDate;
		
		void initFileQueue();
		void openFile();
		bool fileExist(const std::string &fn) const;
		bool fileSizeOverflow(const std::string &fn) const;
		
		bool hasMsgInQueue() const;
		std::string popMsgFromQueue();
		void writeMsgToFile(const std::string &msg);
		std::string getCurrentDate() const;
		
		void getDateDir();
		std::string m_strDateDir; // sort of dir by date.lvjw 2017.12.24
};

#endif /*FILELOGGER_H_*/
