#ifndef PECVDVATBUFFERFLYDRIVER_H_
#define PECVDVATBUFFERFLYDRIVER_H_
#include "IODevice.h"
#include "DeviceNode.h"
#include "DeviceManager.h"
#include "ConfigException.h"
#include "DoubleTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

using namespace std;

class PecvdVatBufferFlyDriver:public IODevice
{
	DECLARE_DYNAMIC(PecvdVatBufferFlyDriver)	
	DECLARE_MSG_MAP	
	
	private:
		int m_nOutputByte;
		int m_nInputByte;
	
	public:
		PecvdVatBufferFlyDriver();
		virtual ~PecvdVatBufferFlyDriver();
	
	public:	
		virtual void init();
		bool writeInt(int channelNum, int value, const IntTypeInfo &typeInfo);
		bool writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo);
		bool readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo);

		bool writeECTDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo);
		bool writeECTInt(int channelNum, int value, const IntTypeInfo &typeInfo);
		bool readECTInt(int channelNum, int *value, const IntTypeInfo &typeInfo);
};

#endif /*PECVDVATBUFFERFLYDRIVER_H_*/
