/********************************************************************
** Copyright (c) 2019 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: EnIPTransport.h
** Description:  
** Release: 1.0
** Modification history:           
** 					2019-06-03   Duq create
** 
*********************************************************************/

#ifndef ENIPTRANSPORT_H_
#define ENIPTRANSPORT_H_

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string>
#include <cstring>
#include "IThread.h"
#include "TCPSocket.h"
#include <errno.h>
#include "IMutex.h"
#include "SysLogger.h"
#include <stdlib.h>
#include <stdint.h>
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

#define UDPServerRecvLength 1024
#define TCPClientRecvLength 1024

//UDP socket: server and client
class EnIPUDPServerTransport:public IThread
{
	public:
		int m_socketfd;
		socklen_t m_clientAddrLen;
		int m_recvLength;
		struct sockaddr_in m_serverAddr; 
		struct sockaddr_in m_clientAddr; 
		bool m_running;	
		bool m_runningstatus;
		char m_recvBuf[UDPServerRecvLength];
		std::string serverIP;
		
	private:
		static EnIPUDPServerTransport* m_Instance;
		static bool startflag;
		
	public:
		EnIPUDPServerTransport();
		virtual ~EnIPUDPServerTransport();
		virtual void run();
		static void startRecvData();
		static EnIPUDPServerTransport* getInstance();
};

//UDP socket: client
class EnIPUDPClientTransport
{
	public:
		int m_socketfd;
		socklen_t m_serverAddrLen;
		int m_sendLength;
		struct sockaddr_in m_serverAddr; 
		char m_sendBuf[UDPServerRecvLength];
		std::string m_server;

	public:
		EnIPUDPClientTransport(const std::string &server);
		virtual ~EnIPUDPClientTransport();
		int sendData(const char *buffer, int length);
};

//TCP socket: client
class EnIPTCPClientTransport
{
	public:
		TCPSocket* m_socket;
		IMutex m_lock;
		std::string m_server;
		
	public:
		EnIPTCPClientTransport(const std::string &server);
		virtual ~EnIPTCPClientTransport();		
		bool isConnected();
		int sendData(const char *buffer, int length);
		int recvData(char *buffer);
		int SendReceive(const char *senddata, int sendlength, char *recvdata = NULL);
};

#endif  /*ENIPTRANSPORT_H_*/
