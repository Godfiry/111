#include "MathTool.h"
#include "DefaultValue.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "AbortException.h"
#endif
#include "Converter.h"
#include "StrTool.h"
#include <cmath>
#include <cstdlib>
using namespace std;
#ifdef IAP4_0
using namespace IAP;
using namespace IAP::CORE;
#endif

double MathTool::Round(double dSrc ,double dAccuracy)
{
	int nBits = 0;
	if(dAccuracy <= 0)
	{
		dAccuracy = DEFAULT_ACCURACY;
	}

	while(dAccuracy < 1)
	{
		dAccuracy = dAccuracy * 10;
		++nBits;
	}

	double dValue = pow(10.0,nBits);
	return floor(dValue * dSrc + 0.5)/dValue;
}
//added by liusy[1.1.39]
void MathTool::LinearFunc(double x1, double y1, double x2, double y2, double &k ,double &b)
{
	if(abs(x1-x2) < 0.00001)
	{
		throw AbortException("the diff between point x1'x and point x2's x is in 0.00001");
	}

	double ktemp = (y1-y2)/(x1-x2);
	double btemp = y1 - x1 * ktemp;
	k = MathTool::Round(ktemp, 0.001);
	b = MathTool::Round(btemp, 0.001);

	if(abs(k) < 0.000001)
	{
		throw AbortException("k is equal 0");
	}
}
//added by liusy[1.1.39]
void MathTool::PiecewiseFunc(string X,string Y,  string &K,string &B, const string &strSeparator)
{
	vector<string> XVector = StrTool::split(X,strSeparator);
	vector<string> YVector = StrTool::split(Y,strSeparator);

	K = "";
	B = "";
	if(XVector.size() != YVector.size() )
	{
		throw AbortException("parameter is valid, Number of parameter is not same");
	}

	if(XVector.size() < 2)
	{
		throw AbortException("Number of parameter is less than 2");
	}

	double x1 =0 ,x2=0 ,y1= 0,y2 =0;
	double k=0,b=0;
	for(int i=0 ;i < XVector.size()-1; i++)
	{
		//i i+1
		k=0;
		b=0;
		if(Converter::stringToDouble(x1, XVector[i]) && Converter::stringToDouble(x2, XVector[i+1]) &&
				Converter::stringToDouble(y1, YVector[i]) && Converter::stringToDouble(y2, YVector[i+1]))
		{
			if(x1 > x2)
			{
				throw AbortException("X axis must be increase");
			}

			MathTool::LinearFunc(x1,  y1, x2,  y2, k ,b);
			K = K+Converter::convertToString(k);
			B = B+Converter::convertToString(b);

			if( i < XVector.size()-2)
			{
				K = K + strSeparator;
				B = B + strSeparator;
			}
		}
		else
		{
			throw AbortException("failed to converter to double in PiecewiseFunc");
		}
	}

}

//added by liusy[1.1.39]
// -100, 0, 1, 2, -100
int MathTool::getPiecewiseIndex(const double &dValue, const vector<double> &source)
{

	if(source.size() <= 0)
	{
		throw AbortException("source's size is equal 0");
	}

	int nIndex = 0;
	while(nIndex < source.size()-2)
	{
		if(dValue< source[0])
		{
			nIndex = -100;
			break;
		}

		if(dValue > source[source.size()-1])
		{
			nIndex = -100;
			break;
		}

		if(dValue >= source[nIndex] &&  dValue <= source[nIndex+1])
		{
			break;
		}
		nIndex++;
	}

	return nIndex;
}

bool MathTool::isTempMeetThreshold(double dRcpTemp, double dReadTemp, double dThreshold, double &dLower, double &dHigh) //added by zhangpf[1.8.2]
{
	dLower = dRcpTemp - dThreshold;
	dHigh = dRcpTemp + dThreshold;

	if(dReadTemp < dLower || dReadTemp > dHigh)
	{
		return false;
	}
	else
	{
		return true;
	}
}

bool MathTool::isTempStableThreshold(double dLastTemp, double dReadTemp, double dThreshold, bool bIsTempUp) //added by zhangpf[1.8.2]
{
	if(bIsTempUp)
	{
		if(dReadTemp - dLastTemp <= dThreshold)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	else
	{
		if(dLastTemp -dReadTemp <= dThreshold)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}

float MathTool::createRandomValue(double dMin, double dMax)//added by mujy [1.11.0] for data random change
{
    srand(static_cast<unsigned int>(time(NULL)));

    float dRandomV = static_cast<float>(std::rand())/RAND_MAX*(dMax-dMin)+dMin;
    return dRandomV;
}
