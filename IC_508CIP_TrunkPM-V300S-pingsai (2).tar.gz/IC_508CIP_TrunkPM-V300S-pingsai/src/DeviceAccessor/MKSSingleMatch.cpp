/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MKSSingleMatch.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-11-18   LiJuanjuan create
**      
*********************************************************************/
#include "MKSSingleMatch.h"
#include "DeviceManager.h"

#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP;
#endif

using namespace std; 

MKSSingleMatch::ParamPair MKSSingleMatch::m_paramPairs[] = {ParamPair("manaut",DescriptorList("Manual,Auto")),
										 ParamPair("locrem",DescriptorList("Local,Remote"))};
										 
map<string,DescriptorList> MKSSingleMatch::m_params = map<string,DescriptorList>(m_paramPairs, m_paramPairs+2);

MKSSingleMatch::Com MKSSingleMatch::m_commands[] = {{0, ""}, //0	reserved 						
											{0, "MAN", 0},//1 (CH,value)manual
											{0, "AUT", 0},//2 auto
											{0, "LOC", 0},//3 local
											{0, "REM", 0},//4 remote
											{0, "FRE", 0},//5 fault reset
											{1, "STO", 0},//6 store 
											{1, "RCL", 0},//7 recall 											
											{1, "SCO", 0},//8 set c1
											{1, "SCT", 0},//9 set c2											
											{1, "SDT", 0},//10 set delay time
											
											{3, "HPV", 13},//11 get Manual/Auto
											{3, "HPV", 12},//12 get Local/Remote
											{8, "RCO", 0},//13 get c1
											{8, "RCT", 0},//14 get c2
											{6, "RPP", 0},//15 get DCBias
											{8, "HPV", 0}//16 6 get Match0 fault word added by liusy
											};
											

MKSSingleMatch::MKSSingleMatch()
{
}

MKSSingleMatch::~MKSSingleMatch()
{
}

bool MKSSingleMatch::writeInt(int channelNum, int value, const IntTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	int ps = com.m_ps;
	string msg = "";
	switch(ps)
	{
		case 0:
			//msg = com.m_s1;
			msg = m_commands[channelNum + value].m_s1;
			break;
		case 1:
			/*if((com.m_s1 == "SPR0=" || com.m_s1 == "RPR0=") && (value > 29))
			{
				msg = com.m_s1 + m_memList.getDescriptor(value-29 + 3);//D or E
			}
			else
			{
				msg = com.m_s1 + Converter::convertToString(value);
			}*/			
			msg = com.m_s1 + Converter::convertToString(value);
			break;	
	}
	return sendCommand(msg, m_timeOut);
}
	
bool MKSSingleMatch::writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];	
	//string	msg = com.m_s1 + Converter::convertToString((int)(value*10));	
	double tmp = (double)(value*10);//modified by chenmz [V2.0.4]
	double tmp1 = (int)tmp;
	int temp = tmp1;	
	string msg = com.m_s1 + Converter::convertToString(temp);
	return sendCommand(msg, m_timeOut);
}	
		
bool MKSSingleMatch::writeRawCommand(int channelNum, std::string value, const StringTypeInfo &typeInfo)
{
	return sendCommand(value, m_timeOut);
}
		
bool MKSSingleMatch::readInt(int channelNum, int *value, const IntTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	int ps = com.m_ps;
	string res = readCommand(com.m_s1, m_timeOut);
	size_t pos = res.find(com.m_s1,0);  //changed by wzd 1.1.39
	if(pos == string::npos)
	{
		throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for response ["+Hex::GetHexString(res.c_str(),res.size())+"] is invalid.");
	}
	else
	{
		string t_value = (res.substr(pos+ps, 4));
		if(com.m_ps2 == 0)
		{
			if(!Converter::stringToInt(*value, t_value))
			{
				throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for can't convert response ["+t_value+"] to integer value.");
			}
		}
		else
		{
			if(!Converter::stringToInt(*value, t_value, std::hex))
			{
				throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for can't convert response ["+t_value+"] to integer value.");
			}
			*value = (*value >> com.m_ps2) & 0x0001;			
		}
		return true;
	}
	
}
		
bool MKSSingleMatch::readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	int ps = com.m_ps;
	string res = readCommand(com.m_s1, m_timeOut);
	size_t pos = res.find(com.m_s1,0);  //changed by wzd 1.1.39
	if(pos == string::npos)
	{
		throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for response ["+Hex::GetHexString(res.c_str(),res.size())+"] is invalid.");
	}
	else
	{
		string t_value = (res.substr(pos+ps, 6));
		int t_intv;
		if(!Converter::stringToInt(t_intv, t_value))
		{
			throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for can't convert response ["+t_value+"] to integer value.");
		}
		*value = t_intv / 2;
		if(*value < 0)
		{
			*value = 0;
		}
		else if(*value > 10000)
		{
			*value = 10000;
		}
		return true;
	}
	
}

//added by liusy for checking Match0 fault word[20190806]
bool MKSSingleMatch::readString(int channelNum, string *pValue, const StringTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	int ps = com.m_ps;
	string res = readCommand(com.m_s1, m_timeOut);
	size_t pos = res.find(com.m_s1,0);  //changed by wzd 1.1.39
	if(pos == string::npos)
	{
		throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for response ["+Hex::GetHexString(res.c_str(),res.size())+"] is invalid.");
	}
	else
	{
		string strValue = (res.substr(pos+ps,4));//possible error
		if(strValue == "0000")
		{
			*pValue = "NoError";
		}
		else
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "MKSSingleMatch: channel ["+Converter::convertToString(channelNum)+"] read back = "+res +" ;split value = "+strValue);
			*pValue = strValue;
		}	
		return true;
	}
}
void MKSSingleMatch::initChs(DeviceNode<MKSSingleMatch> *node)
{
	node->registerWriteCh(0, &MKSSingleMatch::writeRawCommand);
	for(int i = 1; i <= 9; ++i)
	{
		node->registerWriteCh(i, &MKSSingleMatch::writeInt);
	}
	node->registerWriteCh(10, &MKSSingleMatch::writeDouble);
	for(int i = 11; i <= 14; ++i)
	{
		node->registerReadCh(i, &MKSSingleMatch::readInt);
	}	
	node->registerReadCh(15, &MKSSingleMatch::readDouble);
	node->registerReadCh(16, &MKSSingleMatch::readString);	//added by liusy for checking Match0 fault word[20190806]
	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &MKSSingleMatch::getStatus);
}

void MKSSingleMatch::initDevice()
{
	cout<<"Start Scan  MKS Single Match...."<<endl;
	try
	{
		sendCommand("HPV0=17", m_timeOut);
	}
	catch(...)
	{
		sendCommand("HPV0=17", m_timeOut);
	}
	try
	{
		sendCommand("HPV1=9", m_timeOut);
	}
	catch(...)
	{
		sendCommand("HPV1=9", m_timeOut);
	}
	try
	{
		sendCommand("HPV2=FF", m_timeOut);
	}
	catch(...)
	{
		sendCommand("HPV2=FF", m_timeOut);
	}
	cout<<"Scan Single Match Successfully...."<<endl;
}
		
void MKSSingleMatch::init()
{
	DeviceNode<MKSSingleMatch> *node = new DeviceNode<MKSSingleMatch>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	if(!isSimulated())
	{
		initChs(node);		
		initDevice();
	}
}

IMPLEMENT_DYNAMIC(MKSSingleMatch, MKSMatch )
BEGIN_MSG_MAP(MKSSingleMatch, MKSMatch )
    SET_V( init, MKSSingleMatch )
END_MSG_MAP
