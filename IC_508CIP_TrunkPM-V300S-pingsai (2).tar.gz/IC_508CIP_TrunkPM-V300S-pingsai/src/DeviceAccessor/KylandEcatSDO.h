/*
 * KylandEcatSDO.h
 *
 *  Created on: 2025��8��15��
 *      Author: zhangcx
 */

#ifndef KYLANDECATSDO_H_
#define KYLANDECATSDO_H_

#include <string>
#include "AbstractDevice.h"
#include "IntTypeInfo.h"
#include "DoubleTypeInfo.h"
#include <fstream>
#include "DeviceNode.h"
#include "IODevice.h"
#include "IMutex.h"
#include <map>
#include "Util.h"
#include "IStringList.h"
#include "unistd.h"
#include "sys/time.h"
#include "stdio.h"
#include "stdlib.h"
#include "StrTool.h"

#include "EtherCatToSerial.h"

#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
using namespace IAP;
#endif


//typedef unsigned char       BOOL;
typedef char                SINT;
typedef int                 INT;
typedef float               REAL;

class SDOParam
{
public:
	int m_nChannel;
	unsigned int m_nRW;
	unsigned short m_nSlaveAddress;
	unsigned short m_nIndex;
	unsigned char m_charSubindex;
	unsigned int m_nLength;

	SDOParam()
	{
		m_nChannel = 0;
		m_nRW = 0;
		m_nSlaveAddress = 0;
		m_nIndex = 0;
		m_charSubindex = 0;
		m_nLength = 0;
	}
};

class KylandEcatSDO : public AbstractDevice {

	DECLARE_DYNAMIC(KylandEcatSDO)
	DECLARE_MSG_MAP

private:


protected:
	vector<SDOParam> m_vSDOParam;

	bool sendSDOToDevice(int nChannel, unsigned char* pdata);

	int m_nNodeNum;
	int m_nPollInterval;
	int m_nTimeOut;

	SDOParam findSDOParam(int nChannel);

public:
	KylandEcatSDO();
	~KylandEcatSDO();

	virtual void loadDevice();
	virtual void init();
	virtual void initChs(DeviceNode<KylandEcatSDO>* pNode);
	void setTimeOut(int nTime);
	void setNodeNum(int nNodeNum);
	void setPollIntervalMS(int nInterval);

	bool writeInt(int nChannelNum, int nValue, const IntTypeInfo& typeInfo);
	bool writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo& typeInfo);
	bool readDouble(int nChannelNum, double* dValue, const DoubleTypeInfo& typeInfo);
	bool readInt(int nChannelNum, int* nValue, const IntTypeInfo& typeInfo);

	void setAddressMap(string strAddress);

};

#endif /* KYLANDECATSDO_H_ */
