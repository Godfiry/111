/********************************************************************
** Copyright (c) 2016, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: NoahPOUChiller.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2016-2-23   mujy creat
**      
*********************************************************************/
#include "NoahPOUChiller.h"
#include <string.h>
#include "DeviceManager.h"
#include "ObjectManager.h"
#include "Converter.h"

#include <sys/time.h>
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;


NoahPOUChiller::Address NoahPOUChiller::m_addInfo[] = {{0,0},//reserved
													{942, 1},//1(start/stop )
													{330, 10},//2(set temperature, -20~90)
													{363, 10},//3(read temperature, -20~90)
													{897, 0x0001},//4(read ErrorCodes:overtemp)
													{897, 0x0002},//5(read ErrorCodes:LowProcessFlow)
													{897, 0x0008},//6(read ErrorCodes:low fluid)
													{897, 0x0080},//7(read ErrorCodes:SystemStatusAlarm,such as ambient error)
													{943, 0x0002},//8(read local remote)
													{943, 0x0004},//9(read alarm)
													{943, 0x0001}//10(read Activemode)
													};

NoahPOUChiller::NoahPOUChiller():SerialDevice(80, "")
{
	m_resLen = 8;
	m_timeOut = 20;//2s
	
	//the form of the read command
	m_readCmd[0] = 0x01;//controller address
	m_readCmd[1] = 0x03;//function read
	m_readCmd[2] = 0x00;//read starting at register high byte
	m_readCmd[3] = 0x00;//read starting at register low byte
	m_readCmd[4] = 0x00;//read number of consecutive register (always 0)
	m_readCmd[5] = 0x01;//read number of consecutive register (always 1)
	m_readCmd[6] = 0x00;//Low byte of CRC
	m_readCmd[7] = 0x00;//High byte of CRC

	//the form of the write command
	m_writeCmd[0] = 0x01;//controller address
	m_writeCmd[1] = 0x06;//function multiple write
	m_writeCmd[2] = 0x00;//write starting at register High byte
	m_writeCmd[3] = 0x00;//write starting at register Low byte
	m_writeCmd[4] = 0x00;//data High byte of 1# register write 
	m_writeCmd[5] = 0x00;//data Low byte of 1# register write
	m_writeCmd[6] = 0x00;//Low byte of CRC
	m_writeCmd[7] = 0x00;//High byte of CRC
	
}

NoahPOUChiller::~NoahPOUChiller()
{
}

unsigned short  NoahPOUChiller::GetCRC16Code(char* nCmd,int nLen)
{
	unsigned short crc=0xFFFF;
	unsigned short polynomial=0xA001;
	
	unsigned int i,j;
	for(i=0;i<nLen;i++)
	{
		crc=crc^(nCmd[i]&0x00FF);
		for(j=0;j<8;j++)
		{
			if(crc&1)
			{
          		crc=crc>>1;
		   		crc=crc^polynomial;
			}
			else
			{
				crc=crc>>1;
			}
		}
	}
	return crc;
}

int NoahPOUChiller::readCommand(char *command, int timeOut, int len)
{
	char res[m_resLen];	
	memset(res, 0, m_resLen);
	sendCommandOnly(command, len);
	/*int resNum = */getResultOnly(res, m_resLen, timeOut);
	/*
	for(int i=0; i<resNum; ++i)
	{
		cout << hex<<(unsigned int)res[i] << endl;
	}*/
	if((res[0] == 0x01) && (res[1]== 0x03))
	{
		int value = 0;
		value=(int)(res[3] <<8 | (res[4]&0x00FF));
		//value = ((int)res[4] & 0xff) + (((int)res[3] << 8) & 0xff00);
		return value;
	}
	else
	{
		throw IOException("Chiller read command failed for unknown response [" + Hex::GetHexString(res,2)+"]");
	}
}

bool NoahPOUChiller::sendCommand(char *command, int timeOut, int len)
{	
	char res[m_resLen];
	memset(res, 0, m_resLen);
	sendCommandOnly(command, len);
	/*int resNum = */getResultOnly(res, m_resLen, timeOut);
	/*
	for(int i=0; i<resNum; ++i)
	{
		cout << hex<<(unsigned int)res[i] << endl;
	}*/
	if((res[0] == 0x01) && (res[1]== 0x06))
	{
		return true;
	}
	else
	{
		throw IOException("Chiller send control command failed for unknown response [" + Hex::GetHexString(res,2)+"]");
	}
}

//read data from the device 
bool NoahPOUChiller::readDouble(int channelNum,double * value ,const DoubleTypeInfo& typeinfo)
{
	if (isSimulated())
	{
		struct timeval tm;
		struct timezone *tz = NULL;
		
		gettimeofday(&tm,tz);
		*value = typeinfo.getMax() * ((double)tm.tv_usec / 1000000);
		return true;
	}
	unsigned int t_addr = m_addInfo[channelNum].m_address;
	m_readCmd[2] = (t_addr >> 8) & 0xFF;//address high byte
	m_readCmd[3] = t_addr & 0xFF;//address low byte
	
	unsigned short crc = GetCRC16Code(m_readCmd, 6);
	m_readCmd[6] = (crc & 0xFF) & 0xFF;    // low byte of CRC
	m_readCmd[7] = (crc >> 8) & 0xFF;  //  high byte of CRC

	int t_value = readCommand(m_readCmd, m_timeOut, 8);	
	*value = (double)t_value / m_addInfo[channelNum].m_p1;
	return true;
}

//write data to the chiller
bool NoahPOUChiller::writeDouble(int channelNum, double settemp, const DoubleTypeInfo& typeinfo)
{
	if (isSimulated())
	{
		return true;
	}
	unsigned int t_addr = m_addInfo[channelNum].m_address;
	m_writeCmd[2] = (t_addr >> 8) & 0xFF;//address high byte
	m_writeCmd[3] = t_addr & 0xFF;//address low byte
	unsigned int t_value = 0;
	t_value = (int)(settemp * m_addInfo[channelNum].m_p1);
	m_writeCmd[4] = (t_value >> 8) & 0xFF;//data high byte
	m_writeCmd[5] = t_value & 0xFF;//data low byte
	unsigned short crc = GetCRC16Code(m_writeCmd, 6);//CRC
	m_writeCmd[6] = (crc & 0xFF) & 0xFF;    // low byte of CRC
	m_writeCmd[7] = (crc >> 8) & 0xFF;  //  high byte of CRC
	
	return sendCommand(m_writeCmd, m_timeOut, 8);
}

bool NoahPOUChiller::writeInt(int channelNum, int value, const IntTypeInfo &typeInfo)
{
	if (isSimulated())
	{
		return true;
	}
	unsigned int t_addr = m_addInfo[channelNum].m_address;
	m_writeCmd[2] = (t_addr >> 8) & 0xFF;//address high byte
	m_writeCmd[3] = t_addr & 0xFF;//address low byte
	if(value == 1)
	{
		m_writeCmd[4] = 0x00;
		m_writeCmd[5] = 0x01;
	}
	else
	{
		m_writeCmd[4] = 0x00;
		m_writeCmd[5] = 0x00;
	}
	unsigned short crc = GetCRC16Code(m_writeCmd, 6);//CRC
	m_writeCmd[6] = (crc & 0xFF) & 0xFF;    // low byte of CRC
	m_writeCmd[7] = (crc >> 8) & 0xFF;  //  high byte of CRC
	return sendCommand(m_writeCmd, m_timeOut, 8);
}
bool NoahPOUChiller::readInt(int channelNum, int *value, const IntTypeInfo &typeInfo)
{
	unsigned int t_addr = m_addInfo[channelNum].m_address;
	m_readCmd[2] = (t_addr >> 8) & 0xFF;//address high byte
	m_readCmd[3] = t_addr & 0xFF;//address low byte
		
	unsigned short crc = GetCRC16Code(m_readCmd, 6);
	m_readCmd[6] = (crc & 0xFF) & 0xFF;    // low byte of CRC
	m_readCmd[7] = (crc >> 8) & 0xFF;  //  high byte of CRC
	int t_value = readCommand(m_readCmd, m_timeOut, 8);
	*value = ((t_value & m_addInfo[channelNum].m_p1) != 0);
	return true;
}
//register channel
void NoahPOUChiller::initChs(DeviceNode<NoahPOUChiller> *node)
{
	node->registerWriteCh(1, &NoahPOUChiller::writeInt);//1(start/stop )
	node->registerWriteCh(2, &NoahPOUChiller::writeDouble);//2(set temperature, -20~90)
	node->registerReadCh(3, &NoahPOUChiller::readDouble);//3(read temperature, -20~90)
	for(int i = 4; i <= 10; ++i)//4(read ErrorCodes:overtemp),5(read ErrorCodes:LowProcessFlow),6(read ErrorCodes:low fluid)
	{//7(read ErrorCodes:SystemStatusAlarm,such as ambient error),8(read local remote),9(read alarm),10(read Activemode)
		node->registerReadCh(i, &NoahPOUChiller::readInt);	
	}
	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &NoahPOUChiller::getStatus);
}
void NoahPOUChiller::initDevice()
{
	cout<<"Start Scan NoahPOU Chiller...."<<endl;
	//say hello to chiller
	int iTemp;
	readInt(4,&iTemp,IntTypeInfo());
	cout<<"Scan NoahPOU Chiller Successfully...."<<endl;
}
//init device		
void NoahPOUChiller::init()
{
	DeviceNode<NoahPOUChiller> *node = new DeviceNode<NoahPOUChiller>(m_pollPeriod, this);
	initChs(node);		
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	initDevice();
}

IMPLEMENT_DYNAMIC(NoahPOUChiller, SerialDevice)

BEGIN_MSG_MAP(NoahPOUChiller, SerialDevice)
	SET_V( init, NoahPOUChiller)
END_MSG_MAP



