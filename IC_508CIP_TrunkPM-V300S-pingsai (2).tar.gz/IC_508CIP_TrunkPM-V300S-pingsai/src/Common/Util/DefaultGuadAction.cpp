/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: DefaultGuadAction.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-9-28   LiJuanjuan create
**      
*********************************************************************/
#include "DefaultGuadAction.h"
#include "Actuator.h"
#include "SysLogger.h"
#include "ConfigException.h"
#include "ObjectManager.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "InvalidNameException.h"
#endif
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
using namespace IAP::CONDITION;
#endif

using namespace std;

DefaultGuadAction::DefaultGuadAction()
{
}

DefaultGuadAction::~DefaultGuadAction()
{
}

void DefaultGuadAction::execute(const AppConditionPtr &trigger)
{
	string strActionFailedReason = "";
	for(int i=0; i<m_actuators.size(); ++i)
	{
		try
		{
			m_actuators[i]->setBit();
		}
		catch(const exception &ex)
		{
			strActionFailedReason += m_actuators[i]->getSelfName() + " failed for "+ string(ex.what())+";    ";
		}
	}
	if(strActionFailedReason != "")
	{
		m_nActionFailedAlarm->setDescription(strActionFailedReason);
		m_nActionFailedAlarm->post(this);
	}
}
		
void DefaultGuadAction::addActuator(const std::string &path)
{
	ManagedObject *t_obj = NULL;
	try
	{
		t_obj = ObjectManager::getInstance()->getObject(this, path);
	}
	catch(const InvalidNameException &ex)
	{
		t_obj = ObjectManager::getInstance()->getObject(path);
	}
	Actuator *t_obj2 = dynamic_cast<Actuator*>(t_obj);
	if(NULL == t_obj2)
	{
		string error = "the object under path '" + path + "' is not a Actuator";
		throw ConfigException(error);
	}
	m_actuators.push_back(t_obj2);	
}

IMPLEMENT_DYNAMIC(DefaultGuadAction, GuadAction)		

BEGIN_MSG_MAP( DefaultGuadAction, GuadAction )
	SET_S(addActuator, DefaultGuadAction)
END_MSG_MAP

