/********************************************************************
** Copyright (c) 2019, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: DefaultErrorCodeParser.cpp
** Description:
** Release: 1.1
** Modification history:
** 					2019-5-8   mujy create
**
*********************************************************************/
#include "DefaultErrorCodeParser.h"
#include "SysLogger.h"

#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
#endif
using namespace std;

DefaultErrorCodeParser::DefaultErrorCodeParser()
{
}

DefaultErrorCodeParser::~DefaultErrorCodeParser()
{
}

string DefaultErrorCodeParser::parseErrorCode(const string strCode)
{
	return ErrorCodeParser::parseErrorCode(strCode);
}

IMPLEMENT_DYNAMIC(DefaultErrorCodeParser,ErrorCodeParser)

BEGIN_MSG_MAP(DefaultErrorCodeParser,ErrorCodeParser)
END_MSG_MAP

