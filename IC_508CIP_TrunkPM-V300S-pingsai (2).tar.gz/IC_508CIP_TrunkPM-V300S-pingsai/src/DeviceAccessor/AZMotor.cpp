#include "AZMotor.h"
#include "DeviceManager.h"

#include "Converter.h"
#ifdef IAP4_0
#include "ITime.h"
#else
#include "Time.h"
#endif
#include "UTime.h"
//#include "Util.h"
#include <cctype>
#include "SysLogger.h"
#include <string.h>
#include "XmlGetter.h"
#include <iostream>
#include "Hex.h"
#include <string>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif


using namespace std;

AZMotor::AZMotor():SerialDevice(100,"")
{
	m_writeCmd[0] = 0x01;
	m_writeCmd[1] = 0x06;
	m_writeCmd[2] = 0x00;
	m_writeCmd[3] = 0x7d;
	m_writeCmd[4] = 0x00;
	m_writeCmd[5] = 0x00;
	m_writeCmd[6] = 0x00;
	m_writeCmd[7] = 0x00;
	m_pollPeriod = 500;//change by songpan 20200115 from 1000 to 200
	//add by songpan 20200110
	m_timeOut = 20;
	m_readCmd[0] = 0x01;
	m_readCmd[1] = 0x03;
	m_readCmd[2] = 0x00;
	m_readCmd[3] = 0xCC;
	m_readCmd[4] = 0x00;
	m_readCmd[5] = 0x02;
	m_readCmd[6] = 0x00;
	m_readCmd[7] = 0x00;
	//add by songpan 20200106
	m_regWriteAddress[0] = 0x08;
	m_regWriteAddress[1] = 0x09;
	m_regWriteAddress[2] = 0x0A;
	m_regWriteAddress[3] = 0x0B;

}

AZMotor::~AZMotor()
{
}

unsigned short AZMotor::calculateLRC(char* buffer,int len)
{
	//add by songpan 20200113
	unsigned short wcrc = 0xffff;
	int temp;
	char *pushmsg = buffer;
	for(int j=0;j<len;j++)
	{
		temp = *pushmsg & 0x00FF;
		pushmsg++;
		wcrc ^= temp;
		for(int i=0;i<8;i++)
		{
			if(wcrc & 0x0001)
			{
				wcrc >>= 1;
				wcrc ^= 0xA001;	
			}else{
				wcrc >>= 1;
			}
		}
	}
	return wcrc;
	
}

void AZMotor::clearZero()
{
	m_writeCmd[5] = 0x00;
	unsigned short t_crc = calculateLRC(m_writeCmd,6);
	m_writeCmd[6] = t_crc&0xff;
	m_writeCmd[7] = t_crc>>8;
	sendCommandOnly(m_writeCmd,8);
}

bool AZMotor::writeInt(int channelNum,int value,const IntTypeInfo &typeInfo)
{
	//add by songpan 20200115
	if(channelNum >=1 && channelNum<=2)    //pin 
	{
		m_writeCmd[0] = 0x01;
		m_writeCmd[5] = m_regWriteAddress[channelNum-1];
	}
	if(channelNum >=4 && channelNum<=6)    //focusring
	{	
	        m_writeCmd[0] = 0x02;
		m_writeCmd[5] = m_regWriteAddress[channelNum-4];
	}
	if(channelNum == 9)//focusring zero //add by songpan 20200703
	{
		m_writeCmd[0] = 0x02;
		m_writeCmd[5] = m_regWriteAddress[3];
	}
	if(channelNum == 10)    //pin home add sp 20201208
	{
		m_writeCmd[0] = 0x01;
		m_writeCmd[5] = 0x10;
	}
	unsigned short t_crc = calculateLRC(m_writeCmd,6);
	m_writeCmd[6] = t_crc&0xff;
	m_writeCmd[7] = t_crc>>8;
	//cout<<hex<<(int)m_writeCmd[6];
	//cout<<hex<<(int)m_writeCmd[7];
	//SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::EVENT, getName() + "AZMotor start:" + m_writeCmd);
	if(value==1){	
		sendCommandOnly(m_writeCmd,8);
		//sleep(5);//delete by songpan 20200116
		clearZero();
	}
	else
	{
		//add sp 20210106
		if(channelNum == 10)    //pin home add sp 20201208
		{
			sendCommandOnly(m_writeCmd,8);
			clearZero();
		}
		return true;
	}
	return true;
}
//add by songpan 20200110

bool AZMotor::writeAbsPos(int channelNum,double value,const DoubleTypeInfo &typeInfo)//added by wangyk 20251225 [v1.8.1] for MotorPin DongfangMada
{
	//added by wangyk 20251125
	if(channelNum == 12)//any position
	{
		int nValue = value * 1000;
		char t_charValue[5];

	    if (nValue >= 0)
	    {
	        uint32_t hex_value = static_cast<uint32_t>(nValue);
	        for (int i = 0; i < 4; ++i)
	        {
	        	t_charValue[i] = (hex_value >> (24 - 8 * i)) & 0xFF;
	        }
	    }
	    else
	    {
	        uint32_t hex_value = static_cast<uint32_t>(nValue) & 0xFFFFFFFF;
	        for (int i = 0; i < 4; ++i)
	        {
	        	t_charValue[i] = (hex_value >> (24 - 8 * i)) & 0xFF;
	        }
	    }

		//set position High
		m_writeCmd[2] = 0x18;
		m_writeCmd[3] = 0x02;
		m_writeCmd[4] = t_charValue[0];
		m_writeCmd[5] = t_charValue[1];
		calCRCAndSendCommand(m_writeCmd);

		//set position Low
		m_writeCmd[2] = 0x18;
		m_writeCmd[3] = 0x03;
		m_writeCmd[4] = t_charValue[2];
		m_writeCmd[5] = t_charValue[3];
		calCRCAndSendCommand(m_writeCmd);

		//usleep(1000000);
		//start move
		m_writeCmd[2] = 0x00;
		m_writeCmd[3] = 0x7D;
		m_writeCmd[4] = 0x00;
		m_writeCmd[5] = 0x08;
	}

	calCRCAndSendCommand(m_writeCmd);
	clearZero();

	char response[RESP_LEN];
	bzero(response, RESP_LEN);
	if(getResultOnly(response, RESP_LEN, m_timeOut) < 0)
	{
		throw IOException("AZMotor reading back times out");
	}

	return true;
}


bool AZMotor::readDouble(int channelNum,double *value,const DoubleTypeInfo &typeInfo)
{
	if(channelNum == 3)//pin 
	{
		m_readCmd[0] = 0x01;
		m_readCmd[3] = 0xCC;	
	}
	if(channelNum == 7)//focusring 
	{
		m_readCmd[0] = 0x02;
		m_readCmd[3] = 0xCC;
	}
	if(channelNum == 8)//pin 
	{
		m_readCmd[0] = 0x01;
		m_readCmd[3] = 0x80;	
	}
	if(channelNum == 11)//pin torque
	{
		m_readCmd[0] = 0x01;
		m_readCmd[3] = 0xD6;	
	}
	unsigned short t_crc = calculateLRC(m_readCmd,6);
	m_readCmd[6] = t_crc&0xff;
	m_readCmd[7] = t_crc>>8;

	
	char response[RESP_LEN];
	bzero(response, RESP_LEN);
	//cout<<"read send:"<<Hex::GetHexString(m_readCmd,8)<<endl;
	sendCommandOnly(m_readCmd,8);
	//SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::EVENT, getName() + "AZMotor sendcommandonly end:");
	if(getResultOnly(response, RESP_LEN, m_timeOut) < 0)
	{
		throw IOException("AZMotor reading back times out");
	}

	//SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::EVENT, getName() + "AZMotor getResultOnly end:");
	//cout<<"read receive:"<<Hex::GetHexString(response,8)<<endl;
	//SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::EVENT, getName() + "AZMotor hex end:");
	if(response[0] == m_readCmd[0]&&response[1]==0x03)
	{
		if(response[2]==0x04)
		{
			unsigned char cByte[4];
			response[3] = response[3]&0x00ff;
			response[4] = response[4]&0x00ff;
			response[5] = response[5]&0x00ff;
			response[6] = response[6]&0x00ff;
			
			cByte[0] = response[3];
			cByte[1] = response[4];
			cByte[2] = response[5];
			cByte[3] = response[6];
			//cout<<hex<<(int)cByte[3]<<endl;// delete by songpan 20200221
			if(channelNum == 3 || channelNum == 7)
			{
				int temp = (cByte[0]<<24)|(cByte[1]<<16)|(cByte[2]<<8)|cByte[3];
				*value = temp /1000.0; 
			}
			if(channelNum == 8)//add by songpan 20200604
			{
				*value = (cByte[0]<<24)|(cByte[1]<<16)|(cByte[2]<<8)|cByte[3];
				if(*value != 0)
				{
					SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::EVENT, getName() + "AZMotor  Alarm code:" + Converter::convertToString((int)cByte[3]));
				}
			}
			if(channelNum == 11)
			{
				int temp = (cByte[0]<<24)|(cByte[1]<<16)|(cByte[2]<<8)|cByte[3];
				*value = temp/10.0; 
			}
			return true;
		}else
		{
			throw IOException("AZMotor reading data false ..");
		}
	}else
	{
		throw IOException("AZMotor : the read data command is invalid");
	}
}

void AZMotor::WriteToMachien(const std::string &strCmd)//added by wangyk 20251225 [v1.8.1] for MotorPin DongfangMada
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, strCmd);
	cout<<"testmsg send[string]:"<<strCmd<<endl;
	Hex::stringToHexChar(strCmd,m_readCmd,sizeof(m_readCmd));
	cout<<"testmsg send[Hex]:"<<Hex::GetHexString(m_readCmd,8)<<endl;
	sendCommandOnly(m_readCmd,8);

	//usleep(1000000);
	char response[RESP_LEN];
	bzero(response, RESP_LEN);
	if(getResultOnly(response, RESP_LEN, m_timeOut) < 0)
	{
		throw IOException("AZMotor reading back times out");
	}
	//usleep(1000000);
	cout<<"testmsg receive:"<<Hex::GetHexString(response,8)<<endl;
}

bool AZMotor::testMsg(int nChannelNum, string strValue, const StringTypeInfo &typeInfo)//added by wangyk [V1.8.1]
{
    WriteToMachien(strValue);
    return true;
}

void AZMotor::calCRCAndSendCommand(char* arrCmd)//added by wangyk [V1.8.1]
{
	unsigned short t_crc = calculateLRC(arrCmd,6);
	arrCmd[6] = t_crc&0xff;
	arrCmd[7] = t_crc>>8;
	//cout<<"write send:"<<Hex::GetHexString(arrCmd,8)<<endl;
	sendCommandOnly(arrCmd,8);
	//SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::EVENT, getName() + "AZMotor sendcommandonly end:");

	char response[RESP_LEN];
	bzero(response, RESP_LEN);
	if(getResultOnly(response, RESP_LEN, m_timeOut) < 0)
	{
		throw IOException("AZMotor reading back times out");
	}

	//string t_result = getCommandResult(arrCmd,20);
	//cout<<"write receive:"<<Hex::GetHexString(response,8)<<endl;
}

void AZMotor::initChs(DeviceNode<AZMotor> *node)
{
	//node->registerReadCh(0,&SerialDevice::connectStatus);
	node->registerWriteCh(1,&AZMotor::writeInt);
	node->registerWriteCh(2,&AZMotor::writeInt);
	node->registerReadCh(3,&AZMotor::readDouble);
	node->registerWriteCh(4,&AZMotor::writeInt);
	node->registerWriteCh(5,&AZMotor::writeInt);
	node->registerWriteCh(6,&AZMotor::writeInt);
	node->registerReadCh(7,&AZMotor::readDouble);
	node->registerReadCh(8,&AZMotor::readDouble);
	node->registerWriteCh(9,&AZMotor::writeInt);
	node->registerWriteCh(10,&AZMotor::writeInt);
	node->registerReadCh(11,&AZMotor::readDouble);
	node->registerWriteCh(12,&AZMotor::writeAbsPos);//added by wangyk 20251225 [v1.8.1] for MotorPin Any Position

	node->registerWriteCh(10000,&AZMotor::testMsg);//added by wangyk 20251225 [v1.8.1] for MotorPin Test
}

void AZMotor::initDevice()
{
    //added by wangyk 20251225 [v1.8.1] for MotorPin DongfangMada
	double dPower;
	try
	{
		readDouble(3,&dPower,DoubleTypeInfo());
	}
	catch(exception &ex)
	{
		cout<<"Scan AZMotor failed. Communication abnormal!"<<endl;
		throw;
	}
}

void AZMotor::init()
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "AZMotor start");
	DeviceNode<AZMotor> *node = new DeviceNode<AZMotor>(m_pollPeriod,this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	if(!isSimulated())
	{
		initChs(node);	
		initDevice();
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP,LEVEL::EVENT,getName()+"AZMotor end");
}

IMPLEMENT_DYNAMIC(AZMotor, SerialDevice )

BEGIN_MSG_MAP(AZMotor, SerialDevice )
	SET_V( init, AZMotor )
END_MSG_MAP
