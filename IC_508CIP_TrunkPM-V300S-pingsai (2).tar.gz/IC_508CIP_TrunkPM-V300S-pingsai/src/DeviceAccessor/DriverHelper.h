/********************************************************************
** Copyright (c) 2025, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: DriverHelper.h
** Description: This driver is 
*                          
** Release: 1.1
** Modification history: 
** 					2025-7-7   mujy create [1.5.0]
**      
*********************************************************************/
#ifndef DRIVERHELPER_H_
#define DRIVERHELPER_H_
#include <string>
#include <stdint.h>

class DriverHelper
{
public:
	DriverHelper();
	virtual ~DriverHelper();
	
	static bool isSystem64bit();

	static int32_t littleEndianToInt(const uint8_t * bytes,int nLength);
};

#endif /*DRIVERHELPER_H_*/
