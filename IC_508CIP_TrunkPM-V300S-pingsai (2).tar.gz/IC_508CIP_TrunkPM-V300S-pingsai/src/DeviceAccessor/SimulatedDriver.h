/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: SimulatedDriver.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-10-06   LiJuanjuan create
**      
*********************************************************************/
#ifndef SIMULATEDDRIVER_H_
#define SIMULATEDDRIVER_H_

#include "AbstractDevice.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class SimulatedDriver:public AbstractDevice
{
	DECLARE_DYNAMIC(SimulatedDriver)	
	DECLARE_MSG_MAP	
	
	private:
		int m_interval;
		int m_doubleChNum;
		int m_intChNum;
		int m_strChNum;
		int m_nodeNum;
	
	public:
		SimulatedDriver();
		virtual ~SimulatedDriver();
		
		bool readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo);
		
		void init();
		void setPollInterval(int interval);
		void setDoubleChNum(int num);
		void setIntChNum(int num);
		void setStrChNum(int num);
		void setNodeNum(int num);
};

#endif /*SIMULATEDDRIVER_H_*/
