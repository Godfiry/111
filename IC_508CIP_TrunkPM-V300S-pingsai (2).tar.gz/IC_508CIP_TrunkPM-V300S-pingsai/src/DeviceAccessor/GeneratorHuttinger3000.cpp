/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: GeneratorHuttinger3000.cpp
** Description:
** Release: 1.1
** Modification history:
**                     2022-10   weizd create
**
*********************************************************************/

#include "GeneratorHuttinger3000.h"
#include <string.h>
#include "DeviceManager.h"
#include <iostream>
#include <sys/time.h>
#include <sstream>
#include "Converter.h"
#include "SysLogger.h"
#include "CheckCalculationTool.h"
#include "IODevice.h"
#include <unistd.h>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std;

GeneratorHuttinger3000::GeneratorHuttinger3000():SerialDevice(20,"")
{
    m_timeOut=20;
    m_resLen=20;

    m_readCmd[0] = 0xAA;//start byte
    m_readCmd[1] = 0x02;//Address master 0x01 slave 0x02
    m_readCmd[2] = 0x00;//data length
    m_readCmd[3] = 0x00;//GS
    m_readCmd[4] = 0x01;//CMD read 0x01 write 0x02
    m_readCmd[5] = 0x00;//IDXLO
    m_readCmd[6] = 0x00;//IDXHI
    m_readCmd[7] = 0x01;//SUBIDX
    m_readCmd[8] = 0xFF;//STAT
    //m_readCmd[9] = 0x04;//DATA TYPE

    m_writeCmd[0] = 0xAA;//start byte
    m_writeCmd[1] = 0x02;//Address master 0x01 slave 0x02
    m_writeCmd[2] = 0x00;//data length
    m_writeCmd[3] = 0x00;//GS
    m_writeCmd[4] = 0x02;//CMD read 0x01 write 0x02
    m_writeCmd[5] = 0x00;//IDXLO
    m_writeCmd[6] = 0x00;//IDXHI
    m_writeCmd[7] = 0x01;//SUBIDX
    m_writeCmd[8] = 0x00;//STAT
    m_writeCmd[9] = 0x04;//DATA TYPE

    m_ack[0] = (char)0x06;
}

GeneratorHuttinger3000::~GeneratorHuttinger3000()
{
}
GeneratorHuttinger3000::Com GeneratorHuttinger3000::m_commands[] = {
                                            {0x6F,0x00}, //0 setPowerOnOff
                                            {0x06,0x00}, //1 setpower
                                            {0xC9,0x01}, //2 setFrepuency
                                            {0x04,0x02}, //3 setFrepuencyMode
                                            {0x46,0x02}, //4 set Tuning start offset
                                            {0x47,0x02}, //5 set Max Tuning offset
                                            {0x48,0x02}, //6 set Min Tuning offset
                                            {0x4B,0x02}, //7 set Modulation period
                                            {0x4C,0x02}, //8 set Gain
                                            {0x4D,0x02}, //9 set Relative gain
                                            {0x4E,0x02}, //10 set Modulation deviation
                                            {0x4F,0x02}, //11 set Relative modulation deviation
                                            {0x05,0x01}, //12 getControlMode
                                            {0x12,0x00}, //13 getFwdPower
                                            {0x14,0x00}, //14 getreflectPower
                                            {0x07,0x02}, //15 getFrepuency
                                            {0x4D,0x00}, //16 Reset alarm messages
                                            {0x4F,0x00}, //17 Reset warning messages
                                            {0x6D,0x01}, //18 set PulseDutycycle
                                            {0x6C,0x01}, //19 set PulseFrequency
                                            {0x6A,0x01}, //20 set PulseMode
                                            {0x41,0x03}, //21 get PulseDutycycle
                                            {0x42,0x03}, //22 get PulseFrequency
                                            {0x75,0x00}, //23 get PowerStatus
                                            {0x75,0x00}, //24 get WarningStatus
                                            {0x75,0x00}, //25 get AlarmStatus
                                            {0x75,0x00}, //26 get PulseModeStatus
                                            {0x75,0x00}, //27 get TemperatureStatus
                                            //added by taohao[1.3.0] for HTG-60M
                                            {0x62,0x03}, //28 setFrepuencyMode(60M)
                                            {0x63,0x00}, //29 getSweepFrepuency(60M)
                                            {0x07,0x00}, //30 setLoadPower(60M)
                                            {0x1C,0x00}, //31 setLoadForwordMode(60M)
                                            {0x5B,0x03}  //32 setPower(60M)
};


bool GeneratorHuttinger3000::sendCommand(char *msg, char *response, int msg_timeout,int length)
{
    //sendCommandOnly(msg,MESS_LEN);
    //getResultOnly(response,length+1,msg_timeout);
    //string s1=std::string(msg,length);
     //cout<<s1<<endl;
    //string s2=getCommandResult(s1,m_timeOut);

    //strcpy(response,s2.c_str());

    int ret = getCommandResult(msg, length, response, 13, msg_timeout);
    if(response[0] != 0x06 || ret <= 0)
    {
        cout<<"sendCommand response "<<hex<<(int)response[0]<<" "<<(int)response[1]<<" "<<(int)response[2]<<" "<<(int)response[3]<<" "<<(int)response[4]<<endl;
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": response[0] is :" + Converter::convertToString(response[0]));
        throw IOException("Send packet's verification is wrong");
    }
    //cout<<"writeresp "<<hex<<(int)response[0]<<" "<<(int)response[1]<<" "<<(int)response[2]<<" "<<(int)response[3]<<" "<<(int)response[4]<<endl;
    //cout<<"writeresp "<<hex<<(int)response[5]<<" "<<(int)response[6]<<" "<<(int)response[7]<<" "<<(int)response[8]<<" "<<(int)response[9]<<endl;
    //cout<<"writeresp "<<hex<<(int)response[10]<<" "<<(int)response[11]<<" "<<(int)response[12]<<" "<<(int)response[13]<<" "<<(int)response[14]<<endl;
    //cout<<"writeresp "<<hex<<(int)response[15]<<" "<<(int)response[16]<<" "<<(int)response[17]<<endl;
    //else if(response[3] != 0x00)
    //{
        //cout<<"sendCommand response "<<hex<<(int)response[0]<<" "<<(int)response[1]<<" "<<(int)response[2]<<" "<<(int)response[3]<<" "<<(int)response[4]<<endl;
        //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": response[3] is :" + Converter::convertToString(response[3]));
        //throw IOException("Response(CSR) codes was not accepted");
    //}
    //sendCommandOnly(ack,1);
   return true;
}

bool GeneratorHuttinger3000::readCommand(char *msg, char *response, int msg_timeout,int resplen, int msglen)
{
    int ret = getCommandResult(msg, msglen, response, resplen, m_timeOut);
    //cout<<"resp "<<hex<<(int)response[0]<<" "<<(int)response[1]<<" "<<(int)response[2]<<" "<<(int)response[3]<<" "<<(int)response[4]<<endl;
    //cout<<"resp "<<hex<<(int)response[5]<<" "<<(int)response[6]<<" "<<(int)response[7]<<" "<<(int)response[8]<<" "<<(int)response[9]<<endl;
    //cout<<"resp "<<hex<<(int)response[10]<<" "<<(int)response[11]<<" "<<(int)response[12]<<" "<<(int)response[13]<<" "<<(int)response[14]<<endl;
    //cout<<"resp "<<hex<<(int)response[15]<<" "<<(int)response[16]<<" "<<(int)response[17]<<endl;
    if(response[0] != 0x06 || ret <=0)
    {
        throw IOException("Send packet's verification is wrong");
    }
    return true;
}

bool GeneratorHuttinger3000::writeInt(int channelNum, int value, const IntTypeInfo &typeInfo)
{
    Com com = m_commands[channelNum];
    //memset(m_writeCmd, 0, MESS_LEN);
        memset(m_resp, 0, RESP_LEN);
        //int tempint =0;
    m_writeCmd[2] = 0x0B;
    m_writeCmd[5] = m_commands[channelNum].m_cmdLO;
    m_writeCmd[6] = m_commands[channelNum].m_cmdHI;
    if(channelNum == 0)
    {

        if(value == 1) //power on
        {
            m_writeCmd[9] = 0x07;
            m_writeCmd[10] = 0x01;
            m_writeCmd[11] = 0x00;
            m_writeCmd[12] = 0x00;
            m_writeCmd[13] = 0x00;
        }
        if(value == 0) //power 0ff
        {
            m_writeCmd[9] = 0x07;
            m_writeCmd[10] = 0x00;
            m_writeCmd[11] = 0x00;
            m_writeCmd[12] = 0x00;
            m_writeCmd[13] = 0x00;
        }
    }
    else
    {
        m_writeCmd[9] = 0x04;
    }

    if(channelNum == 3)
    {
        if(value == 2)//Phase offset
        {
            m_writeCmd[10] = 0x00;
            m_writeCmd[11] = 0x00;
            m_writeCmd[12] = 0x00;
            m_writeCmd[13] = 0x00;
        }
        if(value == 0)//Frequency offset
        {
            m_writeCmd[10] = 0x01;
            m_writeCmd[11] = 0x00;
            m_writeCmd[12] = 0x00;
            m_writeCmd[13] = 0x00;
        }
        if(value == 1)//Frequency agility
        {
            m_writeCmd[10] = 0x02;
            m_writeCmd[11] = 0x00;
            m_writeCmd[12] = 0x00;
            m_writeCmd[13] = 0x00;
        }
    }
    if(channelNum == 28)//added by taohao[1.3.0] for HTG-60M
    {
        m_writeCmd[9] = 0x05;
        /*if(value == 2)//Phase offset
        {
            m_writeCmd[10] = 0x00;
            m_writeCmd[11] = 0x00;
            m_writeCmd[12] = 0x00;
            m_writeCmd[13] = 0x00;
        }*/
        if(value == 0)//Frequency offset
        {
            m_writeCmd[10] = 0x00;
            m_writeCmd[11] = 0x00;
            m_writeCmd[12] = 0x00;
            m_writeCmd[13] = 0x00;
        }
        if(value == 1)//Frequency agility
        {
            m_writeCmd[10] = 0x01;
            m_writeCmd[11] = 0x00;
            m_writeCmd[12] = 0x00;
            m_writeCmd[13] = 0x00;
        }
    }
    if(channelNum >= 4 && channelNum <= 6)
    {
        value = value - 13560;
        if(value < 0)
        {
            //int temp = value;
            value = value & 0xffffffff;
        }
        //value += 65536;
    /*    unsigned char floatToHex[2];
        //int nChangeSetTemp;
        //nChangeSetTemp=dSetTemp*10;
        char* pChar=(char*) & value;
            for(int i=0;i<sizeof(float);i++)
            {
            floatToHex[i]=*pChar;
            pChar++;
            }

        m_writeCmd[10] = floatToHex[1];
        m_writeCmd[11] = floatToHex[0];
        */
        //long t_val = IODevice::doubleToReal(value);
        //m_writeCmd[10] = (int)t_val & 0x00ff;
        //m_writeCmd[11] = ((int)t_val>>8)&0x00ff;
        //m_writeCmd[12] = 0x00;
        //m_writeCmd[13] = 0x00;
        m_writeCmd[10] = (int)value & 0x00ff;
        m_writeCmd[11] = ((int)value>>8)&0x00ff;
        m_writeCmd[12] = ((int)value>>16)&0x00ff;
        m_writeCmd[13] = ((int)value>>24)&0x00ff;
    }
    if(channelNum >= 7 && channelNum <= 11)
    {
        m_writeCmd[10] = (int)value & 0x00ff;
        m_writeCmd[11] = ((int)value>>8)&0x00ff;
        m_writeCmd[12] = 0x00;
        m_writeCmd[13] = 0x00;
    }
    if(channelNum == 16 && value == 1)  //reset
    {
        m_writeCmd[10] = 0x01;
        m_writeCmd[11] = 0x00;
        m_writeCmd[12] = 0x00;
        m_writeCmd[13] = 0x00;

    }
    if(channelNum == 17 && value == 1)  //reset
    {
        m_writeCmd[10] = 0x01;
        m_writeCmd[11] = 0x00;
        m_writeCmd[12] = 0x00;
        m_writeCmd[13] = 0x00;

    }
    /*if(channelNum == 12) //get control mode
    {
        m_writeCmd[0] = 0xAA;
        m_writeCmd[1] = 0x02;
        m_writeCmd[2] = 0x06;
        m_writeCmd[3] = 0x00;
        m_writeCmd[4] = 0x05;
        m_writeCmd[5] = 0x01;
        m_writeCmd[6] = 0x00;
        m_writeCmd[7] = 0x00;
        m_writeCmd[8] = 0xFF;
        unsigned short crc = CheckCalculationTool::GetCRC16CodeCCITT( m_writeCmd, 9 );
        m_writeCmd[9] = (crc & 0xFF) & 0xFF;    // low byte of CRC
        m_writeCmd[10] = (crc >> 8) & 0xFF;  //  high byte of CRC
        m_writeCmd[11] = 0x55;
        return sendCommand(m_writeCmd, m_resp, m_timeOut, 12);
    }*/
    if(channelNum == 20 )  //setWaveMode
    {
        if(value == 1) // Pulse Mode
        {

            m_writeCmd[10] = 0x01;
            m_writeCmd[11] = 0x00;
            m_writeCmd[12] = 0x00;
            m_writeCmd[13] = 0x00;
        }
        if(value == 0) // Continuous operation
        {
            m_writeCmd[10] = 0x00;
            m_writeCmd[11] = 0x00;
            m_writeCmd[12] = 0x00;
            m_writeCmd[13] = 0x00;
        }

    }

    unsigned short crc = CheckCalculationTool::GetCRC16CodeCCITT( m_writeCmd, 14 );
    m_writeCmd[14] = (crc & 0xFF) & 0xFF;    // low byte of CRC
    m_writeCmd[15] = (crc >> 8) & 0xFF;  //  high byte of CRC
    m_writeCmd[16] = 0x55;
    //cout<<"writeInt��buffer= :: "<<Hex::GetHexString(m_writeCmd,17)<<endl;
    //cout<<"sendWriteInt "<<hex<<(int)m_writeCmd[0]<<" "<<(int)m_writeCmd[1]<<" "<<(int)m_writeCmd[2]<<" "<<(int)m_writeCmd[3]<<" "<<(int)m_writeCmd[4]<<endl;
    //cout<<"sendWriteInt "<<hex<<(int)m_writeCmd[5]<<" "<<(int)m_writeCmd[6]<<" "<<(int)m_writeCmd[7]<<" "<<(int)m_writeCmd[8]<<" "<<(int)m_writeCmd[9]<<endl;
    //cout<<"sendWriteInt "<<hex<<(int)m_writeCmd[10]<<" "<<(int)m_writeCmd[11]<<" "<<(int)m_writeCmd[12]<<" "<<(int)m_writeCmd[13]<<" "<<(int)m_writeCmd[14]<<endl;
    //cout<<"sendWriteInt "<<hex<<(int)m_writeCmd[15]<<" "<<(int)m_writeCmd[16]<<endl;
    return  sendCommand(m_writeCmd , m_resp , m_timeOut , 17 );
}

bool GeneratorHuttinger3000::setLoadForwordMode(int channelNum, int value, const IntTypeInfo &typeInfo)//added by taohao[1.3.0]
{
    Com com = m_commands[channelNum];
    memset(m_resp, 0, RESP_LEN);
    m_writeCmd[2] = 0x08;
    m_writeCmd[5] = m_commands[channelNum].m_cmdLO;
    m_writeCmd[6] = m_commands[channelNum].m_cmdHI;

    if(channelNum == 31)
    {
        m_writeCmd[9] = 0x05;
        m_writeCmd[10] = 0x00;
    }
    unsigned short crc = CheckCalculationTool::GetCRC16CodeCCITT( m_writeCmd, 11 );
    m_writeCmd[11] = (crc & 0xFF) & 0xFF;    // low byte of CRC
    m_writeCmd[12] = (crc >> 8) & 0xFF;  //  high byte of CRC
    m_writeCmd[13] = 0x55;
    return  sendCommand(m_writeCmd , m_resp , m_timeOut , 14 );
}

bool GeneratorHuttinger3000::writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{

    Com com = m_commands[channelNum];
    //memset(m_writeCmd, 0, MESS_LEN);
    memset(m_resp, 0, RESP_LEN);
    m_writeCmd[2] = 0x0B;
    m_writeCmd[5] = m_commands[channelNum].m_cmdLO;
    m_writeCmd[6] = m_commands[channelNum].m_cmdHI;

    if(channelNum == 32)//added by taohao[1.3.0]
    {
        m_writeCmd[9] = 0x08;
    }
    else
    {
        m_writeCmd[9] = 0x04;//[zhangcx v1.1.48]
    }

    m_writeCmd[10] = (int)value & 0x00ff;
    m_writeCmd[11] = ((int)value>>8)&0x00ff;
    m_writeCmd[12] = ((int)value>>16)&0x00ff;
    m_writeCmd[13] = ((int)value>>24)&0x00ff;

    unsigned short crc = CheckCalculationTool::GetCRC16CodeCCITT( m_writeCmd, 14 );
    m_writeCmd[14] = (crc & 0xFF) & 0xFF;    // low byte of CRC
    m_writeCmd[15] = (crc >> 8) & 0xFF;  //  high byte of CRC
    m_writeCmd[16] = 0x55;
    //cout<<"writeDouble��buffer= :: "<<Hex::GetHexString(m_writeCmd,17)<<endl;
    //cout<<"sendWriteDouble "<<hex<<(int)m_writeCmd[0]<<" "<<(int)m_writeCmd[1]<<" "<<(int)m_writeCmd[2]<<" "<<(int)m_writeCmd[3]<<" "<<(int)m_writeCmd[4]<<endl;
    //cout<<"sendWriteDouble "<<hex<<(int)m_writeCmd[5]<<" "<<(int)m_writeCmd[6]<<" "<<(int)m_writeCmd[7]<<" "<<(int)m_writeCmd[8]<<" "<<(int)m_writeCmd[9]<<endl;
    //cout<<"sendWriteDouble "<<hex<<(int)m_writeCmd[10]<<" "<<(int)m_writeCmd[11]<<" "<<(int)m_writeCmd[12]<<" "<<(int)m_writeCmd[13]<<" "<<(int)m_writeCmd[14]<<endl;
    //cout<<"sendWriteDouble "<<hex<<(int)m_writeCmd[15]<<" "<<(int)m_writeCmd[16]<<endl;
    return  sendCommand(m_writeCmd , m_resp , m_timeOut , 17 );
}

bool GeneratorHuttinger3000::getcontrol(int channelNum, int value, const IntTypeInfo &typeInfo)
{
    //memset(m_writeCmd, 0, MESS_LEN);
    memset(m_resp, 0, RESP_LEN);
    char message[50];
    if(channelNum == 12 && value == 1) //get control mode
    {
        message[0] = 0xAA;
        message[1] = 0x02;
        message[2] = 0x06;
        message[3] = 0x00;
        message[4] = 0x05;
        message[5] = 0x01;
        message[6] = 0x00;
        message[7] = 0x00;
        message[8] = 0xFF;
        unsigned short crc = CheckCalculationTool::GetCRC16CodeCCITT( message, 9 );
        message[9] = (crc & 0xFF) & 0xFF;    // low byte of CRC
        message[10] = (crc >> 8) & 0xFF;  //  high byte of CRC
        message[11] = 0x55;

    }
    getCommandResult(message,12,m_resp,13,m_timeOut);
    if((m_resp[4]&0x08)==0)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + " get control failed");
        throw IOException("get control failed");
    }
    return true;
    //return sendCommand(m_writeCmd, m_resp, m_timeOut, 12);
}

bool GeneratorHuttinger3000::readDouble(int channelNum,double *value, const DoubleTypeInfo &typeInfo)
{
    Com com = m_commands[channelNum];
    //memset(m_readCmd, 0, MESS_LEN);
    memset(m_resp, 0, RESP_LEN);
    //if(channelNum == 13 || channelNum == 14 || channelNum == 15)//[zhangcx v1.1.48]
    //{
        m_readCmd[2] = 0x06;
    //}
    m_readCmd[5] = m_commands[channelNum].m_cmdLO;
    m_readCmd[6] = m_commands[channelNum].m_cmdHI;
    unsigned short crc = CheckCalculationTool::GetCRC16CodeCCITT( m_readCmd, 9 );
    m_readCmd[9] = (crc & 0xFF) & 0xFF;    // low byte of CRC
    m_readCmd[10] = (crc >> 8) & 0xFF;  //  high byte of CRC
    m_readCmd[11] = 0x55;
    //cout<<"response "<<hex<<(int)m_readCmd[0]<<" "<<(int)m_readCmd[1]<<" "<<(int)m_readCmd[2]<<" "<<(int)m_readCmd[3]<<" "<<(int)m_readCmd[4]<<endl;
    //cout<<"response "<<hex<<(int)m_readCmd[5]<<" "<<(int)m_readCmd[6]<<" "<<(int)m_readCmd[7]<<" "<<(int)m_readCmd[8]<<" "<<(int)m_readCmd[9]<<" "<<(int)m_readCmd[10]<<" "<<(int)m_readCmd[11]<<endl;
    double temp;
      if(readCommand(m_readCmd , m_resp, m_timeOut, 18, 12))
      {
        if(13 == channelNum || 14 == channelNum || 15 == channelNum || 21 == channelNum || 22 == channelNum || 29 == channelNum)  //read FwdPower or RefPower/PulseDuty/PulseFrequency///[zhangcx v1.1.48]
        {
              temp = ((((int)m_resp[14])& 0xff)<<24) + ((((int)m_resp[13])& 0xff)<<16) + ((((int)m_resp[12])& 0xff)<<8) + ((int)m_resp[11]&0xff);
            *value = temp ; // gaozl modify 20151010
            //cout<<"value is "<<temp<<endl;
            string strResult="";
            for(int i=0;i<=17;i++)
            {
                strResult+=Hex::hexToString(int(m_resp[i]),4);
                strResult+=",";
            }
            //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ":readDouble,buffer [0-17]=" + strResult);
            //cout<<"readDouble，buffer= :: "<<Hex::GetHexString(m_resp,18)<<endl;
              return true;
        }
      }
    return false;
}

bool GeneratorHuttinger3000::readInt(int channelNum,int *value, const IntTypeInfo &typeInfo)  // add by zhangpf
{
    Com com = m_commands[channelNum];
    //memset(m_readCmd, 0, MESS_LEN);
    memset(m_resp, 0, RESP_LEN);

    m_readCmd[2] = 0x06;

    m_readCmd[5] = m_commands[channelNum].m_cmdLO;
    m_readCmd[6] = m_commands[channelNum].m_cmdHI;
    unsigned short crc = CheckCalculationTool::GetCRC16CodeCCITT( m_readCmd, 9 );
    m_readCmd[9] = (crc & 0xFF) & 0xFF;    // low byte of CRC
    m_readCmd[10] = (crc >> 8) & 0xFF;  //  high byte of CRC
    m_readCmd[11] = 0x55;
    unsigned int temp;
      if(readCommand(m_readCmd , m_resp, m_timeOut, 18, 12))
      {
        string strResult="";
        for(int i=0;i<=17;i++)
        {
            strResult+=Hex::hexToString(int(m_resp[i]),4);
            strResult+=",";
        }
        //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ":readInt,buffer [0-17]=" + strResult);
        //cout<<"readDouble，buffer= :: "<<Hex::GetHexString(m_resp,18)<<endl;

        if(23 == channelNum )  //read powerStatus
        {
              temp =  ((unsigned int)m_resp[11]>>4)&0x01;
            *value = temp ;
              return true;
        }
        if(24 == channelNum )  //read warnStatus
        {
              temp =  ((unsigned int)m_resp[11]>>6)&0x01;
            *value = temp ;
              return true;
        }
       if(25 == channelNum )  //read AlarmStatus
        {
              temp =  ((unsigned int)m_resp[11]>>7)&0x01;
            *value = temp ;
              return true;
        }
       if(26 == channelNum )  //read PulsemodeStatus
        {
              temp =  ((unsigned int)m_resp[12]>>4)&0x01;
            *value = temp ;
              return true;
        }
       if(27 == channelNum )  //read TemperatureStatus
        {
              temp =  ((unsigned int)m_resp[12]>>7)&0x01;
            *value = temp ;
              return true;
        }
      }
    return false;
}

void GeneratorHuttinger3000::InitChannels(DeviceNode<GeneratorHuttinger3000> *node)
{

    node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &GeneratorHuttinger3000::getStatus);
    //node->registerReadCh(0, &SerialDevice::connectStatus);
    node->registerWriteCh(0,&GeneratorHuttinger3000::writeInt);
    node->registerWriteCh(1,&GeneratorHuttinger3000::writeDouble);
    node->registerWriteCh(2,&GeneratorHuttinger3000::writeDouble);
    node->registerWriteCh(3,&GeneratorHuttinger3000::writeInt);
    for(int i = 4; i <=11; i++)
    {
        node->registerWriteCh(i,&GeneratorHuttinger3000::writeInt);
    }
    node->registerWriteCh(12,&GeneratorHuttinger3000::getcontrol);
    node->registerReadCh(13,&GeneratorHuttinger3000::readDouble);
    node->registerReadCh(14,&GeneratorHuttinger3000::readDouble);
    node->registerReadCh(15,&GeneratorHuttinger3000::readDouble);

    node->registerWriteCh(16,&GeneratorHuttinger3000::writeInt);
    node->registerWriteCh(17,&GeneratorHuttinger3000::writeInt);
    node->registerWriteCh(18,&GeneratorHuttinger3000::writeDouble);//[zhangcx v1.1.48]
    node->registerWriteCh(19,&GeneratorHuttinger3000::writeDouble);
    node->registerWriteCh(20,&GeneratorHuttinger3000::writeInt);
    node->registerReadCh(21,&GeneratorHuttinger3000::readDouble);
    node->registerReadCh(22,&GeneratorHuttinger3000::readDouble);
    node->registerReadCh(23,&GeneratorHuttinger3000::readInt);
    node->registerReadCh(24,&GeneratorHuttinger3000::readInt);
    node->registerReadCh(25,&GeneratorHuttinger3000::readInt);
    node->registerReadCh(26,&GeneratorHuttinger3000::readInt);
    node->registerReadCh(27,&GeneratorHuttinger3000::readInt);
    //added by taohao[1.3.0] for HTG-60M
    node->registerWriteCh(28,&GeneratorHuttinger3000::writeInt);
    node->registerReadCh(29,&GeneratorHuttinger3000::readDouble);
    node->registerWriteCh(30,&GeneratorHuttinger3000::writeDouble);
    node->registerWriteCh(31,&GeneratorHuttinger3000::setLoadForwordMode);
    node->registerWriteCh(32,&GeneratorHuttinger3000::writeDouble);
}

void GeneratorHuttinger3000::init()
{
    cout<<getName()+"GeneratorHuttinger3000 init start"<<endl;
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "GeneratorHuttinger3000 start");
    DeviceNode<GeneratorHuttinger3000> *node = new DeviceNode<GeneratorHuttinger3000>(200,this);
    DeviceManager::getInstance()->registerNode(m_nodeNum, node);
    if(!isSimulated())
    {
        InitChannels(node);
        char resp[20] = {0};
        //get control mode
        m_message[0] = 0xAA;
        m_message[1] = 0x02;
        m_message[2] = 0x06;
        m_message[3] = 0x00;
        m_message[4] = 0x05;
        m_message[5] = 0x01;
        m_message[6] = 0x00;
        m_message[7] = 0x00;
        m_message[8] = 0xFF;
        unsigned short crc = CheckCalculationTool::GetCRC16CodeCCITT( m_message, 9 );
        m_message[9] = (crc & 0xFF) & 0xFF;    // low byte of CRC
        m_message[10] = (crc >> 8) & 0xFF;  //  high byte of CRC
        m_message[11] = 0x55;

        unsigned char m_message2[20]; //reset alarm
        unsigned char m_message3[20]; //reset warnings

        m_message2[0] = 0xAA;
        m_message2[1] = 0x02;
        m_message2[2] = 0x0B;
        m_message2[3] = 0x00;
        m_message2[4] = 0x02;
        m_message2[5] = 0x4D;
        m_message2[6] = 0x00;
        m_message2[7] = 0x01;
        m_message2[8] = 0x00;
        m_message2[9] = 0x04;
        m_message2[10] = 0x01;
        m_message2[11] = 0x00;
        m_message2[12] = 0x00;
        m_message2[13] = 0x00;
        crc = CheckCalculationTool::GetCRC16CodeCCITT( m_message, 14 );
        m_message2[14] = (crc & 0xFF) & 0xFF;    // low byte of CRC
        m_message2[15] = (crc >> 8) & 0xFF;  //  high byte of CRC
        m_message2[16] = 0x55;

        m_message3[0] = 0xAA;
        m_message3[1] = 0x02;
        m_message3[2] = 0x0B;
        m_message3[3] = 0x00;
        m_message3[4] = 0x02;
        m_message3[5] = 0x4F;
        m_message3[6] = 0x00;
        m_message3[7] = 0x01;
        m_message3[8] = 0x00;
        m_message3[9] = 0x04;
        m_message3[10] = 0x01;
        m_message3[11] = 0x00;
        m_message3[12] = 0x00;
        m_message3[13] = 0x00;
        crc = CheckCalculationTool::GetCRC16CodeCCITT( m_message, 14 );
        m_message3[14] = (crc & 0xFF) & 0xFF;    // low byte of CRC
        m_message3[15] = (crc >> 8) & 0xFF;  //  high byte of CRC
        m_message3[16] = 0x55;

        try
        {
            //sleep(1);
            sendCommand(m_message, resp, m_timeOut, 12);
        //writeInt(12,1,IntTypeInfo());
        //sleep(1);
            //sendCommand(m_message2, resp, m_timeOut, 17);
        //writeInt(16,1,IntTypeInfo());
        //writeInt(17,1,IntTypeInfo());
        //sleep(5);
            //sendCommand(m_message3, resp, m_timeOut, 17);
        //sleep(1);
            //sendCommand(m_message, resp, m_timeOut, 12);
        //sleep(1);
        //writeInt(12,1,IntTypeInfo());
            //sleep(1);
        //writeInt(16,1,IntTypeInfo());
        //writeInt(17,1,IntTypeInfo());
        //sendCommand(m_message2, resp, m_timeOut, 17);
        //double nTemp;
        //readDouble(15,&nTemp,DoubleTypeInfo());
            //memset(resp, 0, 20);
            //sendCommandAck(message1, resp, m_timeOut,5, 3);
       }
        catch(const exception &ex)
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "Setting host mode has IO error!!" + ex.what());
        }
    }
    cout<<getName()+"GeneratorHuttinger3000 end start"<<endl;
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "GeneratorHuttinger3000 end");
}


IMPLEMENT_DYNAMIC(GeneratorHuttinger3000, SerialDevice )
BEGIN_MSG_MAP(GeneratorHuttinger3000, SerialDevice )
    SET_V( init, GeneratorHuttinger3000 )
END_MSG_MAP

