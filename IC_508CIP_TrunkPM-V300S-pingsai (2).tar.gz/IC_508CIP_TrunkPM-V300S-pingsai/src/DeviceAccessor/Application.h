#ifndef __APPLICATION_H
#define __APPLICATION_H

#include "TLR_Types.h"
#include "TLR_Packet.h"
#include "cifXUser.h"

#ifdef WIN32
  #include "conio.h"
#endif

#ifdef __cplusplus
  extern "C" {
#endif  /* _cplusplus */

#pragma pack(1)

typedef struct DNS_PARAM_Ttag
{
	bool       Activated;
	uint8_t    ConsumedSize;
	uint8_t	   ProducedSize;
	uint32_t   SystemFlags;
	uint32_t   WdgTime;
	uint8_t    NodeAddress;
	uint32_t   Baudrate;
	uint32_t   EnableFlags;
	uint32_t   ConfigFlags;
	uint16_t   VendorId;
	uint16_t   ProductType;
	uint16_t   ProductCode;
	uint8_t    MajorRevision;
	uint8_t    MinorRevision;
	uint32_t   SerialNumber;
	char       ProductName[32];
	uint8_t    bProductNameLen;
	bool       Poll;
	uint16_t   PollERP;
	uint16_t   PollBanTime;
	uint8_t    PollProdSz;
	uint8_t    PollConsSz;
	bool       COSCYC;
	uint16_t   COSCYCERP;
	uint16_t   COSCYCBanTime;
	uint8_t    COSCYCProdSz;
	uint8_t    COSCYCConsSz;
	bool       Bitstrobe;
	uint16_t   BitstrobeERP;
	uint16_t   BitstrobeBanTime;
	uint8_t    BitStrobeProdSz;
	uint8_t    BitStrobeConsSz;
	bool       Broadcast;
	//uint8_t    Parameter; //List of dictionary Parameters
	//uint8_t    Database;  //TODO
}
DNS_PARAM_T;


typedef struct DNM_PARAM_Ttag
{
	uint32_t	ConfigFlags;
	uint32_t    SystemFlags;
	//#Watchdog = None,
	uint32_t    NodeAddress;
	uint32_t    Baudrate;
	uint32_t    EnableFlags;
	uint32_t    VendorId;
	uint32_t    ProductType;
	uint32_t    ProductCode;
	uint32_t    MajorRevision;
	uint32_t    MinorRevision;
	uint32_t    SerialNumber;
	char        ProductName[32];
	uint8_t     ProductNameLen;
	DNS_PARAM_T slaves[64];
	//uint32_t    Database = False
}
DNM_PARAM_T;


/*************************************************************************************************
 * Below you will find some common functions, 
 * they are implemented by Application.h and can be used by any application.
 */

TLR_RESULT App_SendRecvPkt(CIFXHANDLE hChannel, CIFX_PACKET* ptSendPkt, CIFX_PACKET* ptRecvPkt, uint32_t ultimeout);
//TLR_RESULT App_SendRecvEmptyPkt(APPLICATION_T* ptApp, TLR_UINT32 ulCmd);

/* main entry function which manages the startup of the application */

//TLR_RESULT App_Main(APPLICATION_T* ptApp);

//void App_ShowHelp();

/*************************************************************************************************
 * Below you will find some common interface functions, 
 * which must be implemented by all applications.
 */

/* configuration */
//void App_GetSlaveState(APPLICATION_T* ptApp, CIFX_PACKET* ptSendPkt, CIFX_PACKET* ptRecvPkt);

/* resource handling */
//TLR_RESULT App_CreateResources(APPLICATION_T** pptApp);
//TLR_RESULT App_FreeResources(APPLICATION_T* ptApp);

/* startup screen */
//TLR_RESULT App_PromptIntro(APPLICATION_T* ptApp);

/* initialize / finalize application */
//TLR_RESULT App_Initialize(APPLICATION_T* ptApp);
//TLR_RESULT App_Finalize(APPLICATION_T* ptApp);

/* default packet handler */
//void App_HandlePacket(APPLICATION_T* ptApp, CIFX_PACKET* ptPacket);

/* functions handling packets from firmware */
//void App_HandleGetSlaveHandleCnf(APPLICATION_T* ptApp, CIFX_PACKET* ptPacket);
//void App_HandleGetSlaveConnInfoCnf(APPLICATION_T* ptApp, CIFX_PACKET* ptPacket);
//void App_HandleSdoUploadCnf(APPLICATION_T* ptApp, CIFX_PACKET* ptPacket);

/* default key handler */
//void App_HandleKey(APPLICATION_T*  ptApp, TLR_INT iKey);

/* handling of cyclic process data */
//void App_HandleProcessData(APPLICATION_T* ptApp);

/* function sending a packet to firmware */
//void App_GetHandles(APPLICATION_T* ptApp);
//void App_GetDeviceInfo(APPLICATION_T* ptApp, TLR_UINT32 ulHandle);
//void App_HandleSdoUploadReq(APPLICATION_T* ptApp);

void createDnmParam(DNM_PARAM_T*            self,
                    uint32_t				ConfigFlag,
                    //uint32_t				#Watchdog,
                    uint32_t				NodeAddress,
                    uint32_t				Baudrate,
                    uint32_t				EnableFlag,
                    uint32_t				VendorId,
                    uint32_t				ProductType,
                    uint32_t				ProductCode,
                    uint32_t				MajorRevision,
                    uint32_t				MinorRevision,
                    uint32_t				SerialNumber,
                    char				    ProductName[32],
                    DNS_PARAM_T*			slaves
                    //uint32_t				Database = False
                    );

void applyDnmParam(CIFXHANDLE hChannel, DNM_PARAM_T*  self, bool BusOn);
/*************************************************************************************************/

#ifdef __cplusplus
  }
#endif  /* _cplusplus */


#endif /* #ifndef __APPLICATION_H */
