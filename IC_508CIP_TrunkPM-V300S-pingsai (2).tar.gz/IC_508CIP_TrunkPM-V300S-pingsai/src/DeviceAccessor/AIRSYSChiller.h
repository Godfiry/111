#ifndef AIRSYSChiller_H_
#define AIRSYSChiller_H_

#include <string>
#include "SerialDevice.h"
#include "ControlObject.h"
#include "ReadWriteInt.h"
#include "ReadOnlyInt.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#include "DeviceNode.h"
#ifdef IAP4_0
using namespace IAP::CONTROL;
using namespace IAP::IO;
#endif

using namespace std;



class AIRSYSChiller : public SerialDevice
{
	DECLARE_DYNAMIC(AIRSYSChiller)
	DECLARE_MSG_MAP

private:

	typedef struct //liusy [1.1.59]
	{
		int m_offset;
		char m_addr;
	}Com;

	static Com m_commands[];

	int m_timeOut;
	int m_resLen;

	char m_writeCmd[8];	//write command array
	char m_readCmd[8];   //read command array
	std::string m_alarmInfo[7];
	static const int RESP_LEN = 80;//the buff length
	char* m_pWriteReg; //liusy [1.1.59]
	bool m_bDualChannel;
protected:

	void initChs(DeviceNode<AIRSYSChiller> *node);//inint channel
	void initDevice();

public:
	AIRSYSChiller();
	virtual ~AIRSYSChiller();
	void init();  //init the device

	bool writeTemperature(int nChannelNum, double dSetTemp, const DoubleTypeInfo& typeinfo);   //set temp
	bool readDouble(int nChannelNum, double * pValue ,const DoubleTypeInfo& typeinfo);
	bool readFlow(int nChannelNum, int * pValue ,const IntTypeInfo& typeinfo);
	bool writeOnOff(int nChannelNum, int nValue,const IntTypeInfo &typeInfo); //start/stop
	bool writeDualOnOff(int nChannelNum, int nValue, const IntTypeInfo& typeInfo);

	bool readAlarm(int nChannelNum,int * pValue , const IntTypeInfo& typeinfo);//add for code merging
	bool readAlarmInfo(int nChannelNum, std::string * pValue , const StringTypeInfo& typeinfo);

	void setDualChannelEnable(bool bFlag);
};

#endif /* AIRSYSChiller_H_ */
