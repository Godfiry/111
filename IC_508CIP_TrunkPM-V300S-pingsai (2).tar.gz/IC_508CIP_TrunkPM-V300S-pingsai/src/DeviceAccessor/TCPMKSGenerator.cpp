/********************************************************************
** Copyright (c) 2018, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TCPMKSGenerator.cpp
** Description: Product Specification 400KHz,1.5KW,Pulsing RF Generator MKS Model Number EDGE 15R40A-D02
*         Port:11235 or 11236
*
** Release: 1.1
** Modification history:
**                     2022-6-19   weizd create
**
*********************************************************************/
#include "TCPMKSGenerator.h"
#include "DeviceManager.h"
#include "ConfigException.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "NoDescriptorException.h"
#endif
#include <iostream>
#include <string.h>
#include <unistd.h>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP;
#endif
using namespace std;

const std::string TCPMKSGenerator::m_strCR = "\x0D";
const std::string TCPMKSGenerator::m_strReadCR = "\x0D\x0A*";

TCPMKSGenerator::Com TCPMKSGenerator::m_Commands[] = {{0, ""}, //0    reserved
                                            {0, "OFF", 0},//1.turn the RF output off
                                            {0, "TRG", 0},//2.turn the RF output on
                                            {0, "FRE", 0},//3.Reset generator faults and warning
                                            {1, "LLT", 0},//4.power mode: 0 is Forward,1 is Load
                                            {1, "PSW", 0},//5 turn pulsing:0 is Off,1 is on
                                            {0, "OEM", 0},//6 set the power setpoint in watts to x
                                            {0, "SPUL ", 0},//7 set the SPUL,power
                                            {0, "SPUL ", 0},//8 set the SPUL,set Pulse Frequency
                                            {0, "SPUL ", 0},//9 set the SPUL,set Pulse Duty
                                            {0, "ROF", 0},//10 get output forward power
                                            {0, "ROR", 0},//11 get output reverse power
                                            {0, "PFREQ", 0},//12 get Pulsing Frequece
                                            {1, "PDUTY", 100},//13 get Duty
                                            {0, "FRQ", 0},//14 get Frequece //add by wzd 1.1.21
                                            {0, "DFT E", 0},//15 Readback DFT rotation value //add by wzd 1.1.21
                                            {0, "FTUE", 0},//16 get current Frequency Tuning  //add by wzd 1.1.21
                                            {0, "DFT ", 0},//17 set rotation value to x//add by wzd 1.1.21
                                            {1, "FTU0=", 0},//18 manual frequency tuningfrequency tuning mode //add by wzd 1.1.21
                                            //{0, "FTU0=1", 0},//19 auto frequency tuning mode //add by wzd 1.1.21
                                            {1, "FTU0-1=", 0},//19 manual Pulse Mode for state 1 //add by wzd 1.1.21
                                            //{0, "FTU0-1=1", 0},// auto Pulse Mode for state 1 //add by wzd 1.1.21
                                            {1, "FTU0-2=", 0},//20 set tune mode //add by wzd 1.1.21
                                            //{0, "FTU0-2=1", 0},// set tune mode //add by wzd 1.1.21
                                            {0, "FTU12-3=", 0},//21 set DFT Gain //add by wzd 1.1.21
                                            {0, "FRQ=", 0}//22, set generator frequency  //add by wzd 1.1.42
};
TCPMKSGenerator::TCPMKSGenerator()
{
    m_bWaiting = false;
    m_strReadError = "";
    //m_strActionError = "";
    m_strResponse = "";
    m_bReadCmd = false;

    m_nReadTimeOutMS = 2000;//2s
    //m_bDebugMode = false;//normal mode
    m_timeOut = 20;//20s
    //m_nCommunicationMode = 0;//BKG Mode
    //m_timeOut = 50;//5s

    m_dPulseFrequency = 0;
    m_dPulseDuty = 10.0;
    m_strMaxFreq = "400000";

    //m_checkInterval = 20;
}

TCPMKSGenerator::~TCPMKSGenerator()
{
}
void TCPMKSGenerator::init()
{
    DeviceNode<TCPMKSGenerator> *pNode = new DeviceNode<TCPMKSGenerator>(m_pollInterval, this);
    DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
    if(!isSimulated())
    {
        InitChannels(pNode);
        TCPDevice::init();
        initDevice();
    }
}
void TCPMKSGenerator::acceptData()
{
    memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
    if(readData(m_recvBuffer, sizeof(m_recvBuffer)))
    {
        if(m_bWaiting)
        {
            parseReply();
            m_bWaiting = false;
        }
        else
        {
            //string strRawResult = string(m_recvBuffer);
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName()+": in acceptData() is not waiting");
        }
    }
    else
    {

        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": reading failed in acceptData()");
        if(m_bWaiting)
        {
            m_strReadError = "read_back from device failed";
            m_bWaiting = false;
        }
    }
}
bool TCPMKSGenerator::reconnectDevice()
{
    if(!m_running)
    {
        return false;
    }
    try
    {
        initDevice();
    }
    catch(const exception &ex)
    {
        return false;
    }
    return TCPDevice::reconnectDevice();
}
bool TCPMKSGenerator::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
    Com com = m_Commands[nChannelNum];
    int nCmdType = com.m_nCmdType;
    string strMsg = "";
    switch(nCmdType)
    {
        case 0:
            strMsg = m_Commands[nChannelNum + nValue].m_strCmd;
            break;
        case 1:
            strMsg = com.m_strCmd + Converter::convertToString(nValue);
            break;
    }
    return sendCommand(strMsg, m_timeOut);
    //sendCommandOnly(strMsg);
    //return true;
}
bool TCPMKSGenerator::writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
    Com com = m_Commands[nChannelNum];
    //Log_Show(getDeviceName() + "send cmd = "+ com.m_strCmd);
    string    strMsg;
    if(nChannelNum == 6)
    {

        strMsg = "OEM" + Converter::convertToString(dValue);
        //sendCommandOnly(strMsg);
        return sendCommand(strMsg, m_timeOut);
        //Log_Show(getDeviceName() + "End send cmd = "+ com.m_strCmd);
        //return true;
    }
    else if(nChannelNum == 7 )//set pulse power
    {
        strMsg = "SPUL "+Converter::convertToString(dValue)+",0,"+Converter::convertToString(m_dPulseFrequency)+","+Converter::convertToString(m_dPulseDuty/100);
        return sendCommand(strMsg, m_timeOut);
        //sendCommandOnly(strMsg);
        //return true;
    }
    else if (nChannelNum == 8)
    {
        m_dPulseFrequency = dValue;
        return true;
    }
    else if (nChannelNum == 9)
    {
        m_dPulseDuty = dValue;
        return true;
    }
    else
    {
        strMsg = m_Commands[nChannelNum].m_strCmd + Converter::convertToString(dValue);
        return sendCommand(strMsg, m_timeOut);
        //sendCommandOnly(strMsg);
        //return true;
    }

}
bool TCPMKSGenerator::writeString(int nChannelNum, std::string strValue, const StringTypeInfo &typeInfo)
{
    return true;
}
bool TCPMKSGenerator::writeRawCommand(int nChannelNum, std::string strValue, const StringTypeInfo &typeInfo)
{
    string strTotalCommand = strValue + m_strCR;
    Log_Show(getDeviceName() + ": PC->Device: "+strTotalCommand,false);
    sendData(strTotalCommand.c_str(), strTotalCommand.length());
    return true;
}
bool TCPMKSGenerator::readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
    Com com = m_Commands[nChannelNum];
    int nCmdType = com.m_nCmdType;
    string strReply = readCommand(com.m_strCmd);
    size_t nPos = strReply.find(com.m_strCmd,0);
    if(nPos == string::npos)
    {
        throw IOException(getDeviceName()+" read command ["+com.m_strCmd+"] failed for response ["+strReply+"] is invalid.");
    }
    else
    {
        string strValue = (strReply.substr(nPos+nCmdType, 4));
        if(com.m_nCmdValueDeal == 0)
        {
            if(!Converter::stringToInt(*pValue, strValue))
            {
                throw IOException(getDeviceName()+" read command ["+com.m_strCmd+"] failed for can't convert response "+strValue+" to integer value.");
            }
        }
        else
        {
            if(!Converter::stringToInt(*pValue, strValue, std::hex))
            {
                throw IOException(getDeviceName()+" read command ["+com.m_strCmd+"] failed for can't convert response "+strValue+" to integer value.");
            }
            *pValue = (*pValue >> com.m_nCmdValueDeal) & 0x0001;
        }
        return true;
    }
}
bool TCPMKSGenerator::readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo)
{
    Com com = m_Commands[nChannelNum];
    int nCmdType = com.m_nCmdType;
    string strReply = readCommand(com.m_strCmd);
    //unsigned int nPos = strReply.find(m_strReadCR, 0);

//    if(nPos == string::npos)
//    {
        //throw IOException(getDeviceName()+" read command ["+com.m_strCmd+"] failed for response "+strReply+" is invalid.");
    //}
    //else
    //{
        string strValue = strReply;
        double nDoubleValue;
        if(nChannelNum == 15)
        {
            //cout<<"DFT E "<<strReply<<endl;
            size_t nPos = strReply.find("+", 0);
            strValue = strReply.substr(nPos+1, 4);
        }
        if(nChannelNum == 16)
        {
            //cout<<"FTUE "<<strReply<<endl;
        }
        //if(nChannelNum == 10)
        //{
            //Log_Show(getDeviceName() + " TCPMKSGenerator Device->PC:Receive = "+ strReply);
        //}
        if(!Converter::stringToDouble(nDoubleValue, strValue))
        {
            throw IOException(getDeviceName()+" read command ["+com.m_strCmd+"] failed for can't convert response ["+strValue+"] is invalid.");
        }

        //int nCmdType = com.m_nCmdType;
        switch(nCmdType)
        {
            case 0:
                *pValue = nDoubleValue;
                break;
            case 1:
                *pValue = nDoubleValue * com.m_nCmdValueDeal;
                break;
        }
        return true;
    //}
}
void TCPMKSGenerator::flush()
{
    memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
    if(!readData(m_recvBuffer, sizeof(m_recvBuffer)))
    {
        Log_Info(getDeviceName() + ": reading failed in flush()");
    }
}
void TCPMKSGenerator::parseReply()
{
    string strReply = string(m_recvBuffer);


    //Log_Info(getDeviceName() + " TCPMKSGenerator  Device->PC: receive command->" + strReply);

    size_t nPosCR = 0;
    //unsigned int nPos = 0;

    int nLeftcount = m_nReadTimeOutMS/m_checkInterval;

    while(nLeftcount >= 0)
    {
        if(m_strResponse == "")
        {
            nPosCR = strReply.find(m_strReadCR, 0);
            if(nPosCR != string::npos)
            {
                m_strResponse = strReply.substr(0, nPosCR);
                return;
            }
        //    else
        //    {
        //        throw IOException(getDeviceName()+" read command ["+com.m_strCmd+"] failed for response "+strReply+" is invalid.");
        //    }
        }
        else
        {

            Log_Info(getDeviceName() + ": Device->PC:parseReadReply strResult is not null, result = " + m_strResponse);

            return;
        }
        usleep(m_checkInterval*10);
        flush();
        strReply += string(m_recvBuffer);

        --nLeftcount;
    }
    m_strReadError = "Unknown read_back:"+strReply;
}
void TCPMKSGenerator::sendCommandOnly(const std::string &strCommand)
{
    Log_Show(getDeviceName() + " PC->Device:send cmd = "+ strCommand);
    m_bWaiting = false;

    string strTotalCommand = strCommand + m_strCR;
    sendData(strTotalCommand.c_str(), strTotalCommand.length());
}
bool TCPMKSGenerator::sendCommand(std::string strCommand, int nTimeOut)
{
    m_bWaiting = true;
    m_strReadError = "";

    //if(strCommand == "ROF")
    //{
        //Log_Show(getDeviceName() + "TCPMKSGenerator PC->Device:send read cmd "+ strCommand);
    //}

    //Log_Info(getDeviceName() + " TCPMKSGenerator PC->Device:send read cmd "+strCommand);

    string strTotalCommand = strCommand + m_strCR;
    sendData(strTotalCommand.c_str(), strTotalCommand.length());

    int nLeftcount = m_nReadTimeOutMS/m_checkInterval;//read time out is 2s
    while(nLeftcount >= 0)
    {
        if(!m_bWaiting)
        {
            if(m_strReadError != "")
            {
                throw IOException(m_strReadError);
                return false;
            }
            else
            {
                return true;
            }
        }
        usleep(m_checkInterval * 10);
        --nLeftcount;
    }
    throw IOException("command read_back time Out");
    return false;
}
std::string TCPMKSGenerator::readCommand(std::string strCommand)
{
    m_bReadCmd = true;
    m_strResponse = "";
    sendCommand(strCommand,m_timeOut);
    m_bReadCmd = false;
    return m_strResponse;
}
void TCPMKSGenerator::InitChannels(DeviceNode<TCPMKSGenerator> *pNode)
{
    pNode->registerWriteCh(0, &TCPMKSGenerator::writeRawCommand);
    for(int i = 1; i <= 5; ++i)
    {
        pNode->registerWriteCh(i, &TCPMKSGenerator::writeInt);
    }

    for(int i = 6; i <= 9; ++i)
    {
        pNode->registerWriteCh(i, &TCPMKSGenerator::writeDouble);
    }

    for(int i = 10; i <= 16; ++i)
    {
        pNode->registerReadCh(i, &TCPMKSGenerator::readDouble);
    }
    pNode->registerWriteCh(17, &TCPMKSGenerator::writeDouble);
    for(int i = 18; i <= 20; ++i)
    {
        pNode->registerWriteCh(i, &TCPMKSGenerator::writeInt);
    }
    pNode->registerWriteCh(21, &TCPMKSGenerator::writeDouble);
    pNode->registerWriteCh(22, &TCPMKSGenerator::writeDouble);  //add by wzd 1.1.42
}
void TCPMKSGenerator::initDevice()
{
    cout<<"Start Scan TCPMKSGenerator...."<<endl;
    sendCommandOnly("REM0");
    sendCommandOnly("EKO1");
    sendCommandOnly("FTU0=0");
    sendCommandOnly("RMP0=0");
    std::string setMaxFreq = std::string("FRQ=") + m_strMaxFreq;
    sendCommandOnly(setMaxFreq);
    cout<<"Scan TCPMKSGenerator Successfully...."<<endl;
}
void TCPMKSGenerator::setMaxFreq(std::string freq)
{
    m_strMaxFreq = freq;
    //m_strMaxFreq = freq;
}

void TCPMKSGenerator::setReadTimeOutMS(int time)  //add by wzd 1.1.33_HotFixed
{
    m_nReadTimeOutMS = time * 100;
}

string TCPMKSGenerator::getDeviceName()
{
    return __FILE__;
}

IMPLEMENT_DYNAMIC(TCPMKSGenerator, TCPDevice )
BEGIN_MSG_MAP(TCPMKSGenerator, TCPDevice )
    SET_V( init, TCPMKSGenerator )
    SET_S( setMaxFreq, TCPMKSGenerator )
    SET_I( setReadTimeOutMS, TCPMKSGenerator )  //add by wzd 1.1.33_HotFixed
END_MSG_MAP
