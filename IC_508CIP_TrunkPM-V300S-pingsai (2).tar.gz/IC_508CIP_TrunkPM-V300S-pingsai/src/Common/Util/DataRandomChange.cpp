/**************************************************************************
** Copyright (c) 2026, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: DataRandomChange.cpp
** Description: 
** Release: 
** Modification history: 
** 					2026-04-16  chensc,mujy create
***************************************************************************/

#include "DataRandomChange.h"
#ifdef IAP4_0
#include "ITime.h"
#else
#include "Time.h"
#endif
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "InvalidNameException.h"
#endif
#include "ConfigException.h"
#include "ObjectManager.h"
#include "DataSource.h"
#include "DataTarget.h"
#include "DefaultIOMonitorLogThread.h"
#include "StringValueInfo.h"
#include "DoubleValueInfo.h"
#include "AlarmReNameManager.h"
#include "SysLogger.h"
#include "XmlGetter.h"
#include "MathTool.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
using namespace IAP::IO;
#endif
using namespace std;

DataRandomChange::DataRandomChange()
{
	m_pRandomUp = NULL;

	m_sRandomUp = new RandomUp;
	m_sRandomUp->setOwner(this);
	
	m_sRandomDown = new RandomDown;
	m_sRandomDown->setOwner(this);

	m_bThreadStarted=false;
	m_nRandomMode=DATACHANGERAMDOMMODE::Idle;

	m_nRandomDataIndex = 0;
        m_bKeepRun = false;
}

DataRandomChange::~DataRandomChange()
{
        m_bKeepRun = false;
	map<int,RandomDataStruct*>::iterator it;
	for(it=m_mapRandomDatas.begin(); it != m_mapRandomDatas.end(); ++it)
	{
		if(it->second != NULL)
		{
			 delete it->second;
			 it->second = NULL;
		}
	}
	m_mapRandomDatas.clear();
}

void DataRandomChange::startup()//added by mujy [1.2]
{
	m_pProcessTheRecipeOffOn=(ReadWriteInt*)ObjectManager::getInstance()->getObject("/IO/Datas/ProcessTheRecipeFlag");
	m_pProcessTheRecipeOffOn->setValue(0);
        m_bKeepRun = true;
}

void DataRandomChange::make()
{
	m_pRandomUp = new ReadWriteInt(getName()+"/RandomUp", IntTypeInfo());
    m_pRandomUp->setValue(0);
}

void DataRandomChange::shutdown()
{
      m_bKeepRun = false;
}

void DataRandomChange::run()
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, ControlObjectEX::getSelfName() + ": start running " );
    while(m_bKeepRun)
    {
        try
        { 
              doRandomChange();     
        }
        catch(...)
        {
        }
        usleep(m_nIntervalMS*1000);
    }
      SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, ControlObjectEX::getSelfName() + ": stop running " );
}

void DataRandomChange::doRandomChange()
{
    //while(m_bKeepRun && m_bThreadStarted && getThreadState() == THREAD_RUNNING)
    //{
        if(!m_bThreadStarted)
        {
             return;
        }
        if(m_pRandomUp == NULL || m_pRandomUp->getValue() == 0)
        {
             return;
        }

        if(m_pProcessTheRecipeOffOn == NULL || (m_nRandomMode == DATACHANGERAMDOMMODE::Process && m_pProcessTheRecipeOffOn->getValue() != 1))
        {
            return;
        }

        while(m_bKeepRun && (getThreadState() == THREAD_RUNNING) && (m_pRandomUp != NULL && m_pRandomUp->getValue() == 1) &&  ((m_pProcessTheRecipeOffOn != NULL && m_pProcessTheRecipeOffOn->getValue() == 1) || (m_nRandomMode == DATACHANGERAMDOMMODE::Idle)))
        {
            map<int,RandomDataStruct*>::iterator it;
			for(it=m_mapRandomDatas.begin(); it != m_mapRandomDatas.end();++it)
			{
				UntypedData * pSP = it->second->pRandomDataSP;
				UntypedData * pSensor = it->second->pRandomDataSensor;
				if(pSP)
				{
					int nTemp=pSP->getDataType();
					switch(nTemp)
					{
						case IO::INTDATA:
						{
							ReadWriteInt *pIntSP = (ReadWriteInt*)pSP;
							if(pIntSP->getValueInfo().getValidity() == IO::NOT_INIT)
							{
								continue;
							}
							if(((ReadOnlyInt*)pSensor)->isSimulated() == false)
							{
								continue;
							}	
							int nTempSP = pIntSP->getValue();
							int nTempSPMin = pIntSP->getTypeInfo().getMin();
							double nRange = it->second->dRandomRange;
							if(nTempSP - nRange <= nTempSPMin)
							{
								((ReadOnlyInt*)pSensor)->setSimulatedValue(MathTool::createRandomValue(nTempSP,nRange));
							}
							else
							{
								((ReadOnlyInt*)pSensor)->setSimulatedValue(MathTool::createRandomValue(nTempSP - nRange, nTempSP + nRange));
							}
							break;
						}
						case IO::DOUBLEDATA:
						{
							ReadWriteDouble *pDoubleSP = (ReadWriteDouble*)pSP;
							if(pDoubleSP->getValueInfo().getValidity() == IO::NOT_INIT)
							{
								continue;
							}
							if(((ReadOnlyDouble*)pSensor)->isSimulated() == false)
							{
							   continue;
							}
							double dTempSP = pDoubleSP->getValue();
							double dTempSPMin = pDoubleSP->getTypeInfo().getMin();
							double dRange = it->second->dRandomRange;
							if(dTempSP - dRange <= (dTempSPMin - 0.1))
							{
								((ReadOnlyDouble*)pSensor)->setSimulatedValue(MathTool::createRandomValue(dTempSP,dRange));
							}
							else
							{
								((ReadOnlyDouble*)pSensor)->setSimulatedValue(MathTool::createRandomValue(dTempSP - dRange, dTempSP + dRange));
							}
							break;
						}
					}

				}
				else//SP == NULL
				{
					int nTemp=pSensor->getDataType();
					switch(nTemp)
					{
						case IO::INTDATA:
						{
							ReadOnlyInt *pIntSensor = (ReadOnlyInt*)pSensor;
												
							if(pIntSensor->isSimulated() == false)
							{
							   continue;
							}
							int nTempSP = pIntSensor->getTypeInfo().getMax()/2;
							int nTempSPMin = pIntSensor->getTypeInfo().getMin();
							double nRange = it->second->dRandomRange;
							if(nTempSP - nRange <= nTempSPMin)
							{
								pIntSensor->setSimulatedValue(MathTool::createRandomValue(nTempSP,nRange));
							}
							else
							{
								pIntSensor->setSimulatedValue(MathTool::createRandomValue(nTempSP - nRange, nTempSP + nRange));
							}
							break;
						}
						case IO::DOUBLEDATA:
						{
							ReadOnlyDouble *pDoubleSensor = (ReadOnlyDouble*)pSensor;
												
							if(pDoubleSensor->isSimulated() == false)
							{
							   continue;
							}
							double dTempSP = pDoubleSensor->getTypeInfo().getMax()/2.0;
							double dTempSPMin = pDoubleSensor->getTypeInfo().getMin();
							double dRange = it->second->dRandomRange;
							if(dTempSP - dRange <= (dTempSPMin - 0.1))
							{
								pDoubleSensor->setSimulatedValue(MathTool::createRandomValue(dTempSP,dRange));
							}
							else
							{
								pDoubleSensor->setSimulatedValue(MathTool::createRandomValue(dTempSP - dRange, dTempSP + dRange));
							}
							break;
						}
					}
				}
			}
	
			for(int n = 0; n < m_nIntervalMS; ++n)
			{
				usleep(1 * 1000);
				if(m_pRandomUp == NULL || m_pRandomUp->getValue() != 1)
				{
					break;
				}
					if(getThreadState() !=  THREAD_RUNNING)
				{
					break;
				}
			}
        }
    //}
}

void DataRandomChange::RandomUp::execute()
{
	DataRandomChange *owner = dynamic_cast<DataRandomChange*>(getOwner());
	
	if(NULL != owner)
	{
		owner->do_RandomUp(Params["IntervalMs"].Int);
	}
}

void DataRandomChange::RandomDown::execute()
{
	DataRandomChange *owner = dynamic_cast<DataRandomChange*>(getOwner());
	
	if(NULL != owner)
	{
		owner->do_RandomDown();
	}
}

void DataRandomChange::startThread()
{
	#ifdef IAP4_0
	IThread::start(IAP::CORE::IThread::PRIORITY_NORMAL, IAP::CORE::IThread::CREATE_DETACHED); 
	#else
	IThread::start(PRIORITY_NORMAL, CREATE_DETACHED); 
	#endif
        m_bThreadStarted=true;
}

void DataRandomChange::do_RandomUp(int nIntervalMs)
{
	m_nIntervalMS = nIntervalMs;
	//turn on the thread
	if(m_bThreadStarted)
	{
	}
	else
	{
        startThread();
        m_bThreadStarted = true;
	}
    m_pRandomUp->setValue(1);
}

void DataRandomChange::do_RandomDown()
{
    m_pRandomUp->setValue(0);
}

void DataRandomChange::addRandomDataCh(const std::string &strRandomSPPath, const std::string &strRandomSensorPath,double dRange)
{
	if(!isSimulated())
	{
		 return;
	}
	if((strRandomSPPath != "NULL" && !XmlGetter::isNamespaceExist(strRandomSPPath)) || !XmlGetter::isNamespaceExist(strRandomSensorPath))
	{
		 cout<<"#####DataRandomChange Channel not exist: "<<strRandomSPPath<<" "<<strRandomSensorPath<<endl;
		 return;
	}
        
	RandomDataStruct * pRandomData = new RandomDataStruct;
	if(strRandomSPPath == "NULL")
	{
		pRandomData->pRandomDataSP = NULL;
	}
	else
	{
		pRandomData->pRandomDataSP = XmlGetter::getFromNamespace<ReadWriteData*>(strRandomSPPath);
	}
	pRandomData->pRandomDataSensor = XmlGetter::getFromNamespace<ReadOnlyData*>(strRandomSensorPath);
	pRandomData->dRandomRange = dRange;
        
	m_mapRandomDatas[m_nRandomDataIndex++] = pRandomData;
}

void DataRandomChange::setIntervalMS(int nMillSecond)
{
	m_nIntervalMS = nMillSecond;
}

void DataRandomChange::setRandomMode(string strMode)
{
	if(strMode == "Process")
	{
	    m_nRandomMode = DATACHANGERAMDOMMODE::Process;
	}
	else
	{
		m_nRandomMode = DATACHANGERAMDOMMODE::Idle;
	}
}

IMPLEMENT_DYNAMIC_SERVICE(RandomUp, DataRandomChange)
IMPLEMENT_DYNAMIC_SERVICE(RandomDown, DataRandomChange)

BEGIN_SERVICEINFO_LIST(DataRandomChange)
	ADD_SERVICE_INFO(DataRandomChange, RandomUp, Monitor turn Up)
             ADD_PARAM_INFO(DataRandomChange, RandomUp, IntervalMs, int, interval ms )
	ADD_SERVICE_INFO(DataRandomChange, RandomDown, Monitor turn Down)
END_SERVICEINFO_LIST(DataRandomChange)

IMPLEMENT_DYNAMIC(DataRandomChange, ControlObjectEX)
BEGIN_MSG_MAP( DataRandomChange, ControlObjectEX)
	SET_I(setIntervalMS, DataRandomChange)
	SET_SSD(addRandomDataCh, DataRandomChange)
	SET_S(setRandomMode, DataRandomChange)
END_MSG_MAP
