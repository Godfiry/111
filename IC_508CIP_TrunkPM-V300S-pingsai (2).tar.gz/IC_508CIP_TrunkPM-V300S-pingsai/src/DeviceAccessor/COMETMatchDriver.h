/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: COMETMatchDriver.h
** Description:  
** Release: 1.1
** Modification history: 
** 					
**                  2014-11-21   lijj	create
*********************************************************************/
#ifndef COMETMATCHDRIVER_H_
#define COMETMATCHDRIVER_H_
#include "SerialDevice.h"
#include "DeviceNode.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class COMETMatchDriver:public SerialDevice
{
	DECLARE_DYNAMIC(COMETMatchDriver)	
	DECLARE_MSG_MAP
		
 	private:		
    
	protected:
		bool sendCommand(std::string command, int timeOut);
		std::string readCommand(std::string command, int timeOut);	
		int m_nGetComResultTimeOut;//added by xiasc[v1.6.14]

	public:
		COMETMatchDriver();
		virtual ~COMETMatchDriver();
		void setGetComResultTimeout(int ms);
};

#endif /*COMETMATCHDRIVER_H_*/
