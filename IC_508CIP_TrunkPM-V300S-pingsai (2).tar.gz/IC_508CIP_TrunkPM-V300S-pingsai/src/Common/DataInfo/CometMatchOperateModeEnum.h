#ifndef COMETMATCHOPERATEMODEENUM_H_
#define COMETMATCHOPERATEMODEENUM_H_

namespace COMETMATCH_OPERATEMODE
{
	enum CometMatchOperateModeEnum
	{
		Hold,
		Manual,
		Auto_Hold,
		Auto
	};
}

#endif /*COMETMATCHOPERATEMODEENUM_H_*/
