#include "PecvdVatBufferFlyDriver.h"

#include "DeviceManager.h"
#include "ConfigException.h"
#include <cmath>
#include<iostream>
#include <string.h>
#ifdef IAP4_0
using namespace IAP::IO;
#endif
using namespace std;


PecvdVatBufferFlyDriver::PecvdVatBufferFlyDriver()
{
}

PecvdVatBufferFlyDriver::~PecvdVatBufferFlyDriver()
{
}

bool PecvdVatBufferFlyDriver::writeInt(int channelNum, int value, const IntTypeInfo &typeInfo)
{
	char buffer[m_nOutputByte];
	memset(buffer, 0, m_nOutputByte);
	
	if(!isSimulated())
	{
		if(value == 0)//close valve
		{
			buffer[0] = (unsigned char)(1 & 0xff);
			buffer[1] = (unsigned char)(0 & 0xff);
			buffer[2] = (unsigned char)(0 & 0xff);
			buffer[3] = (unsigned char)(0 & 0xff);
		}
		if(value == 1)//open valve
		{
			buffer[0] = (unsigned char)(2 & 0xff);
			buffer[1] = (unsigned char)(0 & 0xff);
			buffer[2] = (unsigned char)(0 & 0xff);
			buffer[3] = (unsigned char)(0 & 0xff);
		}
		return m_deviceNet->writeByte(m_macID, buffer);
	}
	else
		return true;
}

bool PecvdVatBufferFlyDriver::writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
	char buffer[m_nOutputByte];
	unsigned long temp;
	memset(buffer, 0, m_nOutputByte);
	if(!isSimulated())
	{
		if(channelNum==2)//presureSP
		{
			temp = (double)(value*10000/typeInfo.getMax()); 
//			temp = value*10000/typeInfo.getMax();
			buffer[0] = (unsigned char)(0 & 0xff);
			buffer[1] = (unsigned char)(temp & 0xff);
			buffer[2] = (unsigned char)((temp>>8) & 0xff);
			buffer[3] = (unsigned char)(0 & 0xff);
		}
		if(channelNum==3)//positionSP
		{
			double  tmp1;
			tmp1 = (double)(value*10000/typeInfo.getMax()); 
			temp = (int)tmp1;
//			temp = value*10000/typeInfo.getMax();
			buffer[0] = (unsigned char)(0 & 0xff);
			buffer[1] = (unsigned char)(temp & 0xff);
			buffer[2] = (unsigned char)((temp>>8) & 0xff);
			buffer[3] = (unsigned char)(1 & 0xff);		
		}
		return m_deviceNet->writeByte(m_macID, buffer);
	}
	else
	{
		return true;
	}
	
}

bool PecvdVatBufferFlyDriver::readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	char buffer[m_nInputByte];
	int temp;//maxm V1.1.5 for has sign 
	memset(buffer, 0, m_nInputByte);
	if(!isSimulated())
	{
		m_deviceNet->readByte(m_macID, buffer);
		
		if(channelNum==9)//pressureAT
		{
			temp = (((unsigned long)buffer[1]) & 0xff) + ((((unsigned long)buffer[2]) << 8) & 0xff00);	
			//maxm V1.1.5
			if(buffer[2] & 0x80)
			{
			    temp -= 65536;
			    *value = temp * typeInfo.getMax() / 10000;
			    if( *value < typeInfo.getMin())
				{
					*value = typeInfo.getMin();
				}
			}
			else if((temp * typeInfo.getMax() / 10000) >10000)
			{
				*value = 10000;
			}
			else
			{
				*value = temp * typeInfo.getMax() / 10000;
			}
		}
		else if(channelNum==10)//positionAT
		{
			temp = (((unsigned long)buffer[3]) & 0xff) + ((((unsigned long)buffer[4]) << 8) & 0xff00);
			if(temp<1)
			{
				*value=0;
			}
			else if((temp * typeInfo.getMax() / 10000) >1000)
			{
				*value =1000;
			}
			else
			{
				*value = temp * typeInfo.getMax() / 10000;
			}
		}
		else
			return false;
		return true;
	}
	else
	{
		*value=typeInfo.getMin();
		return true;
	}
}

bool PecvdVatBufferFlyDriver::writeECTInt(int channelNum, int value, const IntTypeInfo &typeInfo)
{
	if(!isSimulated())
	{
		if(channelNum == 6)//Local/RemoteRW
		{
			char buffer[2]={0x6B,0};
			buffer[1]=(unsigned char)(value & 0xff);
			return m_deviceNet->writeExplicit(m_macID, buffer, 0x10, 0x64, 0x01, 2);
		}
		if(channelNum == 8)
		{
			char buffer[2]={0x66,0x01};
			m_deviceNet->writeExplicit(m_macID, buffer, 0x10, 0x30, 0x01, 2);//ZERO Control
			return m_deviceNet->writeExplicit(m_macID, NULL, 0x4B, 0x31, 0x01, 0);//ZERO
		}
	}
	else
		return true;
}


bool PecvdVatBufferFlyDriver::writeECTDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
	if(!isSimulated())
	{
		char buffer[3]={0x64,0,0};
		unsigned long temp;
		temp = value*10000/typeInfo.getMax();
		buffer[1] = (unsigned char)(temp & 0xff);
		buffer[2] = (unsigned char)((temp>>8) & 0xff);
			
		m_deviceNet->writeExplicit(m_macID, buffer, 0x10, 0x33, 0x01, 3);//Learn pressure limit
		m_deviceNet->writeExplicit(m_macID, NULL, 0x64, 0x33, 0x01, 0);//Learn
		return true;
	}
	else
		return true;
}

bool PecvdVatBufferFlyDriver::readECTInt(int channelNum, int *value, const IntTypeInfo &typeInfo)
{
	if(!isSimulated())
	{
		char bufferout[1];
		memset(bufferout, 0, 1);
		char bufferin[1];
		memset(bufferin, 0, 1);
		int *b;
		if(channelNum == 11)
		{
			bufferin[0] = 0x6B;
			m_deviceNet->readExplicit(m_macID, bufferin, 0x10, 0x64, 1, 1,bufferout,b);
			
			*value = ((unsigned long)bufferout[0]) & 0xff;
		}
		if(channelNum == 12)//device status2
		{
			bufferin[0] = 0x67;
			m_deviceNet->readExplicit(m_macID, bufferin, 0x10, 0x64, 1, 1,bufferout,b);
			
			*value = ((unsigned long)bufferout[0]) & 0xff;
		}
		return true;
	}
	else
		return true;
}

void PecvdVatBufferFlyDriver::init()
{
	DeviceNode<PecvdVatBufferFlyDriver> * node = new DeviceNode<PecvdVatBufferFlyDriver>(m_pollInterval,this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	if(!isSimulated())
	{	
		initDeviceNet();
		//init channels
		node->registerWriteCh(1, &PecvdVatBufferFlyDriver::writeECTDouble);//Learn
		for(int i=2; i<=3; ++i)
		{
			node->registerWriteCh(i,&PecvdVatBufferFlyDriver::writeDouble);
		}
		node->registerWriteCh(4, &PecvdVatBufferFlyDriver::writeInt);//close/open
		node->registerWriteCh(6, &PecvdVatBufferFlyDriver::writeECTInt);//Local/RemoteRW
		node->registerWriteCh(8, &PecvdVatBufferFlyDriver::writeECTInt);//zero
		for(int i=9; i<=10; ++i)
		{
			node->registerReadCh(i, &PecvdVatBufferFlyDriver::readDouble);
		}
		for(int i=11; i<=12; ++i)
		{
			node->registerReadCh(i, &PecvdVatBufferFlyDriver::readECTInt);
		}
		m_nOutputByte = m_deviceNet->getOBytesSize(m_macID);// write to devicenet
		m_nInputByte  = m_deviceNet->getIBytesSize(m_macID);//read from devicenet
		//maxm added set position mode
		char Chinit[4] = {0x00,0x00,0x00,0x01};
		m_deviceNet->writeByte(m_macID, Chinit);
	}
}

IMPLEMENT_DYNAMIC(PecvdVatBufferFlyDriver, IODevice )
BEGIN_MSG_MAP( PecvdVatBufferFlyDriver, IODevice )

END_MSG_MAP
