/*
 * AppRecipeManager.cpp
 *
 *  Created on: 2025-8-5
 *      Author: taohao
 */

#include "AppRecipeManager.h"
#include "SysLogger.h"
#include "ManagedObject.h"
#include "Converter.h"

#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "AbortException.h"
#include "ConfigException.h"
#endif

#include "CTCExport.h"
#include "StrTool.h"
#include <iostream>
#include <math.h>
#include "Version.h"
#include "XmlGetter.h"
#include "IntTypeInfo.h"
#include "ObjectManager.h"
#include <iostream>
#include <dirent.h>
#include <string>
#include "AlarmReNameManager.h"
#include "RecipeTypeValueInfo.h"
#include "BoshRcpBody.h"
using namespace std;

AppRecipeManager* AppRecipeManager::m_pInstance = NULL;

AppRecipeManager::AppRecipeManager()
{
    m_pSession = NULL;
    m_pInstance = this;

    m_sStoreRecipeToMemory = new StoreRecipeToMemory;
    m_sStoreRecipeToMemory->setOwner(this);

    m_sDeleteRecipeBodyFiles = new DeleteRecipeBodyFiles;
    m_sDeleteRecipeBodyFiles->setOwner(this);

    m_sDeleteRecipeFromMemory = new DeleteRecipeFromMemory;
    m_sDeleteRecipeFromMemory->setOwner(this);

    m_cfgDeleteRecipeFlag = NULL;
    m_strCurrentRecipeFullName = "";
    m_pRecipeBodyFromMemory = NULL;

    m_pServiceFailedAlarm = NULL;
    m_pErrorDescription = NULL;
    m_pServiceName = NULL;

    m_pExecuteRecipeFailed = NULL;
}

AppRecipeManager::~AppRecipeManager()
{
	/*   //delete by taohao [1.5.0_HotFix8] for Ctrl+C core dump
    if(m_pRecipeBodyFromMemory != NULL)
    {
        delete m_pRecipeBodyFromMemory;
        m_pRecipeBodyFromMemory = NULL;
    }
    */
    if(m_pRecipeBodyFromIAP != NULL)
    {
        delete m_pRecipeBodyFromIAP;
        m_pRecipeBodyFromIAP = NULL;
    }
}

AppRecipeManager* AppRecipeManager::getInstance()
{
    //When the AppRecipeManager object is not configured in the config file,Delete recipe function is off.
    if (NULL == m_pInstance)
    {
        m_pInstance = new AppRecipeManager();
        ObjectManager::getInstance()->registerObject(m_pInstance, "/Control/PMCExports/Controls/AppRecipeManager");
        m_pInstance->initialize();
        //CTCExport::exportToCTC(m_pInstance,"AppRecipeManager");//need fix
    }
    return m_pInstance;
}

void AppRecipeManager::make()
{
    Log_Info( getName() + " make start" );
    if(isMade())
    {
        return;
    }
    ControlObject::make();
}

void AppRecipeManager::initialize()
{
    Log_Info( getName() + " initialize start" );
    ControlObject::initialize();
    //string strPreName = AlarmReNameManager::getInstance()->GetShowName(getName());

    m_pSession = RecipeNamespaceManager::buildSession(this, getName()); // build a session
    m_cfgDeleteRecipeFlag = XmlGetter::tryGetFromNamespace<ReadWriteInt>("/SETUP/SoftwareFunctionConfig/cfgDeleteRecipeFlag",IntTypeInfo(DescriptorList("false:0,true:1")),false);

    m_pErrorDescription = new ReadWriteString(getName() + "/ErrorMsg");
    m_pServiceName = new ReadWriteString(getName() + "/ServiceName");

    m_pServiceFailedAlarm = new NonBlockingAlarm(getSelfName() + "_RunServiceFailed", "Run service [ <"+ m_pServiceName->getName() +"> ] failed.", "Run service failed: <" + m_pErrorDescription->getName() + ">", Alarm::ERROR);
    m_pServiceFailedAlarm->addRecovery(new Recovery("Clear", Recovery::CLEAR));

    m_pExecuteRecipeFailed = new NonBlockingAlarm(getSelfName() + "_ExecuteRecipeFailed", "Failed to use live edit function.",  "Delete recipe function is running, please check! ", Alarm::ERROR);
    m_pExecuteRecipeFailed->addRecovery(new Recovery("Clear", Recovery::CLEAR));

    if(RecipeTypeValueInfo::getInstance()->isGroupRecipe() || RecipeTypeValueInfo::getInstance()->isFatherChildRecipe())//for bosh recipe type
    {
        m_pRecipeBodyFromIAP = new BoshRcpBody();
    }
    else
    {
        m_pRecipeBodyFromIAP = new AppRcpBody();
    }
}

void AppRecipeManager::shutdown()
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + ": about to AppRecipeManager::ShutDown" );
    if (m_pSession != NULL)
    {
        m_pSession->clear();
        RecipeNamespaceManager::closeSession(&m_pSession);
    }
    Log_Info( getName() + " delete all recipes's memory" );
    string strResult = do_DeleteRecipeFromMemory(m_strAll);
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + " done AppRecipeManager::ShutDown" );
}

std::string AppRecipeManager::call_StoreRecipeToMemory(const std::string &strRecipeID)
{
    m_sStoreRecipeToMemory->setOwner(this);
    m_sStoreRecipeToMemory->setParamValue("strRecipeID", strRecipeID);
    call(m_sStoreRecipeToMemory);
	#ifdef IAP4_0
	return m_sStoreRecipeToMemory->result().Str;
	#else
	ServiceResults ret;
	m_sStoreRecipeToMemory->getResults(ret);
	return ret["ret"].Str;
	#endif
}

std::string AppRecipeManager::call_DeleteRecipeBodyFiles(const std::string &strRecipeID)
{
    m_sDeleteRecipeBodyFiles->setOwner(this);
    m_sDeleteRecipeBodyFiles->setParamValue("strRecipeID", strRecipeID);
    call(m_sDeleteRecipeBodyFiles);
	#ifdef IAP4_0
	return m_sDeleteRecipeBodyFiles->result().Str;
	#else
	ServiceResults ret;
	m_sDeleteRecipeBodyFiles->getResults(ret);
	return ret["ret"].Str;
	#endif
}

std::string AppRecipeManager::call_DeleteRecipeFromMemory(const std::string &strRecipeID)
{
    m_sDeleteRecipeFromMemory->setOwner(this);
    m_sDeleteRecipeFromMemory->setParamValue("strRecipeID", strRecipeID);
    call(m_sDeleteRecipeFromMemory);
	#ifdef IAP4_0
	return m_sDeleteRecipeFromMemory->result().Str;
	#else
	ServiceResults ret;
	m_sDeleteRecipeFromMemory->getResults(ret);
	return ret["ret"].Str;
	#endif
}

std::string AppRecipeManager::do_StoreRecipeToMemory(const std::string &strRecipeID)
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getName() +" AppRecipeManager::start store recipe to memory: " + strRecipeID);

    int nCheckResult = checkRecipeName(strRecipeID);
    if(nCheckResult != OneRecipe)
    {
        return "StoreRecipeToMemory," + strRecipeID + "," + m_strFalse;
    }
    AppRcpBody *tmpRecipeBody = NULL;
    try
    {
        Log_Info( getName() + " start store recipe: " + strRecipeID + " to memory " );
        //m_CurrentRcpHandler = getRecipeHandler(strRecipeID);
        //Prevent tampering with m_CurrentRcpHandler when function is off
        ExecRcpHandler tmpRcpHandler = getRecipeHandler(strRecipeID);

        bool bSpecialComments = isSpecialComments(tmpRcpHandler);//added by taohao[1.5.0_HotFix9] for special recipe with Comments
        if(bSpecialComments)
        {
        	Log_Error(getName() + " " + strRecipeID + " has special Comments,cannot execute StoreRecipeToMemory service");
            return "StoreRecipeToMemory," + strRecipeID + "," + m_strFalse;
        }

        tmpRecipeBody = new AppRcpBody();
        tmpRecipeBody->makeBody(tmpRcpHandler);
        string strResult = refreshRecipeBodyMap(strRecipeID,tmpRecipeBody,tmpRcpHandler);
        m_pSession->releaseRecipe(tmpRcpHandler);
        m_pSession->removeRecipe(strRecipeID);
        Log_Info( getName() + " finish store recipe: " + strRecipeID + " to memory " );
        return "StoreRecipeToMemory," + strRecipeID + "," + strResult;
    }
    catch(const exception &ex)
    {
        Log_Error(getName() + ": AppRecipeManager::do_StoreRecipeToMemory got exception-" +ex.what());
        if(tmpRecipeBody != NULL)
        {
            tmpRecipeBody->clear();//clear AppRcpStep after use
            delete tmpRecipeBody;
            tmpRecipeBody = NULL;
        }
        return "StoreRecipeToMemory," + strRecipeID + "," + m_strFalse;
    }
    catch(...)
    {
        Log_Error(getName() + ": AppRecipeManager::do_StoreRecipeToMemory Unknown exception caught");
        if(tmpRecipeBody != NULL)
        {
            tmpRecipeBody->clear();//clear AppRcpStep after use
            delete tmpRecipeBody;
            tmpRecipeBody = NULL;
        }
        return "StoreRecipeToMemory," + strRecipeID + "," + m_strFalse;
    }
}

std::string AppRecipeManager::do_DeleteRecipeBodyFiles(const std::string &strRecipeID)
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE,getName() + ": delete recipe body files: " + strRecipeID);

    string strConfigPath = Version::s_strConfigPath;
    string strXMLFileName = "";
    int nCheckResult = checkRecipeName(strRecipeID);
    if(nCheckResult == Error)
    {
        return "DeleteRecipeBodyFiles," + strRecipeID + "," + m_strFalse;
    }

    try
    {
        DIR *dir = opendir((strConfigPath + "Recipe").c_str());
        if (dir == NULL)
        {
            throw string(" delete recipe files failed! Cannot open " + strConfigPath + "Recipe");
        }
        struct dirent* dirp;
        string strDeleteResult = "";
        if(nCheckResult == AllRecipes)
        {
            strDeleteResult = m_strTrue;
            while ((dirp = readdir(dir)) != NULL)
            {
                if (dirp->d_type == DT_REG)//filter out "." and ".." directories
                {
                    string strFileName = dirp->d_name;
                    if(strFileName.find("Process_") != string::npos && strFileName.find("_1") != string::npos)
                    {
                        string strRcpName = extractRcpFullName(strFileName);
                        bool bSpecialRecipe = isSpecialRecipe(strRcpName);
                        if(bSpecialRecipe)
                        {
                        	strDeleteResult = m_strTrue;
                        	Log_Error(getName() + " " + strRcpName + " is special recipe,cannot execute DeleteRecipeBodyFiles service");
                        	continue;
                        }
                        try
                        {
                            ExecRcpHandler tmpRcpHandler = getRecipeHandler(strRcpName);

                            bool bSpecialComments = isSpecialComments(tmpRcpHandler);//added by taohao[1.5.0_HotFix9] for special recipe with Comments
                            m_pSession->releaseRecipe(tmpRcpHandler);
                            if(bSpecialComments)
                            {
                                strDeleteResult = m_strTrue;
                            	Log_Error(getName() + " " + strRcpName + " has special Comments,cannot execute StoreRecipeToMemory service");
                            	continue;
                            }
                        }
                        catch(...)
                        {
                        	Log_Error(getName() + " extract " + strRecipeID + " failed,the index for this recipe has been deleted.");
                        }
                        strXMLFileName = strFileName;
                        string strNeedDeleteRecipeName = strConfigPath +  "Recipe/" + strXMLFileName;
                        Log_Info( getName() + " is running to delete recipe file: " + strNeedDeleteRecipeName);
                        strDeleteResult = executeDeleteFile(strNeedDeleteRecipeName);
                    }
                }
            }
        }
        else
        {
        	//added by taohao[1.5.0_HotFix9] for special recipe with Comments
            bool bSpecialRecipe = isSpecialRecipe(strRecipeID);
            if(bSpecialRecipe)
            {
            	Log_Error(getName() + " " + strRecipeID + " is special recipe,cannot execute DeleteRecipeBodyFiles service");
            	return "DeleteRecipeBodyFiles," + strRecipeID + "," + m_strFalse;
            }
            string strRcpName = getRecipeName(strRecipeID);
            if(!strRcpName.empty())
            {
                strXMLFileName = "Process_" + strRcpName + "_1" + ".xml";
                string strNeedDeleteRecipeName = strConfigPath +  "Recipe/" + strXMLFileName;
                Log_Info( getName() + " is running to delete recipe file: " + strNeedDeleteRecipeName);
                strDeleteResult = executeDeleteFile(strNeedDeleteRecipeName);
            }
            else
            {
                Log_Error( getName() + strRecipeID + " is wrong name parameter");
                strDeleteResult = m_strFalse;
            }
        }

        if (closedir(dir) != 0)
        {
            throw string("close recipe files  Failed! Cannot close '" + strConfigPath + "Recipe");
        }
        return "DeleteRecipeBodyFiles," + strRecipeID + "," + strDeleteResult;
    }
    catch(const exception &ex)
    {
        Log_Error(getName() + ": AppRecipeManager::do_DeleteRecipeBodyFiles got exception-" +ex.what());
        return "DeleteRecipeBodyFiles," + strRecipeID + "," + m_strFalse;
    }
    catch(...)
    {
        Log_Error(getName() + ": AppRecipeManager::do_DeleteRecipeBodyFiles Unknown exception caught");
        if(!m_pServiceFailedAlarm->isPosted())
        {
            m_pServiceName->setValue("DeleteRecipeBodyFiles");
            m_pErrorDescription->setValue("Delete "  + strXMLFileName + " File Failed");
            m_pServiceFailedAlarm->post(this);
        }
        throw;
    }
}

std::string AppRecipeManager::do_DeleteRecipeFromMemory(const std::string &strRecipeID)
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE,getName() + " AppRecipeManager::delete recipe " + strRecipeID + " from memory");
    map<string, AppRcpBody*>::iterator it;
    std::map<std::string,RcpInfo>::iterator iter;
    try
    {
        IMutexLocker t_locker(&m_lock);
        switch(checkRecipeName(strRecipeID))
        {
            case AllRecipes:
                for(it = m_allRecipeBody.begin(); it != m_allRecipeBody.end();)
                {
                    Log_Info( getName() + " is running to delete recipe: " + (it->first) + " in memory");
                    if(it->first == m_strCurrentRecipeFullName)
                    {
                        Log_Info( getName() + "recipe[" + (it->first) + "] is in use and cannot be deleted");
                        ++it;
                        continue;
                    }
                    if(it->second != NULL)
                    {
                        it->second->clear();//clear AppRcpStep after use
                        delete it->second;
                        it->second = NULL;
                    }
                    //it = m_allRecipeBody.erase(it);  //C++ 11
                    m_allRecipeBody.erase(it++);
                }
                m_allRecipeBody.clear();
                for(it = m_rcpBodyBuffer.begin(); it != m_rcpBodyBuffer.end();)
                {
                    Log_Info( getName() + " is running to delete recipe : " + (it->first) + " in buffer");
                    if(it->second != NULL)
                    {
                        it->second->clear();//clear AppRcpStep after use
                        delete it->second;
                        it->second = NULL;
                    }
                    m_rcpBodyBuffer.erase(it++);
                }
                m_rcpBodyBuffer.clear();
                m_rcpBodyParam.clear();
                m_rcpBodyParamBuffer.clear();
                return "DeleteRecipeFromMemory," + strRecipeID + "," + m_strTrue;

            case Buffer:
                for(it = m_rcpBodyBuffer.begin(); it != m_rcpBodyBuffer.end();)
                {
                    Log_Info( getName() + " is running to emptying recipes in buffer");
                    if(it->second != NULL)
                    {
                        it->second->clear();//clear AppRcpStep after use
                        delete it->second;
                        it->second = NULL;
                    }
                    m_rcpBodyBuffer.erase(it++);
                }
                m_rcpBodyParamBuffer.clear();
                return "DeleteRecipeFromMemory," + strRecipeID + "," + m_strTrue;

            case OneRecipe:
                it = m_allRecipeBody.find(strRecipeID);
                if(it != m_allRecipeBody.end())
                {
                    if(strRecipeID == m_strCurrentRecipeFullName)
                    {
                        Log_Info( getName() + "recipe[" + (it->first) + "] is in use and cannot be deleted");
                        return "DeleteRecipeFromMemory," + strRecipeID + "," + m_strFalse;
                    }
                    if(it->second != NULL)
                    {
                        it->second->clear();//clear AppRcpStep after use
                        delete it->second;
                        it->second = NULL;
                    }
                    m_allRecipeBody.erase(it);
                }
                iter = m_rcpBodyParam.find(strRecipeID);
                if(iter != m_rcpBodyParam.end())
                {
                    m_rcpBodyParam.erase(iter);
                }
                return "DeleteRecipeFromMemory," + strRecipeID + "," + m_strTrue;

            case Error:
                return "DeleteRecipeFromMemory," + strRecipeID + "," + m_strFalse;
            default:
                return "DeleteRecipeFromMemory," + strRecipeID + "," + m_strFalse;
        }
    }
    catch(const exception &ex)
    {
        Log_Error(getName() + ": AppRecipeManager::do_DeleteRecipeFromMemory  got exception-" +ex.what());
        return "DeleteRecipeFromMemory," + strRecipeID + "," + m_strFalse;
    }
    catch(...)
    {
        Log_Error(getName() + ": AppRecipeManager::do_DeleteRecipeFromMemory Unknown exception caught");
        return "DeleteRecipeFromMemory," + strRecipeID + "," + m_strFalse;
    }
}

void AppRecipeManager::setCurrentRecipeFullName(const std::string &strRecipeID)
{
    Log_Info("OperationalProcess or it's subclass is executing do_PrepareRecipe,recipe's name is: " + strRecipeID);
    IMutexLocker t_locker(&m_lock);
    m_strCurrentRecipeFullName = strRecipeID;
}

void AppRecipeManager::clearCurrentRecipeFullName()
{
    Log_Info(getName() + " m_strCurrentRecipeFullName is " + m_strCurrentRecipeFullName);
    IMutexLocker t_locker(&m_lock);
    m_strCurrentRecipeFullName = "";
    Log_Info(getName() + " m_strCurrentRecipeFullName has been cleared");
}

std::string AppRecipeManager::refreshRecipeBodyMap(const std::string &strRecipeID,AppRcpBody *rcpBody,const ExecRcpHandler &handler)
{
    RcpInfo rcpInfo;
    rcpInfo.rcpVersion = handler.getVersion();
    rcpInfo.rcpNumOfSteps = handler.getNumOfSteps();
    rcpInfo.rcpNumOfParams= handler.getNumOfParams();
    rcpInfo.rcpBodyTotalProcessTime = calculateProcessTotalTime(rcpBody);

    string strDeleteResult = "true";
    if(m_allRecipeBody.size() > MAX_RECIPE_NUM)
    {
        Log_Error( getName() + " The number of recipes in memory has exceeded the maximum of " + Converter::convertToString(MAX_RECIPE_NUM) + ", is emptying all memory");
        strDeleteResult = do_DeleteRecipeFromMemory(m_strAll);
        strDeleteResult = strDeleteResult.substr(strDeleteResult.find_last_of(',')+1);
    }
    if(m_rcpBodyBuffer.size() > MAX_BUFFER_SIZE)
    {
        Log_Error( getName() + " The number of recipes in buffer has exceeded the maximum of " + Converter::convertToString(MAX_BUFFER_SIZE) + ", is emptying buffer");
        strDeleteResult = do_DeleteRecipeFromMemory(m_strBuffer);
        strDeleteResult = strDeleteResult.substr(strDeleteResult.find_last_of(',')+1);
    }

    if(strDeleteResult == m_strTrue)
    {
        if(m_allRecipeBody.find(strRecipeID) != m_allRecipeBody.end())
        {
            Log_Info( getName() + " Recipe " + strRecipeID + " is already in memory, store recipe to buffer");
            m_rcpBodyBuffer[strRecipeID] = rcpBody;
            m_rcpBodyParamBuffer[strRecipeID] = rcpInfo;
        }
        else
        {
            m_allRecipeBody[strRecipeID] = rcpBody;
            m_rcpBodyParam[strRecipeID] = rcpInfo;
        }
        return m_strTrue;
    }
    return m_strFalse;
}

std::string AppRecipeManager::getCurrentRecipeFullName() const
{
    IMutexLocker t_locker(&m_lock);
    return m_strCurrentRecipeFullName;
}

bool AppRecipeManager::isGetRcpInfoFromIAP(const std::string &strRecipeID,bool bSpecialRecipe) const
{
	if(isDryCleanProcessType(strRecipeID) || isSpecialRecipe(strRecipeID,bSpecialRecipe) || !isOpenDeleteFunction(strRecipeID) || !isExistInMemory(m_strCurrentRecipeFullName))
	{
		return true;
	}
	return false;
}

bool AppRecipeManager::isOpenDeleteFunction(const std::string &strRecipeID) const
{
    return m_cfgDeleteRecipeFlag->getValue();
}

bool AppRecipeManager::isDryCleanProcessType(const std::string &strRecipeID) const
{
    if(strRecipeID.find("DryClean") != string::npos)
    {
        return true;
    }
    else if(strRecipeID.empty())
    {
        string strRcpName = getCurrentRecipeFullName();
        if(strRcpName.find("DryClean") != string::npos)
        {
            return true;
        }
    }
    return false;
}

bool AppRecipeManager::isSpecialRecipe(const std::string &strRecipeID,bool bSpecialRecipe) const
{
    if(bSpecialRecipe)//Use for special functions,for example do_ReleaseWaferCharge
    {
        return true;
    }
    string strRcpName = getCurrentRecipeFullName();
    if(strRecipeID.empty())
    {
        strRcpName = getRecipeName(strRcpName);
    }
    else
    {
        strRcpName = getRecipeName(strRecipeID);
    }
    string strLowerName = StrTool::toLower(strRcpName);
    if(strLowerName.compare(0, 7, "dechuck") == 0 || strLowerName.compare(0, 5, "chuck") == 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}
//added by taohao[1.5.0_HotFix9] for special recipe with Comments
bool AppRecipeManager::isSpecialComments(const ExecRcpHandler &handler) const
{
    string strComments = "commentsErr";
    try
    {
        strComments = handler.getComments();
    }
    catch (const exception& ex)
    {
        Log_Error(getName() + ": AppRecipeManager::isSpecialComments got exception-" + ex.what());
        return false;
    }
    catch (...)
    {
        Log_Error(getName() + ": AppRecipeManager::isSpecialComments Unknown exception caught");
        return false;
    }
    Log_Info( getName() + " comments: " + strComments);
    string strLowerComments = StrTool::toLower(strComments);
    //special comments for example: "reserve;2026-03-11 09:42:04"
    if (strComments.size() < 20)
    {
        return false;
    }

    if (strLowerComments.compare(0, 7, "reserve") == 0)
    {
        return true;
    }
    return false;
}

//ExecRcpHandler
std::string AppRecipeManager::getHandlerClass() const
{
    if(isGetRcpInfoFromIAP())
    {
        return m_CurrentRcpHandler.getClass();
    }
    else
    {
        return m_pRecipeBodyFromMemory->getRcpClass();
    }
}

unsigned int AppRecipeManager::getNumOfSteps() const
{
    if(isGetRcpInfoFromIAP())
    {
        return m_CurrentRcpHandler.getNumOfSteps();
    }
    else
    {
        return m_pRecipeBodyFromMemory->getRcpAllStepNum();
    }
}

std::string AppRecipeManager::getStepValueAS(unsigned int nStepIndex, const std::string &strParamName) const
{
    if(isGetRcpInfoFromIAP())
    {
        return m_CurrentRcpHandler.getStepValueAS(nStepIndex,strParamName);
    }
    else
    {
        //for calculateProcessTime;
        return "";//need fix
    }
}

std::string AppRecipeManager::getRcpHandlerName()
{
    if(isGetRcpInfoFromIAP())
    {
        return m_CurrentRcpHandler.getName();
    }
    else
    {
        return m_pRecipeBodyFromMemory->getRcpName();
    }
}

std::string AppRecipeManager::getVersion() const
{
    if(isGetRcpInfoFromIAP())
    {
        return m_CurrentRcpHandler.getVersion();
    }
    else
    {
        return m_rcpInfo.rcpVersion;
    }
}

unsigned int AppRecipeManager::getNumOfParams() const
{
    if(isGetRcpInfoFromIAP())
    {
        return m_CurrentRcpHandler.getNumOfParams();
    }
    else
    {
        return m_rcpInfo.rcpNumOfSteps;
    }
}

void AppRecipeManager::getStepValue(unsigned int nStepIndex, const std::string &strParamName, ValueInfo &vInfo) const
{
    if(isGetRcpInfoFromIAP())
    {
        m_CurrentRcpHandler.getStepValue(nStepIndex,strParamName,vInfo);
    }
    else
    {
        //for do_CalculateLearn
        //need fix
    }
}

std::string AppRecipeManager::getParamName(unsigned int index) const
{
    if(isGetRcpInfoFromIAP())
    {
        return m_CurrentRcpHandler.getParamName(index);
    }
    else
    {
        //for do_CalculateLearn
        return "";//need fix
    }
}

bool AppRecipeManager::setStepValue(unsigned int nStepIndex, unsigned int nParamIndex, const std::string &strValue, bool bNeedNotify)
{
    if(isGetRcpInfoFromIAP())
    {
        return m_CurrentRcpHandler.setStepValue(nStepIndex,nParamIndex,strValue,bNeedNotify);
    }
    else
    {
        //for do_CalculateLearn
        return true;//need fix
    }
}

bool AppRecipeManager::setStepValue(unsigned int nStepIndex, string strParamName, const std::string &strValue, bool bNeedNotify)
{
    if(isGetRcpInfoFromIAP())
    {
        return m_CurrentRcpHandler.setStepValue(nStepIndex,strParamName,strValue,bNeedNotify);
    }
    else
    {
        //for do_CalculateLearn
        return true;//need fix
    }
}

std::string AppRecipeManager::getRecipeID() const
{
    if(isGetRcpInfoFromIAP())
    {
        return m_CurrentRcpHandler.getRecipeID();
    }
    else
    {
        //for do_CalculateLearn
        return "";
    }
}

bool AppRecipeManager::verify() const
{
    if(isGetRcpInfoFromIAP())
    {
        return m_CurrentRcpHandler.verify();
    }
    else
    {
        return true;//do nothing
    }
}

IO::DataType AppRecipeManager::getParamType(const std::string &strName) const
{
    if(isGetRcpInfoFromIAP())
    {
        return m_CurrentRcpHandler.getParamType(strName);
    }
    else
    {
        //for do_CalculateLearn
        return IO::UNKNOWN;//need fix
    }
}

double AppRecipeManager::calculateProcessTotalTime(AppRcpBody *rcpBody) const
{
    AppRcpStep rcpStep;
    double dTotalProcessTime = 0.0;
    for(int nStepNum=1;nStepNum<=rcpBody->getStepSize();nStepNum++)
    {
        rcpStep = rcpBody->getStep(nStepNum);
        if(rcpStep.hasParam("EndMode") && rcpStep.getParamValue("EndMode").IntValue.getValueAsDescriptor() == "EndPt")
        {
            dTotalProcessTime += rcpStep.getParamValue("MaxEPDTime").DoubleValue.getValue();
        }
        else
        {
            dTotalProcessTime += rcpStep.getParamValue("ProcessTime").DoubleValue.getValue();
        }
    }
    return dTotalProcessTime;
}

double AppRecipeManager::calculateProcessTotalTime() const
{
    double dTotalProcessTime = 0.0;
    double d1;
    for(unsigned int i = 1; i <= m_CurrentRcpHandler.getNumOfSteps(); i++)
    {
        Converter::stringToDouble(d1, m_CurrentRcpHandler.getStepValueAS(i, "ProcessTime"));
        dTotalProcessTime += d1;
    }
    return dTotalProcessTime;
}

AppRcpBody* AppRecipeManager::makeCurrentRecipeBody(bool bLiveEdit)
{
    if(isGetRcpInfoFromIAP())
    {
        m_pRecipeBodyFromIAP->clear();
        m_pRecipeBodyFromIAP->makeBody(m_CurrentRcpHandler);
        return m_pRecipeBodyFromIAP;
    }
    else
    {
        if(m_pRecipeBodyFromMemory == NULL)
        {
            throw AbortException("Cannot make current recipe body for recipe body is null !!!");
        }
        if(bLiveEdit)
        {
            if(!m_pExecuteRecipeFailed->isPosted())
            {
                m_pExecuteRecipeFailed->setMessage("Failed to use live edit function.");
                m_pExecuteRecipeFailed->post(this);
                throw AbortException("Cannot live edit recipe for open delete recipe function !!!");
            }
        }
        return m_pRecipeBodyFromMemory;
    }
}

//RecipeMgmtSession
void AppRecipeManager::releaseRecipe(const std::string &strRecipeID)
{
    clearCurrentRecipeFullName();
    if(isGetRcpInfoFromIAP(strRecipeID))
    {
        m_pSession->releaseRecipe(m_CurrentRcpHandler);
        m_pRecipeBodyFromIAP->clear();
    }
}

void AppRecipeManager::retrieveRecipe(const std::string &strRecipeID, bool bSpecialRecipe, bool bExclusive)
{
    setCurrentRecipeFullName(strRecipeID);
    //The following three judgment conditions are: DryClean recipe type; Special process recipes,
    //such as chuck/dechuck/releaseWaferCharge, etc.; Delete recipe function switch
    if(isGetRcpInfoFromIAP(strRecipeID,bSpecialRecipe))
    {
        m_CurrentRcpHandler = getRecipeHandler(strRecipeID,bExclusive);
        //m_pRecipeBody = new AppRcpBody();//delete,avoid memory growth
    }
    else
    {
        //1.Update m_allRecipeBody form m_rcpBodyBuffer
        deleteSameElementInMemory(strRecipeID);
        //2.Update m_pRecipeBodyFromMemory from m_allRecipeBody
        m_pRecipeBodyFromMemory = getRcpBodyFromMemory(strRecipeID);
        m_rcpInfo = getRcpBodyInfoFromMemory(strRecipeID);
    }
}

void AppRecipeManager::storeRecipe(const std::string &strRecipeID,bool bOverwrite)
{
    if(isDryCleanProcessType(strRecipeID) || isSpecialRecipe(strRecipeID) || !isOpenDeleteFunction() || !isExistInMemory(strRecipeID))
    {
        m_pSession->storeRecipe(m_CurrentRcpHandler,bOverwrite);
    }
}

void AppRecipeManager::clear(const std::string &strRecipeID)
{
    if(isDryCleanProcessType(strRecipeID) || isSpecialRecipe(strRecipeID) || !isOpenDeleteFunction() || !isExistInMemory(strRecipeID))
    {
        m_pRecipeBodyFromIAP->clear();
    }
}

void AppRecipeManager::notifyOtherSession(const RecipeMgmtEvent &event)
{
    RecipeNamespaceManager::getInstance()->notifyOtherSession(m_pSession, event);
}

ExecRcpHandler AppRecipeManager::getRecipeHandler(const std::string &strRecipeID,bool bExclusive)
{
    ExecRcpHandler CurrentRcpHandler;

    try
    {
        RecipeMgmtSession::CriticalZone cz;
        //change by taohao [v1.10.0] modify the second parameter of the retrieveRecipe method to be a parameter that can be passed.
        CurrentRcpHandler = m_pSession->retrieveRecipe(strRecipeID, bExclusive);
    }
    catch(const exception &err)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,getName() + strRecipeID +": retrieve recipe failed for: " +string(err.what()));
        m_pSession->clear();
        throw AbortException("Failed to retrieve the recipe ["+strRecipeID+"]");
    }

    if (!CurrentRcpHandler.verify())
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + strRecipeID +": recipe verify failed.");
        m_pSession->releaseRecipe(CurrentRcpHandler);
        m_pSession->clear();
        throw AbortException("Failed to verify the recipe ["+CurrentRcpHandler.getName()+"]");
    }

    if(CurrentRcpHandler.getNumOfSteps() == 0)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() +strRecipeID +": recipe body is empty.");
        m_pSession->releaseRecipe(CurrentRcpHandler);
        m_pSession->clear();
        throw AbortException("Recipe ["+CurrentRcpHandler.getName()+"] is NULL, please add step.");
    }
    return CurrentRcpHandler;
}

void AppRecipeManager::deleteSameElementInMemory(const std::string &strRecipeID)
{
    AppRcpBody *tmpRecipeBody = NULL;
    try
    {
        map<string, AppRcpBody*>::iterator it = m_rcpBodyBuffer.find(strRecipeID);
        if(it != m_rcpBodyBuffer.end())
        {
            Log_Info( getName() + " copy recipe: " + strRecipeID + " from buffer to memory");
            //m_allRecipeBody[strRecipeID] = it->second;
            tmpRecipeBody = new AppRcpBody(*it->second);
            m_allRecipeBody[strRecipeID] = tmpRecipeBody;
            if(it->second != NULL)
            {
                delete it->second;
                it->second = NULL;
            }
            m_rcpBodyBuffer.erase(it);
        }

        std::map<std::string,RcpInfo>::iterator iter = m_rcpBodyParamBuffer.find(strRecipeID);
        if(iter != m_rcpBodyParamBuffer.end())
        {
            m_rcpBodyParam[strRecipeID] = iter->second;
            m_rcpBodyParamBuffer.erase(iter);
        }
    }
    catch(const exception &ex)
    {
        Log_Error(getName() + ": AppRecipeManager::deleteSameElementInMemory got exception-" +ex.what());
        if(tmpRecipeBody != NULL)
        {
            delete tmpRecipeBody;
            tmpRecipeBody = NULL;
        }
    }
    catch(...)
    {
        Log_Error(getName() + ": AppRecipeManager::deleteSameElementInMemory Unknown exception caught");
        if(tmpRecipeBody != NULL)
        {
            delete tmpRecipeBody;
            tmpRecipeBody = NULL;
        }
    }
}

std::string AppRecipeManager::executeDeleteFile(const std::string &strNeedDeleteRecipeName)
{
    try
    {
        int ret = remove(strNeedDeleteRecipeName.c_str());
        if (ret != 0)
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::RECIPE, LEVEL::PROBLEM," Delete Recipe Body File failed, error code " + Converter::convertToString(ret));
            if(!m_pServiceFailedAlarm->isPosted())
            {
                m_pServiceName->setValue("DeleteRecipeBodyFiles");
                m_pErrorDescription->setValue("Delete "  + strNeedDeleteRecipeName + " File Failed");
                m_pServiceFailedAlarm->post(this);
            }
            return m_strFalse;
        }
        else
        {
            return m_strTrue;
        }
    }
    catch(...)
    {
        throw;
    }
}
//added by taohao[1.5.0_HotFix9] for special recipe with Comments
bool AppRecipeManager::isExistInMemory(const std::string &strRecipeID) const
{
    map<string, AppRcpBody*>::iterator it = m_allRecipeBody.find(strRecipeID);
    if(it != m_allRecipeBody.end())
    {
    	return true;
    }
    it = m_rcpBodyBuffer.find(strRecipeID);
    if(it != m_rcpBodyBuffer.end())
    {
    	return true;
    }
	Log_Info( getName() + strRecipeID + " is not in memory or buffer");
	return false;
}

AppRcpBody* AppRecipeManager::getRcpBodyFromMemory(const std::string &strRecipeID) const
{
    Log_Info( getName() + " is running to get RecipeID: " + strRecipeID + "'s AppRcpBody in memory");
    try
    {
        int nCheckResult = checkRecipeName(strRecipeID);
        if(nCheckResult == OneRecipe)
        {
            map<std::string, AppRcpBody*>::const_iterator it = m_allRecipeBody.find(strRecipeID);
            if(it != m_allRecipeBody.end())
            {
                return it->second;
            }
            else
            {
                throw AbortException("There is no recipe [" + strRecipeID + "] in memory, please check.");
            }
        }
        else
        {
            throw AbortException("Invalid key: " + strRecipeID);
        }
    }
    catch (AbortException &ex)
    {
        Log_Error(getName() + " Exception caught: " + std::string(ex.what()));
        throw;
    }
    catch (exception &ex)
    {
        Log_Error(getName() + " Exception caught: " + std::string(ex.what()));
        throw;
    }
    catch (...)
    {
        Log_Error(getName() + " Unknown exception caught");
        throw;
    }
}

RcpInfo AppRecipeManager::getRcpBodyInfoFromMemory(const std::string &strRecipeID) const
{
    Log_Info( getName() + " is running to get RecipeID: " + strRecipeID + "'s RcpBodyInfo in memory");
    try
    {
        int nCheckResult = checkRecipeName(strRecipeID);
        if(nCheckResult == OneRecipe)
        {
            std::map<std::string,RcpInfo>::const_iterator it = m_rcpBodyParam.find(strRecipeID);
            if(it != m_rcpBodyParam.end())
            {
                return it->second;
            }
            else
            {
                throw AbortException("There is no RcpBody [" + strRecipeID + "] in memory, please check.");
            }
        }
        else
        {
            throw AbortException("Invalid key: " + strRecipeID);
        }
    }
    catch (AbortException &ex)
    {
        Log_Error(getName() + " Exception caught: " + std::string(ex.what()));
        throw;
    }
    catch (exception &ex)
    {
        Log_Error(getName() + " Exception caught: " + std::string(ex.what()));
        throw;
    }
    catch (...)
    {
        Log_Error(getName() + " Unknown exception caught");
        throw;
    }
}

int AppRecipeManager::checkRecipeName(const std::string &strRecipeID) const
{
    //Log_Info( getName() + " is checking recipe name: " + strRecipeID);
    try
    {
        if(isDryCleanProcessType(strRecipeID) && !isOpenDeleteFunction(strRecipeID))
        {
            throw AbortException("Cannot execute this operation for not open delete recipe function,or recipe type is DryClean");
        }
        if(isSpecialRecipe(strRecipeID))
        {
            throw AbortException("Cannot execute this operation for recipe name starts with the chuck or dechuck");
        }
        if(strRecipeID == m_strBuffer)
        {
            return Buffer;
        }
        if(strRecipeID.empty())
        {
            return Error;
        }
        if(strRecipeID == m_strAll)
        {
            Log_Info( "AppRecipeManager operation type is AllRecipes");
            return AllRecipes;
        }
        string strRcpName = getRecipeName(strRecipeID);
        if(strRcpName.empty())
        {
            Log_Info( "AppRecipeManager operation type is Error");
            return Error;
        }
        Log_Info( "AppRecipeManager operation type is OneRecipe");
        return OneRecipe;
    }
    catch(const exception &ex)
    {
        Log_Error(getName() + ": AppRecipeManager::checkRecipeName got exception-" +ex.what());
        return Error;
    }
    catch(...)
    {
        Log_Error(getName() + ": AppRecipeManager::checkRecipeName Unknown exception caught");
        return Error;
    }
}

std::string AppRecipeManager::getRecipeName(const std::string &strRecipeID) const
{
    string strRcpName = strRecipeID.substr(strRecipeID.find_last_of('/')+1);
    strRcpName = strRcpName.substr(0,strRcpName.find(";"));
    return strRcpName;
}

std::string AppRecipeManager::extractRcpFullName(const std::string &strFileName) const
{
    size_t firstPos = strFileName.find('_');
    if(firstPos == std::string::npos)
    {
        return "";
    }
    string strRcpClass = strFileName.substr(0,firstPos);
    size_t lastPos = strFileName.find_last_of('_');
    if(lastPos == std::string::npos)
    {
        return "";
    }
    string strRcpVersion = strFileName.substr(lastPos+1,1);//RcpVersion need less 10
    string strRcpName = strFileName.substr(firstPos+1,lastPos-firstPos-1);
    return "/" + strRcpClass + "/" + strRcpName + ";" + strRcpVersion;
}

void AppRecipeManager::StoreRecipeToMemory::execute()
{
    ControlObject* owner = getOwner();
    if (owner != NULL)
    {
        #ifdef IAP4_0
        Result.Str = (dynamic_cast<AppRecipeManager*>(owner))->do_StoreRecipeToMemory(Params["strRecipeID"].Str);
		#else
        Results["success"].Str = (dynamic_cast<AppRecipeManager*>(owner))->do_StoreRecipeToMemory(Params["strRecipeID"].Str);
		#endif
    }
}

void AppRecipeManager::DeleteRecipeBodyFiles::execute()
{
    ControlObject* owner = getOwner();
    if (owner != NULL)
    {
		#ifdef IAP4_0
        Result.Str = (dynamic_cast<AppRecipeManager*>(owner))->do_DeleteRecipeBodyFiles(Params["strRecipeID"].Str);
		#else
        Results["success"].Str = (dynamic_cast<AppRecipeManager*>(owner))->do_DeleteRecipeBodyFiles(Params["strRecipeID"].Str);
		#endif
    }
}

void AppRecipeManager::DeleteRecipeFromMemory::execute()
{
    ControlObject* owner = getOwner();
    if (owner != NULL)
    {
		#ifdef IAP4_0
        Result.Str = (dynamic_cast<AppRecipeManager*>(owner))->do_DeleteRecipeFromMemory(Params["strRecipeID"].Str);
		#else
        Results["success"].Str = (dynamic_cast<AppRecipeManager*>(owner))->do_DeleteRecipeFromMemory(Params["strRecipeID"].Str);
		#endif
    }
}


/*!
    @brief This method is used to get all Recipe IDs under specified RecipeClass.
    @param [in] clsName The name of RecipeClass, such as '/Process'.
    @return A string vector which contains all Recipe IDs.
*/
vector<string> AppRecipeManager::getRcpIDsUnder(const string& clsName) const
{
	return m_pSession->getRcpIDsUnder(clsName);
}

IMPLEMENT_DYNAMIC_SERVICE(StoreRecipeToMemory, AppRecipeManager)
IMPLEMENT_DYNAMIC_SERVICE(DeleteRecipeBodyFiles, AppRecipeManager)
IMPLEMENT_DYNAMIC_SERVICE(DeleteRecipeFromMemory, AppRecipeManager)

BEGIN_SERVICEINFO_LIST(AppRecipeManager)
    ADD_SERVICE_INFO(AppRecipeManager, StoreRecipeToMemory, StoreRecipeToMemory for StoreRecipeToMemory.)
        ADD_PARAM_INFO(AppRecipeManager, StoreRecipeToMemory, strRecipeID, string, strRecipeID.)
    ADD_SERVICE_INFO(AppRecipeManager, DeleteRecipeBodyFiles, strRecipeID for strRecipeID.)
        ADD_PARAM_INFO(AppRecipeManager, DeleteRecipeBodyFiles, strRecipeID, string, strRecipeID.)
    ADD_SERVICE_INFO(AppRecipeManager, DeleteRecipeFromMemory, strRecipeID for strRecipeID.)
        ADD_PARAM_INFO(AppRecipeManager, DeleteRecipeFromMemory, strRecipeID, string, strRecipeID.)
END_SERVICEINFO_LIST(AppRecipeManager)

IMPLEMENT_DYNAMIC(AppRecipeManager, ControlObject)
BEGIN_MSG_MAP( AppRecipeManager, ControlObject )
END_MSG_MAP
