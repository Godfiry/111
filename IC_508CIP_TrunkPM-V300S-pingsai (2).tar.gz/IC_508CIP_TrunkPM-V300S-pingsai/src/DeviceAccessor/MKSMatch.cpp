/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MKSMatch.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-11-17   LiJuanjuan create
**      
*********************************************************************/
#include "MKSMatch.h"
#include "Converter.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std; 

DescriptorList MKSMatch::m_memList = DescriptorList("A:1,B,C,D,E,F");
			
MKSMatch::MKSMatch():SerialDevice(100, "\x0D")
{
	m_timeOut = 50;//5s
	m_pollPeriod = 1000; //1s	
}

MKSMatch::~MKSMatch()
{
}

bool MKSMatch::sendCommand(std::string command, int timeOut)
{
	string res = getCommandResult(command, timeOut);
	if(res.find("\x0D\x0A",0) == string::npos)
	{	
		res += getResultOnly(50);//time out = 5s;
	}

	if(res.find("\x0D\x0A*",0) != string::npos)
	{	
		return true;
	}
	else if(res.find("\x0D\x0A?",0) != string::npos)
	{
		throw IOException(getDeviceName()+" send command ["+command+"] occurred error [" + Hex::GetHexString(res.c_str(),res.size())+"]");
	}
	else
	{
		throw IOException(getDeviceName()+" send command ["+command+"] failed for unknown response [" + Hex::GetHexString(res.c_str(),res.size())+"]");
	}		

}
		
std::string MKSMatch::readCommand(std::string command, int timeOut)
{
	string res = getCommandResult(command, timeOut);
	if(res.find("\x0D\x0A*",0) != string::npos)
	{	
		return res;
	}
	else if(res.find("\x0D\x0A?",0) != string::npos)
	{
		throw IOException(getDeviceName()+" read command ["+command+"] occurred error [" + Hex::GetHexString(res.c_str(),res.size())+"]");
	}	
	else
	{
		throw IOException(getDeviceName()+" read command ["+command+"] failed for unknown response [" + Hex::GetHexString(res.c_str(),res.size())+"]");
	}		
}

IMPLEMENT_DYNAMIC(MKSMatch, SerialDevice )
BEGIN_MSG_MAP(MKSMatch, SerialDevice )
END_MSG_MAP
