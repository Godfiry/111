/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MFCNotCalibratedException.h
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-02-26  LiJuanjuan create
**      
*********************************************************************/
#ifndef MFCNOTCALIBRATEDEXCEPTION_H_
#define MFCNOTCALIBRATEDEXCEPTION_H_

#include "TMCException.h"

class MFCNotCalibratedException:public TMCException
{
	public:
		MFCNotCalibratedException(const std::string &s);
};

#endif /*MFCNOTCALIBRATEDEXCEPTION_H_*/
