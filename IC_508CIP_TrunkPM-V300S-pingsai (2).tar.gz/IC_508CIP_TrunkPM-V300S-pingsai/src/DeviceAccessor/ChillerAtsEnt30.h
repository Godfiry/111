/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: ChillerAtsEnt30.h
** Description: This driver is used for Institute of Automation Chiller 
*                RS485 ATS communication protocol ENT-30
* 				   Communication Type:Modbus protocol,ASCII Mode
* 				   BaudRate:9600
*                DataBit:7
* 				   StartBit:1
*                StopBit:1
*                Parity:Even
*                FlowControl:no flow control 
*                          
** Release: 1.1
** Modification history: 
** 					2019-1-3   chenmz create
**      
*********************************************************************/


#ifndef CHILLERATSENT30_H_
#define CHILLERATSENT30_H_


#include "SerialDevice.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class ChillerAtsEnt30:public SerialDevice
{
	DECLARE_DYNAMIC(ChillerAtsEnt30)	
	DECLARE_MSG_MAP

	public:
		ChillerAtsEnt30();
		virtual ~ChillerAtsEnt30();

	public:	
		bool writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo);
		bool readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);
		bool readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);
		bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
		void init();
	
	protected:
		void initDevice();
		void initChs(DeviceNode<ChillerAtsEnt30> *pNode);

	private:
		typedef struct
		{
			std::string m_strAddress;
			int m_nDeal;
		}Cmd;
		
		static Cmd m_cmd[];	
};
#endif /*CHILLERATSENT30_H_*/
