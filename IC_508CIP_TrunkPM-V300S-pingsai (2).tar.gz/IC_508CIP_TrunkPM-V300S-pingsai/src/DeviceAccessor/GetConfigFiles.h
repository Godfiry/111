/**************************************************************************************

Copyright (c) Hilscher Gesellschaft fuer Systemautomation mbH. All Rights Reserved.

***************************************************************************************

  $Id: GetConfigFiles.h 1427 2014-08-01 09:19:25Z gordon $:

  Description:
    Get Configuration Parameter Files - Host PC Example
    This file contains all task function prototypes including the main functions as
    well as the sub "action" functions to get the configuration files to initialize
    the running firmware on the expected netX-target.
**************************************************************************************/

#ifndef __GETCONFIG_FILES_H__
#define __GETCONFIG_FILES_H__

#include "stdint.h"

/*************************************************************************************/
/* Defines */
#define CONFIG_FILENAME "config.nxd"                                                  /* Slave and bus config file  */
#define NWID_FILENAME "nwid.nxd"                                                      /* TCPIP config file          */


/*************************************************************************************/
/* Prototypes */

/* Get slave and bus SYCON.net configuration config.NXD */
long
GetSlaveBusConfig
(
  unsigned char **ppabFileData,
  unsigned long *pulFileSize
);

/* Get TCPIP SYCON.net configuration nwid.NXD */
long
GetTCPIPConfig
(
  unsigned char **ppabFileData,
  unsigned long *pulFileSize
);


/*************************************************************************************/

#endif /* __GETCONFIG_FILES_H__ */
