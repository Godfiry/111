/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AlarmIDAssigner.h
** Description: 
** Release: 
** Modification history: 
**                   2010-03-06   lijj create
**      
***************************************************************************/
#ifndef ALARMIDASSIGNER_H_
#define ALARMIDASSIGNER_H_

#include "CmdTarget.h"
#include <map>
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

class AlarmIDAssigner:public CmdTarget
{
	DECLARE_DYNAMIC( AlarmIDAssigner )
	DECLARE_MSG_MAP	
	
	private:
		static int m_id;
		std::map<std::string, int> m_alarmIDsMap;  //add by chensc[1.1.57_HotFix3]
	public:
		AlarmIDAssigner();
		virtual ~AlarmIDAssigner();
		
		virtual void startup();
		int assignAnID(const std::string &alarmName);
		
		void setStartID(int id);
		void addAlarm( const std::string &alarmName, int alarmID);  //add by chensc[1.1.57_HotFix3]
};

#endif /*ALARMIDASSIGNER_H_*/
