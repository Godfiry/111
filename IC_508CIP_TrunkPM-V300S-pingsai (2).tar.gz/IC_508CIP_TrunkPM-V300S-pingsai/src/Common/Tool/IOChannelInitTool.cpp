#include "IOChannelInitTool.h"
#include "XmlGetter.h"
#include <iostream>
#include "SysLogger.h"
#include "ConfigException.h"
#include "Converter.h"
#include "ReadWriteInt.h"
#include "ReadWriteDouble.h"
#include "ReadWriteString.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
#endif
IOChannelInitTool::IOChannelInitTool()
{

}

IOChannelInitTool::~IOChannelInitTool()
{

}

void IOChannelInitTool::initIntChannel(string strPath,int nValue)
{
	ReadWriteInt * pData=XmlGetter::getFromNamespace<ReadWriteInt *>(strPath);
	if(pData == NULL )
	{
		throw ConfigException(strPath + " channel is null!");
	}
	pData->setValue(nValue);
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + " init channel ["+strPath+"] 's value = "+Converter::convertToString(nValue));
}

void IOChannelInitTool::initDoubleChannel(string strPath,double dValue)
{
	ReadWriteDouble * pData=XmlGetter::getFromNamespace<ReadWriteDouble *>(strPath);
	if(pData == NULL )
	{
		throw ConfigException(strPath + " channel is null!");
	}
	pData->setValue(dValue);
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + " init channel ["+strPath+"] 's value = "+Converter::convertToString(dValue));
}

void IOChannelInitTool::initStringChannel(string strPath,string strValue)
{
	ReadWriteString * pData=XmlGetter::getFromNamespace<ReadWriteString *>(strPath);
	if(pData == NULL )
	{
		throw ConfigException(strPath + " channel is null!");
	}
	pData->setValue(strValue);
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + " init channel ["+strPath+"] 's value = "+strValue);
}

IMPLEMENT_DYNAMIC(IOChannelInitTool, CmdTarget)

BEGIN_MSG_MAP( IOChannelInitTool, CmdTarget)
	SET_SI(initIntChannel, IOChannelInitTool)
	SET_SD(initDoubleChannel, IOChannelInitTool)
	SET_SS(initStringChannel, IOChannelInitTool)
END_MSG_MAP
