/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					Jan 22, 2008  shenql  create 
**      
***************************************************************************/
#ifndef XFERSTSINFO_H_
#define XFERSTSINFO_H_
#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class XferStsInfo : public IntValueInfo
{
public:

		static const int UnInit = -1;
		static const int Unknown = 0;
		static const int PreChming = 1;
		static const int PreChmbed = 2;
		static const int PrpWfring = 3;
		static const int PrpWfred = 4;
		static const int XfrWfring = 5;
		static const int XfrWfred = 6;
		static const int CmtWfring = 7;
		static const int CmtWfred = 8;
		static const int Cleaning = 9;
		static const int Cleaned = 10;
		static const int Rd4Cln = 11;
		static const int Mapping = 12;
		static const int Mapped = 13;
		static const int Initting = 14;
		static const int Initted = 15;
		static const int Shutdown = 16;
		static const int Shut = 17;
		static const int Paused = 18;
		static const int Aborted = 19;
		static const IntTypeInfo typeInfo;

	   XferStsInfo():IntValueInfo(-1, typeInfo)
	   {
	   }
	
	   XferStsInfo(int i):IntValueInfo(i, typeInfo)
	    {
	    }
	
	   XferStsInfo(std::string s):IntValueInfo(s, typeInfo)
	    {
	    }
};


#endif/*XFERSTSINFO_H_*/
