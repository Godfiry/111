/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					Jan 22, 2008  shenql  create 
**      
***************************************************************************/
#ifndef XFERANMINFO_H_
#define XFERANMINFO_H_
#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class XferAnmInfo : public IntValueInfo
{
public:

		static const int UnInit = -1;
		static const int Init = 0;
		static const int PreChming = 1;
		static const int PreChmbed = 2;
		static const int Moving = 3;
		static const int Moved = 4;
		static const int Mapping = 5;
		static const int Mapped = 6;
		static const int Starting = 7;
		static const int Started = 8;
		static const int Ending = 9;
		static const int Ended = 10;
		static const IntTypeInfo typeInfo;

	   XferAnmInfo():IntValueInfo(-1, typeInfo)
	   {
	   }
	
	   XferAnmInfo(int i):IntValueInfo(i, typeInfo)
	    {
	    }
	
	   XferAnmInfo(std::string s):IntValueInfo(s, typeInfo)
	    {
	    }
};


#endif/*XFERANMINFO_H_*/
