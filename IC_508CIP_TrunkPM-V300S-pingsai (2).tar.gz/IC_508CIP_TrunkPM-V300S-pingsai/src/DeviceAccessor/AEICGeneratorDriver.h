/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AEICGeneratorDriver.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2015-4   gaozl create
**      
*********************************************************************/
#ifndef AEICGENERATORDRIVER_H_
#define AEICGENERATORDRIVER_H_
#include "SerialDevice.h"
#include "DeviceNode.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class AEICGeneratorDriver : public SerialDevice
{
    DECLARE_DYNAMIC(AEICGeneratorDriver)	
    DECLARE_MSG_MAP

private:
    typedef struct
	 {
		int m_type;
		unsigned char m_cmd;  //changed by wzd 1.1.39
		int m_relen;
	 }Com;
	 static Com m_commands[];	 
    static const int RESP_LEN = 10;
    static const int MESS_LEN = 10;
    double m_multi;
    //add by wz
    double m_rampupw;
    double m_rampdownw;
    double m_rampuptime;
    double m_rampdowntime;

    char message[MESS_LEN];
    char resp[RESP_LEN];
    char ack[1];
    bool sendCommand(char *msg,char *response, int l_msg_timeout,int length);
    bool sendCommandAck(char *msg, char *response, int msg_timeout,int resplen, int msglen);
    bool readCommand(char *msg, char *response, int msg_timeout,int resplen, int msglen);
		 
public:
    AEICGeneratorDriver();
    virtual ~AEICGeneratorDriver();
    void init();
    void InitChannels(DeviceNode<AEICGeneratorDriver> *node);   
    bool writeInt(int channel,int value,const IntTypeInfo& typeinfo);
    bool writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo);
    bool readInt(int channel,int *value,const IntTypeInfo& typeinfo);
    bool readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo);		
    void setHaloMultiple(double multi);			
};
#endif /*AEICGENERATORDRIVER_H_*/
