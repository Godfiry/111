/*
 * N2BallastStripChamber.h
 *
 *  Created on: 2022-10-03
 *      Author: liusiyuan
 */

#ifndef _N2BALLASTSTRIPCHAMBER_H_
#define _N2BALLASTSTRIPCHAMBER_H_

#include "N2BallastChamber.h"

class N2BallastStripChamber :public N2BallastChamber{


    DECLARE_DYNAMIC(N2BallastStripChamber)
    DECLARE_MSG_MAP

public:
    N2BallastStripChamber();
    virtual ~N2BallastStripChamber();

    virtual void doPostExecuteRecipe(GassesToFlow *pGassesToFlow);//added by liusy[1.1.43]
    virtual void doPreExecuteRecipe();//added by liusy[1.1.43]
    virtual void doCompleteTransferMaterial(int status, int slot);
};

#endif /* _N2BALLASTSTRIPCHAMBER_H_ */
