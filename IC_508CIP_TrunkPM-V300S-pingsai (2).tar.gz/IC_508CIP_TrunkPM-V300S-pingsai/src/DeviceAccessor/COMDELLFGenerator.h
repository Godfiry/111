/********************************************************************
** Copyright (c) 2017, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: COMDELLFGenerator.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2017-3-9   mujy create
**      
*********************************************************************/
#ifndef COMDELLFGENERATOR_H_
#define COMDELLFGENERATOR_H_

#include "IODevice.h"
#include "DeviceNode.h"
#include "DeviceManager.h"
#include "ConfigException.h"
#include "ReadWriteInt.h"

#include "DoubleTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif
//using namespace std;
class COMDELLFGenerator:public IODevice
{
	DECLARE_DYNAMIC(COMDELLFGenerator)	
	DECLARE_MSG_MAP		
	public:
		COMDELLFGenerator();
		virtual ~COMDELLFGenerator();

	
	public://for config					
		virtual void init();
		bool setMaxLFPower(double value);

	public:		
		bool writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo);
		bool readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo);
		bool writeInt(int channelNum, int value, const IntTypeInfo &typeInfo);	
		bool readInt(int channelNum, int* value, const IntTypeInfo &typeInfo);	
	private:
		double m_dMaxLFPower;
		char m_pBufferSave[5];
		int m_nStatus;
};
#endif /*COMDELLFGENERATOR_H_*/
