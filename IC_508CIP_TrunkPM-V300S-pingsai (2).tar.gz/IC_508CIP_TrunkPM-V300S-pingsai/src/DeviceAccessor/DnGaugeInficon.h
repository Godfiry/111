/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: DnGaugeInficon.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2018-8-12   Duwenbin create
**      
*********************************************************************/
#ifndef DnGaugeInficon_H_
#define DnGaugeInficon_H_

#include "IODevice.h"
#include "DeviceNode.h"
#include "DeviceManager.h"
#include "ConfigException.h"
//#include "DNSS5136.h"

#include "DoubleTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

using namespace std;

class DnGaugeInficon:public IODevice
{
	DECLARE_DYNAMIC(DnGaugeInficon)	
	DECLARE_MSG_MAP	
	private:
		typedef struct
		{
			int m_datasize;
			int m_service;
			int m_class;
			int m_instance;
			int m_attribute;
		}Com;
		
		static Com m_commands[];
		
	protected:
		void initChs(DeviceNode<DnGaugeInficon> *node);
	
	public:
		DnGaugeInficon();
		virtual ~DnGaugeInficon();
		
		virtual void init();
		bool readPressure(int channelNum, double *value, const DoubleTypeInfo &typeInfo);
		bool writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo);
};

#endif /*DnGaugeInficon_H_*/
