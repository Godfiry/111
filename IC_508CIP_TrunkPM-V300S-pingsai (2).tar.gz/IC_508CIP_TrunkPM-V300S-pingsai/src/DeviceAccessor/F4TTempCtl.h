/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: F4TTempCtl.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2016-02-26   gaozl created
**      
*********************************************************************/
#ifndef F4TTEMPCTL_H_
#define F4TTEMPCTL_H_

#include "DeviceNode.h"
#include "SerialDevice.h"
#include "MonitorDoubleValue.h" //added by zpf 20250602 for TempCtl Protect CIP
#ifdef IAP4_0
using namespace IAP::IO;
#endif



#define MONITORDOUBLEVALUEADDMAP 200//added by zpf 20250618 for TempCtl Protect CIP

class F4TTempCtl : public SerialDevice,public CMonitorDoubleValue
{
	DECLARE_DYNAMIC(F4TTempCtl)	
	DECLARE_MSG_MAP
	
private:
	static const int MAX_MESSAGE_LEN = 20;
	static const int MIN_RECEIVEMSG_LEN = 20;
	static const unsigned char auchCRCHi[256];//buff for CRC High byte
	static const unsigned char auchCRCLo[256];//buff for CRC Low byte
	static const unsigned char regReadAddress[16]; // Register of read address
	static const unsigned char regWriteAddress[24];// Register of Write address
	unsigned char unm_writeCmd[13];	//write command array	
	char m_writeCmd[13];	//write command array	
	char m_readCmd[8];   //read command array
	
	static const int RESP_LEN = 80;//the buff length
	//calculate the CRC and get it
	unsigned short CRC16(char * puchMsg, unsigned short usDataLen );
	unsigned short GetCRCCode(char *cCommand, int nLen);
	

protected:

	void initChs(DeviceNode<F4TTempCtl> *node);//init channel
	void initDevice();
	
public:
	F4TTempCtl();
	virtual ~F4TTempCtl();
	void init();  //init the device 

	bool writeInt(int channnelNum,int setpt ,const IntTypeInfo& typeinfo);
	bool writeDouble(int channnelNum,double setpt ,const DoubleTypeInfo& typeinfo);
	bool readDouble(int channnelNum,double * value ,const DoubleTypeInfo& typeinfo);
	float Hex_To_Decimal(unsigned char *Byte,int num);    //hex to decimal
	void FloatToByte(float floatNum,unsigned char* byteArry);//float to byte
};

#endif /*F4TTEMPCTL_H_*/
