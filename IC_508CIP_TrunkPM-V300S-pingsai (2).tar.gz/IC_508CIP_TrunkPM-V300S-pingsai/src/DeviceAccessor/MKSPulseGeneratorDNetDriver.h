/********************************************************************
** Copyright (c) 2018, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MKSPulseGeneratorDNetDriver.h
** Description:SuperNova Flexible DeviceNet Profile
*             Use Polled I/O
* 				Default instance is 104,105 (16 by 47's Polled Request Data)
* Instance 104 Poll request packets
* ----------------------------------------------------------------------------------------------------------------
* Byte   |  Bit7    | Bit6     | Bit5    | Bit4    | Bit3    | Bit2   | Bit1    | Bit0
* -----------------------------------------------------------------------------------------------------------------
* 0   Pulse High/State1/Continuous Wave(CW) Setpoint(low byte)
* 1   Pulse High/State1/Continuous Wave(CW) Setpoint(high byte)
* 2   Pulse Low/State2 Setpoint(low byte)
* 3   Pulse Low/State2 Setpoint(high byte)
* 4   Pulse Frequency (low byte)
* 5   Pulse Frequency (high byte)
* 6   Pulse Duty Cycle(High/Low Pulsing)(low byte)
* 7   Pulse Duty Cycle(High/Low Pulsing)(high byte)
* 8   Pulse Delay from Edge(low byte)
* 9   Pulse Delay from Edge(middle low byte)
* 10  Pulse Delay from Edge(middle high byte)
* 11  Pulse Delay from Edge(high byte)
* -----------------------------------------------------------------------------------------------------------------------
* 12     | Reset    | 0        |         |         |      0 |  LevelModeSelection | PowerOn
*        | Faults	   |	
* -------------------------------------------------------------------------------------------------------------------------
* 13     |    0     |  0       |       0 |       0 |       0|     0     | PulseMode Selection 
* --------------------------------------------------------------------------------------------------------------------------     
* 14
* 15
* -------------------------------------------------------------------------------------------------------------------------
* Instance 105 Poll response packets
* ----------------------------------------------------------------------------------------------------------------
* Byte   |  Bit7    | Bit6     | Bit5    | Bit4    | Bit3    | Bit2   | Bit1    | Bit0
* -----------------------------------------------------------------------------------------------------------------
* 0   Pulse High/State1/Continuous Wave(CW) Forward Power Readback(low byte)
* 1   Pulse High/State1/Continuous Wave(CW) Forward Power Readback(high byte)
* 2   Pulse High/State1/Continuous Wave(CW) Reverse Power Readback(low byte)
* 3   Pulse High/State1/Continuous Wave(CW) Reverse Power Readback(high byte)
* 4   Pulse Low/State2 Forward Power Readback(low byte)
* 5   Pulse Low/State2 Forward Power Readback(high byte)
* 6   Pulse Low/State2 Reverse Power Readback(low byte)
* 7   Pulse Low/State2 Reverse Power Readback(high byte)
* 8   Actual RF Frequency Pulse High/State1/CW (low byte)
* 9   Actual RF Frequency Pulse High/State1/CW (middle low byte)
* 10  Actual RF Frequency Pulse High/State1/CW (middle high byte)
* 11  Actual RF Frequency Pulse High/State1/CW (high byte)
* 12  Actual RF Frequency Pulse Low/State2 (low byte)
* 13  Actual RF Frequency Pulse Low/State2 (middle low byte)
* 14  Actual RF Frequency Pulse Low/State2 (middle high byte)
* 15  Actual RF Frequency Pulse Low/State2 (high byte)
* .......
* 32  Actual Pulse Frequency(low byte)
* 33  Actual Pulse Frequency(high byte)
* 34  Acutal Pulse Duty Cycle(High/Low Pulsing)(low byte)
* 35  Acutal Pulse Duty Cycle(High/Low Pulsing)(high byte)
* ......
* ---------------------------------------------------------------------------------------------------------------------------------------
* 42      |  0     |WarnStatus|Fault Status|ILock Status|   0  |TempStatus|SetptStatus|PowerOnStatus
* 43      |     0  |   0      |     0      |     0      |   0  |    0     |  Level Mode Selection Status  
* 44      |     0  |   0      |     0      |     0      |   0  |    0     |  Pulse Mode Selection Status 
* ......
* -----------------------------------------------------------------------------------------------------------------------------------------
*Notes 
*1)For Power: 4095 represent 100% of full scale
*2)PulseFrequency: Range(1 HZ):0x0000-0xFFFF,representing a value from 0~65535HZ
*3)DutyCycle:Range(0.1%):0x0000-0x03E8
*4)Pulse Mode Select or Pulse Mode Status
* 			Bit 1 /Bit 0
* 			00 = Pulsing Disabled / CW
* 			01 = Pulsing On -- Internal(Master)
*5)Level Mode Select or Level Mode Status
*  			Bit 1/Bit 0
* 			00 = Forward Leveling Mode
* 			01 = Delivered/Load Leveling Mode
*6)PowerOn: 0 = RF Off; 1 = RF On
** Release: 1.1
** Modification history: 
** 					2018-9-6   mujy create
**      
*********************************************************************/
#ifndef MKSPULSEGENERATORDNETDRIVER_H_
#define MKSPULSEGENERATORDNETDRIVER_H_

#include "IODevice.h"
#include "DeviceNode.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class MKSPulseGeneratorDNetDriver : public IODevice
{
    DECLARE_DYNAMIC(MKSPulseGeneratorDNetDriver)	
    DECLARE_MSG_MAP

public:
 	MKSPulseGeneratorDNetDriver();
   virtual ~MKSPulseGeneratorDNetDriver(); 
  
public://xml
	void init();

public://read and write function    
	bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
	bool writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo);
	bool writeRawCommand(int nChannelNum, std::string strValue, const StringTypeInfo &typeInfo);
	bool readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);
	bool readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);	
	
protected:
	bool sendCommand(std::string strCommand, int nTimeOut);
	std::string readCommand(std::string strCommand, int nTimeOut);	
	void InitChannels(DeviceNode<MKSPulseGeneratorDNetDriver> *pNode);   
	void initDevice();	

private:
	typedef struct
	{
		int m_nByte;
		int m_nBit;
	}Com; 
	int m_nLastLevelMode;//0:forward leveling;1:load leveling
	int m_nLastPulseMode;//0:CW Mode;1:Pulse Mode
	int m_nLastRFOnOffControl;//0:Off;1:On
	static Com m_Commands[];	
	char *m_pWriteBuffer;
	char *m_pReadBuffer;
};
#endif /*MKSPULSEGENERATORDNETDRIVER_H_*/
