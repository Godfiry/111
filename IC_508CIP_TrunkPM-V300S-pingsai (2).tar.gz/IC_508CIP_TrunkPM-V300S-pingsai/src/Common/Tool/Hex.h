#ifndef HEX_H_
#define HEX_H_
#include <string>
#include <vector>

using namespace std;

class Hex
{
public:
	struct HexArray
	{
		int nLength;
		char * pData;
	};
public:
	//GetHexString("abc",3) -> 0x61 0x62 0x63 ;
	static string GetHexString(const char * pData,int nLength);
	//eg:pData="abcdefgdefg"   pSeparator="*&"
	//separat by '*' or '&'!
	//"ab*&efg&efg"->"ab" "efg" "efg"
	static vector<Hex::HexArray> splitBySet(char* pData,int nDataLength,const char * pSeparator,int nSeparatorNum);
	//eg:pData="abcdefgdefg"   pSeparator="*&"
	//separat by "*&"!
	//"ab*&efg&efg"->"ab" "efg&efg"
	static vector<Hex::HexArray> splitByList(char* pData,int nDataLength,const char * pSeparator,int nSeparatorNum);

	static bool stringToHex(int *res, const std::string &s);
	static void stringToHexChar(const std::string& strHexString, char* charArray, size_t nArraySize);//added by wangyk 20251225 [v1.8.1] for MotorPin DongfangMada
	//hexToString(123)->"7b"
	//hexToString(-123)->not support
	static std::string hexToString(int value);
	//hexToString(123,1)->"7b"
	//hexToString(123,4)->"007b"
	//hexToString(-123,1)->not support
	static std::string hexToString(int value,int length);
	
	static std::string hexToAscii( std::string &hex);
	static std::string asciiToHex( std::string &str);
	static std::string intToHex(int i);
	static int hexToInt( std::string &hex);

	//eg:'a' -> 10
	static bool charToHex(int *pResult, const char ch);//lvjw
	//hexToStringFixWidth(0x00)->"00"
	//hexToStringFixWidth(0x0b)->"0b"
	//hexToStringFixWidth(0xff)->"ff"
	static std::string hexToStringFixWidth(unsigned char value);//mayc
};

#endif /*HEX_H_*/
