/*
 * EnergyLeakingBottle.cpp
 *
 *  Created on: 2021-11-17
 *      Author: lvjiawen
 */

#include "EnergyLeakingBottle.h"

EnergyLeakingBottle::EnergyLeakingBottle()
{
    m_nEnergy = 0;
    m_nCapcity = 0;

    m_pMutex=new IMutex(true);

    m_pEmptyListener = NULL;

    m_pTimer = new TimerEx();
    m_pTimer->setTicker(this);
    m_pTimer->setDuration(100);//100ms
    m_pTimer->start();
}

EnergyLeakingBottle::EnergyLeakingBottle(const EnergyLeakingBottle& pObj)
{
    m_nEnergy = pObj.m_nEnergy;
    m_nCapcity = pObj.m_nCapcity;

    m_pMutex = new IMutex(true);

    m_pEmptyListener = pObj.m_pEmptyListener;

    m_pTimer = new TimerEx();
    m_pTimer->setTicker(this);
    m_pTimer->setDuration(100);//100ms
    m_pTimer->start();
}

EnergyLeakingBottle& EnergyLeakingBottle::operator=(const EnergyLeakingBottle& pObj)
{
    if (this != &pObj)
    {
        m_nEnergy = pObj.m_nEnergy;
        m_nCapcity = pObj.m_nCapcity;

        m_pMutex = new IMutex(true);

        m_pEmptyListener = pObj.m_pEmptyListener;

        m_pTimer = new TimerEx();
        m_pTimer->setTicker(this);
        m_pTimer->setDuration(100);//100ms
        m_pTimer->start();
    }
    return *this;
}

EnergyLeakingBottle::~EnergyLeakingBottle()
{
    m_pTimer->stop();
    #ifndef IAP4_0
    delete m_pTimer;
    m_pTimer = NULL;
    #endif


    delete m_pMutex;
    m_pMutex=NULL;
}

void EnergyLeakingBottle::flush()
{
    IMutexLocker locker(m_pMutex);
    m_nEnergy = 0;
}

void EnergyLeakingBottle::fillUp()
{
    Log_Info("EnergyLeakingBottle fillUp.");
    IMutexLocker locker(m_pMutex);
    m_nEnergy = m_nCapcity;
}

bool EnergyLeakingBottle::isEmpty()
{
    IMutexLocker locker(m_pMutex);
    if(m_nEnergy == 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}

void EnergyLeakingBottle::updateFromTimer(TimerEx * pSender)
{
    leaking();
}

void EnergyLeakingBottle::leaking()
{
    IMutexLocker locker(m_pMutex);
    if(m_nEnergy>0)
    {
        m_nEnergy-=100;
        if(m_nEnergy <= 0)
        {
            m_nEnergy = 0;
            onEmpty();
        }
        //Log_Info("EnergyLeakingBottle energyleft %d",m_nEnergy);//test msg
    }
}

void EnergyLeakingBottle::onEmpty()
{
    Log_Info("EnergyLeakingBottle Empty!");
    if(m_pEmptyListener)
    {
        m_pEmptyListener->onEnergyLeakingBottleEmpty();
    }
}

void EnergyLeakingBottle::setCapacity_ms(int nCapcity)
{
    m_nCapcity=nCapcity;
}

void EnergyLeakingBottle::setCapacity_s(int nCapcity)
{
    m_nCapcity=nCapcity*1000;
}

void EnergyLeakingBottle::setCapacity_min(int nCapcity)
{
    m_nCapcity=nCapcity*1000*60;
}

void EnergyLeakingBottle::setEmptyListener(IEnergyLeakingBottleEmptyListener *pEmptyListener)
{
    m_pEmptyListener=pEmptyListener;
}
