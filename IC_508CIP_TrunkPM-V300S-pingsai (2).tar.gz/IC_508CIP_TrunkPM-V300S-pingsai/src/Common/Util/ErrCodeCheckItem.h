/********************************************************************
** Copyright (c) 2009, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: ErrCodeCheckItem.h
** Description:  
** Release: 1.0
** Modification history: 
* 					2009-9-28   LiJuanjuan create
** 					2019-06-10 liuxj create, for parse Error code
*********************************************************************/
#ifndef ERRCODECHECKITEM_H_
#define ERRCODECHECKITEM_H_

#include "NonBlockingAlarm.h"
#include "NonBlockingAlarmEX.h"//added by mujy for Chinesization[v1.6.0]
#include "CheckItem.h"//[liuxj v1.0.25]
#include "ReadOnlyString.h"//[liuxj 1.0.25],for setMessageInfo function;
#include "ErrorCodeParserInterface.h"//[liuxj v1.0.25], for Error code parse;
#include <vector>
#ifdef IAP4_0
using namespace IAP::ALARM;
using namespace IAP::IO;
#endif

class ErrCodeCheckItem:public CheckItem
{
	DECLARE_DYNAMIC(ErrCodeCheckItem)
	DECLARE_MSG_MAP
		
	public:
		ErrCodeCheckItem();
		virtual ~ErrCodeCheckItem();

	public://.xml config
		void setAlarmDescriptionCh(const std::string &strPath);//[liuxj v1.0.25]
		void setErrorCodeParser(const std::string &strPath);//added by [liuxj v1.0.25]	
		
	protected:	//override
		virtual bool doCheck();		
		virtual void make();
		
	private:
		std::string getDeviceErr(std::string strErrMsg);//added by [liuxj v1.0.25], call ErrorCodeParser to abtain ErrorCode Message information. 
		
	private:
		Alarm *m_pAlarmMessageGetFailedAlarm;//modified by mujy for Chinesization[v1.1.0]
		ReadOnlyString *m_pAlarmDescription;//added by [liuxj 1.0.25]
		ErrorCodeParserInterface * m_pErrorCodeParser;//added by [liuxj v1.0.25]
};

#endif /*ERRCODECHECKITEM_H_*/
