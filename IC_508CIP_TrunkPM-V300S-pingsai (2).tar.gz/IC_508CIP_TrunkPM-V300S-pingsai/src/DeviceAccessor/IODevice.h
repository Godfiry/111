/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: IODevice.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2007-9-22   LiJuanjuan create
**      
*********************************************************************/
#ifndef IODEVICE_H_
#define IODEVICE_H_

#include "AbstractDevice.h"
#include "DeviceNode.h"
#include "DeviceNet.h"
#include "IntTypeInfo.h"
#include "DoubleTypeInfo.h"
#include <vector>
#include "MathTool.h"
#include "DefineValue.h"
#include "CommunicationStatusEnum.h"
#include "Hex.h"
#include "DriverHelper.h"//added by mujy [1.5.0] for IODeviceBaseClass
#ifdef IAP4_0
using namespace IAP::IO;
#endif
#include "ReadWriteString.h"


class IODevice:public AbstractDevice
{
	DECLARE_DYNAMIC(IODevice)
	DECLARE_MSG_MAP

	public://xml
		//void setFullScale(double nFullScale);//added by mujy [v1.0.8]
		void setValuePerUnit(double mTorrRatio);//added by taohao [1.1.30]

	protected:
		int m_macID;
		int m_nodeNum;
		std::string m_deviceName;		
		int m_DIChsSize;
		int m_DOChsSize;
		int m_AIChsSize;
		int m_AOChsSize;
		char *m_buffer;	
		static DeviceNet *m_deviceNet;
		int m_pollInterval;
		int m_baudRate;
		int m_connectStatus;
		int m_pollStatusInterval;
		int m_currentCycle;
		std::string m_fwdir;
		std::vector<int> m_enableChs;
		std::map<int, int> m_aiFilter; //[added by wangyk 1.2.4]
		
		virtual void initChs(DeviceNode<IODevice> *node);
		virtual void initDevice();
		void initDeviceNet();
		
	public:
		
		IODevice();
		virtual ~IODevice();
		
		void setMacID(int macId);
		void setNodeNum(int nodeNum);
		void setOutEnableCh(int channelNum);
		void setDIChsSize(int num);
		void setDOChsSize(int num);
		void setAIChsSize(int num);
		void setAOChsSize(int num);
		void setDeviceName(const std::string &name);
		void setPollInterval(int ms);
		void setBaudRate(int baudRate);
		void setFWdir(const std::string &dir);
		void setStatusPollInterval(int cycle);
		void addAIFilterParam(int channelNum, int nAIFilterValue);//[added by wangyk 1.2.4]
		virtual void init();
				
		virtual bool readBit(int channelNum, int *bit, const IntTypeInfo &typeInfo);
		virtual bool writeBit(int channelNum, int bit, const IntTypeInfo &typeInfo);
		virtual bool readAnalog(int channelNum, double *bit, const DoubleTypeInfo &typeInfo);
		virtual bool writeAnalog(int channelNum, double bit, const DoubleTypeInfo &typeInfo);
		
		static double realToDouble(long value);
		static unsigned long doubleToReal(double value);

		virtual bool getStatus(int nChannelNum, int *pBit, const IntTypeInfo &typeInfo);//added by mujy [v1.0.8]
		virtual void setFullScale(const std::string &strPath);//zhangyy add for gas CIP
	protected:
		double m_dFullScale;//added by mujy [v1.0.8]
		double m_dmTorrRatio;//added by taohao [1.1.30]
};

#endif /*IODEVICE_H_*/
