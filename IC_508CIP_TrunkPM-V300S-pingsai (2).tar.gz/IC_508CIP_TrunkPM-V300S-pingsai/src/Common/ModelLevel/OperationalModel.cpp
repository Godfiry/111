#include "OperationalModel.h"
#include "ModuleStatusEnum.h"
#include "AlarmReNameManager.h"

OperationalModel::OperationalModel()
{
	m_pServiceFailedAlarm = NULL;
	m_pErrorDescription = NULL;
	m_pServiceName = NULL;

	m_Init=new Init();
	m_Init->setOwner(this);
	
	m_SetMaintMode=new SetMaintMode();
	m_SetMaintMode->setOwner(this);
	
	m_SetOpMode=new SetOpMode();
	m_SetOpMode->setOwner(this);
	
	m_Shutdown=new Shutdown();
	m_Shutdown->setOwner(this);
	
	m_bOverrideActionRecovery = false;
	
	m_pFunctionalModel = NULL;

	m_pFuncModelBusyAlarm = NULL;

	m_bNeedtomakeLearnRcp = false;//added by liusy[1.1.52]
	m_bProcessAutoLearnEnable = true;
	m_bDryCleanAutoLearnEnable = true;
}

OperationalModel::~OperationalModel()
{
}

bool OperationalModel::OverrideAction::execute(const Alarm *pAlarm, Recovery *pRecovery)
{
	if(NULL != m_pOwner)
	{
		m_pOwner->m_bOverrideActionRecovery = true;
	}
   	return true;
}

void OperationalModel::OverrideAction::setOwner(OperationalModel *pModel)
{
	m_pOwner = pModel;
}

void OperationalModel::initialize()
{
	ControlObject::initialize();
	string strPreName = AlarmReNameManager::getInstance()->GetShowName(getName());
	m_pInvalidModeAlarm = new BlockingAlarm(strPreName + "_InvalidModeAlarm",
												strPreName + " is not in proper mode for this operation.",
												"A client has attempted to run a service when it's status is not in the correct status.",
												Alarm::EVENT);
	OverrideAction *pAction = new OverrideAction();
	pAction->setOwner(this);
	m_pInvalidModeAlarm->addRecovery(new Recovery("Cancel request",Recovery::CONTINUE));
	m_pInvalidModeAlarm->addRecovery(new Recovery("Override and Continue",Recovery::CONTINUE,pAction));
	
	m_pErrorDescription = new ReadWriteString(getName() + "/ErrorMsg");
	m_pServiceName = new ReadWriteString(getName() + "/ServiceName");

	m_pServiceFailedAlarm = new NonBlockingAlarm(strPreName + "_RunServiceFailed", "Run service [ <"+ m_pServiceName->getName() +"> ] failed.", "Run service failed: <" + m_pErrorDescription->getName() + ">", Alarm::ERROR);
	m_pServiceFailedAlarm->addRecovery(new Recovery("Clear", Recovery::CLEAR));

	m_pFuncModelBusyAlarm = new NonBlockingAlarm(strPreName + "_ChamberBusy", "Cannot do action.", "Chamber is busy, please check whether the chamber is performing service at Chamber page UI.", Alarm::ERROR);
	m_pFuncModelBusyAlarm->addRecovery(new Recovery("Clear", Recovery::CLEAR));
}

//maxm added for samplify MODULE_STATUS  maintian[v1.0.12]
void OperationalModel::defaultAbort()
{
	Log_Info(getName()+": defaultAbort start");
	m_pFunctionalModel->setStatusValue(MODULE_STATUS::NotReady);//NotReady
	Log_Info(getName()+": defaultAbort end");
}

bool OperationalModel::checkModeByWhiteListAndPostAlm(std::list<int> whiteList)
{
	int nMode=m_pFunctionalModel->getStatusValue();
	std::list<int>::iterator it;
	for(it=whiteList.begin();it!=whiteList.end();++it)
	{
		if(nMode==(*it))
		{
			return true;
		}
	}
	Log_Error("checkModeByWhiteListAndPostAlm---invalid Mode");
	m_pInvalidModeAlarm->post(this);
	if(m_bOverrideActionRecovery)
	{
		m_bOverrideActionRecovery = false;
		return true;
	}
	return false;
}

bool OperationalModel::checkModeByBlackListAndPostAlm(std::list<int> blackList)
{
	int nMode=m_pFunctionalModel->getStatusValue();
	std::list<int>::iterator it;
	for(it=blackList.begin();it!=blackList.end();++it)
	{
		if(nMode==(*it))
		{
			Log_Error("checkModeByBlackListAndPostAlm---invalid Mode");
			m_pInvalidModeAlarm->post(this);
			if(m_bOverrideActionRecovery)
			{
				m_bOverrideActionRecovery = false;
				return false;
			}
			return true;
		}
	}
	return false;
}

bool OperationalModel::checkMode_JobService()//for subclass use
{
	if(m_pFunctionalModel->getState() == 1/*ControlState::RUNNING*/ || m_pFunctionalModel->getState() == 2/*ControlState::ALMPAUSE*/ || m_pFunctionalModel->getState() == 4/*ControlState::ABORTING*/)
	{
		Log_Error("checkMode_JobService() functional model control state is " + m_pFunctionalModel->getStateAsString());
		m_pFuncModelBusyAlarm->post(this);
		return false;
	}
	std::list<int> whiteList;
	whiteList.push_back(MODULE_STATUS::Standby);
	whiteList.push_back(MODULE_STATUS::CTCInUse);
	whiteList.push_back(MODULE_STATUS::MaintMode);
	return checkModeByWhiteListAndPostAlm(whiteList);
}

bool OperationalModel::checkMode_JobService(AlarmPoster *pPoster)//for other class use
{
	if(m_pFunctionalModel->getState() == 1/*ControlState::RUNNING*/ || m_pFunctionalModel->getState() == 2/*ControlState::ALMPAUSE*/ || m_pFunctionalModel->getState() == 4/*ControlState::ABORTING*/)
	{
		Log_Error("checkMode_JobService(poster)222 functional model control state is " + m_pFunctionalModel->getStateAsString());
		m_pFuncModelBusyAlarm->post(this);
		return false;
	}
	std::list<int> whiteList;
	whiteList.push_back(MODULE_STATUS::Standby);
	whiteList.push_back(MODULE_STATUS::CTCInUse);
	whiteList.push_back(MODULE_STATUS::MaintMode);

	int nMode=m_pFunctionalModel->getStatusValue();
	std::list<int>::iterator it;
	for(it=whiteList.begin();it!=whiteList.end();++it)
	{
		if(nMode==(*it))
		{
			return true;
		}
	}
	Log_Error("checkModeByWhiteListAndPostAlm---invalid Mode");
	m_pInvalidModeAlarm->post(pPoster);
	if(m_bOverrideActionRecovery)
	{
		m_bOverrideActionRecovery = false;
		return true;
	}
	return false;
}

int OperationalModel::getModuleStatus()
{
	return m_pFunctionalModel->getStatusValue();
}

void OperationalModel::changeModuleStatus(int nMode)
{
	m_pFunctionalModel->setStatusValue( nMode);
}

void OperationalModel::setFunctionalModel(std::string &strPath)
{
	ManagedObject *p = NULL;

	try
	{
		p = ObjectManager::getInstance()->getObject(strPath);	
	}
	catch (const InvalidNameException &e)
	{
		p = ObjectManager::getInstance()->getObject(this, strPath);
	}
	m_pFunctionalModel = dynamic_cast<FunctionalModel*>(p);
	if (m_pFunctionalModel == NULL)
	{
		throw ConfigException("The object under path " + strPath + " is not the class expected.");
	}
	
}

void OperationalModel::call_Init()
{
	call(m_Init);
}

void OperationalModel::call_SetMaintMode()
{
	call(m_SetMaintMode);
}

void OperationalModel::call_SetOpMode(int nMode, bool override)
{
	m_SetOpMode->setParamValue("mode",nMode);
	m_SetOpMode->setParamValue("override",override);
	call(m_SetOpMode);
}

void OperationalModel::call_Shutdown()
{
	call(m_Shutdown);
}

void OperationalModel::do_Init()
{
	std::list<int> blackList;
	blackList.push_back(MODULE_STATUS::CTCInUse);
	if(!checkModeByBlackListAndPostAlm(blackList))
	{
		try
		{
			m_pFunctionalModel->call_Init();
		}
		catch(const RetryException &retryException)
		{
			throw;
		}
		catch(const InterruptException &interruptException)
		{
			Log_Error(getName()+" do init catch InterruptException - "+string(interruptException.what()));
			m_pServiceName->setValue("Initialize");
			m_pErrorDescription->setValue("Manual Abort");
			m_pServiceFailedAlarm->post(this);
			throw;
		}
		catch(const exception &ex)
		{
			Log_Error(getName() + " do init caught exception - " + string(ex.what()));
			m_pServiceName->setValue("Initialize");
			m_pErrorDescription->setValue(ex.what());
			if(!m_pServiceFailedAlarm->isPosted() && string(ex.what()).find("executed recovery 'ABORT'") == string::npos)
			{
				m_pServiceFailedAlarm->post(this);
			}
			throw;
		}
	}
}

void OperationalModel::do_SetMaintMode()
{
	std::list<int> whiteList;
	whiteList.push_back(MODULE_STATUS::Standby);
	whiteList.push_back(MODULE_STATUS::MaintMode);
	if(checkModeByWhiteListAndPostAlm(whiteList))
	{
		m_pFunctionalModel->setStatusValue(MODULE_STATUS::MaintMode);
	}
}

void OperationalModel::do_SetOpMode(int nMode, bool override)
{
	if(nMode == MODULE_STATUS::MaintMode && m_pFunctionalModel->getStatusValue() == MODULE_STATUS::CTCInUse)
	{
		Log_Error(getName()+" Set OpMode to MaintMode when Mode is CTCInUse");
		m_pInvalidModeAlarm->post(this);
		if(m_bOverrideActionRecovery)
		{
			m_bOverrideActionRecovery = false;
			m_pFunctionalModel->setStatusValue(MODULE_STATUS::MaintMode);
		}
	}
	else
	{
		if(!m_pFunctionalModel->checkStatusEqual(nMode))
		{
			m_pFunctionalModel->setStatusValue(nMode);
		}
	}
}

void OperationalModel::do_Shutdown()
{
	std::list<int> blackList;
	blackList.push_back(MODULE_STATUS::CTCInUse);
	if(!checkModeByBlackListAndPostAlm(blackList))
	{
		try
		{
			m_pFunctionalModel->setStatusValue(MODULE_STATUS::NotReady);
			m_pFunctionalModel->call_Shutdown();
		}
		catch(const RetryException &retryException)
		{
			throw;
		}
		catch(const InterruptException &interruptException)
		{
			Log_Error(getName()+" do Shutdown catch InterruptException - "+string(interruptException.what()));
			m_pServiceName->setValue("Shutdown");
			m_pErrorDescription->setValue("Manual Abort");
			m_pServiceFailedAlarm->post(this);
			throw;
		}
		catch(const exception &ex)
		{
			Log_Error(getName() + " do Shutdown caught exception - " + string(ex.what()));
			m_pServiceName->setValue("Shutdown");
			m_pErrorDescription->setValue(ex.what());
			if(!m_pServiceFailedAlarm->isPosted() && string(ex.what()).find("executed recovery 'ABORT'") == string::npos)
			{
				m_pServiceFailedAlarm->post(this);
			}
			throw;
		}
	}
}

void OperationalModel::Init::execute()
{
	OperationalModel *pOwner = dynamic_cast<OperationalModel*>(getOwner());
	if(pOwner != NULL)
	{
		Log_Info(pOwner->getName()+": do_Init start");
		pOwner->do_Init();	
		Log_Info(pOwner->getName()+": do_Init end");
	}
}

void OperationalModel::SetMaintMode::execute()
{
	OperationalModel *pOwner = dynamic_cast<OperationalModel*>(getOwner());
	if(pOwner != NULL)
	{
		Log_Info(pOwner->getName()+": do_SetMaintMode start");
		pOwner->do_SetMaintMode();
		Log_Info(pOwner->getName()+": do_SetMaintMode end");
	}
}

void OperationalModel::SetOpMode::execute()
{
	OperationalModel *pOwner = dynamic_cast<OperationalModel*>(getOwner());
	if(pOwner != NULL)
	{
		int nMode = Params["mode"].Int;
		bool override = Params["override"].Bool;
		
		Log_Info(pOwner->getName()+": do_SetOpMode start - nMode = "+Converter::convertToString(nMode));
		
		pOwner->do_SetOpMode(nMode, override);
		
		Log_Info(pOwner->getName()+": do_SetOpMode end");
	}
}

void OperationalModel::Shutdown::execute()
{
	OperationalModel *pOwner = dynamic_cast<OperationalModel*>(getOwner());
	if(pOwner != NULL)
	{
		Log_Info(pOwner->getName()+": do_Shutdown start");
	
		pOwner->do_Shutdown();
		
		Log_Info(pOwner->getName()+": do_Shutdown end");
	}
}
//added by liusy[1.1.52]
bool OperationalModel::ifNeedtomakeLearnRcp()const
{
	return m_bNeedtomakeLearnRcp;
}

bool OperationalModel::ifProcessAutoLearnEnable()const
{
	return m_bProcessAutoLearnEnable;
}

bool OperationalModel::ifDryCleanAutoLearnEnable()const
{
	return m_bDryCleanAutoLearnEnable;
}

void OperationalModel::setMakeLearnRcpEnable(bool choice)
{
	m_bNeedtomakeLearnRcp = choice;
}

IMPLEMENT_DYNAMIC_SERVICE(Init, OperationalModel)
IMPLEMENT_DYNAMIC_SERVICE(SetMaintMode, OperationalModel)
IMPLEMENT_DYNAMIC_SERVICE(SetOpMode, OperationalModel)
IMPLEMENT_DYNAMIC_SERVICE(Shutdown, OperationalModel)

BEGIN_SERVICEINFO_LIST(OperationalModel)

	ADD_SERVICE_INFO(OperationalModel, Init, The Init service )
	
	ADD_SERVICE_INFO(OperationalModel, SetMaintMode, The SetMaintMode service )
		
	ADD_SERVICE_INFO(OperationalModel, SetOpMode, The SetOpMode service )
		ADD_PARAM_INFO(OperationalModel, SetOpMode, mode, int, InfoIsNew:-1 Offline UnInit NotReady Standby CTCInUse MaintPend MaintMode)
		ADD_PARAM_INFO(OperationalModel, SetOpMode, override, bool, If override the mode of OperationalModule)
	ADD_SERVICE_INFO(OperationalModel, Shutdown, The Shutdown service )
		
END_SERVICEINFO_LIST(OperationalModel)

IMPLEMENT_DYNAMIC(OperationalModel, ControlObjectEX)

BEGIN_MSG_MAP( OperationalModel, ControlObjectEX )
	SET_S( setFunctionalModel, OperationalModel )
	SET_B(setMakeLearnRcpEnable, OperationalModel)//added by liusy[1.1.52]
END_MSG_MAP
