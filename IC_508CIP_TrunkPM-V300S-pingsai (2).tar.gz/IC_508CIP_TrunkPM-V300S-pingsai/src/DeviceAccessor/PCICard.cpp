/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: PCICard.cpp
** Description:  
** Release: 1.1
** Modification history: 
**                     2009-12-04   LiJuanjuan create
**      
*********************************************************************/
#include "PCICard.h"
#include "ConfigException.h"
#include "DeviceManager.h"
#include "MathTool.h"
#include "CTCExport.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP;
#endif
    
using namespace std;

PCICard::PCICard()
{
    m_cardNum = 0;
    m_cardType = 0;
    m_cardID = -1;
    m_nodeNum = 0;
    m_pollInterval = 500;
    m_filterInterval = 4;
    m_dcardVoltage = 5.0;//added by taohao[1.1.30]
}

PCICard::~PCICard()
{
    if(!isSimulated())
    {
        Release_Card(m_cardID);
    }
}

bool PCICard::write7432(int channelNum, int value ,const IntTypeInfo& typeinfo)
{  
    I16 err=0;
    err = DO_WriteLine(m_cardID, channelNum < 32 ? 0:P7432R_DO_LED, channelNum < 32 ? channelNum:channelNum-32, value);
    if (err != NoError) 
    {
        throw IOException("write card 7432 failed : " + Converter::convertToString(err));
    }
    return true;
}

bool PCICard::read7432(int channelNum, int *value ,const IntTypeInfo& typeinfo)
{ 
    I16 err=0;
    U16 state=0;
    err = DI_ReadLine(m_cardID, 0, channelNum-32, &state);
    if (err!=NoError)
    {
        throw IOException("read card 7432 failed : " + Converter::convertToString(err));
    }
    *value = state;
    return true;
}

bool PCICard::read7433(int channelNum, int *value ,const IntTypeInfo& typeinfo)
{
    I16 err=0;
    U16 state=0;
    err = DI_ReadLine(m_cardID, channelNum < 32 ? PORT_DI_LOW:PORT_DI_HIGH, channelNum < 32 ? channelNum:channelNum-32, &state);
    if (err!=NoError)
    {
        throw IOException("read card 7433 failed : " + Converter::convertToString(err));
    }
    *value = state;
    return true;
}

bool PCICard::write7434(int channelNum, int value ,const IntTypeInfo& typeinfo)
{
    I16 err=0;
    err = DO_WriteLine(m_cardID, channelNum < 32 ? PORT_DI_LOW:PORT_DI_HIGH, channelNum < 32 ? channelNum:channelNum-32, value);
    if (err!=NoError) 
    {
        throw IOException("write card 7434 failed : " + Converter::convertToString(err));
    }
    return true;
}

bool PCICard::write6208(int channelNum, double value, const DoubleTypeInfo &typeinfo)
{
    F64 DaVoltage;
    I16 err = 0;
    int nMax = typeinfo.getMax(); //added by guojin[1.1.31]

    /*    if( (int)(typeinfo.getMin())==1 && (int)(typeinfo.getMax()) == 9)//??? why?
     {
     DaVoltage = value;
     }
     else*//*removed by lijj 20110511  there is no such data*/
    if (m_mapSpecialChlName.find(channelNum) != m_mapSpecialChlName.end())
    {
        if (m_mapSpecialChlName[channelNum] == "VDMSetPointAO") //added by xiasc[20180321]
        {
            DaVoltage = value * 5.0 / typeinfo.getMax(); //Voltage
        }
    }
    else if (m_ScopeChannels.find(channelNum) != m_ScopeChannels.end())
    {
        nMax = m_ScopeChannels[channelNum].dMax;
        DaVoltage = value * 10.0 / nMax; //added by guojin[1.1.31]
    }
    else
    {
        DaVoltage = value * 10.0 / typeinfo.getMax();
    }

    err = AO_VWriteChannel(m_cardID, channelNum, DaVoltage);

    if (err != NoError)
    {
        throw IOException("write card 6208 failed : " + Converter::convertToString(err));
    }
    return true;
}

bool PCICard::read9116(int channelNum, double* value ,const DoubleTypeInfo& typeinfo)
{
    F64 AdVoltage;
    I16 err=0;
    err = AI_VReadChannel(m_cardID, channelNum, AD_U_10_V, &AdVoltage);
    double dTempValue = 0;
    if (err!=NoError) 
    {
        throw IOException("read card 9116 failed : " + Converter::convertToString(err));
    }
    if( (int)(typeinfo.getMin())== -500 && (int)(typeinfo.getMax()) == 500)
    {
        if(AdVoltage >= 5.0)
        {
            dTempValue=500;
        }
        else 
        {
            dTempValue=AdVoltage * 200 - 500.0;
        }
        *value = MathTool::Round(dTempValue,typeinfo.getAccuracy()); 
    }
    
    else if(m_mapSpecialChlName.find(channelNum) != m_mapSpecialChlName.end())
    {
        if(m_mapSpecialChlName[channelNum] == "VDMFlowSignalOutAI")//added by xiasc[20180321]
        {
            int nMax = typeinfo.getMax();
            int nMin = typeinfo.getMin();
            if(m_ScopeChannels.find(channelNum) != m_ScopeChannels.end())  //added by liusy[1.1.22]
            {
                nMax = m_ScopeChannels[channelNum].dMax;
                nMin = m_ScopeChannels[channelNum].dMin;
            }

            dTempValue = AdVoltage*(nMax - nMin)/5.0 + nMin;
            if(dTempValue < 15)//filter noise
            {
                 *value = 0; 
            }
            else
            {
                *value = MathTool::Round(dTempValue,typeinfo.getAccuracy());
            }
        }
        else if(m_mapSpecialChlName[channelNum] == "PMHighVacuumGaugeAI")//added by taohao[1.4.0_HotFix] for HighVacuumGauge
        {
            dTempValue = 1.667*AdVoltage - 11.46;
            dTempValue = pow(10,dTempValue);
            if(dTempValue >= 750)
            {
                dTempValue=750*1000;//Torr -> mTorr
            }
            else if(dTempValue <= 3.8e-09)
            {
                dTempValue=3.8e-09*1000;//Torr -> mTorr
            }
            else
            {
                dTempValue=dTempValue*1000;//Torr -> mTorr
            }
            *value = MathTool::Round(dTempValue,typeinfo.getAccuracy()); 
        }
        else if(m_mapSpecialChlName[channelNum] == "PCFlowOutAI"
        || m_mapSpecialChlName[channelNum] == "PCFlowOut2AI")//added by mayc[V1.0.5]
        {
            //dTempValue = AdVoltage*(typeinfo.getMax() - typeinfo.getMin())/5.0 + typeinfo.getMin();
            dTempValue = AdVoltage*(typeinfo.getMax() - typeinfo.getMin())/m_dcardVoltage + typeinfo.getMin();    //added by taohao[1.1.30]
            *value = MathTool::Round(dTempValue,typeinfo.getAccuracy());
        }
        else if(m_mapSpecialChlName[channelNum].find("PT") != string::npos)// 1~5V = -0.1~0.5Mpa, 1Mpa = 145.04PSI, -0.1~0.5Mpa = -14.504Psi~72.52psi
        {
            dTempValue = (AdVoltage-1)*(typeinfo.getMax() - typeinfo.getMin())/4 + typeinfo.getMin();
            *value = MathTool::Round(dTempValue,typeinfo.getAccuracy());
        }
        else if(m_mapSpecialChlName[channelNum].find("PF3W720_Voltage") != string::npos)
        {
            // "(AdVoltage - 1) * 4" is based on PF3W720 manual, "-0.2" is based on the difference between software result and hardware number.
            dTempValue = (AdVoltage - 1) * 4 - 0.2;
            if (dTempValue < 2)
            {
                dTempValue = 0;
            }
            *value = MathTool::Round(dTempValue, typeinfo.getAccuracy());
        }
        else if(m_mapSpecialChlName[channelNum] == "SRFReflectPWRAI" || m_mapSpecialChlName[channelNum] == "SRFFWDLPWRAI")//added by guojin[1.1.43]
        {
            dTempValue = AdVoltage*(typeinfo.getMax() - typeinfo.getMin())/10.0 + typeinfo.getMin();
            if(dTempValue < 10)//filter noise
            {
                 *value = 0;
            }
            else
            {
                *value = MathTool::Round(dTempValue,typeinfo.getAccuracy());
            }
        }
        else if(m_mapSpecialChlName[channelNum] == "HFSweepFreqAI") //added by taohao[1.1.46]
        {
            dTempValue = AdVoltage*(typeinfo.getMax() - typeinfo.getMin())/5 + typeinfo.getMin();
            if(dTempValue > typeinfo.getMax())
            {
                dTempValue = typeinfo.getMax();
            }
            else if (dTempValue < typeinfo.getMin())
            {
                dTempValue = typeinfo.getMin();
            }
            *value = MathTool::Round(dTempValue,typeinfo.getAccuracy());
        }
    }
    else
    {
        dTempValue = AdVoltage*(typeinfo.getMax() - typeinfo.getMin())/10.0 + typeinfo.getMin();
        *value = MathTool::Round(dTempValue,typeinfo.getAccuracy());
    }

    if (m_filterChannels.find(channelNum) != m_filterChannels.end())
    {
        if ((m_filterInterval - 1) == m_filterChannels[channelNum].count)
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
                                    getSelfName() + " " + m_filterChannels[channelNum].name + ": " + Converter::convertToString(*value));
            m_filterChannels[channelNum].sum += *value;
            m_filterChannels[channelNum].value->setValue(m_filterChannels[channelNum].sum / m_filterInterval);
                        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
                                    getSelfName() + " " + m_filterChannels[channelNum].name + "_filter: " + Converter::convertToString(m_filterChannels[channelNum].sum / m_filterInterval));
            m_filterChannels[channelNum].sum = 0.0;
            m_filterChannels[channelNum].count = 0;
        }
        else
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,
                                    getSelfName() + " " + m_filterChannels[channelNum].name + ": " + Converter::convertToString(*value));
            m_filterChannels[channelNum].sum += *value;
            m_filterChannels[channelNum].count++;
        }

    }

    return true;
}

void PCICard::initCard()
{
    m_cardID = Register_Card(m_cardType, m_cardNum);
    if (m_cardID < 0) 
    {
        m_cardID = Register_Card(m_cardType, m_cardNum); 
        if (m_cardID < 0) 
        {
            throw ConfigException("It is failed to register the card ");
        }        
    }    
    if(m_cardType == PCI_9116)
    {
        if(AI_9116_Config(m_cardID, P9116_AI_UniPolar|P9116_AI_SingEnded|P9116_AI_LocalGND,
                      P9116_AI_SoftPolling, 0, 0, 0) != NoError)
        {
            throw  ConfigException("It is failed to initialize the PCI_9116 card");
        }        
    }
}

void PCICard::init7432(DeviceNode<PCICard> *node)
{
    
    for(int i=0; i<32; i++)
    {
        node->registerWriteCh(i,&PCICard::write7432);
    }
    
    for(int i=32; i<64; i++)
    {
        node->registerReadCh(i,&PCICard::read7432);
    }    
}

void PCICard::init7433(DeviceNode<PCICard> *node)
{
    for(int i=0; i<64; i++)
    {
        node->registerReadCh(i,&PCICard::read7433);
    }
}

void PCICard::init7434(DeviceNode<PCICard> *node)
{
    for(int i=0; i<64; i++)
    {
        node->registerWriteCh(i,&PCICard::write7434);
    }    
}

void PCICard::init6208(DeviceNode<PCICard> *node)
{
    for(int i=0; i<16; i++)
    {
        node->registerWriteCh(i,&PCICard::write6208);
    }    
}

void PCICard::init9116(DeviceNode<PCICard> *node)
{
    for(int i=0; i<64; i++)
    {
        node->registerReadCh(i,&PCICard::read9116);
    }
}

void PCICard::init()
{
    DeviceNode<PCICard> *node = new DeviceNode<PCICard>(m_pollInterval, this);
    DeviceManager::getInstance()->registerNode(m_nodeNum, node);
    
    if(!isSimulated())
    {
        switch(m_cardType)
        {
            case PCI_7432:
                init7432(node);
                break;
                
            case PCI_7433:
                init7433(node);
                break;
                
            case PCI_7434:
                init7434(node);
                break;
                
            case PCI_6208V:
                init6208(node);
                break;
                
            case PCI_9116:
                init9116(node);
                break;
                
            default:
                delete node;
                throw ConfigException("invalid card type!");
        }    
        initCard();
    }   
}

void PCICard::setCardType(unsigned short cardType)
{
    m_cardType = cardType;
}

void PCICard::setCardNum(unsigned short cardNum)
{
    m_cardNum = cardNum;
}

void PCICard::setNodeNum(int nodeNum)
{
    m_nodeNum = nodeNum;
}

void PCICard::setPollInterval(int ms)
{
    m_pollInterval = ms;
}

void PCICard::setSpecialChlName(int channelNum, std::string name)//added by xiasc[20180321]
{  
    m_mapSpecialChlName.insert(pair<int,std::string>(channelNum,name));
    if(m_mapSpecialChlName.find(channelNum) != m_mapSpecialChlName.end())
    {    
        cout<<"channelNum1:"<<channelNum<<endl;
        cout<<"name1:"<<name<<endl;
    }        
    else
    {
        cout<<"channelNum2:"<<channelNum<<endl;
        cout<<"name2:"<<name<<endl;
    }
}

void PCICard::addFilterChl(int channelNum, std::string name)
{

    if(m_filterChannels.find(channelNum) != m_filterChannels.end())
    {
        cout<<"addFilterChl already has:"<<channelNum<<endl;
        cout<<"addFilterChl already has:"<<name<<endl;
    }
    else
    {
        FilterInfo info;
        info.name = name;
        info.value = new ReadWriteDouble();
        info.value->setValue(0.0);//add by AtuoCodeChangeTool for IAP4.0
        info.count = 0;
        info.sum = 0.0;
        info.lastValue = 0.0;
        m_filterChannels.insert(pair<int,FilterInfo>(channelNum,info));
        CTCExport::exportAsOthers(info.value, name + "_Filter");
        cout<<"addFilterChl:"<<channelNum<<endl;
        cout<<"addFilterChl:"<<name<<endl;
    }
}

void PCICard::setFilterInterval(int interval)
{
    m_filterInterval = interval;
}

void PCICard::addScopeChl(int channelNum, double dMin, double dMax)//added by liusy[1.1.22]
{
    if(m_ScopeChannels.find(channelNum) != m_ScopeChannels.end())
    {
        cout<<"addScopeChannel already has:"<<channelNum<<endl;
    }
    else
    {
        ScopeInfo info;
        info.dMin=dMin;
        info.dMax=dMax;
        m_ScopeChannels.insert(pair<int,ScopeInfo>(channelNum,info));
    }
}

void PCICard::setCardVoltage(double dCardVoltage)//added by taohao[1.1.30]
{
    m_dcardVoltage = dCardVoltage;
}

IMPLEMENT_DYNAMIC(PCICard, AbstractDevice)
BEGIN_MSG_MAP( PCICard, AbstractDevice)
    SET_I( setCardType,PCICard )
    SET_I( setCardNum, PCICard )
    SET_I( setNodeNum, PCICard )
    SET_I( setPollInterval, PCICard )
    SET_V( init, PCICard )
    SET_IS(setSpecialChlName, PCICard)
    SET_IS(addFilterChl, PCICard)
    SET_I( setFilterInterval, PCICard)
    SET_IDD(addScopeChl,PCICard)//added by liusy[1.1.22]
    SET_D( setCardVoltage, PCICard)//added by taohao[1.1.30]
END_MSG_MAP
