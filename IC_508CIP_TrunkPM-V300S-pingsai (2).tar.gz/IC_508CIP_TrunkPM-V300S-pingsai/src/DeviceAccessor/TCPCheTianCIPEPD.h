/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TCPCheTianCIPEPD.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2021-6-25   Zhongchenyu create
**      
*********************************************************************/
#ifndef TCPCheTianCIPEPD_H_
#define TCPCheTianCIPEPD_H_



#include "TCPDevice.h"
#include "DeviceNode.h"
#include "IMutex.h"
#include "TCPCheTianEPD.h"
#include <map>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
#endif

#define CheTian_TCPIP_PORT "15000"
#define BUFFER_SIZE 300

class TCPCheTianCIPEPD:public TCPCheTianEPD
{
	DECLARE_DYNAMIC(TCPCheTianCIPEPD)	
	DECLARE_MSG_MAP	
	
	protected:	
		
		
		Cmd m_QUERYRUNSTATUS;
		Cmd m_QUERYOPERATESTATUS;
		Cmd m_SETRUNSTATUS;
		Cmd m_SETOPERATESTATUS;
		Cmd m_SETX1;
		Cmd m_SETX2;	
		Cmd m_QUERYX1;		
		Cmd m_QUERYX2;	
		
		
		void initChannels(DeviceNode<TCPCheTianCIPEPD> *node);
		void initCmd();
       	 	void init();
		void sendWfrInfo(int channelNum, int nChannelNo = 0);
		void sendCmd(Cmd *cmd, int nChannelNo = 0);
		void preRead(char *buffer); 
		void replyCmd(); 
		void replyCmd(Cmd *cmd); 
		void replyEvent();

		std::string replyErrorMsg(char *error);

		
		std::string m_RecpName;
		std::string m_querydatda;
		double m_trenddata1[2];
		double m_trenddata2[2];
		double m_trenddata3[2];
		double m_trenddata4[2];
		double m_trenddata5[2];
		double m_trenddata6[2];
		double m_x1;
		double m_x2;
		double m_readx1[2];
		double m_readx2[2];
		
		int m_eventstart[2];
		int m_eventdelay[2];
		int m_eventnormaliazation[2];
		int m_eventsatisfy[2];
		int m_eventstop[2];

		int m_runstatus[2];
		int m_operatestatus[2];
		int m_setrunstatus[2];
		int m_setoperatestatus[2];

		bool m_bDoubleChannelEnabled;

	public:
		TCPCheTianCIPEPD();
		virtual ~TCPCheTianCIPEPD();
		virtual void acceptData();
		virtual bool reconnectDevice();
		virtual std::string getDeviceName();
		
		bool writeI(int channelNum, int setpt, const IntTypeInfo &);
		bool writeS(int channelNum, std::string value, const StringTypeInfo &);
		bool readI(int channelNum, int *value, const IntTypeInfo &);
		bool readD(int channelNum, double *value, const DoubleTypeInfo &);
		bool writeD(int channelNum, double value, const DoubleTypeInfo &);

		bool setDoubleChannelEnabled(bool bDoubleChannelEnabled);
};

#endif /*TCPCheTianCIPEPD_H_*/
