/********************************************************************
** Copyright (c) 2019 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: EIPApplication.h
** Description:  
** Release: 1.0
** Modification history:           
** 					2019-06-05   Duq create
** 
*********************************************************************/

#ifndef EIPAPPLICATION_H_
#define EIPAPPLICATION_H_

#include "EnIPRemoteDevice.h"

//send and receive EIP
class EIPApplication
{
	protected:
		uint32_t unique_session_id;
		bool m_running;
		bool m_runningstatus;
		bool m_result;
		
		//if more than one connection, more EnIPRemoteDevice --- futrue map 
		int m_inputSize;
		int m_outputSize;
		uint16_t m_inputInstanceId;
		uint16_t m_outputInstanceId;
		uint16_t m_configInstanceId;
		EnIPRemoteDevice* m_remotedevice;
	
	public:
		std::string m_server;//192.168.250.x
		bool startflag;
		
	public:
		EIPApplication(std::string &server, uint16_t configId, uint16_t inputId, uint16_t outputId);
		virtual ~EIPApplication();
		
		virtual bool initDevice(std::string &error, unsigned int cycleTime);
		virtual void shutdownDevice();
		virtual void ApplicationInitialization(); //init Application: create input and output data assembly 
		virtual bool getAttributDataSize(); //get Attributs data size
		virtual bool do_RegisterSession(); //class RegisterSession
		virtual void do_UnRegisterSession(); //class UnRegisterSession
		virtual bool do_ForwardOpen(unsigned int cycleTime); //Attribut open connection
		virtual bool do_ForwardClose(); //Attribut close connection
		virtual bool getBytesInputsData(int offset, int len, void *value); // get inputs attribut (offset ~ offset + len -1)th byte data
		virtual bool setBytesOutputsData(int offset, int len, void *value, bool flag); // set value to outputs attribut (offset ~ offset + len -1)th byte data
		virtual void do_ReadClass1Data(char * data, int len); //Attribut read class1 connection data -- class1 UDP
		static EIPApplication* getEIP(std::string &server, uint16_t configId, uint16_t inputId, uint16_t outputId, unsigned int cycleTime, std::string &error);
};

#endif  /*EIPAPPLICATION_H_*/
