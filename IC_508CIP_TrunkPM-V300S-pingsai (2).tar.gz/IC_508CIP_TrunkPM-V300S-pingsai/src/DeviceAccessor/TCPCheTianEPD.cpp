/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TCPCheTianEPD.cpp
** Description:  
** Release: 1.1
** Modification history: 
**                     2021-6-25   Zhongchenyu create
**      
*********************************************************************/
#include "TCPCheTianEPD.h"
#include "DeviceManager.h"
#include "SysLogger.h"
#include "ConfigException.h"
#include <iostream>
#include <string.h>
#include <ctype.h>
#include "Converter.h"
#include "Hex.h"
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std;

TCPCheTianEPD::TCPCheTianEPD()
{
    memset(m_sndBuffer, 0, sizeof(m_sndBuffer));
    memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
    m_configName = "";
	//[wangyk 1.10.0 change]
    m_lot[0] = "";
    m_slot[0] = "";
    m_Waferid[0] = "";
    m_Recipe = "";
    m_Step = "";
    m_configlist[0]= "";
    m_version = "";
    m_status[0] = -1;
    m_endpoint[0] = 0;   //added by liusy[1.1.39]
    m_epdtime[0] = 0.0;
    m_error[0] = "";

}

TCPCheTianEPD::~TCPCheTianEPD()
{
    if(!isSimulated())
    {

    }
}

bool TCPCheTianEPD::writeI(int channelNum, int setpt, const IntTypeInfo &)
{
    //sendCmd(&m_CONNECT);
    switch(channelNum)
    {
        case 1://recipestart
            sendCmd(&m_RECIPESTART);
            break;

        case 2://recipestop
            sendCmd(&m_RECIPESTOP);
            break;

        case 3://complete
            sendCmd(&m_COMPLETED);
            break;

        case 4://start
            m_endpoint[0] = 0;//[wangyk 1.10.0 change]
            m_epdtime[0] = 0.0;
            sendCmd(&m_START);
            break;

        case 5://stop
            sendCmd(&m_STOP);
            break;
        case 12://cfglist
            sendCmd(&m_CFGLIST);
            break;
        case 13://version
            sendCmd(&m_VERSION);
            break;
        case 26://reset
            sendCmd(&m_RESET);
            break;
        case 27://connect
            //setPort(CheTian_TCPIP_PORT);
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianEPD sending cmd -ZZZZZZ");
            TCPDevice::init();    //??
            sendCmd(&m_CONNECT);
            break;
        case 28://disconnect
            sendCmd(&m_DISCONNECT);
            break;

        default:
            break;
    }
    return true;

}

bool TCPCheTianEPD::writeS(int channelNum, std::string value, const StringTypeInfo &)
{
    if (!isConnected())
    {
        throw IOException("device is not connected! ");
    }
    switch(channelNum)
    {
        case 6: // configname
            m_configName = value;
            return true;

        case 7: //lot
            m_lot[0] = value;//[wangyk 1.10.0 change]
            break;

        case 8: //slot
            m_slot[0] = value;
            break;

        case 9: // wafer
            m_Waferid[0] = value;
            break;

        case 10: //recipe
            m_Recipe = value;
            break;

        case 11: //step
            m_Step = value;
            break;
    }
    if(channelNum != 6)
    {
        sendWfrInfo();
    }

    return true;
}

bool TCPCheTianEPD::readS(int channelNum, std::string *value, const StringTypeInfo &)
{
    if (!isConnected())
    {
        throw IOException("device is not connected! ");
    }
    switch(channelNum)
    {
        case 23: // error
            *value = m_error[0];//[wangyk 1.10.0 change]
            break;
        case 24: // configurelist
            *value = m_configlist[0];
            //cout<<"config list is"<<m_configlist<<endl;
            break;

        case 25: //version
            *value = m_version;
            break;
    }
    return true;
}

bool TCPCheTianEPD::readI(int channelNum, int *value, const IntTypeInfo &)
{
    if (!isConnected())
    {
        throw IOException("device is not connected! ");
    }
    switch(channelNum)
    {
        case 14: // state
            sendCmd(&m_STATE);
            //sendCmd(&m_DISCONNECT);
            *value = m_status[0];//[wangyk 1.10.0 change]
            break;

        case 15: //EndPoint
            *value = m_endpoint[0];
            break;
        //case 29://heatbeat
            /*if(isConnected())
            {
                sendCmd(&m_HEATBEAT);
            }
            *value = 1;
            break;    */
    }
    return true;
}

bool TCPCheTianEPD::readD(int channelNum, double *value, const DoubleTypeInfo &)
{
    if (!isConnected())
    {
        throw IOException("device is not connected! ");
    }
    switch(channelNum)
    {
        case 16: // time
            *value = m_status[0];//[wangyk 1.10.0 change]
            break;

        case 15: //EndPoint
            *value = m_endpoint[0];
            break;

    }
    if(channelNum >30 || channelNum<=36)
    {
        *value = 0.0;
    }
    return true;
}


void TCPCheTianEPD::sendWfrInfo()
{

}

void TCPCheTianEPD::initChannels(DeviceNode<TCPCheTianEPD> *node)
{
    node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &TCPDevice::getStatus);
    //node->registerReadCh(1000,&TCPDevice::connectStatus);
    for(int i = 1; i <=5; i++)
    {
        node->registerWriteCh(i,&TCPCheTianEPD::writeI);
    }
    for(int i = 6; i <=11; i++)
    {
        node->registerWriteCh(i,&TCPCheTianEPD::writeS);
    }
    for(int i = 12; i <=13; i++)
    {
        node->registerWriteCh(i,&TCPCheTianEPD::writeI);
    }
    node->registerReadCh(14,&TCPCheTianEPD::readI);
    node->registerReadCh(15,&TCPCheTianEPD::readI);
    for(int i = 16; i <=22; i++)
    {
        node->registerReadCh(i,&TCPCheTianEPD::readD);
    }
    for(int i = 23; i <=25; i++)
    {
        node->registerReadCh(i,&TCPCheTianEPD::readS);
    }
    for(int i = 26; i <=28; i++)
    {
        node->registerWriteCh(i,&TCPCheTianEPD::writeI);
    }
    node->registerReadCh(29,&TCPCheTianEPD::readI);
    for(int i = 30; i <=36; i++)
    {
        node->registerReadCh(i,&TCPCheTianEPD::readD);
    }
}

void TCPCheTianEPD::initCmd()
{
    m_RECIPESTART.m_name = "RECIPESTART";
    m_RECIPESTART.m_cmd = 0x01;
    m_RECIPESTART.m_status[0] = 0x00;
    m_RECIPESTART.m_status[1] = 0x00;
    m_RECIPESTART.m_errormsg = "";
    m_RECIPESTART.m_datalength = 4;
    m_RECIPESTART.m_reslength = 0;

    m_RECIPESTOP.m_name = "RECIPESTOP";
    m_RECIPESTOP.m_cmd = 0x02;
    m_RECIPESTOP.m_status[0] = 0x00;
    m_RECIPESTOP.m_status[1] = 0x00;
    m_RECIPESTOP.m_errormsg = "";
    m_RECIPESTOP.m_datalength = 1;
    m_RECIPESTOP.m_reslength = 0;

    m_COMPLETED.m_name = "COMPLETED";
    m_COMPLETED.m_cmd = 0x03;
    m_COMPLETED.m_status[0] = 0x00;
    m_COMPLETED.m_status[1] = 0x00;
    m_COMPLETED.m_errormsg = "";
    m_COMPLETED.m_datalength = 1;
    m_COMPLETED.m_reslength = 0;

    m_START.m_name = "START";
    m_START.m_cmd = 0x04;
    m_START.m_status[0] = 0x00;
    m_START.m_status[1] = 0x00;
    m_START.m_errormsg = "";
    m_START.m_datalength = 256;
    m_START.m_reslength = 0;

    m_STOP.m_name = "STOP";
    m_STOP.m_cmd = 0x05;
    m_STOP.m_status[0] = 0x00;
    m_STOP.m_status[1] = 0x00;
    m_STOP.m_errormsg = "";
    m_STOP.m_datalength = 1;
    m_STOP.m_reslength = 0;

    m_WAFERINFO.m_name = "WAFERINFO";
    m_WAFERINFO.m_cmd = 0x06;
    m_WAFERINFO.m_status[0] = 0x00;
    m_WAFERINFO.m_status[1] = 0x00;
    m_WAFERINFO.m_errormsg = "";
    m_WAFERINFO.m_reslength = 0;

    m_CFGLIST.m_name = "CFGLIST";
    m_CFGLIST.m_cmd = 0x07;
    m_CFGLIST.m_status[0] = 0x00;
    m_CFGLIST.m_status[1] = 0x00;
    m_CFGLIST.m_errormsg = "";
    m_CFGLIST.m_datalength = 4;
    m_CFGLIST.m_reslength = 0;

    m_STATE.m_name = "STATE";
    m_STATE.m_cmd = 0x08;
    m_STATE.m_status[0] = 0x00;
    m_STATE.m_status[1] = 0x00;
    m_STATE.m_errormsg = "";
    m_STATE.m_datalength = 4;
    m_STATE.m_reslength = 0;
    m_STATE.m_res = "";

    m_VERSION.m_name = "VERSION";
    m_VERSION.m_cmd = 0x09;
    m_VERSION.m_status[0] = 0x00;
    m_VERSION.m_status[1] = 0x00;
    m_VERSION.m_errormsg = "";
    m_VERSION.m_datalength = 4;
    m_VERSION.m_reslength = 32;
    m_VERSION.m_res = "";

    m_EVENT.m_name = "EVENT";
    m_EVENT.m_cmd = 0x0A;
    m_EVENT.m_status[0] = 0x00;
    m_EVENT.m_status[1] = 0x00;
    m_EVENT.m_errormsg = "";
    m_EVENT.m_reslength = 0;

    m_RESPONSE.m_name = "";
    m_RESPONSE.m_cmd = 0x00;
    m_RESPONSE.m_status[0] = 0x00;
    m_RESPONSE.m_status[1] = 0x00;
    m_RESPONSE.m_errormsg = "";
    m_RESPONSE.m_datalength = 0;
    m_RESPONSE.m_reslength = 0;
    m_RESPONSE.m_res = "";

    m_RESET.m_name = "RESET";
    m_RESET.m_cmd = 0x00;
    m_RESET.m_status[0] = 0x00;
    m_RESET.m_status[1] = 0x00;
    m_RESET.m_errormsg = "";
    m_RESET.m_datalength = 1;
    m_RESET.m_reslength = 0;

    m_CONNECT.m_name = "CONNECT";
    m_CONNECT.m_cmd = 0x10;
    m_CONNECT.m_status[0] = 0x00;
    m_CONNECT.m_status[1] = 0x00;
    m_CONNECT.m_errormsg = "";
    m_CONNECT.m_datalength = 1;
    m_CONNECT.m_reslength = 0;

    m_DISCONNECT.m_name = "DISCONNECT";
    m_DISCONNECT.m_cmd = 0x11;
    m_DISCONNECT.m_status[0] = 0x00;
    m_DISCONNECT.m_status[1] = 0x00;
    m_DISCONNECT.m_errormsg = "";
    m_DISCONNECT.m_datalength = 1;
    m_DISCONNECT.m_reslength = 0;

    m_HEATBEAT.m_name = "HEATBEAT";
    m_HEATBEAT.m_cmd = 0x20;
    m_HEATBEAT.m_status[0] = 0x00;
    m_HEATBEAT.m_status[1] = 0x00;
    m_HEATBEAT.m_errormsg = "";
    m_HEATBEAT.m_datalength = 1;
    m_HEATBEAT.m_reslength = 0;

    m_QUERYDATA.m_name = "QUERYDATA";
    m_QUERYDATA.m_cmd = 0x30;
    m_QUERYDATA.m_status[0] = 0x00;
    m_QUERYDATA.m_status[1] = 0x00;
    m_QUERYDATA.m_errormsg = "";
    m_QUERYDATA.m_datalength = 256;
    m_QUERYDATA.m_reslength = 0;
    for(int i=0; i<6; ++i)
    {
        m_trendDatas.insert(TrendPair("EPDTrend" + Converter::convertToString(i+1), new TrendData(0.0, 0, -1)));
    }
}

void TCPCheTianEPD::init()
{
    DeviceNode<TCPCheTianEPD> *node = new DeviceNode<TCPCheTianEPD>(m_pollInterval,this);
    DeviceManager::getInstance()->registerNode(m_nodeNum,node);
    if(!isSimulated())
    {
        initChannels(node);
        setPort(CheTian_TCPIP_PORT);
        TCPDevice::init();
        initEPD();
    }
}

void TCPCheTianEPD::initEPD()
{
    initCmd();
    connectEPD();
}

void TCPCheTianEPD::connectEPD()
{
    sendCmd(&m_CONNECT);
}

void TCPCheTianEPD::sendCmd(Cmd *cmd)
{
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianEPD sending cmd -" + cmd->m_name);
    memset(m_sndBuffer, 0, sizeof(m_sndBuffer));

    //added by liusy[1.1.39]
    cmd->m_status[0] = 0xFFFFFFFF;
    m_RESPONSE.m_status[0] = 0X00;
    m_RESPONSE.m_status[1] = 0X00;
    char t_orgdata[4];
    for(int i=0;i<4;i++)
    {
        t_orgdata[i] = 0x00;
    }
    m_head[0]=0x01;
    m_head[1]=0x01;
    m_head[2]=0x00;
    m_head[3]=0x00;
    int t_size = 4;

    for(int i=0;i<t_size;i++)
    {
        m_sndBuffer[i] = m_head[i];
        //cout<<"buffer["<<i<<"]"<<hex<<(int)m_sndBuffer[i]<<endl;
    }
    m_sndBuffer[t_size] = 0x00;
    //cout<<"buffer["<<t_size<<"]"<<hex<<(int)m_sndBuffer[t_size]<<endl;
    t_size = t_size+1;
    m_sndBuffer[t_size] = cmd->m_cmd;
    //cout<<"buffer["<<t_size<<"]"<<hex<<(int)m_sndBuffer[t_size]<<endl;

    if(cmd->m_name == "START" || cmd->m_name == "RECIPESTART")
    {
        t_orgdata[0] = 0xFF;
        for(int i=0;i< 4; i++)
        {
            t_size ++;
            m_sndBuffer[t_size] = t_orgdata[i];
            //cout<<"buffer["<<t_size<<"]"<<hex<<(int)m_sndBuffer[t_size]<<endl;
        }
        for(int i=0;i< m_configName.length(); i++)
        {
            t_size++;
            m_sndBuffer[t_size] = m_configName[i];
            //cout<<"buffer["<<t_size<<"]"<<hex<<(int)m_sndBuffer[t_size]<<endl;
        }
        t_size = 266;
        //t_size = t_size+1;
        //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianEPD other2 sending cmd -"+ Hex::GetHexString(m_sndBuffer,t_size));
        sendData(m_sndBuffer, t_size);
    }
    else
    {
        for(int i=0;i< 4; i++)
        {
            t_size = t_size+1;
            m_sndBuffer[t_size] = t_orgdata[i];
            //cout<<"buffer["<<t_size<<"]"<<hex<<(int)m_sndBuffer[t_size]<<endl;
        }
        t_size = t_size+1;
        //cout<<"t_size is "<<t_size<<endl;
        //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianEPD other sending cmd -"+ Hex::GetHexString(m_sndBuffer,t_size));
        sendData(m_sndBuffer, t_size);

    }


    int t_leftcount = m_timeOut*1000/m_checkInterval;

    while(t_leftcount > 0)//added by liusy[1.1.39]
    {
        if(cmd->m_status[0] == 0xFFFFFFFF)
        {

        }
        else
        {
            if(cmd->m_status[0] == 0x00)
            {
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianEPD sended cmd -" + cmd->m_name);
                return;
            }
            else
            {
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": TCPCheTianEPD get fail ack for cmd - "+ cmd->m_name + ".error is " + cmd->m_errormsg);
                throw IOException("get fail ack for cmd - "+ cmd->m_name + ".error is " + cmd->m_errormsg);
            }
        }
        usleep(m_checkInterval*1000);
        --t_leftcount;
    }
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": TCPCheTianEPD waiting for cmd ack time out-" + cmd->m_name);
    throw IOException("waiting for cmd ack time out-" + cmd->m_name);
}

void TCPCheTianEPD::acceptData()
{
    IMutexLocker t_locker(&m_lock);
    memset(m_recvBuffer, 0, sizeof(m_recvBuffer));

    if(readData(m_recvBuffer,14))
    {
        //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianEPD receive data -"+ Hex::GetHexString(m_recvBuffer,14));
        /*for(int i = 0; i < 14; i++)
        {
            cout<<"result is : "<<i<<hex<<(int)m_recvBuffer[0]<<endl;
        }*/
        preRead(m_recvBuffer);
        if(m_RESPONSE.m_cmd != 0x0A) //modify by chenw 1.5.0
        {
            replyCmd();
        }
        else
        {
            replyEvent();
        }
    }
    else
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": TCPCheTianEPD reading header failed in acceptData()");
    }
}

void TCPCheTianEPD::preRead(char *buffer)
{
    char t_status[4];
    char t_length[4];
    int t_len;


    if(m_recvBuffer[0]==0x01 && m_recvBuffer[1] == 0x01)
    {

        if(m_recvBuffer[7] == 0x10)
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": TCPCheTianEPD have received ErrorCode :" + Converter::convertToString(m_recvBuffer[7]) + Converter::convertToString(m_recvBuffer[6]));
            m_RESPONSE.m_status[0] = m_recvBuffer[7];
            m_RESPONSE.m_status[1] = m_recvBuffer[6];
            m_error[0] =  replyErrorMsg(m_RESPONSE.m_status);//[wangyk 1.10.0 change]
            m_RESPONSE.m_cmd = m_recvBuffer[5];//added by liusy[1.1.39]
            return;
        }
        else
        {
            //m_RESPONSE.m_status[0] = 0X00;
            //m_RESPONSE.m_status[1] = 0X00;
            m_error[0] = "";//added by liusy[1.1.39]//[wangyk 1.10.0 change]
        }
        m_RESPONSE.m_cmd = m_recvBuffer[5];
        if(m_RESPONSE.m_cmd == 0x0A)
        {
            unsigned int result = *((unsigned int*)(m_recvBuffer + 10)); //modify by chenw [1.5.0]

			if (BUFFER_SIZE >= result)
			{
                readData(m_recvBuffer,result);
			}
			else
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": TCPCheTianEPD get data len more than BUFFER_SIZE, need check chetian OES log for more info ."+"Result is "+Converter::convertToString(result));
				throw IOException(getDeviceName() + " get data len more than BUFFER_SIZE");
			}
            //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianEPD receive data -"+ Hex::GetHexString(m_recvBuffer,result));

            if(m_recvBuffer[0]==0x07)
            {
                m_endpoint[0] = 1;//[wangyk 1.10.0 change]
            }
            else if(m_recvBuffer[0]==0x10)
            {
                char t_trenddata[256];

                string t_trenddatalist[256];      //changed by wzd 1.1.65 hotfix3 for SUSE offline
                string t_trenddataFinal = "";
                //m_configlist = "D";

                for(int i = 0;i< 256;i++)
                {
                    t_trenddata[i] = m_recvBuffer[11+i];
                    t_trenddatalist[i] = t_trenddata[i];


                    t_trenddataFinal += t_trenddatalist[i];

                }
                //cout<<"config list is"<<t_trenddataFinal<<endl;

                double t_value = 0.0;
                std::map<std::string, TrendData*>::iterator t_it;
                for(t_it=m_trendDatas.begin(); t_it!=m_trendDatas.end(); ++t_it)
                {
                    t_it->second->m_value = t_value;
                }
            }
            const long long ticket = 62135596800000ULL; //modify by chenw 1.5.0
            long long t_time;

            t_time = (((int)(m_recvBuffer[11]&0x00ff)<<56)&0xff0000000000000000ULL)+(((int)(m_recvBuffer[10]&0x00ff)<<48)&0xff00000000000000ULL)+(((int)(m_recvBuffer[9]&0x00ff)<<40)&0xff0000000000ULL)+(((int)(m_recvBuffer[8]&0x00ff)<<32)&0xff00000000ULL)+(((int)(m_recvBuffer[7]&0x00ff)<<24)&0xff000000) + (((int)(m_recvBuffer[6]&0x00ff)<<16)&0xff0000) 
                        + (((int)(m_recvBuffer[5]&0x00ff)<<8)&0xff00) + ((int)m_recvBuffer[4]&0xff);

            t_time = (t_time - ticket)%1000;
            m_epdtime[0] = t_time;//[wangyk 1.10.0 change]
            //cout<<"result is : "<<t_time<<endl;

        }
        else if(m_RESPONSE.m_cmd == 0x07)
        {
            readData(m_recvBuffer,4);
            //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianEPD receive data -"+ Hex::GetHexString(m_recvBuffer,4));
            int t_cfgnum = (int)m_recvBuffer[0];
            cout<<"config list is"<<hex<<(int)m_recvBuffer[0]<<endl;
            cout<<"config list is"<<t_cfgnum<<endl;
            cout<<"config list is"<<hex<<(int)m_recvBuffer[2]<<endl;
            cout<<"config list is"<<hex<<(int)m_recvBuffer[3]<<endl;
            char t_cfg[256];
            int t_cfgint[256];
            string t_cfglist[256];      //changed by wzd 1.1.65 hotfix3 for SUSE offline
            string t_cfglistFinal = "";
            //m_configlist = "D";
            m_configlist[0] = "";     //changed by wzd 1.1.65 hotfix3 for list repeat//[wangyk 1.10.0 change]
            for(int j = 0; j < t_cfgnum; j++)
            {
                memset(m_recvBuffer, 0, 256);
                readData(m_recvBuffer,256);
                //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianEPD receive data -"+ Hex::GetHexString(m_recvBuffer,256));
                for(int i = 0;i< 256;i++)
                {
                    t_cfg[i] = m_recvBuffer[i];
                    t_cfglist[i] = t_cfg[i];

                    if(t_cfglistFinal == "")
                    {
                        t_cfglistFinal = t_cfglist[i];
                    }
                    else
                    {
                        t_cfglistFinal += t_cfglist[i];
                    }
                }
                cout<<"config list is"<<t_cfglistFinal<<endl;
                //t_cfglist=t_cfgint;
                //m_configlist = "D";
                m_configlist[0] = m_configlist[0]+t_cfglistFinal.substr(0,t_cfglistFinal.find("."))+".epd,";//[wangyk 1.10.0 change]
                t_cfglistFinal = "";
            }
        }
        else if(m_RESPONSE.m_cmd == 0x08)
        {
            readData(m_recvBuffer,4);
            //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianEPD receive data -"+ Hex::GetHexString(m_recvBuffer,4));
            m_status[0]= (int)m_recvBuffer[0];//[wangyk 1.10.0 change]

        }
        else if(m_RESPONSE.m_cmd == 0x09)
        {
            readData(m_recvBuffer,32);
            //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": TCPCheTianEPD receive data -"+ Hex::GetHexString(m_recvBuffer,32));
            char t_ver[32];
            int t_verint[32];
            string t_verstr[32];      //changed by wzd 1.1.65 hotfix3 for SUSE offline
            string t_verFinal = "";
            for(int i = 0;i< 32;i++)
            {
                t_ver[i] = m_recvBuffer[i];
                t_verint[i] = t_ver[i];
                t_verstr[i] = t_verint[i];
                t_verFinal = t_verFinal + t_verstr[i];
            }
            m_version = t_verFinal;

        }

    }
} 

void TCPCheTianEPD::replyCmd()
{
    switch(m_RESPONSE.m_cmd)
    {
        case 0x01://recipestart
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianEPD got ack of RECIPESTART, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
            replyCmd(&m_RECIPESTART);
            break;

        case 0x02://recipestop
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianEPD got ack of RECIPESTOP, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
            replyCmd(&m_RECIPESTOP);
            break;

        case 0x03://complete
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianEPD got ack of COMPLETED, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
            replyCmd(&m_COMPLETED);
            break;

        case 0x04://start
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianEPD got ack of START, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
            replyCmd(&m_START);
            break;

        case 0x05://stop
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianEPD got ack of STOP, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
            replyCmd(&m_STOP);
            break;

        case 0x06://waferinfo
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianEPD got ack of WAFERINFO, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
            replyCmd(&m_WAFERINFO);
            break;

        case 0x07://cfglist
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianEPD got ack of CFGLIST, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
            replyCmd(&m_CFGLIST);   //changed by wzd 1.1.65 hotfix3 for send command time out
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianEPD got CFGLIST :" );
            break;

        case 0x08://epd state
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianEPD got ack of STATE, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
            replyCmd(&m_STATE);
            m_STATE.m_res = m_RESPONSE.m_res;
            break;

        case 0x09://version
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianEPD got ack of VERSION, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
            replyCmd(&m_VERSION);
            m_VERSION.m_res = m_RESPONSE.m_res;
            break;
        case 0x10://CONNECT //add by chenw 1.5.0
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianEPD got ack of CONNECT, length is " + Converter::convertToString(m_RESPONSE.m_reslength));
            replyCmd(&m_CONNECT);
            break;

        case 0x0A://event
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianEPD got ack of EVENT, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
            replyCmd(&m_EVENT);
            break;
        default:
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPCheTianEPD got ack of UNKNOWN COMMAND:" + Converter::convertToString(m_RESPONSE.m_cmd) + ", length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
            flush();
            break;
    }

}

void TCPCheTianEPD::replyCmd(Cmd *cmd)
{
    readDatas();

    if(m_RESPONSE.m_status[0] == 0x00)
    {
        cmd->m_errormsg = "";
    }
    else
    {
        cmd->m_errormsg = replyErrorMsg(m_RESPONSE.m_status);
    }
    cmd->m_status[1] = m_RESPONSE.m_status[1];//added by liusy[1.1.39]
    cmd->m_status[0] = m_RESPONSE.m_status[0];    //added by liusy[1.1.39]
}

string TCPCheTianEPD::replyErrorMsg(char *error)
{
    if(error[0] == 0x20)
            return "EPD hardware error(please check EPD device).";
    if(error[1] == 0x01)
            return "illegal parameter error.";
    if(error[1] == 0x02)
            return "system is offline (EPD is in remote mode or EPDViewer is in switch state ).";
    if(error[1] == 0x03)
            return "system is busy,not ready(EPD initialization is not complete).";
    if(error[1] == 0x04)
            return "EPD parameter configuration error(the parameter model defined has a syntax error,please use EPDViewer to check).";
    if(error[1] == 0x05)
            return "EPD calculation error.";
    if(error[0] == 0x30)
            return "EPD system error(Naura defined).";
    if(error[1] == 0x00)
            return "communication packet format error.";
    return " ";

}


void TCPCheTianEPD::readDatas()
{
    if (m_RESPONSE.m_reslength > 0)
    {
        char t_res[m_RESPONSE.m_reslength];
        memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
		bool res = false;
		if (BUFFER_SIZE >= (14+m_RESPONSE.m_reslength)) //add by chenw 1.5.0
		{
			res = readFixLenData(m_recvBuffer, 14+m_RESPONSE.m_reslength);
		}
		else
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": TCPCheTianEPD get data len more than BUFFER_SIZE, need check chetian OES log for more info ."+"m_RESPONSE.m_reslength is "+Converter::convertToString(m_RESPONSE.m_reslength));
			throw IOException(getDeviceName() + " get data len more than BUFFER_SIZE");
		}
        if (res)
        {
            for(int i= 0; i < m_RESPONSE.m_reslength;i++ )
            {
                t_res[i] = m_recvBuffer[14+i];
            }
            m_RESPONSE.m_res = t_res;
        }
        else
        {
            string t_error = "readDatas time out";
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ":TCPCheTianEPD readDatas time out");
        }
    }
}


void TCPCheTianEPD::replyEvent()
{
    readDatas();

    if(m_RESPONSE.m_res.empty())  //add by wzd 1.2.0
    {
        return;
    }

    const char *t_event = (m_RESPONSE.m_res).data();
    replyCmd(&m_CONNECT);//added by liusy[1.1.39]


    switch( t_event[8])
    {
        case 0x01://message
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got event MESSAGE, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
            flush();
            break;

        case 0x02://error
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got event ERROR, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
            m_RESPONSE.m_status[0] == 0x30;
            break;
 
        case 0x03://endpoint
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got event ENDPOINT, length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
            flush();
            break;
        default:
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":TCPEPD got UNKNOWN EVENT:" + t_event[8] + ", length is "+ Converter::convertToString(m_RESPONSE.m_reslength));
            flush();
            break;
    }
}

void TCPCheTianEPD::flush()
{

    if (m_RESPONSE.m_reslength > 0)
    {
        char t_res[m_RESPONSE.m_reslength];
        memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
		bool res = false;
		if (BUFFER_SIZE >= (14+m_RESPONSE.m_reslength)) //add by chenw 1.5.0
		{
			readFixLenData(m_recvBuffer, 14+m_RESPONSE.m_reslength);
		}
		else
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": TCPCheTianEPD get data len more than BUFFER_SIZE, need check chetian OES log for more info ."+"m_RESPONSE.m_reslength is "+Converter::convertToString(m_RESPONSE.m_reslength));
			throw IOException(getDeviceName() + " get data len more than BUFFER_SIZE");
		}
        if (res)
        {
            for(int i= 0; i < m_RESPONSE.m_reslength;i++ )
            {
                t_res[i] = m_recvBuffer[14+i];
            }
            m_RESPONSE.m_res = t_res;
        }
        else
        {
            string t_error = "readDatas time out";
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ":TCPCheTianEPD flush time out");
        }
    }
}

void TCPCheTianEPD::readEPDTime()
{

}

void TCPCheTianEPD::readConfigList()
{
}

IMPLEMENT_DYNAMIC(TCPCheTianEPD, TCPDevice )

BEGIN_MSG_MAP( TCPCheTianEPD, TCPDevice )
    //SET_S( setNameOfSPCV, TCPEPD )
END_MSG_MAP

