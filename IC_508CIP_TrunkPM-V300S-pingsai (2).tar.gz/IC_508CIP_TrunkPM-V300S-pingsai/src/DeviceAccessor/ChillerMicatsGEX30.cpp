/********************************************************************
** Copyright (c) 2021, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: ChillerMicatsGEX30.cpp
** Description:
** Release: 1.1
** Modification history:
*                      2021-10-28   zhangyy create
**
*********************************************************************/
#include "ChillerMicatsGEX30.h"
#include "DeviceManager.h"

#include "Converter.h"
#include "Hex.h"
#include "StrTool.h"
#include "CheckCalculationTool.h"
#include "SysLogger.h"
#include <string.h>
#include <iostream>
#include <cctype>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;

ChillerMicatsGEX30::Cmd ChillerMicatsGEX30::m_cmd[] = {{""},//reserved
                                       {":01170100000B0109000102",0}, //1 stop:0/run:1
                                              {":01170100000B010A000102",0},//2  set temprature
                                              {":01170100000B0109000000",0},//3 read temperature (-60~160)
                                              {":01170100000B0109000000",0},//4 read fluid resistivity(0~20)
                                              {":01170100000B0109000000",0},//5 read flow rate(0~10)
                                              {":01170100000B0109000000",0x8000},//6 read fault summary ok:0/fault:1
                                              {":01170100000B0109000000",0x4000},//7 read warn summary ok:0/warning:1
                                            {":01170100000B0109000000",0x0400},//8 local:0/remote:1
                                            {":01170100000B0109000000",0xF800},//9 read fault
//(15:fluid level fault/14:fluid flow fault/13:fluid resistivity fault/12:facility water fault/11:fuse fault)
                                            {":01170100000B0109000000",0x0200},};//10 read on off

ChillerMicatsGEX30::ChillerMicatsGEX30():SerialDevice(200, "\x0D\x0A")
{
    m_timeOut = 50;//5s
    m_pollPeriod = 1000; //1s
}

ChillerMicatsGEX30::~ChillerMicatsGEX30()
{
}

bool ChillerMicatsGEX30::writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
    string strCommand = m_cmd[nChannelNum].m_strAddress;
    double dTemp = (double)((dValue + 60) * 65535 / 220);
    double dTemp1 = (int) dTemp;
    int nTemp = dTemp1;
    string strTemp = Hex::hexToString(nTemp,4);
    strCommand += strTemp;
    strCommand += CheckCalculationTool::GetLRCCode(strCommand);
    strCommand = StrTool::toUpper(strCommand);
    //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "*****ChillerMicatsGEX30 set temperature command is **" +strCommand);
    string strResponse = getCommandResult(strCommand, m_timeOut);
    //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "*****ChillerMicatsGEX30 set temperature get readback is  **" +strResponse);

    int nPos = strResponse.find(":", 0);
    if(nPos == string::npos)
    {
        throw IOException("Chiller write temperature ["+Converter::convertToString(dValue)+"] failed for unknown response [" + strResponse+"]");
    }
    return true;
}

bool ChillerMicatsGEX30::readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo)
{
    Cmd cmd = m_cmd[nChannelNum];
    string strCommand = cmd.m_strAddress + CheckCalculationTool::GetLRCCode(cmd.m_strAddress);
    strCommand = StrTool::toUpper(strCommand);
    //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "*****ChillerMicatsGEX30 readDouble send command is  **" +strCommand);
    //string strRes = getCommandResult(strCommand, m_timeOut);
    string strRes = getFixCommandResult(strCommand,50,53,5);
    //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "*****ChillerMicatsGEX30 readDouble get readback is  **" +strRes);
    //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " channelNum is "+Converter::convertToString(nChannelNum));
    int nPos = strRes.find(":", 0);
    if(nPos == string::npos)
    {
        throw IOException("Chiller read temperature failed for unknown response [" + strRes+"]");
    }
    else
    {
        int nValue = 0;
        if(nChannelNum == 3)
        {
            string strValue = strRes.substr(nPos+11, 4);
            if(!Hex::stringToHex(&nValue, strValue))
            {
                throw IOException("Chiller read temperature failed for can't convert response ["+strValue+"] to double value.");
            }
            else
            {
                *pValue = nValue * 220.0/65535.0-60;//value range is from -60 to 160,see the manual
            }
        }
        else if(nChannelNum == 4)
        {
            string strValue = strRes.substr(nPos+23, 4);
            if(!Hex::stringToHex(&nValue, strValue))
            {
                throw IOException("Chiller read temperature failed for can't convert response ["+strValue+"] to double value.");
            }
            else
            {
                *pValue = nValue * 20/65535.0;//value range is from 0 to 20,see the manual
            }
        }
        else if(nChannelNum == 5)
        {
            string strValue = strRes.substr(nPos+27, 4);
            if(!Hex::stringToHex(&nValue, strValue))
            {
                throw IOException("Chiller read temperature failed for can't convert response ["+strValue+"] to double value.");
            }
            else
            {
                *pValue = nValue * 10/65535.0;//value range is from 0 to 10,see the manual
            }
        }
        return true;
    }
}

bool ChillerMicatsGEX30::readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
    Cmd cmd = m_cmd[nChannelNum];
    string strCommand = cmd.m_strAddress + CheckCalculationTool::GetLRCCode(cmd.m_strAddress);
    strCommand = StrTool::toUpper(strCommand);
    //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "*****ChillerMicatsGEX30 readInt send command is  **" +strCommand);
    //string strRes = getCommandResult(strCommand, m_timeOut);
    string strRes = getFixCommandResult(strCommand,50,53,5);
    //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "*****ChillerMicatsGEX30 readInt get readback is  **" +strRes);
    //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " channelNum is "+Converter::convertToString(nChannelNum));
    int nPos = strRes.find(":", 0);
    if(nPos == string::npos)
    {
        throw IOException("Chiller read status failed for unknown response [" + strRes+"]");
    }
    else
    {
        int nTempValue = 0;
        if(nChannelNum == 6 ||nChannelNum == 7)//read fault or warn
        {
            string strValue = strRes.substr(nPos+7, 4);
            if(!Hex::stringToHex(&nTempValue, strValue))
            {
                throw IOException("Chiller read status failed for can't convert response ["+strValue+"] to integer value.");
            }
            else
            {
                int nTmp;
                nTmp = (nTempValue & cmd.m_nDeal) != 0;
                *pValue = nTmp;
                if(nTmp)
                {
                    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "*****ChillerMicatsGEX30 get fault or warn**");
                }
            }
        }
        else if(nChannelNum == 8)//read local or remote
        {
            string strValue = strRes.substr(nPos+15, 4);
            if(!Hex::stringToHex(&nTempValue, strValue))
            {
                throw IOException("Chiller read status failed for can't convert response ["+strValue+"] to integer value.");
            }
            else
            {
                int nTmp;
                nTmp = (nTempValue & cmd.m_nDeal) != 0;
                *pValue = nTmp;
            }
        }
        else if(nChannelNum == 9)//read alarm
        {
            string strValue = strRes.substr(nPos+15, 4);
            if(!Hex::stringToHex(&nTempValue, strValue))
            {
                throw IOException("Chiller read status failed for can't convert response ["+strValue+"] to integer value.");
            }
            else
            {
                int nTmp;
                nTmp = (nTempValue & cmd.m_nDeal) != 0;
                *pValue = nTmp;
                if(nTempValue & 0x8000)
                {
                    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,"ChillerMicatsGEX30 has alarm.Detail is fluid level fault");
                }
                if(nTempValue & 0x4000)
                {
                    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,"ChillerMicatsGEX30 has alarm.Detail is fluid flow fault");
                }
                if(nTempValue & 0x2000)
                {
                    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,"ChillerMicatsGEX30 has alarm.Detail is fluid resistivity fault");
                }
                if(nTempValue & 0x1000)
                {
                    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,"ChillerMicatsGEX30 has alarm.Detail is facility water fault");
                }
                if(nTempValue & 0x0800)
                {
                    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,"ChillerMicatsGEX30 has alarm.Detail is fuse fault");
                }
            }

        }
        else if(nChannelNum == 10)//read run or stop status
        {
            string strValue = strRes.substr(nPos+15, 4);
            if(!Hex::stringToHex(&nTempValue, strValue))
            {
                throw IOException("Chiller read status failed for can't convert response ["+strValue+"] to integer value.");
            }
            else
            {
                int nTmp;
                nTmp = (nTempValue & cmd.m_nDeal) != 0;
                *pValue = nTmp;
                /**
                if(nTmp)
                {
                    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "*****ChillerMicatsGEX30 status is running**");
                }
                else
                {
                    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "*****ChillerMicatsGEX30 status is stopped**");
                }
                **/
            }
        }
        return true;
    }
}

bool ChillerMicatsGEX30::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
    string strCommand = m_cmd[nChannelNum].m_strAddress;
    if(nValue == 1)
    {
        strCommand += "8000";
    }
    else
    {
        strCommand += "0000";
    }
    strCommand += CheckCalculationTool::GetLRCCode(strCommand);
    strCommand = StrTool::toUpper(strCommand);//need test to decide if keep it
    //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + "*****ChillerMicatsGEX30 start/stop command is **" +strCommand);
    sendCommandOnly(strCommand);
    return true;
}

void ChillerMicatsGEX30::initChs(DeviceNode<ChillerMicatsGEX30> *pNode)
{
    pNode->registerWriteCh(1, &ChillerMicatsGEX30::writeInt);
    pNode->registerWriteCh(2, &ChillerMicatsGEX30::writeDouble);
    for(int i = 3; i<=5; ++i)
    {
        pNode->registerReadCh(i, &ChillerMicatsGEX30::readDouble);
    }
    for(int i = 6; i<=10; ++i)
    {
        pNode->registerReadCh(i, &ChillerMicatsGEX30::readInt);
    }
    pNode->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &ChillerMicatsGEX30::getStatus);//added by mujy [v1.0.8]
}

void ChillerMicatsGEX30::initDevice()
{
    cout<<"Start Scan Chiller...."<<endl;
    //say hello to chiller
    double dTemp;
    try
    {
        readDouble(3,&dTemp,DoubleTypeInfo());//3 read temprature
    }
    catch(exception &ex)
    {
        cout<<"Scan chiller failed. Communication abnormal!"<<endl;
        throw;
    }
    cout<<"Scan Chiller Successfully...."<<endl;
}

void ChillerMicatsGEX30::init()
{
    DeviceNode<ChillerMicatsGEX30> *pNode = new DeviceNode<ChillerMicatsGEX30>(m_pollPeriod, this);
    DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
    if(!isSimulated())
    {
        initChs(pNode);
        initDevice();
    }
}

IMPLEMENT_DYNAMIC(ChillerMicatsGEX30, SerialDevice )

BEGIN_MSG_MAP(ChillerMicatsGEX30, SerialDevice )
    SET_V( init, ChillerMicatsGEX30 )
END_MSG_MAP
