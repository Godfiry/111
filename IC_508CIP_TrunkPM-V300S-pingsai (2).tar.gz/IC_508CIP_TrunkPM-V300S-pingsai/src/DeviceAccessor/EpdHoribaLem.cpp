/********************************************************************
** Copyright (c) 2020, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: EpdHoribaLem.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2020-4-20   zhangyy create
**      
*********************************************************************/
#include "EpdHoribaLem.h"
#include <string.h>
#include "DeviceManager.h"
#include "SysLogger.h"
#include "IStringList.h"
#include "Converter.h"
#include "ConfigException.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;

EpdHoribaLem::Cmd EpdHoribaLem::m_commands[]={{0, 0, "",0}, //Reserved
	{1, '0', "",14},  //(channel=10) Get Sensor Status	
	{3, '0', "",14},  //(channel=31) Get EPD RecipeList (ConfigureList)
	{2, '5', "",0 },  //(channel=3) Start Measurement,need send 5 parameters: m_strConfigName,m_strWaferID,m_strLotID,m_strCassetID,m_strStepName
	{4, '1',"STOP",19} //(channel=4) Stop Run Action
};

EpdHoribaLem::EpdHoribaLem()
{
	m_timeOut = 8;//s
	m_checkInterval = 100;//ms	
	m_nEpdStatus = 0;
	m_nEndPoint = 0;
	m_dEndPointTime = 0.0;
	m_strError = "";
	m_strEventError = "";
	m_bWaiting = false;
	m_strConfigName = "";
	m_strWaferID = "5";
	m_strLotID = "Lot ID";
	m_strCassetID = "Cassette ID ";
	m_strStepName = "1";//default = 1
	m_strSenderID = "SIM";
	m_strReceiverID = "";
	m_strConfigList = "";
	m_bLogOn = false;
}

EpdHoribaLem::~EpdHoribaLem()
{

}

bool EpdHoribaLem::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
	
	if (!isConnected())//not connect
	{
		
		throw IOException("device is not connected! ");
	}
	
	//Get necessary parameters from struct
	Cmd cmd = m_commands[nChannelNum];
	int nCmdID = cmd.nCmdID;
	char cParamNum = cmd.cParamNum;
	string strBody = cmd.strBody;
	int nCmdLength = cmd.nCmdLength;
	
	//Begin to build Command: x 0 x 0 xxx 0 xxx 0 x 0 \r \n
	char pCommand[100] = {0};
	pCommand[0]= '1';
	pCommand[1]= 0x00;
	pCommand[2]= '1';
	pCommand[3]= 0x00;
	memcpy(pCommand+4, m_strSenderID.c_str(),m_strSenderID.length());
	pCommand[7]= 0x00;
	memcpy(pCommand+8, m_strReceiverID.c_str(),m_strReceiverID.length());
	pCommand[9]= 0x00;
	pCommand[10]= cParamNum;
	pCommand[11]= 0x00;
	pCommand[12]= 0x0D;
	pCommand[13]= 0x0A;
	
	//Declare parameters for [start] command
	string strConfigInfo[]={m_strConfigName, m_strWaferID, m_strLotID, m_strCassetID, m_strStepName};
	vector<string> vConfigInfo(strConfigInfo,strConfigInfo+5);
	vector<string>::iterator iter;
	int nConfigLenth = 0;
	int i = 0;
	switch(nCmdID)
	{
		case 1: //Get Sensor Status
			if(m_bLogOn)
			{
				cout<<"start to Get Sensor Status====sendData"<<endl;
				for(int j =0;j<14;j++)
				{
					cout<<"pCommand["<<j<<"] = "<<pCommand[j]<<endl;
				}
			}
			sendCmd(pCommand, nCmdLength);
			break;
		
		case 2: //Start Measurement
			m_nEndPoint = 0;
			m_dEndPointTime = 0.0;
			pCommand[2]= '2'; //CommandID = 2
			//******Build Start command**************
			
			for(iter = vConfigInfo.begin(); iter != vConfigInfo.end(); ++iter)
			{
				//cout<<*iter<<""<<endl;
				//cout<<"(*iter).length() = "<<(*iter).length()<<endl;
				memcpy(pCommand+i+12+nConfigLenth, (*iter).c_str(),(*iter).length());
				nConfigLenth += (*iter).length();
				pCommand[12+i+nConfigLenth]= 0x00;
				i++;
			}
			pCommand[12+i+nConfigLenth]= 0x0D;
			pCommand[13+i+nConfigLenth]= 0x0A;
			
			nCmdLength = 19 + m_strConfigName.length()+m_strWaferID.length()+m_strLotID.length()+m_strCassetID.length()+m_strStepName.length();
			if(m_bLogOn)
			{
				cout<<"nCmdLength = "<<nCmdLength<<endl;
				cout<<"nConfigLenth = "<<nConfigLenth<<endl;
				cout<<"m_strConfigName.length() = "<<m_strConfigName.length()<<endl;
				cout<<"m_strWaferID.length() = "<<m_strWaferID.length()<<endl;
				cout<<"m_strLotID.length() = "<<m_strLotID.length()<<endl;
				cout<<"Cassette ID's length = "<<m_strCassetID.length()<<endl;
				cout<<"m_strStepName.length() = "<<m_strStepName.length()<<endl;
				cout<<"start to start EPD====sendData"<<endl;
				for(int k =0;k<53;k++)
				{
					cout<<"pCommand["<<k<<"] = "<<pCommand[k]<<endl;
				}		
			}
			sendCmd(pCommand, nCmdLength);
			break;
		
		case 3: //Get EPDRecipeList
			pCommand[2]= '3';//CommandID = 3
			if(m_bLogOn)
			{
				cout<<"start to Get EPDRecipeList====sendData"<<endl;
				for(int z =0;z<14;z++)
				{
					cout<<"pCommand["<<z<<"] = "<<pCommand[z]<<endl;
				}
			}
			sendCmd(pCommand, nCmdLength);
			break;
			
		case 4: //Stop Run Action
			pCommand[2]= '4';//CommandID = 4
			memcpy(pCommand+12, strBody.c_str(),strBody.length());
			pCommand[16]= 0x00;
			pCommand[17]= 0x0D;
			pCommand[18]= 0x0A;
			if(m_bLogOn)
			{
				cout<<"start to Stop EPD====sendData"<<endl;
				for(int y =0;y<19;y++)
				{
					cout<<"pCommand["<<y<<"] = "<<pCommand[y]<<endl;
				}
			}
			sendCmd(pCommand, nCmdLength);
			break;
			
		default:
			break;
	}
	return true;
}

bool EpdHoribaLem::writeString(int nChannelNum, std::string pValue, const StringTypeInfo &typeInfo)
{
	switch(nChannelNum)
	{
		case 40: //Config Name (Recipe Name)
			m_strConfigName = pValue;
			break;
			
		case 41: //lot
			m_strLotID = pValue;
			break;
			
		case 42: //slot(Cassette ID)
			m_strCassetID = pValue;
			break;
		
		case 43: // wafer
			m_strWaferID = pValue;
			break;
					
		case 45: //step
			m_strStepName = pValue;
			break;
	}
	return true;
}

bool EpdHoribaLem::readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
	
	if (!isConnected() && nChannelNum != 10)//not epdstatus
	{
		
		throw IOException("device is not connected! ");
	}
	switch(nChannelNum)
	{
		case 10: //epdstatus
			//cout<<"Begin to writeInt"<<endl;
			writeInt(1, 0, IntTypeInfo());//use m_commands[1]
			//cout<<"m_nEpdStatus = "<<m_nEpdStatus<<endl;	
			*pValue = m_nEpdStatus;
			break;
			
		case 11: //EndPoint
			*pValue = m_nEndPoint;
			break;
	}
	return true;
}

bool EpdHoribaLem::readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo)
{
	
	if (!isConnected())
	{
		
		throw IOException("device is not connected! ");
	}

	if(nChannelNum == 20)	
	{
		*pValue = m_dEndPointTime;
	}
	else
	{
		*pValue = getTraceData("EPDTrend" + Converter::convertToString(nChannelNum - 20));
	}
	return true;	
}

bool EpdHoribaLem::readString(int nChannelNum, std::string *pValue, const StringTypeInfo &typeInfo)
{
	
	if (!isConnected())
	{
		throw IOException("device is not connected! ");
	}
	
	switch(nChannelNum)
	{
		case 30: // Event Error
			*pValue = m_strEventError;
			break;
			
		case 31: //Get EPDRecipeList
			m_strConfigList = "";	
			writeInt(2, 0, IntTypeInfo());//use m_commands[2]	
			*pValue = m_strConfigList;
			break;
	}
	return true;
}
void EpdHoribaLem::sendCmd(const char *pData, int nLength)
{
	//Init parameters for [sendData]
	//cout<<"Begin to sendCmd"<<endl;	
	m_bWaiting = true;
	m_strError = "";
	sendData(pData, nLength);
	int t_leftcount = m_timeOut*1000/m_checkInterval;
	while(t_leftcount >= 0)
	{
		if(!m_bWaiting)
		{
			if(m_strError != "")
			{
				m_nEpdStatus = 3;//NotReady
				throw IOException(m_strError);
			}	
			else
			{
				//cout<<"m_strError == kong"<<endl;
				return;
			}		
		}
		usleep(m_checkInterval * 1000);
		--t_leftcount;
	}
	throw IOException("Command read_back TimeOut");
}



double EpdHoribaLem::getTraceData(const std::string &strDataName)
{
	if(m_MapTraceDatas.find(strDataName) != m_MapTraceDatas.end())
	{
		return m_MapTraceDatas[strDataName];
	}
	else
	{
		throw IOException("Invalid TraceDataName = "+ strDataName);
	}
}

void EpdHoribaLem::flush()
{
	memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
	if(!readData(m_recvBuffer, sizeof(m_recvBuffer)))
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": reading failed in flush()");						
	}	
}

void EpdHoribaLem::acceptData()
{
	memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
	if(readData(m_recvBuffer, sizeof(m_recvBuffer)))
	{
		if(m_bLogOn)
		{
			for(int i =0;i<34;i++)
			{
				cout<<"m_recvBuffer["<<i<<"] = "<<m_recvBuffer[i]<<endl;
			}
			cout<<"***********splitNul(m_recvBuffer,2) = "<<splitNul(m_recvBuffer,2)<<endl;
		}
		if(splitNul(m_recvBuffer,2).find("5",0) != string::npos) //CommandID = 5, Reply Event
		{
			//cout<<"parseEvent!!!!!!"<<endl;
			parseEvent();
		}
		else
		{
			if(m_bWaiting)
			{
				//cout<<"parseCmd!!!!!!"<<endl;
				parseCmd();
				m_bWaiting = false;
			}
		}	
	}
	else
	{	
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": EpdHoribaLem reading failed in acceptData()");		
		if(m_bWaiting)
		{	
			m_strError = "read_back from device failed";
			m_bWaiting = false;
		}
	}	
}
//For example: Array[] = ab cde fg
//Then: vAftSplitResult[0] = ab ; vAftSplitResult[1] = cde ; vAftSplitResult[2] = fg ;
std::string EpdHoribaLem::splitNul(char Array[], unsigned int nDataSegmentNum)
{
	std::string strAftSplitNul = "";
	char *pArray = Array;
	vector<string> vAftSplitResult;
	for(int i=0; i<100000; i++)//100000 depending on the number of RecipeList in EPD
	{
		string strArray = pArray;
		pArray = pArray +strArray.size() + 1;
		if(strArray.size() != 0)
		{
			vAftSplitResult.push_back(strArray);
		}
		else
		{
			pArray = pArray + 1; // To skip the second NUL
			strArray = pArray;
			if(strArray.size() == 0)
			{
				break;
			}	
		}	
	}
	if(nDataSegmentNum > vAftSplitResult.size())
	{
		strAftSplitNul = "";
	}
	else
	{
		strAftSplitNul = vAftSplitResult[nDataSegmentNum - 1];
	}
	return strAftSplitNul;
}

void EpdHoribaLem::setEventError(const std::string &strError)
{
	m_strEventError = strError;
}
		
std::string EpdHoribaLem::getEventError()
{
	return m_strEventError;
}

void EpdHoribaLem::parseCmd()
{
	int nLeftcount = m_timeOut*1000/m_checkInterval;
	while(nLeftcount >= 0)
	{
		if(m_bLogOn)
		{
			cout<<"splitNul(m_recvBuffer,1);"<<splitNul(m_recvBuffer,1)<<endl;
			cout<<"splitNul(m_recvBuffer,2);"<<splitNul(m_recvBuffer,2)<<endl;
			cout<<"splitNul(m_recvBuffer,3);"<<splitNul(m_recvBuffer,3)<<endl;
			cout<<"splitNul(m_recvBuffer,4);"<<splitNul(m_recvBuffer,4)<<endl;
			cout<<"splitNul(m_recvBuffer,5);"<<splitNul(m_recvBuffer,5)<<endl;
			cout<<"splitNul(m_recvBuffer,6);"<<splitNul(m_recvBuffer,6)<<endl;
			cout<<"splitNul(m_recvBuffer,7);"<<splitNul(m_recvBuffer,7)<<endl;
			cout<<"splitNul(m_recvBuffer,8);"<<splitNul(m_recvBuffer,8)<<endl;
			cout<<"splitNul(m_recvBuffer,9);"<<splitNul(m_recvBuffer,9)<<endl;
			cout<<"splitNul(m_recvBuffer,10);"<<splitNul(m_recvBuffer,10)<<endl;
			cout<<"splitNul(m_recvBuffer,11);"<<splitNul(m_recvBuffer,11)<<endl;
			cout<<"splitNul(m_recvBuffer,12);"<<splitNul(m_recvBuffer,12)<<endl;
			cout<<"splitNul(m_recvBuffer,13);"<<splitNul(m_recvBuffer,13)<<endl;
			cout<<"splitNul(m_recvBuffer,14);"<<splitNul(m_recvBuffer,14)<<endl;
		}
		
		std::string strRecvError = splitNul(m_recvBuffer,6);// Error Code	
		int nRecvError = -1;
		if(!Converter::stringToInt(nRecvError,strRecvError))
		{
			throw IOException("readback is not a valid int value:" + strRecvError);
		}
		//cout<<"nRecvError = "<<nRecvError<<endl;
		if(nRecvError != 0 && nRecvError != 20)//Error Code != 0 && Error Code != 20
		{
			std::string strRecvErrDetail = splitNul(m_recvBuffer,7);//Error Description
			m_strError = "parseCmd() got error code. Error Description is: "+ strRecvErrDetail;
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + " in parseCmd() got ErrorCode " + strRecvError);
			return;
		}
		if(splitNul(m_recvBuffer,2).find("101",0) != string::npos) //Get EPDStatus,reply code = 0(Ready)
		{
			if(nRecvError == 0)
			{
				m_nEpdStatus = 2;//Ready
				return;
			}
			else
			{
				m_nEpdStatus = 3;//NotReady
				return;
			}
		}	
		if(splitNul(m_recvBuffer,2).find("102",0) != string::npos) //start Recipe.
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " start Recipe ");
			return;
		}
		if(splitNul(m_recvBuffer,2).find("104",0) != string::npos) //Stop Run.
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + " Stop Run ");
			m_nEndPoint = 0;// Stop EPD successfully, EndPoint = 0
			return;
		}
		if(splitNul(m_recvBuffer,2).find("103",0) != string::npos) //Get EPDRecipeList.
		{
			for(unsigned int i=8;i <= sizeof(m_recvBuffer);++i)
			{
				if(splitNul(m_recvBuffer,i) != "")
				{
					if(splitNul(m_recvBuffer,i) == "\x0D\x0A")
					{
						break;
					}
					m_strConfigList += splitNul(m_recvBuffer,i);
					m_strConfigList +=",";
				}
			}
			cout<<"m_strConfigList = "<<m_strConfigList<<endl;
			return;
		}
			
		usleep(m_checkInterval*1000);
		flush();
		--nLeftcount;
	}
	m_strError = "parseCmd() got Unknown read_back!";
}

void EpdHoribaLem::parseEvent()
{
	std::string strReplyEvent = splitNul(m_recvBuffer,6);
	cout<<"The reply Event is "<<strReplyEvent<<endl;//for test
	if(strReplyEvent.find("TRACE") != string::npos)
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":EpdHoribaLem got event TRACE DATA:"+ strReplyEvent);
		vector<string> strTraceEvent = IStringList::split(strReplyEvent,"\x20"); //space
		cout<<"The size of Trace Event"<<strTraceEvent.size()<<endl;//need test
		//strTraceEvent[0]=TRACE   strTraceEvent[1]=time(ms):  strTraceEvent[2]=xxx  strTraceEvent[3]=data1  strTraceEvent[4]=data2 ...strTraceEvent[10]=data8
		double dTraceEvent = 0.0;
		string strEPDTrendNum = "";
		
		if(!Converter::stringToDouble(m_dEndPointTime, strTraceEvent[2]))//Get Measurement elapse time, npos=9,length = default
		{
			throw IOException("Readback EndpointTime is not a valid double value:" + strTraceEvent[2]);
		}
		else //for test
		{
			cout<<"Readback EndpointTime = "<<m_dEndPointTime<<endl;
		}
		
		for(unsigned int i=3; i < strTraceEvent.size()-3; ++i)
		{
			if(!Converter::stringToDouble(dTraceEvent, strTraceEvent[i]))
			{
				throw IOException("read back value is not a valid double value:" + strTraceEvent[i]);
			}
			else
			{
				strEPDTrendNum = "EPDTrend" + Converter::convertToString(i-2);
				m_MapTraceDatas[strEPDTrendNum] = dTraceEvent;
			}
		}
	}
	if(strReplyEvent =="ENDPOINT")
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":EpdHoribaLem got event ENDPOINT:"+ strReplyEvent);
		m_nEndPoint = 1;
		//readEndpointTime
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":EpdHoribaLem got event ENDPOINT and endtime is " + Converter::convertToString(m_dEndPointTime));
	}
	else if(strReplyEvent =="WARNING1" ||strReplyEvent =="WARNING2"||strReplyEvent =="ALARM")
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":EpdHoribaLem got event WARNING or ALARM:"+ strReplyEvent);
		setEventError(strReplyEvent);
		m_nEpdStatus = 3;//NotReady
		flush();
	}
	else if(strReplyEvent =="RUN_ENDED")
	{
		m_nEpdStatus = 2;//Ready
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":EpdHoribaLem got event RUN_ENDED:"+ strReplyEvent);
		flush();
	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getDeviceName() + ":EpdHoribaLem got UNKNOWN EVENT:" + strReplyEvent);
		flush();
	}
}

void EpdHoribaLem::initChannels(DeviceNode<EpdHoribaLem> *pNode)
{
	pNode->registerWriteCh(3,&EpdHoribaLem::writeInt);//Start Measurement
	pNode->registerWriteCh(4,&EpdHoribaLem::writeInt);//Stop Measurement
	pNode->registerReadCh(10,&EpdHoribaLem::readInt);//Read EpdStatus
	pNode->registerReadCh(11,&EpdHoribaLem::readInt);//Read EndPoint
	for (int i = 20; i <= 28; i++)//Read EPDTime & TrendData1~TrendData8
	{
		pNode->registerReadCh(i,&EpdHoribaLem::readDouble);
	}
	pNode->registerReadCh(30,&EpdHoribaLem::readString);//Read Error
	pNode->registerReadCh(31,&EpdHoribaLem::readString);//Read EPDRecipeList
	
	for (int i = 40; i <= 45; i++)
	{
		pNode->registerWriteCh(i,&EpdHoribaLem::writeString);
	}
	
}
void EpdHoribaLem::initDevice()
{
	
	cout<<"Start Scan Horiba EPD ...."<<endl;
	int nTemp;
	try
	{
		readInt(10,&nTemp,IntTypeInfo()); //read EPDStatus
	}
	catch(exception &ex)
	{
		cout<<"Scan Horiba EPD failed. Communication abnormal!"<<endl;
		throw;
	}
	cout<<"Scan Horiba EPD Successfully...."<<endl;
	
}


void EpdHoribaLem::init()
{
	DeviceNode<EpdHoribaLem> *pNode = new DeviceNode<EpdHoribaLem>(m_pollInterval, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum,pNode);	
	if(!isSimulated())
	{
		initChannels(pNode);
		TCPDeviceHoriba::init();
		initDevice();
		for(int i=0; i<8; ++i)
		{		
			m_MapTraceDatas.insert(std::pair<std::string,double>("EPDTrend" + Converter::convertToString(i+1),0.0));
		}
	}
}

std::string EpdHoribaLem::getDeviceName()
{
	return "EPD";
}

void EpdHoribaLem::setNameOfSPCV(const std::string &strName)
{
	if(strName == "")
	{
		throw ConfigException("name can not be empty");
	}
	m_strReceiverID = strName;
}

void EpdHoribaLem::setLogOn(bool bFlag)
{
	m_bLogOn = bFlag;
}
IMPLEMENT_DYNAMIC(EpdHoribaLem, TCPDeviceHoriba )

BEGIN_MSG_MAP( EpdHoribaLem, TCPDeviceHoriba )
	SET_S( setNameOfSPCV, EpdHoribaLem ) 	 
	SET_B( setLogOn, EpdHoribaLem)
END_MSG_MAP
