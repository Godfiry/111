/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AEGeneratorDriver.cpp
** Description:  
** Release: 1.1
** Modification history: 
**                     2014-12-10   bihuijie create
**      
*********************************************************************/

#include "AEGeneratorDriver.h"
#include <string.h>
#include "DeviceManager.h"
#include <iostream>
#include <sys/time.h>
#include <sstream>
#include "Converter.h"
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std;

AEGeneratorDriver::AEGeneratorDriver() : SerialDevice(20, "")
{
    ack[0] = (char) 0x06;
}

AEGeneratorDriver::~AEGeneratorDriver()
{
}

AEGeneratorDriver::Com AEGeneratorDriver::m_commands[] =
{
        {3, 0x01, 4}, //0 setLfPowerOnOff
        {9, 0x1A, 4}, //1 setpulseEnable
        {5, 0x08, 4}, //2 setLfPower
        {5, 0x60, 4}, //3 setPulseDuty
        {7, 0x5D, 4}, //4 setPulseFreq
        {3, 0xA5, 5}, //5 getLfPower
        {3, 0xA6, 5}, //6 getLfreflectPower
        {3, 0xC1, 7}, //7 getPulseFreq
        {3, 0xC4, 5}, //8 getPulsDuty
        {4, 0x0E, 4}, //9 modecontrol
        {3, 0x9B, 4}, //10 mode
        {5, 0x08, 4}, //11 setLfPower HALO UNITS
        {3, 0xA5, 5}, //12 getLfPower HALO UNITS
        {3, 0xA6, 5}, //13 getLfreflectPower HALO UNITS
        {4, 0x03, 4}, //14 set regulationmode Forward/load
        {7, 0x76, 4}, //15 set control loop gain
        {5, 0xF8, 5}, //16 get control loop gain

        {9, 0x1A, 4}, //17 set wave mode(8) 0-CW/1-Pulse
        {6, 0x20, 4}, //18 set CEX
        {5, 0xAC, 7}, //19 get wave mode(8): 0-CW/1-Pulse
        {4, 0x84, 5}, //20 get CEX
        {5, 0xA2, 7},//21  read SetpointStatusDI
        {5, 0xA2, 7}, //22 read OverTemperature fault
        {5, 0xA2, 7}, //23 read interlock
        {5, 0xA2, 7}, //24 read Fault Present
        {5, 0xA2, 7}, //25 read Warning present

        //added by taohao [1.1.51] for 2M BGP2502
        {7, 0x2C, 4}, //26 set minimum tuning frequency
        {7, 0x2D, 4}, //27 set maximum tuning frequency
        {7, 0x2E, 4}, //28 set tuning start frequency
        {4, 0x30, 4}, //29 set fixed or variable frequency mode
        {7, 0x3C, 4}, //30 set tune delay
        {7, 0x3D, 4}, //31 set fixed frequency
        {3, 0x90, 7}, //32 read minimum tuning frequency
        {3, 0x91, 7}, //33 read maximum tuning frequency
        {3, 0x92, 7}, //34 read tuning start frequency
        {3, 0x93, 7}, //35 get generator actual frequency
        {3, 0x94, 4}, //36 read fixed or variable frequency mode
        {3, 0x9A, 4}, //37 read regulation mode
        {3, 0xA0, 7}, //38 read tune delay
        {3, 0xA1, 7}, //39 read fixed frequency
        //{3, 0xA4, 7}, //40 read setpoint and regulation mode
        {9,0x76,4}, //40 set Frequency Step Min   //add by zhangpf[v1.6.1]
        {9,0x76,4}, //41 set Frequency Step Max
        {7,0x76,4}, //42 set Low tuning threshold
        {7,0x76,4}, //43 set High tuning threshold
        {7,0x76,4}, //44 set Step Up Gain
        {7,0x76,4}, //45 set Step Down Gain
        {7,0x76,4}, //46 set Maximum tuning count
        {7,0x76,4}, //47 set Tuning Step Time
        {7,0x3A,4},//48 set retuning threshold
        //read AutoFrequency  add by zhangpf[v1.6.1]
        {5,0xF8,7}, //49 get Frequency Step Min
        {5,0xF8,7}, //50 get Frequency Step Max
        {5,0xF8,5}, //51 get Low tuning threshold
        {5,0xF8,5}, //52 get High tuning threshold
        {5,0xF8,5}, //53 get Step Up Gain
        {5,0xF8,5}, //54 get Step Down Gain
        {5,0xF8,5}, //55 get Maximum tuning count
        {5,0xF8,5}, //56 get Tuning Step Time
        {3,0x9E,7} //57 get retuning threshold
};

bool AEGeneratorDriver::sendCommand(char *msg, char *response, int msg_timeout,int length)
{
    //sendCommandOnly(msg,MESS_LEN);
    //getResultOnly(response,length+1,msg_timeout);
     string s1=std::string(msg,9);
     //cout<<s1<<endl;
     string s2=getCommandResult(s1,m_timeOut);
     
     strcpy(response,s2.c_str());
    if(response[0] != 0x06)
    {
            cout<<"sendCommand response "<<hex<<(int)response[0]<<" "<<(int)response[1]<<" "<<(int)response[2]<<" "<<(int)response[3]<<" "<<(int)response[4]<<endl;
        throw IOException("AE Generator send packet's verification is wrong");
    }
    else if(response[3] != 0x00 && response[3] != 0x02)
    {
            cout<<"sendCommand response "<<hex<<(int)response[0]<<" "<<(int)response[1]<<" "<<(int)response[2]<<" "<<(int)response[3]<<" "<<(int)response[4]<<endl;
           throw IOException("AE Generator's response(CSR) codes was not accepted");
    }
      //sendCommandOnly(ack,1); 
   return true;
}

bool AEGeneratorDriver::sendCommandAck(char *msg, char *response, int msg_timeout,int resplen,int msglen)
{
     int ret=getCommandResult(msg,msglen,response,resplen,m_timeOut);
       
    if(response[0] != 0x06 || ret <= 0)
    {
            cout<<"sendCommand response "<<hex<<(int)response[0]<<" "<<(int)response[1]<<" "<<(int)response[2]<<" "<<(int)response[3]<<" "<<(int)response[4]<<endl;
        throw IOException("AE Generator send packet's verification is wrong");
    }
    else if(response[3] != 0x00 && response[3] != 0x02)
    {
            cout<<"sendCommand response "<<hex<<(int)response[0]<<" "<<(int)response[1]<<" "<<(int)response[2]<<" "<<(int)response[3]<<" "<<(int)response[4]<<endl;
           throw IOException("AE Generator's response(CSR) codes was not accepted");
    }
   sendCommandOnly(ack,1); 
   return true;
}
bool AEGeneratorDriver::readCommand(char *msg, char *response, int msg_timeout,int resplen,int msglen)
{
    int ret=getCommandResult(msg,msglen,response,resplen,m_timeOut);
    
    if(response[0] != 0x06 || ret<= 0)
    {
        throw IOException("AE Generator send packet's verification is wrong");
    }
    sendCommandOnly(ack,1);
   return true;
}

bool AEGeneratorDriver::writeInt(int channelNum, int value, const IntTypeInfo &typeInfo)
{
    Com com = m_commands[channelNum];

    memset(message, 0, MESS_LEN);
    memset(resp, 0, RESP_LEN);
    message[0] = (char) (com.m_type + 5);
    switch (com.m_type)
    {
        case 3:
            if (value == 0)
            {
                message[1] = 0x01;
            }
            else if (value == 1)
            {
                message[1] = 0x02;
            }
            message[2] = message[0] ^ message[1];
            break;
        case 9:
            if (channelNum == 17) // set CW
            {
                message[1] = com.m_cmd;
                message[2] = 0x08;
                message[3] = 0x00;
                message[4] = (char) (0x00 + value); // 0-CW, 1-Pulse
                message[5] = 0x00;
                message[6] = 0x00;
                message[7] = 0x00;
                message[8] = message[0] ^ message[1] ^ message[2] ^ message[3] ^ message[4];
            }
            break;
        case 4:
            message[1] = com.m_cmd;
            if(channelNum == 9)
            {
                if (value == 0)
                {
                    message[2] = 0x04;//User
                }
                else if (value == 1)
                {
                    message[2] = 0x02;//host
                }
            }
            else if(channelNum == 29)
            {
                if (value == 0)
                {
                    message[2] = 0x00; //fixed
                }
                else if (value == 1)
                {
                    message[2] = 0x01;//variable
                }
            }

            message[3] = message[0] ^ message[1] ^ message[2];
            break;
        case 6: //set CEX
            //message[1] = com.m_cmd;
            if (channelNum == 18)
            {
                int tmpint = 0;
                message[1] = com.m_cmd;
                message[2] = 0x00;
                tmpint = value * 10;
                message[3] = (int) tmpint & 0x00ff;
                message[4] = ((int) tmpint >> 8) & 0x00ff;
                message[5] = message[0] ^ message[1] ^ message[3] ^ message[4];
            }
            break;
        case 7:    //set tuning frequency and mode(fixed and variable)   taohao added
            message[1] = com.m_cmd;
            message[2] = (int) value & 0x00ff;
            message[3] = ((int) value >> 8) & 0x00ff;
            message[6] = message[0] ^ message[1] ^ message[2] ^ message[3];
            break;
    }

    return (sendCommandAck(message, resp, m_timeOut, com.m_relen + 1, com.m_type));
}

bool AEGeneratorDriver::writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
    Com com = m_commands[channelNum];
    memset(message, 0, MESS_LEN);
    memset(resp, 0, RESP_LEN);
    message[0] = (char) (com.m_type + 5);
    switch (com.m_type)
    {
        case 5:
            message[1] = com.m_cmd;
            message[2] = (int) value & 0x00ff;
            message[3] = ((int) value >> 8) & 0x00ff;
            message[4] = message[0] ^ message[1] ^ message[2] ^ message[3];
            break;
        case 7:
            if (channelNum == 4 || (channelNum >25 && channelNum < 29) || (channelNum > 29 && channelNum < 32)|| channelNum == 48)
            {
                message[1] = com.m_cmd;
                message[2] = (int) value & 0x00ff;
                message[3] = ((int) value >> 8) & 0x00ff;
                message[6] = message[0] ^ message[1] ^ message[2] ^ message[3];
                break;
            }
            if( ( channelNum >= 42) && (channelNum <= 47) )
            {
                message[1] = com.m_cmd;
                if( channelNum == 43)
                {
                    message[2] = 0x06;
                }
                else if(channelNum == 42)
                {
                    message[2] = 0x07;
                }
                else if(channelNum == 44)
                {
                    message[2] = 0x03;
                }
                else if (channelNum == 45)
                {
                    message[2] = 0x04;
                }
                else if(channelNum == 46)
                {
                    message[2] = 0x08;
                }
                else //channelNum == 47
                {
                    message[2] = 0x16;
                }
                message[4] = (int) value & 0x00ff;
                message[5] = ((int) value >> 8) & 0x00ff;
                message[6] = message[0] ^ message[1] ^ message[2] ^ message[4] ^ message[5];
                break;
            }
            if (channelNum == 15)
            {
                message[1] = com.m_cmd;
                message[2] = 0x4F; //subcommand = 79
                message[4] = (int) value & 0x00ff;
                message[5] = ((int) value >> 8) & 0x00ff;
                message[6] = message[0] ^ message[1] ^ message[2] ^ message[4] ^ message[5];
                break;
            }
        case 9:
            
            if(channelNum == 40 || channelNum == 41)
            {
                message[1] = com.m_cmd;
                if( channelNum == 40)
                {
                    message[2] = 0x01;
                }
                else
                {
                    message[2] = 0x02;
                }
                message[4] = (int) value & 0x00ff;
                message[5] = ((int) value >> 8) & 0x00ff;
                message[8] = message[0] ^ message[1] ^ message[2] ^ message[4] ^ message[5];
                break;
            }
    }
    return (sendCommandAck(message, resp, m_timeOut, com.m_relen + 1, com.m_type));
}

bool AEGeneratorDriver::readInt(int channelNum, int *value, const IntTypeInfo &typeInfo)
{
    Com com = m_commands[channelNum];
    memset(message, 0, MESS_LEN);
    memset(resp, 0, RESP_LEN);
    message[0] = (char) (com.m_type + 5);
    message[1] = com.m_cmd;

    if (channelNum == 10 || channelNum == 21 || channelNum == 22 || channelNum == 23|| channelNum == 24 || channelNum == 25) //read control mode|| status
    {
        message[2] = message[0] ^ message[1];
    }
    else if (channelNum == 19) //read CW mode
    {
        message[2] = 0x08;
        message[4] = message[0] ^ message[1] ^ message[2];
    }
    else if (channelNum == 20) //read CEX
    {
        message[2] = 0x00;
        message[3] = message[0] ^ message[1] ^ message[2];
    }

    if(channelNum == 36) //read Frequence Mode
    {
        message[2] = message[0] ^ message[1];
    }

    int temp = 0;
    if (readCommand(message, resp, m_timeOut, com.m_relen + 1, com.m_type))
    {
        switch (com.m_type)
        {
            case 3:
                if (10 == channelNum) //read control mode
                {
                    temp = (int) resp[3] & 0x00ff;
                    if (temp == 2)
                    {
                        *value = 1;
                    }
                    else if (temp == 4)
                    {
                        *value = 0;
                    }
                    return true;
                }
                else if(37 == channelNum)//read Regulation Mode
                {
                    temp = (int) resp[3] & 0x00ff;
                    if (temp == 6)
                    {
                        *value = 0;
                    }
                    else if (temp == 7)
                    {
                        *value = 1;
                    }
                    else if(temp == 8)
                    {
                        *value = 2;
                    }
                    else if(temp == 9)
                    {
                        *value = 3;
                    }
                    return true;
                }
                else if(36 == channelNum)//read Frequence Mode
                {
                    temp = (int) resp[3] & 0x00ff;
                    if (temp == 0)
                    {
                        *value = 0;
                    }
                    else if (temp == 1)
                    {
                        *value = 1;
                    }
                    return true;
                }
                break;
            case 4: //read CEX
                temp = (((int) (resp[4] & 0x00ff) << 8) & 0xff00) + ((int) resp[3] & 0xff);
                *value = temp / 10;
                return true;
            case 5: // read CW
                  if(19 == channelNum) // read CW mode
                  {
                       *value = (int)resp[3]&0x00ff;
                       return true;
                  }
                else if(21 == channelNum)  //read SetpointStatusDI
                {
                    *value = (int) resp[3] & 0x80;
                    return true;
                }
                else if(22 == channelNum)  //read OverTemperature fault
                {
                    *value = (int) resp[4] & 0x08;
                    return true;
                }
                else if(23 == channelNum)  //read interlock
                {
                    *value = (int) resp[4] & 0x80;
                    return true;
                }
                else if(24 == channelNum)  //24 read Fault Present
                {
                    *value = (int) resp[6] & 0x20;
                    return true;
                }
                else if(25 == channelNum)  //25 read Warning present
                {
                    *value = (int) resp[6] & 0x40;
                    return true;
                }
                break;
        }
    }
    return false;
}

bool AEGeneratorDriver::readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
    Com com = m_commands[channelNum];
    memset(message, 0, MESS_LEN);
    memset(resp, 0, RESP_LEN);
    message[0] = (char) (com.m_type + 5);
    message[1] = com.m_cmd;
    if (channelNum == 16 || (49 <= channelNum && channelNum <= 56 ))
    {
        if(channelNum == 16)
        {
            message[2] = 0x4F;
        }
        else if(channelNum == 49)
        {
            message[2] = 0x01;
        }
        else if(channelNum == 50)
        {
            message[2] = 0x02;
        }
        else if(channelNum == 51)
        {
            message[2] = 0x07;
        }
        else if(channelNum == 52)
        {
            message[2] = 0x06;
        }
        else if(channelNum == 53)
        {
            message[2] = 0x03;
        }
        else if(channelNum == 54)
        {
            message[2] = 0x04;
        }
        else if(channelNum == 55)
        {
            message[2] = 0x08;
        }
        else     //channelNum == 56
        {
            message[2] = 0x16;
        }
        message[4] = message[0] ^ message[1] ^ message[2];
    }
    else
    {
        message[2] = message[0] ^ message[1];
    }
    if (readCommand(message, resp, m_timeOut, com.m_relen + 1, com.m_type))
    {
        *value = (((int) (resp[4] & 0x00ff) << 8) & 0xff00) + ((int) resp[3] & 0xff);
        return true;
    }
    return false;
}

// for HALO UNITS
bool AEGeneratorDriver::writePosition(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
    Com com = m_commands[channelNum];
    memset(message, 0, MESS_LEN);
    memset(resp, 0, RESP_LEN);
    message[0] = (char)(com.m_type +5);
    message[1] = com.m_cmd;
    message[2] = (int)(value*10)&0x00ff;
    message[3] = ((int)(value*10)>>8)&0x00ff;
    message[4] = message[0]^message[1]^message[2]^message[3];

    return(sendCommandAck(message, resp, m_timeOut, com.m_relen+1, com.m_type));
}

// for HALO UNITS
bool AEGeneratorDriver::readPosition(int channelNum,double *value, const DoubleTypeInfo &typeInfo)
{
    Com com = m_commands[channelNum];
    memset(message, 0, MESS_LEN);
    memset(resp, 0, RESP_LEN);
    message[0] = (char)(com.m_type +5);
    message[1] = com.m_cmd;
    message[2] = message[0]^message[1];
    int tmp =0;
         
        //cout<<"sfsdfsdfsdafsdfsadf"<<endl;
      if(readCommand(message , resp, m_timeOut, com.m_relen+1, com.m_type))
      {

          tmp = (((int)(resp[4]& 0x00ff)<<8)&0xff00) +((int)resp[3]&0xff);
          *value =(double) tmp / 10;
          return true;
      }
    return false;
}

bool AEGeneratorDriver::writeForwardLoad(int channelNum,int value,const IntTypeInfo& typeinfo)
{
    Com com = m_commands[channelNum];

    memset(message, 0, MESS_LEN);
    memset(resp, 0, RESP_LEN);
   
    message[0] = (char)(com.m_type +5);
    message[1] = com.m_cmd;
   if(value == 0)
    {
      message[2] = 0x06;
    }
   if(value == 1)
    {
      message[2] = 0x07;
    }
   message[3] = message[0]^message[1]^message[2];
   
   return(sendCommandAck(message, resp, m_timeOut, com.m_relen+1, com.m_type));
   
}

void AEGeneratorDriver::InitChannels(DeviceNode<AEGeneratorDriver> *node)
{
    node->registerWriteCh(0, &AEGeneratorDriver::writeInt);
    node->registerWriteCh(1, &AEGeneratorDriver::writeInt);
    node->registerWriteCh(2, &AEGeneratorDriver::writeDouble); //added by zhangyy for PMNT3013,3156330-036
    node->registerWriteCh(3, &AEGeneratorDriver::writeDouble);
    node->registerWriteCh(4, &AEGeneratorDriver::writeDouble);
    node->registerReadCh(5, &AEGeneratorDriver::readDouble); //added by zhangyy for PMNT3013,3156330-036
    node->registerReadCh(6, &AEGeneratorDriver::readDouble); //added by zhangyy for PMNT3013,3156330-036
    node->registerReadCh(7, &AEGeneratorDriver::readDouble);
    node->registerReadCh(8, &AEGeneratorDriver::readDouble);
    node->registerWriteCh(9, &AEGeneratorDriver::writeInt);
    node->registerReadCh(10, &AEGeneratorDriver::readInt);

    node->registerWriteCh(11, &AEGeneratorDriver::writePosition);
    node->registerReadCh(12, &AEGeneratorDriver::readPosition);
    node->registerReadCh(13, &AEGeneratorDriver::readPosition);
    node->registerWriteCh(14, &AEGeneratorDriver::writeForwardLoad);
    node->registerWriteCh(15, &AEGeneratorDriver::writeDouble); //added by zhangyy[v.17.16]
    node->registerReadCh(16, &AEGeneratorDriver::readDouble);

    node->registerWriteCh(17, &AEGeneratorDriver::writeInt);
    node->registerWriteCh(18, &AEGeneratorDriver::writeInt);
    node->registerReadCh(19, &AEGeneratorDriver::readInt);
    node->registerReadCh(20, &AEGeneratorDriver::readInt);

    for(int i=21;i<26;i++)//added by taohao[1.1.52]
    {
        node->registerReadCh(i,&AEGeneratorDriver::readInt);
    }

    for(int i=26;i<29;i++)
    {
        node->registerWriteCh(i,&AEGeneratorDriver::writeDouble);
    }

    node->registerWriteCh(29,&AEGeneratorDriver::writeInt);//modify by taohao[1.3.0]

    for(int i=30;i<32;i++)
    {
        node->registerWriteCh(i,&AEGeneratorDriver::writeDouble);
    }
    for(int i=32;i<36;i++) //read tuning Freq
    {
        node->registerReadCh(i,&AEGeneratorDriver::readDouble);
    }
    node->registerReadCh(36, &AEGeneratorDriver::readInt);
    node->registerReadCh(37, &AEGeneratorDriver::readInt);
    node->registerReadCh(38,&AEGeneratorDriver::readDouble);
    node->registerReadCh(39,&AEGeneratorDriver::readDouble);
    for(int i=40;i<=48;i++)  //add by zhangpf[v1.6.1]
    {
        node->registerWriteCh(i,&AEGeneratorDriver::writeDouble);
    }
    for(int i=49;i<=57;i++) //read AutoFrequency  add by zhangpf[v1.6.1]
    {
        node->registerReadCh(i,&AEGeneratorDriver::readDouble);
    }
    node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &AEGeneratorDriver::getStatus); //added by mujy [v1.0.8]
}
  
void AEGeneratorDriver::init()
{
    cout<<getName()+"AEGeneratorDriver init start"<<endl;
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "AEGeneratorDriver start");
    DeviceNode<AEGeneratorDriver> *node = new DeviceNode<AEGeneratorDriver>(m_pollPeriod,this);   //modify by zhangpf [1.1.48]
    InitChannels(node);
    DeviceManager::getInstance()->registerNode(m_nodeNum, node);
    cout<<getName()+"AEGeneratorDriver end start"<<endl;
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "AEGeneratorDriver end");
    //char resp[5] = {0};
   // char message[4]={0x09,0x0E,0x02,0x05};
   // sendCommand(message, resp, m_timeOut, 5);
}

IMPLEMENT_DYNAMIC(AEGeneratorDriver, SerialDevice )
BEGIN_MSG_MAP(AEGeneratorDriver, SerialDevice )
    SET_V( init, AEGeneratorDriver )
END_MSG_MAP

