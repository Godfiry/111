 #!/bin/bash

 ##############################################################################
 # Copyright (C) 2008 by Ma ping
 #
 # File: led.sh
 #
 # Date: 2008-11-01
 #
 # Author: Ma ping, <csmaping@126.com>
 # 
 # Version: 0.1
 #
 # Descriptor:
 #   start led
 #
 # Modified:
 #
 ##############################################################################
source /etc/profile

project_path=$(dirname $(readlink -f $0))
cd $project_path

dirs=$(pwd)
echo $dirs
sleep 1

make

read -p "#### Make end, Press <Enter> to exit the terminal!!!"