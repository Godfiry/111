/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					Jan 22, 2008  shenql  create 
**      
***************************************************************************/
#ifndef DISABLEENABLEINFO_H_
#define DISABLEENABLEINFO_H_
#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class DisableEnableInfo : public IntValueInfo
{
public:

		static const int UnInit = -1;
		static const int Disable = 0;
		static const int Enable = 1;

		static const IntTypeInfo typeInfo;

	   DisableEnableInfo():IntValueInfo(-1, typeInfo)
	   {
	   }
	
	   DisableEnableInfo(int i):IntValueInfo(i, typeInfo)
	    {
	    }
	
	   DisableEnableInfo(std::string s):IntValueInfo(s, typeInfo)
	    {
	    }
};


#endif /*DISABLEENABLEINFO_H_*/
