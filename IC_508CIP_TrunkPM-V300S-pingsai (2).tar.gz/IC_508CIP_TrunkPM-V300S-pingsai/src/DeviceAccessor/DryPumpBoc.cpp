/********************************************************************
** Copyright (c) 2019, Beijing Naura Co.,Ltd. All rights reserved.
** File name: DryPumpBoc.cpp
** Description: For BOC dry pump device for RS232 communicational model.
** Release: 1.0
** Modification history: 
** 					2019-08-29   liuxj create
**      
*********************************************************************/

#include "DryPumpBoc.h"
#include "DeviceManager.h"
#include <iostream>
#include <sys/time.h>
#include <sstream>
#include "Converter.h"
#include "SysLogger.h"
#include "ObjectManager.h"
#include "IStringList.h"
#include <string.h>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;

DryPumpBoc::Com DryPumpBoc::m_commands[] = {{"",0},
												//DO: 1~999
												{"!C",20},//1 timeOut=2s; command message: local remote, eg: !C1[CR]: to set remot, see manual page[P24] or [P25];
												{"!P",20},//2 timeOut=2s; command message: Auto(slow) shut down, on, fast shut down, eg: !P1[CR]: to set on, see manual page[P24] or [P27];
												{"!F",20},//3 timeOut=2s; command message: short reply or long reply, eg: !F1[CR]: to set long reply, see manual page[P24] or [P26];
												
												//DI:1000~1999
												{"?C",5},//1000 timeOut=0.5s; query control status: local remote, eg: ?C[CR], see manual page[P18] or [P22];
												{"?P",5},//1001 timeOut=0.5s; query control status: on off, eg: ?P[CR], see manual page[P18] or [P23], and Page [P20]: Table 8;
												{"?F",5},//1002 timeOut=0.5s; query reply mode: short long, eg: ?F[CR], see manual page[P18] or [P22];
												
												//Alarm:2000~2999
												{"?I",5}};//2000 2001: timeOut=0.5s; query Alarm status, just read the detail info, eg: ?I[CR], see manual page[P18] or [P22];
													      /* when query the exception details, this should base on reply mode_Long,
													       *  the reply format is: [number][;parameter, priority level,alarm type, bitfiled status(reason)];
													       * eg: Dry pump has two exceptions,the reply is: 
													        2:14,1,1,0;1,3,1,4096;  */
											
DryPumpBoc::DryPumpBoc():SerialDevice(20,"\x0D")
{
} 

DryPumpBoc::~DryPumpBoc()
{
}

//to print the logSystem.
void DryPumpBoc::logIOException(string strCommand, string strFailedReason)
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::PROBLEM, getName() + "DryPump send command "+strCommand +" failed,"+strFailedReason);
}

// for analysis the send eeror reason;
void DryPumpBoc::checkActionCommandReply(std::string strCmd, std::string strResp)
{
	int nIndex = strResp.find("ERR 0", 0);	
	if(nIndex != string::npos)
	{	
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "DryPump send command successfully, the command is: " + strCmd);
	}
	else
	{
		int nIndexErr = strResp.find("ERR ", 0);
		if(nIndexErr != string::npos)
		{	
			string strValue;
			if(nIndexErr+4<=strResp.length())
			{
				strValue=strResp.substr(nIndexErr+4,1);
			}
			else
			{
				logIOException(strCmd,"The length of response is abnormal. The response is:" + strResp);
				throw IOException("The length of response is abnormal. The response is:" + strResp);
			}
			
			int nValue;
			if(Converter::stringToInt(nValue, strValue))
			{
				switch(nValue)
				{
					case 0://the string variable (strValue) cannot convert to int variable.
						logIOException(strCmd,"The response is not conform to format. The response is:" + strResp);
						throw IOException("The response is not conform to format. The response is: " + strResp);
						break;
					case 1:
						logIOException(strCmd,"Invalid message: The message sent was not a valid query or command message. The response is:" + strResp);
						throw IOException("Invalid message: The message sent was not a valid query or command message. The response is:" + strResp);
						break;
					case 2:
						logIOException(strCmd,"Number not found: Part of a message was not found. Resend the message in the correct format. The response is:" + strResp);
						throw IOException("Number not found: Part of a message was not found. Resend the message in the correct format. The response is:" + strResp);
						break;
					case 3:
						logIOException(strCmd,"Number Invalid: Part of a message was outside the valid range. The response is:" + strResp);
						throw IOException("Number Invalid: Part of a message was outside the valid range. The response is:" + strResp);
						break;
					case 4:
						logIOException(strCmd,"Parameter's value not received. The response is:" + strResp);
						throw IOException("Parameter's value not received. The response is:" + strResp);
						break;
					case 5:
						logIOException(strCmd,"Command not possible, please try to take or release control. The response is:" + strResp);
						throw IOException("Command not possible, please try to take or release control. The response is:" + strResp);
						break;
					default:
						logIOException(strCmd,"Other exceptions. The response is:" + strResp);
						throw IOException("Other exceptions. The response is:" + strResp);
						break;
				}
			}
			else
			{
				logIOException(strCmd,"The priority level of response cannot transform to digit. The response is:" + strResp);
				throw IOException("The priority level of response cannot transform to digit. The response is:" + strResp);
			}
		}
		else
		{
			logIOException(strCmd,"The response is invalid. The response is:" + strResp);
			throw IOException("The response is invalid. The response is:" + strResp);
		}
	}	
}

bool DryPumpBoc::readInt(int nChannelNum, int * pValue, const IntTypeInfo &typeInfo)
{
	Com com = m_commands[nChannelNum-1000+4];
	string strCmd = com.m_strMsg;
	string strResp = getCommandResult(strCmd, com.m_nTimeOut);	
	int strLength=strResp.length();
	if(strResp.length()!=0)
	{
		string strValue=strResp.substr(0,1);
		int nValue;
		if(Converter::stringToInt(nValue, strValue))
		{
			if(nChannelNum==1001)
			{
				if(nValue==0 || nValue==1 || nValue==2 || nValue==3 || nValue==4)
				{
					*pValue = nValue;
					return true;
				}
				else
				{
					logIOException(strCmd,"The response is invalid. The response is:" + strResp);
					throw IOException("The response is invalid. " + strResp);
				}
			}
			else
			{
				if(nValue==0 || nValue==1)
				{
					*pValue = nValue;
					return true;
				}
				else
				{
					logIOException(strCmd,"The response is invalid. The response is:" + strResp);
					throw IOException("The response is invalid. " + strResp);
				}
			}
		}
		else
		{
			logIOException(strCmd,"The response of query command cannot transform to digit in readInt channel. The response is:" + strResp);
			throw IOException("The response of query command cannot transform to digit in readInt channel. The response is:" + strResp);
		}
	}
	else
	{
		logIOException(strCmd,"No response received.");
		throw IOException("No response received.");
	}
}

bool DryPumpBoc::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
	Com com = m_commands[nChannelNum];
	string strCmd = com.m_strMsg;
	string strTempCmd = Converter::convertToString(nValue);
	strCmd = strCmd + strTempCmd;
	
	string strResp = getCommandResult(strCmd, com.m_nTimeOut);
	if(strResp.length()!=0)
	{
		checkActionCommandReply(strCmd,strResp);
		return true;//zhangyy modify[1.0.48]
	}
	else
	{
		logIOException(strCmd,"No response received.");
		throw IOException("No response received.");
	}
}

//for post Alarm ID within the alarm message
bool DryPumpBoc::readStringError(int nChannelNum,string * pValue , const StringTypeInfo& typeinfo)
{
	//for test 
//	string strResp = "2:14,1,1,0;1,3,1,4096";	//warning+alarm
	//string strResp = "1:14,1,1,0";	//warning
	//string strResp = "1:14,3,1,1";	//alarm
	//string strResp = "0:";	
	//string strResp = "0";	
	
	Com com = m_commands[7];
	string strCmd = com.m_strMsg;
	string strResp = getCommandResult(strCmd, com.m_nTimeOut);	

	string strAlarmCode = "";
	string strWarningCode= "";
	string strValue=strResp.substr(0,1);
	int nValue;
	if(Converter::stringToInt(nValue, strValue))
	{
		if(nValue == 0)
		{
			*pValue = "NoError";
		}
		else if(nValue < 0)
		{
			logIOException(strCmd,"The number of exceptions cannot be negative. The response is:" + strResp);
			throw IOException("The number of exceptions cannot be negative. The response is:" + strResp);
		}
		else //nValue > 0
		{
			int nIndex = strResp.find(";",0);
			if(nIndex != string::npos)
			{
				string strRespTemp;
				if(nIndex+1<=strResp.length())
				{
					strRespTemp=strResp.substr(nIndex+1,strResp.length()-nIndex-1);
				}
				else
				{
					logIOException(strCmd,"The length of response is abnormal. The response is:" + strResp);
					throw IOException("The length of response is abnormal. The response is:" + strResp);
				}
				
				// to distinguish abnormal type.
				//1.extraction of data:Alarm and warning;
				std::vector<std::string> vErrorList = IStringList::split(strRespTemp, ";");
	
				//2.extraction of Alarm and warning: priority level and bitfiled status;
				std::vector<std::string> vPriorityLevelList;
				
				for(vector<string>::size_type i=0;i!=vErrorList.size(); ++i)
				{
					vPriorityLevelList = IStringList::split(vErrorList[i], ",");
					if (vPriorityLevelList.size() == 4)
					{
						string strLevel= vPriorityLevelList[1];
						int nLevel;
						if(Converter::stringToInt(nLevel, strLevel))
						{
							switch (nLevel)
							{
								case 1:
									strWarningCode = vPriorityLevelList[3];
									break;
								case 2:
								case 3:
									strAlarmCode = vPriorityLevelList[3];
									break;
								default:
									logIOException(strCmd,"The response's priority level is invalid. The response is:" + strResp);
									throw IOException("The response's priority level is invalid." + strResp);
							}
						}
						else
						{
							logIOException(strCmd,"The priority level of response cannot transform to digit. The response is:" + strResp);
							throw IOException("The priority level of response cannot transform to digit. The response is:" + strResp);
						}
						
					}
					else
					{
						logIOException(strCmd,"The response is invalid. The response is:" + strResp);
						throw IOException("The response is invalid." + strResp);
					}
				}
			}
			else
			{
				logIOException(strCmd,"The response is invalid. Cannot find the symbol: simicolon(;)! The response is:" + strResp);
				throw IOException("The response is invalid. Cannot find the symbol: simicolon(;)!" + strResp);
			}
		}
		
		if(nChannelNum==2000)
		{
			if(strAlarmCode=="")
			{
				*pValue = "NoError";
			}
			else
			{
				*pValue = strAlarmCode;
			}
		}
		else
		{
			if(strWarningCode=="")
			{
				*pValue = "NoError";
			}
			else
			{
				*pValue = strWarningCode;
			}
		}
	}
	else
	{
		logIOException(strCmd,"The number of exceptions cannot transform to digit in readStringError channel. The response is:" + strResp);
		throw IOException("The number of exceptions cannot transform to digit in readStringError channel. The response is:" + strResp);
	}
	return true;
}

void DryPumpBoc::initDevice()
{
	cout<<"Start Scan DryPumpBoc...."<<endl;
//	throw IOException("reading back times out ");	//for test
	if(!isSimulated())
	{
//		try
//		{
			//set the mode: remote
			string strResp = getCommandResult("!C1", 20);
			checkActionCommandReply("!C1",strResp);
	
			//set the reply mode: long
			string strResReply = getCommandResult("!F1", 20);
			checkActionCommandReply("!F1",strResp);
//		}
//		catch(exception &ex)
//		{
//			cout<<"Scan DryPumpBoc failed. Communication abnormal!"<<endl;
//			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "Scan DryPumpBoc failed. Communication abnormal!");	
//		}
	}
	else
	{
		cout<<"Scan DryPumpBoc Successfully...."<<endl;
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "Scan DryPumpBoc Successfully....");	
	}
	cout<<"Scan DryPumpBoc Successfully...."<<endl;
}
void DryPumpBoc::initChs(DeviceNode<DryPumpBoc> *pNode)
{
	pNode->registerWriteCh(1,&DryPumpBoc::writeInt);	//to set the control model:Local/Remote, see manual page[P25];
	pNode->registerWriteCh(2,&DryPumpBoc::writeInt);	//to set the run model: start/stop, see manual page[P27];
	pNode->registerWriteCh(3,&DryPumpBoc::writeInt);	//to set the response model: short/long, see manual page[P26];
	pNode->registerReadCh(1000,&DryPumpBoc::readInt);	//query control model, see manual page[P22];
	pNode->registerReadCh(1001,&DryPumpBoc::readInt);	//query run model, see manual page[P23]+[P20] table 8;
	pNode->registerReadCh(1002,&DryPumpBoc::readInt);	//query reply format, see manual page[P22];
	pNode->registerReadCh(2000,&DryPumpBoc::readStringError);	//Alarm Details, see manual page[P22];
	pNode->registerReadCh(2001,&DryPumpBoc::readStringError);	//Warning Details, see manual page[P22];
}

void DryPumpBoc::init()
{
	cout<<getName()+"DryPumpBoc init start."<<endl;
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "DryPumpBoc init start.");
	DeviceNode<DryPumpBoc> *pNode = new DeviceNode<DryPumpBoc>(m_pollPeriod,this);
	if(!isSimulated())
	{
		initChs(pNode);		
		initDevice();
	}
	else
	{
		initChs(pNode);
		initDevice();
	}
	DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
	cout<<getName()+"DryPumpBoc init end."<<endl;
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "DryPumpBoc init end.");
}

IMPLEMENT_DYNAMIC(DryPumpBoc, SerialDevice )
BEGIN_MSG_MAP(DryPumpBoc, SerialDevice )
    SET_V( init, DryPumpBoc )
END_MSG_MAP
