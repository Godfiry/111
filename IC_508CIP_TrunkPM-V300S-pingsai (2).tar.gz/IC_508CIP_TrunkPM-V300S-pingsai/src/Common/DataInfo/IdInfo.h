/********************************************************************
** Copyright (c) 2023 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: IdInfo.h
** Description:
** Release: 1.0
** Modification history:
** 					2023-10-31   GuoJin create
**
*********************************************************************/
#ifndef IDINFO_H_
#define IDINFO_H_

#include "StringValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class IdInfo : public StringValueInfo
{
	public:
		static const StringTypeInfo typeInfo;

		IdInfo():StringValueInfo()
		{
		}

		IdInfo(std::string s):StringValueInfo(s)
		{
		}
};

#endif  /*IDINFO_H_*/
