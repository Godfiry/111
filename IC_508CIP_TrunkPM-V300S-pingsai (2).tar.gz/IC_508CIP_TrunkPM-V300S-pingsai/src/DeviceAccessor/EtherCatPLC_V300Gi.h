#ifndef ETHERCATPLC_V300GI_H_
#define ETHERCATPLC_V300GI_H_

#include "EtherCatPLC_E300Ge.h"
#include "DeviceNode.h"



class EtherCatPLC_V300Gi :public EtherCatPLC_E300Ge{

	DECLARE_DYNAMIC(EtherCatPLC_V300Gi)
	DECLARE_MSG_MAP

public:
	EtherCatPLC_V300Gi();//
	virtual ~EtherCatPLC_V300Gi();

	virtual bool readAnalog(int channelNum, double *value, const DoubleTypeInfo &typeInfo);
	virtual bool writeAnalog(int channelNum, double value, const DoubleTypeInfo &typeInfo);
	virtual bool readBit(int channelNum, int *bit, const IntTypeInfo &typeInfo);
	virtual bool writeBit(int channelNum, int bit, const IntTypeInfo &typeInfo);
	virtual bool readInt(int channelNum, int *value, const IntTypeInfo &typeInfo);
	virtual bool writeInt(int channelNum, int value, const IntTypeInfo &typeInfo);
    virtual bool readEcatStatus(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);   //add by wzd 1.1.65 hotfix4
	void setChannelSize(int channelNum);

protected:

	virtual void initChs(DeviceNode<EtherCatBaseDevice> *node);
	int m_channelSize;
};

#endif /* ETHERCATPLC_V300GI_H_ */
