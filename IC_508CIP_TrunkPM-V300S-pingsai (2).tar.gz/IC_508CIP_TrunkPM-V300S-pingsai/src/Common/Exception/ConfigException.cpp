/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: ConfigException.cpp
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-03-04  LiJuanjuan create
**      
*********************************************************************/
#include "ConfigException.h"

ConfigException::ConfigException(const std::string &s):TMCException(s)
{
}


