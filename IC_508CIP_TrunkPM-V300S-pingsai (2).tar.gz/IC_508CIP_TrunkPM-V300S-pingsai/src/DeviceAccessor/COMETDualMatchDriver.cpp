/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: COMETDualMatchDriver.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					
**                  2014-11-26   gaozl 	modified
*********************************************************************/
#include "COMETDualMatchDriver.h"
#include "DeviceManager.h"

#include "IStringList.h"
#include <iostream>
#include "SysLogger.h"
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std; 

//COMETDualMatchDriver::ParamPair COMETDualMatchDriver::m_paramPairs[] = {ParamPair("manaut",DescriptorList("3,1"))};//0="3"="manual" 1="1"="auto"
										 
//map<string,DescriptorList> COMETDualMatchDriver::m_params = map<string,DescriptorList>(m_paramPairs, m_paramPairs+1);

COMETDualMatchDriver::Com COMETDualMatchDriver::m_commands[] = {{0, ""}, //0	reserved 	
											{0, "Mode10", 0},//1 set C1 and C2 Hold
											{0, "Mode11", 0},//2 set C1 and C2 Manual
											{0, "Mode12", 0},//3 set C1 and C2 AutoHold
											{0, "Mode13", 0},//4 set C1 and C2 AutoPreset
											{0, "Mode20", 0},//5 set C3 and C4 Hold
											{0, "Mode21", 0},//6 set C3 and C4 Manual
											{0, "Mode22", 0},//7 set C3 and C4 AutoHold
											{0, "Mode23", 0},//8 set C3 and C4 AutoPreset
											{0, "C1Mode0", 0},//9 set C1 Hold
											{0, "C1Mode1", 0},//10 set C1 Manual
											{0, "C1Mode2", 0},//11 set C1 AutoHold
											{0, "C1Mode3", 0},//12 set C1 AutoPreset
											{0, "C2Mode0", 0},//13 set C2 Hold
											{0, "C2Mode1", 0},//14 set C2 Manual
											{0, "C2Mode2", 0},//15 set C2 AutoHold
											{0, "C2Mode3", 0},//16 set C2 AutoPreset
											{0, "C3Mode0", 0},//17 set C3 Hold
											{0, "C3Mode1", 0},//18 set C3 Manual
											{0, "C3Mode2", 0},//19 set C3 AutoHold
											{0, "C3Mode3", 0},//20 set C3 AutoPreset
											{0, "C4Mode0", 0},//21 set C4 Hold
											{0, "C4Mode1", 0},//22 set C4 Manual
											{0, "C4Mode2", 0},//23 set C4 AutoHold
											{0, "C4Mode3", 0},//24 set C4 AutoPreset
											{0, "WCurrRatio", 0},//25 store the target value for current ratio in EEPROM
											{0, "Rest", 0},//26 Restart PCB and init capacitors
											{0, "Lube", 0},//27 run a lubrication cycle to redistribute the grease on the lead screws of capacitors
											{1, "C1Pos", 0},//28 set C1 Position
											{1, "C2Pos", 0},//29 set C2 Position
											{1, "C3Pos", 0},//30 set C3 Position
											{1, "C4Pos", 0},//31 set C4 Position
											{2, "SP1", 0},//32 store actual pos of C1 and C2 in preset 0x0-0xF 
											{2, "SP2", 0},//33 store actual pos of C3 and C4 in preset 0x0-0xF 
											{2, "G1", 0},//34 select stored preset pos of C1 and C2 
											{2, "G2", 0},//35 select stored preset pos of C3 and C4
											{0, "CurrRatio", 0},//36 set target value for current ratio											
						
											{1, "QC1Pos", 0},//37 get actual position of C1 in 0.0% through 99.9%
											{1, "QC2Pos", 0},//38 get actual position of C2 in 0.0% through 99.9%
											{1, "QC3Pos", 0},//39 get actual position of C3 in 0.0% through 99.9%
											{1, "QC4Pos", 0},//40 get actual position of C4 in 0.0% through 99.9%
											{2, "QP##1", 0},//41 report actual position of C1
											{2, "QP##1", 1},//42 report actual position of C2
											{2, "QP##2", 0},//43 report actual position of C3
											{2, "QP##2", 1},//44 report actual position of C4
											{1, "QMode1", 0},//45 report current mode of C1 and C2
											{1, "QMode2", 0},//46 report current mode of C3 and C4
											{1, "QC1Mode", 0},//47 report current mode of C1
											{1, "QC2Mode", 0},//48 report current mode of C2
											{1, "QC3Mode", 0},//49 report current mode of C3
											{1, "QC4Mode", 0},//50 report current mode of C4
											{1, "QActCR", 0},//51 get the actual value of current ratio
											{1, "Status", 0},//52 get the 16-bit unit for operational status
											{1, "QCurrRatio", 0},//53 read the target value for the curr ratio from RAM
											{2, "QAux1", 0},//54 get curr value of the V sensor from Out1(Main)
											{2, "QAux1", 1},//55 get curr value of the I sensor from Out1(Main)
											{2, "QAux2", 0},//56 get curr value of the V sensor from Out2
											{2, "QAux2", 1},//57 get curr value of the I sensor from Out2
											{1, "Zload1", 0},//58  get the load impedance which corresponds to Main RF circuit
											{1, "Zload2", 0},//59  get the load impedance which corresponds to Split current circuit
											{1, "QP1", 0},//60  get preset position of C1C2
											{1, "QP2", 0},//61  get preset position of C3C4
											{0, "hello", 0}//62 hello
};


COMETDualMatchDriver::COMETDualMatchDriver()
{
}

COMETDualMatchDriver::~COMETDualMatchDriver()
{
}

bool COMETDualMatchDriver::writeInt(int channelNum, int value, const IntTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	int ps = com.m_ps;
	string msg = "";
	string hexstr = "";
	double t_c = 0.0;
	char format[5]={0};
	switch(ps)
	{
		case 0:
			//msg = com.m_s1;
			msg = m_commands[channelNum + value].m_s1;
			break;
		case 1:
			t_c = value / 10.0;		
			sprintf(format,"%04.1f",t_c);
			msg = com.m_s1 + format;
			break;	
		case 2:
		/*	switch(value)
			{
				case 10:
					hexstr = "A";
					break;
				case 11:
					hexstr = "B";
					break;
				case 12:
					hexstr = "C";
					break;
				case 13:
					hexstr = "D";
					break;
				case 14:
					hexstr = "E";
					break;
				case 15:
					hexstr = "F";
					break;
				default:
					hexstr = Converter::convertToString(value);
					break;
			}*/
			if(value > 99)
			{
				hexstr = "," + Converter::convertToString(value);
			}
			else if(value > 9)
			{
				hexstr = ",0" + Converter::convertToString(value);
			}
			else
			{
				  hexstr = ",00" + Converter::convertToString(value);
			}
			msg = com.m_s1 + hexstr;
			break;	
	}
	//add by wz
	if(msg == "Rest")
	{
		sendCommand(msg, 0);
		return true;

	}
	return sendCommand(msg, m_timeOut);
}

bool COMETDualMatchDriver::writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	string msg = "";
	double t_c = value;
	char format[7]={0};	
	sprintf(format,"%05.3f",t_c);
	msg = com.m_s1 + "0" + format;
	return sendCommand(msg, m_timeOut);
}
	
bool COMETDualMatchDriver::writeRawCommand(int channelNum, std::string value, const StringTypeInfo &typeInfo)
{
	return sendCommand(value, m_timeOut);
}
		
bool COMETDualMatchDriver::readInt(int channelNum, int *value, const IntTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	if(channelNum == 52)
	{
		string status = readCommand(com.m_s1, m_timeOut);
		status = status.substr(0,4);
		Converter::stringToInt(*value, status,hex);
		if(*value>1)
		{
			string result="";
			for(int i = 0; i < 4; i++)
			{
				result=result+HexCharToBinStr(status[i]);
			}
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "COMETDualMatchDriver has fault" + result);
		}
		return true;
	}
	if(channelNum == 62)
	{
		*value = 0;
		string status = readCommand(com.m_s1, m_timeOut);
		if(status.find("COMET") != string::npos)
		{
			*value = 1;
		}
		else
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "COMETDualMatchDriver say hello failed for response is " + status);
			*value = 0;
		}
		return true;
	}
	string res = readCommand(com.m_s1, m_timeOut);
	std::vector<std::string> t_vlist = IStringList::split(res, ",");
	string t_svalue = "";
	double t_dvalue,t_dvalue1;

	if(t_vlist.size() != com.m_ps)
	{
		throw IOException("read back value is not valid:" + res);
	}
	
	if(t_vlist.size() == 1)
	{
		t_svalue = t_vlist[0];

		if (channelNum > 36 && channelNum < 41)
		{		
			if(!Converter::stringToDouble(t_dvalue, t_svalue))
			{
				throw IOException("read back value is not an valid double value:" + t_svalue);
			}
			t_dvalue1 = t_dvalue * 10;
			*value = (int)t_dvalue1;
		}
		
		//comment because int -> double
		
//		if (channelNum == 51) //QActCurrRatio
//		{
//			if(!Converter::stringToDouble(t_dvalue, t_svalue))
//			{
//				throw IOException("read back value is not an valid double value:" + t_svalue);
//			}	
//			t_dvalue1 = t_dvalue * 1000;		
//			*value = (int)t_dvalue1;	
//		}

		if (channelNum > 44 && channelNum < 51 ) //QMode,QC*Mode
		{
			int t_ivalue;
			if(!Converter::stringToInt(t_ivalue, t_svalue))
			{
				throw IOException("read back value is not an valid int Mode-value:" + t_svalue);
			}			
			*value = t_ivalue;
		}	
	}
	if(t_vlist.size() > 1)
	{
		if(com.m_ps2 < 0 || com.m_ps2 > t_vlist.size())
		{
			throw IOException("COMET dual Match read command -[ "+com.m_s1+" ] failed,because response -[ "+res+" ] is invalid.");
		} 
		t_svalue = t_vlist[com.m_ps2];
		t_dvalue = 0;
		if(!Converter::stringToDouble(t_dvalue, t_svalue))
		{
			throw IOException("read back value is not an valid double value:" + t_svalue);
		}
		t_dvalue1 = t_dvalue * 10;
		*value = (int)t_dvalue1;
	}
	return true;
}

string COMETDualMatchDriver::HexCharToBinStr(char hexch)
{
	string binstr = "";
	switch(hexch)
	{
		case '0':
			binstr = "0000"; break;
		case '1':
			binstr = "0001"; break;
		case '2':
			binstr = "0010"; break;
		case '3':
			binstr = "0011"; break;
		case '4':
			binstr = "0100"; break;
		case '5':
			binstr = "0101"; break;
		case '6':
			binstr = "0110"; break;
		case '7':
			binstr = "0111"; break;
		case '8':
			binstr = "1000"; break;
		case '9':
			binstr = "1001"; break;
		case 'A':
			binstr = "1010"; break;
		case 'B':
			binstr = "1011"; break;
		case 'C':
			binstr = "1100"; break;
		case 'D':
			binstr = "1101"; break;
		case 'E':
			binstr = "1110"; break;
		case 'F':
			binstr = "1111"; break;
		default :
			binstr = "0000"; break;
	}	
	return binstr;	
}

bool COMETDualMatchDriver::readString(int channelNum, std::string *value, const StringTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	string res = readCommand(com.m_s1, m_timeOut);
	*value = res;
	return true;
}

bool COMETDualMatchDriver::readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
	Com com = m_commands[channelNum];
	string res = readCommand(com.m_s1, m_timeOut);
	std::vector<std::string> t_vlist = IStringList::split(res, ",");
	string t_svalue = "";
	double t_dvalue = 0.0;

	if(t_vlist.size() != com.m_ps)
	{
		throw IOException("read back value is not valid:" + res);
	}
	if(t_vlist.size() == 1)
	{
		t_svalue = t_vlist[com.m_ps2];
		if(!Converter::stringToDouble(t_dvalue, t_svalue))
		{
			throw IOException("read back value is not an valid double value:" + t_svalue);
		}			
		*value = t_dvalue;	
	}	
	if(t_vlist.size() > 1)
	{
		t_svalue = t_vlist[com.m_ps2];
		if(!Converter::stringToDouble(t_dvalue, t_svalue))
		{
			throw IOException("read back value is not an valid double value:" + t_svalue);
		}
		*value = t_dvalue;
	}	
	return true;		
}

void COMETDualMatchDriver::initChs(DeviceNode<COMETDualMatchDriver> *node)
{
	for(int i = 1; i <= 35; ++i)
	{
		node->registerWriteCh(i, &COMETDualMatchDriver::writeInt);
	}
	
	node->registerWriteCh(36, &COMETDualMatchDriver::writeDouble); //CurrRatio
		
	for(int i = 37; i <= 50 ; ++i)
	{
		node->registerReadCh(i, &COMETDualMatchDriver::readInt);
	}	
	node->registerReadCh(51, &COMETDualMatchDriver::readDouble); //read Curr Ratio
	node->registerReadCh(52, &COMETDualMatchDriver::readInt); //Status

	for(int i = 53; i <= 57; ++i)
	{
		node->registerReadCh(i, &COMETDualMatchDriver::readDouble);
	}

	for(int i = 58; i <= 61; ++i)
	{
		node->registerReadCh(i, &COMETDualMatchDriver::readString);
	}
	node->registerReadCh(62, &COMETDualMatchDriver::readInt);//hello
	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &COMETDualMatchDriver::getStatus);
}

void COMETDualMatchDriver::initDevice()
{
	string strResponse = readCommand("hello", m_timeOut);
	if(strResponse.find("COMET") == string::npos)
	{
		cout<<"Scan COMET Dual Match failed. Communication abnormal! Response is "<<strResponse<<endl;
		throw IOException("Scan COMET Dual Match failed!");
	}
}
		
void COMETDualMatchDriver::init()
{
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "COMETDualMatchDriver start");
	DeviceNode<COMETDualMatchDriver> *node = new DeviceNode<COMETDualMatchDriver>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	if(!isSimulated())
	{
		cout<<getName()+" scan COMETDualMatch start..."<<endl;
		initChs(node);		
		initDevice();
		cout<<getName()+" scan COMET Dual Match successfully!"<<endl;
	}
	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "COMETDualMatchDriver end");
}

IMPLEMENT_DYNAMIC(COMETDualMatchDriver, COMETMatchDriver )
BEGIN_MSG_MAP(COMETDualMatchDriver, COMETMatchDriver )
    SET_V( init, COMETDualMatchDriver )
END_MSG_MAP
