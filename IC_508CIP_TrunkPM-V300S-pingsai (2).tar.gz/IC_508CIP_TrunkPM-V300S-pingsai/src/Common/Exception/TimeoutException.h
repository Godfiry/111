/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TimeoutException.h
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-02-26  LiJuanjuan create
**      
*********************************************************************/
#ifndef TIMEOUTEXCEPTION_H_
#define TIMEOUTEXCEPTION_H_

#include "TMCException.h"

class TimeoutException:public TMCException
{
	public:
		TimeoutException(const std::string &s);
};

#endif /*TIMEOUTEXCEPTION_H_*/
