/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: VacuumTypeInfo.h
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-01-03   LiJuanjuan create
**      
*********************************************************************/
#ifndef VACUUMTYPEINFO_H_
#define VACUUMTYPEINFO_H_

#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class VacuumTypeInfo
{
	public:
		static const IntTypeInfo TimeTypeInfo;
		static const DoubleTypeInfo PressureTypeInfo;
		static const DoubleTypeInfo FlowTypeInfo;
		static const IntTypeInfo TimeOut;
		
		VacuumTypeInfo();
		virtual ~VacuumTypeInfo();
};

#endif /*VACUUMTYPEINFO_H_*/
