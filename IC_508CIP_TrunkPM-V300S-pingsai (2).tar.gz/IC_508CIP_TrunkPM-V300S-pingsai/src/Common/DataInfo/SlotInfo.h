#ifndef SLOTINFO_H_
#define SLOTINFO_H_

#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class SlotInfo : public IntValueInfo
{
public:
		static const int UnInit = -1;
		static const IntTypeInfo typeInfo;
		static const SlotInfo all;

		SlotInfo():IntValueInfo(-1, typeInfo)
		{
		}
		
		SlotInfo(int i):IntValueInfo(i, typeInfo)
		{
		    
		}
		
		SlotInfo(std::string s):IntValueInfo(s, typeInfo)
		{
		    
		}
};

#endif /*SLOTINFO_H_*/
