/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: IOMonitorLogThread.cpp
** Description: 
** Release: 
** Modification history: 
** 					2015-07-01  lvjw  create 
**      
***************************************************************************/



#include "IOMonitorLogThread.h"

#include "IntValueInfo.h"
#include "StringValueInfo.h"
#include "DoubleValueInfo.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
#endif
using namespace std;

IOMonitorLogThread::IOMonitorLogThread()
{
	m_bExit=false;
	m_pMonitor=NULL;
	m_plogger=NULL;
}

IOMonitorLogThread::~IOMonitorLogThread()
{
	delete m_plogger;
	m_plogger =NULL;
}

void IOMonitorLogThread::setLogPath(std::string & strPath)
{
	if(m_plogger)
	{
		//to do throw exception???
	}
	else
	{
		m_plogger=new FileLogger();
		m_plogger->init(strPath,5000,1024);
		m_plogger->start(PRIORITY_LOW);
	}
	
}

void IOMonitorLogThread::setIOMonitor(IOMonitor * pMonitor)
{
	if(m_pMonitor)
	{
		//to do throw exception???
	}
	else
	{
		m_pMonitor=pMonitor;
	}
	
}

void IOMonitorLogThread::dealWithTheData(MonitorData &pData)// fixed by liusy 1.1.47
{
	
}

void IOMonitorLogThread::run()
{
	while(true)
	{
		getData();
		if(m_bExit)
		{
			break;
		}
		usleep(10);
	}
}

void IOMonitorLogThread::toExit()
{
	m_bExit = true;
}

void IOMonitorLogThread::getData()
{
	if(m_pMonitor && m_plogger)
	{
		while(true)
		{
			MonitorData pData;
			m_pMonitor->getData(pData);
			if(pData.strName != "")
			{
				dealWithTheData(pData);
			}
			else
			{
				break;
			}
		}
	}
}

IMPLEMENT_JOINT(IOMonitorLogThread,ManagedObject)
