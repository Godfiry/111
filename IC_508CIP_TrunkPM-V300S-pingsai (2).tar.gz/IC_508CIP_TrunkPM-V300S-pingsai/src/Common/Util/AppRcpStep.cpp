/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AppRcpStep.cpp
** Description:  
** Release: 1.1
** Modification history: 
**                     2009-8-4   LiJuanjuan create
**      
*********************************************************************/
#include "AppRcpStep.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "InvalidParameterException.h"
#endif
#include "Converter.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP;
using namespace IAP::CORE;
#endif

using namespace std;

AppRcpStep::AppRcpStep()
{
    m_stepName = "";
    m_stepNum = -1;
}

AppRcpStep::~AppRcpStep()
{
}

std::string AppRcpStep::getStepName()const
{
    return m_stepName;
}
        
ParamValue AppRcpStep::getParamValue(const std::string &param)const
{
    map<std::string, ParamValue>::const_iterator it = m_paramMap.find(param);
    if(it != m_paramMap.end())
    {
        return it->second;
    }
    else
    {
        throw InvalidParameterException("There is no parameter name [" + param+"] in recipe's step "+m_stepName);
    }
}

ParamValue AppRcpStep::getParamValue(int index)const
{
    if(index < 0 || index >= getParamSize())
    {
        throw InvalidParameterException("Invalid recipe parameter index "+Converter::convertToString(index));
    }
    else
    {
        return m_paramVector.at(index);
    }
}

bool AppRcpStep::hasParam(const std::string &param)const
{
    map<std::string, ParamValue>::const_iterator it = m_paramMap.find(param);
    if(it != m_paramMap.end())
    {
        return true;
    }
    else
    {
        return false;
    }    
}
        
void AppRcpStep::addParam(const ParamValue &value)
{
    m_paramMap.insert(pair<std::string, ParamValue>(value.Name, value));
    m_paramVector.push_back(value);
}
        
void AppRcpStep::setStepName(const std::string &name)
{
    m_stepName = name;
}
        
int AppRcpStep::getParamSize()const
{
    return    m_paramMap.size();
}

int AppRcpStep::getStepNum()const
{
    return m_stepNum;
}
        
void AppRcpStep::setStepNum(int stepnum)
{
    m_stepNum = stepnum;
}

double AppRcpStep::getParamDoubleValue(const std::string &param)
{
    double pvalue = 0.0;
    map<std::string, ParamValue>::const_iterator it = m_paramMap.find(param);//add by mjr[v1.5.0]for sonartest
    if(it != m_paramMap.end())
    {
        if(!Converter::stringToDouble(pvalue, it->second.StringValue1))
        {
            throw InvalidParameterException("Invalid param double value '"+it->second.StringValue1+"' for '"+ param +"' at step '"+Converter::convertToString(m_stepNum)+"'.");
        }
    }
    else
    {
        throw InvalidParameterException("There is no param name of '"+ param +"' at step '"+Converter::convertToString(m_stepNum)+"'.");
    }
    return pvalue;
}

int AppRcpStep::getParamIntValue(const std::string &param)
{
    int pvalue = 0.0;
    map<std::string, ParamValue>::const_iterator it = m_paramMap.find(param);//add by mjr[v1.5.0]for sonartest
    if(it != m_paramMap.end())
    {
        if(!Converter::stringToInt(pvalue, it->second.StringValue1))
        {
            throw InvalidParameterException("Invalid param int value '"+it->second.StringValue1+"' for '"+ param +"' at step '"+Converter::convertToString(m_stepNum)+"'.");
        }
    }
    else
    {
        throw InvalidParameterException("There is no param name of '"+ param +"' at step '"+Converter::convertToString(m_stepNum)+"'.");
    }
    return pvalue;
}

string AppRcpStep::getParamStringValue(const std::string &param)
{
    map<std::string, ParamValue>::const_iterator it = m_paramMap.find(param);//add by mjr[v1.5.0]for sonartest
    if(it != m_paramMap.end())
    {
        return it->second.StringValue1;
    }
    else
    {
        throw InvalidParameterException("There is no param name of '"+ param +"' at step '"+Converter::convertToString(m_stepNum)+"'.");
    }
}

