#include "CPUTestDriver.h"
#include <string.h>
#include "DeviceManager.h"

#include "Converter.h"
#include "ConfigException.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#include "Hex.h"
#include "SysLogger.h"
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<fstream>
#include <iostream>
#include <memory.h>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;


CPUTestDriver::CPUTestDriver()
{
	m_pollPeriod = 1000; //1s
}

CPUTestDriver::~CPUTestDriver()
{

}

bool CPUTestDriver::ReadCurrentCPU( int channelNum,double *value,const DoubleTypeInfo& typeinfo)
{
   string a ="";
   double b = 0.0;
   ofstream outfile;
   outfile.open("/tmp/cputest1.txt", ios::out);
   system("top  -n 2 |grep Cpu | cut -d ',' -f 4 | cut -d % -f 1 >/tmp/cputest1.txt");
   outfile.close(); 
    
	
	ifstream infile;
	infile.open("/tmp/cputest1.txt",ios::in);
	char pData[100] = {0};
	infile.getline(pData,100);
	memset(pData,0,100);
	infile.getline(pData,100);
	//cout<<Hex::GetHexString(pData,30)<<endl;
	a = pData;
	infile.close();
	//cout<<" idle cpu is "<<a<<endl;
	if(!a.empty())
	{
	   for(unsigned int i=0; i<= a.length()-1;i++)
	   {
	     //cout<<"a[i] is :"<<a[i]<<endl;
	   }
	   //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "reading current idle cpu is" + a);   
	}
	else
	{
	  throw IOException("failed to get idle cpu");
	}
   if(a.length()>4)
   {
	   a = a.substr(a.length()-4,4);
	   a.erase(0,a.find_first_not_of(' '));
	   //cout<<"a substr is :"<<a<<endl;
	   //SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "reading current idle cpu is" + a);
	   
   }
   	if(! Converter::stringToDouble(b, a))
	{
		throw ConfigException(getName()+":the first parameter must be a double");
	} 
   *value = 100 - b;
	return true;
}

bool CPUTestDriver::ReadCurrentMem( int channelNum,double *value,const DoubleTypeInfo& typeinfo)
{	
   system("free -m|grep Mem|awk '{print$2,$3,$6,$7}' >/tmp/cputest2.txt"); 
   
   ifstream fin;
   fin.open("/tmp/cputest2.txt");
   unsigned int a = 0;
   unsigned int b = 0;
   unsigned int buffer = 0;
   unsigned int cached = 0;
   double c = 0.0;
   fin>>a;
   //cout<<"total mem is"<<a<<endl;
   fin>>b;
   //cout<<"used mem is"<<b<<endl;
   fin>>buffer;
   //cout<<"buffer is"<<buffer<<endl;
   fin>>cached;
   //cout<<"cached is"<<cached<<endl;
   
   fin.close();
   if(a > 0)
   c = ((b-buffer-cached)*1.0)/(a*1.0);
   //cout<<"used mem percent is"<<c<<endl;	
	*value = c*100.0;
	//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "reading current used mem is" + Converter::convertToString(c));   
	return true;

}

void CPUTestDriver::initChs(DeviceNode<CPUTestDriver> *node)
{
   node->registerReadCh(1, &CPUTestDriver::ReadCurrentCPU);
   node->registerReadCh(2, &CPUTestDriver::ReadCurrentMem);
   

}

void CPUTestDriver::init()
{
	DeviceNode<CPUTestDriver> *node = new DeviceNode<CPUTestDriver>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	if(!isSimulated())
	{
		initChs(node);	
	}	
}

void CPUTestDriver::setNodeNum(int nodeNum)
{
	m_nodeNum = nodeNum;
}	

void CPUTestDriver::setPollInterval(int ms)
{
	m_pollPeriod = ms;
}

IMPLEMENT_DYNAMIC(CPUTestDriver, AbstractDevice )

BEGIN_MSG_MAP(CPUTestDriver, AbstractDevice )
	SET_I( setNodeNum, CPUTestDriver )
	SET_I( setPollInterval, CPUTestDriver )
	SET_V( init, CPUTestDriver )
END_MSG_MAP
