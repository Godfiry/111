/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: UTime.h
** Description: This class offers functions to get the system time
** Release: 1.1
** Modification history: 
** 					2009-09-2   LiJuanjuan create
**      
*********************************************************************/
#ifndef UTIME_H_
#define UTIME_H_



class UTime//:public Time
{
	public:
		//UTime();
		//virtual ~UTime();
		
		static long getCurrentTimeAsMSeconds();//m seconds 
};

#endif /*UTIME_H_*/
