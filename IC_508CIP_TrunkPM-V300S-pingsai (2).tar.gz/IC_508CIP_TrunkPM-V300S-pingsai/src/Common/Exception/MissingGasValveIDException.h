/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MissingGasValveIDException.h
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-03-20   LiJuanjuan create
**      
*********************************************************************/
#ifndef MISSINGGASVALVEIDEXCEPTION_H_
#define MISSINGGASVALVEIDEXCEPTION_H_

#include "TMCException.h"

class MissingGasValveIDException:public TMCException
{
	public:
		MissingGasValveIDException(const std::string &s);
};

#endif /*MISSINGGASVALVEIDEXCEPTION_H_*/
