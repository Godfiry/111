/********************************************************************
** Copyright (c) 2019, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AlarmTool.cpp
** Description:
** Created on: Jan 9, 2019
** Author: mujy
** Modification history:
**						[V1.0.0.2] create
**
*********************************************************************/
#include "AlarmTool.h"
#include "AlarmManager.h"
#include "ObjectManager.h"
#include "Alarm.h"
#include "Converter.h"
#include "SysLogger.h"
#include "Alarm.h"
#include "ConfigException.h"
#include <fstream>
#include <dirent.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string>
#include <iostream>
#ifdef IAP4_0
using namespace IAP::ALARM;
using namespace IAP::CORE;
#endif
using namespace std;

AlarmTool::AlarmTool()
{
	m_sPrint = new Print();
	m_sPrint->setOwner(this);
	m_sRenamePrint = new RenamePrint();
	m_sRenamePrint->setOwner(this);
}

AlarmTool::~AlarmTool()
{
	
}

void AlarmTool::make()
{
	
}

void AlarmTool::verifyInit()
{
	bool bFlag = true;
	vector<Alarm*> allAlarmsVector = AlarmManager::getInstance()->getAllAlarms();
	for(int i = 0;i<allAlarmsVector.size();i++)
	{
		std::string strAlarm = allAlarmsVector[i]->getName();
		if(strAlarm.find("/") != string::npos)
		{
			bFlag =false;
			cout<<"["<<strAlarm<<"] alarm name invalid!!!"<<endl;
		}
	}
	if(!bFlag)
	{
		throw ConfigException("!!!Error:Alarm name invalid,don't permit to contain \"/\". Please check.");
	}
}
void AlarmTool::Print::execute()
{
	
	AlarmTool *pOwner = dynamic_cast<AlarmTool*>(getOwner());
	if(pOwner != NULL)
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT,pOwner->getName()+": do_Print start");
		pOwner->do_Print();
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT,pOwner->getName()+": do_Print end");
	}
}

void AlarmTool::RenamePrint::execute()
{
	
	AlarmTool *pOwner = dynamic_cast<AlarmTool*>(getOwner());
	if(pOwner != NULL)
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT,pOwner->getName()+": do_RenamePrint start");
		pOwner->do_RenamePrint();
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT,pOwner->getName()+": do_RenamePrint end");
	}
}

void AlarmTool::call_Print()
{
	call(m_sPrint);
}

void AlarmTool::call_RenamePrint()
{
	call(m_sRenamePrint);
}
void AlarmTool::do_Print()
{
	cout<<"-------------------------------------------------"<<endl;
	cout<<"Start to print alarm information..."<<endl;

	char current_absolute_path[300];
	if(NULL == getcwd(current_absolute_path,300))
	{
		cout<<"Cannot get current absolute path!"<<endl;
		return;
	}

	string strPath = string(current_absolute_path)+"/Information/";

	cout<<"Print alarm info to path ["<<strPath<<"]"<<endl;

	if (access(strPath.c_str(), F_OK) != 0)
	{
		if(mkdir(strPath.c_str(),S_IRWXU|S_IRWXG|S_IRWXO) != 0)
		{
			cout<<"Cannot creat specified directory "<<strPath<<endl;
			throw string("Cannot creat specified directory "+strPath);
		}
	}
	else
	{
		if (access(strPath.c_str(), R_OK|W_OK) != 0) // cannot obtain 'rw' permission of dir
		{
			cout<<"Cannot access specified directory "<<strPath<<endl;
			throw string("Cannot access specified directory "+strPath);
		}
	}

	vector<Alarm*> allAlarmsVector = AlarmManager::getInstance()->getAllAlarms();
	SysLogger::getInstance()->logMsg(LOGBRANCH::ALARM, LEVEL::EVENT, "getAllAlarms");
	ofstream in;
	string strFileName = strPath + "Alarms.txt";
	in.open(strFileName.c_str(),ios::trunc);

	int nID;
	std::string strID;
	std::string strAlarmName;
	Alarm::Severity nAlarmSeverity;
	std::string strMessage;
	std::string strDescription;
	std::string strRecovery;
	std::vector<Recovery*> recoveriesVector;

	for(unsigned int i=0; i<allAlarmsVector.size(); ++i)
	{
		nID = allAlarmsVector[i]->getNumber();
		strID = Converter::convertToString(nID);
		strAlarmName = allAlarmsVector[i]->getName();
		nAlarmSeverity = allAlarmsVector[i]->getSeverity();
		strMessage = allAlarmsVector[i]->getMessage();
		strDescription = allAlarmsVector[i]->getDescription();
		in<<"ID:"<<"\t"<<strID<<"\t";
		in<<"Name:"<<"\t"<<strAlarmName<<endl;
		switch(nAlarmSeverity)
		{
			case 0:in<<"Severity:"<<"\t"<<"UNKNOWN"<<endl;
					break;
			case 1:in<<"Severity:"<<"\t"<<"FATAL"<<endl;
					break;
			case 2:in<<"Severity:"<<"\t"<<"ERROR"<<endl;
					break;		
			case 3:in<<"Severity:"<<"\t"<<"PROBLEM"<<endl;
					break;
			case 4:in<<"Severity:"<<"\t"<<"EVENT"<<endl;
					break;		
			case 5:in<<"Severity:"<<"\t"<<"NOTICE"<<endl;
					break;		
			default:in<<"None"<<endl;		
					
		}
		
		in<<"Message:"<<"\t"<<strMessage<<endl;
		in<<"Description:"<<"\t"<<strDescription<<endl;
		recoveriesVector = allAlarmsVector[i]->getAllRecoveries();
		
		for(unsigned int j=0; j<recoveriesVector.size(); ++j)
		{
			strRecovery = recoveriesVector[j] ->getMessage();
			in<<"Recoveries["<<j+1<<"]:"<<"\t"<<strRecovery<<endl;
		}
		in<<"-------------------------------------------------------------------------------"<<endl;
		in<<endl;	
		SysLogger::getInstance()->logMsg(LOGBRANCH::ALARM, LEVEL::EVENT, strID+strAlarmName+strMessage+strDescription);
	}
	in.close();
	cout<<"Print alarm information end."<<endl;
	cout<<"-------------------------------------------------"<<endl;
}

void AlarmTool::do_RenamePrint()
{
	cout<<"-------------------------------------------------"<<endl;
	cout<<"Start to Rename print alarm ..."<<endl;

	char current_absolute_path[300];
	if(NULL == getcwd(current_absolute_path,300))
	{
		cout<<"Cannot get current absolute path!"<<endl;
		return;
	}

	string strPath = string(current_absolute_path)+"/Information/";

	cout<<"Print alarm info to path ["<<strPath<<"]"<<endl;

	if (access(strPath.c_str(), F_OK) != 0)
	{
		if(mkdir(strPath.c_str(),S_IRWXU|S_IRWXG|S_IRWXO) != 0)
		{
			cout<<"Cannot creat specified syslog directory "<<strPath<<endl;
			throw string("Cannot creat specified syslog directory "+strPath);
		}
	}
	else
	{
		if (access(strPath.c_str(), R_OK|W_OK) != 0) // cannot obtain 'rw' permission of dir
		{
			cout<<"Cannot access specified directory "<<strPath<<endl;
			throw string("Cannot access specified directory "+strPath);
		}
	}

	vector<Alarm*> allAlarmsVector = AlarmManager::getInstance()->getAllAlarms();
	SysLogger::getInstance()->logMsg(LOGBRANCH::ALARM, LEVEL::EVENT, "getAllAlarms");
	ofstream in;
	string strFileName = strPath + "AlarmRename.txt";
	in.open(strFileName.c_str(),ios::trunc);
	std::string strAlarmName;
	for(unsigned int i=0; i<allAlarmsVector.size(); ++i)
	{
		strAlarmName = allAlarmsVector[i]->getName();
		in<<"	\<AddAlarmName type=\"method\"\>"<<strAlarmName<<", "<<"\<\/AddAlarmName>"<<endl;
	}
	in.close();
	cout<<"Print alarm information end."<<endl;
	cout<<"-------------------------------------------------"<<endl;
}

IMPLEMENT_DYNAMIC_SERVICE(Print, AlarmTool)
IMPLEMENT_DYNAMIC_SERVICE(RenamePrint, AlarmTool)
BEGIN_SERVICEINFO_LIST(AlarmTool)
	ADD_SERVICE_INFO(AlarmTool, Print, Print )
	ADD_SERVICE_INFO(AlarmTool, RenamePrint, RenamePrint )
END_SERVICEINFO_LIST(AlarmTool)

IMPLEMENT_DYNAMIC(AlarmTool, ControlObject)

BEGIN_MSG_MAP( AlarmTool, ControlObject)
END_MSG_MAP
