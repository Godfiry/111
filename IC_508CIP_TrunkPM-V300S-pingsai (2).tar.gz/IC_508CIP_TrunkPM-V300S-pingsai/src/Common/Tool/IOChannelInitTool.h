/**************************************************************************
** Copyright (c) 2021, Beijing NAURA Co.,Ltd.  All rights reserved.
** File name: .h
** Description:
** Release:
** Modification history:
** 					mujy created 2021-2-26
**
***************************************************************************/

#ifndef IOCHANNELINITTOOL_H_
#define IOCHANNELINITTOOL_H_

#include "CmdTarget.h"
#ifdef IAP4_0
using namespace IAP::CORE;
#endif
using namespace std;

class IOChannelInitTool: public CmdTarget
{
	DECLARE_DYNAMIC( IOChannelInitTool )
	DECLARE_MSG_MAP

public:
	IOChannelInitTool();
	virtual ~IOChannelInitTool();

public://xml config
	void initIntChannel(string strPath,int nValue);
	void initDoubleChannel(string strPath,double dValue);
	void initStringChannel(string strPath,string strValue);
};

#endif /* IOCHANNELINITTOOL_H_ */
