/********************************************************************
** Copyright (c) 2016, Beijing NMC Co.,Ltd. All rights reserved.
** All rights reserved.
**
** File name: StringResource.h
**
** Description:
**
** Modification history:
* 							2016.10.31		lvjw	created.
*********************************************************************/

#ifndef STRINGRESOURCE_H_
#define STRINGRESOURCE_H_
#include "CmdTarget.h"
#ifdef IAP4_0
using namespace IAP::CORE;
#endif
using namespace std;

class StringResource:public CmdTarget
{
	DECLARE_DYNAMIC( StringResource ) 
	DECLARE_MSG_MAP
public:
	StringResource();
	virtual ~StringResource();
	
public:
	bool AddString(int nID , const string &strData);
};

#endif /*STRINGRESOURCE_H_*/
