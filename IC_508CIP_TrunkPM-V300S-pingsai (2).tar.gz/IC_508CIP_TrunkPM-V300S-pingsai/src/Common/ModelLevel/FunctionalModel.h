#ifndef FUNCTIONALMODEL_H_
#define FUNCTIONALMODEL_H_

#include "ControlObjectEX.h"
#include "ObjectManager.h"
#include "ReadWriteInt.h"
#include "Service.h"
#include "SysLogger.h"
#include "Converter.h"
#include "CTCExport.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
using namespace IAP::CONTROL;
#endif

class FunctionalModel:public ControlObjectEX
{
	DECLARE_DYNAMIC( FunctionalModel )
	DECLARE_MSG_MAP
	DECLARE_SERVICEINFO_LIST
	class Init : public Service
	{
		DECLARE_DYNAMIC_SERVICE(Init)
		
		public:
			void execute();
	};
	
	class InitMaintain : public Service
	{
		DECLARE_DYNAMIC_SERVICE(InitMaintain)
		
		public:
			void execute();
	};
	
	class SetOpMode : public Service
	{
		DECLARE_DYNAMIC_SERVICE(SetOpMode)
		
		public:
			void execute();
	};
	
	class Shutdown : public Service
	{
		DECLARE_DYNAMIC_SERVICE(Shutdown)
		
		public:
			void execute();
	};
	
public://constructer & destructer
	FunctionalModel();
	virtual ~FunctionalModel();

public:
	int getStatusValue();
	string getStatusValueAsString(int nMode);//added by mujy [V1.0.0.3]
	void setStatusValue(int nMode);
	bool checkStatusEqual(int nMode);
	
public://service
	void call_Init();
	void call_InitMaintain();
	void call_SetOpMode(int nMode);
	void call_Shutdown();

public:
	void setMessage(string strMessage);

protected://service
	virtual void do_Init();
	virtual void do_InitMaintain();
	virtual void do_SetOpMode(int nMode);
	virtual void do_Shutdown();
	
protected://override
	virtual void make();
	virtual void defaultAbort();

protected:
	ReadWriteString * m_pModuleMessage;
			
private:
	ReadWriteInt * m_pModuleStatus;
	
private:
	ServicePtr<Init> m_Init;
	ServicePtr<InitMaintain> m_InitMaintain;
	ServicePtr<SetOpMode> m_SetOpMode;
	ServicePtr<Shutdown> m_Shutdown;
};

#endif /*FUNCTIONALMODEL_H_*/
