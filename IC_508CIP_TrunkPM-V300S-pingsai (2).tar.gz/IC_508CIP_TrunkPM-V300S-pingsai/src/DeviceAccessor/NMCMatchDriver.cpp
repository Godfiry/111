/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: NMCMatchDriver.cpp
** Description:  
** Release: 1.1
** Modification history: 
**                     2014-09-11   bihuijie create
**      
*********************************************************************/
#include "NMCMatchDriver.h"
#include "DeviceManager.h"

#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP;
#endif

using namespace std; 
NMCMatchDriver::Com NMCMatchDriver::m_commands[] = {{0, ""}, //0    reserved                         
                                            {0, "MAN", 0},//1 (CH,value)manual
                                            {0, "AUT", 0},//2 auto
                                            {0, "LOC", 0},//3 local
                                            {0, "REM", 0},//4 remote        
                                            {0, "PRD", 0},//5 disable presetmode
                                            {0, "PRE", 0},//6 enable presetmode    
                                            {1, "SCO", 0},//7 set c1
                                            {1, "SCT", 0},//8 set c2    
                                            {1, "CPO", 0},//9 preset c1    
                                            {1, "CPT", 0},//10 preset c2                                                            
                                            {3, "HPV", 13},//11 get Manual/Auto
                                            {3, "HPV", 12},//12 get Local/Remote
                                            {8, "RCO", 0},//13 get c1
                                            {8, "RCT", 0},//14 get c2
                                            {6, "DCB", 0},//15 get DCBias  //changed by wzd 1.1.42
                                            {0,"IND",0},//16 matchreset
                                            //added by taohao [1.1.58] for zizhisaopin Match
                                            {1, "SC1", 0},//17 set c1 Position
                                            {1, "SC2", 0},//18 set c2 Position
                                            {8, "RCA", 0},//19 get c1 Position
                                            {8, "RCB", 0},//20 get c2 Position
                                            {6, "DCB", 0}};//21 get VPP  //add by taohao [v1.5.0_HotFix5]
NMCMatchDriver::NMCMatchDriver()
{
}

NMCMatchDriver::~NMCMatchDriver()
{
}

bool NMCMatchDriver::writeInt(int channelNum, int value, const IntTypeInfo &typeInfo)
{
    Com com = m_commands[channelNum];
    int ps = com.m_ps;
    string msg = "";
    switch(ps)
    {
        case 0:
            //msg = com.m_s1;
            msg = m_commands[channelNum + value].m_s1;
            break;
        case 1:
            msg = com.m_s1 + Converter::convertToString(value);
            break;    
    }
    return sendCommand(msg, m_timeOut);
}
    
bool NMCMatchDriver::writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
    Com com = m_commands[channelNum];    
    //string    msg = com.m_s1 + Converter::convertToString((int)(value*10));    
    double tmp = (double)(value*10);//modified by chenmz [V2.0.4]
    double tmp1 = (int)tmp;
    int temp = tmp1;
    string    msg = com.m_s1 + Converter::convertToString(temp);        
    return sendCommand(msg, m_timeOut);
}    
        
bool NMCMatchDriver::writeRawCommand(int channelNum, std::string value, const StringTypeInfo &typeInfo)
{
    return sendCommand(value, m_timeOut);
}
        
bool NMCMatchDriver::readInt(int channelNum, int *value, const IntTypeInfo &typeInfo)
{
    Com com = m_commands[channelNum];
    int ps = com.m_ps;
    string res = readCommand(com.m_s1, m_timeOut);
    size_t pos = res.find(com.m_s1,0);  //changed by wzd 1.1.39
    if(pos == string::npos)
    {
        throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for response ["+Hex::GetHexString(res.c_str(),res.size())+"] is invalid.");
    }
    else
    {
        string t_value = (res.substr(pos+ps, 4));
        if(com.m_ps2 == 0)
        {
            if(!Converter::stringToInt(*value, t_value))
            {
                throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for can't convert response ["+t_value+"] to integer value.");
            }
        }
        else
        {
            if(!Converter::stringToInt(*value, t_value, std::hex))
            {
                throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for can't convert response ["+t_value+"] to integer value.");
            }
            *value = (*value >> com.m_ps2) & 0x0001;            
        }
        return true;
    }
    
}
        
bool NMCMatchDriver::readDouble(int channelNum, double *value, const DoubleTypeInfo &typeInfo)
{
    Com com = m_commands[channelNum];
    int ps = com.m_ps;
    string res = readCommand(com.m_s1, m_timeOut);
    size_t pos = res.find(com.m_s1,0);  //changed by wzd 1.1.39
    if(pos == string::npos)
    {
        throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for response ["+Hex::GetHexString(res.c_str(),res.size())+"] is invalid.");
    }
    else
    {
        string t_value = (res.substr(pos+ps, 6));
        int t_intv;
        if(!Converter::stringToInt(t_intv, t_value))
        {
            throw IOException(getDeviceName()+" read command ["+com.m_s1+"] failed for can't convert response ["+t_value+"] to integer value.");
        }
        if(channelNum == 21)//added by taohao[v1.5.0_HotFix5] read vpp sensor
        {
            *value = t_intv;
        }
        else
        {
            *value = t_intv / 2;
        }
        if(*value < 0)
        {
            *value = 0;
        }
        else if(*value > 10000)
        {
            *value = 10000;
        }
        return true;
    }
    
}

void NMCMatchDriver::initChs(DeviceNode<NMCMatchDriver> *node)
{
    for(int i = 1; i <= 10; ++i)
    {
        node->registerWriteCh(i, &NMCMatchDriver::writeInt);
    }
    for(int i = 11; i <= 14; ++i)
    {
        node->registerReadCh(i, &NMCMatchDriver::readInt);
    }    
    node->registerReadCh(15, &NMCMatchDriver::readDouble);
    node->registerWriteCh(16, &NMCMatchDriver::writeInt);
    node->registerWriteCh(17, &NMCMatchDriver::writeInt);
    node->registerWriteCh(18, &NMCMatchDriver::writeInt);
    node->registerReadCh(19, &NMCMatchDriver::readInt);
    node->registerReadCh(20, &NMCMatchDriver::readInt);
    node->registerReadCh(21, &NMCMatchDriver::readDouble);//added by taohao[v1.5.0_HotFix5] read vpp sensor
    node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &NMCMatchDriver::getStatus);
}

void NMCMatchDriver::initDevice()
{
    cout<<"Start Scan  NNC Match...."<<endl;
    //say hello to match
    int iTemp;
    try
    {
        readInt(11,&iTemp,IntTypeInfo());//11 get Manual/Auto
    }
    catch(exception &ex)
    {
        cout<<"Scan NNC Match failed. Communication abnormal!"<<endl;    
    }
    
    cout<<"Scan NNC Match Successfully...."<<endl;
}
        
void NMCMatchDriver::init()
{
    DeviceNode<NMCMatchDriver> *node = new DeviceNode<NMCMatchDriver>(m_pollPeriod, this);
    DeviceManager::getInstance()->registerNode(m_nodeNum, node);
    if(!isSimulated())
    {
        initChs(node);        
        initDevice();
    }
}

IMPLEMENT_DYNAMIC(NMCMatchDriver, MKSMatch )
BEGIN_MSG_MAP(NMCMatchDriver, MKSMatch )
    SET_V( init, NMCMatchDriver )
END_MSG_MAP
