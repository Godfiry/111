/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: GeneratorPearl30V6AJ1.cpp
** Description:  
** Release: 1.1
** Modification history: 
**					2020-04-20   mayc create
*********************************************************************/
#include "GeneratorPearl30V6AJ1.h"
#include "DeviceManager.h"

#include "Converter.h"
#include "StrTool.h"
#include "Hex.h"
#include "CheckCalculationTool.h"
#include <cctype>
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std; 

GeneratorPearl30V6AJ1::Cmd GeneratorPearl30V6AJ1::m_cmd[] = {{""},//reserved
											{":0110000002",0},//1.turn the RF output off/On, 1:RF ON; 0:RF OFF
											{"",0},						  //2...
											{":0110000002",3},//3.Reset generator faults, 1:Fault Reset,0:Normal state
											{":0110000002",5},//4.power mode: 0 is Forward,1 is Load // 30M20 not support
											{"",0},                       //5 ..
											{":0110000102",0},//6 set the power setpoint in watts to x
											{"",0},//7 ..
											{"",0},//8 ..
											{"",0},//9 ..
											{":010340000001",0},//10 get output forward power
											{":010340010001",0},//11 get output reverse power
											{":010340050001",0},//12 read Frequency MHz
											{":010340040001",0x0001},//13 get status, bit 0 is RF ON/OFF
											{":010340040001",0x0004},//14 get status, bit 2 is Fault;
											{":010340040001",0x0010},//15 get status, bit 4 is Interlock open
											{":010340040001",0x0100},//16 get status, bit 8 is link Intergrity fault
											{":010340040001",0x0200},//17 get status, bit 9 is Over temp condition
											{":010308060001",0xFFFF}, //18 get fault,bit 0:panel switch open; bit 1:Thermal switch open;  // 30M20 not support
																					//bit 3:Interlock open; bit 7: Pr trip; bit 11:Abnormal state of DC Power; bit 13: Power over
											{":010308000001",0xFFFF}//19 error code for 30M20

};
GeneratorPearl30V6AJ1::GeneratorPearl30V6AJ1():SerialDevice(200, "\x0D\x0A")
{
	m_timeOut = 50;//5s
	m_pollPeriod = 200; //200ms

	//m_nAddress0000 = 0;

	m_nFullScale = 0x1FFF;//8191
}

GeneratorPearl30V6AJ1::~GeneratorPearl30V6AJ1()
{
}

string GeneratorPearl30V6AJ1::sendCommandAndReadResponse(string &strCommond, int nTimeOut)
{
	string strResponse = getCommandResult(strCommond, nTimeOut);
	if(strResponse.find("\x0D\x0A",0) == string::npos)
	{
		throw IOException("Generator send command ["+strCommond+"] occurred error [" + strResponse+"]");
	}
	size_t nPos = 0;  //changed by wzd 1.1.39
	string strCommondHead = strCommond.substr(0,5);
	if(strResponse.find(strCommondHead,0) != string::npos)
	{
		return strResponse;
	}
	else if((nPos = strResponse.find(":0190",0)) != string::npos || (nPos = strResponse.find(":0183",0)) != string::npos)
	{
		string strErrorCode = strResponse.substr(nPos+5,2);
		throw IOException("Generator send command ["+strCommond+"] occurred error, error code is [" + strErrorCode+"]");
	}
	else
	{
		throw IOException("Generator send command ["+strCommond+"] failed for unknown response [" + strResponse+"]");
	}
}

int GeneratorPearl30V6AJ1::readAddress0000(int nTimeOut)
{
	string strCommand = ":010300000001FB";
	//string strTotalCommand = strCommand + CheckCalculationTool::GetLRCCode(strCommand);
	//strTotalCommand = StrTool::toUpper(strTotalCommand);

	string strResponse = sendCommandAndReadResponse(strCommand, nTimeOut);
	cout<<strResponse<<endl;
	size_t nPos = strResponse.find(":");  //changed by wzd 1.1.39
	int nValueInAddress0000 = 0;

	string strSplitValue = strResponse.substr(nPos+7,4);
	cout<<strSplitValue<<endl;
	if(!Hex::stringToHex(&nValueInAddress0000, strSplitValue))
	{
		cout<<"response "<<strSplitValue <<" invalid."<<endl;
		throw IOException(strSplitValue + " is invalid.");
	}
	if(nValueInAddress0000 & 0x0001)
	{
		cout<<"In write register 0x0000, RF is On"<<endl;
	}
	else
	{
		cout<<"In write register 0x0000, RF is Off"<<endl;
	}
	//
	if(nValueInAddress0000 & 0x0008)
	{
		cout<<"In write register 0x0000, Fault reset"<<endl;
	}
	else
	{
		cout<<"In write register 0x0000, Normal State"<<endl;
	}
	//
	if(nValueInAddress0000 & 0x0020)
	{
		cout<<"In write register 0x0000, Load Control"<<endl;
	}
	else
	{
		cout<<"In write register 0x0000, Forward Control"<<endl;
	}
	return nValueInAddress0000;
}

bool GeneratorPearl30V6AJ1::writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
	string strCommand = m_cmd[nChannelNum].m_strAddress;

	double dTempValue = dValue * m_nFullScale / typeInfo.getMax();
	int nTemp = (int) dTempValue;
	string strTemp = Hex::hexToString(nTemp,4);
	
	strCommand += strTemp;
	strCommand += CheckCalculationTool::GetLRCCode(strCommand);
	strCommand = StrTool::toUpper(strCommand);
	string strResponse = sendCommandAndReadResponse(strCommand, m_timeOut);
	return true;
}
		
bool GeneratorPearl30V6AJ1::readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo)
{
	Cmd cmd = m_cmd[nChannelNum];
	string strCommand = cmd.m_strAddress + CheckCalculationTool::GetLRCCode(cmd.m_strAddress);
	strCommand = StrTool::toUpper(strCommand);
	string strResponse = sendCommandAndReadResponse(strCommand, m_timeOut);
	size_t nPos = strResponse.find(":");  //changed by wzd 1.1.39
	string strSplitValue = strResponse.substr(nPos+7, 4);
	int nValue = 0;
	if(nChannelNum == 12) //frequency
	{
		if(!Converter::stringToInt(nValue, strSplitValue))
		{
			throw IOException("Generator read frequency failed for can't convert response ["+strSplitValue+"] to integer value.");
		}
		*pValue = (double)nValue;
		return true;
	}
	else
	{
		if(!Hex::stringToHex(&nValue, strSplitValue))
		{
			throw IOException("Generator read power/reflect power failed for can't convert response ["+strSplitValue+"] to integer value.");
		}
		else
		{
			*pValue = (double)nValue * typeInfo.getMax() / m_nFullScale;
			return true;
		}
	}

}
		
bool GeneratorPearl30V6AJ1::readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
	Cmd cmd = m_cmd[nChannelNum];
	string strCommand = cmd.m_strAddress + CheckCalculationTool::GetLRCCode(cmd.m_strAddress);
	strCommand = StrTool::toUpper(strCommand);
	string strResponse = sendCommandAndReadResponse(strCommand, m_timeOut);
	size_t nPos = strResponse.find(":");  //changed by wzd 1.1.39
	string strSplitValue = strResponse.substr(nPos+7, 4);
	int nValue = 0;
	if(!Hex::stringToHex(&nValue, strSplitValue))
	{
		throw IOException("Generator read status failed for can't convert response ["+strSplitValue+"] to integer value.");
	}
	else
	{
		*pValue = (nValue & cmd.m_nDeal) != 0;
		switch(nChannelNum)
		{
			case 14:
			case 15:
			case 16:
			case 17:
			case 18:
			case 19:
				if(*pValue == 1)
				{
					SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "GeneratorPearl30V6AJ1: channel ["+Converter::convertToString(nChannelNum)+"] read back = "+strResponse +" ;split value = "+strSplitValue);
				}
				break;
			default:
				break;
		}
		return true;
	}	
}
		
bool GeneratorPearl30V6AJ1::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
	string strCommand = "";
	//int nTempAddress0000 = m_nAddress0000;
	int nTempAddress0000 = readAddress0000(m_timeOut);

	unsigned char bitmask = 1;
	bitmask = bitmask << m_cmd[nChannelNum].m_nDeal;

	if(nValue == 1)
	{
		nTempAddress0000 = nTempAddress0000 | bitmask;
	}
	else
	{
		bitmask = ~bitmask;
		nTempAddress0000 = nTempAddress0000 & bitmask;
	}
	string strData = Hex::hexToString(nTempAddress0000,4);
	strCommand = m_cmd[nChannelNum].m_strAddress + strData;
	strCommand += CheckCalculationTool::GetLRCCode(strCommand);
	strCommand = StrTool::toUpper(strCommand);//need test to decide if keep it
	sendCommandAndReadResponse(strCommand,m_timeOut);
	//m_nAddress0000 = nTempAddress0000;
	return true;
}

void GeneratorPearl30V6AJ1::initChs(DeviceNode<GeneratorPearl30V6AJ1> *pNode)
{
	pNode->registerWriteCh(1, &GeneratorPearl30V6AJ1::writeInt);
	pNode->registerWriteCh(3, &GeneratorPearl30V6AJ1::writeInt);
	pNode->registerWriteCh(4, &GeneratorPearl30V6AJ1::writeInt);
	pNode->registerWriteCh(6, &GeneratorPearl30V6AJ1::writeDouble);
	for(int i = 10; i<=12; ++i)
	{
		pNode->registerReadCh(i, &GeneratorPearl30V6AJ1::readDouble);
	}
	for(int i = 13; i<=19; ++i)
	{
		pNode->registerReadCh(i, &GeneratorPearl30V6AJ1::readInt);
	}
	pNode->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &GeneratorPearl30V6AJ1::getStatus);
}

void GeneratorPearl30V6AJ1::initDevice()
{
	cout<<"Start Scan pearl generator...."<<endl;
	//say hello to generator
	try
	{
		readAddress0000(m_timeOut);
	}
	catch(exception &ex)
	{
		cout<<"Scan pearl generator failed. Communication abnormal!"<<endl;
		throw;
	}
	cout<<"Scan pearl generator Successfully...."<<endl;
}

void GeneratorPearl30V6AJ1::init()
{
	DeviceNode<GeneratorPearl30V6AJ1> *pNode = new DeviceNode<GeneratorPearl30V6AJ1>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
	if(!isSimulated())
	{
		initChs(pNode);
		initDevice();
	}	
}

IMPLEMENT_DYNAMIC(GeneratorPearl30V6AJ1, SerialDevice )

BEGIN_MSG_MAP(GeneratorPearl30V6AJ1, SerialDevice )
	SET_V( init, GeneratorPearl30V6AJ1 )
END_MSG_MAP
