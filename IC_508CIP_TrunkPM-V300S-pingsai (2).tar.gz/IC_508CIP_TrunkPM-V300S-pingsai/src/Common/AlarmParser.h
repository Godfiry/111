/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AlarmParser.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2012-4-12   Lanf create
**      
*********************************************************************/

#ifndef ALARMPARSER_H_
#define ALARMPARSER_H_

#include <xercesc/util/PlatformUtils.hpp>
#include <xercesc/parsers/AbstractDOMParser.hpp>
#include <xercesc/dom/DOMImplementation.hpp>
#include <xercesc/dom/DOMImplementationLS.hpp>
#include <xercesc/dom/DOMImplementationRegistry.hpp>
#include <xercesc/dom/DOMBuilder.hpp>
#include <xercesc/dom/DOMException.hpp>
#include <xercesc/dom/DOMDocument.hpp>
#include <xercesc/dom/DOMNodeList.hpp>
#include <xercesc/dom/DOMError.hpp>
#include <xercesc/dom/DOMLocator.hpp>
#include <xercesc/dom/DOMNamedNodeMap.hpp>
#include <xercesc/dom/DOMAttr.hpp>
#include <xercesc/util/XMLString.hpp>
#include <fstream>
#include <iomanip>
#include <string>
#include <map>
#include <vector>
#include "Noncopyable.h"
#include "Util.h"
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

XERCES_CPP_NAMESPACE_USE

typedef struct AlarmElement{
	std::string msg;
	std::string des;
	int id;
}AlarmElement;

class XStr : private Noncopyable
{
	private:

	    char *m_str; // This is the local code page form of the string.

	public:
	
	    XStr(const XMLCh* const xch)
	    {
	        // Call the static transcoding method
	        m_str = XMLString::transcode(xch);
	    }
			
	    virtual ~XStr()
	    {
	    	XMLString::release(&m_str); // release the resource
	    }

	    const char* self() const
	    {
	        return m_str;
	    }
};

class XCh : private Noncopyable
{
	private:

	    XMLCh *m_xch; // This is the XMLCh data.
		
	public:
	
	    XCh(const char* const str)
	    {
	        // Call the static transcoding method
	        m_xch = XMLString::transcode(str);
	    }
			
	    virtual ~XCh()
	    {
	    	XMLString::release(&m_xch); // release the resource
	    }

	    const XMLCh* self() const
	    {
	        return m_xch;
	    }
};

class AlarmParser
{
	
private:
	DOMBuilder *m_parser; 
	static AlarmParser *m_instance;		// DOMBuilder of Xerces-C++_2_7_0 
	std::string m_configDir; 	// the config dir 
	// parse specific XML file and return its root element node
	DOMNode* parseXMLFile(const char* const xmlPath);
	static std::map<std::string,AlarmElement> Dscs;  
	std::string m_lang;
	std::vector<std::string> m_rcfiles;
	bool isElementNode(DOMNode *node, const std::string &n);
public:
	AlarmParser();
	virtual ~AlarmParser();
	void setConfigDir(const std::string &path);
	static AlarmParser* getInstance();
	void shutdown();
	void buildAlarmElements();
	void parseFile(const std::string &fileName);
	static std::string getMsg(std::string key);
	static std::string getDes(std::string key);
	static int getAlarmId(std::string key);
	static int replace(std::string &src_str,const std::string old_str,const std::string new_str);
	
	bool isEnVer();
};

#endif /*ALARMPARSER_H_*/
