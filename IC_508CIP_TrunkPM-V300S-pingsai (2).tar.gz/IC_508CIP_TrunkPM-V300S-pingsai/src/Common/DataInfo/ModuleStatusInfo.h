/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					2023-10-31   GuoJin create
**      
***************************************************************************/
#ifndef MODULESTATUSINFO_H_
#define MODULESTATUSINFO_H_
#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class ModuleStatusInfo : public IntValueInfo
{
	public:
		//NotReady:0,Offline:1,Online:2
		static const int NotReady = 0;
		static const int Offline = 1;
		static const int Online = 2;

		static const IntTypeInfo typeInfo;

		ModuleStatusInfo():IntValueInfo(0, typeInfo)
		{

		}

		ModuleStatusInfo(int i):IntValueInfo(i, typeInfo)
		{
		}

		ModuleStatusInfo(std::string s):IntValueInfo(s, typeInfo)
		{
		}
};


#endif /*MODULESTATUSINFO_H_*/
