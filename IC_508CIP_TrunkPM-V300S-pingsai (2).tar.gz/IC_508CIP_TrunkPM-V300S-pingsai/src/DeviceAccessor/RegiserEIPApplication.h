/********************************************************************
** Copyright (c) 2019 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: RegiserEIPApplication.h
** Description:  
** Release: 1.0
** Modification history:           
** 					2019-05-29   Duq create
**                                                 2019-08-30   Duq update
**                                                 2020-06-03   Duq update
*********************************************************************/

#ifndef REGISEREIPAPPLICATION_H_
#define REGISEREIPAPPLICATION_H_

#include "EIPApplication.h"
#include <string>
#include "Converter.h"
#include <map>
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

//
class RegiserEIPApplication
{
	public:
		std::map< std::string, EIPApplication* > m_EIPApplications;
		std::map< std::string, EIPApplication* >::iterator it;
		EIPApplication* att;
		int Offset;
		int m_ConnectionId;
	
	private:
		static RegiserEIPApplication* m_Instance;
		
	public:	
		RegiserEIPApplication();
		virtual ~RegiserEIPApplication();
		void do_RegiserEIPApplication(std::string &serverIP, EIPApplication* att);
		void do_UnRegiserEIPApplication(std::string &serverIP);
		void NoticeRegiseredAttribut(std::string &serverIP, char *data, int len);
		static RegiserEIPApplication* getInstance();
};
#endif  /*REGISEREIPAPPLICATION_H_*/
