/********************************************************************
** Copyright (c) 2021, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TCPFuXiangEPD.cpp
** Description:
** Release: 1.0
** Modification history:
** 					2021-11-23   zhangcx create
**
*********************************************************************/
#include "TCPFuXiangEPD.h"
#include "DeviceManager.h"
#include "Hex.h"
#include "Converter.h"
#include "StrTool.h"
#include <iostream>
#include <string.h>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std;

string TCPFuXiangEPD::m_Commands[]=
				{
					"START#0#",//-------------------------------0.START
					"STOP#0#",//--------------------------------1.STOP
					"INQCONFIG#0#",//---------------------------2.INQCONFIG
					"SETCONFIG#9#",//---------------------------3.SETCONFIG
	            };
TCPFuXiangEPD::TCPFuXiangEPD()
{
	m_mutex=new IMutex(true);

	m_nEndPoint = 0;
	m_nEndPoint1 = 0;//[added by wangyk 1.9.1]
	m_nEndPoint2 = 0;
	m_dTime = 0;
	m_dTime1 = 0;//[added by wangyk 1.9.1]
	m_dTime2 = 0;
	m_strCfgList = "";
	m_strError = "";

	m_strCfg = "";
	m_strCfgName = "#";
	m_strRecipe = "#";
	m_strStep = "#";
	m_strLot1 = "#";
	m_strWafer1 = "#";
	m_strPiece1 = "#";
	m_strLot2 = "#";
	m_strWafer2 = "#";
	m_strPiece2 = "#";
	m_strSendCommandReply = "";//[added by wangyk 1.2.4]
	for(int i = 0; i < 6; i++)//[zhangcx v1.1.23]
	{
		m_dTrendData[i] = 0;
	}
}

TCPFuXiangEPD::~TCPFuXiangEPD()
{
	delete m_mutex;
	m_mutex=NULL;
}

void TCPFuXiangEPD::InitChannels(DeviceNode<TCPFuXiangEPD> *pNode)
{
	for (int i = 0; i <= 3; i++)
	{
		pNode->registerWriteCh(i, &TCPFuXiangEPD::writeI);
	}
	pNode->registerReadCh(4, &TCPFuXiangEPD::readI);
	pNode->registerReadCh(5, &TCPFuXiangEPD::readD);
	for (int i = 6; i <= 7; i++)
	{
		pNode->registerReadCh(i, &TCPFuXiangEPD::readStr);
	}
	for (int i = 8; i <= 16; i++)
	{
		pNode->registerWriteCh(i, &TCPFuXiangEPD::writeStr);
	}
	pNode->registerWriteCh(101, &TCPFuXiangEPD::writeRawCmd);
	for (int i = 110; i <= 117; i++)//[zhangcx v1.1.23]//[changed by wangyk 1.9.1]
	{
		pNode->registerReadCh(i, &TCPFuXiangEPD::readD);
	}
	for (int i = 118; i <= 119; i++)//[added by wangyk 1.9.1]
	{
		pNode->registerReadCh(i, &TCPFuXiangEPD::readI);
	}
	pNode->registerReadCh(COMMUNICATION_STATUS_CHANNEL,&TCPFuXiangEPD::getStatus);//zhangyy add[v1.1.60_RC_01]
}

void TCPFuXiangEPD::InitDevice()
{
	cout<<"TCPFuXiangEPD::  TCP connecting...."<<endl;
	TCPDevice::init();//connect;
	sleep(1);
	cout<<"TCPFuXiangEPD::  TCP connected"<<endl;

	/*string strCmd = "";
	strCmd = m_strHead + m_Commands[2];
	//Log_Info(getName()+": PC->EPD:" + strCmd);
	sendData(strCmd.c_str(), strCmd.length());*/
}

void TCPFuXiangEPD::acceptData()
{
	//cout<<"TCPFuXiangEPD::acceptData()......."<<endl;
	memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
	if(readData(m_recvBuffer, sizeof(m_recvBuffer)))
	{
		//cout<<"TCPFuXiangEPD Device->PC: " + string(m_recvBuffer)<<endl;
		Log_Info(getDeviceName() + ": Device->PC: "  + string(m_recvBuffer));
		onReceiveMsg(m_recvBuffer);
	}
}

void TCPFuXiangEPD::onReceiveMsg(string strData)
{
	IMutexLocker locker(m_mutex);
	//cout<<"TCPFuXiangEPD::acceptData().......:" + strData<<endl;
	Log_Info(getDeviceName() + ":acceptData().......: "  + strData);
	Subpackage(strData);
}

void TCPFuXiangEPD::Subpackage(string strMassage)
{
	if (strMassage!="")
	{
		string separator = m_strHead;
		vector<string> splitStrings = StrTool::split(strMassage,separator);

		for (int unsigned i = 0; i < splitStrings.size(); i++)
		{
			if (splitStrings[i]!="")
			{
				string strData=m_strHead+splitStrings[i];
				dispatchMsg(strData);
			}
		}
	}
}

void TCPFuXiangEPD::dispatchMsg(string strMassage)
{
	Log_Info("dispatchMsg: "  + strMassage);
	char separator[] ={ '#' };
	vector<string> splitStrings = StrTool::split(strMassage,separator,1);
	if(splitStrings.size() < 4)
	{
		Log_Info("Receive Unexpected Messages: " + strMassage);
		throw IOException("Unexpected Messages!");
	}

	string strCmd = "";
	string strData="";
	int nLength = 0;

	strCmd = splitStrings[1];
	Log_Info("strCmd: "  + strCmd);
	Converter::stringToInt(nLength, splitStrings[2]);
	Log_Info("nLength: "  + Converter::convertToString(nLength));

	//splitStrings example: PM2#SPECFRAME#6#1177.3#1109.4#6519.5#1217.8#1108.6#7161.8#
	if(splitStrings.size()-3 != nLength)// added by wangyk 20250721 PM1��5.0 RC02
	{
		Log_Info("Receive Unexpected Messages: " + strMassage);
		throw IOException("Unexpected Messages!");
	}

	if(nLength > 0)
	{
		for (int unsigned i = 0; i < nLength; i++)
		{
			strData = strData + splitStrings[3+i] + ",";
		}
		strData.erase(strData.length() - 1);
	}
	else
	{
		Log_Info("Receive Wrong Messages: " + strMassage);
		throw IOException("Wrong Messages!");
	}
	dealWithMsg(strCmd, strData);
}

void TCPFuXiangEPD::dealWithMsg(string strMsgCmd, string strMsgData)
{
	Log_Info("dealWithMsg: " + strMsgCmd + ", " + strMsgData);
	if(strMsgCmd == "INQCONFIG")
	{
		m_strCfgList = strMsgData;
		Log_Info("The Config List is: " + m_strCfgList);
		return;
	}
	if(strMsgCmd == "ENDPOINT")
	{
		Converter::stringToDouble(m_dTime, strMsgData);
		m_nEndPoint = 1;
		Log_Info("Arrive EndPoint, The End Time is %f", m_dTime);
		return;
	}
	if(strMsgCmd == "ST1EP")//[added by wangyk 1.9.1]
	{
		Converter::stringToDouble(m_dTime1, strMsgData);
		m_nEndPoint1 = 1;
		Log_Info("Arrive ST1 EndPoint, The End Time is %f", m_dTime);
		return;
	}
	if(strMsgCmd == "ST2EP")//[added by wangyk 1.9.1]
	{
		Converter::stringToDouble(m_dTime2, strMsgData);
		m_nEndPoint2 = 1;
		Log_Info("Arrive ST2 EndPoint, The End Time is %f", m_dTime);
		return;
	}
	if(strMsgCmd == "ERROR")
	{
		m_strError = strMsgData;
		Log_Info("Error, The Messages is: " + m_strError);
		return;
	}
	if(strMsgCmd == "START")
	{
		if (strMsgData == "1")
		{
			Log_Info("EPD started successfully!");
		}
		m_strSendCommandReply = strMsgData;//[added by wangyk 1.2.4]
		m_waitAction.wakeAll();
		return;
	}
	if(strMsgCmd == "STOP")
	{
		if (strMsgData == "1")
		{
			Log_Info("EPD stopped successfully!");
		}
		for(int i = 0; i < 6; i++)//[zhangcx v1.1.23]
		{
			m_dTrendData[i] = 0;
		}
		m_strSendCommandReply = strMsgData;//[added by wangyk 1.2.4]
		m_waitAction.wakeAll();
		return;
	}
	if(strMsgCmd == "SETCONFIG")
	{
		if (strMsgData == "1")
		{
			Log_Info("EPD setconfig successfully!");
		}
		m_strSendCommandReply = strMsgData;//[added by wangyk 1.2.4]
		m_waitAction.wakeAll();
		return;
	}

	if(strMsgCmd == "SPECFRAME")//[zhangcx v1.1.23]
	{
		char separator[] ={ ',' };
		vector<string> splitStrings = StrTool::split(strMsgData,separator,1);
		for(int i = 0; i < 6; i++)
		{
			Converter::stringToDouble(m_dTrendData[i],splitStrings[i]);
		}
		return;
	}
	//Log_Info("Receive Unexpected Massages: " + strMsgCmd + ", " + strMsgData);
}

bool TCPFuXiangEPD::writeI(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
	IMutexLocker locker(m_mutex);

	if (nChannelNum < 0 || nChannelNum > 3)
	{
		Log_Error("BuildCmd ERR-----------nCmdID=d%" , nChannelNum);
		throw IOException("command not exist.");
	}
	string strCmd = "";
	string strCfg = "";
	m_strSendCommandReply = "";
	strCmd = m_strHead + m_Commands[nChannelNum];
	if(nChannelNum == 0)
	{
		m_nEndPoint = 0;
		m_dTime = 0;
		m_nEndPoint1 = 0;//[added by wangyk 1.9.1]
		m_nEndPoint2 = 0;
		m_dTime1 = 0;
		m_dTime2 = 0;
		m_strCfg = m_strCfgName + m_strRecipe + m_strStep + m_strLot1 + m_strWafer1 + m_strPiece1 + m_strLot2 + m_strWafer2 + m_strPiece2;

		strCfg = m_strHead + m_Commands[3] + m_strCfg;
		Log_Info(getName()+": EPD will start, PC->EPD:" + strCfg);
		sendData(strCfg.c_str(), strCfg.length());
	}
	if(nChannelNum == 3)
	{
		m_strCfg = m_strCfgName + m_strRecipe + m_strStep + m_strLot1 + m_strWafer1 + m_strPiece1 + m_strLot2 + m_strWafer2 + m_strPiece2;
		strCmd = strCmd + m_strCfg;
	}

	Log_Info(getName()+": PC->EPD:" + strCmd);
	sendData(strCmd.c_str(), strCmd.length());

	if(nChannelNum != 2)//[added by wangyk 1.2.4]
	{
		if(m_waitAction.wait(m_mutex, 5000))
		{
			if(m_strSendCommandReply != "1")
			{
				Log_Error("Send Command \" %s \" error for incorrect reply" , strCmd);
				throw IOException(strCmd+": Command get incorrect reply.");
			}
		}
		else
		{
			Log_Info(getName()+": Send Command \" %s \" error for wait reply time out !" + strCmd);
			throw IOException(strCmd+": Wait command reply time out");
		}
	}

	return true;
}

bool TCPFuXiangEPD::readI(int nChannelNum, int *nValue, const IntTypeInfo &typeInfo)
{
	IMutexLocker locker(m_mutex);

	switch(nChannelNum)//[added by wangyk 1.9.1]
	{
		case 4: //EndPoint signal
			*nValue = m_nEndPoint;
			break;
		case 118: //ST1 EndPoint signal
			*nValue = m_nEndPoint1;
			break;
		case 119: //ST2 EndPoint signal
			*nValue = m_nEndPoint2;
			break;
		defalut:
			break;
	}
	return true;
}

bool TCPFuXiangEPD::readD(int nChannelNum, double *dValue, const DoubleTypeInfo &typeInfo)
{
	IMutexLocker locker(m_mutex);

	switch(nChannelNum)//[zhangcx v1.1.23]
	{
		case 5: //EPDTime
			*dValue = m_dTime;
			break;
		case 110://TrendData1
			*dValue = m_dTrendData[0];
			break;
		case 111://TrendData2
			*dValue = m_dTrendData[1];
			break;
		case 112://TrendData3
			*dValue = m_dTrendData[2];
			break;
		case 113://TrendData4
			*dValue = m_dTrendData[3];
			break;
		case 114://TrendData5
			*dValue = m_dTrendData[4];
			break;
		case 115://TrendData6
			*dValue = m_dTrendData[5];
			break;
		case 116://ST1 EPDTime //[added by wangyk 1.9.1]
			*dValue = m_dTime1;
			break;
		case 117://ST2 EPDTime //[added by wangyk 1.9.1]
			*dValue = m_dTime2;
			break;
		defalut:
			break;
	}
	return true;
}

bool TCPFuXiangEPD::readStr(int nChannelNum, std::string *strCommand, const StringTypeInfo &typeInfo)
{
	IMutexLocker locker(m_mutex);
	switch(nChannelNum)
	{
	case 6: //Error
		*strCommand = m_strError;
		break;
	case 7://CfgList
		string strCmd = "";
		strCmd = m_strHead + m_Commands[2];
		Log_Info(getName()+": PC->EPD:" + strCmd);
		sendData(strCmd.c_str(), strCmd.length());
		usleep(300 * 1000);
		*strCommand = m_strCfgList;
		break;
	defalut:
		break;
	}
	return true;
}

bool TCPFuXiangEPD::writeStr(int nChannelNum, std::string strCommand, const StringTypeInfo &typeInfo)
{
	IMutexLocker locker(m_mutex);
	if(StrTool::contains(strCommand,"#"))//[wangyk 1.2.0]
	{
		StrTool::string_replace(strCommand,"#","@");
	}
	switch(nChannelNum)
	{
		case 8: //ConfigureName
			m_strCfgName = strCommand + "#";
			break;
		case 9://Recipe
			m_strRecipe = strCommand + "#";
			break;
		case 10: //Step
			m_strStep = strCommand + "#";
			break;
		case 11://Lot1
			m_strLot1 = strCommand + "#";
			break;
		case 12: //Wafer1
			m_strWafer1 = strCommand + "#";
			break;
		case 13://Piece1
			m_strPiece1 = strCommand + "#";
			break;
		case 14: //Lot2
			m_strLot2 = strCommand + "#";
			break;
		case 15://Wafer2
			m_strWafer2 = strCommand + "#";
			break;
		case 16: //Piece2
			m_strPiece2 = strCommand + "#";
			break;
		defalut:
			break;
	}
	return true;
}

bool TCPFuXiangEPD::writeRawCmd(int nChannelNum, std::string strCommand, const StringTypeInfo &typeInfo)
{
	if (!isConnected())
	{
		throw IOException("device is not connected! ");
	}
	string strTotalCommand = strCommand;
	Log_Info(getDeviceName() + ": PC->Device: "+strTotalCommand);
	sendData(strTotalCommand.c_str(), strTotalCommand.length());
	return true;
}

void TCPFuXiangEPD::init()
{
	cout<<"EPD:init-----------"<<endl;
	DeviceNode<TCPFuXiangEPD> *pNode = new DeviceNode<TCPFuXiangEPD>(m_pollInterval,this);
	InitChannels(pNode);
	DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);

	if(!isSimulated())
	{
		InitDevice();
	}
}

void TCPFuXiangEPD::setPMName(const std::string &strPMName)
{
	m_strHead = strPMName.substr(0, 3) + "#";
	Log_Info("The strHead is " + m_strHead);
}

string TCPFuXiangEPD::getDeviceName()
{
	return __FILE__;
}

IMPLEMENT_DYNAMIC(TCPFuXiangEPD, TCPDevice)
BEGIN_MSG_MAP(TCPFuXiangEPD, TCPDevice)
	SET_V(init, TCPFuXiangEPD)
	SET_S(setPMName, TCPFuXiangEPD)
END_MSG_MAP

