/********************************************************************
** Copyright (c) 2021, Beijing NAURA Co.,Ltd.  All rights reserved.
** File name: BeckhoffPlc.h
** Description:Beckhoff module communication through TCP/IP Protocol
** Release: 1.1
** Modification history:
**                     2021-1-20   chenmz create
**                     2021-2-1   mayc modified
**
*********************************************************************/
#include "BeckhoffPlc.h"

#include "DeviceManager.h"
#include "Converter.h"
#ifdef IAP4_0
#include "ITime.h"
#else
#include "Time.h"
#endif
#include "UTime.h"
#include "Hex.h"
#include "ObjectManager.h"
#include <sys/time.h>
#include <string.h>
#include <math.h>
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;


BeckhoffPlc::BeckhoffPlc()
{

    bzero(m_modbusSend, sizeof(m_modbusSend));//set 0

    // fixed header title
    m_modbusSend[0] = 0x00; /*Header title is fixed: 00 00 00 00 */
    m_modbusSend[1] = 0x00;
    m_modbusSend[2] = 0x00;
    m_modbusSend[3] = 0x00;
    m_bWaiting = false;
    m_bReadCmd = false;
    m_strError = "";
    m_strRawResult = "";
    m_strResult = "";

    m_doParam.clear();
    m_diParam.clear();
}

BeckhoffPlc::~BeckhoffPlc()
{


}

void BeckhoffPlc::modbusSendCommand(const Param &param, void *val, int nValLen, const std::string &strErrTitle)
{
    ////////////////////////////////////////////////////////
    // <><>     1. Send modbus cmd to server (plc)     <><> //
    ////////////////////////////////////////////////////////

    // 1.1 Cal and fill Length-code for send command
    //
    m_modbusSend[4] = param.m_cLenH; //0, if msg length less 256bytes
    m_modbusSend[5] = param.m_cLenL;

    // assert no else <><><>
    // 1.2 Fill unit identify, default 255
    if(param.m_cUid != 0xFF)
    {
        m_modbusSend[6] = param.m_cUid;
    }
    else
    {
        m_modbusSend[6] = 0xFF;
    }

    // 1.3 Fill function-code
    //
    m_modbusSend[7] = param.m_cFuncCode;

    //1.4 Fill data address, for bit - offset start from 0x0000, for word - offset start from 0x0800
    //
    m_modbusSend[8] = param.m_cAddrH;
    m_modbusSend[9] = param.m_cAddrL;

    // 1.5 Fill input 'val'
    //

   switch (param.m_cFuncCode)
   {
      case 0x01:
      case 0x02:
           if (ceil(nValLen/8.0) > 56) //secondly check ,because the array size is 64.
           {
               string strErr = strErrTitle+":Invalid valLen '"+ Converter::convertToString(nValLen)+"'.It is too large.";
               throw strErr;
           }
           m_modbusSend[10] = ((nValLen & 0xff00) >> 8);  //func1/2 is bit counter;
           m_modbusSend[11] = nValLen & 0x00ff;
           break;

      case 0x05://DO
      case 0x06://AO
           memcpy(m_modbusSend + 10, (unsigned char*)val + 1, 1);
           memcpy(m_modbusSend + 11, (unsigned char*)val + 0, 1);
           break;
           
      case 0x0f:     
          {
               m_modbusSend[10] = (unsigned char)((nValLen & 0xff00) >> 8);
               m_modbusSend[11] = (unsigned char)(nValLen & 0x00ff);
               int valueByteCounter = (int)ceil(nValLen/8.0);
               if (valueByteCounter > 52)
               {
                    string strErr = strErrTitle+":Invalid valLen '"+Converter::convertToString(valueByteCounter)+"'.It is too large";
                    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, strErr);
                    throw strErr;
               }
               m_modbusSend[12] = (unsigned char)(valueByteCounter & 0xff);
               for (int i = 0; i < valueByteCounter; i++)
               {
                    memcpy(m_modbusSend+13+i, (unsigned char*)val+i, 1);
                    //memcpy(m_modbusSend + 14, (unsigned char*)val + 0, 1);
                    //cout << "@ data [" << charArrayToStr((unsigned char*)val+i,1) << "] " << endl;
                    //cout << "@ data [" << charArrayToStr(&m_modbusSend[13+i],1) << "] " << endl;
               }
          }
            break;
            
       case 0x10: //DO
              {
                  int nWordlenth = 0;
                  if (nValLen % 2 == 0 )
                  {
                      nWordlenth = nValLen/2;
                  }
                  else
                  {
                   string strErr = strErrTitle+":  The input value length '"+Converter::convertToString(nValLen)+"' is invalid,not a even.";
                   SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, strErr);
                   throw strErr;
                  }
             
                  m_modbusSend[10] = (unsigned char)((nWordlenth & 0xff00) >> 8);//data word counter high
                  m_modbusSend[11] = (unsigned char)(nWordlenth & 0x00ff); //data word counter low
                  m_modbusSend[12] = (unsigned char)(nValLen & 0xff);    //data bytes counter
            
                  if (nValLen > 52)
                  {
                   string strErr = strErrTitle+":Invalid valLen '"+Converter::convertToString(nValLen)+"'.It is too large";
                   throw strErr;
                  }
                  for (int i = 0; i < nValLen; i++)
               {
                      if (i % 2 == 0)
                      {
                          memcpy(m_modbusSend + 13 + i, (unsigned char*)val + i + 1, 1);
                      }
                      else
                      {
                          memcpy(m_modbusSend + 13 + i, (unsigned char*)val + i - 1, 1);
                      }
               }
              }
              break;

       default: // impossible
         break;
    }

    // 1.5 Send command frame
    //
    m_bWaiting = true;
    m_strError = "";
    int nTotalLen = ((int)(m_modbusSend[4]) << 8) + (int)(m_modbusSend[5]) + 6;
    
    sendData(m_modbusSend,nTotalLen);
    
    int nLeftcount = m_timeOut*1000 / m_checkInterval;
    while(nLeftcount >= 0)
    {
        if(!m_bWaiting)
        {
            if(m_strError != "")
            {
                throw IOException(m_strError);
            }
            else
            {
                return;
            }
        }
        usleep(m_checkInterval * 1000);
        --nLeftcount;
    }
    throw IOException("command read_back timeOut");
   
}

bool BeckhoffPlc::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
    string nErrTitle = "BeckhoffPlc::writeInt("+Converter::convertToString(nChannelNum)+")";
    if (nChannelNum >= (int)m_doParam.size())
    {
        string strErr = nErrTitle+": Invalid channel number.";
        throw IOException(strErr);
    }
    modbusSendCommand(m_doParam[nChannelNum], &nValue, m_doParam[nChannelNum].m_nByteLen, nErrTitle); // IOException

    return true;
}

bool BeckhoffPlc::readInt(int nChannelNum, int *nValue, const IntTypeInfo &typeInfo)
{
    if (!isConnected())
    {
        throw IOException("device is not connected! ");
    }
    int nIndex = nChannelNum - 1000;
    string strErrTitle = "BeckhoffPlc::readInt("+Converter::convertToString(nChannelNum)+")";
    if (nIndex >= (int)m_diParam.size())
    {
        string strErr = strErrTitle+": Invalid channel number.";
        throw IOException(strErr);
    }
    m_bReadCmd = true;
    m_strResult = "";
    modbusSendCommand(m_diParam[nIndex], NULL, m_diParam[nIndex].m_nByteLen, strErrTitle); // IOException
    m_bReadCmd = false;
    if(((int)m_recvBuffer[8]) > 0)  //m_modbusRecv[8] the data bytes counter of response
    {
        //if ((int)m_diParam[index].m_addrBit != 16)  //only used to check one bit.
        if ((m_diParam[nIndex].m_cFuncCode == 0x01) ||(m_diParam[nIndex].m_cFuncCode == 0x02))
        {
            *nValue = m_recvBuffer[9];
        }
    }
    else
    {
        string strErr= strErrTitle + ": No Data has received.";
        throw IOException(strErrTitle + ": No Data has received.");
    }
    return true;
}

void BeckhoffPlc::initChannels(DeviceNode<BeckhoffPlc> *node)
{
    int nIndex = 0;
    for (nIndex = 0; nIndex <= m_doParam.size(); ++nIndex)
    {
          node->registerWriteCh(nIndex, &BeckhoffPlc::writeInt); // DuplicatedException
    }
  
    for (unsigned int i = 1000; i < (m_diParam.size() + 1000); ++i)
    {
        node->registerReadCh(i, &BeckhoffPlc::readInt); // DuplicatedException
    }
    return;
}

void BeckhoffPlc::init()
{
    cout<<"BeckhoffPlc start to init"<<endl;
    DeviceNode<BeckhoffPlc> *node = new DeviceNode<BeckhoffPlc>(m_pollInterval,this);
    DeviceManager::getInstance()->registerNode(m_nodeNum,node);

    if(!isSimulated())
    {
        cout<<"BeckhoffPlc start to init channels"<<endl;
        initChannels(node);
        cout<<"BeckhoffPlc init channels ok"<<endl;
        TCPDevice::init();
    }
}

void BeckhoffPlc::parseReply()
{
    string strReply = Hex::GetHexString(m_recvBuffer,12);
    if(!m_bReadCmd)
    {
        #ifdef IAP4_0
        cout << "BeckhoffPlc: [" << ITime::getCurrentTimeAsStr() << "] " << getDeviceName() <<" reply:" <<strReply<<endl;
        #else
        cout << "BeckhoffPlc: [" << Time::getCurrentTimeAsStr() << "] " << getDeviceName() <<" reply:" <<strReply<<endl;
        #endif
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "@@@@@"+getDeviceName() + " reply: " + strReply);
    }
   //2.2 check function code, should be same as send command
       long nLeftTime = m_timeOut * 1000;//ms
    long nStartTime = UTime::getCurrentTimeAsMSeconds();
    while(nLeftTime > 0)
    {
        if(m_recvBuffer[7] > 0x80)
        {
            string strErr = ": Receive unknown MODBUS response ! Error function code is '"+ Converter::convertToString(m_recvBuffer[8])+"'.";
            #ifdef IAP4_0
            cout << "BeckhoffPlc: [" << ITime::getCurrentTimeAsStr() << "] " << strErr << endl;
            #else
            cout << "BeckhoffPlc: [" << Time::getCurrentTimeAsStr() << "] " << strErr << endl;
            #endif
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, strErr);
            m_strError = strErr+"reply is"+strReply;
        }
        if (!m_bReadCmd)
        {
            if( (m_modbusSend[7] == 0x05) || (m_modbusSend[7] == 0x06) || (m_modbusSend[7] == 0x0f) || (m_modbusSend[7] == 0x016))
            {
                if(m_recvBuffer[7] != m_modbusSend[7]
                    || m_recvBuffer[8] != m_modbusSend[8]
                    || m_recvBuffer[9] != m_modbusSend[9]
                    || m_recvBuffer[10] != m_modbusSend[10]
                    || m_recvBuffer[11] != m_modbusSend[11])
                {
                    string strErr = ": Receive MODBUS response frame failed! Invalid source node address '";
                    #ifdef IAP4_0
                    cout << "BeckhoffPlc: [" << ITime::getCurrentTimeAsStr() << "] " << strErr << endl;
                    #else
                    cout << "BeckhoffPlc: [" << Time::getCurrentTimeAsStr() << "] " << strErr << endl;
                    #endif
                    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, strErr);
                    m_strError = strErr+"reply is"+strReply;
                }
            }
        }
        if(!m_bReadCmd && m_strError.empty())
        {
            //cout<<"send command reply is ****"<<t_reply<<endl;
            return;
        }
        if(m_bReadCmd && m_strResult == "")
        {
            if(m_recvBuffer[7] == 0x01)
            {
                m_strResult == strReply;
                return;
            }
        }
        usleep(m_checkInterval*1000);
        flush();
        strReply +=  Hex::GetHexString(m_recvBuffer,12);
        if(!m_bReadCmd)
        {
            #ifdef IAP4_0
            cout << "BeckhoffPlc: [" <<ITime::getCurrentTimeAsStr() << "] " << getDeviceName() <<" reply n:" << strReply<< endl;
            #else
            cout << "BeckhoffPlc: [" <<Time::getCurrentTimeAsStr() << "] " << getDeviceName() <<" reply n:" << strReply<< endl;
            #endif
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "@@@@@"+getDeviceName() + " reply n: " + strReply);
        }
        nLeftTime -= UTime::getCurrentTimeAsMSeconds() - nStartTime;
    }
    m_strError = "waiting Receive timeout " + strReply;
}

void BeckhoffPlc::flush()
{
    memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
    if(!readData(m_recvBuffer, sizeof(m_recvBuffer)))
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": reading failed in flush()");
    }

}

void BeckhoffPlc::acceptData()
{
    memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
    /////////////////////////////////////////////////////////
    // <><>  2. Recv fins response from server (plc) <><>  //
    /////////////////////////////////    ////////////////////////

    // 2.1 reveive data
    if(readData(m_recvBuffer, sizeof(m_recvBuffer)))
    {
        if(m_bWaiting)
        {
            parseReply();
            m_bWaiting = false;
        }
        else
        {
            m_strRawResult = Hex::GetHexString(m_recvBuffer,12);
            #ifdef IAP4_0
            cout << "BeckhoffPlc: [" << ITime::getCurrentTimeAsStr() << "] " << getDeviceName() << " rawResult:"<< m_strRawResult<< endl;
            #else
            cout << "BeckhoffPlc: [" << Time::getCurrentTimeAsStr() << "] " << getDeviceName() << " rawResult:"<< m_strRawResult<< endl;
            #endif
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": in acceptData() is not waiting");
        }
    }
    else
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": reading failed in acceptData()");
        if(m_bWaiting)
        {
            m_strError = "read_back from device failed";
            m_bWaiting = false;
        }
    }
}

void BeckhoffPlc::addParamDO(int nAreaCode, int nAreaAddr, int nByteLen)
{
    if (nByteLen!=1 && nByteLen!=2 && nByteLen!=4)
    {
        throw string("Variable length (in word) must be '1' or '2' or '4'.");
    }

    Param newParam(nAreaCode, nAreaAddr, nByteLen); // throw string for invalid inputs

    if (find(m_doParam.begin(), m_doParam.end(), newParam) != m_doParam.end())
    {
        throw string("Duplicated DO-Param("+Converter::convertToString(nAreaCode)+", "+Converter::convertToString(nAreaAddr)+", "+Converter::convertToString(nByteLen)+").");
    }

    if (m_doParam.size() > 1000)
    {
        throw string("Total DO-Param number is over 1000.");
    }

    m_doParam.push_back(newParam);
}

/*ParamDI  type bool,value is 0 or 1,can use func1,2 valLen is bit basis
 ParamDI  type bool,value is 0 or 1,can use func3,4 valLen is byte basis*/
void BeckhoffPlc::addParamDI(int nAreaCode, int nAreaAddr, int nByteLen)//, int addrBit)
{
    /*if (addrBit == 16)
    {
       if ((valLen != 2) && (valLen != 4))
        {
            throw string("Variable length (in byte) is not '2' or '4'.");
        }
    }
    else
    {
        if (valLen >= 32)
        {
            throw string("Variable length (in bit) is bigger than 31.");
        }
    }*/

    Param newParam(nAreaCode, nAreaAddr, nByteLen);//, addrBit); //

    if (find(m_diParam.begin(), m_diParam.end(), newParam) != m_diParam.end())
    {
        throw string("Duplicated DI-Param("+Converter::convertToString(nAreaCode)+", "+Converter::convertToString(nAreaAddr)+", "+Converter::convertToString(nByteLen)+").");
    }

    if (m_diParam.size() > 1000)
    {
        throw string("Total DI-Param number is over 1000.");
    }

    m_diParam.push_back(newParam);
}

BeckhoffPlc::Param::Param()
{
    m_nAreaCode = 0;
    m_cLenH = 0;
    m_cLenL = 0;
    m_cUid = 0;
    m_cFuncCode = 0;

    m_nAreaAddr = 0;
    m_cAddrH = 0;
    m_cAddrL = 0;

    m_nByteLen = 0;
}

BeckhoffPlc::Param::Param(int nAreaCode, int strAreaAddr, int strByteLen)
{
    string strErrTitle = "Param("+Converter::convertToString(nAreaCode)+", "+Converter::convertToString(strAreaAddr)+", "+Converter::convertToString(strByteLen)+")";
    /*[lenH, lenL, uid, funcCode] [addr_H, addr_L, addr_Bit] [wordLen_H, wordLen_L]*/
    m_nAreaCode = nAreaCode;

    m_cLenH = (unsigned char)((nAreaCode & 0xff000000) >> 24);
    if (m_cLenH != 0x00)
    {
        throw string(strErrTitle+": Message length is large than 256bytes.");
    }

    m_cLenL = (unsigned char)((nAreaCode & 0x00ff0000) >> 16);
    m_cUid = (unsigned char)((nAreaCode & 0x0000ff00) >> 8);
    m_cFuncCode = (unsigned char)(nAreaCode & 0x000000ff);
    
    if ((m_cFuncCode != WR_BIT)
        && (m_cFuncCode != WR_WORD)
        && (m_cFuncCode != MWR_BIT)
        && (m_cFuncCode != MWR_WORD)
        && (m_cFuncCode != R_COILBITS)
        && (m_cFuncCode != R_INPUTBITS)
        && (m_cFuncCode != R_HREGWORD)
        && (m_cFuncCode != R_IREGWORD))
    {
        throw string(strErrTitle+": Invalid function code.");
    }
    m_nAreaAddr = strAreaAddr;

    m_cAddrH = (unsigned char)((strAreaAddr & 0xff00) >> 8);
    m_cAddrL = (unsigned char)((strAreaAddr & 0x00ff));

    m_nByteLen =( (unsigned char) (strByteLen)) & 0xff;
}

bool BeckhoffPlc::Param::operator==(const Param &right) const
{
    return (m_nAreaCode == right.m_nAreaCode) 
           && (m_cUid == right.m_cUid) 
           && (m_cFuncCode == right.m_cFuncCode) 
           && (m_cLenH == right.m_cLenH) 
           && (m_cLenL == right.m_cLenL)
           && (m_nAreaAddr == right.m_nAreaAddr) 
           && (m_cAddrH == right.m_cAddrH) 
           && (m_cAddrL == right.m_cAddrL) 
           && (m_nByteLen == right.m_nByteLen);
}

string BeckhoffPlc::getDeviceName()
{
    return "BeckhoffPlc";
}

IMPLEMENT_DYNAMIC( BeckhoffPlc, TCPDevice )

BEGIN_MSG_MAP( BeckhoffPlc, TCPDevice )
    SET_III( addParamDO, BeckhoffPlc )
    SET_III( addParamDI, BeckhoffPlc )
    SET_V( init, BeckhoffPlc )
END_MSG_MAP
