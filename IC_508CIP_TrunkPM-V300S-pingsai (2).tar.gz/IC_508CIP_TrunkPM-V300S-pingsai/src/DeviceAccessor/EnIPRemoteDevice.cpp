/********************************************************************
** Copyright (c) 2019 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: EnIPRemoteDevice.cpp
** Description:  
** Release: 1.0
** Modification history:           
** 					2019-08-30   Duq create
**                                                 2020-06-03   Duq update
*********************************************************************/

#include "EnIPRemoteDevice.h"
#include <string.h>
#include "Converter.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#include <iostream>
#include <unistd.h>
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;

EnIPRemoteDevice::EnIPRemoteDevice(uint16_t configIid, uint16_t inputIid, uint16_t outputIid, string &service)
{
	m_classID = 4;
	m_attributID = 3;
	m_configInstanceID = configIid;
	m_inputInstanceID = inputIid;
	m_outputInstanceID = outputIid;
	m_inputEPath = EnIPPath::GetPath(&m_classID, m_inputInstanceID, &m_attributID);
	m_outputEPath = EnIPPath::GetPath(&m_classID, m_outputInstanceID, &m_attributID);
	m_SessionHandle = 0;
	m_serverIP = service;
	m_Tcpclient = new EnIPTCPClientTransport(service); 
	m_Udpclient = new EnIPUDPClientTransport(service); 
	m_config = NULL;
	m_closePkt = NULL;
	m_inputPocketSize = 0;
	m_outputPocketSize = 0;
	m_SequenceNumber = 0;
	m_inputBuffer = NULL;
	m_outputBuffer = NULL;
	m_running = false;
	m_runningstatus = false;
	m_cycleTime = 200*1000;    //200ms
}

EnIPRemoteDevice::~EnIPRemoteDevice()
{
	delete m_Tcpclient;
	m_Tcpclient = NULL;
	delete m_Udpclient;
	m_Udpclient = NULL;	
	delete [] m_inputBuffer;
	m_inputBuffer = NULL;
	delete [] m_outputBuffer;
	m_outputBuffer = NULL;
}
		
bool EnIPRemoteDevice::isConnected()
{
	return m_Tcpclient->isConnected();
}

//RegisterSession Encapsulation_Packet: 28bytes
bool EnIPRemoteDevice::do_RegisterSession()
{
    if ((isConnected()) && (m_SessionHandle == 0))
    {
		char tempdata[4] = {1,0,0,0};        
		string encapsulateddata = "";
		encapsulateddata.assign(tempdata, 4);
		EncapsulationCommands ss = RegisterSessionCommand;
        Encapsulation_Packet sendPoceket = Encapsulation_Packet(ss, 0, encapsulateddata);
		string senddata = sendPoceket.toByteArray();
		int sendLength = senddata.length();
		
		//cout<<"EnIPRemoteDevice::RegisterSession: sendLength"<<sendLength<<endl;
		const char* sendBuffer = senddata.data();
        int ret = 0;
		int Offset = 0;
		char recvBuffer[28] = {0};
/*		for(int i = 0; i < sendLength; i++)
		{
			cout<<"i: "<<i<<" sendBuffer: "<<(int)sendBuffer[i]<<endl;
		}*/
		try
		{
			ret = m_Tcpclient->SendReceive(sendBuffer, sendLength, recvBuffer);
		}
        catch(const exception &ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "EnIPRemoteDevice::do_RegisterSession got exception: " + string(ex.what()));
			return false;
		}
/*		for(int i = 0; i < ret; i++)
		{
			cout<<"i: "<<i<<" recvBuffer: "<<(int)recvBuffer[i]<<endl;
		}*/
        if (ret == 28)
		{
			string Packet = "";
			Packet.assign(recvBuffer, 28);
			bool result = sendPoceket.analysisEncapsulationPacket(Packet, Offset, ret);
			
			if (result)
			{
				m_SessionHandle = sendPoceket.m_Sessionhandle;
				//cout<<"m_SessionHandle: "<<m_SessionHandle<<endl;
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
    }
	return false;
}

//UnRegisterSession Encapsulation_Packet: 24bytes
void EnIPRemoteDevice::do_UnRegisterSession()
{
    if (m_SessionHandle != 0)
    {
		EncapsulationCommands ss = UnRegisterSessionCommand;
		string encapsulateddata = "";
        Encapsulation_Packet sendPoceket = Encapsulation_Packet(ss, m_SessionHandle, encapsulateddata);
		string senddata = sendPoceket.toByteArray();
		int sendLength = senddata.length();
		const char* sendBuffer = senddata.data();
		try
		{
			m_Tcpclient->SendReceive(sendBuffer, sendLength);	
		}
		catch(const exception &ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "EnIPRemoteDevice::do_UnRegisterSession got exception: " + string(ex.what()));
		}
		m_SessionHandle = 0;
    }
}

bool EnIPRemoteDevice::do_GetDataSize()
{
	CIPServiceCodes ServiceCode = GetAttributeSingle;
	int Offset = 0;
	int Lenght = 0;
	string Packet = "";
	string tempdata = "";
	m_status = SendUCMM_RR_Packet(m_inputEPath, ServiceCode, tempdata, Offset, Packet);
	if (m_status == OnLine)
	{
		Lenght = Packet.length();
		m_inputDataSize = Lenght - Offset;
		m_inputPocketSize = m_inputDataSize + 20;
		//cout<<"Lenght: "<<Lenght<<" Offset: "<<Offset<<" m_inputDataSize: "<<m_inputDataSize<<" m_inputPocketSize: "<<m_inputPocketSize<<endl;
		m_inputBuffer = new char[m_inputPocketSize];
		memset(m_inputBuffer,0,m_inputPocketSize);//recive
	}
	else
	{
		return false;
	}
	
	Offset = 0;
	Lenght = 0;
	Packet = "";
	tempdata = "";
	m_status = SendUCMM_RR_Packet(m_outputEPath, ServiceCode, tempdata, Offset, Packet);
	if (m_status == OnLine)
	{
		Lenght = Packet.length();
		m_outputDataSize = Lenght - Offset;
		m_outputPocketSize = m_outputDataSize + 24;
		//cout<<"Lenght: "<<Lenght<<" Offset: "<<Offset<<" m_outputDataSize: "<<m_outputDataSize<<" m_outputPocketSize: "<<m_outputPocketSize<<endl;
		m_outputBuffer = new char[m_outputPocketSize];
		memset(m_outputBuffer,0,m_outputPocketSize);//send
	}
	else
	{
		return false;
	}
	return true;
}

//UCMM SendRRData
EnIPNetworkStatus EnIPRemoteDevice::SendUCMM_RR_Packet(string &DataPath, CIPServiceCodes Service, string &data, int &Offset, string &Packet)
{
    try
    {
		if ((m_SessionHandle == 0) || (DataPath == "") || ((DataPath.length() % 2) != 0))
			return OffLine;
        UCMM_RR_Packet m = UCMM_RR_Packet(Service, true, DataPath, data);
		string str_ucmmpacket = m.toByteArray();
		if(str_ucmmpacket == "")
			return OffLine;
		EncapsulationCommands ss = SendRRDataCommand;
        Encapsulation_Packet sendPoceket = Encapsulation_Packet(ss, m_SessionHandle, str_ucmmpacket);
        string senddata = sendPoceket.toByteArray();
		int sendLength = senddata.length();
		//cout<<"sendLength: "<<sendLength<<endl;
		const char* sendBuffer = senddata.data();
        char recvBuffer[65535] = {0};
        Offset = 0;
		/*for(int i = 0; i < sendLength; i++)
		{
			cout<<"i: "<<i<<" sendBuffer: "<<(int)sendBuffer[i]<<endl;
		}*/		
		int Lenght = m_Tcpclient->SendReceive(sendBuffer, sendLength, recvBuffer);
		/*for(int i = 0; i < Lenght; i++)
		{
			cout<<"i: "<<i<<" recvBuffer: "<<(int)recvBuffer[i]<<endl;
		}*/
		//cout<<"Lenght: "<<Lenght<<endl;
        string ErrorMsg="TCP read data less";
        if (Lenght > 24)
        {
			Packet.assign(recvBuffer, Lenght);
			bool result = sendPoceket.analysisEncapsulationPacket(Packet, Offset, Lenght);
            if (result && (sendPoceket.m_Command == SendRRDataCommand))
            {
                result = m.analysisUCMMRRPacket(Packet, Offset, Lenght);
                if (result && (m.IsService(Service)))
                {
                    // all is OK, and Offset is ready set at the beginning of data[]
                    return OnLine;
                }
                else
                    ErrorMsg = Converter::convertToString(m.m_GeneralStatus);
            }
            else
			{
                ErrorMsg = Converter::convertToString(sendPoceket.m_Status);
			}
        }
		
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "EnIPRemoteDevice::SendUCMM_RR_Packet failed, Service is " + Converter::convertToString(Service) + " , ErrorMsg is " + ErrorMsg);	

        if (ErrorMsg == "TCP read data less")
            return OffLine;

        if (Service == SetAttributeSingle)
            return OnLineWriteRejected;
        else 
            return OnLineReadRejected;
    }
    catch(const exception &ex)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "EnIPRemoteDevice::SendUCMM_RR_Packet failed, Service is " + Converter::convertToString(Service) + " , ex is " + string(ex.what()));
        return OffLine;
    }
}

void EnIPRemoteDevice::run()
{
	while(m_running)
	{
		try
		{
			m_runningstatus = true;
			m_result = do_WriteClass1Data();
			usleep(m_cycleTime);
			
			if(!m_result)
			{
				throw IOException("EIP sending or reading Byte failed, m_server is " + m_serverIP);
			}
		}
		catch(const exception &ex)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "EnIPRemoteDevice::run() got exception: " + string(ex.what()));
		}
		catch(...)
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "EnIPRemoteDevice::run() got exception.");
		}
	}
	m_runningstatus = false;
	exit();	
}

//UDP/IP write class1 data
bool EnIPRemoteDevice::do_WriteClass1Data()
{
	IMutexLocker locker(&m_writelock);
	// update m_outputBuffer value
	SequencedAddressItem_Packet::updateSequenceNumber(m_outputBuffer, m_SequenceNumber);
	int len = m_Udpclient->sendData(m_outputBuffer, m_outputPocketSize);
	if(len == m_outputPocketSize)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool EnIPRemoteDevice::setBytesOutputsData(int offset, int len, void *value, bool flag)
{
	IMutexLocker locker(&m_writelock);
	offset = offset + 24;
	if(flag)//true: len --- byte
	{
		if((len == 1) || (len == 2) || (len == 4) || (len == 8))
		{
			if((offset + len) > m_outputPocketSize)
				return false;
			else
			{
				memcpy(m_outputBuffer + offset, (uint8_t *)value, len);
			}
		}
		else
			return false;
	}
	else//false: len --- bit
	{
		if(offset >= m_outputPocketSize)
			return false;
		unsigned char bitmask = 1;
		bitmask = bitmask << len;
		char temp = m_outputBuffer[offset];
		if(*((uint8_t *)value) == 1)
		{
			m_outputBuffer[offset] = temp | bitmask; 
		}
		else if(*((uint8_t *)value) == 0)
		{
			m_outputBuffer[offset] = temp & (~bitmask); 
		}
		else
			return false;
	}
	
	return true;
}

//UDP/IP read class1 data
bool EnIPRemoteDevice::do_ReadClass1Data(char *data, int len)
{
	IMutexLocker locker(&m_readlock);
	if(len == m_inputPocketSize)
	{
		int Offset = 0;
		unsigned int m_ConnectionId = 0;
		bool result = SequencedAddressItem_Packet::analysisGetItem(data, len, Offset, m_ConnectionId);
		if(result && (m_inputConnectionId == m_ConnectionId))
		{
			//data
			if((len - Offset) == m_inputDataSize)//Offset = 20;
			{
				memcpy(m_inputBuffer, data, len);
				return true;
			}
			else
			{
				SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "EnIPRemoteDevice::do_ReadClass1Data return false 1.");
				return false;
			}
		}
		else
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "EnIPRemoteDevice::do_ReadClass1Data return false 2.");
			return false;
		}
	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "EnIPRemoteDevice::do_ReadClass1Data return false 3.");
		return false;
	}
}

bool EnIPRemoteDevice::getBytesInputsData(int offset, int len, void *value)
{
	IMutexLocker locker(&m_readlock);
	offset = offset + 20;
	if((len == 1) || (len == 2) || (len == 4) || (len == 8))
	{
		if((offset + len) > m_inputPocketSize)
			return false;
		else
		{
			memcpy((uint8_t *)value, m_inputBuffer + offset, len);
		}
	}
	else
		return false;
	return true;
}

//get EPATH:  config --- T20 (Consumption)--- O2T()Production
string EnIPRemoteDevice::GetForwardOpenPath()
{
    string fullPath = "";
	fullPath += EnIPPath::GetPath(&m_classID, m_configInstanceID, NULL, false);
	fullPath += EnIPPath::GetPath(NULL, m_outputInstanceID, NULL, true);
	fullPath += EnIPPath::GetPath(NULL, m_inputInstanceID, NULL, true);
    return fullPath;
}

//TCP/IP UCMM Forward open
bool EnIPRemoteDevice::do_ForwardOpen(unsigned int cycleTime)
{
	m_cycleTime = cycleTime;
	m_config = new ForwardOpen_Config(m_inputDataSize, m_outputDataSize, true, m_cycleTime);
	string DataPath = GetForwardOpenPath();
	m_openPkt = new ForwardOpen_Packet(DataPath, m_config);
    int Offset = 0;
    string packet = "";

	uint16_t Cid = 6, Iid = 1;
	uint16_t *mCid = &Cid;
	CIPServiceCodes ss;
    if (true == m_openPkt->m_IsLargeForwardOpen)
	{
		//cout<<"LargeForwardOpenService"<<endl;
		ss = LargeForwardOpenService;
	}
    else
		ss = ForwardOpenService;
	string path = EnIPPath::GetPath(mCid, Iid, NULL);
	string data = m_openPkt->toByteArray();
	EnIPNetworkStatus Status = SendUCMM_RR_Packet(path, ss, data, Offset, packet);
	const char* pp = packet.data();
    if (Status == OnLine)
    {
		EnIPUDPServerTransport::getInstance()->startRecvData();
		
		memcpy(&m_outputConnectionId, pp + Offset, 4);
        //m_outputConnectionId = (unsigned char)(pp[Offset]) + (unsigned int)(pp[Offset + 1]<<8) + (unsigned int)(pp[Offset + 2]<<16) + (unsigned int)(pp[Offset + 3]<<24);
		SequencedAddressItem_Packet::fillSendItemPacketHead(m_outputBuffer, m_outputDataSize, m_outputConnectionId, m_SequenceNumber); // ready to send
		
		Offset = Offset + 4;
		memcpy(&m_inputConnectionId, pp + Offset, 4);
        //m_inputConnectionId = (unsigned char)(pp[Offset]) + (unsigned int)(pp[Offset + 1]<<8) + (unsigned int)(pp[Offset + 2]<<16) + (unsigned int)(pp[Offset + 3]<<24);

        m_closePkt = new ForwardClose_Packet(m_openPkt);
    }
	
	delete m_config;
	m_config = NULL;
	
    if (Status == OnLine)
    {
		m_running = true;
		start();//start run:
		return true;
	}
	else 
	{
		return false;
	}
}

//TCP/IP UCMM Forward close
bool EnIPRemoteDevice::do_ForwardClose()
{
	m_running = false;
	while(m_runningstatus)
	{
		usleep(10);
    }
	int Offset = 0;
    string packet;
	uint16_t Cid = 6, Iid = 1;
	uint16_t *mCid = &Cid;
	CIPServiceCodes ss = ForwardCloseService;
	string path = EnIPPath::GetPath(mCid, Iid, NULL);
	string data = m_closePkt->toByteArray();
	EnIPNetworkStatus Status = SendUCMM_RR_Packet(path, ss, data, Offset, packet);
	
	delete m_closePkt;
	m_closePkt = NULL;
	
	delete m_openPkt;
	m_openPkt = NULL;
	
	if (Status == OnLine)
    {
		return true;
	}
	else 
	{
		return false;
	}
}
