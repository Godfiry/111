/********************************************************************
** Copyright (c) 2019 ~ 2029, Beijing NAURA Co.,Ltd. All rights reserved.
** File name: StatusInfo.h
** Description:  
** Release: 1.0
** Modification history:           
** 					2019-04-16   Duq create
** 
*********************************************************************/

#ifndef STATUSINFO_H_
#define STATUSINFO_H_

#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class StatusInfo : public IntValueInfo
{
	public:
		//UnInit:-1,Unknown,Start,Stop
		static const int UnInit = -1;
		static const int Unknown = 0;
		static const int Start = 1;
		static const int Stop = 2;
		
		static const IntTypeInfo typeInfo;

	    StatusInfo():IntValueInfo(-1, typeInfo)
	    {
	    }
	
	    StatusInfo(int i):IntValueInfo(i, typeInfo)
	    {
	    }
	
	    StatusInfo(std::string s):IntValueInfo(s, typeInfo)
	    {
	    }
};

#endif  /*STATUSINFO_H_*/
