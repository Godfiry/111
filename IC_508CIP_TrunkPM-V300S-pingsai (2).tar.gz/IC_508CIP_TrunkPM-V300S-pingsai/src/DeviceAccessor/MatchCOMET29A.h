/*
 * MatchCOMET29A.h
 *
 *  Created on: 2021-4-27
 *      Author: lvjiawen
 */

#ifndef SRC_DEVICEACCESSOR_MATCHCOMET29A_H_
#define SRC_DEVICEACCESSOR_MATCHCOMET29A_H_

#include "COMETMatchDriver.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#include "DescriptorList.h"
#include "StringTypeInfo.h"
#include "CBase.h"
#include <map>
#ifdef IAP4_0
using namespace IAP::IO;
#endif




class MatchCOMET29A :public COMETMatchDriver, public CBase
{
	DECLARE_DYNAMIC(MatchCOMET29A)
	DECLARE_MSG_MAP

public:
	static std::string m_commands[];

public://construct &destruct
	MatchCOMET29A();
	virtual ~MatchCOMET29A();

public://interface
	bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
	bool readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);
	bool readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);
	bool readString(int nChannelNum, std::string *pValue, const StringTypeInfo &typeInfo);

	bool writeRawCommand(int nChannelNum, std::string strValue, const StringTypeInfo &typeInfo);

public://xml config
	void init();

private:
	void initChs(DeviceNode<MatchCOMET29A> *node);
	void initDevice();
};

#endif /* SRC_DEVICEACCESSOR_COMET29A_H_ */
