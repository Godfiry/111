/********************************************************************
** Copyright (c) 2021, Beijing NAURA Co.,Ltd.  All rights reserved.
** File name: PLCRecipeAssistant.h
** Description:
*
*
** Release: 1.1
** Modification history:
** 					2021-6-12   mujy create
**
*********************************************************************/
//#ifndef PLCRECIPEASSISTANT_H_
//#define PLCRECIPEASSISTANT_H_
//
//#include <map>
//#include <string>
//#include "CmdTarget.h"
//#include "ReadWriteDouble.h"
//
//class PLCRecipeAssistant :public CmdTarget
//{
//	DECLARE_DYNAMIC(PLCRecipeAssistant)
//	DECLARE_MSG_MAP	
//
//public:
//	PLCRecipeAssistant();
//	virtual ~PLCRecipeAssistant();
//
//public://for upper
//	void setRcpItemValue(std::string strParamName,int nStepIndex,double dValue);
//	void setRcpItemValue(std::string strParamName,int nStepIndex,int nValue);
//
//	//void setChildRecipeTotalNum(int nNum);
//	//void setEveryChildRecipeTotalCycleNum(std::vector<int> data);
//	//void setChildRecipeTotalStepNum(std::vector<int> data);
//
//	void setEveryChildRecipeTotalCycleNum(int nCycleNum);
//	void setChildRecipeTotalStepNum(int nStepNum);	
//
//	void clear();
//
//	bool isAddRecipeParamFromDriver();
//
//public://for PLCDriver
//	void addRecipeParam(std::string strParamName);
//	std::vector<double> getItemArray(std::string strParamName);
//	//int getChildRecipeTotalNum();
//	//std::vector<int> getEveryChildRecipeTotalCycleNum();
//	//std::vector<int> getChildRecipeTotalStepNum();
//
//	int getEveryChildRecipeTotalCycleNum();
//	int getChildRecipeTotalStepNum();
//private:
//	std::map<std::string,std::vector<double> > m_mapRecipeContent;
//	//int m_nTotalChildRecipeNum;
//	//std::vector<int> m_ChildRecipeTotalCycleNum;
//	//std::vector<int> m_ChildRecipeTotalStepNum;
//	int m_nChildRecipeTotalCycleNum;
//	int m_nChildRecipeTotalStepNum;
//};
//#endif /*PLCRECIPEASSISTANT_H_*/
