/*
 * KylandShm.cpp
 *
 *  Created on: 2024年4月9日
 *      Author: zhangcx
 */

#include "KylandShm.h"
#include "ConfigException.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "IOException.h"
#endif
#ifdef KYLAND //added by zhangyy [1.6.3]
#include "SHMInitInstance.h"
#endif
#include "DeviceManager.h"
#include "SysLogger.h"

#include "Hex.h"
#include "Converter.h"
#include <iostream>
#include <unistd.h>
#include <string.h>
#include "shmlib.h"

//KylandShmBaseNode* KylandShm :: m_KylandShmBaseNode= NULL;

KylandShm::KylandShm()
{
	m_nShmWdataLength = 0;
	m_nShmRdataLength = 0;

	m_nNodeNum = 0;
	m_nPollInterval = 200;
	m_nTimeOut = -1; 
}

KylandShm::~KylandShm()
{
	/*if(m_KylandShmBaseNode != NULL)
	{
		delete m_KylandShmBaseNode;
		m_KylandShmBaseNode = NULL;
	}*/

}

void KylandShm::loadDevice()
{
#ifdef KYLAND //added by zhangyy [1.6.3]
	if(!SHMInitInstance::getInstance().InitSHM())
	{
		printf("Init fail, reason : %s", GetErrorStr());
		//sleep(1);
	}
#else
	// do nothing
#endif
}

void KylandShm::init()
{
	string  strWdatapath;
	string  strRdatapath;
	strWdatapath = "/home/nmc/PMCI/structdata/ShmWdata.txt";

	strRdatapath = "/home/nmc/PMCI/structdata/ShmRdata.txt";
	m_nShmWdataLength = getLength(strWdatapath);

	m_nShmRdataLength = getLength(strRdatapath);

	generateStruct(strWdatapath,ShmWriteData);
	generateStruct(strRdatapath,ShmReadData);

	DeviceNode<KylandShm> * node = new DeviceNode<KylandShm>(m_nPollInterval,this);
	DeviceManager::getInstance()->registerNode(m_nNodeNum, node);

	makeWriteShmData();
	//initDeviceNet();
	
	/*if(m_KylandShmBaseNode == NULL)
	{
		m_KylandShmBaseNode = new KylandShmBaseNode();
	}*/

	if(!isSimulated())
	{

		initChs(node);

		loadDevice();
	}
}

int KylandShm::getLength(string strPath)
{
	ifstream input(strPath.c_str());

	int nLength = 0;
	string tmp;

	input.seekg(0,std::ios::beg);

	while(getline(input,tmp,'\n'))
	{
		nLength++;
	}

	input.close();
	return nLength;
}

void KylandShm::generateStruct(string strPath ,DataStruct *Data)
{
	ifstream input(strPath.c_str());

	int nLength = getLength(strPath);

	for (int i = 0; i < nLength; i++ )
	{
		input >> Data[i].m_nChannelNum;
		cout << Data[i].m_nChannelNum << " ";

		input >> Data[i].m_strDataType;
		cout << Data[i].m_strDataType << " ";

		input >> Data[i].m_strDataName;
		cout << Data[i].m_strDataName << " ";

		cout << endl;
	}
	input.close();
}

void KylandShm::initChs(DeviceNode< KylandShm> *node)
{
	for(int i = 0; i <m_nShmWdataLength; i++)
	{

		if (ShmWriteData[i].m_strDataType == "BOOL" || ShmWriteData[i].m_strDataType == "USINT" || ShmWriteData[i].m_strDataType == "UINT" || ShmWriteData[i].m_strDataType == "UDINT"|| ShmWriteData[i].m_strDataType == "INT"|| ShmWriteData[i].m_strDataType == "DINT" || ShmWriteData[i].m_strDataType == "SINT")
		{

			node->registerWriteCh(ShmWriteData[i].m_nChannelNum, & KylandShm::writeInt);
		}

		if (ShmWriteData[i].m_strDataType == "REAL" || ShmWriteData[i].m_strDataType == "SREAL")
		{
			node->registerWriteCh(ShmWriteData[i].m_nChannelNum, & KylandShm::writeDouble);
		}

	}

	for(int i = 0; i <m_nShmRdataLength; i++)
	{
		if (ShmReadData[i].m_strDataType == "BOOL" || ShmReadData[i].m_strDataType == "USINT" || ShmReadData[i].m_strDataType == "UINT" || ShmReadData[i].m_strDataType == "UDINT" || ShmReadData[i].m_strDataType == "INT"|| ShmReadData[i].m_strDataType == "DINT" || ShmReadData[i].m_strDataType == "SINT")
		{

			node->registerReadCh(ShmReadData[i].m_nChannelNum, & KylandShm::readInt);
		}

		if (ShmReadData[i].m_strDataType == "REAL"|| ShmReadData[i].m_strDataType == "SREAL")
		{
			node->registerReadCh(ShmReadData[i].m_nChannelNum, & KylandShm::readDouble);
		}
	}
}

bool KylandShm::writeShm(char *pBlockName, unsigned int pBlockSize, void * pData)
{
#ifdef KYLAND //added by zhangyy [1.6.3]
	IMutexLocker locker(&m_lock);
	if(KY_SHM_OK != WriteFromMemory(pBlockName, pBlockSize, pData))
	{
		cout<<WriteFromMemory(pBlockName, pBlockSize, pData)<<endl;
		cout<<GetErrorStr()<<endl;
		printf("WriteFromMemory fail\n");
		CloseSHM();
		return KY_SHM_ERROR;
	}
	usleep(2000);
	if(KY_SHM_OK != SetDataToMemory())
	{
		cout<<SetDataToMemory()<<endl;
		cout<<GetErrorStr()<<endl;
		printf("SetDataToMemory fail\n");
		//CloseSHM();
		return KY_SHM_ERROR;
	}
	usleep(2000);
#endif
	return true;
	
}

bool KylandShm::readShm(char * pBlockName, unsigned int pBlockSize, void * pData)
{
#ifdef KYLAND //added by zhangyy [1.6.3]
	IMutexLocker locker(&m_lock);

	if(KY_SHM_OK != GetDataFromMemory())
	{
		printf("GetDataFromMemory fail, reason : %s", GetErrorStr());
		//CloseSHM();
		//return KY_SHM_ERROR;
	}

	//printf("=======get data=======\n");

	ReadFromMemory(pBlockName, pBlockSize, pData);
#endif
	return true;
}

bool KylandShm::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
#ifdef KYLAND //added by zhangyy [1.6.3]
	if(nChannelNum >= ShmWriteData[0].m_nChannelNum && nChannelNum <= ShmWriteData[m_nShmWdataLength-1].m_nChannelNum)
	{
		int nIndex = findStruct(ShmWriteData,m_nShmWdataLength,nChannelNum);
		int nNum = 0;
		if(nChannelNum == 15080 || nChannelNum == 15081 || nChannelNum == 15088)
		{
			cout<<"xxxxxxxxxxxxxx"<<nChannelNum<<endl;
		}
		if(nChannelNum >15000)
		{
			nNum = ShmWriteData[nIndex].m_nChannelNum - 15001;
			(SHM_WOUT.address[nNum].wr_cnt)++;
		}	
		else
		{
			nNum = ShmWriteData[nIndex].m_nChannelNum - 5001;
		}		
		if(ShmWriteData[nIndex].m_strDataType == "BOOL")
		{
			SHM_WOUT.address[nNum].value_bool = nValue;
		}
		else if(ShmWriteData[nIndex].m_strDataType == "DINT")
		{
			SHM_WOUT.address[nNum].value_dint = nValue;
		}
		
		writeShm("SHM_WOUT", sizeof(SHM_WOUT), &SHM_WOUT);
	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + " in writeInt function, nChannelNum = " + Converter::convertToString(nChannelNum) + ", is wrong! ");	
	}
#endif
	return true;
}

bool KylandShm::writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
#ifdef KYLAND //added by zhangyy [1.6.3]
	if(nChannelNum >= ShmWriteData[0].m_nChannelNum && nChannelNum <= ShmWriteData[m_nShmWdataLength-1].m_nChannelNum)
	{
		int nIndex = findStruct(ShmWriteData,m_nShmWdataLength,nChannelNum);
		int nNum = 0;
		if(nChannelNum >15000)
		{
			nNum = ShmWriteData[nIndex].m_nChannelNum - 15001;
			(SHM_WOUT.address[nNum].wr_cnt)++;
		}	
		else
		{
			nNum = ShmWriteData[nIndex].m_nChannelNum - 5001;
		}
		SHM_WOUT.address[nNum].value_real = dValue;
		usleep(2000);
		writeShm("SHM_WOUT", sizeof(SHM_WOUT), &SHM_WOUT);
	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + " in writeDouble function, nChannelNum = " + Converter::convertToString(nChannelNum) + ", is wrong! ");
	}
#endif
	return true;
}

bool KylandShm::readInt(int nChannelNum, int *nValue, const IntTypeInfo &typeInfo)
{
#ifdef KYLAND //added by zhangyy [1.6.3]
	if(nChannelNum >= ShmReadData[0].m_nChannelNum && nChannelNum <= ShmReadData[m_nShmRdataLength-1].m_nChannelNum)
	{
		readShm("SHM_RIN", sizeof(SHM_RIN), &SHM_RIN);
		int nIndex = findStruct(ShmReadData,m_nShmRdataLength,nChannelNum);
		int nNum = ShmReadData[nIndex].m_nChannelNum-1;

		if(ShmReadData[nIndex].m_strDataType == "BOOL")
		{
			*nValue = SHM_RIN.address[nNum].value_bool;
		}
		else if(ShmReadData[nIndex].m_strDataType == "DINT")
		{
			*nValue = SHM_RIN.address[nNum].value_dint;
		}

		//*nValue = SHM_RIN.address[nIndex].value_dint;
	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + " in readInt function, nChannelNum = " + Converter::convertToString(nChannelNum) + ", is wrong! ");
	}
#endif
	return true;
}

bool KylandShm::readDouble(int nChannelNum, double *dValue, const DoubleTypeInfo &typeInfo)
{
#ifdef KYLAND //added by zhangyy [1.6.3]
	if(nChannelNum >= ShmReadData[0].m_nChannelNum && nChannelNum <= ShmReadData[m_nShmRdataLength-1].m_nChannelNum)
	{

		readShm("SHM_RIN", sizeof(SHM_RIN), &SHM_RIN);
		int nIndex = findStruct(ShmReadData,m_nShmRdataLength,nChannelNum);
		int nNum = ShmReadData[nIndex].m_nChannelNum-1;

		/*cout << nChannelNum <<"*************"<< endl;
		cout << nIndex << endl;
		cout << ShmReadData[nIndex].m_strDataName << endl;
		cout << ShmReadData[nIndex].m_nChannelNum << endl;
		cout << SHM_RIN.address[nIndex].value_real << endl;*/
		/*for(int i = 0; i < 300; i++ )
		{
			if(205 == SHM_RIN.address[i].value_real)
			{
					cout << i <<"********999**"<< endl;
			}
		}*/

		*dValue = SHM_RIN.address[nNum].value_real;
	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + " in readDouble function, nChannelNum = " + Converter::convertToString(nChannelNum) + ", is wrong! ");
	}
#endif
	return true;
}

int KylandShm::findStruct(DataStruct Data[], int nLength, int nChannelNum)
{
	for (int i = 0 ;i < nLength; i++)
	{
		if (Data[i].m_nChannelNum == nChannelNum)
		{
			return i;
		}
	}
	return -1;
}

void KylandShm::makeWriteShmData()
{
	for(int i = 0; i < m_nShmWdataLength; i++)
	{
		SHM_WOUT.address[i].wr_cnt = 0;
		//SHM_WOUT.address[i].m_strDataName = ShmWriteData[i].m_strDataName;
		if("BOOL" == ShmWriteData[i].m_strDataType)
		{
			SHM_WOUT.address[i].type = 1;
		}
		else if("DINT" == ShmWriteData[i].m_strDataType)
		{
			SHM_WOUT.address[i].type = 2;
		}
		else if("REAL" == ShmWriteData[i].m_strDataType)
		{
			SHM_WOUT.address[i].type = 3;		
		}
		else
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + " the type of " + ShmWriteData[i].m_strDataName + " is wrong, the type now is " + ShmWriteData[i].m_strDataType);
		}
		//SHM_WOUT.address[i].type = ShmWriteData[i].m_strDataType;
		SHM_WOUT.address[i].value_bool = false;
		SHM_WOUT.address[i].value_dint = 0;
		SHM_WOUT.address[i].value_real = 0.0;
	}


	/*int nflag = 0;
	for(int i = 0; i < m_nShmWdataLength; i++)
	{
		nflag = ShmWriteData[i].m_nChannelNum;
		if("BOOL" == ShmWriteData[i].m_strDataType)
		{		
			SHM_WOUT.address[nflag].type = 1;
		}
		else if("INT" == ShmWriteData[i].m_strDataType)
		{
			SHM_WOUT.address[nflag].type = 2;
		}
		else if("DOUBLE" == ShmWriteData[i].m_strDataType)
		{
			SHM_WOUT.address[nflag].type = 3;		
		}
		else
		{
			SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + " the type of " + ShmWriteData[i].m_strDataName + " is wrong, the type now is " + ShmWriteData[i].m_strDataType);
		}
		
		SHM_WOUT.address[nflag].value_bool = false;
		SHM_WOUT.address[nflag].value_dint = 0;
		SHM_WOUT.address[nflag].value_real = 0.0;
	}*/


}

void KylandShm::setNodeNum(int nNodeNum)
{
	if(nNodeNum < 0)
	{
		throw ConfigException("IODevice: illegal nNodeNum");
	}
	m_nNodeNum = nNodeNum;
}

void KylandShm::setTimeOut(int nTime)
{
	m_nTimeOut = nTime;
}

void KylandShm::setPollIntervalMS(int nInterval)
{
	m_nPollInterval = nInterval;
}

IMPLEMENT_DYNAMIC(KylandShm, AbstractDevice )
BEGIN_MSG_MAP( KylandShm, AbstractDevice )
	SET_I( setTimeOut, KylandShm )
	SET_I( setNodeNum, KylandShm )
	SET_I( setPollIntervalMS, KylandShm )
	SET_V( init, KylandShm )
END_MSG_MAP
