/********************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: FailedToReachSetpoint.h
** Description:  
** Release: 1.0
** Modification history: 
** 					2008-03-17   LiJuanjuan create
**      
*********************************************************************/
#ifndef FAILEDTOREACHSETPOINT_H_
#define FAILEDTOREACHSETPOINT_H_

#include "TMCException.h"

class FailedToReachSetpoint:public TMCException
{
	public:
		FailedToReachSetpoint(const std::string &s);
};

#endif /*FAILEDTOREACHSETPOINT_H_*/
