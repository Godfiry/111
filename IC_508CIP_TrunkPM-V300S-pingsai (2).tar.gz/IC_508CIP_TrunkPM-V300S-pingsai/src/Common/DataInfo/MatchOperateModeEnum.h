#ifndef MATCHOPERATEMODEENUM_H_
#define MATCHOPERATEMODEENUM_H_

namespace MATCH_OPERATEMODE
{
	enum MatchOperateModeEnum
	{
		Manual,
		Auto
	};
}

#endif /*MATCHOPERATEMODEENUM_H_*/
