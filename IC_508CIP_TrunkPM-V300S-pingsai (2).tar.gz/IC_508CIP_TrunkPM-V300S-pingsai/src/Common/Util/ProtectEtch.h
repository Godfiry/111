/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: ProtectEtch.h
** Description:  
** Release: 1.1
** Modification history: 
**						2019-6-17		mujy		Created
**      
*********************************************************************/

#ifndef PROTECTETCH_H_
#define PROTECTETCH_H_


#include "CmdTarget.h"
#include "ReadWriteInt.h"
#include "ReadOnlyDouble.h"
#include <string.h>
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
#endif

using namespace std;

class ProtectEtch :public CmdTarget
{
	DECLARE_DYNAMIC( ProtectEtch )
	DECLARE_MSG_MAP
	
public://construction
	ProtectEtch();
	virtual ~ProtectEtch();
	
public://xml config	
	void addRFOnOffWCh(const string strParamName, const string &strPath);
	void addOffWCh(const string strParamName, const string &strPath);//added by liusy [1.1.26]
	void addOnWCh(const string strParamName, const string &strPath);//added by liusy [1.1.26]
	void addRFForwardPowerSensorCh(const string strParamName, const string &strPath);
	
protected://override
	virtual void initialize();
	
private:
	map<string,ReadWriteInt*> m_IntWriteChs;
	map<string,ReadWriteInt*> m_IntOnWriteChs;

	map<string,ReadOnlyDouble*> m_DoubleSensorChs;
};

#endif /*PROTECTETCH_H_*/
