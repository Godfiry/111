/*
 * LinerRobot.h
 *
 *  Created on: 20210712
 *      Author: lvjiawen
 *
 *  modify:	2021-12-07 lvJiawen
 *  modify:	2024-7-8 liusy
 */

#ifndef SRC_LINERROBOT_H_
#define SRC_LINERROBOT_H_


#include "LinerRobotPosition.h"

#include "TimeScale.h"
#include <vector>
#include "IOInterlocks.h"
#include "TimerEx.h"
#include "NonBlockingAlarmEX.h"
#include "Pin.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP::CORE;
#endif

class LinerRobot :public Pin, public ITimeTicker
{
	DECLARE_DYNAMIC( LinerRobot )
	DECLARE_MSG_MAP
	DECLARE_SERVICEINFO_LIST

private:
	LinerRobot(const LinerRobot& pObj); //modified by chenw [1.6.0_RC02]

	LinerRobot& operator=(const LinerRobot& pObj);

public:
	LinerRobot();

	virtual ~LinerRobot();

public://service
	virtual void do_Up();
	virtual void do_Down();
	virtual void do_GoTo(string strPosName);
	virtual void do_GoNotWait(string strPosName);

public://xml config
	void setPosition(string strPosName);

	void setDO(int nDOID,string strPath);
	void setDI(int nDIID,string strPath);

	void setPositionDO(string strPosName,string strDoList);
	void setPositionDI(string strPosName,string strDIList);

	void setInterlock(string strPosName,string strPath);

	void useStatusMonitor(bool bUseStatusMonitor);

	void setPositionExportPath(string strPath);
	void setStatusExportPath(string strPath);
	void setTimeOut(int nTimeOutSecond);

public://get status
	virtual string getCurrentPosition();
	virtual bool isAt(string strPosName);
	virtual bool isMoving();

public://action
	virtual void go(string strPosName);
	virtual void goAndWait(string strPosName);
	virtual bool waitArrive();

	virtual void goCurrentPosition();//go sensor position(if not unknown)

public://override
	virtual void make();
	virtual void initialize();
	virtual void verifyInit();
	virtual void startup();

	virtual void update(UntypedData *pData, const ValueInfo &value);
	virtual void updateFromTimer(TimerEx * pSender);

protected://event
	virtual void onMoving(string strPosName);//By actuator
	virtual void onStatusChange(string strPosName);//By Sensor

	virtual void onArriveDestination();
	virtual void onGoFailed(string strPosName,string strFailReason);

protected://Error interface
	virtual void onUnexpectedMove(string strPosName);//in update thread. throw exception is forbiden!!!!

	virtual void onGoAndWaitTimeOut(string strPosName);
	virtual void onGoTimeOut(string strPosName);//in update thread. throw exception is forbiden!!!!
	virtual void onPositionNotExist(string strErrPosName);
	virtual void onOtherActionNotFinish(bool bWait,string strCurrentDestination);//  [lvjw 1.2.10]

	//virtual void onIOException(string strPosName);

protected://value
	virtual string getDestinationPos();
	virtual void setDestinationPos(string strPosName);

protected:
	virtual bool isSensorAt(string strPosName);//only check sensor,if no sensor return true
	bool isPositionExist(string strPosName);
	virtual string makeDescriptorListStr();

protected:
	int m_nTimeOutSec;
	bool m_bUseStatusMonitor;

	map<int, ReadWriteInt*> m_DO;
	map<int, ReadOnlyInt*> m_DI;

	map<string, vector<int> > m_PositionDO;
	map<string, vector<int> > m_PositionDI;

	map<string, LinerRobotPosition*> m_Position;

	map<string, IOInterlocks *> m_Interlock;

	ReadWriteInt *m_pState;
	ReadWriteInt *m_pCurrentPosition;

	ReadWriteDouble *m_pMoveTime;//[zhangcx v1.1.27]

private:
	NonBlockingAlarmEX * m_pTimeOutAlarm;//only post when go no wait
	NonBlockingAlarmEX * m_pUnexpectedMoveAlarm;

	TimeScale * m_pTimeScale;

private:
	mutable IMutex *m_pDestinationPosMutex; //lock m_strDestinationPos
	string m_strDestinationPos;

	TimerEx * m_pTimerMoveMonitor;
	TimerEx * m_pTimerSimulateMove;

public:
	static const string UNKNOWN;

	int MOVING_TIME; //simulated move time
};

#endif /* SRC_LINERROBOT_H_ */
