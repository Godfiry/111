/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: F4TTempCtl.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2016-02-26   gaozl created
**                RS232  19200            
*********************************************************************/
#include "F4TTempCtl.h"
#include <string.h>
#include "DeviceManager.h"
#include "ObjectManager.h"
#include "Converter.h"

#include <sys/time.h>
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;

const unsigned char F4TTempCtl::auchCRCHi[256] = {
0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,0x01,0xc0,
0x80,0x41,0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,
0x00,0xc1,0x81,0x40,0x00,0xc1,0x81,0x40,0x01,0xc0,
0x80,0x41,0x01,0xc0,0x80,0x41,0x00,0xc1,0x81,0x40,
0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,0x00,0xc1,
0x81,0x40,0x01,0xc0,0x80,0x41,0x01,0xc0,0x80,0x41,
0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,0x00,0xc1,
0x81,0x40,0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,
0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,0x01,0xc0,
0x80,0x41,0x00,0xc1,0x81,0x40,0x00,0xc1,0x81,0x40,
0x01,0xc0,0x80,0x41,0x01,0xc0,0x80,0x41,0x00,0xc1,
0x81,0x40,0x01,0xc0,0x80,0x41,0x00,0xc1,0x81,0x40,
0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,0x01,0xc0,
0x80,0x41,0x00,0xc1,0x81,0x40,0x00,0xc1,0x81,0x40,
0x01,0xc0,0x80,0x41,0x00,0xc1,0x81,0x40,0x01,0xc0,
0x80,0x41,0x01,0xc0,0x80,0x41,0x00,0xc1,0x81,0x40,
0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,0x01,0xc0,
0x80,0x41,0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,
0x00,0xc1,0x81,0x40,0x00,0xc1,0x81,0x40,0x01,0xc0,
0x80,0x41,0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,
0x01,0xc0,0x80,0x41,0x00,0xc1,0x81,0x40,0x01,0xc0,
0x80,0x41,0x00,0xc1,0x81,0x40,0x00,0xc1,0x81,0x40,
0x01,0xc0,0x80,0x41,0x01,0xc0,0x80,0x41,0x00,0xc1,
0x81,0x40,0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,
0x00,0xc1,0x81,0x40,0x01,0xc0,0x80,0x41,0x01,0xc0,
0x80,0x41,0x00,0xc1,0x81,0x40
};

const unsigned char F4TTempCtl::auchCRCLo[256] = {
0x00,0xc0,0xc1,0x01,0xc3,0x03,0x02,0xc2,0xc6,0x06,
0x07,0xc7,0x05,0xc5,0xc4,0x04,0xcc,0x0c,0x0d,0xcd,
0x0f,0xcf,0xce,0x0e,0x0a,0xca,0xcb,0x0b,0xc9,0x09,
0x08,0xc8,0xd8,0x18,0x19,0xd9,0x1b,0xdb,0xda,0x1a,
0x1e,0xde,0xdf,0x1f,0xdd,0x1d,0x1c,0xdc,0x14,0xd4,
0xd5,0x15,0xd7,0x17,0x16,0xd6,0xd2,0x12,0x13,0xd3,
0x11,0xd1,0xd0,0x10,0xf0,0x30,0x31,0xf1,0x33,0xf3,
0xf2,0x32,0x36,0xf6,0xf7,0x37,0xf5,0x35,0x34,0xf4,
0x3c,0xfc,0xfd,0x3d,0xff,0x3f,0x3e,0xfe,0xfa,0x3a,
0x3b,0xfb,0x39,0xf9,0xf8,0x38,0x28,0xe8,0xe9,0x29,
0xeb,0x2b,0x2a,0xea,0xee,0x2e,0x2f,0xef,0x2d,0xed,
0xec,0x2c,0xe4,0x24,0x25,0xe5,0x27,0xe7,0xe6,0x26,
0x22,0xe2,0xe3,0x23,0xe1,0x21,0x20,0xe0,0xa0,0x60,
0x61,0xa1,0x63,0xa3,0xa2,0x62,0x66,0xa6,0xa7,0x67,
0xa5,0x65,0x64,0xa4,0x6c,0xac,0xad,0x6d,0xaf,0x6f,
0x6e,0xae,0xaa,0x6a,0x6b,0xab,0x69,0xa9,0xa8,0x68,
0x78,0xb8,0xb9,0x79,0xbb,0x7b,0x7a,0xba,0xbe,0x7e,
0x7f,0xbf,0x7d,0xbd,0xbc,0x7c,0xb4,0x74,0x75,0xb5,
0x77,0xb7,0xb6,0x76,0x72,0xb2,0xb3,0x73,0xb1,0x71,
0x70,0xb0,0x50,0x90,0x91,0x51,0x93,0x53,0x52,0x92,
0x96,0x56,0x57,0x97,0x55,0x95,0x94,0x54,0x9c,0x5c,
0x5d,0x9d,0x5f,0x9f,0x9e,0x5e,0x5a,0x9a,0x9b,0x5b,
0x99,0x59,0x58,0x98,0x88,0x48,0x49,0x89,0x4b,0x8b,
0x8a,0x4a,0x4e,0x8e,0x8f,0x4f,0x8d,0x4d,0x4c,0x8c,
0x44,0x84,0x85,0x45,0x87,0x47,0x46,0x86,0x82,0x42,
0x43,0x83,0x41,0x81,0x80,0x40
};

const unsigned char F4TTempCtl::regReadAddress[16] = {
/*0x6D,0x7A,0x6D,0xE8,0x6E,0x56,0x6E,0xC4    */
0x2D,0x5C,0x2D,0xA2,0x2D,0xE8,0x2E,0x2E,
0x0A,0xF4,0x0B,0x94,0x0C,0x34,0x0C,0xD4//use for read power
};
const unsigned char F4TTempCtl::regWriteAddress[24] = {
0x0A,0xDE,0x0B,0x7E,0x0C,0x1E,0x0C,0xBE,
0x0A,0xAA,0x0B,0x4A,0x0B,0xEA,0x0C,0x8A,//add by wz
0x0A,0xE0,0x0B,0x80,0x0C,0x20,0x0C,0xC0
};

F4TTempCtl::F4TTempCtl():SerialDevice(80, "")
{
	
	m_timeOut = 20;//2s
	//the form of the read command
	m_readCmd[0] = 0x01;//controller address
	m_readCmd[1] = 0x03;//function read
	m_readCmd[2] = 0x00;//read starting at register high byte
	m_readCmd[3] = 0x00;//read starting at register low byte
	m_readCmd[4] = 0x00;//read number of consecutive register (always 0)
	m_readCmd[5] = 0x02;//read number of consecutive register (always 2)
	m_readCmd[6] = 0x00;//Low byte of CRC
	m_readCmd[7] = 0x00;//High byte of CRC
	
	//the form of the write command
	m_writeCmd[0] = 0x01;//controller address
	m_writeCmd[1] = 0x10;//function multiple write
	m_writeCmd[2] = 0x00;//write starting at register High byte
	m_writeCmd[3] = 0x00;//write starting at register Low byte
	m_writeCmd[4] = 0x00;//read number of consecutive register--High byte(always 0)
	m_writeCmd[5] = 0x02;//read number of consecutive register--Low byte
	m_writeCmd[6] = 0x04;//number of byte to Write
	m_writeCmd[7] = 0x00;//data High byte of 1# register write
	m_writeCmd[8] = 0x00;//data Low byte of 1# register write
	m_writeCmd[9] = 0x00;//data High byte of 2# register write
	m_writeCmd[10] = 0x00;//data Low byte of 2# register write
	m_writeCmd[11] = 0x00;//Low byte of CRC
	m_writeCmd[12] = 0x00;//High byte of CRC
}

F4TTempCtl::~F4TTempCtl()
{
}

// Hex to decimal
float F4TTempCtl::Hex_To_Decimal(unsigned char *Byte,int num)
{
	if(num > 4)//zhangyy add[1.8.0]
	{
		throw IOException("The input num of function Hex_To_Decimal must be less than or equal to 4 in F4TTempCtl");
	}
   	char cByte[4];//save the 32-bite
    for (int i=0;i<num;i++)
      {
  		cByte[i] = Byte[i];
  		//cout<<"cByte="<<cByte[i]<<"  Byte=  "<<Byte[i]<<endl;
      }
      
  	float pfValue=*(float*)&cByte;
    return  pfValue;     //return a decimal such as 42960000=75.0
	
}
// Decimal to hex
void F4TTempCtl::FloatToByte(float floatNum,unsigned char* byteArry)
{
    char* pchar=(char*)&floatNum;
    for(int i=0;i<sizeof(float);i++) //4
    {
		*byteArry=*pchar;
		pchar++;
		byteArry++;
    }	
}

//calculate the CRC code
unsigned short F4TTempCtl::CRC16(char * puchMsg, unsigned short usDataLen )
{
	unsigned char newPuchMsg[100] = {0};//message to calculate CRC upon
	unsigned char uchCRCHi = 0xFF;      //the high bytes of CRC initialize
	unsigned char uchCRCLo = 0xFF;      //the low bytes of CRC initialize
	unsigned uIndex;                    //index of the CRC message 
	unsigned i = 0;
	
	memcpy(newPuchMsg, puchMsg, usDataLen);
	while (usDataLen--)
	{
		//uIndex = uchCRCHi^*puchMsg++;
		uIndex = uchCRCHi^newPuchMsg[i++];  //calculate the CRC
		uchCRCHi = uchCRCLo^auchCRCHi[uIndex];
		uchCRCLo = auchCRCLo[uIndex];
	}
	return (uchCRCHi << 8 | uchCRCLo);
}

// return the CRC code
unsigned short F4TTempCtl::GetCRCCode(char * cCommand, int nLen )
{	
	unsigned short crc = 0xffff;
	crc = CRC16(cCommand, nLen);
	//cout << "crc is :"<<crc<<endl;	
 	return crc;
	
}

//read data from the device 
bool F4TTempCtl::readDouble(int channelNum,double * value ,const DoubleTypeInfo& typeinfo)
{
	if (isSimulated())
	{
		struct timeval tm;
		struct timezone *tz = NULL;
		
		gettimeofday(&tm,tz);
		*value = typeinfo.getMax() * ((double)tm.tv_usec / 1000000);
		return true;
	}
	//get the channel address with read only 
	if(channelNum >=15 && channelNum <= 22)
	{
	   m_readCmd[2] = regReadAddress[(channelNum-15)*2];
	   m_readCmd[3] = regReadAddress[(channelNum-15)*2+1];
	}
	//<<hex<<(int)m_readCmd[1]<<m_readCmd[2]<<m_readCmd[3]<<m_readCmd[4]<<m_readCmd[5]<<m_readCmd[6]<<m_readCmd[7]<<endl;
	
	unsigned short crc = GetCRCCode( m_readCmd, 6 );
	m_readCmd[6] = crc >> 8;  // low byte of CRC
	m_readCmd[7] = crc & 0xff;    // high byte of CRC
	//cout<<"echo"<<m_readCmd[1]<<m_readCmd[2]<<m_readCmd[3]<<m_readCmd[4]<<m_readCmd[5]<<m_readCmd[6]<<m_readCmd[7]<<endl;
	char response[RESP_LEN];
	int i=0;
	/*
	while (m_dev.readStr(response,1,RESP_LEN) > 0) //read the F4T
	{
		i++;
		if(i > 100)
		 {
		 	throw IOException("there are more data receive from F4TTempCtl");
		 }
	}
	
	bzero(response, RESP_LEN);//reset the response
	
	//send the read data  8 bytes command
	if (m_dev.writeRaw(m_readCmd, 8) < 0)
    {
    	//cout << "writeRaw return error" << endl;
		throw IOException("F4T failed to send command");
    }
    // receive data from the reading; readStr() function;  response is the char buff
    // 5 is the timeout value; RESP_LEN is the maxread
	//if (m_dev.readStr(response,5,RESP_LEN) < 0)
	*/
	bzero(response, RESP_LEN);//reset the response
	sendCommandOnly(m_readCmd, 8);
	if(getResultOnly(response, RESP_LEN, m_timeOut) < 0)
	 {
		//cout << "readStr return error..."<< endl;
		throw IOException("F4T reading back times out");
	 }
	
	string res = string(response);
		
	if(response[0]==0x01&&response[1]==0x03)
	{
		if(response[2]==0x04)
		{
			unsigned char  cByte[4];//save the 32-bite
			int val;
			response[3] = response[3]&0x00ff;
			response[4] = response[4]&0x00ff;
			response[5] = response[5]&0x00ff;
			response[6] = response[6]&0x00ff;
			cByte[3] = response[5];
			cByte[2] = response[6];
			cByte[1] = response[3];
			cByte[0] = response[4];
  	       float pfValue=*(float*)&cByte;
       	*value = pfValue;
           setDoubleValue(channelNum + MONITORDOUBLEVALUEADDMAP, *value, typeinfo.getAccuracy());//added by zpf 20250618 for TempCtl Protect CIP
			return true;
		}
		else
		{
			cout<<hex<<"F4T the real data resp[2],[3] is: "<<response[2]<<" "<<response[3]<<endl;
			throw IOException("F4T reading data false...");
		}
	}
	else
	{
		//cout<< "F4T:the read data command is invalid"<<endl;
		string serr = "F4T reading data got Function and Exception code(in Dec): ";
		serr = serr + Converter::convertToString((int)response[1]&0xFF) + " " + Converter::convertToString((int)response[2]&0xFF);
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + serr);
		throw IOException(serr);
	}
}

//write data to the F4T
bool F4TTempCtl::writeDouble(int channelNum, double settemp, const DoubleTypeInfo& typeinfo)
{
	if (isSimulated())
	{
		return true;
	}
	//get the channel address with REWS
	if ((channelNum >= 1 && channelNum <= 4)||(channelNum >= 9 && channelNum <= 12))
	{
		m_writeCmd[2] = regWriteAddress[(channelNum-1)*2];
		m_writeCmd[3] = regWriteAddress[(channelNum-1)*2+1];
	}
	unsigned char floatToHex[4];	
	float changesettemp = (float)settemp;
	char* pchar=(char*)&changesettemp;
    for(int i=0;i<sizeof(float);i++) //4
    {
		floatToHex[i]=*pchar;
		pchar++;
		//floatToHex++;
		//cout<<hex<<(int)*pchar<< " ";
    }
	m_writeCmd[7] =floatToHex[1];//0x00
	m_writeCmd[8] =floatToHex[0];//0x00
	m_writeCmd[9] =floatToHex[3];//0x42
	m_writeCmd[10]=floatToHex[2];//0x96
	
	unsigned short crc = GetCRCCode( m_writeCmd, 11 );
	m_writeCmd[11] =0xff&( crc >> 8);  // low byte of CRCunsigned char ss = 0x96;
	m_writeCmd[12] = 0xff&(crc & 0xff);    // high byte of CRC
	//if the write command failed, return error
	/*
	if (m_dev.writeRaw(m_writeCmd, 13) < 0)
    {
    	//cout << "F4T writeRaw return error" << endl;
		throw IOException("F4T failed to send command");
    }
    char response[RESP_LEN];
	bzero(response, RESP_LEN);
    
    //receive from writing 
    if (m_dev.readStr(response,100,RESP_LEN) < 0)
	*/
    char response[RESP_LEN];
	bzero(response, RESP_LEN);//reset the response
	sendCommandOnly(m_writeCmd, 13);
	if(getResultOnly(response, RESP_LEN, m_timeOut) < 0)
	{
		throw IOException("F4T reading back times out");
	}

	//check the key bytes
	if(response[0]==0x01&&response[1]==0x10)
	{
		if(response[5]!= 0x02)
		{
			throw IOException("F4T write-back reg-count is not 0x02, abnormal!");
		}
		else
		{
			return true;	
		}
	}
	else
	{
		string serr = "F4T writing data got Function and Exception code(in Dec): ";
		serr = serr + Converter::convertToString((int)response[1]&0xFF) + " " + Converter::convertToString((int)response[2]&0xFF);
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + serr);
		throw IOException(serr);
	}
	
}



bool F4TTempCtl::writeInt(int channelNum, int settemp, const IntTypeInfo& typeinfo)
{
	if (isSimulated())
	{
		return true;
	}
	//get the channel address with REWS
	if (channelNum >= 5 && channelNum <= 8)
	{
		m_writeCmd[2] = regWriteAddress[(channelNum-1)*2];
		m_writeCmd[3] = regWriteAddress[(channelNum-1)*2+1];
	}
	if(settemp==0)
	{
		m_writeCmd[7] =0x00;
		m_writeCmd[8] =0x0A;
	}else
	{
		m_writeCmd[7] =0x00;
		m_writeCmd[8] = 0x36;
	}
	unsigned short crc = GetCRCCode( m_writeCmd, 11 );
	m_writeCmd[11] =0xff&( crc >> 8);  // low byte of CRCunsigned char ss = 0x96;
	m_writeCmd[12] = 0xff&(crc & 0xff);    // high byte of CRC
	//if the write command failed, return error
	/*
	if (m_dev.writeRaw(m_writeCmd, 13) < 0)
    {
    	//cout << "F4T writeRaw return error" << endl;
		throw IOException("F4T failed to send command");
    }
    char response[RESP_LEN];
	bzero(response, RESP_LEN);

    //receive from writing
    if (m_dev.readStr(response,100,RESP_LEN) < 0)
	*/
    char response[RESP_LEN];
	bzero(response, RESP_LEN);//reset the response
	sendCommandOnly(m_writeCmd, 13);
	if(getResultOnly(response, RESP_LEN, m_timeOut) < 0)
	{
		throw IOException("F4T reading back times out");
	}

	//check the key bytes
	if(response[0]==0x01&&response[1]==0x10)
	{
		if(response[5]!= 0x02)
		{
			throw IOException("F4T write-back reg-count is not 0x02, abnormal!");
		}
		else
		{
			return true;
		}
	}
	else
	{
		string serr = "F4T writing data got Function and Exception code(in Dec): ";
		serr = serr + Converter::convertToString((int)response[1]&0xFF) + " " + Converter::convertToString((int)response[2]&0xFF);
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getSelfName() + serr);
		throw IOException(serr);
	}

}


//register channel
void F4TTempCtl::initChs(DeviceNode<F4TTempCtl> *node)
{
	//node->registerReadCh(0, &SerialDevice::connectStatus);
	for(int i = 1; i <= 4; ++i)
	{
		node->registerWriteCh(i, &F4TTempCtl::writeDouble);
	}
	for(int i = 5; i <= 8; ++i)
	{
		node->registerWriteCh(i, &F4TTempCtl::writeInt);
	}
	for(int i = 9; i <= 12; ++i)
	{
		node->registerWriteCh(i, &F4TTempCtl::writeDouble);
	}
	for(int i = 15; i <= 22; ++i)
	{
		node->registerReadCh(i, &F4TTempCtl::readDouble);
        node->registerReadCh(i + MONITORDOUBLEVALUEADDMAP, &CMonitorDoubleValue::readDoubleChange);//added by zpf 20250618 for TempCtl Protect CIP
        initDoubleValue(i + MONITORDOUBLEVALUEADDMAP, -1);//added by zpf 20250618 for TempCtl Protect CIP
	}	
}
void F4TTempCtl::initDevice()
{
	//cout<<"F4TTempCtl::initDevice()"<<endl;
}
//init device		
void F4TTempCtl::init()
{
	DeviceNode<F4TTempCtl> *node = new DeviceNode<F4TTempCtl>(m_pollPeriod, this);
	initChs(node);		
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	initDevice();
}

IMPLEMENT_DYNAMIC(F4TTempCtl, SerialDevice)

BEGIN_MSG_MAP(F4TTempCtl, SerialDevice)
	SET_V( init, F4TTempCtl)
END_MSG_MAP


