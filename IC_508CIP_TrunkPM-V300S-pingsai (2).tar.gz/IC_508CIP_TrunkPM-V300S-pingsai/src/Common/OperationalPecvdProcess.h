#ifndef OPERATIONALPECVDPROCESS_H_
#define OPERATIONALPECVDPROCESS_H_

#include "ControlObjectEX.h"
#include "BlockingAlarm.h"
#include "ReadWriteInt.h"
#include "ReadWriteString.h"
#include "ReadWriteDouble.h"
#include "AppCondition.h"
#include "RecipeNamespaceManager.h"
#include "RecipeNameInfo.h"
#include "FunctionalPM.h"
#include "OverrunInterlock.h"
#include "Service.h"
#include "RecipeUser.h"
#include "Timer.h"
#include "CounterTimer.h"
#include "ControlObjectEX.h"
#include "OperationalModel.h"
#include "OperationalProcess.h"
#ifdef IAP4_0
using namespace IAP::ALARM;
using namespace IAP::IO;
using namespace IAP::CONDITION;
using namespace IAP::RECIPE;
using namespace IAP::INTERLOCK;
using namespace IAP::CONTROL;
using namespace IAP::CORE;
#endif


class OperationalPecvdProcess : public OperationalProcess
{
	DECLARE_DYNAMIC( OperationalPecvdProcess )
	DECLARE_MSG_MAP

	DECLARE_SERVICEINFO_LIST
	
public:
	
	class TotalCycleProcess : public Service
	{
		DECLARE_DYNAMIC_SERVICE(TotalCycleProcess)

		public:

			void execute();
	};

	public://constructor
		OperationalPecvdProcess();
		virtual ~OperationalPecvdProcess();

	public://service
		virtual bool do_TotalCycleProcess(const std::string &RecipeName,int nCycle);

	public://xml
		
		void setTheProcessStr(std::string &strPath);
		


	protected:
		FunctionalPM *m_pFuncTotalCycleProcess;
		
	public:
		ServicePtr<TotalCycleProcess> m_sTotalCycleProcess;//maxm [v1.0.27]



};

#endif /*OPERATIONALPECVDPROCESS_H_*/
