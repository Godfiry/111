#ifndef MATERIALIDINFO_H_
#define MATERIALIDINFO_H_

#include "IntValueInfo.h"
#include "IntTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class MaterialIdInfo : public IntValueInfo
{
	public:
		static const IntTypeInfo typeInfo;
		
		MaterialIdInfo():IntValueInfo(-1, typeInfo)
		{}
		
		MaterialIdInfo(int i):IntValueInfo(i, typeInfo)
		{
		}
};

#endif /*MATERIALIDINFO_H_*/
