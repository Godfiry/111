#ifndef STRTOOL_H_
#define STRTOOL_H_

#include <vector>
#include <string>

#include <sstream>
#include "AppCondition.h"
#ifdef IAP4_0
using namespace IAP::CONDITION;
#endif

using namespace std;

class StrTool
{
public:
	//split("ab?cd*ab",{'*','?'},2)->{"ab","cd","ab"}
	//split("*ab?cd*ab*",{'*','?'},2)->{"ab","cd","ab"}
	static vector<string> split(const string &strData,char * pSeparator,int nSeparatorNum);
	
	//split("abc*d*?ef","*?")->{"abc*d","ef"}
	static vector<string> split(const string &strData,const string &strSeparator);
	
	//eg:"a""bc""d" -> "abcd"
	static string join(vector<string> &strs);//lvjw

	//eg:strSeparator=" "
	//"a""bc""d" -> "a bc d"
	static string join(vector<string> &strs,const string strSeparator);//lvjw

	static void string_replace(string &strData, const string &str_oldvalue,const string &str_newvalue);


	static std::string toUpper(const std::string &str);
	static std::string toLower(const std::string &str);

	//Double2String(1121.325,"2")->"1121.33"
	//Double2String(1121.324,"2")->"1121.32"
	//Double2String(1121.1,"2")  ->"1121.10"
	static string Double2String(const double dData, const string strLength);//[lvjw]
	//Int2String(2,"2")->"02"
	//Int2String(-2,"2")->"-02"
	//Int2String(121,"2")->"121"
	static string Int2String(const int nData, const string strLength);//[lvjw]
	//Int2HexString(123)->"7b"
	//Int2HexString(-123)->not support
	static std::string Int2HexString(int value);
	//Int2HexString(123,1)->"7b"
	//Int2HexString(123,4)->"007b"
	//Int2HexString(-123,1)->not support
	static string Int2HexString(int nData,int length);

	//default:" ","/r"(0x0d),"/n"(0x0a)
	//trim(" abc \r\n")->"abc"
	static string trim(string strData);
	static string trim_start(string strData);
	static string trim_end(string strData);

	static string trim(string strData,const string strTrimChars);
	static string trim_start(string strData,const string strpTrimChars);
	static string trim_end(string strData,const string strpTrimChars);

	//contains("abcd","bc")->true
	static bool contains(string strData,string strContainStr);

	//startWith("abcde","ab")->true
	static bool startWith(const string strData,const string strStart);
	static bool endWith(const string strData,const string strEnd);

	static AppConditionPtr stringToCondition(const std::string &str);

	static string getIOStringFromCondition(const std::string &str);
	
	static bool stringToBool(const std::string& str);//[zhangcx v1.2.0]
};

#endif /*STRTOOL_H_*/
