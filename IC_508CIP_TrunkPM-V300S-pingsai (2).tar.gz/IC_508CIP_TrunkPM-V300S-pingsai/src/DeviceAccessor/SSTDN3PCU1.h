/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: SSTDN3PCU1.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2008-5-17   LiJuanjuan create
**      
*********************************************************************/
#ifndef SSTDN3PCU1_H_
#define SSTDN3PCU1_H_

#include "DeviceNet.h"
#include "sstdn3pcu1_pci.h"
#include "sstdn3pcu1_lib.h"

extern int dni;
extern DNS_SCANNER_CFG ScannerCfg;
extern DNS_DEVICE_CFG DeviceCfg;
extern cardmemel * CardMemHead, * curmemp;	
extern DNS_DEVICE_CFG * DevicesList[64];

class SSTDN3PCU1:public DeviceNet
{
	public:
		SSTDN3PCU1(const std::string &devName, int masterMacId, int baudRate);
		virtual ~SSTDN3PCU1();
		
		virtual void loadDevice(); 
		virtual bool addDevice(int inmac); 
		virtual int getIBytesSize(int inmac);
		virtual int getOBytesSize(int inmac);
		virtual bool readByte(int macid, char *buffer);
		virtual bool writeByte(int inmac, char *byte);
		virtual bool readBit(int inmac, int channel, bool *bit);
		virtual bool writeBit(int inmac, int channel, bool bit);
		virtual bool writeExplicit(int macid, char *buffer, int service, int Class, int instance, int datasize);
		virtual bool readExplicit(int macid, char *bufferIn, int service,int Class, int instance, int datasizeIn, char *bufferOut, int *datasizeOut);
		virtual int readStatus(int nMacId);//added by mujy[v1.0.8]
};

#endif /*SSTDN3PCU1_H_*/
