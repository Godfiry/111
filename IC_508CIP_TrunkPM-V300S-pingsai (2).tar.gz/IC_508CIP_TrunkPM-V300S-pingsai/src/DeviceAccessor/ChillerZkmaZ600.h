/********************************************************************
** Copyright (c) 2021, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: ChillerZkmaZ600.h
** Description:This driver is used for Institute of ZKMA Chiller
**               RS485
**               Communication Type:Modbus protocol,ASCII Mode
**     			 BaudRate:          9600 bps
**   			 Character length:  7 bit
**  			 Stop bit length:   1 bit
**				 Parity checking:   EVEN
** Release: 1.1
** Modification history:
** 				 2021-6-16   zhangyy create
**
*********************************************************************/

#ifndef CHILLERZKMAZ600_H_
#define CHILLERZKMAZ600_H_
#include "SerialDevice.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#include "ReadWriteDouble.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class ChillerZkmaZ600:public SerialDevice
{
	DECLARE_DYNAMIC(ChillerZkmaZ600)
	DECLARE_MSG_MAP

	public:
		ChillerZkmaZ600();
		virtual ~ChillerZkmaZ600();

		std::string SendReadWriteCmd(const std::string &strCommand);
		std::string ConstructTotalCmd();
		bool writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo);
		bool readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);
		bool readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);
		bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);

	public://xml
		void setChillerTempSetupCh(const std::string &strName);
		void setChillerOffsetSetupCh(const std::string &strName);
		void init();

	protected:
		void initDevice();
		void initChs(DeviceNode<ChillerZkmaZ600> *pNode);

	private:
		std::string m_strCommand;
		std::string m_strStartStop;
		std::string m_strTemp;
		std::string m_strChillerTempSetupPath;
		std::string m_strChillerOffsetSetupPath;


		ReadWriteDouble *m_cfgChillerTempSetpoint;
		ReadWriteDouble *m_cfgChillerTempOffset;
};

#endif /* CHILLERZKMAZ600_H_ */
