/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: RMHTempCtl.cpp
** Description:  
** Release: 1.1
** Modification history: 
**                  2013-12-31   bihuijie creat
**      
*********************************************************************/
#include "RMHTempCtl.h"
#include <string.h>
#include "CheckCalculationTool.h"
#include "DeviceManager.h"
#include "ObjectManager.h"
#include "Converter.h"

#include "ConfigException.h"
#include <sys/time.h>
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std;

const unsigned char RMHTempCtl::regReadAddress[26] = {
0x01,0x7C,0x01,0xD6,0x02,0x30,0x02,0x8A,0x02,0xE4,0x03,0x3E,0x03,0x98,0x03,0xF2,
0x10,0x1C,0x10,0x62,0x10,0xA8,0x10,0xEE,0x11,0x34
};//changed by wzd 1.1.20
const unsigned char RMHTempCtl::regReadErrorAddress[16] = {
0x01,0x7E,0x01,0xD8,0x02,0x32,0x02,0x8C,0x02,0xE6,0x03,0x40,0x03,0x9A,0x03,0xF4
};
const unsigned char RMHTempCtl::regWriteAddress[16] = {
0x14,0x64,0x14,0xB4,0x15,0x04,0x15,0x54,0x15,0xA4,0x15,0xF4,0x16,0x44,0x16,0x94
};
const unsigned char RMHTempCtl::regReadAlarmAddress[16] = {
0x0A,0x74,0x0A,0xB0,0x0A,0xEC,0x0B,0x28,0x0B,0x64,0x0B,0xA0,0x0B,0xDC,0x0C,0x18
};

const unsigned char RMHTempCtl::regReadOffsetAddress[16] = {
0x01,0x92,0x01,0xEC,0x02,0x46,0x02,0xA0,0x02,0xFA,0x03,0x54,0x03,0xAE,0x04,0x08
};

const unsigned char RMHTempCtl::regWriteOffsetAddress[16] = {
0x01,0x92,0x01,0xEC,0x02,0x46,0x02,0xA0,0x02,0xFA,0x03,0x54,0x03,0xAE,0x04,0x08
};
RMHTempCtl::RMHTempCtl():SerialDevice(80, "")
{
    
    m_timeOut = 20;//2s
    //the form of the read command
    m_readCmd[0] = 0x01;//controller address
    m_readCmd[1] = 0x03;//function read
    m_readCmd[2] = 0x00;//read starting at register high byte
    m_readCmd[3] = 0x00;//read starting at register low byte
    m_readCmd[4] = 0x00;//read number of consecutive register (always 0)
    m_readCmd[5] = 0x02;//read number of consecutive register (always 2)
    m_readCmd[6] = 0x00;//Low byte of CRC
    m_readCmd[7] = 0x00;//High byte of CRC
    
    //the form of the write command
    m_writeCmd[0] = 0x01;//controller address
    m_writeCmd[1] = 0x10;//function multiple write
    m_writeCmd[2] = 0x00;//write starting at register High byte
    m_writeCmd[3] = 0x00;//write starting at register Low byte
    m_writeCmd[4] = 0x00;//read number of consecutive register--High byte(always 0)
    m_writeCmd[5] = 0x02;//read number of consecutive register--Low byte
    m_writeCmd[6] = 0x04;//number of byte to Write
    m_writeCmd[7] = 0x00;//data High byte of 1# register write
    m_writeCmd[8] = 0x00;//data Low byte of 1# register write
    m_writeCmd[9] = 0x00;//data High byte of 2# register write
    m_writeCmd[10] = 0x00;//data Low byte of 2# register write
    m_writeCmd[11] = 0x00;//Low byte of CRC
    m_writeCmd[12] = 0x00;//High byte of CRC
    
    m_heatPower1 = 0;
    m_heatPower2 = 0;
    m_heatPower3 = 0;
    m_heatPower4 = 0;//add by wzd 1.1.20
    m_heatPower5 = 0;//add by wzd 1.1.20
}

RMHTempCtl::~RMHTempCtl()
{
}

//read data from the device
bool RMHTempCtl::readDouble(int nChannelNum,double * value ,const DoubleTypeInfo& typeinfo)
{
    if (isSimulated())
    {
        struct timeval tm;
        struct timezone *tz = NULL;
        
        gettimeofday(&tm,tz);
        *value = typeinfo.getMax() * ((double)tm.tv_usec / 1000000);
        return true;
    }
    //get the channel address with read only 
    if(nChannelNum >=15 && nChannelNum <= 25)
    {
        m_readCmd[2] = regReadAddress[(nChannelNum-15)*2];
        m_readCmd[3] = regReadAddress[(nChannelNum-15)*2+1];
    }
    if(nChannelNum >=80 && nChannelNum <= 87)
    {
        m_readCmd[2] = regReadOffsetAddress[(nChannelNum-80)*2];
        m_readCmd[3] = regReadOffsetAddress[(nChannelNum-80)*2+1];
    }
    //<<hex<<(int)m_readCmd[1]<<m_readCmd[2]<<m_readCmd[3]<<m_readCmd[4]<<m_readCmd[5]<<m_readCmd[6]<<m_readCmd[7]<<endl;
    
    // read tempCtl power  [1.1.29 add by zhangpf]
    else if(nChannelNum == 60) //channel 1:Power
    {
        m_readCmd[2] = 0x07;
        m_readCmd[3] = 0x2A;
    }
    else if(nChannelNum == 61) //channel 2:Power
    {
        m_readCmd[2] = 0x07;
        m_readCmd[3] = 0x48;
    }
    else if(nChannelNum == 62) //channel 3:Power
    {
        m_readCmd[2] = 0x07;
        m_readCmd[3] = 0x66;
    }
    else if(nChannelNum == 63) //channel 4:Power
    {
        m_readCmd[2] = 0x07;
        m_readCmd[3] = 0x84;
    }
    else if(nChannelNum == 64) //channel 5:Power	//added by liuxj v1.5.0,added Power5~Power8
    {
        m_readCmd[2] = 0x07;
        m_readCmd[3] = 0xA2;
    }
    else if(nChannelNum == 65) //channel 6:Power
    {
        m_readCmd[2] = 0x07;
        m_readCmd[3] = 0xC0;
    }
    else if(nChannelNum == 66) //channel 7:Power
    {
        m_readCmd[2] = 0x07;
        m_readCmd[3] = 0xDE;
    }
    else if(nChannelNum == 67) //channel 8:Power
    {
        m_readCmd[2] = 0x07;
        m_readCmd[3] = 0xFC;
    }
    m_readCmd[5] = 0x02;

    unsigned short crc = CheckCalculationTool::GetCRCCode( m_readCmd, 6 );
    m_readCmd[6] = crc & 0xff;  // low byte of CRC
    m_readCmd[7] = 0xff & (crc >> 8);    // high byte of CRC
    
    char response[RESP_LEN];
    int i=0;
    while (m_dev.readStr(response,1,RESP_LEN) > 0) //read the watlow
    {
        i++;
        if(i > 100)
         {
            setCommunicationStatus(COMMUNICATION_STATUS::DISCONNECT);
            throw IOException("Watlow temperature has some problem, there are more data received from temperature device");
         }
    }
    
    bzero(response, RESP_LEN);//reset the response
    
    //send the read data  8 bytes command
    if (m_dev.writeRaw(m_readCmd, 8) < 0)
    {
        //cout << "writeRaw return error" << endl;
        setCommunicationStatus(COMMUNICATION_STATUS::DISCONNECT);
        throw IOException("Watlow temperature read command failed for can't write to "+m_strDevName);
    }
    // receive data from the reading; readStr() function;  response is the char buff
    // 5 is the timeout value; RESP_LEN is the maxread
    if (m_dev.readStr(response,5,RESP_LEN) < 0)
     {
        //cout << "readStr return error..."<< endl;
        setCommunicationStatus(COMMUNICATION_STATUS::DISCONNECT);
        throw IOException("Watlow temperature read command failed for no response.");
     }
    double dTempValue = 0.0;
    if(response[0]==0x01&&response[1]==0x03)
    {
        if(response[2]==0x04)
        {
            unsigned char  cByte[4];//save the 32-bite
            int val;
            response[3] = response[3]&0x00ff;
            response[4] = response[4]&0x00ff;
            response[5] = response[5]&0x00ff;
            response[6] = response[6]&0x00ff;
            cByte[3] = response[5];
            cByte[2] = response[6];
            cByte[1] = response[3];
            cByte[0] = response[4];
           float pfValue=*(float*)&cByte;
           if(23 == nChannelNum)
           {
             dTempValue = (pfValue/100.0 )*m_heatPower1/208.0;
           }
           else if(24 == nChannelNum)
           {
           
             dTempValue = (pfValue/100.0 )*m_heatPower2/208.0;
           }
           else if(25 == nChannelNum)
           {
             dTempValue = (pfValue/100.0 )*m_heatPower3/208.0;
           }
           else if(26 == nChannelNum)//add by wzd 1.1.20
           {
             dTempValue = (pfValue/100.0 )*m_heatPower4/208.0;
           }
           else if(27 == nChannelNum)//add by wzd 1.1.20
           {
             dTempValue = (pfValue/100.0 )*m_heatPower5/208.0;
           }
           else
           {
             dTempValue = pfValue;
           }
           *value = MathTool::Round(dTempValue,typeinfo.getAccuracy());
           setDoubleValue(nChannelNum + MONITORDOUBLEVALUEADDMAP, *value, typeinfo.getAccuracy()); //added by liuxj v1.5.0 20250622 for TempCtl Protect CIP
           setCommunicationStatus(COMMUNICATION_STATUS::CONNECT);
           return true;
        }
        else
        {
            setCommunicationStatus(COMMUNICATION_STATUS::DISCONNECT);
            //cout<<"RHM the real data is:" <<response[3]<<endl;
            throw IOException("Watlow temperature read command failed for response is invalid(byte 3 is not equal 0x04)");
        }
    }
    else
    {
        setCommunicationStatus(COMMUNICATION_STATUS::DISCONNECT);
        //cout<< "RHM:the read data command is invalid"<<endl;
        throw IOException("Watlow temperature read command failed for response is invalid(byte 1 and 2 is not equal 0x01 and 0x03)");
    }
}

//write data to the RHM
bool RMHTempCtl::writeDouble(int nChannelNum, double settemp, const DoubleTypeInfo& typeinfo)
{
    if (isSimulated())
    {
        return true;
    }
    //get the channel address with REWS
    if (nChannelNum >= 1 && nChannelNum <= 8)
    {
        m_writeCmd[2] = regWriteAddress[(nChannelNum-1)*2];
        m_writeCmd[3] = regWriteAddress[(nChannelNum-1)*2+1];
    }
    if (nChannelNum >= 70 && nChannelNum <= 77)
    {
        m_writeCmd[2] = regWriteOffsetAddress[(nChannelNum-70)*2];
        m_writeCmd[3] = regWriteOffsetAddress[(nChannelNum-70)*2+1];
    }
    unsigned char floatToHex[4];
    //FloatToByte(settemp,floatToHex);
    //cout<<"settemp"<<settemp<<"="<<floatToHex[3]<<floatToHex[2]<<floatToHex[1]<<floatToHex[0]<<endl;
    
    float changesettemp = (float)settemp;
    char* pchar=(char*)&changesettemp;
    for(int i=0;i<sizeof(float);i++) //4
    {
        floatToHex[i]=*pchar;
        pchar++;
        //floatToHex++;
        //cout<<hex<<(int)*pchar<< " ";
    }
    for(int i=0;i<sizeof(float);i++) //4
    {
        //cout<<endl<<hex<<(int)floatToHex[i]<< " ";
    }
    m_writeCmd[7] =floatToHex[1];//0x00
    m_writeCmd[8] =floatToHex[0];//0x00
    m_writeCmd[9] =floatToHex[3];//0x42
    m_writeCmd[10]=floatToHex[2];//0x96
    
    unsigned short crc = CheckCalculationTool::GetCRCCode( m_writeCmd, 11 );
    m_writeCmd[11] =0xff&(crc & 0xff);  // low byte of CRCunsigned char ss = 0x96;
    m_writeCmd[12] = 0xff&( crc >> 8);    // high byte of CRC

    clearPort();

    //if the write command failed, return error
    if (m_dev.writeRaw(m_writeCmd, 13) < 0)
    {
        //cout << "RHM writeRaw return error" << endl;
        setCommunicationStatus(COMMUNICATION_STATUS::DISCONNECT);
        throw IOException("Watlow temperature send command failed for can't write to "+m_strDevName);
    }
    char response[RESP_LEN];
    bzero(response, RESP_LEN);
    
    //receive from writing 
    if (m_dev.readStr(response,100,RESP_LEN) < 0)
    {
        setCommunicationStatus(COMMUNICATION_STATUS::DISCONNECT);
        throw IOException("Watlow temperature send command failed for no response.");
    }
    else
    {
        for(int i =0 ; i<8;i++)
        {
            //cout<<hex<<(int)response[i]<<" ";
        }
    }
    //check the key bytes
    if(response[0]==0x01&&response[1]==0x10)
    {
        if(response[5]!= 0x02)
        {
            setCommunicationStatus(COMMUNICATION_STATUS::DISCONNECT);
            throw IOException("Watlow temperature send command failed for response is invalid(byte 6 is not equal 0x02)");
        }
        else
        {
            setCommunicationStatus(COMMUNICATION_STATUS::CONNECT);
            return true;    
        }
    }
    else
    {
        setCommunicationStatus(COMMUNICATION_STATUS::DISCONNECT);
        throw IOException("Watlow temperature send command failed for response is invalid(byte 1 and 2 is not equal 0x01 and 0x10)");
    }
    
}

//added by liusy for reading error[20190809]
bool RMHTempCtl::readString(int nChannelNum,string * pValue ,const StringTypeInfo& typeinfo)
{
    if (isSimulated())
    {
        *pValue = "NoError";
        //cout<<"ddddd"<<endl;
        return true;
    }
    //get the channel address with read only 
    if(nChannelNum >=30 && nChannelNum <= 37)
    {
        m_readCmd[2] = regReadErrorAddress[(nChannelNum-30)*2];
        m_readCmd[3] = regReadErrorAddress[(nChannelNum-30)*2+1];
    }
    m_readCmd[5] = 0x02;
    unsigned short crc = CheckCalculationTool::GetCRCCode( m_readCmd, 6 );
    m_readCmd[6] = crc & 0xff;  // low byte of CRC
    m_readCmd[7] = 0xff & (crc >> 8);    // high byte of CRC
    
    char response[RESP_LEN];
    bzero(response, RESP_LEN);//reset the response

    int nLen = getCommandResult(m_readCmd,8,response,9,m_timeOut);

    if(nLen < 5)
    {
        setCommunicationStatus(COMMUNICATION_STATUS::DISCONNECT);
        throw IOException("Watlow temperature read command failed for reading back time out ("+Converter::convertToString(m_timeOut/10)+"s)");
    }
    
    if(response[0]==0x01 && response[1]==0x03)
    {
        if(response[2]==0x04)
        {
            unsigned char cByte[4];//save the 32-bite
            
            response[3] = response[3]&0x00ff;
            response[4] = response[4]&0x00ff;

            cByte[3] = 0x00;
            cByte[2] = 0x00;
            cByte[1] = response[3];
            cByte[0] = response[4];

            int nValue=*(int*)&cByte;
            
            if(nValue == 61)
            {
                *pValue="NoError";
                setCommunicationStatus(COMMUNICATION_STATUS::CONNECT);
                return true;
            }
            
            *pValue = Converter::convertToString(nValue);
            setCommunicationStatus(COMMUNICATION_STATUS::CONNECT);
            return true;
        }
        else
        {
            throw IOException("Watlow temperature read command failed for response is invalid(byte 3 is not equal 0x04)");
        }
    }
    else
    {
        throw IOException("Watlow temperature read command failed for response is invalid(byte 1 and 2 is not equal 0x01 and 0x03)");
    }
}
bool RMHTempCtl::readAlarm(int nChannelNum,int * value , const IntTypeInfo& typeinfo)
{
    if (isSimulated())
    {
        struct timeval tm;
        struct timezone *tz = NULL;
        
        gettimeofday(&tm,tz);
        *value = tm.tv_usec % 2;
        return true;
    }
        //get the channel address with read only 
    if(nChannelNum >=40 && nChannelNum <= 47)
    {
      m_readCmd[2] = regReadAlarmAddress[(nChannelNum-40)*2];
      m_readCmd[3] = regReadAlarmAddress[(nChannelNum-40)*2+1];
    }
    m_readCmd[5] = 0x01;
    unsigned short crc = CheckCalculationTool::GetCRCCode( m_readCmd, 6 );
    m_readCmd[6] = crc & 0xff;  // low byte of CRC
    m_readCmd[7] = crc >> 8;    // high byte of CRC
    
    //consider all the possible exception
    char response[RESP_LEN];//save response data
    int i=0;

    
    while (m_dev.readStr(response,1,RESP_LEN) > 0) //read the watlow
    {
        i++;
        if(i > 100)
         {
            throw IOException("there are more data receive from RHMTempCtl");
         }
    }
    
    bzero(response, RESP_LEN);//reset the response
    
    //send the read data  8 bytes command
    if (m_dev.writeRaw(m_readCmd, 8) < 0)
    {
        cout << "writeRaw return error" << endl;
        throw IOException("WatLow failed to send command");
    }
    //receive data from the reading
    // readStr() function
    // response is the char buff
    // 5 is the timeout value
    // RESP_LEN is the maxread
    if (m_dev.readStr(response,5,RESP_LEN) < 0)
     {
        cout << "readStr return error..."<< endl;
        throw IOException("WatLow reading back times out");
     }

    //analysis the response:low temp or high temp   
    if((response[0] == 0x01)&& response[1] == 0x03)
    {
        if(response[2]==0x02 && response[3] == 0x00)
        {
            char resjudge = 0x00;//judge the length of response is 7 or not.
            
            for(i=8; i<RESP_LEN; i++)// or operation
                resjudge |= response[i];
            
            if(!resjudge) 
            {
                if(response[4] == 0x3D)
                { 
                    *value = 0;//0 represents that temp is normal
                    //cout << "WatLow: temp is normal!"<<endl;
                }
                else if(response[4] == 0x07)
                {
                    //set tempstatus
                    *value = 1;//1 represents that temp is high
                    cout << "WatLow: temp is high!"<<endl;
                    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "WatLow Alarm: high temp"+string(response));
                }
            
                else if (response[4] == 0x08)
                {
                    //set tempstatus
                    *value = -1;//-1 represents that temp is low
                    cout << "WatLow: temp is low!"<<endl;
                    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "WatLow Alarm: low temp"+string(response));
                }
                else 
                {
                    cout<<"WatLow: the real data is:"<<response[4]<<endl;
                    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "WatLow Alarm:wrong response or no device"+string(response));
                    throw IOException("WatLow: wrong response or no device...");
                }
                return true;
            }
            else 
            {
                cout << "length is wrong..."<< endl;    
                throw IOException("WatLow: the length of alarm reading back is wrong...");
            }
        }
        else
        {
            cout<<"WatLow: alarm reading data false..." <<response[2]<<response[3]<<endl;
            throw IOException("WatLow: alarm reading data false...");
        }
    }
    else
    {
        cout<< "WatLow:reading alarm data command is invalid"<<endl;
        throw IOException("WatLow:reading alarm data command is invalid");
    }
}

//added by xiasc[2017-03-30]
void RMHTempCtl::setHeatPower(int num,double power)
{
   if(1 == num)
   {
      m_heatPower1 = power;
   }
   else if(2 == num)
   {
      m_heatPower2 = power;
   }
   else if(3 == num)
   {
      m_heatPower3 = power;
   }
   else if(4 == num)//add by wzd 1.1.20
   {
      m_heatPower4 = power;
   }
   else if(5 == num)//add by wzd 1.1.20
   {
      m_heatPower5 = power;
   }
   else
   {
     throw ConfigException("Tempctl HeatPower num is out of range 1~5");//changed by wzd 1.1.20
   }

}

//register channel
void RMHTempCtl::initChs(DeviceNode<RMHTempCtl> *node)
{
    for(int i = 1; i <= 8; ++i)
    {
        node->registerWriteCh(i, &RMHTempCtl::writeDouble);
    }
    for(int i = 15; i <= 29; ++i)//changed by wzd 1.1.20
    {
        node->registerReadCh(i, &RMHTempCtl::readDouble);
        node->registerReadCh(i + MONITORDOUBLEVALUEADDMAP, &CMonitorDoubleValue::readDoubleChange); //added by liuxj v1.5.0 20250622 for TempCtl Protect CIP
        initDoubleValue(i + MONITORDOUBLEVALUEADDMAP, -1); //added by liuxj v1.5.0 20250622 for TempCtl Protect CIP
    }
    //added by liusy for reading error[20190809]
    for(int i = 30; i <= 37; ++i)
    {
        node->registerReadCh(i, &RMHTempCtl::readString); 
    }
    for(int i = 40; i <= 47; ++i)
    {
        node->registerReadCh(i, &RMHTempCtl::readAlarm);
    }
    for(int i = 60; i <= 67; ++i)	//added by liuxj v1.5.0,added Power5~Power8
    {
        node->registerReadCh(i, &RMHTempCtl::readDouble);
        node->registerReadCh(i + MONITORDOUBLEVALUEADDMAP, &CMonitorDoubleValue::readDoubleChange); //added by liuxj v1.5.0 20250622 for TempCtl Protect CIP
        initDoubleValue(i + MONITORDOUBLEVALUEADDMAP, -1); //added by liuxj v1.5.0 20250622 for TempCtl Protect CIP
    }
    for(int i = 70; i <= 77; ++i)//added by zhangyy for writing calibration offset
    {
        node->registerWriteCh(i, &RMHTempCtl::writeDouble);
    }
    for(int i = 80; i <= 87; ++i)//added by zhangyy for reading calibration offset
    {
        node->registerReadCh(i, &RMHTempCtl::readDouble);
    }

    node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &RMHTempCtl::getStatus);
}
void RMHTempCtl::initDevice()
{
    cout<<"Start Scan TempCtl...."<<endl;
    //say hello to tempctl
    double dTemp;
    try
    {
        readDouble(15,&dTemp,DoubleTypeInfo());
    }
    catch(exception &ex)
    {
        cout<<"Scan TempCtl failed. Communication abnormal!"<<endl; 
        throw;
    }
    cout<<"Scan TempCtl Successfully...."<<endl;
}
//init device       
void RMHTempCtl::init()
{
    DeviceNode<RMHTempCtl> *node = new DeviceNode<RMHTempCtl>(m_pollPeriod, this);  
    DeviceManager::getInstance()->registerNode(m_nodeNum, node);
    if(!isSimulated())  
    {
        initChs(node);  
        initDevice();
    }
}

IMPLEMENT_DYNAMIC(RMHTempCtl, SerialDevice)

BEGIN_MSG_MAP(RMHTempCtl, SerialDevice)
    SET_V( init, RMHTempCtl)
    SET_ID(setHeatPower, RMHTempCtl )
END_MSG_MAP



