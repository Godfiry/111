/*
 * FiberLaserCheyitianA500.cpp
 *
 *  Created on: 20240514
 *      Author: chenshicun
 *      Also applicable to Changchunxinchanye OEM-I-405-LE-500mW-GC31392
 */
#include "FiberLaserCheyitianA500.h"
#include <string.h>
#include "ObjectManager.h"
#include "DeviceManager.h"

#include "Hex.h"
#include <iostream>
#include "StrTool.h"
#include "CheckCalculationTool.h"
#ifdef IAP4_0
using namespace IAP::CORE;
using namespace IAP::IO;
using namespace IAP;
#endif
using namespace std;


FiberLaserCheyitianA500::FiberLaserCheyitianA500():SerialDevice(200, "")
{
	m_nTimeOut=20;
	m_nResLen = 11;
	m_writeCmd[0] = 0x5A;//start
	m_writeCmd[1] = 0x01;//start
	m_writeCmd[2] = 0x00;//00 stop /01 start/02 set
	m_writeCmd[3] = 0x00;//one
	m_writeCmd[4] = 0x00;//one
	m_writeCmd[5] = 0x00;//00 stop /01 start/02 set
	m_writeCmd[6] = 0x00;//two
	m_writeCmd[7] = 0x00;//two
	m_writeCmd[8] = 0x00;//check
	m_writeCmd[9] = 0xA5;//end

	m_dPower1 = 0;
	m_dPower2 = 0;
}

FiberLaserCheyitianA500::~FiberLaserCheyitianA500()
{
}


bool FiberLaserCheyitianA500::writeDouble(int nChannelNum, double dValue,const DoubleTypeInfo &typeInfo)
{
	refreshCh();
	int power = dValue;
	int powerqian = power / 1000;
	power = power % 1000;
	int powerbai = power / 100;
	power = power % 100;
	int powershi = power / 10;
	power = power % 10;
	int powerge = power;

	int voltageH = (powerqian << 4) + powerbai;
	int voltageL = (powershi << 4) + powerge;

	if(0 <= nChannelNum && nChannelNum < 10)
	{
		m_writeCmd[2] = 0x03;
		m_writeCmd[3] = voltageH;
		m_writeCmd[4] = voltageL;
	}
	else
	{
		m_writeCmd[5] = 0x03;
		m_writeCmd[6] = voltageH;
		m_writeCmd[7] = voltageL;
	}

	unsigned short crc = CheckCalculationTool::GetCRCCode( m_writeCmd, 2, 7 );
	m_writeCmd[8] = crc & 0xff;// get low byte of CRC as checkcode

	char response[m_nResLen];
	bzero(response, m_nResLen);//reset the response
	if(getCommandResult(m_writeCmd, 10, response, m_nResLen, m_nTimeOut)  < 0)
	 {
		throw IOException("FiberLaser reading back times out");
	 }

	return true;
}

bool FiberLaserCheyitianA500::writeInt(int nChannelNum, int nValue,const IntTypeInfo &typeInfo)
{
	refreshCh();
	if(nChannelNum == 0)
	{
		m_writeCmd[2] = (nValue == 0)?0x00:0x01;
	}
	else if(nChannelNum == 10)
	{
		m_writeCmd[5] = (nValue == 0)?0x00:0x01;
	}

	unsigned short crc = CheckCalculationTool::GetCRCCode( m_writeCmd, 2, 7 );
	m_writeCmd[8] = crc & 0xff;// get low byte of CRC as checkcode

	char response[m_nResLen];
	bzero(response, m_nResLen);//reset the response
	if(getCommandResult(m_writeCmd, 10, response, m_nResLen, m_nTimeOut)  < 0)
	 {
		throw IOException("FiberLaser reading back times out");
	 }

	m_dPower1 = (response[3]<<8) + response[4];
	m_dPower2 = (response[6]<<8) + response[7];

	return true;
}

bool FiberLaserCheyitianA500::requestInt(int nChannelNum, int *pValue,const IntTypeInfo &typeInfo)
{
	refreshCh();
	m_writeCmd[2] = 0x04;
	m_writeCmd[5] = 0x04;
	char response[m_nResLen];
	unsigned short crc = CheckCalculationTool::GetCRCCode( m_writeCmd, 2, 7 );
	m_writeCmd[8] = crc & 0xff;// get low byte of CRC as checkcode

	if(getCommandResult(m_writeCmd, 10, response, m_nResLen, m_nTimeOut)  < 0)
	 {
		throw IOException("FiberLaser reading back times out");
	 }

	*pValue = (response[13] == '0')?1:0;//value=1 abnormal , value=0 normal

	return true;
}

bool FiberLaserCheyitianA500::readDouble(int nChannelNum, double *pValue,const DoubleTypeInfo &typeInfo)
{
	*pValue = (nChannelNum == 2)?m_dPower1:m_dPower2;
	return true;
}

void FiberLaserCheyitianA500::initChs(DeviceNode<FiberLaserCheyitianA500>* pNode)
{
	int nLaserNum = 2;
	for(int i=0; i<nLaserNum; i++)
	{
		pNode->registerWriteCh(0+10*i, &FiberLaserCheyitianA500::writeInt);//Laser start&stop
		pNode->registerReadCh(1+10*i, &FiberLaserCheyitianA500::readDouble);//Laser read Power
		pNode->registerWriteCh(2+10*i, &FiberLaserCheyitianA500::writeDouble);//Laser write Power
		pNode->registerReadCh(3+10*i, &FiberLaserCheyitianA500::requestInt);//check Laser status
	}
	pNode->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &FiberLaserCheyitianA500::getStatus);
}

void FiberLaserCheyitianA500::initDevice()
{
	cout<<"Start Scan FiberLaser...."<<endl;
	try
	{
		refreshCh();
		char response[m_nResLen];
		bzero(response, m_nResLen);//reset the response
		if(getCommandResult(m_writeCmd, 10, response, m_nResLen, m_nTimeOut) < 0)
		{
			throw IOException("FiberLaser reading back times out");
		}
	}
	catch(exception &ex)
	{
		cout<<"Scan FiberLaser failed. Communication abnormal!"<<endl;
		throw;
	}
	cout<<"Scan FiberLaser Successfully...."<<endl;
}


void FiberLaserCheyitianA500::init()
{
	DeviceNode<FiberLaserCheyitianA500> *pNode = new DeviceNode<FiberLaserCheyitianA500>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);

	if(!isSimulated())
	{
		initChs(pNode);
		initDevice();
	}
}

void FiberLaserCheyitianA500::refreshCh()
{
	m_writeCmd[0] = 0x5A;//start
	m_writeCmd[1] = 0x01;//start
	m_writeCmd[2] = 0x00;//00 stop /01 start/02 set
	m_writeCmd[3] = 0x00;//one
	m_writeCmd[4] = 0x00;//one
	m_writeCmd[5] = 0x00;//00 stop /01 start/02 set
	m_writeCmd[6] = 0x00;//two
	m_writeCmd[7] = 0x00;//two
	m_writeCmd[8] = 0x00;//check
	m_writeCmd[9] = 0xA5;//end
}


IMPLEMENT_DYNAMIC(FiberLaserCheyitianA500, SerialDevice )

BEGIN_MSG_MAP(FiberLaserCheyitianA500, SerialDevice )
	SET_V( init, FiberLaserCheyitianA500 )
END_MSG_MAP
