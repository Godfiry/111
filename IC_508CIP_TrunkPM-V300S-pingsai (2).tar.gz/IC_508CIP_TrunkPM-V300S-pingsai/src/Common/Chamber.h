#ifndef CHAMBER_H_
#define CHAMBER_H_

#include "Station.h"
#include "ValveController.h"

class Chamber:public Station
{
	DECLARE_DYNAMIC( Chamber ) 
	DECLARE_MSG_MAP
	DECLARE_SERVICEINFO_LIST
	
	class OpenDoor : public Service
	{
		DECLARE_DYNAMIC_SERVICE(OpenDoor)
		
		public:
			void execute();
	};
	class CloseDoor : public Service
	{
		DECLARE_DYNAMIC_SERVICE(CloseDoor)
		
		public:
			void execute();
	};
	
	class IsolateDoor:public Service
	{
		DECLARE_DYNAMIC_SERVICE(IsolateDoor)
		
		public:
			void execute();
	};
	
public:
	Chamber();
	virtual ~Chamber();
	
public://xml config	
	void addDoor(int nPort,const std::string &strPath);
	
public://for service
	void call_OpenDoor(int nPort);
	virtual void do_OpenDoor(int nPort);
	
	void call_CloseDoor(int nPort);
	virtual void do_CloseDoor(int nPort);
	
	void call_IsolateDoor();
	virtual void do_IsolateDoor();
	
public:
	bool isIsolatedDoor();
	
	bool isDoorOpen(int nPort);
	bool isDoorClose(int nPort);
	
	ValveController * getDoor(int nPort);
	 
protected://override
	virtual void initialize();
	virtual void verifyInit();

protected:
	bool IsDoorExist(int nPort);
	
private:
	ServicePtr<OpenDoor> m_OpenDoor;
	ServicePtr<CloseDoor> m_CloseDoor;
	ServicePtr<IsolateDoor> m_IsolateDoor;
	
private:
	std::map<int ,ValveController *> m_Doors;
};

#endif /*CHAMBER_H_*/
