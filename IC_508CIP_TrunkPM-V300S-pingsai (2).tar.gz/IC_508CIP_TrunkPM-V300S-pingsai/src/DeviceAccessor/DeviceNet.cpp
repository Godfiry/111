/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: DeviceNet.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2007-9-22   LiJuanjuan create
**      
*********************************************************************/
#include "DeviceNet.h"
#include "unistd.h"

using namespace std;

DeviceNet::DeviceNet(const std::string &devName, int masterMacId, int baudRate)
{
	m_devName = devName;
	m_baudRate = baudRate;
	m_masterMacID = masterMacId;
	m_fwdir = "";//string(get_current_dir_name()) +"/DeviceAccessor/";
	
	m_nHeadLen = -1;
	
}

DeviceNet::~DeviceNet()
{
}

void DeviceNet::setFWdir(const std::string &dir)
{
	m_fwdir = dir;
}

void DeviceNet::setHeadLen(int len)  //add by wzd 1.1.54
{
	m_nHeadLen = len;
}

/*
bool DeviceNet::writeExplicit(int macid, int service,int class, int instance, int attribute, char *data, char *result)
{
	
}
*/


/*
bool DeviceNet::readByte(int macid, char *buffer)
{
	if(DevicesList[macid] == NULL)
	{
		return false;
	}
	int foo;
	unsigned char inflags;
	unsigned char outflags;
	time_t initialtime;
	time_t passedtime;
	time_t accumedtime;
	unsigned int timeout = 3;

	unsigned char DSTL_INITRLCK = DSTL_IN1ITRLCK;
	unsigned char DCTL_INITRLCK = DCTL_IN1ITRLCK;
	unsigned short input_offset = DevicesList[macid]->Input1Offset;
	unsigned short input_size = DevicesList[macid]->Input1Size;

	bool flag = true;
	while(flag)
	{
		flag = false;
		initialtime = time(&passedtime);
	  // Check IO interlock flag in the Device Status Table.  
		do {
		foo=ioctl(dni,SS5136DN_SETCARDMEMPTR,DATA_BASE+(STATUSTOP+(macid*DSONSIZE)+1));
		foo=read(dni,&inflags,1);
		accumedtime = time(&passedtime) - initialtime;
		} while ((inflags & DSTL_INITRLCK) && (accumedtime < timeout));
	  // Once more to avoid racing 
		if (inflags & DSTL_INITRLCK)
	    {
			foo=ioctl(dni,SS5136DN_SETCARDMEMPTR,DATA_BASE+(STATUSTOP+(macid*DSONSIZE)+1));
			foo=read(dni,&inflags,1);
	    }
		if (inflags & DSTL_INITRLCK)
		{
			return false;
		}
	
	 // Set the IO interlock flag in the Device Control Table 
		foo=ioctl(dni,SS5136DN_SETCARDMEMPTR,DATA_BASE+(CONTROLTOP+(macid*DCONSIZE)));
		foo=read(dni,&inflags,1);
		outflags = inflags | DCTL_INITRLCK;
		foo=ioctl(dni,SS5136DN_SETCARDMEMPTR,DATA_BASE+(CONTROLTOP+(macid*DCONSIZE)));
		foo=write(dni,&outflags,1);
	
	  // Re-check IO interlock flag in the Device Status Table. 
		foo=ioctl(dni,SS5136DN_SETCARDMEMPTR,DATA_BASE+(STATUSTOP+(macid*DSONSIZE)+1));
		foo=read(dni,&inflags,1);
		if (inflags & DSTL_INITRLCK)
		{
			foo=ioctl(dni,SS5136DN_SETCARDMEMPTR,DATA_BASE+(CONTROLTOP+(macid*DCONSIZE)));
			foo=read(dni,&inflags,1);
			outflags = inflags & (~DCTL_INITRLCK);
			foo=ioctl(dni,SS5136DN_SETCARDMEMPTR,DATA_BASE+(CONTROLTOP+(macid*DCONSIZE)));
			foo=write(dni,&outflags,1);
			flag = true;
	  	}
	}

  // Read IO data  
	foo=ioctl(dni,SS5136DN_SETCARDMEMPTR,DATA_BASE+input_offset);
	read(dni, buffer, input_size);
//  if (dbg ==1) dumpcardmem("readed.txt");

  // Clear the IO interlock flag in the Device Control Table 
	foo=ioctl(dni,SS5136DN_SETCARDMEMPTR,DATA_BASE+(CONTROLTOP+(macid*DCONSIZE)));
	foo=read(dni,&inflags,1);
	outflags = inflags & (~DCTL_INITRLCK);
	foo=ioctl(dni,SS5136DN_SETCARDMEMPTR,DATA_BASE+(CONTROLTOP+(macid*DCONSIZE)));
	foo=write(dni,&outflags,1);

	return true;	
}*/


/*
bool DeviceNet::writeByte(int macid, char *buffer)
{
	if(DevicesList[macid] == NULL)
	{
		return false;
	}	
	int foo;
	unsigned char inflags;
	unsigned char outflags;
	time_t initialtime;
	time_t passedtime;
	time_t accumedtime;
	unsigned int timeout = 3;  

	unsigned char DSTL_OUTITRLCK = DSTL_OUT1ITRLCK;
	unsigned char DCTL_OUTITRLCK = DCTL_OUT1ITRLCK;
	unsigned short output_offset = DevicesList[macid]->Output1Offset;
	unsigned short output_size = DevicesList[macid]->Output1Size;

	bool flag = true;
	while(flag)
	{
		flag = false;
		initialtime = time(&passedtime);
	  // Check IO interlock flag in the Device Status Table.  
		do {
		foo=ioctl(dni,SS5136DN_SETCARDMEMPTR,DATA_BASE+(STATUSTOP+(macid*DSONSIZE)+1));
		foo=read(dni,&inflags,1);
		accumedtime = time(&passedtime) - initialtime;
		} while ((inflags & DSTL_OUTITRLCK) && (accumedtime < timeout));
	  // Once more to avoid racing  
		if (inflags & DSTL_OUTITRLCK)
	    {
			foo=ioctl(dni,SS5136DN_SETCARDMEMPTR,DATA_BASE+(STATUSTOP+(macid*DSONSIZE)+1));
			foo=read(dni,&inflags,1);
	    }
		if (inflags & DSTL_OUTITRLCK)
		{
			return false;
		}
	
	  // Set the IO interlock flag in the Device Control Table 
		foo=ioctl(dni,SS5136DN_SETCARDMEMPTR,DATA_BASE+(CONTROLTOP+(macid*DCONSIZE)));
		foo=read(dni,&inflags,1);
		outflags = inflags | DCTL_OUTITRLCK;
		foo=ioctl(dni,SS5136DN_SETCARDMEMPTR,DATA_BASE+(CONTROLTOP+(macid*DCONSIZE)));
		foo=write(dni,&outflags,1);
	
	  // Re-check IO interlock flag in the Device Status Table.  
		foo=ioctl(dni,SS5136DN_SETCARDMEMPTR,DATA_BASE+(STATUSTOP+(macid*DSONSIZE)+1));
		foo=read(dni,&inflags,1);
		if (inflags & DSTL_OUTITRLCK)
		{
			foo=ioctl(dni,SS5136DN_SETCARDMEMPTR,DATA_BASE+(CONTROLTOP+(macid*DCONSIZE)));
			foo=read(dni,&inflags,1);
			outflags = inflags & (~DCTL_OUTITRLCK);
			foo=ioctl(dni,SS5136DN_SETCARDMEMPTR,DATA_BASE+(CONTROLTOP+(macid*DCONSIZE)));
			foo=write(dni,&outflags,1);
			flag = true;
		}
	}

  // Write IO data  
	foo=ioctl(dni,SS5136DN_SETCARDMEMPTR,DATA_BASE+output_offset);
	write(dni, buffer, output_size);

  // Clear the IO interlock flag in the Device Control Table 
	foo=ioctl(dni,SS5136DN_SETCARDMEMPTR,DATA_BASE+(CONTROLTOP+(macid*DCONSIZE)));
	foo=read(dni,&inflags,1);
	outflags = inflags & (~DCTL_OUTITRLCK);
	foo=ioctl(dni,SS5136DN_SETCARDMEMPTR,DATA_BASE+(CONTROLTOP+(macid*DCONSIZE)));
	foo=write(dni,&outflags,1);

	return true;	
}
*/
