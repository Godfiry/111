/*
 * KylandShmDevice.h
 *
 *  Created on: Feb 12, 2025
 *      Author: zhangyy
 */

#ifndef KYLANDSHMDEVICE_H_
#define KYLANDSHMDEVICE_H_


#include <string>
//#include "KylandShmBaseNode.h"
#include "AbstractDevice.h"
#include "IntTypeInfo.h"
#include "DoubleTypeInfo.h"
#include <fstream>
#include "DeviceNode.h"
#include "IODevice.h"
#include "IMutex.h"
#include <map>
#include "Util.h"
#include "IStringList.h"
#include "unistd.h"
#include "sys/time.h"
#include "stdio.h"
#include "stdlib.h"
#include "PLCRecipeAssistant.h"
#include "TCPDevice.h"
#include "IThread.h"

#define RESPONSE_SHORTEST_LENGTH 8
#define REGISTE_AREA 400000
#define MAX_SENDCOM_LENGTH 64


//typedef unsigned char       BOOL;
typedef char                SINT;
typedef int                 INT;
typedef float               REAL;

class KylandShmDevice : public AbstractDevice
{

	DECLARE_DYNAMIC(KylandShmDevice)
	DECLARE_MSG_MAP


	struct Param
	{
	public:
		int m_nAddr;
		int m_nType;
	};

	struct ReadData
	{
	public:
		int m_nOffset;
		int m_nDataType;
	};

private:

    /*
	std::map<std::string, Param> m_mapRecipeData;
	PLCRecipeAssistant * m_pPLCRecipeAssistant;
	std::string m_strPLCRecipeAssistantPath;
	char m_pModbusSend[MAX_SENDCOM_LENGTH];
	char m_pModbusSend[MAX_SENDCOM_LENGTH];
	IWaitCondition m_waitAction;
	*/

protected:

	
	IMutex m_lock;


	int m_nNodeNum;
	int m_nPollInterval;
	int m_nTimeOut;

protected:

	bool SHM_WBool[5000];
	INT SHM_WDint[5000];
	REAL SHM_WReal[5000];

	bool SHM_RBool[5000];
	INT SHM_RDint[5000];
	REAL SHM_RReal[5000];
	double m_dFullScale;

	std::vector<int> m_NoChangeChannel;

public:
	KylandShmDevice();
	virtual ~KylandShmDevice();
	virtual void loadDevice();


	virtual void init();
	virtual void initChs(DeviceNode<KylandShmDevice> *pNode);

	bool readInt(int nChannelNum, int *nValue, const IntTypeInfo &typeInfo);
	bool readDouble(int nChannelNum, double *dValue, const DoubleTypeInfo &typeInfo);
	bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
	bool writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo);
	//bool writeRecipe(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);//added by V300S

	void setFullScale(double dFullScale);
	void setTimeOut(int nTime);
	void setNodeNum(int nNodeNum);
	void setPollIntervalMS(int nInterval);
	void setNoChangeChannel(int nNoChangeChannel);


    //void addRecipeParam(string strParamName,int nRegisteAddress, int nParamType);//ParamType: 1 is int ; 2 is double
	//void setPLCRecipeAssistant(string strPath);
protected:

	bool writeShm(char * pBlockName, unsigned int pBlockSize, void * pData);
	bool readShm(char * pBlockName, unsigned int pBlockSize, void * pData);
    
	//void loadRecipeParam();
};


#endif /* KYLANDSHMDEVICE_H_ */
