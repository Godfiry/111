/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .cpp
** Description: 
** Release: 
** Modification history: 
**                  Feb 22, 2008  shenql  create 
*                   2010-0118 lijj modified
**      
***************************************************************************/
#include "CounterTimerMs.h"
#include "ConfigException.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "AbortException.h"
#endif
#include "Converter.h"
#include "SysLogger.h"
#include "Converter.h"
#ifdef IAP4_0
#include "ITime.h"
#else
#include "Time.h"
#endif
#include "UTime.h"
#include "TimedCollectDataEnum.h"
#include <math.h>
#include <iostream>
#ifdef IAP4_0
using namespace IAP;
using namespace IAP::CORE;
#endif

using namespace std;

CounterTimerMs::CounterTimerMs()
{
    m_initialTime = 0;
    m_startTime = 0;
    m_running = false;
    m_counterType = 0;
    m_timerItem = NULL;
    m_periodInSeconds = 1.0;
    m_typeInfo = IntTypeInfo(DescriptorList("Up, Down"));
    m_myTimer = new Timer();
    m_myTimer->subscribe(this); 
    m_pCollectData = NULL;  
    m_dCollectTime = 0;
    m_dThreshold = 0.1;    //add by xiezr v1.1.48_hotfix2
}

CounterTimerMs::CounterTimerMs(const CounterTimerMs& pObj)
{
    m_initialTime = pObj.m_initialTime;
    m_startTime = pObj.m_startTime;
    m_running = pObj.m_running;
    m_counterType = pObj.m_counterType;
    m_timerItem = pObj.m_timerItem;
    m_periodInSeconds = pObj.m_periodInSeconds;
    m_typeInfo = IntTypeInfo(DescriptorList("Up, Down"));
    m_myTimer = new Timer();
    m_myTimer->subscribe(this);
    m_pCollectData = pObj.m_pCollectData;
    m_dCollectTime = pObj.m_dCollectTime;
    m_dThreshold = pObj.m_dThreshold;
}

CounterTimerMs& CounterTimerMs::operator=(const CounterTimerMs& pObj)
{
    if (this != &pObj)
    {
        m_initialTime = pObj.m_initialTime;
        m_startTime = pObj.m_startTime;
        m_running = pObj.m_running;
        m_counterType = pObj.m_counterType;
        m_timerItem = pObj.m_timerItem;
        m_periodInSeconds = pObj.m_periodInSeconds;
        m_typeInfo = IntTypeInfo(DescriptorList("Up, Down"));
        m_myTimer = new Timer();
        m_myTimer->subscribe(this);
        m_pCollectData = pObj.m_pCollectData;
        m_dCollectTime = pObj.m_dCollectTime;
        m_dThreshold = pObj.m_dThreshold;
    }
    return *this;
}

CounterTimerMs::~CounterTimerMs()
{
    #ifndef IAP4_0
    delete m_myTimer;
    m_myTimer = NULL;
    #endif

}

CounterTimerMs::CounterTimerMs(ReadWriteDouble *data, int counterType, double period)
{
    m_initialTime = data->getValue();
    m_startTime = 0;    
    m_running = false;
    m_timerItem = data;
    m_typeInfo =  IntTypeInfo(DescriptorList("Up, Down"));
    setCounterType(counterType);
    m_myTimer = new Timer();
    m_myTimer->subscribe(this);
    setPeriod(period);
    m_pCollectData = NULL;
    m_dCollectTime = 0;
    m_dThreshold = 0.1;  //add by xiezr v1.1.48_hotfix2
}

CounterTimerMs::CounterTimerMs(ReadWriteDouble *data, int counterType, double period,ReadWriteInt *collectData,double collectTime)//added by mujy [v1.0.20]
{
    m_initialTime = data->getValue();
    m_startTime = 0;
    m_running = false;  
    m_timerItem = data;
    m_typeInfo =  IntTypeInfo(DescriptorList("Up, Down"));
    setCounterType(counterType);
    m_myTimer = new Timer();
    m_myTimer->subscribe(this);
    setPeriod(period);
    m_pCollectData = collectData;//added by mujy 
    m_dCollectTime = collectTime;//added by mujy 
    m_dThreshold = 0.1;  //add by xiezr v1.1.48_hotfix2
}

CounterTimerMs::CounterTimerMs(ReadWriteDouble *data, int counterType, double period,ReadWriteInt *collectData,double collectTime, double updateThreshold)  //add by xiezr v1.1.48_hotfix2
{
    m_initialTime = data->getValue();
    m_startTime = 0;
    m_running = false;  
    m_timerItem = data;
    m_typeInfo =  IntTypeInfo(DescriptorList("Up, Down"));
    setCounterType(counterType);
    m_myTimer = new Timer();
    m_myTimer->subscribe(this);
    setPeriod(period);
    m_pCollectData = collectData;//added by mujy 
    m_dCollectTime = collectTime;//added by mujy
    m_dThreshold = updateThreshold;  //add by xiezr v1.1.48_hotfix2
}

void CounterTimerMs::setCounterType(int i)
{
    if(i < m_typeInfo.getMin() || i > m_typeInfo.getMax())
    {
        string s = "Counter type " + i;
        throw ConfigException( s + " out of range");
    } 
    else
    {
        m_counterType = i;
    }
}

void CounterTimerMs::setCounterType(string s)
{
    m_counterType = m_typeInfo.getDescriptorList().getDescriptorValue(s);
}

void CounterTimerMs::setPeriod(double d)
{
    if(d < 0.01)
    {
        throw ConfigException("Period must be positive");
    } 
    else
    {
        m_periodInSeconds = d;
    }
}

void CounterTimerMs::setTimerItem(ReadWriteDouble* data)
{
    m_timerItem = data;
}


void CounterTimerMs::setCollectTime(double dTime)
{
    m_dCollectTime = dTime;
}
void CounterTimerMs::start()
{   
    if(m_running)
    {
        return;
    }
    m_initialTime = m_timerItem->getValue();
    m_running = true;
    //m_startTime = Time::getCurrentTimeAsSeconds();
    m_startTime =UTime::getCurrentTimeAsMSeconds();
    m_myTimer->setDuration((long)(m_periodInSeconds*1000)); 
    m_myTimer->start();
    if(m_pCollectData != NULL)//added by mujy 
    {
        m_pCollectData->setValue(TIMEDCOLLECTDATA::UnInit);
    }
}

void CounterTimerMs::stop()
{
    if(!m_running)
    {
        return;
    }   
    #ifndef IAP4_0
    updateFromTimer();
    #endif
    m_running = false;
    m_myTimer->stop();
    m_startTime = 0;
    if(m_pCollectData != NULL)//added by mujy 
    {
        m_pCollectData->setValue(TIMEDCOLLECTDATA::Stop);
    }
}

#ifdef IAP4_0
void CounterTimerMs::updateFromTimer(const Timer * const timer)
#else
void CounterTimerMs::updateFromTimer()
#endif
{
    if(!m_running)
    {
        return;
    }
    double t_newValue = 0;
    //double t_passedTimeInSeconds = Time::getCurrentTimeAsSeconds() - m_startTime;
    double t_passedTimeInSeconds =  (UTime::getCurrentTimeAsMSeconds() - m_startTime)/1000.0;
    if(m_pCollectData != NULL)//added by mujy 
    {
        if(m_pCollectData->getValue() != TIMEDCOLLECTDATA::Collect)
        {
            if(t_passedTimeInSeconds > m_dCollectTime && (t_passedTimeInSeconds - m_dCollectTime) < m_dThreshold)
            {
                m_pCollectData->setValue(TIMEDCOLLECTDATA::Collect);
            }
        }
        
    }
    switch(m_counterType)
    {
        case 0: // up
            t_newValue = m_initialTime + t_passedTimeInSeconds;
            break;
        
        case 1: // down
            if(m_initialTime - t_passedTimeInSeconds > 0)
            {
                t_newValue = m_initialTime - t_passedTimeInSeconds;
            }
            break;
            
        default:
            break;
    }
    try
    {
        m_timerItem->setValue(t_newValue);
    }
    catch(const exception &ex)
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, m_timerItem->getName() + "updateFromTimer() catch exception "+ex.what());
    }

}
