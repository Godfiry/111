#include "SMCChillerDNetDriver.h"
#include "DeviceManager.h"
#include <iostream>
#include <string.h>
#ifdef IAP4_0
using namespace IAP::IO;
#endif
using namespace std;

SMCChillerDNetDriver::Com SMCChillerDNetDriver::m_Commands[] = {{0, 0}, //0	reserved 	
											{2,0},//1.Byte2,bit0 is Run/Stop flag. 0=Stop,1=Run
											{0,0},//2.Byte0 and Byte1,set temperature 
											//------------------//
											{0,0},//3.Byte0 and Byte1,read temperature 
											{4,0},//4.Byte4 and Byte5,read Pressure
											{2,0},//5.Byte2 and Byte3,read water Flow
											{8,1},//6.Byte8,bit1,read status flag <Fault flag>
											{8,2},//7.Byte8,bit2,read status flag <Warning flag>
											{8,5},//8.Byte8,bit5,read status flag <remote flag>
											{10,0},//9.Byte10,11,12,13,read alarm										
											{8,0}//10.Byte8,bit0,read status flag <run flag>

};

SMCChillerDNetDriver::SMCChillerDNetDriver()
{
	m_pWriteBuffer = NULL;
}

SMCChillerDNetDriver::~SMCChillerDNetDriver()
{
	if(m_pWriteBuffer != NULL)
	{
		delete m_pWriteBuffer;
		m_pWriteBuffer = NULL;
	}	
}

bool SMCChillerDNetDriver::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
	Com com = m_Commands[nChannelNum];
	unsigned char bitmask = 1;
	bitmask = bitmask << com.m_nBit;
	
	if(nValue == 1)
	{
		m_pWriteBuffer[com.m_nByte] = m_pWriteBuffer[com.m_nByte] | bitmask;//start chiller
	}
	if(nValue == 0)
	{
		bitmask = ~bitmask;
		m_pWriteBuffer[com.m_nByte] = m_pWriteBuffer[com.m_nByte] & bitmask;//stop chiller
	}
	return m_deviceNet->writeByte(m_macID, m_pWriteBuffer);

}

bool SMCChillerDNetDriver::writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
	Com com = m_Commands[nChannelNum];
	
	unsigned long  temp = 0;
	temp = (unsigned long) (dValue * 10.0);
	m_pWriteBuffer[com.m_nByte] = (unsigned char)(temp & 0xff);//byte[0]temperature set point LSB
	m_pWriteBuffer[com.m_nByte+1] = (unsigned char)((temp>>8) & 0xff);//byte[1]temperature set point MSB
	
	return m_deviceNet->writeByte(m_macID, m_pWriteBuffer);

}

bool SMCChillerDNetDriver::readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
	Com com = m_Commands[nChannelNum];
	int inputBytes = m_deviceNet->getIBytesSize(m_macID);
	char buffer[inputBytes];
	memset(buffer, 0, inputBytes);
	m_deviceNet->readByte(m_macID, buffer);
	
	unsigned int nTempValue = 0;
	if(nChannelNum == 9)//read alarm flag
	{
		 nTempValue= ((unsigned int)buffer[com.m_nByte]) & 0xff + ((unsigned int)buffer[com.m_nByte+1]) & 0xff + ((unsigned int)buffer[com.m_nByte+2]) & 0xff +((unsigned int)buffer[com.m_nByte+3]) & 0xff;
		 if(nTempValue >1)
		 {
		 	SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "SMCChillerDNetDriver: channel ["+Converter::convertToString(nChannelNum)+"] read alarm status sum is  "+Converter::convertToString(nTempValue));
		 	nTempValue = 1;
		 }
	}
	else
	{
		unsigned int movebit = 1 << com.m_nBit;
		unsigned int temp = ((unsigned int)buffer[com.m_nByte]) & movebit;
	    nTempValue = temp >> com.m_nBit;
	}
	if(nTempValue == 0 || nTempValue == 1)
	{
		*pValue = nTempValue;
		return true;
	}
	else
	{
		return false;
	}

}

bool SMCChillerDNetDriver::readAlarm(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
	int ChannelNum = nChannelNum - 100;
	int inputBytes = m_deviceNet->getIBytesSize(m_macID);
	char buffer[inputBytes];
	memset(buffer, 0, inputBytes);
	m_deviceNet->readByte(m_macID, buffer);

	unsigned int nTempValue = 0;

	int nbyte = 10 + (ChannelNum / 8);
	int nBit = ChannelNum % 8;
	unsigned int movebit = 1 << nBit;
	unsigned int temp = ((unsigned int)buffer[nbyte]) & movebit;
	nTempValue = temp >> nBit;

	if(nTempValue == 0 || nTempValue == 1)
	{
		*pValue = nTempValue;
		return true;
	}
	else
	{
		return false;
	}
}

bool SMCChillerDNetDriver::readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo)
{
	Com com = m_Commands[nChannelNum];
	int inputBytes = m_deviceNet->getIBytesSize(m_macID);
	char buffer[inputBytes];
	memset(buffer, 0, inputBytes);
	m_deviceNet->readByte(m_macID, buffer);
	
	unsigned long temp=0;
	double dTempValue = 0;
	temp = (((unsigned long)buffer[com.m_nByte]) & 0xff) + ((((unsigned long)buffer[com.m_nByte+1]) << 8) & 0xff00);
	if(nChannelNum == 3)//read temperature
	{
		dTempValue = temp / 10.0;
	}
	else if(nChannelNum == 4)//read pressure
	{
		dTempValue = temp / 100.0;
	}
	else if(nChannelNum == 5)//read flow
	{
		dTempValue = temp / 10.0;
	}
	else
	{
		return false;
	}
	*pValue = dTempValue;
	return true;
	
}

void SMCChillerDNetDriver::InitChannels(DeviceNode<SMCChillerDNetDriver> *pNode)
{
	pNode->registerWriteCh(1, &SMCChillerDNetDriver::writeInt);
	pNode->registerWriteCh(2, &SMCChillerDNetDriver::writeDouble);
	for(int i=3;i<=5;i++)
	{
		pNode->registerReadCh(i, &SMCChillerDNetDriver::readDouble);
	}
   for(int i=6;i<=10;i++)
   {
   		pNode->registerReadCh(i, &SMCChillerDNetDriver::readInt);
   }
   for(int i=0;i<=32;i++) //read 32bit alarm
   {
	   pNode->registerReadCh(i+100, &SMCChillerDNetDriver::readAlarm);
   }
   pNode->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &SMCChillerDNetDriver::getStatus);
}

void SMCChillerDNetDriver::initDevice()
{
	int nOutBytesSize = m_deviceNet->getOBytesSize(m_macID);
	
	m_pWriteBuffer = new char[nOutBytesSize];
	memset(m_pWriteBuffer, 0, nOutBytesSize);

}

void SMCChillerDNetDriver::init()
{
	DeviceNode<SMCChillerDNetDriver> *pNode = new DeviceNode<SMCChillerDNetDriver>(m_pollInterval, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
	if(!isSimulated())
	{
		InitChannels(pNode);
		initDeviceNet();
		initDevice();
	}	
}

IMPLEMENT_DYNAMIC(SMCChillerDNetDriver, IODevice )
BEGIN_MSG_MAP(SMCChillerDNetDriver, IODevice )
    SET_V( init, SMCChillerDNetDriver )
END_MSG_MAP
