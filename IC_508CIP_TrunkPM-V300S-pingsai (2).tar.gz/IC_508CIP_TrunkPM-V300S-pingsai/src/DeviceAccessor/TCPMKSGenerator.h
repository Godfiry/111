/********************************************************************
** Copyright (c) 2018, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: TCPMKSGenerator.cpp
** Description: Product Specification 400KHz,1.5KW,Pulsing RF Generator MKS Model Number EDGE 15R40A-D02
* 		Port:11235 or 11236
*
** Release: 1.1
** Modification history:
** 					2022-6-19   weizd create
**
*********************************************************************/
#ifndef TCPMKSGENERATOR_H_
#define TCPMKSGENERATOR_H_

#include "TCPDevice.h"
#include "IntTypeInfo.h"
#include "DoubleTypeInfo.h"
#include "StringTypeInfo.h"
#include "DeviceNode.h"
#include <iostream>
#include <string.h>
#ifdef IAP4_0
using namespace IAP::IO;
#endif
using namespace std;


class TCPMKSGenerator:public TCPDevice
{
	DECLARE_DYNAMIC(TCPMKSGenerator)
	DECLARE_MSG_MAP

public:
	TCPMKSGenerator();
	virtual ~TCPMKSGenerator();

public://xml
	void init();

public:
	virtual void acceptData();
	virtual bool reconnectDevice();

public://read and write function
	bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
	bool writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo);
	bool writeString(int nChannelNum, std::string strValue, const StringTypeInfo &typeInfo);
	bool writeRawCommand(int nChannelNum, std::string strValue, const StringTypeInfo &typeInfo);
	bool readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo);
	bool readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);
	virtual std::string getDeviceName();

protected:
	void flush();
	void parseReply();
	void sendCommandOnly(const std::string &strCommand);
	bool sendCommand(std::string strCommand, int nTimeOut);
	std::string readCommand(std::string strCommand);
	void InitChannels(DeviceNode<TCPMKSGenerator> *pNode);
	void initDevice();
	void setMaxFreq(std::string freq);
	void setReadTimeOutMS(int time);  //add by wzd 1.1.33_HotFixed

private:
	typedef struct
	{
		int m_nCmdType;
		std::string m_strCmd;
		int m_nCmdValueDeal;
	}Com;
	static const std::string m_strCR;
	static const std::string m_strReadCR;
	static Com m_Commands[];

	bool m_bWaiting;
	bool m_bReadCmd;
	std::string m_strResponse;
	std::string m_strReadError;
	int m_nReadTimeOutMS;

	double m_dPulseFrequency;
	double m_dPulseDuty;
	std::string m_strMaxFreq;

};

#endif /*TCPMKSGENERATOR_H_*/
