#include "XmlGetter.h"
#include "Converter.h"

using namespace std;

XmlGetter::XmlGetter()
{
}

XmlGetter::~XmlGetter()
{
}

bool XmlGetter::isNamespaceExist(const std::string& strPath)//[wangyk 1.2.7HotFix RC02]
{
    ManagedObject *pObj = NULL;
    try
    {
        pObj = ObjectManager::getInstance()->getObject(strPath);
        return true;
    }
    catch(...)
    {
        string strErr="Get obj failed. Path("+strPath+") not exist.";
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR,strErr);
        return false;
    }
}
