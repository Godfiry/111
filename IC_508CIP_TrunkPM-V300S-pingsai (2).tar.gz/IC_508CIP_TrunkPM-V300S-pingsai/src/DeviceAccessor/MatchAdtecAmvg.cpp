/********************************************************************
** Copyright (c) 2020, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MatchAdtecAmvg.h
** Description:
** Release: 1.1
** Modification history:
** 					2020-2-7   zhangyy create
**
*********************************************************************/

#include "MatchAdtecAmvg.h"
#include "DeviceManager.h"
#include "ObjectManager.h"
#include "Converter.h"
#include "StrTool.h"
#include "Hex.h"
#include <iostream>
#include <sys/time.h>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std;

MatchAdtecAmvg::Cmd MatchAdtecAmvg::m_commands[] = {{0, ""}, //0 Reserved
									{0, "M",     0}, //1 (CH,value)Manual
									{0, "L",     0}, //2 Auto
									{1, "P",     0}, //3 Store
									{1, "G",     0}, //4 Recall
									{1, "$APGR", 0}, //5 Set C1  
									{1, "$APGR", 0}  //6 Set C2 
};

MatchAdtecAmvg::ReadCmd MatchAdtecAmvg::m_readCommands[] = {
									{4, "S3",    2, 56, 14},//7.Get Manual/Auto
									{5, "$APRR", 3, 12, 4}, //8.Get C1
									{8, "$APRR", 3, 12, 4}, //9.Get C2
									{40,"S3",    3, 56, 14},//10.Get Vdc
									{3, "R46",   4, 8, 4},  //11.Get Vdc_MUL
									{3, "R47",   4, 8, 4},  //12.Get Vdc_DIV
									{43,"S3",    3, 56, 14},//13.Get Vpp
									{3, "R48",   4, 8, 4},  //14.Get Vpp_MUL
									{3, "R49",   4, 8, 4}   //15.Get Vpp_DIV
};

MatchAdtecAmvg::MatchAdtecAmvg():SerialDevice(200, "\x0D")
{
	m_nReadTimeOut = 10;//1s
	m_nPreC1 = 0;
	m_nPreC2 = 0;
}

MatchAdtecAmvg::~MatchAdtecAmvg()
{

}

bool MatchAdtecAmvg::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
	Cmd cmd = m_commands[nChannelNum];
	string strMsg = "";
	string strHexValue = "";
	if(cmd.nType == 0)
	{
		strMsg = m_commands[nChannelNum + nValue].strCmd;
	}
	else if(cmd.strCmd == "P" ||cmd.strCmd == "G" )
	{
		strHexValue = Hex::hexToString(nValue);
		strMsg = cmd.strCmd + strHexValue;
	}
	else 
	{
		if(nChannelNum == 5) //Set C1
		{
			m_nPreC1 = nValue;
			strHexValue = Hex::hexToString(m_nPreC1,3)+Hex::hexToString(m_nPreC2,3);
			strMsg = cmd.strCmd + strHexValue;
		}
		else if(nChannelNum == 6) //Set C2
		{
			m_nPreC2 = nValue;
			strHexValue = Hex::hexToString(m_nPreC1,3)+Hex::hexToString(m_nPreC2,3);
			strMsg = cmd.strCmd + strHexValue;
		}
	}
	strMsg = StrTool::toUpper(strMsg);
	sendCommandOnly(strMsg); //For Response is None;
	//cout<<"writeInt send command = "<<strMsg<<endl;
	return true;
}

bool MatchAdtecAmvg::writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
	Cmd cmd = m_commands[nChannelNum];
	string strMsg = "";
	string strHexValue = "";
	int nValue = (int)dValue;
	if(cmd.strCmd == "P" ||cmd.strCmd == "G" )
	{
		strHexValue = Hex::hexToString(nValue);
		strMsg = cmd.strCmd + strHexValue;
	}
	else 
	{
		if(nChannelNum == 5) //Set C1
		{
			m_nPreC1 = (int)(dValue*10);
			strHexValue = Hex::hexToString(m_nPreC1,3)+Hex::hexToString(m_nPreC2,3);
			strMsg = cmd.strCmd + strHexValue;
		}
		else if(nChannelNum == 6) //Set C2
		{
			m_nPreC2 = (int)(dValue*10);
			strHexValue = Hex::hexToString(m_nPreC1,3)+Hex::hexToString(m_nPreC2,3);
			strMsg = cmd.strCmd + strHexValue;
		}
	}
	strMsg = StrTool::toUpper(strMsg);
	sendCommandOnly(strMsg); //For Response is None;
	//cout<<"writeDouble send command = "<<strMsg<<endl;
	return true;
}

bool MatchAdtecAmvg::readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
	ReadCmd readCmd = m_readCommands[nChannelNum-7];
	int nTempValue,nTempValue2;
	std::string strResult = getFixCommandResult(readCmd.strCmd, m_nReadTimeOut, readCmd.nCorrectResponseLen, readCmd.nRetryTime);
	if(CheckValidity(strResult,readCmd.strCmd))
	{
		if(nChannelNum == 7)
		{
			sendCommandOnly("SP"); //Send SP[CR] to stop the response
			nTempValue = SubAndConvert(strResult, readCmd.nSubStartPos, readCmd.nSubLength );
			nTempValue2 = (nTempValue >> 7) & 0x0001;//nTempValue = 80 means Bit7 =1,Bit0 =0
			if(nTempValue2)//1 == Manual
			{
				*pValue = 0;//IO config = Manual
			}
			else//0 == Auto
			{
				*pValue = 1;//IO config = Auto
			}
		}
		if(nChannelNum == 8 || nChannelNum == 9)
		{
			nTempValue = SubAndConvert(strResult, readCmd.nSubStartPos, readCmd.nSubLength );
			*pValue = nTempValue;
		}
			return true;	
	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "Adtec Match send "+readCmd.strCmd +" again.");
		std::string strResultAgain = getFixCommandResult(readCmd.strCmd, m_nReadTimeOut, readCmd.nCorrectResponseLen, readCmd.nRetryTime);
		if(CheckValidity(strResultAgain,readCmd.strCmd))
		{
			if(nChannelNum == 7)
			{
				sendCommandOnly("SP"); //Send SP[CR] to stop the response
				nTempValue = SubAndConvert(strResultAgain, readCmd.nSubStartPos, readCmd.nSubLength );
				nTempValue2 = (nTempValue >> 7) & 0x0001;//nTempValue = 80 means Bit7 =1,Bit0 =0
				if(nTempValue2)//1 == Manual
				{
					*pValue = 0;//IO config = Manual
				}
				else//0 == Auto
				{
					*pValue = 1;//IO config = Auto
				}
			}
			if(nChannelNum == 8 || nChannelNum == 9)
			{
				nTempValue = SubAndConvert(strResultAgain, readCmd.nSubStartPos, readCmd.nSubLength );
				*pValue = nTempValue;
			}
			return true;
		}
	    else
		{
			throw IOException("Send read command = "+readCmd.strCmd +", Unknown read back : " + strResultAgain);
		}
	}
}

bool MatchAdtecAmvg::readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo)
{
	ReadCmd readCmd = m_readCommands[nChannelNum-7];
	string strRequestCmd = readCmd.strCmd;//modify
	int nTempValue;
	std::string strResult = getFixCommandResult(strRequestCmd, m_nReadTimeOut, readCmd.nCorrectResponseLen, readCmd.nRetryTime);
	if(CheckValidity(strResult,strRequestCmd))
	{
		if(nChannelNum == 8 || nChannelNum == 9)
		{
			nTempValue = SubAndConvert(strResult, readCmd.nSubStartPos, readCmd.nSubLength );
			*pValue = (double)nTempValue/10;
		}
		return true;	
	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "Adtec Match send "+strRequestCmd +" again.");
		std::string strResultAgain = getFixCommandResult(strRequestCmd, m_nReadTimeOut, readCmd.nCorrectResponseLen, readCmd.nRetryTime);

		if(CheckValidity(strResultAgain,strRequestCmd))
		{
			if(nChannelNum == 8 || nChannelNum == 9)
			{
				nTempValue = SubAndConvert(strResultAgain, readCmd.nSubStartPos, readCmd.nSubLength );
				*pValue = (double)nTempValue/10;
			}
			return true;
		}
	    else
		{
			throw IOException("Send read command = "+strRequestCmd +", Unknown read back : " + strResultAgain);
		}
	}
}

bool MatchAdtecAmvg::CheckValidity(std::string strSource, std::string strKeyCommand)
{
	if(strSource.find(strKeyCommand,0) != string::npos && strSource.find("\x0D",0) != string::npos)
	{
		return true;
	}
	else
	{
		return false;
	}
}

int MatchAdtecAmvg::SubAndConvert(std::string strSource, int nSubStartPos, int nSubLength)
{
	std::string strTempValue = strSource.substr(nSubStartPos, nSubLength);
	int nTempValue = 0;
	if(!Converter::stringToInt(nTempValue, strTempValue, std::hex))
	{
		throw IOException("read back is not a valid hexadecimal int value" + strTempValue);
	}
	return nTempValue;
}

bool MatchAdtecAmvg::readDCBias(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo)
{
	
	ReadCmd readVDC = m_readCommands[nChannelNum-7];
	ReadCmd readMUL = m_readCommands[nChannelNum-6];
	ReadCmd readDIV = m_readCommands[nChannelNum-5];
	int nTempVDC, nTempMUL, nTempDIV;
	std::string strVDCResult = getFixCommandResult(readVDC.strCmd, m_nReadTimeOut, readVDC.nCorrectResponseLen, readVDC.nRetryTime);
	if(CheckValidity(strVDCResult,readVDC.strCmd))
	{
		sendCommandOnly("SP"); //Send SP[CR] to stop the response of S3 command
		std::string strMULResult = getFixCommandResult(readMUL.strCmd, m_nReadTimeOut, readMUL.nCorrectResponseLen, readMUL.nRetryTime);
		usleep(120*1000); //Interval time = 120ms
		std::string strDIVResult = getFixCommandResult(readDIV.strCmd, m_nReadTimeOut, readDIV.nCorrectResponseLen, readDIV.nRetryTime);
		if(CheckValidity(strMULResult,readMUL.strCmd) && CheckValidity(strDIVResult,readDIV.strCmd))
		{
			nTempVDC = SubAndConvert(strVDCResult, readVDC.nSubStartPos, readVDC.nSubLength );
			nTempMUL = SubAndConvert(strMULResult, readMUL.nSubStartPos, readMUL.nSubLength );
			nTempDIV = SubAndConvert(strDIVResult, readDIV.nSubStartPos, readDIV.nSubLength );
		}
		else
		{
			throw IOException(getDeviceName() + ": Match got incorrect readback. Vdc_MUL = " + strMULResult +"Vdc_DIV = "+ strDIVResult);
		}
		if(nChannelNum == 13)//Vpp need divide 2
		{
			*pValue = (double)nTempVDC *0.5*nTempMUL/nTempDIV;	
		}
		if(nChannelNum == 10)
		{
			if(nTempVDC & 0x800)
			{
				nTempVDC = nTempVDC - 4096;
			}
			*pValue = (double)nTempVDC *nTempMUL/nTempDIV;
		}
			//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "Adtec Match got Vdc = "+ Converter::convertToString(*pValue));
			return true;	
	}
	else
	{
		SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "Adtec Match send "+readVDC.strCmd +" again.");
		std::string strVDCResultAgain = getFixCommandResult(readVDC.strCmd, m_nReadTimeOut, readVDC.nCorrectResponseLen, readVDC.nRetryTime);
		if(CheckValidity(strVDCResultAgain,readVDC.strCmd))
		{
			sendCommandOnly("SP"); //Send SP[CR] to stop the response of S3 command	
			std::string strMULResultAgain = getFixCommandResult(readMUL.strCmd, m_nReadTimeOut, readMUL.nCorrectResponseLen, readMUL.nRetryTime);
			usleep(120*1000); //Interval time = 120ms
			std::string strDIVResultAgain = getFixCommandResult(readDIV.strCmd, m_nReadTimeOut, readDIV.nCorrectResponseLen, readDIV.nRetryTime);
			if(CheckValidity(strMULResultAgain,readMUL.strCmd) && CheckValidity(strDIVResultAgain,readDIV.strCmd))
			{
				nTempVDC = SubAndConvert(strVDCResultAgain, readVDC.nSubStartPos, readVDC.nSubLength );
				nTempMUL = SubAndConvert(strMULResultAgain, readMUL.nSubStartPos, readMUL.nSubLength );
				nTempDIV = SubAndConvert(strDIVResultAgain, readDIV.nSubStartPos, readDIV.nSubLength );
			}
			else
			{
				throw IOException(getDeviceName() + ": Match got incorrect readback again!!! Vdc_MUL = " + strMULResultAgain +"Vdc_DIV = "+ strDIVResultAgain);
			}
			if(nChannelNum == 13)//Vpp need divide 2
			{
				*pValue = (double)nTempVDC *0.5*nTempMUL/nTempDIV;	
			}
			if(nChannelNum == 10)
			{
				if(nTempVDC & 0x800)
				{
					nTempVDC = nTempVDC - 4096;
				}
				*pValue = (double)nTempVDC *nTempMUL/nTempDIV;
			}
				//SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "Adtec Match again got Vdc = "+ Converter::convertToString(*pValue));
	 		    return true;		
		}
		else
		{
			throw IOException("Send S3 to read Vdc get unknown read back : " + strVDCResultAgain);
		}
	}
}

void MatchAdtecAmvg::InitChannels(DeviceNode<MatchAdtecAmvg> *pNode)
{
	pNode->registerWriteCh(1,&MatchAdtecAmvg::writeInt);
	for(int i=3; i<=6; ++i)
	{
		pNode->registerWriteCh(i,&MatchAdtecAmvg::writeInt);
	}
	for(int i=7; i<= 9; ++i)
	{
		pNode->registerReadCh(i,&MatchAdtecAmvg::readInt);
	}
	pNode->registerReadCh(10,&MatchAdtecAmvg::readDCBias);// read Vdc
	pNode->registerReadCh(13,&MatchAdtecAmvg::readDCBias);// read Vpp
	pNode->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &MatchAdtecAmvg::getStatus);//added by mujy [v1.0.8]

}
void MatchAdtecAmvg::initDevice()
{
	cout<<"Start Scan Adtec Match...."<<endl;
	int nTemp;
	try
	{
		readInt(8,&nTemp,IntTypeInfo()); //read C1
	}
	catch(exception &ex)
	{
		cout<<"Scan Adtec Match failed. Communication abnormal!"<<endl;
		throw;
	}
	cout<<"Scan Adtec Match Successfully...."<<endl;

}

void MatchAdtecAmvg::init()
{
    DeviceNode<MatchAdtecAmvg> *pNode = new DeviceNode<MatchAdtecAmvg>(m_pollPeriod,this);
    DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
    if(!isSimulated())
   	{
   	    InitChannels(pNode);
   	    initDevice();
    }
}

string MatchAdtecAmvg::getDeviceName()
{
	return __FILE__;
}

IMPLEMENT_DYNAMIC(MatchAdtecAmvg, SerialDevice )
BEGIN_MSG_MAP(MatchAdtecAmvg, SerialDevice )
    SET_V( init, MatchAdtecAmvg )
END_MSG_MAP
