#ifndef AZMOTOR_H_
#define AZMOTOR_H_
#include "SerialDevice.h"
#include "DeviceNode.h"
#include "IntTypeInfo.h"
#include <iostream>
#include "ReadOnlyInt.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class AZMotor : public SerialDevice
{
	DECLARE_DYNAMIC(AZMotor)	
	DECLARE_MSG_MAP
	private:
		char m_writeCmd[8];
		char m_readCmd[8];//add by songpan 20200110
		static const int RESP_LEN = 80;//add by songpan 20200110
		int m_pollPeriod;
		//add by songpan 20200115
		char m_regWriteAddress[4];//old:3

	protected:
		void WriteToMachien(const std::string &strCmd);//added by wangyk 20251225 [v1.8.1] 
		bool testMsg(int nChannelNum, string strValue, const StringTypeInfo &typeInfo);//added by wangyk 20251225 [v1.8.1]
		void calCRCAndSendCommand(char* arrCmd);//added by wangyk 20251225 [v1.8.1]
		void initDevice();
		void initChs(DeviceNode<AZMotor> *node);
		unsigned short calculateLRC(char* buffer,int len);
		void clearZero();	
	
	public:
		AZMotor();
		virtual ~AZMotor();
		bool writeInt(int channelNum,int value,const IntTypeInfo &typeInfo);
		//add by songpan 20200110
		bool writeAbsPos(int channelNum,double value,const DoubleTypeInfo &typeInfo);//added by wangyk 20251225 [v1.8.1]
		bool readDouble(int channelNum,double *value,const DoubleTypeInfo &typeInfo);
		
		void init();

};
#endif /*AZMOTOR_H_*/
