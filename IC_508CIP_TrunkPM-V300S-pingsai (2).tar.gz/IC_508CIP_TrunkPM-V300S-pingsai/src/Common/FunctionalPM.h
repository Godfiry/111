/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: FunctionalPM.h
** Description: 
** Release: 
** Modification history: 
**                     2009-12-09   LiJuanjuan create
**                    2025-08-05   taohao[v1.5.0_HotFix] modify for obtain the recipe from the memory
**                                 Use from AppRecipeManager management sessions and recipes instead
***************************************************************************/
#ifndef FUNCTIONALPM_H_
#define FUNCTIONALPM_H_

#include "Chamber.h"
#include "FunctionalProcessInterface.h"
#include "BlockingAlarm.h"
#include "NonBlockingAlarm.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "AbortException.h"
#endif
#include "Recovery.h"
#include "ExecRcpHandler.h"
#include "ReadWriteDouble.h"
#include "CounterTimerMs.h"
#include "TransferOperationInfo.h"
#include "XferStsInfo.h"
#include "XferAnmInfo.h"
#include "SlotInfo.h"
#include "MaterialIdInfo.h"
#include "LotIdInfo.h"
#include "SlotMapInfo.h"
#include "CounterTimer.h"
#include "CheckItem.h"
#include "AppRecipeManager.h"
#include "CheckItemControlBySequence.h" //add by zhangpf[v1.6.6]
#include "XmlGetter.h" //add by zhangpf[v1.6.6]
#ifdef IAP4_0
using namespace IAP::ALARM;
using namespace IAP;
using namespace IAP::RECIPE;
using namespace IAP::IO;
using namespace IAP::CONDITION;
#endif
class FunctionalPM:public Chamber, public FunctionalProcessInterface
{
	DECLARE_DYNAMIC( FunctionalPM )
	DECLARE_MSG_MAP
	DECLARE_SERVICEINFO_LIST
	
	public:		
		class PrepChamb : public Service
		{
			DECLARE_DYNAMIC_SERVICE(PrepChamb)
			
			public:				
				void execute();
		};
		
		class JobStartCondition : public Service //[wangyk 1.1.60]
		{
			DECLARE_DYNAMIC_SERVICE(JobStartCondition)
			public:
				void execute();
		};

		class JobEndCondition : public Service
		{
			DECLARE_DYNAMIC_SERVICE(JobEndCondition)
			public:
				void execute();
		};

		class PrepareForProcessingMaterial : public Service
		{
			DECLARE_DYNAMIC_SERVICE(PrepareForProcessingMaterial)
			
			private:
				ExecRcpHandler m_rcpHandler;
				
			public:
				void execute();
		};
			
		class ProcessMaterial : public Service
		{
			DECLARE_DYNAMIC_SERVICE(ProcessMaterial)
				
			public:
				void execute();
		};

		class CycleProcessMaterial : public Service //added by chensc [1.1.49]
		{
			DECLARE_DYNAMIC_SERVICE(CycleProcessMaterial)

			public:
				void execute();
		};

		class TotalCycleProcess : public Service //added by chensc [1.1.49]
		{
			DECLARE_DYNAMIC_SERVICE(TotalCycleProcess)

			public:
				void execute();
		};

		struct WaferInfor
		{
			public:
				string strLotID;
				string strWaferName;
				string strRecipeName;
		};

	public:
		FunctionalPM();
		virtual ~FunctionalPM();

	public://xml config
		void setCTCIP(const string &strIPAddress);
		void addDisableCheckItemBeforeSyc(const std::string &path);

	public://override
		virtual void make();
		virtual void initialize();
		virtual void startup();

		virtual double getTotalProcessTime();
	public://service
		virtual void call_PrepChamb(int nPort);
		virtual void call_JobStartCondition(string strProcessRecipeName);//[wangyk 1.1.60]
		virtual void call_JobEndCondition(string strProcessRecipeName);//[wangyk 1.1.60]
		
		virtual void do_PrepChamb(int nPort);
		virtual void do_JobStartCondition(string strProcessRecipeName);//[wangyk 1.1.60]
		virtual void do_JobEndCondition(string strProcessRecipeName);//[wangyk 1.1.60]
				
        virtual bool call_PrepareForProcessingMaterial();
		virtual bool call_ProcessMaterial();
		virtual void call_CycleProcessMaterial(const std::string &strRecipeID,int cycle); //added by chensc [1.1.49]
		virtual void call_TotalCycleProcess(const std::string &strRecipeID,int cycle);//added by chensc [1.1.49]

        virtual bool do_PrepareForProcessingMaterial();
		virtual bool do_ProcessMaterial();
		virtual void do_CycleProcessMaterial(const std::string &strRecipeID,int cycle); //added by chensc [1.1.49]
		virtual void do_TotalCycleProcess(const std::string &strRecipeID,int cycle); //added by chensc [1.1.49]

		virtual void do_PrepWfr(int nSlot, int nTransferOperation, int nHandOffMode,int nMatID,string strLotID, string strWaferName);
		virtual int do_CompWfr();
				
	public:
		void do_Wait(double d);
		std::string getProcessRecipeName();
		void setProcessRecipeName(const std::string &s);

	protected://for override
		virtual void buildAlarms();
		virtual void buildConditions();
		virtual void buildDataItems();
		virtual void initConditionsAndInterlocks();
		virtual void registerDependentObjects();
		virtual void registerObjects();
		virtual void connectDependentObjects();
		virtual void completeReceivingMaterial(int i);
		virtual void completeSendingMaterial(int i);

		virtual void goToPrepareChamber();
		virtual void goToTransferPosition();
		virtual void goToCompleteWaferPosition();
		virtual bool isAtProcessPosition();
		virtual bool isAtTransferPosition();

		virtual void processTheRecipe();
		virtual void processTheRecipeStep(double d);
		virtual void extractRecipeParameters();
		virtual void goToProcessPosition();
		virtual void clearProcessParam();
		virtual void verifyRecipeParameters();

	protected:
		std::string m_shortName;

		std::vector<ReadWriteInt*> m_slotOccupancy;
		std::vector<ReadWriteInt*> m_slotWfr;
		std::vector<ReadWriteString*> m_slotLotId;
		std::vector<ReadWriteString*> m_slotWaferName;

		ReadWriteInt *m_pProcessTheRecipeOffOn;//added by mujy [V1.0.0.2]
		ReadWriteInt *m_pMonitorEPDOffOn;//added by guojin[1.1.43]
		//BlockingAlarm *m_slotValveNotOpenAlarm;
		BlockingAlarm *m_pSlotValveNotCloseAlarm;
		
		ReadWriteInt *m_slotValveStatus;
		AppConditionPtr m_slotValveIsOpen;
		AppConditionPtr m_slotValveIsClosed;
		ReadWriteInt *m_sendReceiveStatus;

		ReadWriteString *m_pRcpName;

		int m_nSlotNumber;
		int m_nTransferOperation;
		int m_nWaferID;
		int m_nHandOffMode;//added by chensc[1.1.53]
		string m_strLotID;
		string m_strWaferName;

		WaferInfor m_currentWaferInfor;
		CounterTimer *m_pDoubleRunCheckTimer;
		ReadWriteDouble *m_pDoubleRunCheckTimeLeft;

    private:
        BlockingAlarm *m_pVerifyRecipeParameterFailed;

        std::string m_strProcessRecipeName;
        CounterTimerMs *m_pProcessTimer;
		ReadWriteDouble *m_pElapsedProcessTime;

		ServicePtr<PrepChamb> m_sPrepChamb;
		ServicePtr<JobStartCondition> m_sJobStartCondition;//[wangyk 1.1.60]
		ServicePtr<JobEndCondition> m_sJobEndCondition;//[wangyk 1.1.60]
		ServicePtr<PrepareForProcessingMaterial> m_sPrepareForProcessingMaterial;
		ServicePtr<ProcessMaterial> m_sProcessMaterial;
		ServicePtr<CycleProcessMaterial> m_sCycleProcessMaterial; //added by chensc [1.1.49]
		ServicePtr<TotalCycleProcess> m_sTotalCycleProcess; //added by chensc [1.1.49]

		
		WaferInfor m_lastWaferInfo;
		
		BlockingAlarm *m_pDoubleRunAlarm;

		string m_strCTCIPAddress;
		std::vector<CheckItem*> m_pDisableCheckItemBeforeSyc;
};

#endif /*FUNCTIONALPROCESSMODULE_H_*/
