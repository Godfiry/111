/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: DNSS5136.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2008-5-17   LiJuanjuan create
**      
*********************************************************************/
#ifndef DNSS5136_H_
#define DNSS5136_H_

#include "DeviceNet.h"
#include "ss5136dn_lib.h"
#include "ss5136dn_pci.h"

extern int dni;
extern DNS_SCANNER_CFG ScannerCfg;
extern DNS_DEVICE_CFG DeviceCfg;
extern cardmemel * CardMemHead, * curmemp;	
extern DNS_DEVICE_CFG * DevicesList[64];

class DNSS5136:public DeviceNet
{
	public:
		DNSS5136(const std::string &devName, int masterMacId, int baudRate);
		virtual ~DNSS5136();	
		
		virtual void loadDevice(); 	
		virtual bool addDevice(int inmac); 
		virtual int getIBytesSize(int inmac);
		virtual int getOBytesSize(int inmac);
		virtual bool readByte(int macid, char *buffer);
		virtual bool writeByte(int inmac, char *byte);
		virtual bool readBit(int inmac, int channel, bool *bit);
		virtual bool writeBit(int inmac, int channel, bool bit);
		virtual bool writeExplicit(int macid, char *buffer, int service, int Class, int instance, int datasize);
		virtual bool readExplicit(int macid, char *bufferIn, int service,int Class, int instance, int datasizeIn, char *bufferOut, int *datasizeOut);
		virtual int readStatus(int nMacId);//added by mujy[v1.0.8]
};

#endif /*DNSS5136_H_*/
