/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AEICGeneratorDriver.cpp
** Description:  
** Release: 1.1
** Modification history: 
**                     2015-4   gaozl create
**      
*********************************************************************/

#include "AEICGeneratorDriver.h"
#include <string.h>
#include "DeviceManager.h"
#include <iostream>
#include <sys/time.h>
#include <sstream>
#include "Converter.h"
#include "SysLogger.h"
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif
using namespace std;

AEICGeneratorDriver::AEICGeneratorDriver():SerialDevice(20,"")
{
    m_rampupw = 0;
    m_rampdownw = 0;
    m_rampuptime = 0;
    m_rampdowntime = 0;
    m_multi = 1.0; //HaloMultiple     add by gaozl 20151010
    ack[0] = (char)0x06;
} 

AEICGeneratorDriver::~AEICGeneratorDriver()
{
}
AEICGeneratorDriver::Com AEICGeneratorDriver::m_commands[] =   { {3, 0x01, 4}, // 0 setPowerOnOff
                                            {9, 0x1A, 4}, //1 setpulseEnable
                                            {5, 0x08, 4}, //2 setPower
                                            {5, 0x60, 4}, //3 setPulseDuty
                                            {7, 0x5D, 4}, //4 setPulseFreq
                                            {3, 0xA5, 5}, //5 getFwdPower
                                            {3, 0xA6, 5}, //6 getreflectPower
                                            {3, 0xC1, 7}, //7 getPulseFreq
                                            {3, 0xC4, 5}, //8 getPulsDuty
                                              {4, 0x0E, 4}, //9 set control mode
                                            {3, 0x9B, 4}, //10 read mode

                                          //add by gaozl
                                            {9, 0x1A, 4}, //11 set wave mode(8) 0-CW/1-Pulse
                                            {6, 0x20, 4}, //12 set CEX
                                            {5, 0xAC, 7}, //13 get wave mode(8): 0-CW/1-Pulse
                                            {4, 0x84, 5}, //14 get CEX
                                            {3, 0xA2, 7}, //15 OverHeat (1 == alarm )
                                            {5, 0xAC, 7}, //16 read PulseSyncTimeDelay (us)
                                            {9, 0x1A, 4}, //17 set PulseSyncTimeDelay (us)
                                            {5, 0xAC, 7}, //18 read PulseMode (0:Master mode;  1:Slave mode)
                                            {9, 0x1A, 4},  //19 set PulseMode (0:Master mode;  1:Slave mode)
                                          //add by wz
                                            {9, 0x1F, 4},//20 set point ramping configuration

                                            {4, 48, 4},//21 reserve for the simulator channel
                                            {7, 61, 4},//22 reserve for the simulator channel
                                            {3, 148, 4},//23reserve for the simulator channel
                                            {3, 161, 7},//24reserve for the simulator channel

                                            {4, 48, 4},//25 set fixd or variable frequency mode
                                            {7, 61, 4},//26 set fixd frequency
                                            {3, 148, 4},//27 report fixd or variable frequency mode
                                            {3, 161, 7},//28 report fixd frequency
                                            {3, 0x01, 4}, // 29 setPowerOnOff
                                            {4, 0xDF, 44},

                                            {4, 0x03, 4},  //31setBRFMode
                                            {5, 0x06, 4},  //32setBVCUserlimit
                                            {6, 0x09, 4},//33setBVCRatio
                                            {3, 0x9A, 4},//34ReadBRFMode
                                            {3, 0xA8, 5},//35VDC
                                            {3, 0xAB, 5},//36ReadBVCUserlimit BVCRatio
                                            {4, 0xAB, 5}, //37ReadBVCRatio
                                            {5, 0x08, 4}, //38 setVoltage
                                            {5, 0x04, 4},  //39 set power limit
                                            {3, 0xA9, 5}, //40 read power limit
                                            {9, 0x1A, 4},//41 set slave duty cycle  add by songpan 20200530
                                            {5, 0xAC, 7},//42 read slave duty cycle add by songpan 20200530
                                            {5, 0x05, 4}, //43 set reflected power limit
                                            {3, 0xAA, 5}  //44 read reflected power limit
};
                                                                                        

bool AEICGeneratorDriver::sendCommand(char *msg, char *response, int msg_timeout,int length)
{
    //sendCommandOnly(msg,MESS_LEN);
    //getResultOnly(response,length+1,msg_timeout);
     string s1=std::string(msg,length);
     //cout<<s1<<endl;
     string s2=getCommandResult(s1,m_timeOut);
     
     strcpy(response,s2.c_str());
    if(response[0] != 0x06)
    {
        cout<<"sendCommand response "<<hex<<(int)response[0]<<" "<<(int)response[1]<<" "<<(int)response[2]<<" "<<(int)response[3]<<" "<<(int)response[4]<<endl;
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": response[0] is :" + Converter::convertToString(response[0]));
        throw IOException("Send packet's verification is wrong");
    }
    else if(response[3] != 0x00)
    {
        cout<<"sendCommand response "<<hex<<(int)response[0]<<" "<<(int)response[1]<<" "<<(int)response[2]<<" "<<(int)response[3]<<" "<<(int)response[4]<<endl;
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": response[3] is :" + Converter::convertToString(response[3]));
        throw IOException("Response(CSR) codes was not accepted");
    }
      //sendCommandOnly(ack,1); 
   return true;
}

bool AEICGeneratorDriver::sendCommandAck(char *msg, char *response, int msg_timeout,int resplen, int msglen)
{
    int ret = getCommandResult(msg, msglen, response, resplen, m_timeOut);
    
    if(response[0] != 0x06 || ret <= 0)
    {
        cout<<"sendCommand response "<<hex<<(int)response[0]<<" "<<(int)response[1]<<" "<<(int)response[2]<<" "<<(int)response[3]<<" "<<(int)response[4]<<endl;
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": response[0] is :" + Converter::convertToString(response[0]));
        throw IOException("Send packet's verification is wrong");
    }
    else if(response[3] != 0x00)
    {
        cout<<"sendCommand response "<<hex<<(int)response[0]<<" "<<(int)response[1]<<" "<<(int)response[2]<<" "<<(int)response[3]<<" "<<(int)response[4]<<endl;
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getName() + ": response[3] is :" + Converter::convertToString(response[3]));
        throw IOException("Response(CSR) codes was not accepted");
    }
   sendCommandOnly(ack,1); 
   return true;
}
bool AEICGeneratorDriver::readCommand(char *msg, char *response, int msg_timeout,int resplen, int msglen)
{
    int ret = getCommandResult(msg, msglen, response, resplen, m_timeOut);

    if(response[0] != 0x06 || ret <=0)
    {
        throw IOException("Send packet's verification is wrong");
    }
     int dtFldsize = (int)response[1] & 0x07;
    int csrcode;
    string s1 = std::string("Get ");

    if(dtFldsize < 7)
    {
        csrcode = (int)response[3]&0xFF ;
        if(dtFldsize < resplen - 4)
        {
            s1 += "wrong response. CSR code is ";
            s1 += Converter::convertToString(csrcode);
            throw IOException(s1);
        }
        if(dtFldsize > resplen - 4)
        {
            s1 += "more bytes of response than expected. Count: ";
            s1 += Converter::convertToString(ret);
            cout<<"In AEICGeneratorDriver: "<<s1<<endl;
            throw IOException(s1);
        }
    }
    else
    {
        dtFldsize = (int)response[3] & 0xFF;
        if(dtFldsize != resplen - 5)
        {
            s1 += "unexpected bytes of response. Count: ";
            s1 += Converter::convertToString(ret);
            cout<<"In AEICGeneratorDriver: "<<s1<<endl;
            throw IOException(s1);
        }
    }


    sendCommandOnly(ack,1);
   return true;
}

bool AEICGeneratorDriver::writeInt(int channelNum, int value, const IntTypeInfo &typeInfo)
{
    Com com = m_commands[channelNum];

    memset(message, 0, MESS_LEN);
        memset(resp, 0, RESP_LEN);
    int tempint =0;
    message[0] = (char)(com.m_type +5);
    switch(com.m_type)
    {
        case 3:
            if(value == 0 )
            {
                message[1] = 0x01;
            }
            if(value == 1 )
            {
                message[1] = 0x02;
            }
            message[2] = message[0]^message[1];
            break;

             case 9:

               if(channelNum == 11)  // set CW
               {
                   message[1] = com.m_cmd;
                   message[2] = 0x08;
                   message[3] = 0x00;
                   message[4] = (char)(0x00 + value);  // 0-CW, 1-Pulse
                   message[5] = 0x00;
                   message[6] = 0x00;
                   message[7] = 0x00;
                   message[8] = message[0]^message[1]^message[2]^message[3]^message[4];
                   break;
               }

               else if(channelNum == 17)  //set PulseSyncTimeDelay (us)
               {
                   message[1] = com.m_cmd;
                   message[2] = 0x04;
                   message[3] = 0x00;
                   tempint = value;

                   message[4] = (int)tempint&0x00ff;
                   message[5] = ((int)tempint>>8)&0x00ff;
                   message[6] = ((int)tempint>>16)&0x00ff;
                   message[7] = ((int)tempint>>24)&0x00ff;
                   message[8] = message[0]^message[1]^message[2]^message[3]^message[4]^message[5]^message[6]^message[7];
                   break;

               }
               else if(channelNum == 19)  //set PulseMode
               {
                   message[1] = com.m_cmd;
                   message[2] = 0x01;
                   message[3] = 0x00;
                   if(value == 0)  //Master Mode
                       message[4] = 0x01;
                   if(value == 1)  //Slave Mode
                       message[4] = 0x02;

                   message[8] = message[0]^message[1]^message[2]^message[3]^message[4];
                   break;

               }
               else if(channelNum == 20)
               {
                        message[1] = com.m_cmd;
                        message[2] = (int)value&0x00ff;
                        message[3] =((int)value>>8)&0x00ff;
                        if(value == 1||value == 0)
                        {
                            message[4] = (int)m_rampupw&0x00ff;
                            message[5] =((int)m_rampupw>>8)&0x00ff;
                            message[6] =(int)m_rampdownw&0x00ff;
                            message[7] =((int)m_rampdownw>>8)&0x00ff;
                        }
                        if(value == 2)
                        {
                           message[4] = (int)m_rampuptime&0x00ff;
                           message[5] =((int)m_rampuptime>>8)&0x00ff;
                           message[6] =(int)m_rampdowntime&0x00ff;
                           message[7] =((int)m_rampdowntime>>8)&0x00ff;
                        }
                        message[8] = message[0]^message[1]^message[2]^message[3]^message[4]^message[5]^message[6]^message[7];
                       break;
               }else if(channelNum == 41)//set slave duty cycle add by songpan 20200530
        {
            message[1] = com.m_cmd;
            message[2] = 0x0B;
            message[3] = 0x00;
            tempint = value*10;
            message[4] = (int)tempint&0x00ff;
                   message[5] = ((int)tempint>>8)&0x00ff;
                   message[6] = ((int)tempint>>16)&0x00ff;
                   message[7] = ((int)tempint>>24)&0x00ff;
                   message[8] = message[0]^message[1]^message[2]^message[3]^message[4]^message[5]^message[6]^message[7];
                   break;
               }
               else
               {
                message[1] = com.m_cmd;
                message[2] = 0x02;
                message[3] = 0x00;
                message[4] = (char)(0x00 +value);
                message[5] = 0x00;
                message[8] = message[0]^message[1]^message[2]^message[3]^message[4]^message[5];
                break;
               }
            
          case 4:
            if (channelNum == 9)
            {
                message[1] = com.m_cmd;
                if(value == 0)
                {
                    message[2] = 0x04;
                }
                if(value == 1)
                {
                    message[2] = 0x02;
                }
                message[3] = message[0]^message[1]^message[2];
                break;
            }
            else if (channelNum == 25) // set fixed or variable frequency mode
            {
                message[1] = com.m_cmd;
                if(value == 0 )
                {
                    message[2] = 0;
                }
                if(value == 1 )
                {
                    message[2] = 0x01;
                }
                message[3] = message[0]^message[1]^message[2];
                break;
            }else if (channelNum == 31)
            {
                message[1] = com.m_cmd;
                if(value == 0 )//20180730 duwenbin 6--->0
                {
                    message[2] = 0x06;
                }
                if(value == 1 )
                {
                    message[2] = 0x07;
                }
                if(value == 2 )
                {
                    message[2] = 0x08;
                }
                message[3] = message[0]^message[1]^message[2];
                break;
            }
            
         case 5:
          message[1] = com.m_cmd;
          tempint = value;

          message[2] = (int)tempint&0x00ff;
          message[3] = ((int)tempint>>8)&0x00ff;
          message[4] = message[0]^message[1]^message[2]^message[3];
          break;        
          
         case 6:  //set CEX
          //message[1] = com.m_cmd;
          if (channelNum == 33)
          {
         message[1] = com.m_cmd;
             message[2] = (int)value&0x00ff;
             message[3] = ((int)value>>8)&0x00ff;
             message[4] = 0x00;
             message[5] = message[0]^message[1]^message[2]^message[3]^message[4];
          }
          else
          {
         message[1] = com.m_cmd;
              message[2] = 0x00;
              tempint = value * 10;
              message[3] = (int)tempint&0x00ff;
              message[4] = ((int)tempint>>8)&0x00ff;
              message[5] = message[0]^message[1]^message[3]^message[4];
          }

          break; 
         
          
           case 7:
          if (channelNum == 4)
          {
              message[1] = com.m_cmd;
              message[2] = (int)value&0x00ff;
              message[3] = ((int)value>>8)&0x00ff;
              message[6] = message[0]^message[1]^message[2]^message[3];
          }
          else if (channelNum == 26) //set fixd frequency
          {
            message[1] = com.m_cmd;
            message[2] = (int)value&0x000000ff;
            message[3] = ((int)value>>8)&0x000000ff;
            message[4] = ((int)value>>16)&0x000000ff;
            message[5] = ((int)value>>24)&0x000000ff;
            message[6] = message[0]^message[1]^message[2]^message[3]^message[4]^message[5];
          }
          break;
    }
          
    return(sendCommandAck(message, resp, m_timeOut, com.m_relen+1, com.m_type));
}

bool AEICGeneratorDriver::writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
    if(channelNum == 21)
    {
        m_rampupw =value;
        return true;
    }
    if(channelNum == 22)
    {
        m_rampdownw =value;
        return true;
    }
    if(channelNum == 23)
    {
        m_rampuptime =value;
        return true;
    }
    if(channelNum == 24)
    {
        m_rampdowntime =value;
        return true;
    }
    Com com = m_commands[channelNum];
    memset(message, 0, MESS_LEN);
    memset(resp, 0, RESP_LEN);
    double tempdouble = value;
    message[0] = (char)(com.m_type +5);
    switch(com.m_type)
    {
       case 5: // setpower
             message[1] = com.m_cmd;
        if(2 == channelNum) //set power
        {
          tempdouble = value * 10 * m_multi; //gaozl modify 20151010
        }
        else if(38 == channelNum)
        {
          tempdouble = value; //duwenbin 20180727
        }
             message[2] = (int)tempdouble&0x00ff;
             message[3] = ((int)tempdouble>>8)&0x00ff;
             message[4] = message[0]^message[1]^message[2]^message[3];
             break;

         case 7:
             message[1] = com.m_cmd;
             message[2] = (int)value&0x00ff;
             message[3] = ((int)value>>8)&0x00ff;
             message[6] = message[0]^message[1]^message[2]^message[3];
             break;
    }
    return(sendCommandAck(message, resp, m_timeOut, com.m_relen+1, com.m_type));
}

bool AEICGeneratorDriver::readInt(int channelNum, int *value, const IntTypeInfo &typeInfo)
{
    Com com = m_commands[channelNum];
    memset(message, 0, MESS_LEN);
    memset(resp, 0, RESP_LEN);
    message[0] = (char)(com.m_type +5);
    message[1] = com.m_cmd;

    if(channelNum == 13) //read CW mode
    {
        message[2] = 0x08;
        message[4] = message[0]^message[1]^message[2];
    }
    else if (channelNum == 14)  //read CEX
    {
        message[2] = 0x00;
        message[3] = message[0]^message[1]^message[2];
    }
    else if (channelNum == 16)  //read PulseSyncTimeDelay
    {
        message[2] = 0x04;
        message[4] = message[0]^message[1]^message[2]^message[3];
    }
    else if (channelNum == 18)  //read PulseMode
    {
        message[2] = 0x01;
        message[4] = message[0]^message[1]^message[2]^message[3];
    }
    else if (channelNum == 36)  //read BVCUserlimit
    {
        //message[2] = 0x00;
        //message[3] = message[0]^message[1]^message[2];
    message[2] = message[0]^message[1];
    }
    else if (channelNum == 37)  //read BVCRatio
    {
        message[2] = 0x01;
         message[3] = message[0]^message[1]^message[2];
    }
    else if (channelNum == 42)  //read slave duty cycle add by songpan 20200530
    {
        message[2] = 0x0B;
        message[4] = message[0]^message[1]^message[2];
    }
    else
    {
        message[2] = message[0]^message[1];
    }
    if (channelNum == 30)  
    {
        *value = 0;
        message[2] = 0x01;
        message[3] = message[0]^message[1]^message[2];
        getCommandResult(message,com.m_type,resp,com.m_relen+1,m_timeOut);
        *value=(int)resp[1] & 0x07;
        if((*value)>1 && (*value)<7)
        {
            for(int i=3;i<(*value)+3;i++)
            {
                //error code
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, Converter::convertToString(i)+":"+Converter::convertToString(((int)resp[i] & 0x00ff)));
            }
        }
        if((*value)==7)
        {
            for(int i=3;i<((int)resp[3] & 0x00ff)+4;i++)
            {
                //error code
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, Converter::convertToString(i)+":"+Converter::convertToString(((int)resp[i] & 0x00ff)));
            }
        }
        return true;
    }
    int temp = 0;
      if(readCommand(message , resp, m_timeOut, com.m_relen+1, com.m_type))
      {
          switch(com.m_type)
          {
              case 3:

                if(10 == channelNum)    //read control mode
                {
                    temp = (int)resp[3]&0x00ff;
                    if(temp == 2)
                    {
                        *value = 1;
                    }
                    if(temp ==4)
                    {
                        *value = 0;
                    }
                    return true;
                }

                else if(15 == channelNum)  //15 overheat alarm
                {
                    temp = (int)resp[4]&0xf;
                    *value = (temp>>3)&0x01;
                    return true;
                }
                else if (channelNum == 27) //report fixd or variable frequency mode
                {
                    temp = (int)(resp[3]&0x00ff);
                    if(temp == 0)
                    {
                        *value = 0;
                    }
                    if(temp ==1)
                    {
                        *value = 1;
                    }
                    return true;
                }
                else if (channelNum == 28) //report fixd frequency
                {
                    //*value = (((((int)(resp[6]& 0x00ff)<<24) & 0xff000000) + ((int)(resp[5]& 0x00ff)<<16) & 0xff0000)
                    //            +((int)(resp[4]& 0x00ff)<<8)&0xff00) +((int)resp[3]&0xff);
                    *value = *(int *)&resp[3];
                    return true;
                    //    {4, 48, 4},//21 set fixd or variable frequency mode
                    //    {7, 61, 4},//22 set fixd frequency
                    //    {3, 148, 4},//23 report fixd or variable frequency mode
                    //    {3, 161, 7}//24 report fixd frequency
                }
                else if(34 == channelNum)
                {
                    *value = (int)resp[3]&0x00ff;
                    return true;
                }
                //else if(35 == channelNum||36 == channelNum)
                else
                {
                    *value = (((int)(resp[4]& 0x00ff)<<8)&0xff00) +((int)resp[3]&0xff);
                    return true;
                }
                /*else
                {
                    *value = (((int)(resp[4]& 0x00ff)<<8)&0xff00) +((int)resp[3]&0xff);
                    return true;
                }*/
              case 4: //read CEX
                  temp = (((int)(resp[4]& 0x00ff)<<8)&0xff00) +((int)resp[3]&0xff);
                if(37 == channelNum)
                {
                    *value = temp;
                    return true;
                }
                  *value = temp / 10;
                  return true;

              case 5: // read CW
                  if(13 == channelNum) // read CW mode
                  {
                       *value = (int)resp[3]&0x00ff;
                       return true;
                  }
                  if(16 == channelNum)  //read PulseSyncTimeDelay
                  {
                      *value = (((int)(resp[6]&0x00ff)<<24)&0xff000000) + (((int)(resp[5]&0x00ff)<<16)&0xff0000)
                        + (((int)(resp[4]&0x00ff)<<8)&0xff00) + ((int)resp[3]&0xff);
                     return true;
                  }
                  if(18 == channelNum)    //read Pulse mode
                  {
                  temp = (int)resp[3]&0x00ff;
                  if(temp == 1)
                   {
                       *value = 0; //Master Mode
                   }
                   if(temp ==2)
                   {
                       *value = 1; //Slave Mode
                   }
                  return true;
              }
                if(42 == channelNum)  //read slave duty cycle add by songpan 20200430
                  {
                    *value  = ((int)(resp[6]<<24)&0xff000000) + ((int)(resp[5]<<16)&0xff0000) + ((int)(resp[4]<<8)&0xff00) + ((int)resp[3]&0xff);
                    *value  = *value/10;
                    /*for(int i =3;i<7;i++)
                    {
                        cout<<"resp["<<i<<"]"<<hex<<(int)resp[i]<<endl;
                    } */
                     return true;
                  }
          }
      }
    return false;
}

bool AEICGeneratorDriver::readDouble(int channelNum,double *value, const DoubleTypeInfo &typeInfo)
{
    Com com = m_commands[channelNum];
    memset(message, 0, MESS_LEN);
    memset(resp, 0, RESP_LEN);
        message[0] = (char)(com.m_type +5);
        message[1] = com.m_cmd;
        message[2] = message[0]^message[1];
    int temp;
      if(readCommand(message , resp, m_timeOut, com.m_relen+1, com.m_type))
      {
        if(5 == channelNum || 6 == channelNum)  //read FwdPower or RefPower
              {
                      temp = (((int)(resp[4]& 0x00ff)<<8)&0xff00) +((int)resp[3]&0xff);
                *value = temp / (10 * m_multi); // gaozl modify 20151010
                      return true;
              }


        else
        {
              *value = (((int)(resp[4]& 0x00ff)<<8)&0xff00) +((int)resp[3]&0xff);
              return true;
        }
      }
    return false;
}

void AEICGeneratorDriver::InitChannels(DeviceNode<AEICGeneratorDriver> *node)
{
    //node->registerWriteCh(0,&AEICGeneratorDriver::writeInt);
    node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &AEICGeneratorDriver::getStatus);
    //node->registerReadCh(0, &SerialDevice::connectStatus);
    node->registerWriteCh(1,&AEICGeneratorDriver::writeInt);
    node->registerWriteCh(2,&AEICGeneratorDriver::writeDouble);
    node->registerWriteCh(3,&AEICGeneratorDriver::writeInt);
    node->registerWriteCh(4,&AEICGeneratorDriver::writeInt);
    node->registerReadCh(5,&AEICGeneratorDriver::readDouble);
    node->registerReadCh(6,&AEICGeneratorDriver::readDouble);
    node->registerReadCh(7,&AEICGeneratorDriver::readInt);
    node->registerReadCh(8,&AEICGeneratorDriver::readInt);
    node->registerWriteCh(9,&AEICGeneratorDriver::writeInt);
    node->registerReadCh(10,&AEICGeneratorDriver::readInt);
    node->registerWriteCh(11,&AEICGeneratorDriver::writeInt);
    node->registerWriteCh(12,&AEICGeneratorDriver::writeInt);
    node->registerReadCh(13,&AEICGeneratorDriver::readInt);
    node->registerReadCh(14,&AEICGeneratorDriver::readInt);
    node->registerReadCh(15,&AEICGeneratorDriver::readInt);
    node->registerReadCh(16,&AEICGeneratorDriver::readInt);//read PulseSyncTimeDelay (us) 
    node->registerWriteCh(17,&AEICGeneratorDriver::writeInt);//set PulseSyncTimeDelay (us) 
    node->registerReadCh(18,&AEICGeneratorDriver::readInt);//read PulseMode 
    node->registerWriteCh(19,&AEICGeneratorDriver::writeInt);//set PulseMode 

    node->registerWriteCh(20,&AEICGeneratorDriver::writeInt);
    node->registerWriteCh(21,&AEICGeneratorDriver::writeDouble);
    node->registerWriteCh(22,&AEICGeneratorDriver::writeDouble);
    node->registerWriteCh(23,&AEICGeneratorDriver::writeDouble);
    node->registerWriteCh(24,&AEICGeneratorDriver::writeDouble);

    node->registerWriteCh(25,&AEICGeneratorDriver::writeInt);
    node->registerWriteCh(26,&AEICGeneratorDriver::writeInt);
    node->registerReadCh(27,&AEICGeneratorDriver::readInt);
    node->registerReadCh(28,&AEICGeneratorDriver::readInt);
    node->registerWriteCh(29,&AEICGeneratorDriver::writeInt);
    node->registerReadCh(30,&AEICGeneratorDriver::readInt);

    node->registerWriteCh(31,&AEICGeneratorDriver::writeInt);
    node->registerWriteCh(32,&AEICGeneratorDriver::writeInt);
    node->registerWriteCh(33,&AEICGeneratorDriver::writeInt);
    node->registerReadCh(34,&AEICGeneratorDriver::readInt);
    node->registerReadCh(35,&AEICGeneratorDriver::readDouble);
    node->registerReadCh(36,&AEICGeneratorDriver::readInt);
    node->registerReadCh(37,&AEICGeneratorDriver::readInt);
    node->registerWriteCh(38,&AEICGeneratorDriver::writeDouble);
    node->registerWriteCh(39,&AEICGeneratorDriver::writeInt);
    node->registerReadCh(40,&AEICGeneratorDriver::readInt);
    node->registerWriteCh(41,&AEICGeneratorDriver::writeInt);//add by songpan 20200530
    node->registerReadCh(42,&AEICGeneratorDriver::readInt);//add by songpan 20200530
    node->registerWriteCh(43,&AEICGeneratorDriver::writeInt);
    node->registerReadCh(44,&AEICGeneratorDriver::readInt);
}
  
void AEICGeneratorDriver::init()
{
    cout<<getName()+"Generator driver init start"<<endl;
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "AEICGeneratorDriver start");
    DeviceNode<AEICGeneratorDriver> *node = new DeviceNode<AEICGeneratorDriver>(200,this);
    DeviceManager::getInstance()->registerNode(m_nodeNum, node);
    if(!isSimulated())
    {
        InitChannels(node);
        char resp[5] = {0};
        char message[4]={0x09,0x0E,0x02,0x05};//set serial communication mode
        char message1[3]={0x08,0x01,0x09};
        try
        {
            sleep(1);
            sendCommand(message, resp, m_timeOut, 5);
            sleep(1);
            memset(resp, 0, 5);
            sendCommandAck(message1, resp, m_timeOut,5, 3);
       }
        catch(const exception &ex)
        {
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "Setting host mode has IO error!!" + ex.what());
        }
    }
    cout<<getName()+"Generator driver end start"<<endl;
    SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, getName() + "AEICGeneratorDriver end");
}

//add by gaozl 20151010
void AEICGeneratorDriver::setHaloMultiple(double multi)
{
    m_multi = multi;
}

IMPLEMENT_DYNAMIC(AEICGeneratorDriver, SerialDevice )
BEGIN_MSG_MAP(AEICGeneratorDriver, SerialDevice )
    SET_V( init, AEICGeneratorDriver )
    SET_D( setHaloMultiple, AEICGeneratorDriver )
END_MSG_MAP

