/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MKSMatch.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-11-17   LiJuanjuan create
**      
*********************************************************************/
#ifndef MKSMATCH_H_
#define MKSMATCH_H_

#include "SerialDevice.h"
#include "DescriptorList.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class MKSMatch:public SerialDevice
{
	DECLARE_DYNAMIC(MKSMatch)	
	DECLARE_MSG_MAP
    
 	private:
		
    
	protected:
		bool sendCommand(std::string command, int timeOut);
		std::string readCommand(std::string command, int timeOut);	
		static DescriptorList m_memList;
    	
	public:
		MKSMatch();
		virtual ~MKSMatch();
};

#endif /*MKSMATCH_H_*/
