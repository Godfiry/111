/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: ATSChiller.cpp
** Description:
** Release: 1.1
** Modification history:
** 					2021-12-03   wzd create
*********************************************************************/
#ifndef GMPOWERDM4MATCHDRIVER_H_
#define GMPOWERDM4MATCHDRIVER_H_

#include <string>
#include "SerialDevice.h"
#include "ControlObject.h"
#include "ReadWriteInt.h"
#include "ReadOnlyInt.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#include "DeviceNode.h"
#ifdef IAP4_0
using namespace IAP::CONTROL;
using namespace IAP::IO;
#endif

using namespace std;



class GmpowerDM4MatchDriver : public SerialDevice
{
	DECLARE_DYNAMIC(GmpowerDM4MatchDriver)
	DECLARE_MSG_MAP

private:

	int m_timeOut;
	int m_resLen;

	char m_writeCmd[8];	//write command array
	char m_readCmd[8];   //read command array
	std::string m_alarmInfo[7];
	static const int RESP_LEN = 80;//the buff length

protected:

	void initChs(DeviceNode<GmpowerDM4MatchDriver> *node);//inint channel
	void initDevice();

public:
	GmpowerDM4MatchDriver();
	virtual ~GmpowerDM4MatchDriver();
	void init();  //init the device
	bool writeInt(int nChannelNum, int nSetTemp, const IntTypeInfo& typeinfo);
	bool readInt(int nChannelNum, int * pValue ,const IntTypeInfo& typeinfo);
};

#endif /* GMPOWERDM4MATCHDRIVER_H_ */
