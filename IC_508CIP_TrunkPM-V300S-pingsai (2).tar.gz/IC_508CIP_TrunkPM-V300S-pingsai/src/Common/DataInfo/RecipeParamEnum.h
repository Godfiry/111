#ifndef RECIPEPARAMENUM_H_
#define RECIPEPARAMENUM_H_

namespace RFOUTPUTMODEENUM
{
	enum RFOutputMode
	{
		Power,
		Voltage
	};
}

namespace VATCTLMODE//added by mujy for PSE V300Gi AutoPressureControl [1.10.0]
{
        enum VATCtlMode
        {
              Position=0,
              Pressure=1,
              PressureLearn=2,
              PressureLearn1=3,
              PressureLearn2=4,
              PressureLearn3=5,
              PressureLearnByPPMode=6,
              PressureLearnByManualPPMode=7
        };
}

#endif /*RECIPEPARAMENUM_H_*/
