/********************************************************************
** Copyright (c) 2020, Beijing NAURA Co.,Ltd.  All rights reserved.
** File name: GaugeHoribaGR300.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2020-10-26   Mujy create
**      
*********************************************************************/
#include "GaugeHoribaGR300.h"

#include "DeviceManager.h"
#include "ConfigException.h"
#include <cmath>
#include <string.h>
#ifdef IAP4_0
using namespace IAP::IO;
#endif

using namespace std;

GaugeHoribaGR300::GaugeHoribaGR300()
{
	m_pollInterval = 300;
	m_dFullScale = 32767;//0x7FFF = 32767 details please see manual

	m_nInBytesSize = 0;
	m_nOutBytesSize = 0;
	
	m_bEnable = false;
	m_dCoefficient = 1.0;
}

GaugeHoribaGR300::~GaugeHoribaGR300()
{
}

bool GaugeHoribaGR300::writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
	int nMaxPressure = typeInfo.getMax();
	char pBuffer[m_nOutBytesSize];
	memset(pBuffer, 0, m_nOutBytesSize);
	int nTempValue =(int)((dValue / nMaxPressure) * m_dFullScale);
	pBuffer[0] = nTempValue & 0xff;
	pBuffer[1] = (nTempValue >> 8) & 0xff;
	return m_deviceNet->writeByte(m_macID, pBuffer);
}

bool GaugeHoribaGR300::readDouble(int nChannelNum, double *pValue,const DoubleTypeInfo &typeInfo )
{	
	int nMax = typeInfo.getMax();
	char pBuffer[m_nInBytesSize];
	memset(pBuffer, 0, m_nInBytesSize);
	m_deviceNet->readByte(m_macID, pBuffer);
	int nTempValue = 0;
	if(nChannelNum == 2)
	{
		if(!(pBuffer[2] & 0x80))
		{
			nTempValue = (pBuffer[1] &0xff) + ((pBuffer[2] << 8) & 0xff00);
		}
	}
	else if(nChannelNum == 3)
	{
		if(!(pBuffer[4] & 0x80))
		{
			nTempValue = (pBuffer[3] &0xff) + ((pBuffer[4] << 8) & 0xff00);
		}
	}
	else
	{
		return false;
	}

	if(nTempValue > m_dFullScale)
	{
		*pValue = nMax;
	}
	else
	{
		double dValue = (((double)nTempValue)/m_dFullScale) * nMax;
		if(m_bEnable == true && nChannelNum == 3 )
		{
			dValue = dValue/2.0;
			if(m_dCoefficient != 1.0)
			{
				dValue = dValue / m_dCoefficient;
			}
		}
		*pValue = MathTool::Round(dValue,typeInfo.getAccuracy());
	}
	return true;
}

void GaugeHoribaGR300::initDevice()
{
	m_nInBytesSize = m_deviceNet->getIBytesSize(m_macID);
	m_nOutBytesSize = m_deviceNet->getOBytesSize(m_macID);
	if(m_nInBytesSize != 5)
	{
		throw ConfigException(getName()+" MacID "+Converter::convertToString(m_macID)+" InByteSize abnormal "+Converter::convertToString(m_nInBytesSize));
	}
	if(m_nOutBytesSize != 2)
	{
		throw ConfigException(getName()+" MacID "+Converter::convertToString(m_macID)+" OutByteSize abnormal "+Converter::convertToString(m_nOutBytesSize));
	}
}

void GaugeHoribaGR300::init()
{
	DeviceNode<GaugeHoribaGR300> * node = new DeviceNode<GaugeHoribaGR300>(m_pollInterval,this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
	if(!isSimulated())
	{
		node->registerWriteCh(1, &GaugeHoribaGR300::writeDouble);
		node->registerReadCh(2, &GaugeHoribaGR300::readDouble);
		node->registerReadCh(3, &GaugeHoribaGR300::readDouble);

		node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &GaugeHoribaGR300::getStatus);
		initDeviceNet();
		initDevice();
	}
}

void GaugeHoribaGR300::setFlagForMatch649(bool bEnable)
{
	m_bEnable = bEnable;
}

void GaugeHoribaGR300::setChangeCoefficientForMatch649(double dCoefficient)
{
	m_dCoefficient = dCoefficient;

	if(m_dCoefficient == 0.0)
	{
		throw ConfigException(getName()+" can't setChangeCoefficientForMatch649 to 0, please check Driver_config.xml.");
	}
}

IMPLEMENT_DYNAMIC(GaugeHoribaGR300, IODevice )
BEGIN_MSG_MAP( GaugeHoribaGR300, IODevice )
	SET_B(setFlagForMatch649, GaugeHoribaGR300)
	SET_D(setChangeCoefficientForMatch649, GaugeHoribaGR300)
END_MSG_MAP

