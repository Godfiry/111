/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: COMETSingleMatchDriver.h
** Description:  
** Release: 1.1
** Modification history: 
** 					
**                  2014-11-21   lijj	create
*********************************************************************/
#ifndef COMETSINGLEMATCHDRIVER_H_
#define COMETSINGLEMATCHDRIVER_H_
#include "COMETMatchDriver.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#include "DescriptorList.h"
#include "StringTypeInfo.h"
#include <map>
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class COMETSingleMatchDriver:public COMETMatchDriver
{
	DECLARE_DYNAMIC(COMETSingleMatchDriver)	
	DECLARE_MSG_MAP	

	private:
		typedef struct
		{
			int m_ps;
			std::string m_s1;
			int m_ps2;
		}Com;
		
		typedef std::pair<std::string,DescriptorList> ParamPair;
		
		static std::map<std::string,DescriptorList> m_params;
		static ParamPair m_paramPairs[];
		static Com m_commands[];	  

	protected:
		void initChs(DeviceNode<COMETSingleMatchDriver> *node);
		void initDevice();	
		
	public:
		COMETSingleMatchDriver();
		virtual ~COMETSingleMatchDriver();
		
		bool writeInt(int channelNum, int value, const IntTypeInfo &typeInfo);
		bool writeRawCommand(int channelNum, std::string value, const StringTypeInfo &typeInfo);
		bool readInt(int channelNum, int *value, const IntTypeInfo &typeInfo);
		
		void init();		
};

#endif /*COMETSINGLEMATCHDRIVER_H_*/
