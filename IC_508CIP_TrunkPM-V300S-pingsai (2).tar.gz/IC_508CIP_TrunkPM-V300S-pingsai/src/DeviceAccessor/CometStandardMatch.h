#ifndef COMETSTANDARDMATCH_H_
#define COMETSTANDARDMATCH_H_
#include "COMETMatchDriver.h"
#include "DeviceNode.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#include "DescriptorList.h"
#include "StringTypeInfo.h"
#include <map>
#ifdef IAP4_0
using namespace IAP::IO;
#endif



class CometStandardMatch : public COMETMatchDriver
{
	DECLARE_DYNAMIC(CometStandardMatch)	
	DECLARE_MSG_MAP
	
	private:
		typedef struct
		{
			int m_ps;
			std::string m_s1;
			int m_ps2;
		}Com;	
	
		typedef std::pair<std::string,DescriptorList> ParamPair;
		
		static std::map<std::string,DescriptorList> m_params;
		static ParamPair m_paramPairs[];
		static Com m_commands[];
	
	protected:
		void initChs(DeviceNode<CometStandardMatch> *node);
		void initDevice();	
		
	public:
		CometStandardMatch();
		virtual ~CometStandardMatch();
		
		bool writeInt(int channelNum, int nValue, const IntTypeInfo &typeInfo);
		bool writeRawCommand(int channelNum, std::string value, const StringTypeInfo &typeInfo);
		bool readInt(int channelNum, int *nValue, const IntTypeInfo &typeInfo);
		bool readDouble(int nChannelNum, double *pValue, const DoubleTypeInfo &typeInfo);//[liusy v1.1.50]
		
		void init();		
	

};
#endif /*COMETSTANDARDMATCH_H_*/
