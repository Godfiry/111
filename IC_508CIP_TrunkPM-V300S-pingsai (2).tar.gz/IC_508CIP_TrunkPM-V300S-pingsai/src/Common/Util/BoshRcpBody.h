/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: BoshRcpBody.h
** Description:  
** Release: 1.1
** Modification history: 
** 					2014-1-8   LiJuanjuan create
**      
*********************************************************************/
#ifndef BOSHRCPBODY_H_
#define BOSHRCPBODY_H_

#include "AppRcpBody.h"
#include "RecipeUser.h"
#include "ReadWriteInt.h"
#include <vector>
#ifdef IAP4_0
using namespace IAP::RECIPE;
using namespace IAP::IO;
#endif

class BoshRcpBody:public AppRcpBody, public RecipeUser
{

	private:
	
		class ChildRcpBodyMaker:public AppRcpBody
		{
			public:
				void makeBody(const ExecRcpHandler &rcpHandler, int cycleNum, int cycleIdex);
				void addStep(const ExecRcpHandler &rcpHandler, int nStepInRecipe,int nAddStepNum, int cycleNum, int cycleIdex);  //add by wzd 1.1.21
				void setRcpName(std::string strName);  //add by wzd 1.1.21
		};
/*		struct ChildRcpInfo
		{
			int cycle;
			AppRcpBody childRcpBody;
		}
		//std::map<int,*AppRcpBody> m_childRcps;
		std::vector<ChildRcpInfo> m_childRcps;*/
		// m_childRcps is a 3-dimension vector-like struct in OneBodyRecipe, the content of dimension is described as follow:
		// Recipe Example: Step1, Step2, Step3(group1, cycle3), Step4(group1, cycle3), Step5
		// m_childRcps: [[[Step1]], [[Step2]], [[Step3(cycle1), Step4(cycle1)], [Step3(cycle2), Step4(cycle2)], [Step3(cycle3), Step4(cycle3)]], [[Step5]]]
		std::vector<std::vector<AppRcpBody> > m_childRcps;
		int m_currentChildRcpIndex;
		int m_currentChildRcpCycle;
		//std::string m_childRcpClass;
		double m_totalProcessTime;//added by mujy[v1.5.17]
		std::vector<double> m_leftProcessTime;//added by mujy[v1.5.17]

		ReadWriteInt *m_pRecipeType; //add by wzd 1.1.21
		int m_currentChildRcpCycleStep;//added by taohao[1.1.48]

	public:
		BoshRcpBody();
		virtual ~BoshRcpBody();
		
		virtual void clear();
		virtual void makeBody(const ExecRcpHandler &rcpHandler);  //changed by wzd 1.1.21
		virtual void makeGroupBody(const ExecRcpHandler &rcpHandler); //add by wzd 1.1.21
		virtual void makeChildBody(const ExecRcpHandler &rcpHandler);  //add by wzd 1.1.21
		virtual AppRcpStep getStep(int index)const;
		virtual int getStepSize()const;	
		virtual int getPredecessorStepSize(int index);       //add by xiezr 1.1.26

				
		int getChildRcpCycleNum() const;
		std::string getChildRcpName() const;
		int getChildRcpSize() const;
		void setCurrentChildRcp(int index);
		void setCurrentCycle(int cycle);
		double getTotalProcessTime();//added by mujy[v1.5.17]
		virtual double getLeftProcessTime(int step)const;
		virtual int getRcpAllStepNum()const;//added by taohao[1.1.48]
		virtual int getCurrentStepIndex()const;//added by taohao[1.1.48]
		void setCurrentCycleStep(int step);//added by taohao[1.1.48]
		//int getCurrentChildRcpIndex() const;      //huoxb [v1.1.43]  Reserved interface, Need Test
		//AppRcpStep getChildRcpStep(int index, int cycle=1);      //huoxb [v1.1.43]  Reserved interface, Need Test
};

#endif /*BOSHRCPBODY_H_*/
