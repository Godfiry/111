/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: AppRcpBody.cpp
** Description:  
** Release: 1.1
** Modification history: 
**                     2009-8-4   LiJuanjuan create
**      
*********************************************************************/
#include "AppRcpBody.h"
#ifdef IAP4_0
#include "IExceptions.h"
#else
#include "InvalidParameterException.h"
#endif
#include "Converter.h"
#include <iostream>
#ifdef IAP4_0
using namespace IAP;
using namespace IAP::CORE;
using namespace IAP::IO;
#endif

using namespace std;

AppRcpBody::AppRcpBody()
{
    m_rcpName = "";
    m_rcpClass = "";
}
//added by taohao[v1.5.0_HotFix] for obtain the recipe from the memory
AppRcpBody::AppRcpBody(const AppRcpBody &rcpBody)
{
    m_steps = rcpBody.m_steps;
    m_rcpName = rcpBody.m_rcpName;
    m_rcpClass = rcpBody.m_rcpClass;
}
//added by taohao[v1.5.0_HotFix] for obtain the recipe from the memory
AppRcpBody& AppRcpBody::operator=(const AppRcpBody &rcpBody)
{
    if (this != &rcpBody)
    {
        m_steps = rcpBody.m_steps;
        m_rcpName = rcpBody.m_rcpName;
        m_rcpClass = rcpBody.m_rcpClass;
    }
    return *this;
}

AppRcpBody::~AppRcpBody()
{
}

void AppRcpBody::clear()
{
	m_steps.clear();
}

void AppRcpBody::addStep(const ExecRcpHandler &rcpHandler, int nStepInRecipe,int nAddStepNum)  //add by wzd 1.1.21
{
	AppRcpStep t_step;
	t_step.setStepNum(nAddStepNum);
	t_step.setStepName(rcpHandler.getStepName(nStepInRecipe));
	
	for(unsigned int j=1; j<= rcpHandler.getNumOfParams(); ++j)
	{
		ParamValue t_value;
		t_value.Name = rcpHandler.getParamName(j);
		switch(rcpHandler.getParamType(j))
		{
			case IO::INTDATA:
				t_value.Type = IO::INTDATA;
				rcpHandler.getStepValue(nStepInRecipe, j, t_value.IntValue);
				break;

			case IO::STRINGDATA:
				t_value.Type = IO::STRINGDATA;
				rcpHandler.getStepValue(nStepInRecipe, j, t_value.StringValue);
				break;

			case IO::DOUBLEDATA:
				t_value.Type = IO::DOUBLEDATA;
				rcpHandler.getStepValue(nStepInRecipe, j, t_value.DoubleValue);
				break;

			default:
				t_value.Type = IO::UNKNOWN;
				break;
		}
		t_step.addParam(t_value);
	}
	m_steps.push_back(t_step);
}
		
void AppRcpBody::makeBody(const ExecRcpHandler &rcpHandler)
{
	m_rcpName = rcpHandler.getName();
	m_rcpClass = 	rcpHandler.getClass();	
	
	for(unsigned int i=1; i<= rcpHandler.getNumOfSteps(); ++i)
	{
		AppRcpStep t_step;
		t_step.setStepNum(i);
		t_step.setStepName(rcpHandler.getStepName(i));
				
		for(unsigned int j=1; j<= rcpHandler.getNumOfParams(); ++j)
		{
			ParamValue t_value;
			t_value.Name = rcpHandler.getParamName(j);
			switch(rcpHandler.getParamType(j))
			{
				case IO::INTDATA:
					t_value.Type = IO::INTDATA;
					rcpHandler.getStepValue(i, j, t_value.IntValue);
					break;
					
				case IO::STRINGDATA:
					t_value.Type = IO::STRINGDATA;
					rcpHandler.getStepValue(i, j, t_value.StringValue);
					break;
					
				case IO::DOUBLEDATA:
					t_value.Type = IO::DOUBLEDATA;
					rcpHandler.getStepValue(i, j, t_value.DoubleValue);
					break;
					
				default:
					t_value.Type = IO::UNKNOWN;
					break;
			}			
			t_step.addParam(t_value);
		}		
		m_steps.push_back(t_step);
	}
}

AppRcpStep AppRcpBody::getStep(int index)const
{
	if(index > getStepSize() || index <= 0)
	{
		throw InvalidParameterException("step num extend valid range");
	}
	else
	{
		return m_steps.at(index-1);
	}
}

int AppRcpBody::getStepSize()const
{
	return m_steps.size();
}

std::string AppRcpBody::getRcpName()const
{
	return m_rcpName;
}

std::string AppRcpBody::getRcpClass()const
{
	return m_rcpClass;
}

bool AppRcpBody::isEmpty()const
{
	return m_steps.size() == 0;
}

double AppRcpBody::getLeftProcessTime(int step)const
{
	double t_time = 0;
	for (int i=step; i<=getStepSize(); ++i)
	{
		t_time += getStep(i).getParamValue("ProcessTime").DoubleValue.getValue();	
	}
	return t_time;	
}

int AppRcpBody::getRcpAllStepNum()const//added by taohao[1.1.48]
{
	return m_steps.size();
}
