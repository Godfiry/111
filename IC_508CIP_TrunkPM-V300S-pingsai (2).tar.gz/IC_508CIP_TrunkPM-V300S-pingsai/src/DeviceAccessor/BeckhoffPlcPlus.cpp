/*
 * BeckhoffPlcPlus.cpp
 *
 *  Created on: 2023��9��28��
 *      Author: liusiyuan
 */

#include "BeckhoffPlcPlus.h"

#include "DeviceManager.h"
#include "Converter.h"
#ifdef IAP4_0
#include "ITime.h"
#else
#include "Time.h"
#endif
#include "UTime.h"
#include "Hex.h"
#include "ObjectManager.h"
#include <sys/time.h>
#include <string.h>
#include <math.h>
#include <cmath>
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

ParamBase::ParamBase()
{
    m_cLenH = 0;
    m_cLenL = 0;
    m_cUid = 0;
    m_cFuncCode = 0;
    m_cAddrH = 0;
    m_cAddrL = 0;
    m_nRegisterNum = 0;
    m_nAreaAddr = 0;
}

ParamBase::ParamBase(int nAreaCode, int nAreaAddr, int nRegisterNum)
{
    m_cLenH = (unsigned char)((nAreaCode & 0xff000000) >> 24);
    m_cLenL = (unsigned char)((nAreaCode & 0x00ff0000) >> 16);
    m_cUid = (unsigned char)((nAreaCode & 0x0000ff00) >> 8);
    m_cFuncCode = (unsigned char)(nAreaCode & 0x000000ff);

    m_cAddrH = (unsigned char)((nAreaAddr & 0xff00) >> 8);
    m_cAddrL = (unsigned char)((nAreaAddr & 0x00ff));
    m_nAreaAddr = nAreaAddr;
    m_nRegisterNum = nRegisterNum;
}

DIDOParam::DIDOParam():ParamBase()
{
    m_nOffset = 0;
}

DIDOParam::DIDOParam(int nAreaCode, int nAreaAddr, int nOffset):ParamBase(nAreaCode,nAreaAddr,1)
{
    m_nOffset = nOffset;
}

bool DIDOParam::operator==(const DIDOParam &right) const
{
    return (m_cUid == right.m_cUid)
               && (m_cFuncCode == right.m_cFuncCode)
               && (m_cLenH == right.m_cLenH)
               && (m_cLenL == right.m_cLenL)
               && (m_cAddrH == right.m_cAddrH)
               && (m_cAddrL == right.m_cAddrL)
               && (m_nRegisterNum == right.m_nRegisterNum)
               && (m_nOffset == right.m_nOffset);
}


AIAOParam::AIAOParam():ParamBase()
{
    m_dMax = 3000;                //3000W or 10Torr
    m_dMin = 0;                // 0W or 0Torr
    m_nVoltageRange = 10;     // 10V or 5V
}


AIAOParam::AIAOParam(int nAreaCode, int nAreaAddr, double nMax):ParamBase(nAreaCode,nAreaAddr,2)
{
    m_dMax = nMax;                //3000W or 10Torr
    m_dMin = 0;                // 0W or 0Torr
    m_nVoltageRange = 10;     // 10V or 5V
}

bool AIAOParam::operator==(const AIAOParam &right) const
{
    return (m_cUid == right.m_cUid)
                   && (m_cFuncCode == right.m_cFuncCode)
                   && (m_cLenH == right.m_cLenH)
                   && (m_cLenL == right.m_cLenL)
                   && (m_cAddrH == right.m_cAddrH)
                   && (m_cAddrL == right.m_cAddrL)
                   && (m_nRegisterNum == right.m_nRegisterNum)
                   && (abs(m_dMin - right.m_dMin)<0.1)
                   && (m_nVoltageRange == right.m_nVoltageRange)
                   && (abs(m_dMax - right.m_dMax)<0.1);
}

BeckhoffPlcPlus::BeckhoffPlcPlus() {
    // TODO Auto-generated constructor stub
    bzero(m_modbusSend, sizeof(m_modbusSend));//set 0

    // fixed header title
    m_modbusSend[0] = 0x00; /*Header title is fixed: 00 00 00 00 */
    m_modbusSend[1] = 0x00;
    m_modbusSend[2] = 0x00;
    m_modbusSend[3] = 0x00;

    m_bWaiting = false;
    m_bReadCmd = false;
    m_bFastRead = true;
    m_strReadError = "";
    m_strWriteError = "";
    m_strResult = "";

    m_doParam.clear();
    m_diParam.clear();

    m_aoParam.clear();
    m_aiParam.clear();

    m_bExist = false;

    m_pDIRegisterRWMutex = new IMutex();
    m_pAIRegisterRWMutex = new IMutex();

    m_nThreadStatus = UNINIT;

    m_nDebugEnable = 0;// 0= no print;1=to log; 2=to console
    m_bWriteFlag = false;//added by liusy[1.1.52]
    m_pReadMutex = new IMutex();
    m_pWriteMutex = new IMutex();

    m_nWritePollTimeUs = 1000;//us
    m_nMainThreadCount = 0;
    m_nReadPollIntervalCount = 200;
    m_checkInterval = 1;//ms
}

BeckhoffPlcPlus::~BeckhoffPlcPlus() {
    // TODO Auto-generated destructor stub
    m_bExist = true;
    while(!(m_nThreadStatus == EXITED || m_nThreadStatus == UNINIT))
    {
        usleep(20);//wait thread exit();
    }
    delete m_pAIRegisterRWMutex;
    m_pAIRegisterRWMutex = NULL;
    delete m_pDIRegisterRWMutex;
    m_pDIRegisterRWMutex = NULL;
    delete m_pReadMutex;//added by liusy[1.1.52]
    m_pReadMutex = NULL;
    delete m_pWriteMutex;
    m_pWriteMutex = NULL;
}

void BeckhoffPlcPlus::setReadPollIntervalMs(double dTimeMs)
{
    m_nReadPollIntervalCount = dTimeMs * 1000/m_nWritePollTimeUs;
}


void BeckhoffPlcPlus::setWritePollTimeUs(int dTimeUs)
{
    m_nWritePollTimeUs =dTimeUs;
}

void BeckhoffPlcPlus::run()
{
    while(true)
    {

        if(m_bExist)
        {
            m_nThreadStatus =EXITED;
            exit();
        }

        try
        {
            if (m_bWriteFlag == true)//added by liusy[1.1.52]
            {
                m_waitWrtieCond.wakeAll();

                m_pReadMutex->lock();
                m_waitReadCond.wait(m_pReadMutex, 5000);
                m_pReadMutex->unlock();
            }
            if(m_nMainThreadCount == m_nReadPollIntervalCount)
            {
                readAIDIRegister();
                m_nMainThreadCount = 0;
            }
        }
        catch(const exception &ex)//added by liusy[1.1.52]
        {
            m_nMainThreadCount = 0;
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": run() catch exception-"+string(ex.what()));
            //m_bExist = true;
        }

        m_nThreadStatus = RUN;
        m_nMainThreadCount++;
        usleep(m_nWritePollTimeUs*1);
    }
}

void BeckhoffPlcPlus::init()
{
    cout<<"BeckhoffPlcPlus start to init"<<endl;
    DeviceNode<BeckhoffPlcPlus> *node = new DeviceNode<BeckhoffPlcPlus>(m_pollInterval,this);
    DeviceManager::getInstance()->registerNode(m_nodeNum,node);

    if(!isSimulated())
    {
        cout<<"BeckhoffPlcPlus start to init channels"<<endl;
        initChannels(node);
        cout<<"BeckhoffPlcPlus init channels ok"<<endl;
        TCPDevice::init();

        initDIDORegister();
        sleep(1);
        start();
    }


}

void BeckhoffPlcPlus::initDIDORegister()
{
    //DO

    map<int,int>::iterator it;
    try
    {
        char cRemotePLCDOData[32];
        for(it = m_WriteDORegister.begin();it != m_WriteDORegister.end();it++)
        {
            int nLength = sizeof(cRemotePLCDOData);
            int nData = 0;
            memset(cRemotePLCDOData, 0, nLength);
            readPLCRegisterData(it->first, 1, cRemotePLCDOData, nLength);

            if(nLength != 2)
            {
                throw IOException("read DO data is exception! it should be 2");
            }
            //cRemotePLCData = { 0x03(H) 0x00(L)[first]   0x03(H) 0x00(L)[second] }

            nData = ((cRemotePLCDOData[0] << 8 & 0x0000FF00)) + (cRemotePLCDOData[1] & 0x000000FF);

            it->second = nData;
        }

    }
    catch(const exception &ex)//added by liusy[1.1.52]
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": run() catch exception-"+string(ex.what()));
    }
    catch(...)
    {
        throw IOException("failed to connect to Backoff PLC!");
    }



    ////DI
    /*
    sort(m_ReadDIRegister.begin(),m_ReadDIRegister.end());

    if(m_ReadDIRegister.size() == 0)
    {
        return;
    }

    it = m_ReadDIRegister.begin();

    if(!m_bFastRead)
        return;




    m_ReadContiuneRegister.insert(pair<int,int>(it->first,1));

    if(m_ReadDIRegister.size() == 1)
    {
        return;
    }

    map<int,int>::iterator it2 = m_ReadDIRegister.begin()+1;
    int nRegisterNum = 1;

    while(it2 != m_ReadDIRegister.end())
    {

        if(it2->first == (it->first+1))
        {
            nRegisterNum++;
        }
        else
        {
            m_ReadContiuneRegister[it->first] = nRegisterNum;
            nRegisterNum =1;
            m_ReadContiuneRegister.insert(it2->first,1);
        }
        it++;
        it2++;
    }
    */
    // 1 2 3 4 5 7 8 9 11 13
    // (1,5) (7,3) (11,1) (13,1)
}
//added by liusy[1.1.52]
void BeckhoffPlcPlus::readWriteRegister(int nAddr, int nReadSize)
{
    try
    {
        {
            char cRemotePLCDOData[32];
            int nLength = sizeof(cRemotePLCDOData);
            int nData = 0;
            memset(cRemotePLCDOData, 0, nLength);
            recordLog(" readWriteRegister, nAddr = "+ Converter::convertToString(nAddr) + ", size ="+Converter::convertToString(nReadSize));
            readPLCRegisterData(nAddr, nReadSize, cRemotePLCDOData, nLength);

            if (nLength < 2)
            {
                throw IOException("read DO data is exception! it should be over 2");
            }
            //cRemotePLCData = { 0x03(H) 0x00(L)[first]   0x03(H) 0x00(L)[second] }

            //nData = ((cRemotePLCDOData[0] << 8 & 0x0000FF00)) + (cRemotePLCDOData[1] & 0x000000FF);

            if (nReadSize == 1)
            {
                //m_WriteDORegister[nAddr] = nData;
            }
        }
    }
    catch (...)
    {
        throw IOException("failed to connect to Backoff PLC!");
    }

}

void BeckhoffPlcPlus::recordLog(string strLog)
{
    if(m_nDebugEnable == 1)
    {
        //cout<<"???";
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, Converter::convertToString(UTime::getCurrentTimeAsMSeconds())+": " +getDeviceName() + ":"+strLog);
    }
    else if(m_nDebugEnable == 2)
    {
        cout<<Converter::convertToString(UTime::getCurrentTimeAsMSeconds())<<": "<<getDeviceName() + ":"+strLog<<endl;
    }
}

void BeckhoffPlcPlus::readAIDIRegister()
{
    map<int,int>::iterator it,it2;
    char cRemotePLCData[256];

    //DI read
    
    for(it = m_ReadDIRegister.begin();it != m_ReadDIRegister.end();it++)
    {
        int nLength = sizeof(cRemotePLCData);
        int nData = 0;
        memset(cRemotePLCData, 0, nLength);
        
            if (m_bWriteFlag == true)//added by liusy[1.1.52]
            {
                m_waitWrtieCond.wakeAll();

                m_pReadMutex->lock();
                m_waitReadCond.wait(m_pReadMutex, 5000);
                m_pReadMutex->unlock();
            }
        
        recordLog("read DI:" + Converter::convertToString(it->first)+" begin");
        readPLCRegisterData(it->first, 1, cRemotePLCData, nLength);
        recordLog("read DI:" + Converter::convertToString(it->first)+" end");
        if(nLength != 2)
        {
            throw IOException("data is exception!,should be 2");
        }
        //cRemotePLCData = { 0x03(H) 0x00(L)[first]   0x03(H) 0x00(L)[second] }
        
        nData = ((cRemotePLCData[0] << 8 & 0x0000FF00)) + (cRemotePLCData[1] & 0x000000FF);

        {
            IMutexLocker locker(m_pDIRegisterRWMutex);
            it->second = nData;
        }
    }

    //AI read
    
    for(it = m_ReadAIRegister.begin();it != m_ReadAIRegister.end();it++)
    {
        int nLength = sizeof(cRemotePLCData);
        int nData = 0;
        memset(cRemotePLCData, 0, nLength);

            if (m_bWriteFlag == true)//added by liusy[1.1.52]
            {
                m_waitWrtieCond.wakeAll();

                m_pReadMutex->lock();
                m_waitReadCond.wait(m_pReadMutex, 5000);
                m_pReadMutex->unlock();
            }

        recordLog("read AI:" + Converter::convertToString(it->first)+" begin");
        readPLCRegisterData(it->first, 2, cRemotePLCData, nLength);
        recordLog("read AI:" + Converter::convertToString(it->first)+" end");
        
        nData = ((cRemotePLCData[0] << 8 & 0xFF00)) + (cRemotePLCData[1] & 0x00FF);
        {
            IMutexLocker locker(m_pAIRegisterRWMutex);
            it->second = nData;
        }
    }

}
/*
void BeckhoffPlcPlus::readDIRegister()
{
    map<int,int>::iterator it,it2;

    if(!m_bFastRead) // slow Read
    {
        char cRemotePLCData[256];

        for(it = m_ReadRegister.begin();it != m_ReadRegister.end();it++)
        {
            int nLength = sizeof(cRemotePLCData);
            int nData = 0;
            memset(cRemotePLCData, 0, nLength);
            readPLCRegisterData(it->first, 1, cRemotePLCData, nLength);

            if(nLength != 2)
            {
                throw IOException("data is exception!");
            }
            //cRemotePLCData = { 0x03(H) 0x00(L)[first]   0x03(H) 0x00(L)[second] }

            nData = ((cRemotePLCData[0] << 8 & 0x0000FF00)) + (cRemotePLCData[1] & 0x000000FF);

            {
                IMutexLocker locker(m_AIDIRegisterRWMutex);
                it->second = nData;
            }
        }
        return;
    }
    //fast read
    //char cRemotePLCData[256]; //the most length

    it = m_ReadRegister.begin();
    for(it2 = m_ReadContiuneRegister.begin();it2 != m_ReadContiuneRegister.end();it2++)
    {

        int nLength = (it2->second)*4;
        int nData = 0;

        char *pRemotePLCData = new char[nLength];
        memset(pRemotePLCData, 0, nLength);

        readPLCRegisterData(it2->first, it2->second, pRemotePLCData, nLength);

        if(nLength != it2->second*2)
        {
            throw IOException("data is exception!");
        }
        //cRemotePLCData = { 0x03(H) 0x00(L)[first]   0x03(H) 0x00(L)[second] }

        int nIndex = 0;
        while(it!=m_ReadRegister.end() && nIndex < it2->second*2)
        {
            {
                IMutexLocker locker(m_AIDIRegisterRWMutex);
                it->second =  ((pRemotePLCData[nIndex] << 8 & 0x0000FF00)) + (pRemotePLCData[nIndex+1] & 0x000000FF);
            }
            it++��
            nIndex += 2;
        }
        delete[] pRemotePLCData;
    }

}
*/

void BeckhoffPlcPlus::readPLCRegisterData(int nAddr, int nReadSize, char *pResult, int &nResultSize)
{
    string strErrTitle = "BeckhoffPlcPlus::readPLCRegisterData, Address = "+Converter::convertToString(nAddr)+",size="+Converter::convertToString(nReadSize) ;

    ParamBase param;

    param.m_cUid = 0x01;// ���� DIDO read //added by liusy[1.1.52]
    param.m_cFuncCode = R_HREGWORD;
    param.m_cLenH = 0x00;
    param.m_cLenL = 0x06;
    param.m_cAddrH = (nAddr & 0xFF00) >> 8;
    param.m_cAddrL = nAddr & 0x00FF;
    param.m_nRegisterNum = nReadSize;

    recordLog(strErrTitle);
       m_bReadCmd = true;
    m_strResult = "";
    m_strReadError = "";
    modbusSendCommand(&param, NULL, strErrTitle ,m_strReadError);
    m_bReadCmd = false;

    recordLog(strErrTitle + ", read data: "+ Hex::GetHexString(m_recvBuffer,20));
    if(m_strReadError != "")
    {
        throw IOException(strErrTitle+":  failed to read DIDO bit. reason: " + m_strReadError);
    }

    if(((int)m_recvBuffer[8]) < 0)  //m_modbusRecv[8] the data bytes counter of response
    {
        throw IOException(strErrTitle + ": No Data has received.");

    }
    if(nResultSize < (int)m_recvBuffer[8])
    {
        throw IOException(strErrTitle + ":  Data length is over 32 bit. buffer overflow!");//buffer overflow
    }

    nResultSize = (int)m_recvBuffer[8];//length

    memcpy(pResult, &m_recvBuffer[9], nResultSize);

    if(m_bExist == true)
    {
        throw IOException(strErrTitle + ":  it uses to stop thread!");
    }
}

void BeckhoffPlcPlus::initChannels(DeviceNode<BeckhoffPlcPlus> *node)
{
    if(m_diParam.size() >= 1000 || m_doParam.size() >= 1000 || m_aiParam.size() >= 1000 || m_aoParam.size() >= 1000)
    {
        throw IOException("DI, DO , AI or AO's size is over 1000");
    }

    for (unsigned int i = 0; i < m_doParam.size(); ++i)
    {
        node->registerWriteCh(i, &BeckhoffPlcPlus::writeInt); // DuplicatedException
    }

    for (unsigned int i = 1000; i < (m_diParam.size() + 1000); ++i)
    {
        node->registerReadCh(i, &BeckhoffPlcPlus::readInt); // DuplicatedException
    }

    for (unsigned int i = 2000; i < (m_aoParam.size() + 2000); ++i)
    {
        node->registerWriteCh(i, &BeckhoffPlcPlus::writeDouble); // DuplicatedException
    }

    for (unsigned int i = 3000; i < (m_aiParam.size() + 3000); ++i)
    {
        node->registerReadCh(i, &BeckhoffPlcPlus::readDouble); // DuplicatedException
    }

}

std::string BeckhoffPlcPlus::getDeviceName()
{
    return "BeckhoffPlcPlus";
}



void BeckhoffPlcPlus::acceptData()
{
    memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
    /////////////////////////////////////////////////////////
    // <><>  2. Recv fins response from server (plc) <><>  //
    /////////////////////////////////    ////////////////////////

    // 2.1 reveive data
    if(readData(m_recvBuffer, sizeof(m_recvBuffer)))
    {
        recordLog("rec Data -> PC: " + Hex::GetHexString(m_recvBuffer,20));        
        if(m_bWaiting)
        {
            if(m_bReadCmd)
            {
                parseReadReply();
            }
            else
            {
                parseWriteReply();
            }
            m_bWaiting = false;
        }
        else
        {
            m_strRawResult = Hex::GetHexString(m_recvBuffer,12);
            #ifdef IAP4_0
            cout << "BeckhoffPlc: [" << ITime::getCurrentTimeAsStr() << "] " << getDeviceName() << " rawResult:"<< m_strRawResult<< endl;
            #else
            cout << "BeckhoffPlc: [" << Time::getCurrentTimeAsStr() << "] " << getDeviceName() << " rawResult:"<< m_strRawResult<< endl;
            #endif
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::VERBOSE, getDeviceName() + ": in acceptData() is not waiting");
        }
    }
    else
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": reading failed in acceptData()");
        if(m_bWaiting)
        {
            if(m_bReadCmd)
            {
                m_strReadError = "read_back from device failed";
            }
            else
            {
                m_strWriteError = "read_back from device failed";
            }
            m_bWaiting = false;
        }
    }
}


void BeckhoffPlcPlus::parseWriteReply()//need to modify
{
    string strReply = Hex::GetHexString(m_recvBuffer,20);
    recordLog("parseWrite:");        
    long nLeftTime = m_timeOut * 1000;//ms
    long nStartTime = UTime::getCurrentTimeAsMSeconds();

    while(nLeftTime > 0)
    {
        nStartTime = UTime::getCurrentTimeAsMSeconds();

        if( (m_modbusSend[7] == MWR_WORD)  || (m_modbusSend[7] == WR_WORD) )
        {
            if(m_recvBuffer[7] != m_modbusSend[7]
                || m_recvBuffer[8] != m_modbusSend[8]
                || m_recvBuffer[9] != m_modbusSend[9]
                || m_recvBuffer[10] != m_modbusSend[10]
                || m_recvBuffer[11] != m_modbusSend[11])
            {
                string strErr = ": Receive MODBUS response frame failed! Invalid source node address '";
                SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, strErr);
                m_strWriteError = strErr+"reply is"+strReply;
            }
        }
        if(m_strWriteError.empty())
        {
            return;
        }

        usleep(m_checkInterval*1000);
        flush();
        strReply +=  Hex::GetHexString(m_recvBuffer,20);
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::EVENT, "@@@@@"+getDeviceName() + " reply n: " + strReply);
        nLeftTime -= UTime::getCurrentTimeAsMSeconds() - nStartTime;
    }
    m_strWriteError = "waiting Receive timeout " + strReply;
}

void BeckhoffPlcPlus::parseReadReply()
{
    string strReply = Hex::GetHexString(m_recvBuffer,20);
    recordLog("parseRead:");        
    long nLeftTime = m_timeOut * 1000;//ms
    long nStartTime = UTime::getCurrentTimeAsMSeconds();
    while(nLeftTime > 0)
    {
        nStartTime = UTime::getCurrentTimeAsMSeconds();

        if(m_recvBuffer[7] > 0x80)
        {
            string strErr = ": Receive unknown MODBUS response ! Error function code is '"+ Converter::convertToString(m_recvBuffer[8])+"'.";
            SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, strErr);
            m_strReadError = strErr+"reply is"+strReply;
        }

        if(m_strResult == "")
        {
            if( m_recvBuffer[7] == R_HREGWORD ||  m_recvBuffer[7] == R_IREGWORD)
            {
                recordLog("parseRead, results = "+ strReply);
                m_strResult == strReply;
                return;
            }
        }
        usleep(m_checkInterval*1000);
        flush();
        strReply +=  Hex::GetHexString(m_recvBuffer,20);
        nLeftTime -= UTime::getCurrentTimeAsMSeconds() - nStartTime;
    }
    m_strReadError = "waiting Receive timeout " + strReply;
}

void BeckhoffPlcPlus::flush()
{
    memset(m_recvBuffer, 0, sizeof(m_recvBuffer));
    if(!readData(m_recvBuffer, sizeof(m_recvBuffer)))
    {
        SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, getDeviceName() + ": reading failed in flush()");
    }

}

bool BeckhoffPlcPlus::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
    string nErrTitle = "BeckhoffPlcPlus::writeInt("+Converter::convertToString(nChannelNum)+")";

    if (nChannelNum >= (int)m_doParam.size())
    {
        throw IOException(nErrTitle+": Invalid channel number.");
    }

    int nAddr = ((m_doParam[nChannelNum].m_cAddrH & 0x00ff) << 8) +(m_doParam[nChannelNum].m_cAddrL);

    //m_WriteDORegister

    if(m_WriteDORegister.find(nAddr) == m_WriteDORegister.end())
    {
        throw IOException(nErrTitle+": Invalid Write Register addr.");
    }

    m_bWriteFlag = true; //added by liusy[1.1.52]
    m_pWriteMutex->lock();
    m_waitWrtieCond.wait(m_pWriteMutex, 1000);
    m_pWriteMutex->unlock();

    readWriteRegister(nAddr);
    int nSendValue = m_WriteDORegister[nAddr];
    recordLog("nAddr = "+ Converter::convertToString(nAddr)+ ", oldbuffer="+ Converter::convertToString(nSendValue));
    if(nValue == 1)
    {
        nSendValue = nSendValue | (0x0001 << m_doParam[nChannelNum].m_nOffset);//set 1
    }
    else
    {
        nSendValue = nSendValue & (~(0x0001 << m_doParam[nChannelNum].m_nOffset));//set 0
    }
    recordLog("nAddr = "+ Converter::convertToString(nAddr)+ ", send buffer="+ Converter::convertToString(nSendValue));
    m_strWriteError = "";
    modbusSendCommand(&m_doParam[nChannelNum], &nSendValue, nErrTitle,m_strWriteError);

    m_bWriteFlag = false;
    m_waitReadCond.wakeAll();//added by liusy[1.1.52]
    if(m_strWriteError == "")
    {
        m_WriteDORegister[nAddr] = nSendValue; // update register
    }
    else
    {
        throw IOException(nErrTitle+":  failed to write bit. reason: " + m_strWriteError);
    }

    return true;
}

bool BeckhoffPlcPlus::readInt(int nChannelNum, int *nValue, const IntTypeInfo &typeInfo)
{

    string nErrTitle = "BeckhoffPlcPlus::readInt("+Converter::convertToString(nChannelNum)+")";

    int nIndex = nChannelNum -1000;
    if (nIndex >= (int)m_diParam.size())
    {
        throw IOException(nErrTitle+": Invalid channel number.");
    }

    int nAddr = m_diParam[nIndex].m_nAreaAddr;

    if(m_ReadDIRegister.find(nAddr) == m_ReadDIRegister.end())
    {
        throw IOException(nErrTitle+": Invalid read Register addr.");
    }

    int nReadRegisterValue = 0;

    {
        IMutexLocker locker(m_pDIRegisterRWMutex);
        nReadRegisterValue = m_ReadDIRegister[nAddr];
    }

    if((nReadRegisterValue & (0x00000001 << m_diParam[nIndex].m_nOffset)) == 0)//added by liusy[1.1.52]
    {
        *nValue = 0;
    }
    else
    {
        *nValue = 1;
    }

    return true;

}

bool BeckhoffPlcPlus::writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
    string strErrTitle = "BeckhoffPlcPlus::writeDouble("+Converter::convertToString(nChannelNum)+")";
    int nIndex = nChannelNum - 2000;
    if (nIndex >= (int)m_aoParam.size())
    {
        string strErr = strErrTitle+": Invalid channel number.";
        throw IOException(strErr);
    }
    int nAddr = ((m_aoParam[nIndex].m_cAddrH & 0x00ff) << 8) +(m_aoParam[nIndex].m_cAddrL);

    float dTempValue = ((dValue  / (m_aoParam[nIndex].m_dMax - m_aoParam[nIndex].m_dMin)) + m_aoParam[nIndex].m_dMin)* m_aoParam[nIndex].m_nVoltageRange;
        unsigned char tmpCmd[4];
    int t_tempValue = (int)dTempValue;
    tmpCmd[0] = (t_tempValue >> 8) & 0xFF;
    tmpCmd[1] = t_tempValue & 0xFF;


    m_strWriteError = "";
    m_bWriteFlag = true;//added by liusy[1.1.52]

    m_pWriteMutex->lock();
    m_waitWrtieCond.wait(m_pWriteMutex, 1000);
    m_pWriteMutex->unlock();
    readWriteRegister(nAddr, 2);
    modbusSendCommand(&m_aoParam[nIndex], tmpCmd, strErrTitle ,m_strWriteError);
    m_bWriteFlag = false;
    m_waitReadCond.wakeAll();

    if(m_strWriteError != "")
    {
        throw IOException(strErrTitle+":  failed to write bit. reason: " + m_strWriteError);
    }

    return true;

}

bool BeckhoffPlcPlus::readDouble(int nChannelNum, double *dValue, const DoubleTypeInfo &typeInfo)
{

    int nIndex = nChannelNum - 3000;
    string strErrTitle = "BeckhoffPlcPlus::readDouble("+Converter::convertToString(nChannelNum)+")";

    if (nIndex >= (int)m_aiParam.size())
    {
        throw IOException(strErrTitle+": Invalid channel number.");
    }


    if ((m_aiParam[nIndex].m_cFuncCode != R_HREGWORD) )
    {
        throw IOException(strErrTitle + ": AI channel function code is not read word.");
    }

    int nAddr = m_aiParam[nIndex].m_nAreaAddr;

    if(m_ReadAIRegister.find(nAddr) == m_ReadAIRegister.end())
    {
        throw IOException(strErrTitle+": Invalid read Register addr.");
    }

    int nReadRegisterValue = 0;

    {
        IMutexLocker locker(m_pAIRegisterRWMutex);
        nReadRegisterValue = m_ReadAIRegister[nAddr];
    }


    short sTempValue = (short)(((nReadRegisterValue & 0x0000FF00)) | (nReadRegisterValue & 0x000000FF));
    double pdValue = (double)sTempValue;
    
    //float pfValue= (float)nReadRegisterValue 0xFF00;

    double dTempValue = pdValue*(m_aiParam[nIndex].m_dMax - m_aiParam[nIndex].m_dMin)/m_aiParam[nIndex].m_nVoltageRange + m_aiParam[nIndex].m_dMin;


    if(m_aiFilter.find(nChannelNum) == m_aiFilter.end())//no filter
    {
        *dValue = MathTool::Round(dTempValue,typeInfo.getAccuracy());
        return true;
    }

    if(dTempValue < m_aiFilter[nChannelNum])//filter noise
    {
        *dValue = 0;
    }
    else
    {
        *dValue = MathTool::Round(dTempValue,typeInfo.getAccuracy());
    }

    return true;
}





void BeckhoffPlcPlus::modbusSendCommand(ParamBase *param, void *val, const std::string &strErrTitle, std::string &strErrorMsg)
{

    int nByteLen = 0;
    m_modbusSend[4] = param->m_cLenH; //0, if msg length less 256bytes
    m_modbusSend[5] = param->m_cLenL;


    if(param->m_cUid != 0xFF)
    {
        m_modbusSend[6] = param->m_cUid;
    }
    else
    {
        m_modbusSend[6] = 0xFF;
    }


    // 1.3 Fill function-code
    //
    m_modbusSend[7] = param->m_cFuncCode;

    //1.4 Fill data address, for bit - offset start from 0x0000, for word - offset start from 0x0800
    //
    m_modbusSend[8] = param->m_cAddrH;
    m_modbusSend[9] = param->m_cAddrL;

    switch (param->m_cFuncCode)
    {
        case R_COILBITS:
        case R_INPUTBITS:
        case WR_BIT:
        case MWR_BIT:
        case R_IREGWORD:
            throw IOException(strErrTitle+": this functional code is not developed");
            break;

        case WR_WORD://DO 16bit
            m_modbusSend[6] = 0x01;//added by liusy[1.1.52]
            memcpy(m_modbusSend + 10, (unsigned char*)val + 1, 1);
            memcpy(m_modbusSend + 11, (unsigned char*)val + 0, 1);

            break;
        case MWR_WORD: //AO
            m_modbusSend[10] = ((param->m_nRegisterNum & 0xff00) >> 8);
            m_modbusSend[11] = (param->m_nRegisterNum) & 0x00ff;
            nByteLen = (param->m_nRegisterNum - 0x00)*2;
            m_modbusSend[12] = (unsigned char)(nByteLen & 0x00ff);

            for (int i = 0; i < nByteLen; i++)
            {
                memcpy(m_modbusSend+13+i, (unsigned char*)val+i, 1);
                //memcpy(m_modbusSend + 14, (unsigned char*)val + 0, 1);
                //cout << "@ data [" << charArrayToStr((unsigned char*)val+i,1) << "] " << endl;
                //cout << "@ data [" << charArrayToStr(&m_modbusSend[13+i],1) << "] " << endl;
            }
            break;

        case R_HREGWORD://AI DI
            m_modbusSend[10] = ((param->m_nRegisterNum & 0xff00) >> 8);
            m_modbusSend[11] = param->m_nRegisterNum & 0x00ff;

            break;
        default:
            throw IOException(strErrTitle+": this functional code is not exist");
            break;

    }

    m_bWaiting = true;
    int nTotalLen = ((int)(m_modbusSend[4]) << 8) + (int)(m_modbusSend[5]) + 6;

    recordLog("send Data -> equipment" + Hex::GetHexString(m_modbusSend,nTotalLen));
    sendData(m_modbusSend,nTotalLen);
    recordLog("sended Data -> equipment" + Hex::GetHexString(m_modbusSend,nTotalLen));

    int nLeftcount = m_timeOut*1000 / m_checkInterval;
    while(nLeftcount >= 0)
    {
        if(!m_bWaiting)
        {
            if(strErrorMsg != "")
            {
                recordLog(strErrTitle + ":" + strErrorMsg);
                throw IOException(strErrTitle + ":" + strErrorMsg);
            }
            else
            {
                recordLog("sended OK");
                return;
            }
        }
        usleep(m_checkInterval * 1000);
        --nLeftcount;
    }
    recordLog(strErrorMsg+","+strErrTitle + ":command read_back timeOut");
    throw IOException(strErrorMsg+","+strErrTitle + ":command read_back timeOut");
}


void BeckhoffPlcPlus::addParamDI(int nAreaCode, int nAreaAddr, int nOffsetAddr)
{

    string strErrTitle = "Param("+Converter::convertToString(nAreaCode)+", "+Converter::convertToString(nAreaAddr)+", "+Converter::convertToString(nOffsetAddr)+")";
    string strErrorMsg = "";
    if(!checkParamValid(nAreaCode,nAreaAddr,strErrorMsg))
        throw string(strErrTitle+": "+strErrorMsg);

    DIDOParam newParam(nAreaCode, nAreaAddr, nOffsetAddr);//, addrBit); //

    if (find(m_diParam.begin(), m_diParam.end(), newParam) != m_diParam.end())
    {
        throw string("Duplicated DI-Param("+Converter::convertToString(nAreaCode)+", "+Converter::convertToString(nAreaAddr)+", "+Converter::convertToString(nOffsetAddr)+").");
    }

    if (m_diParam.size() > 1000)
    {
        throw string("Total DI-Param number is over 1000.");
    }

    m_diParam.push_back(newParam);

    if(m_ReadDIRegister.find(nAreaAddr) == m_ReadDIRegister.end()) 
    {
        m_ReadDIRegister.insert(pair<int,int>(nAreaAddr,0));
    }

    if(m_nDebugEnable)
    {
        cout<<"addDI: "<<strErrTitle<<endl;
    }
    
}

void BeckhoffPlcPlus::addParamDO(int nAreaCode, int nAreaAddr, int nOffsetAddr)
{
    string strErrTitle = "Param("+Converter::convertToString(nAreaCode)+", "+Converter::convertToString(nAreaAddr)+", "+Converter::convertToString(nOffsetAddr)+")";
    string strErrorMsg = "";
    if(!checkParamValid(nAreaCode,nAreaAddr,strErrorMsg))
        throw string(strErrTitle+": "+strErrorMsg);

    DIDOParam newParam(nAreaCode, nAreaAddr, nOffsetAddr);//, addrBit); //

    if (find(m_doParam.begin(), m_doParam.end(), newParam) != m_doParam.end())
    {
        throw string("Duplicated DI-Param("+Converter::convertToString(nAreaCode)+", "+Converter::convertToString(nAreaAddr)+", "+Converter::convertToString(nOffsetAddr)+").");
    }

    if (m_doParam.size() > 1000)
    {
        throw string("Total DI-Param number is over 1000.");
    }

    m_doParam.push_back(newParam);

    if(m_WriteDORegister.find(nAreaAddr) == m_WriteDORegister.end())  //added by liusy[1.1.22]
    {
        m_WriteDORegister.insert(pair<int,int>(nAreaAddr,0));
    }
    if(m_nDebugEnable)
    {
        cout<<"addDO: "<<strErrTitle<<endl;
    }
}

void BeckhoffPlcPlus::addParamAI(int nAreaCode, int nAreaAddr, double nMax)
{
    string strErrTitle = "Param("+Converter::convertToString(nAreaCode)+", "+Converter::convertToString(nAreaAddr)+", "+Converter::convertToString(nMax)+")";
    string strErrorMsg = "";
    if(!checkParamValid(nAreaCode,nAreaAddr,strErrorMsg))
        throw string(strErrTitle+": "+strErrorMsg);

    AIAOParam newParam(nAreaCode, nAreaAddr, nMax);//, addrBit); //

    if (find(m_aiParam.begin(), m_aiParam.end(), newParam) != m_aiParam.end())
    {
        throw string("Duplicated AI-Param("+Converter::convertToString(nAreaCode)+", "+Converter::convertToString(nAreaAddr)+", "+Converter::convertToString(nMax)+").");
    }

    if (m_aiParam.size() > 1000)
    {
        throw string("Total AI-Param number is over 1000.");
    }

    m_aiParam.push_back(newParam);

    if(m_ReadAIRegister.find(nAreaAddr) == m_ReadAIRegister.end())  //added by liusy[1.1.22]
    {
        m_ReadAIRegister.insert(pair<int,int>(nAreaAddr,0));
    }

    if(m_nDebugEnable)
    {
        cout<<"addAI: "<<strErrTitle<<endl;
    }
}

void BeckhoffPlcPlus::addParamAO(int nAreaCode, int nAreaAddr, double nMax)
{
    string strErrTitle = "Param("+Converter::convertToString(nAreaCode)+", "+Converter::convertToString(nAreaAddr)+", "+Converter::convertToString(nMax)+")";
    string strErrorMsg = "";
    if(!checkParamValid(nAreaCode,nAreaAddr,strErrorMsg))
        throw string(strErrTitle+": "+strErrorMsg);

    AIAOParam newParam(nAreaCode, nAreaAddr, nMax);//, addrBit); //

    if (find(m_aoParam.begin(), m_aoParam.end(), newParam) != m_aoParam.end())
    {
        throw string("Duplicated AO-Param("+Converter::convertToString(nAreaCode)+", "+Converter::convertToString(nAreaAddr)+", "+Converter::convertToString(nMax)+").");
    }

    if (m_aoParam.size() > 1000)
    {
        throw string("Total AO-Param number is over 1000.");
    }

    m_aoParam.push_back(newParam);

    if(m_nDebugEnable)
    {
        cout<<"addAO: "<<strErrTitle<<endl;
    }
}

void BeckhoffPlcPlus::setAOOtherParam(int nChannelNum, double dMin, int nVoltageRange)
{
    int nIndex = nChannelNum - 2000;
    m_aoParam.at(nIndex).m_nVoltageRange = nVoltageRange;
    m_aoParam.at(nIndex).m_dMin = dMin;
}

void BeckhoffPlcPlus::setAIOtherParam(int nChannelNum, double dMin, int nVoltageRange)
{
    int nIndex = nChannelNum - 3000;
    m_aiParam.at(nIndex).m_nVoltageRange = nVoltageRange;
    m_aiParam.at(nIndex).m_dMin = dMin;
}

void BeckhoffPlcPlus::setAIFilterParam(int nChannelNum, int nAIFilterValue)
{
    m_aiFilter.insert(pair<int,int>(nChannelNum,nAIFilterValue));
}

bool BeckhoffPlcPlus::checkParamValid(int nAreaCode, int nAreaAddr,std::string &strErrorMsg)
{
    int m_cLenH = (unsigned char)((nAreaCode & 0xff000000) >> 24);
    if (m_cLenH != 0x00)
    {
        strErrorMsg = "Message length is large than 256bytes.";
        return false;
    }

    int m_cFuncCode = (unsigned char)(nAreaCode & 0x000000ff);

    if ((m_cFuncCode != WR_BIT)
        && (m_cFuncCode != WR_WORD)
        && (m_cFuncCode != MWR_BIT)
        && (m_cFuncCode != MWR_WORD)
        && (m_cFuncCode != R_COILBITS)
        && (m_cFuncCode != R_INPUTBITS)
        && (m_cFuncCode != R_HREGWORD)
        && (m_cFuncCode != R_IREGWORD))
    {
        strErrorMsg = "Invalid function code";
        return false;
    }
    return true;
}

void BeckhoffPlcPlus::setDebugLog(int dEnable)
{
    m_nDebugEnable = dEnable;
}


IMPLEMENT_DYNAMIC( BeckhoffPlcPlus, TCPDevice )

BEGIN_MSG_MAP( BeckhoffPlcPlus, TCPDevice )
    SET_III( addParamDO, BeckhoffPlcPlus )
    SET_III( addParamDI, BeckhoffPlcPlus )
    SET_IID( addParamAI, BeckhoffPlcPlus )
    SET_IID( addParamAO, BeckhoffPlcPlus )
    SET_IDI( setAOOtherParam, BeckhoffPlcPlus )
    SET_IDI( setAIOtherParam, BeckhoffPlcPlus )
    SET_II( setAIFilterParam, BeckhoffPlcPlus )
    SET_I( setDebugLog, BeckhoffPlcPlus )
    SET_D( setReadPollIntervalMs, BeckhoffPlcPlus )
    SET_I( setWritePollTimeUs, BeckhoffPlcPlus )
    SET_V( init, BeckhoffPlcPlus )
END_MSG_MAP
