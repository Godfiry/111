/*
 * KylandShm.h
 *
 *  Created on: 2024年4月9日
 *      Author: zhangcx
 */

#ifndef KYLANDSHM_H_
#define KYLANDSHM_H_

#include <string>
//#include "KylandShmBaseNode.h"
#include "AbstractDevice.h"
#include "IntTypeInfo.h"
#include "DoubleTypeInfo.h"
#include <fstream>
#include "DeviceNode.h"
#include "IODevice.h"
#include "IMutex.h"
#include <map>
#include "Util.h"
#include "IStringList.h"
#include "unistd.h"
#include "sys/time.h"
#include "stdio.h"
#include "stdlib.h"

//typedef unsigned char       BOOL;
typedef char                SINT;
typedef int                 INT;
typedef float               REAL;

class KylandShm : public AbstractDevice {

	DECLARE_DYNAMIC(KylandShm)
	DECLARE_MSG_MAP

private:
	typedef struct 
	{
		int m_nChannelNum;
		std::string m_strDataType;
		std::string m_strDataName;
	}DataStruct;

	IMutex m_lock;

	int m_nShmWdataLength;
	int m_nShmRdataLength;
	DataStruct ShmWriteData[5000];
	DataStruct ShmReadData[5000];
	int m_nNodeNum;
	int m_nPollInterval;
	int m_nTimeOut;   

	void FloatToByte(float floatNum, unsigned char* byteArry);

private:
	/*typedef struct 
	{
		int m_nChannelNum;
		std::string m_strDataType;
		char* m_strDataName;
	}Wtruct;

	typedef struct 
	{
		int m_nChannelNum;
		std::string m_strDataType;
		char* m_strDataName;
	}RStruct;

	Wtruct SHM_DOUT;
	RStruct SHM_DIN;*/

	//static KylandShmBaseNode *m_KylandShmBaseNode;

	typedef struct 
	{
		SINT type;//1--bool;2--int;3--double
		INT wr_cnt;
		bool value_bool;
		INT value_dint;
		REAL value_real;

		/*typedef struct {
		SINT type;
		INT wr_cnt;
		BOOL value_bool;
		DINT value_dint;
		REAL value_real;
		} __attribute__((packed)) Stest_1;*/

		/*string m_strDataName;
		string m_strDataType;
		bool m_bValue;
		int m_nValue;
		double m_dValue;*/
	} __attribute__((packed)) Stest_1;
	
	typedef struct 
	{
		Stest_1 address[1300];
	}JGT;

	//JGT SHM_DOUT;
	//JGT SHM_DIN;

	JGT SHM_WOUT;
	JGT SHM_RIN;


public:
	KylandShm();
	virtual ~KylandShm();

	virtual void loadDevice();

	virtual void init();
	virtual void initChs(DeviceNode<KylandShm> *node);

	bool readInt(int nChannelNum, int *nValue, const IntTypeInfo &typeInfo);
	bool readDouble(int nChannelNum, double *dValue, const DoubleTypeInfo &typeInfo);
	bool writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo);
	bool writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo);

	void setTimeOut(int nTime);
	void setNodeNum(int nNodeNum);
	void setPollIntervalMS(int nInterval);

protected:
	int findStruct(DataStruct Data[], int nLength, int nChannelNum);

	int getLength(string strPath);
	void generateStruct(string strPath ,DataStruct *Data);

	bool writeShm(char * pBlockName, unsigned int pBlockSize, void * pData);
	bool readShm(char * pBlockName, unsigned int pBlockSize, void * pData);

	/*void writeINTData(int nIndex, int nValue);
	void writeSINTData(int nIndex, int nValue);
	void writeDINTData(int nIndex, int nValue);
	void writeREALData(int nIndex, double dValue);
	void writeSREALData(int nIndex, double dValue);

	int readINTData(int nIndex, int *nValue);
	int readSINTData(int nIndex, int *nValue);
	void readDINTData(int nIndex, int *nValue);
	double readREALData(int nIndex, double *dValue);
	double readSREALData(int nIndex, double *dValue);*/

	void makeWriteShmData();
};

#endif /* KYLANDSHM_H_ */
