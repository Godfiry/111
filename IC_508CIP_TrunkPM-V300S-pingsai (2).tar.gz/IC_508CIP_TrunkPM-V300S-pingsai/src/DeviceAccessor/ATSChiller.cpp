/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: ATSChiller.cpp
** Description:  
** Release: 1.1
** Modification history: 
** 					2009-11-25   LiJuanjuan create
**					2016-10-18   mujy modify [V1.5.16]
* 					2021-1-28	chenmz modify [V1.1.3] for being compatible with Dual Channel.
*********************************************************************/
#include "ATSChiller.h"
#include "DeviceManager.h"

#include "Converter.h"
#include "StrTool.h"
#include "Hex.h"
#include "CheckCalculationTool.h"
#include <cctype>
#include <iostream>
#ifdef IAP4_0
using namespace IAP::IO;
using namespace IAP::CORE;
using namespace IAP;
#endif

using namespace std; 

ATSChiller::Cmd ATSChiller::m_cmd[] = {{""},//reserved
											{":0117010000000109000102",0},//1 stop/start
											{":011701000000010A000102",0},//2 set temprature
											
											{":011701010002010A000000",0},//3 read temprature
											{":011701070002010A000000",0},//4 read pump temprature
											{":011701080002010A000000",0},//5 read water flow
											{":011701000002010A000000",0x8000},//6 read fault summary
											{":011701000002010A000000",0x4000},//7 read warn summary
											{":011701020002010A000000",0x0400},//8 read local remote
											{":011701000002010A000000",0xC000},//9 read alarm
											{":011701020002010A000000",0x0800},//10 read on off // added by mujy [V1.5.16]
											{":0217010000000109000102",0},//11 channel2 stop/start
											{":021701000000010A000102",0},//12 channel2 set temprature

											{":021701010002010A000000",0},//13 channel2 read temprature
											{":021701070002010A000000",0},//14  channel2 read pump temprature
											{":021701080002010A000000",0},//15 channel2 read water flow
											{":021701000002010A000000",0x8000},//16 channel2 read fault summary
											{":021701000002010A000000",0x4000},//17 channel2 read warn summary
											{":021701020002010A000000",0x0400},//18 channel2 read local remote
											{":021701000002010A000000",0xC000},//19 channel2 read alarm
											{":021701020002010A000000",0x0800}//20 channel2 read on off
};

ATSChiller::ATSChiller():SerialDevice(200, "\x0D\x0A")
{
	m_timeOut = 50;//5s
	m_pollPeriod = 1000; //1s		
}

ATSChiller::~ATSChiller()
{
}

bool ATSChiller::writeDouble(int nChannelNum, double dValue, const DoubleTypeInfo &typeInfo)
{
	string strCommand = m_cmd[nChannelNum].m_strAddress;
	//int t_temp = (int)((value + 60) * 65535 / 220);
	double dTmp = (double)((dValue + 60) * 65535 / 220);//modified by chenmz [V2.0.4]
	double dTmp1 = (int) dTmp;
	int nTemp = dTmp1;
	string strTemp = Hex::hexToString(nTemp,4);// modified by mujy [V1.5.16]
	
	strCommand += strTemp;
	strCommand += CheckCalculationTool::GetLRCCode(strCommand);
	strCommand = StrTool::toUpper(strCommand);
	string strResponse = getCommandResult(strCommand, m_timeOut);
	int nPos = strResponse.find(":", 0);
	if(nPos == string::npos)
	{
		if(strCommand.find(":02") != string::npos)
		{
			throw IOException("Chiller channel2 write temperature ["+Converter::convertToString(dValue)+"] failed for unknown response [" + strResponse+"]");
		}
		else
		{
			throw IOException("Chiller write temperature ["+Converter::convertToString(dValue)+"] failed for unknown response [" + strResponse+"]");
		}
	}
	return true;
}
		
bool ATSChiller::readDouble(int nChannelNum, double *dValue, const DoubleTypeInfo &typeInfo)
{
	Cmd cmd = m_cmd[nChannelNum];
	string strCommand = cmd.m_strAddress + CheckCalculationTool::GetLRCCode(cmd.m_strAddress);
	strCommand = StrTool::toUpper(strCommand);
	string strResponse = getCommandResult(strCommand, m_timeOut);
	int nPos = strResponse.find(":", 0);
	if(nPos == string::npos)
	{
		if(strCommand.find(":02") != string::npos)
		{
			throw IOException("Chiller channel2 read temperature failed for unknown response [" + strResponse+"]");
		}
		else
		{
			throw IOException("Chiller read temperature failed for unknown response [" + strResponse+"]");
		}
	}
	else
	{
		string strSplitValue = strResponse.substr(nPos+7, 4);
		int nValue = 0;
		if(!Hex::stringToHex(&nValue, strSplitValue))
		{
			throw IOException("Chiller read temperature failed for can't convert response ["+strSplitValue+"] to double value.");
		}
		else
		{
			switch(nChannelNum)
			{
				case 3:
				case 13:
					*dValue = nValue * 220.0/65535.0-60;//value range is from -60 to 160,see the manual
					break;
				case 4:
				case 14:
					*dValue = nValue * 2/65535.0;//value range is from 0 to 2,see the manual
					break;
				case 5:
				case 15:
					*dValue = nValue * 10/65535.0;//value range is from 0 to 10,see the manual
					break;
				default:
					break;
			}
			return true;
		}
	}
}
		
bool ATSChiller::readInt(int nChannelNum, int *pValue, const IntTypeInfo &typeInfo)
{
	Cmd cmd = m_cmd[nChannelNum];
	string strCommand = cmd.m_strAddress + CheckCalculationTool::GetLRCCode(cmd.m_strAddress);
	strCommand = StrTool::toUpper(strCommand);
	string strResponse = getCommandResult(strCommand, m_timeOut);
	int nPos = strResponse.find(":", 0);
	if(nPos == string::npos)
	{
		if(strCommand.find(":02") != string::npos)
		{
			throw IOException("Chiller channel2 read status failed for unknown response [" + strResponse+"]");
		}
		else
		{
			throw IOException("Chiller read status failed for unknown response [" + strResponse+"]");
		}
	}
	else
	{
		string strSplitValue = strResponse.substr(nPos+7, 4);
		int nValue = 0;
		if(!Hex::stringToHex(&nValue, strSplitValue))
		{
			throw IOException("Chiller read status failed for can't convert response ["+strSplitValue+"] to integer value.");
		}
		else
		{
			*pValue = (nValue & cmd.m_nDeal) != 0;
			switch(nChannelNum)
			{
				case 6:
				case 7:
				case 9:
				case 16:
				case 17:
				case 19:
					if(*pValue == 1)
					{
						SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "ATSChiller: channel ["+Converter::convertToString(nChannelNum)+"] read back = "+strResponse +" ;split value = "+strSplitValue);
					}
					break;
				case 8:
				case 10:
				case 18:
				case 20:
					if(*pValue == 0)
					{
						SysLogger::getInstance()->logMsg(LOGBRANCH::APP, LEVEL::ERROR, "ATSChiller: channel ["+Converter::convertToString(nChannelNum)+"] read back = "+strResponse+" ;split value = "+strSplitValue);
					}
					break;
				default:
					break;
			}
			return true;
		}
	}	
}
		
bool ATSChiller::writeInt(int nChannelNum, int nValue, const IntTypeInfo &typeInfo)
{
	string strCommand = m_cmd[nChannelNum].m_strAddress;
	string strAction;
	if(nValue == 1)
	{
		strCommand += "8000";
		strAction = "start";
	}
	else
	{
		strCommand += "0000";
		strAction = "stop";
	}
	strCommand += CheckCalculationTool::GetLRCCode(strCommand);
	strCommand = StrTool::toUpper(strCommand);//need test to decide if keep it
	string strResponse = getCommandResult(strCommand, m_timeOut);
	int nPos = strResponse.find(":", 0);
	if(nPos == string::npos)
	{
		if(strCommand.find(":02") != string::npos)
		{
			throw IOException("Chiller channel2 "+strAction+" failed for unknown response [" + strResponse+"]");
		}
		else
		{
			throw IOException("Chiller "+strAction+" failed for unknown response [" + strResponse+"]");
		}
	}
	return true;
}

void ATSChiller::initChs(DeviceNode<ATSChiller> *pNode)
{
	pNode->registerWriteCh(1, &ATSChiller::writeInt);
	pNode->registerWriteCh(2, &ATSChiller::writeDouble);
	for(int i = 3; i<=5; ++i)
	{
		pNode->registerReadCh(i, &ATSChiller::readDouble);
	}
	for(int i = 6; i<=10; ++i)// modified by mujy [V1.5.16]
	{
		pNode->registerReadCh(i, &ATSChiller::readInt);
	}

	pNode->registerWriteCh(11, &ATSChiller::writeInt);
	pNode->registerWriteCh(12, &ATSChiller::writeDouble);
	for(int i = 13; i<=15; ++i)
	{
		pNode->registerReadCh(i, &ATSChiller::readDouble);
	}
	for(int i = 16; i<=20; ++i)
	{
		pNode->registerReadCh(i, &ATSChiller::readInt);
	}

	pNode->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &ATSChiller::getStatus);//added by mujy [v1.0.8]
}

void ATSChiller::initDevice()
{
	cout<<"Start Scan Chiller...."<<endl;
	//say hello to chiller
	double dTemp;
	try
	{
		readDouble(3,&dTemp,DoubleTypeInfo());//3 read temprature
	}
	catch(exception &ex)
	{
		cout<<"Scan chiller failed. Communication abnormal!"<<endl;
		throw;
	}
	cout<<"Scan Chiller Successfully...."<<endl;
}

void ATSChiller::init()
{
	DeviceNode<ATSChiller> *pNode = new DeviceNode<ATSChiller>(m_pollPeriod, this);
	DeviceManager::getInstance()->registerNode(m_nodeNum, pNode);
	if(!isSimulated())
	{
		initChs(pNode);
		initDevice();
	}	
}

IMPLEMENT_DYNAMIC(ATSChiller, SerialDevice )

BEGIN_MSG_MAP(ATSChiller, SerialDevice )
	SET_V( init, ATSChiller )
END_MSG_MAP
