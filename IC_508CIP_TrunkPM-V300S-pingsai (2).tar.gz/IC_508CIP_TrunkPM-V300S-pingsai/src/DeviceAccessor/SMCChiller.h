/********************************************************************
** Copyright (c) 2006, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: SMCChiller.h
** Description: This driver is used for SMC Chiller 
*                RS485
* 				   Communication Type:Modbus protocol,ASCII Mode
* 				   BaudRate:9600
*                DataBit:7
*                StopBit:1
*                Parity:Even
* 					Check algorithm:LRC method
*                FlowControl:no flow control 
** Release: 1.1
** Modification history: 
** 					2010-10-21   caom create
**      
*********************************************************************/

#ifndef SMCCHILLER_
#define SMCCHILLER_

#include "SerialDevice.h"
#include "DeviceNode.h"
#include "ControlObject.h"
#include "ReadWriteInt.h"
#include "ReadOnlyInt.h"
#include "DoubleTypeInfo.h"
#include "IntTypeInfo.h"
#ifdef IAP4_0
using namespace IAP::CONTROL;
using namespace IAP::IO;
#endif
using namespace std;


class SMCChiller:public SerialDevice
{
	DECLARE_DYNAMIC(SMCChiller)	
	DECLARE_MSG_MAP	
 public:
	SMCChiller();
	virtual ~SMCChiller();

	bool writeDouble(int nChannelNum, double dValue,const DoubleTypeInfo &typeInfo);
	bool readDouble(int nChannelNum, double *pValue,const DoubleTypeInfo &typeInfo);
    bool writeInt(int nChannelNum, int nValue,const IntTypeInfo &typeInfo);
	bool readInt(int nChannelNum, int *pValue,const IntTypeInfo &typeInfo);

	void init();
protected:
    void initDevice();
    void initChs(DeviceNode<SMCChiller>* pNode);

private:
	typedef struct
	{
		std::string m_strAddress;
		int m_nDeal;
	}Cmd;

	static Cmd m_cmd[];
};


#endif /*SMCCHILLER_*/
