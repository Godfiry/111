#ifndef RECIPETIMEINFO_
#define RECIPETIMEINFO_

#include "DoubleValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif
class RecipeTimeInfo : public DoubleValueInfo
{
public:
    static const DoubleTypeInfo typeInfo;
    //= new ContinuousTypeInfo(0.0D, 360000D, "sec", "0.001", "1");

	RecipeTimeInfo()
	{
	}
	
	RecipeTimeInfo(double d):DoubleValueInfo(d, this->typeInfo)
	{
	}
};

#endif /*RECIPETIMEINFO_*/
