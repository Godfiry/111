/*
 * TimerEx.cpp
 *
 *  Created on: 2021-07-16
 *      Author: lvjiawen
 */

#include "TimerEx.h"

TimerEx::TimerEx()
{
    m_pTicker = NULL;
}

TimerEx::~TimerEx()
{
}

void TimerEx::setTicker(ITimeTicker * pTicker)
{
    m_pTicker = pTicker;
    subscribe(this);
}

#ifdef IAP4_0
void TimerEx::updateFromTimer(const Timer * const timer)
#else
void TimerEx::updateFromTimer()
#endif
{
    m_pTicker->updateFromTimer(this);
}
