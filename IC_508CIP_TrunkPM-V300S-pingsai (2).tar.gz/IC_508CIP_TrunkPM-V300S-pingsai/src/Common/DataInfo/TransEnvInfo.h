/**************************************************************************
** Copyright (c) 2008, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: .h
** Description: 
** Release: 
** Modification history: 
** 					2023-10-31   GuoJin create
**      
***************************************************************************/
#ifndef TRANSENVINFO_H_
#define TRANSENVINFO_H_
#include "IntValueInfo.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class TransEnvInfo : public IntValueInfo
{
public:

		static const int UnInit = -1;
		static const int Unknown = 0;
		static const int AtAtm = 1;
		static const int InBetWeen = 2;
		static const int AtHiVac = 3;
		static const IntTypeInfo typeInfo;

	   TransEnvInfo():IntValueInfo(-1, typeInfo)
	   {
	   }
	
	   TransEnvInfo(int i):IntValueInfo(i, typeInfo)
	    {
	    }
	
	   TransEnvInfo(std::string s):IntValueInfo(s, typeInfo)
	    {
	    }
};


#endif /*TRANSENVINFO_H_*/
