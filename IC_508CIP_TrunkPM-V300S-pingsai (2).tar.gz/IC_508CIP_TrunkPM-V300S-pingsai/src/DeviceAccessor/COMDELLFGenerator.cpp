/********************************************************************
** Copyright (c) 2017, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: COMDELLFGenerator.cpp
** Description: COMDELLFGenerator is the class of COMDEL LF Generator of CBH1K 
** Release: 1.1
** Modification history: 
** 					2017-3-9   mujy create
**      
*********************************************************************/
#include "COMDELLFGenerator.h"

#include "DeviceManager.h"
#include "ConfigException.h"

#include <cmath>
#include <sys/time.h>
#include <iostream>
#include <string.h>
#ifdef IAP4_0
using namespace IAP::IO;
#endif
using namespace std;

COMDELLFGenerator::COMDELLFGenerator()
{
	m_nStatus = -1;
}

COMDELLFGenerator::~COMDELLFGenerator()
{
}

bool COMDELLFGenerator::writeDouble(int channelNum, double value, const DoubleTypeInfo &typeInfo)
{
	int outputBytes = m_deviceNet->getOBytesSize(m_macID);
	char buffer[outputBytes];
	memset(buffer, 0, outputBytes);	
	unsigned long  temp =(unsigned long)((value / m_dMaxLFPower) * 4095);//0xFFF
	buffer[0] = temp & 0xff;
	buffer[1] = (temp >> 8) & 0x0f;
	buffer[2] = 0x00;
	buffer[3] = 0x00;
	buffer[4] = m_pBufferSave[4];
	m_pBufferSave[0]=buffer[0];
	m_pBufferSave[1]=buffer[1];
	return m_deviceNet->writeByte(m_macID, buffer);
}
bool COMDELLFGenerator::writeInt(int channelNum, int value, const IntTypeInfo &typeInfo)
{
	int outputBytes = m_deviceNet->getOBytesSize(m_macID);
	char buffer[outputBytes];
	memset(buffer, 0, outputBytes);
	buffer[0]=m_pBufferSave[0];
	buffer[1]=m_pBufferSave[1];
	buffer[2] = 0x00;
	buffer[3] = 0x00;

	if(0==value)
	{
	   buffer[4]=0x00;
	}
    
	if(1==value)
	{
		buffer[4]=0x01;
	}
	m_pBufferSave[4] = buffer[4];
	
	return m_deviceNet->writeByte(m_macID, buffer);
}

bool COMDELLFGenerator::readDouble(int channelNum, double *value,const DoubleTypeInfo &typeInfo )
{
	int inputBytes = m_deviceNet->getIBytesSize(m_macID);
	char buffer[inputBytes];
	memset(buffer, 0, inputBytes);
	m_deviceNet->readByte(m_macID, buffer);

	unsigned long temp = 0;
	
	if(channelNum == 1)
	{
		temp = (buffer[0] &0xff) + ((buffer[1] << 8) & 0x0f00);	
		*value = (((double)temp)/4095) * typeInfo.getMax();//0xFFF = 4095;
	}
	if(channelNum == 3)
	{
		temp = (buffer[2] &0xff) + ((buffer[3] << 8) & 0x0f00);	
		*value = (((double)temp)/4095) * typeInfo.getMax();//0xFFF = 4095;
	}
	m_nStatus = buffer[8] & 0xFF;
	return true;	
}

bool COMDELLFGenerator::readInt(int channelNum, int *value,const IntTypeInfo &typeInfo )
{
	if(m_nStatus >= 0)
	{
		*value = (m_nStatus>>(channelNum-9))&0x01;
		return true;
	}
	return false;
}
bool COMDELLFGenerator::setMaxLFPower(double value)
{
	m_dMaxLFPower = value;
	return true;
}

void COMDELLFGenerator::init()
{
	if(!isSimulated())
	{
		initDeviceNet();
		memset(m_pBufferSave, 0, 5);
	}
	DeviceNode<COMDELLFGenerator> * node = new DeviceNode<COMDELLFGenerator>(m_pollInterval,this);
		
	node->registerReadCh(1, &COMDELLFGenerator::readDouble);//LFFWDLPAI
	node->registerWriteCh(2, &COMDELLFGenerator::writeDouble);//LFSetpointAO
	node->registerReadCh(3, &COMDELLFGenerator::readDouble);//LFReflectAI
	node->registerWriteCh(8, &COMDELLFGenerator::writeInt);//LFPowerOn
	/*9:POS  = Power on status,   1=power output on,     0=power output off;
	 10:SPS  = Setpoint status,   1=setpoint reached,    0=setpoint not reached;
	 11:TS   = Temperature Status,1 = Normal range,      0=overtemp;
	 13:INTS = Interlock Status,  1=satisfied,           0=open;
	 14:SPE  = Serial Port Status,1=no serial connection,0=serial connection*/
	for(int i = 9; i <= 14; ++i)
	{
		node->registerReadCh(i, &COMDELLFGenerator::readInt);	
	}
	node->registerReadCh(COMMUNICATION_STATUS_CHANNEL, &COMDELLFGenerator::getStatus);
	DeviceManager::getInstance()->registerNode(m_nodeNum, node);
}

IMPLEMENT_DYNAMIC(COMDELLFGenerator, IODevice )
BEGIN_MSG_MAP( COMDELLFGenerator, IODevice )
	SET_D(setMaxLFPower, COMDELLFGenerator)
END_MSG_MAP


