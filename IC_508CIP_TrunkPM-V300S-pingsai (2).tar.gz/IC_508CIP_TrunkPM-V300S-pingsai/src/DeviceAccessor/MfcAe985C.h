/******************************************************************************
** Copyright (c) 2018, Beijing NMC Co.,Ltd.  All rights reserved.
** File name: MfcAe985C.h
** Description: RS-485 for Series Mass Flow Controller(AE 985C) Controllers and Meters.
*                RS485
* 				 BaudRate:38400
*                DataBit:8
*                StopBit:1
*                Parity:none
*                Byte order:LSB first
*                         
** Release: 1.1
 *   
 *
 * Modified:
 * the channels as below will be delete in release version because those are unuseful:
 * MfcAe985C*_alarmAT/MfcAe985C*VoltageAT/MfcAe985C*_valveSP
 ******************************************************************************/
#ifndef MFCAE985C_H_
#define MFCAE985C_H_


#include "SerialDevice.h"
#include "DeviceNode.h"
#ifdef IAP4_0
using namespace IAP::IO;
#endif

class MfcAe985C : public SerialDevice
{
    DECLARE_DYNAMIC(MfcAe985C)
    DECLARE_MSG_MAP

	public:
		MfcAe985C();
		virtual ~MfcAe985C();

	public://xml config
		void init();
		void setBrooksMFC(string strBrooksMFC);

	public:
		bool WriteCt(int nChannelNum,double dSetValue ,const DoubleTypeInfo& typeinfo);
		bool ReadCt(int nChannelNum, double *pValue  ,const DoubleTypeInfo& typeinfo);
		bool WriteVDt( int nChannelNum,int nSetValue ,const IntTypeInfo& typeinfo);

	    bool WriteBrooksMFCFlowRate(int nChannelNum,double dSetValue ,const DoubleTypeInfo& typeinfo);
	    bool ReadBrooksMFCFlowRate(int nChannelNum, double *pValue  ,const DoubleTypeInfo& typeinfo);

		void InitMFC();
		void InitChannels(DeviceNode<MfcAe985C> *node);

	private:
		static const int MAX_MESSAGE_LEN = 100;

		char Message[MAX_MESSAGE_LEN];
		char Response[MAX_MESSAGE_LEN];

		vector<int> m_vectorBrooksMFC;

	    int   GetBrooksMFCCheckSum(char * buff);

	    static const int write_message_length = 11;  /* message length for transmiting the message */
	    static const int read_message_length = 9;
	    static const int receive_message_length = 21;  /* message length for receiving the message */
	    static const int receive_alarm_length = 23;  /* message length for receiving the message */
	    static const int msg_timeout = 10;/*timeout in deciseconds before deciding that message has failed*/
};

#endif /*MFC_H_*/
